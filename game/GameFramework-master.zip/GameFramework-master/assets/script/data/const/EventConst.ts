export class SocketEvent {
    public static readonly SOCKET_OPEN = 'SOCKET_OPEN';
    public static readonly SOCKET_CLOSE = 'SOCKET_CLOSE';
}

export class GameEvent {
    public static readonly LOGIN_SUCCESS = 'LOGIN_SUCCESS';
}