module.exports = {
    1: {
        fruit: "香蕉",
        cost: 1,
        num: 5
    },
    2: {
        fruit: "苹果",
        cost: 1,
        num: 6
    },
    3: {
        fruit: "草莓",
        cost: 1,
        num: 7
    }
};