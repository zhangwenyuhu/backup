module.exports = {
    1: {
        name: "小明",
        age: 10,
        is_man: !0,
        relationship: {
            "爸爸": "小明爸",
            "妈妈": "小明妈"
        },
        array_test: [ "a", 1, [ 2, "c" ] ]
    },
    2: {
        name: "小红",
        age: 20,
        is_man: !1,
        relationship: {
            "爸爸": "小红爸",
            "妈妈": "小红妈"
        },
        array_test: [ "a", 1, [ 2, "c" ] ]
    }
};