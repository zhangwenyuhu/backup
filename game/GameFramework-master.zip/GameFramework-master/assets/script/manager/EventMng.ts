// 偷懒，直接用EventTarget
export default new cc.EventTarget();