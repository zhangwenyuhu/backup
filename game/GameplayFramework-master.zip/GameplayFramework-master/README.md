# GameplayFramework
GameplayFramework for CocosCreator Instant Games  
The HTML form of the documentation can be found on: [https://huangx916.github.io/2019/01/01/gameplayframework/](https://huangx916.github.io/2019/01/01/gameplayframework/)
