const {ccclass, property} = cc._decorator;

@ccclass
export class PlatformManager
{
    
}