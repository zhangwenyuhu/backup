export enum EBulletType
{
    none = -1,
    slow,
    crit,
    stun,
}