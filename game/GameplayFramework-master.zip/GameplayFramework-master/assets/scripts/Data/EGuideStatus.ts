export enum EGuideStatus
{
    buyDragon1,
    buyDragon2,
    merge,
    claim,
    drag,
    buyDragon3,
    buyDragon4,
    tip,
    none,
}