export enum ETaskType
{
    none = -1,
    inviteFriend = 1,
    login = 2,
    watchVideo = 3,
    share = 4,
    playWithFriend = 5,
    mergeTimes = 10,
    speedupTimes = 11,
    killEnemy = 12
}