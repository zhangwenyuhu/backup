interface String
{
    format(...param): string;
}