import Dialog from "../core/Dialog";

const {ccclass, property} = cc._decorator;

@ccclass
export default class Toast extends Dialog {
    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    //start () {}

    // update (dt) {}

    onInit(data:any){
    }
}
