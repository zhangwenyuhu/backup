
// codecs version

export default {
	cversion:'B$'
}
