
/**
 * info
 */
class GameInfo {
    mode: "develop" | "test" | "release" ="release"
    version: string ="1.0.1"
    resVersion: number =25
    
}

var Info = GameInfo

export default new Info()