(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/login/dataCheck.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '7bd29zgHwtCb7X4DdAfna+Z', 'dataCheck', __filename);
// Script/login/dataCheck.ts

Object.defineProperty(exports, "__esModule", { value: true });
var logicChain_1 = require("../Utils/logicChain");
/**
 * 数据检查
 */
var dataCheck = /** @class */ (function (_super) {
    __extends(dataCheck, _super);
    function dataCheck() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    dataCheck.prototype.logic = function () {
        return __awaiter(this, void 0, Promise, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        var reuslt = new logicChain_1.logicResult;
                        //向下传递数据
                        reuslt.nextData = {
                            data: {}
                        };
                        resolve(reuslt);
                    })];
            });
        });
    };
    return dataCheck;
}(logicChain_1.default));
exports.default = dataCheck;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=dataCheck.js.map
        