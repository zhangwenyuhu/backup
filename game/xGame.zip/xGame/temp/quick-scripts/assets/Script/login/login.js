(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/login/login.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e913b8xt0lBr6KFdTZOFrKM', 'login', __filename);
// Script/login/login.ts

Object.defineProperty(exports, "__esModule", { value: true });
var logicChain_1 = require("../Utils/logicChain");
/**
 * 登陆
 */
var login = /** @class */ (function (_super) {
    __extends(login, _super);
    function login() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    login.prototype.logic = function (data) {
        return __awaiter(this, void 0, Promise, function () {
            var _this = this;
            return __generator(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        var reuslt = new logicChain_1.logicResult;
                        var loginLogic;
                        loginLogic = function () { return __awaiter(_this, void 0, void 0, function () {
                            var loginCallback;
                            return __generator(this, function (_a) {
                                loginCallback = function (data) {
                                    // 数据处理
                                    // 向下传递数据
                                    reuslt.nextData = {
                                        data: {
                                            data: data
                                        }
                                    };
                                    resolve(reuslt);
                                };
                                try {
                                    //await gssdk.login({});
                                    console.log("登录完成");
                                    loginCallback({});
                                }
                                catch (e) {
                                    console.error('登录异常:', e);
                                }
                                return [2 /*return*/];
                            });
                        }); };
                        setTimeout(function () {
                            loginLogic();
                        }, 3000);
                    })];
            });
        });
    };
    return login;
}(logicChain_1.default));
exports.default = login;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=login.js.map
        