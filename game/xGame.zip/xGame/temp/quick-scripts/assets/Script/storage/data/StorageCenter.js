(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/storage/data/StorageCenter.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '7d11bpeDZBEGYrwGYCPSfa+', 'StorageCenter', __filename);
// Script/storage/data/StorageCenter.ts

Object.defineProperty(exports, "__esModule", { value: true });
//import UserData from "./UserData";
var StorageBase_1 = require("../base/StorageBase");
var StorageCenter = /** @class */ (function (_super) {
    __extends(StorageCenter, _super);
    //userData = new UserData
    function StorageCenter() {
        return _super.call(this) || this;
    }
    Object.defineProperty(StorageCenter, "instance", {
        get: function () {
            if (this._instance == null) {
                this._instance = new StorageCenter();
            }
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    StorageCenter.prototype.reset = function () {
        //this.userData = new UserData
    };
    StorageCenter.prototype.applyServerReward = function (reward) {
    };
    StorageCenter.prototype.fixData = function () {
        //this.userData.boxDatas.fixData();
        //this.farmSkinData.fixData();
    };
    return StorageCenter;
}(StorageBase_1.default));
exports.default = StorageCenter;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=StorageCenter.js.map
        