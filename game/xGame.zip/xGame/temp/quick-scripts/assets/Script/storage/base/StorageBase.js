(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/storage/base/StorageBase.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'be45def1GJP4poF62PZjTvR', 'StorageBase', __filename);
// Script/storage/base/StorageBase.ts

Object.defineProperty(exports, "__esModule", { value: true });
var SafeData_1 = require("../../config/lib/SafeData");
var DataBase_1 = require("../../config/lib/DataBase");
var LocalStorage_1 = require("./LocalStorage");
var utilTest_1 = require("../../utils/utilTest");
var LoginData_1 = require("../data/LoginData");
var StorageBase = /** @class */ (function () {
    function StorageBase() {
        this.storageKey = "glee_storage";
        this.timestampKey = "glee_storage_timestamp";
        this.roleIdKey = "glee_roleId";
        this.autoInterval = 20 * 1000; //默认20秒保存一次
        this._autoSave = false;
        this._saveHandler = null;
        this.onAutoSave = null; //当默认保存时，触发
        this.loginData = new LoginData_1.default();
    }
    StorageBase.prototype.resetKey = function (oppoId) {
        this.storageKey = this.storageKey + oppoId;
        this.timestampKey = this.timestampKey + oppoId;
    };
    Object.defineProperty(StorageBase.prototype, "autoSave", {
        get: function () {
            return this._autoSave;
        },
        set: function (value) {
            var _this = this;
            if (this._autoSave == value) {
                return;
            }
            this._autoSave = value;
            if (this._autoSave) {
                this._saveHandler = setInterval(function () {
                    _this.saveToLocalStorage();
                    if (_this.onAutoSave)
                        _this.onAutoSave();
                }, this.autoInterval);
            }
            else {
                clearInterval(this._saveHandler);
            }
        },
        enumerable: true,
        configurable: true
    });
    StorageBase.prototype._saveToLocalStorage = function (async) {
        if (async === void 0) { async = true; }
        var data = this.save();
        var storage = JSON.stringify(data);
        LocalStorage_1.default.setItem(this.storageKey, storage); //保存游戏存档
        var serverTime = utilTest_1.default.instance.getSystemTime();
        LocalStorage_1.default.setItem(this.timestampKey, serverTime.getTime().toString()); //保存时间戳key
    };
    StorageBase.prototype.saveToLocalStorage = function (async) {
        if (async === void 0) { async = true; }
        try {
            return this._saveToLocalStorage(async);
        }
        catch (e) {
            console.log("本地存储异常!!");
        }
    };
    StorageBase.prototype.loadFromLocalStorage = function () {
        var storage = LocalStorage_1.default.getItem(this.storageKey);
        if (!storage) {
            return;
        }
        try {
            var data = JSON.parse(storage);
            this.load(data);
        }
        catch (e) {
            //Log.instance.error("存档解析失败",storage)
            throw new Error("存档解析失败");
        }
    };
    /**
     * 保存玩家数据至字符串
     */
    StorageBase.prototype.save = function () {
        var result = {};
        for (var key in this) {
            var data = this[key];
            if (data instanceof DataBase_1.default) {
                result[key] = this.saveObject(data);
            }
        }
        return result;
    };
    /**
     * 加载玩家数据字符串
     */
    StorageBase.prototype.load = function (data) {
        for (var key in data) {
            this[key] = this.loadObject(data[key]);
        }
    };
    StorageBase.prototype.saveObject = function (obj) {
        if (obj instanceof DataBase_1.default) {
            //遍历所有已经设置的属性，保存类名
            var result = {};
            result.__class__ = obj['_classname_'];
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    if (key.startsWith("__") && key.endsWith("__")) {
                        //属性
                        var newkey = key.substring(2, key.length - 2);
                        var value = obj[key];
                        result[newkey] = this.saveObject(value);
                    }
                }
            }
            return result;
        }
        else if (obj instanceof Array) {
            //保存数组对象
            var result = [];
            for (var i = 0; i < obj.length; i++) {
                result.push(this.saveObject(obj[i]));
            }
            return result;
        }
        else if (obj instanceof Object) {
            //常规对象数据
            var result = {};
            for (var key in obj) {
                if (obj.hasOwnProperty(key)) {
                    result[key] = this.saveObject(obj[key]);
                }
            }
            return result;
        }
        else {
            //普通数据
            return obj;
        }
    };
    StorageBase.prototype.loadObject = function (obj) {
        if (obj instanceof Array) {
            var result = [];
            for (var i = 0; i < obj.length; i++) {
                result.push(this.loadObject(obj[i]));
            }
            return result;
        }
        else if (obj instanceof Object) {
            //对象
            if (obj.__class__) {
                //数据模型
                var result = SafeData_1.DataFactory.instance.create(obj.__class__);
                if (result) {
                    for (var key in obj) {
                        if (key != "__class__" && obj.hasOwnProperty(key)) {
                            result["__" + key + "__"] = this.loadObject(obj[key]);
                        }
                    }
                    return result;
                }
                else {
                    console.log("存档解析错误，无法找到模型" + obj.__class__);
                    return null;
                }
            }
            else {
                //常规对象
                var result = {};
                for (var key in obj) {
                    if (obj.hasOwnProperty(key)) {
                        result[key] = this.loadObject(obj[key]);
                    }
                }
                return result;
            }
        }
        else {
            //普通数据
            return obj;
        }
    };
    Object.defineProperty(StorageBase.prototype, "isSaved", {
        /**
         * 本地是否已经有存档
         */
        get: function () {
            var data = LocalStorage_1.default.getItem(this.storageKey);
            return data != null && data != "";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(StorageBase.prototype, "timestamp", {
        /**
         * 获取最新保存的存档的时间戳
         */
        get: function () {
            var time = LocalStorage_1.default.getItem(this.timestampKey);
            if (time) {
                var t = parseInt(time);
                if (!isNaN(t)) {
                    return t;
                }
                else {
                    return 0;
                }
            }
            else {
                return 0;
            }
        },
        enumerable: true,
        configurable: true
    });
    /**
     * 应用服务器提供的奖励数据 需要在子类实现
     * @param reward 奖励数据
     */
    StorageBase.prototype.applyServerReward = function (reward) {
    };
    return StorageBase;
}());
exports.default = StorageBase;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=StorageBase.js.map
        