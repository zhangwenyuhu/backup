(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/layers/block/MapHelper.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '5fab8USs69BS48gk2oYESNk', 'MapHelper', __filename);
// Script/layers/block/MapHelper.ts

Object.defineProperty(exports, "__esModule", { value: true });
var MapHelper = /** @class */ (function () {
    function MapHelper() {
        this._width = 0;
        this._height = 0;
        this._width_block = 0;
        this._height_block = 0;
        this._width_count = 0;
        this._height_count = 0;
        this._blockPool = [];
    }
    Object.defineProperty(MapHelper, "instance", {
        get: function () {
            if (!this._instance)
                this._instance = new MapHelper();
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    MapHelper.prototype.initMapInfo = function (width, height, width_block, height_block) {
        this._height = Math.floor(height);
        this._width = Math.floor(width);
        this._width_block = Math.floor(width_block);
        this._height_block = Math.floor(height_block);
        this._width_count = Math.floor(this._width / this._width_block);
        this._height_count = Math.floor(this._height / this._height_block);
        for (var i = 0; i < this._height_count; i++) {
            var tmp = [];
            for (var j = 0; j < this._width_count; j++) {
                tmp.push(1);
            }
            this._blockPool.push(tmp);
        }
    };
    MapHelper.prototype.getPosX = function (xIndex) {
        var posX = 0;
        return posX = this._width_block * (xIndex + 1 / 2);
    };
    MapHelper.prototype.getPosY = function (yIndex) {
        return this._height_block * (yIndex + 1 / 2);
    };
    MapHelper.prototype.getxIndex = function (posX) {
        return Math.floor(posX / this._width_block);
    };
    MapHelper.prototype.getyIndex = function (posY) {
        return Math.floor(posY / this._height_block);
    };
    MapHelper.prototype.validBlock = function (xIndex, yIndex, value) {
        if (value === void 0) { value = 1; }
        if (this._blockPool && this._blockPool.length > yIndex && this._blockPool[yIndex].length > xIndex) {
            this._blockPool[yIndex][xIndex] = value;
        }
    };
    MapHelper.prototype.isValid = function (xIndex, yIndex) {
        if (this._blockPool && this._blockPool.length > yIndex && this._blockPool[yIndex].length > xIndex) {
            return this._blockPool[yIndex][xIndex] == 1;
        }
        return false;
    };
    return MapHelper;
}());
exports.default = MapHelper;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MapHelper.js.map
        