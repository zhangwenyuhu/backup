(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/layers/frappy/dragon_control.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '898dbx69d5N3JylQ4B3d7rc', 'dragon_control', __filename);
// Script/layers/frappy/dragon_control.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("../../core/Core");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var dragon_Control = /** @class */ (function (_super) {
    __extends(dragon_Control, _super);
    function dragon_Control() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.heroSpine = null;
        _this.gravity = -120;
        // 开始 停止
        _this.bStartMove = false;
        _this.bGameOver = false;
        // 是否向上
        _this.bUpTouch = false;
        // 横向移动控制变量
        _this.moveSpeed = 100;
        // 纵向移动控制变量
        _this.upSpeed = 0;
        _this.downFrame = 20;
        return _this;
    }
    dragon_Control.prototype.onload = function () {
    };
    dragon_Control.prototype.start = function () {
        //add keyboard input listener to call turnLeft and turnRight
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyPressed, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyReleased, this);
        this.loadSpine("spine/long", this.heroSpine, "long", function () {
            //this.holdSpineValide(true);
        });
    };
    dragon_Control.prototype.reStart = function () {
        this.bStartMove = false;
        this.bGameOver = false;
        this.node.x = -300;
        this.node.y = -150;
    };
    dragon_Control.prototype.onEnable = function () {
        cc.director.getCollisionManager().enabled = true;
        cc.director.getCollisionManager().enabledDebugDraw = true;
    };
    dragon_Control.prototype.onDisable = function () {
        cc.director.getCollisionManager().enabled = false;
        cc.director.getCollisionManager().enabledDebugDraw = false;
    };
    dragon_Control.prototype.onKeyPressed = function (event) {
        var keyCode = event.keyCode;
        if (this.bGameOver) {
            return;
        }
        switch (keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                //this.direction = -1;
                //this.bStartMove = false;
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                //this.bStartMove = true;
                break;
            case cc.macro.KEY.w:
            case cc.macro.KEY.up:
                //
                this.bStartMove = true;
                this.bUpTouch = true;
                this.upSpeed = -this.gravity * 1.5;
                break;
        }
    };
    dragon_Control.prototype.onKeyReleased = function (event) {
        var keyCode = event.keyCode;
        if (this.bGameOver) {
            return;
        }
        switch (keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                //this.reStart()
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                //this.direction = 0;
                break;
            case cc.macro.KEY.w:
            case cc.macro.KEY.up:
                //
                this.bUpTouch = false;
                break;
        }
    };
    dragon_Control.prototype.onCollisionEnter = function (other, self) {
        console.log("Hero collision enter");
        //this.node.color = cc.Color.RED;
        this.bStartMove = false;
        this.bGameOver = true;
        Core_1.default.instance.toast("Game Over~");
    };
    dragon_Control.prototype.onCollisionStay = function (other, self) {
    };
    dragon_Control.prototype.onCollisionExit = function (other) {
        console.log("Hero collision exit");
    };
    dragon_Control.prototype.update = function (dt) {
        if (!this.bStartMove || this.bGameOver) {
            return;
        }
        console.log("update: " + dt);
        //this.holdSpineValide(true);
        // 纵向速度
        this.upSpeed = this.bUpTouch ? this.upSpeed : (this.upSpeed - this.downFrame);
        console.log("dragon speed: " + this.upSpeed);
        this.node.x += this.moveSpeed * dt;
        this.node.y += this.upSpeed * dt;
    };
    dragon_Control.prototype.onDestroy = function () {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyPressed, this);
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyReleased, this);
    };
    // spine
    dragon_Control.prototype.holdSpineValide = function (bValide) {
        var nodeSpine = cc.find("hold", this.node);
        if (nodeSpine) {
            nodeSpine.active = bValide;
        }
    };
    dragon_Control.prototype.loadSpine = function (url, spineComponent, spineName, callback) {
        cc.loader.loadRes(url, sp.SkeletonData, function (err, sp) {
            if (err) {
                console.log(err);
            }
            else {
                spineComponent.skeletonData = sp;
                var dragon_track = spineComponent.setAnimation(0, 'idle', true);
                /*
                spineComponent.setAnimation(0, 'ruchang', false);
                spineComponent.setCompleteListener(e => {
                    spineComponent.setAnimation(0, 'idle', true);
                });*/
                if (callback) {
                    callback();
                }
            }
        });
    };
    __decorate([
        property(sp.Skeleton)
    ], dragon_Control.prototype, "heroSpine", void 0);
    dragon_Control = __decorate([
        ccclass
    ], dragon_Control);
    return dragon_Control;
}(cc.Component));
exports.default = dragon_Control;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=dragon_control.js.map
        