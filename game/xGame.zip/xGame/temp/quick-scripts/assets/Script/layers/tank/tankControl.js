(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/layers/tank/tankControl.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e666dZXmOpMr4UR8xsObHsH', 'tankControl', __filename);
// Script/layers/tank/tankControl.ts

Object.defineProperty(exports, "__esModule", { value: true });
var tankGame_1 = require("./tankGame");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var TankGame_Statu;
(function (TankGame_Statu) {
    TankGame_Statu[TankGame_Statu["stand"] = 0] = "stand";
    TankGame_Statu[TankGame_Statu["playing"] = 1] = "playing";
    TankGame_Statu[TankGame_Statu["pause"] = 2] = "pause";
    TankGame_Statu[TankGame_Statu["over"] = 3] = "over";
})(TankGame_Statu = exports.TankGame_Statu || (exports.TankGame_Statu = {}));
var tankControl = /** @class */ (function () {
    function tankControl() {
        this._gameStatu = TankGame_Statu.stand;
        this._gameLayer = null;
    }
    tankControl_1 = tankControl;
    Object.defineProperty(tankControl, "instance", {
        get: function () {
            if (!this._instance) {
                this._instance = new tankControl_1();
            }
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(tankControl.prototype, "gameStatu", {
        get: function () {
            return this._gameStatu;
        },
        set: function (value) {
            this._gameStatu = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(tankControl.prototype, "gameCenter", {
        get: function () {
            return this._gameLayer;
        },
        set: function (value) {
            this._gameLayer = value;
        },
        enumerable: true,
        configurable: true
    });
    tankControl.prototype.BornBullet = function (group, p, sp) {
        if (this._gameLayer) {
            var gameScript = this._gameLayer.getComponent(tankGame_1.default);
            if (gameScript) {
                gameScript.runBullet(group, p, sp);
            }
        }
    };
    var tankControl_1;
    tankControl._instance = null;
    tankControl = tankControl_1 = __decorate([
        ccclass
    ], tankControl);
    return tankControl;
}());
exports.default = tankControl;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=tankControl.js.map
        