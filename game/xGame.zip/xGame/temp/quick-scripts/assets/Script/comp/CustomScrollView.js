(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/comp/CustomScrollView.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b5ddeQA38ZP1KGwnD+F45aR', 'CustomScrollView', __filename);
// Script/comp/CustomScrollView.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var CustomScrollView = /** @class */ (function (_super) {
    __extends(CustomScrollView, _super);
    function CustomScrollView() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.useValidCellSize = true;
        _this.cellSize = cc.size(100, 100);
        _this.cell = null;
        _this.prefabCell = null;
        _this._lastRefreshTime = 100;
        _this._scrollView = null;
        _this._nodePool = new cc.NodePool();
        _this._freshFunc = null;
        _this._data = null;
        _this._inited = {};
        _this._onRender = false;
        _this._isLoaded = false;
        _this._autoReleasePool = true;
        return _this;
    }
    CustomScrollView.prototype.onLoad = function () {
        if (this._isLoaded) {
            return;
        }
        this._isLoaded = true;
        if (this.cell) {
            this.cellSize = this.cell.getContentSize();
        }
        this._scrollView = this.node.getComponent(cc.ScrollView);
        cc.assert(this._scrollView, "cc.ScrollView组件缺失");
        var scrollHandler = new cc.Component.EventHandler();
        scrollHandler.component = "CustomScrollView";
        scrollHandler.target = this.node;
        scrollHandler.handler = "_onScrollViewEvent";
        this._scrollView.scrollEvents.push(scrollHandler);
        this._scrollView.content.removeAllChildren(true);
    };
    CustomScrollView.prototype.start = function () {
    };
    /**
     * @param data 数据
     * @param freshFunc 刷新每个节点的方法  freshFunc(node,index,data)
     */
    CustomScrollView.prototype.setData = function (data, freshFunc, relocate) {
        var _this = this;
        if (relocate === void 0) { relocate = false; }
        if (this._isOnLoadCalled == 0) {
            this.onLoad();
        }
        this._data = data;
        this._freshFunc = freshFunc;
        this._inited = {};
        if (relocate) {
            this._scrollView.stopAutoScroll();
            if (this._scrollView.horizontal) {
                this._scrollView.scrollToPercentHorizontal(1, 0);
            }
            else {
                this._scrollView.scrollToPercentVertical(1, 0);
            }
        }
        this._refreshContentNodes();
        this._scrollView.content.getComponent(cc.Layout).updateLayout();
        this.scheduleOnce(function () {
            if (_this.onLoaded) {
                _this.onLoaded();
            }
            _this._refreshContent();
        }, 1 / 30);
    };
    /**
     * 节点数量不变 单纯刷新的时候用
     * @param index 节点index
     * @param data 新的数据
     */
    CustomScrollView.prototype.refreshItem = function (index, data) {
        if (index >= this._data.length) {
            console.error("Index Out Range");
        }
        this._data[index] = data;
        this._inited[index] = false;
        this._refreshContent();
    };
    /**
     * 创建一个占位的node
     */
    CustomScrollView.prototype._createNewNode = function (newSize) {
        var node = new cc.Node();
        node.setContentSize(newSize ? newSize : this.cellSize);
        return node;
    };
    CustomScrollView.prototype._onScrollViewEvent = function (sender, eventType) {
        if (eventType === cc.ScrollView.EventType.SCROLLING) {
            // if(Date.now() - this._lastRefreshTime > 100){
            this._refreshContent();
            // this._lastRefreshTime = Date.now();
            // }
        }
        else if (eventType === cc.ScrollView.EventType.SCROLL_ENDED
            || eventType === cc.ScrollView.EventType.AUTOSCROLL_ENDED_WITH_THRESHOLD) {
            this._refreshContent();
        }
    };
    //占位的node
    CustomScrollView.prototype._refreshContentNodes = function () {
        if (this._scrollView.content.childrenCount < this._data.length) {
            for (var i = 0; i < this._data.length; i++) {
                if (i >= this._scrollView.content.childrenCount) {
                    var node = null;
                    if (this._data[i] && this._data[i].height) {
                        node = this._createNewNode(cc.size(this.cell.width, this._data[i].height));
                    }
                    else {
                        node = this._createNewNode();
                    }
                    this._scrollView.content.addChild(node);
                }
                else {
                    // this._scrollView.content.children[i].active = true
                }
            }
        }
        else if (this._scrollView.content.childrenCount > this._data.length) {
            for (var i = this._scrollView.content.childrenCount - 1; i >= this._data.length; i--) {
                var child = this._scrollView.content.children[i];
                if (child.childrenCount > 0) {
                    this._nodePool.put(child.children[0]);
                }
                // child.active = false
                child.removeFromParent(true);
                // child.destroy()
            }
        }
    };
    CustomScrollView.prototype.setOutsidePool = function (pool, autoRelease) {
        if (autoRelease === void 0) { autoRelease = true; }
        this._nodePool = pool;
        this._autoReleasePool = autoRelease;
    };
    CustomScrollView.prototype._getCellNode = function () {
        var node = this._nodePool.get();
        if (!node) {
            node = this.cell ? cc.instantiate(this.cell) : cc.instantiate(this.prefabCell);
        }
        return node;
    };
    CustomScrollView.prototype._refreshContent = function () {
        if (this._onRender)
            return;
        this._onRender = true;
        for (var i = 0; i < this._scrollView.content.childrenCount; i++) {
            var child = this._scrollView.content.children[i];
            var inVisibleArea = false;
            if (this._scrollView.horizontal) { //横向滑动
                var tempX = child.x + this._scrollView.content.x;
                inVisibleArea = (tempX > -this._scrollView.node.width && tempX < this._scrollView.node.width);
            }
            else if (this._scrollView.vertical) { //纵向滑动
                var tempY = child.y + this._scrollView.content.y;
                inVisibleArea = (tempY > -this._scrollView.node.height && tempY < this._scrollView.node.height);
            }
            if (inVisibleArea && !this._inited[i]) {
                if (child.childrenCount == 0) {
                    var node = this._getCellNode();
                    child.addChild(node);
                    node.position = cc.p(0, 0);
                }
                this._freshFunc(child.children[0], i, this._data[i]);
                this._inited[i] = true;
            }
            else if (!inVisibleArea) {
                this._nodePool.put(child.children[0]);
                this._inited[i] = false;
            }
        }
        this._onRender = false;
    };
    CustomScrollView.prototype.recycleForce = function () {
        for (var _i = 0, _a = this._scrollView.content.children; _i < _a.length; _i++) {
            var child = _a[_i];
            this._nodePool.put(child.children[0]);
        }
    };
    CustomScrollView.prototype.onDestroy = function () {
        if (this._autoReleasePool) {
            this._nodePool.clear();
        }
        this._nodePool = null;
    };
    CustomScrollView.prototype.removeItem = function (index) {
        var child = this._scrollView.content.children[index];
        if (child) {
            this._nodePool.put(child.children[0]);
            child.destroy();
            for (var i = index; i < this._scrollView.content.childrenCount; i++) {
                this._inited[i] = this._inited[i + 1];
            }
        }
    };
    __decorate([
        property
    ], CustomScrollView.prototype, "useValidCellSize", void 0);
    __decorate([
        property(cc.Size)
    ], CustomScrollView.prototype, "cellSize", void 0);
    __decorate([
        property(cc.Node)
    ], CustomScrollView.prototype, "cell", void 0);
    __decorate([
        property(cc.Prefab)
    ], CustomScrollView.prototype, "prefabCell", void 0);
    CustomScrollView = __decorate([
        ccclass
    ], CustomScrollView);
    return CustomScrollView;
}(cc.Component));
exports.default = CustomScrollView;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=CustomScrollView.js.map
        