(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/config/cfg/TableInit.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'fd80dran5pIkamgf5CPIX7n', 'TableInit', __filename);
// Script/config/cfg/TableInit.ts

Object.defineProperty(exports, "__esModule", { value: true });
var cropconfig_1 = require("./cropconfig");
var isInit = false;
var list = { cropconfig: cropconfig_1.cropconfigInit, };
function initTable(value) {
    if (isInit) {
        return;
    }
    cropconfig_1.cropconfigInit;
    isInit = true;
    for (var key in list) {
        var init = list[key];
        var data = value[key];
        if (data) {
            init(data.k, data.v);
        }
        else {
            init();
        }
    }
}
exports.initTable = initTable;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=TableInit.js.map
        