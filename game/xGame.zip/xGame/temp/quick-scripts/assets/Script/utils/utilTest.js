(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/utils/utilTest.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '56815/o2lpPeJywtR6E9Amn', 'utilTest', __filename);
// Script/utils/utilTest.ts

Object.defineProperty(exports, "__esModule", { value: true });
var xxtea_1 = require("../utils/crypt/xxtea");
var md5_1 = require("../utils/crypt/md5");
var LocalStorage_1 = require("../storage/base/LocalStorage");
var cropconfig_1 = require("../config/cfg/cropconfig");
var utilTest = /** @class */ (function () {
    function utilTest() {
    }
    Object.defineProperty(utilTest, "instance", {
        get: function () {
            if (!this._instance) {
                this._instance = new utilTest();
            }
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    utilTest.prototype.testCfg = function () {
        var ids = cropconfig_1.default.map(function (v, i, arr) {
            return v.cropid;
        });
        console.log(ids);
    };
    // 
    utilTest.prototype.testEncryption = function () {
        var str = "BBBBBBB";
        var key = "glee";
        var testXXtea = function () {
            var enStr = xxtea_1.default.XXTEA.encrypt(str, key);
            console.log("xxtea enStr: " + enStr);
            var deStr = xxtea_1.default.XXTEA.decrypt(enStr, key);
            console.log("xxtea deStr: " + deStr);
            var bStr = xxtea_1.default.XXTEA.encryptToBase64(str, key);
            console.log("xxtea base64 enStr: " + bStr);
            var dStr = xxtea_1.default.XXTEA.decryptFromBase64(bStr, key);
            console.log("xxtea base64 deStr: " + dStr);
        };
        var testMd5 = function () {
            var enStr = md5_1.Md5.hashStr(str);
            console.log("md5 enStr: " + enStr);
        };
        var testBase64 = function () {
            var enStr = Base64.encode(str);
            console.log("base64 enStr: " + enStr);
            var deStr = Base64.decode(enStr);
            console.log("base64 deStr: " + deStr);
        };
        testXXtea();
        testMd5();
        testBase64();
    };
    utilTest.prototype.testStorage = function () {
        var testValue = "18682237863";
        // base
        var key = "base_20190110";
        var testStr = LocalStorage_1.default.getItem(key);
        if (testStr) {
        }
        else {
            LocalStorage_1.default.setItem(key, testValue);
        }
        testStr = LocalStorage_1.default.getItem(key);
        // center
    };
    // 
    utilTest.prototype.getSystemTime = function () {
        return new Date();
    };
    utilTest.prototype.test = function () {
        var a = {
            left: {
                left: {
                    value: 4
                },
                right: {
                    value: 5
                },
                value: 2
            },
            right: {
                left: {
                    value: 6
                },
                right: {
                    value: 7
                },
                value: 3
            },
            value: 1
        };
    };
    return utilTest;
}());
exports.default = utilTest;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=utilTest.js.map
        