(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/core/Log.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '777bfY2cHFH14eF4PUiiE/u', 'Log', __filename);
// Script/core/Log.ts

Object.defineProperty(exports, "__esModule", { value: true });
// hello
// hello
console.log('hello');
var Log = /** @class */ (function () {
    function Log(_a) {
        var _b = _a === void 0 ? {} : _a, time = _b.time, tags = _b.tags;
        this.time = time;
        if (tags) {
            this.tags = tags.concat();
        }
    }
    Object.defineProperty(Log, "instance", {
        get: function () {
            if (!this._instance)
                this._instance = new Log();
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * 将消息打印到控制台，不存储至日志文件
     */
    Log.prototype.info = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        if (this.tags) {
            args = this.tags.concat(args);
        }
        if (this.time) {
            args.push(new Date().getTime());
        }
        console.log.apply(console, [' '].concat(args));
    };
    /**
     * 将消息打印到控制台，并储至日志文件
     */
    Log.prototype.warn = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        if (this.tags) {
            args = this.tags.concat(args);
        }
        if (this.time) {
            args.push(new Date().getTime());
        }
        console.warn.apply(console, [' '].concat(args));
    };
    /**
     * 将消息打印到控制台，并储至日志文件
     */
    Log.prototype.error = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        if (this.tags) {
            args = this.tags.concat(args);
        }
        if (this.time) {
            args.unshift(new Date().getTime());
        }
        console.error.apply(console, [' '].concat(args));
    };
    Log.info = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        var _a;
        (_a = Log.instance).info.apply(_a, args);
    };
    Log.warn = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        var _a;
        (_a = Log.instance).warn.apply(_a, args);
    };
    Log.error = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
        }
        var _a;
        (_a = Log.instance).error.apply(_a, args);
    };
    return Log;
}());
exports.default = Log;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Log.js.map
        