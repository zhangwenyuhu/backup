"use strict";
cc._RF.push(module, '3a1790RMfZMZJZP2qDz+feX', 'ball');
// Script/layers/pinball/ball.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var coll_type;
(function (coll_type) {
    coll_type[coll_type["up"] = 1] = "up";
    coll_type[coll_type["down"] = 2] = "down";
    coll_type[coll_type["left"] = 3] = "left";
    coll_type[coll_type["right"] = 4] = "right";
})(coll_type || (coll_type = {}));
var ball = /** @class */ (function (_super) {
    __extends(ball, _super);
    function ball() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.maxSpeed = 15;
        _this.speedEx = 3;
        _this._ballSpeed = cc.v2(0, 0);
        _this.autoMove = false;
        _this.isDraging = false;
        _this.preTouch = cc.v2(0, 0);
        return _this;
    }
    ball.prototype.onload = function () {
    };
    ball.prototype.start = function () {
        var collider = this.getComponent(cc.CircleCollider);
        if (!collider) {
            return;
        }
        this.touchBall();
    };
    Object.defineProperty(ball.prototype, "ballSpeed", {
        get: function () {
            return this._ballSpeed;
        },
        set: function (value) {
            if (Math.abs(value.x) > this.maxSpeed) {
                value.x = value.x > this.maxSpeed ? this.maxSpeed : -this.maxSpeed;
            }
            if (Math.abs(value.y) > this.maxSpeed) {
                value.y = value.y > this.maxSpeed ? this.maxSpeed : -this.maxSpeed;
            }
            console.log("change ball speed x: " + value.x + " y: " + value.y);
            this._ballSpeed = value;
        },
        enumerable: true,
        configurable: true
    });
    ball.prototype.touchBall = function () {
        this.node.on(cc.Node.EventType.TOUCH_START, function (e) {
            this.autoMove = false;
        }, this);
        this.node.on(cc.Node.EventType.TOUCH_MOVE, function (e) {
            var pos = this.node.getParent().convertTouchToNodeSpaceAR(e);
            if (this.isDraging) {
                this.ballSpeed = cc.v2(pos.x - this.preTouch.x, pos.y - this.preTouch.y);
                this.node.x += pos.x - this.preTouch.x;
                this.node.y += pos.y - this.preTouch.y;
            }
            this.isDraging = true;
            this.preTouch = pos;
        }, this);
        this.node.on(cc.Node.EventType.TOUCH_END, function (e) {
            this.autoMove = true;
            this.isDraging = false;
        }, this);
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, function (e) {
            this.autoMove = true;
            this.isDraging = false;
        }, this);
    };
    ball.prototype.checkBallMove = function () {
        if (this.autoMove) {
            var moveX = this.ballSpeed.x * this.speedEx;
            var moveY = this.ballSpeed.y * this.speedEx;
            moveX = moveX > this.maxSpeed ? this.maxSpeed : moveX;
            moveX = moveX < -this.maxSpeed ? -this.maxSpeed : moveX;
            moveY = moveY > this.maxSpeed ? this.maxSpeed : moveY;
            moveY = moveY < -this.maxSpeed ? -this.maxSpeed : moveY;
            this.node.x += moveX;
            this.node.y += moveY;
        }
    };
    ball.prototype.update = function (dt) {
        this.checkBallMove();
    };
    ball.prototype.onDestroy = function () {
    };
    ball.prototype.getNowPos = function () {
        return cc.v2(Math.floor(this.node.x), Math.floor(this.node.y));
    };
    ball.prototype.collisionDir = function (dir) {
        var bSpeed = this.ballSpeed;
        if (dir == coll_type.up) {
            bSpeed.y = bSpeed.y > 0 ? -bSpeed.y : bSpeed.y;
        }
        else if (dir == coll_type.down) {
            bSpeed.y = bSpeed.y < 0 ? -bSpeed.y : bSpeed.y;
        }
        else if (dir == coll_type.left) {
            bSpeed.x = bSpeed.x < 0 ? -bSpeed.x : bSpeed.x;
        }
        else if (dir == coll_type.right) {
            bSpeed.x = bSpeed.x > 0 ? -bSpeed.x : bSpeed.x;
        }
        if (bSpeed.x != this.ballSpeed.x || bSpeed.y != this.ballSpeed.y) {
            this.ballSpeed = bSpeed;
        }
    };
    ball.prototype.onCollisionEnter = function (other, self) {
        console.log("ball collision enter");
        // 1st step 
        // get pre aabb, go back before collision
        var otherAabb = other.world.aabb;
        var otherPreAabb = other.world.preAabb.clone();
        var selfAabb = self.world.aabb;
        var selfPreAabb = self.world.preAabb.clone();
        // 2nd step
        // forward x-axis, check whether collision on x-axis
        selfPreAabb.x = selfAabb.x;
        otherPreAabb.x = otherAabb.x;
        // 横向碰撞
        if (cc.Intersection.rectRect(selfPreAabb, otherPreAabb)) {
            console.log("横向碰撞");
            if (selfPreAabb.xMax > otherPreAabb.xMax) {
                // 自己在右边,对方在左边
                console.log("球左边碰撞");
                this.collisionDir(coll_type.left);
                var endPos = this.node.parent.convertToNodeSpaceAR(cc.v2(otherPreAabb.xMax, selfPreAabb.y));
                this.node.x = endPos.x + self.radius;
            }
            else {
                // 自己在左边,对方在右边
                console.log("球右边碰撞");
                this.collisionDir(coll_type.right);
                var endPos = this.node.parent.convertToNodeSpaceAR(cc.v2(otherPreAabb.xMin, selfPreAabb.y));
                this.node.x = endPos.x - self.radius;
            }
            //other.touchingX = true;
            return;
        }
        // 3rd step
        // forward y-axis, check whether collision on y-axis
        selfPreAabb.y = selfAabb.y;
        otherPreAabb.y = otherAabb.y;
        // 纵向碰撞
        if (cc.Intersection.rectRect(selfPreAabb, otherPreAabb)) {
            console.log("纵向碰撞");
            if (selfPreAabb.yMax > otherPreAabb.yMax) {
                // 自己在上面,对方在下面
                console.log("球下边碰撞");
                //let endPos = this.node.parent.convertToNodeSpaceAR(cc.v2(selfPreAabb.x, otherPreAabb.yMax));
                //this.node.y = endPos.y+selfPreAabb.height/2
                this.collisionDir(coll_type.down);
            }
            else {
                // 自己在下面,对方在上面
                console.log("球上边碰撞");
                //let endPos = this.node.parent.convertToNodeSpaceAR(cc.v2(selfPreAabb.x, otherPreAabb.yMin));
                //this.node.y = endPos.y-selfPreAabb.height/2-1
                this.collisionDir(coll_type.up);
            }
            //other.touchingY = true;
        }
    };
    ball.prototype.onCollisionStay = function (other, self) {
        console.log("ball collision stay");
        //this.onCollisionEnter(other,self);
    };
    ball.prototype.onCollisionExit = function (other) {
        console.log("ball collision exit");
    };
    ball = __decorate([
        ccclass
    ], ball);
    return ball;
}(cc.Component));
exports.default = ball;

cc._RF.pop();