"use strict";
cc._RF.push(module, '70329TTqmtLypoNHqjcCat0', 'frappy');
// Script/layers/frappy/frappy.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Dialog_1 = require("../../core/Dialog");
var GlobalEmit_1 = require("../../core/GlobalEmit");
var dragon_control_1 = require("./dragon_control");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var frappy = /** @class */ (function (_super) {
    __extends(frappy, _super);
    function frappy() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.dragon = null;
        return _this;
    }
    frappy.prototype.onInit = function (data) {
    };
    frappy.prototype.onload = function () {
    };
    frappy.prototype.onEnable = function () {
        cc.director.getCollisionManager().enabled = true;
        cc.director.getCollisionManager().enabledDebugDraw = true;
        cc.director.getCollisionManager().enabledDrawBoundingBox = true;
    };
    frappy.prototype.onDisable = function () {
        cc.director.getCollisionManager().enabled = false;
        cc.director.getCollisionManager().enabledDebugDraw = false;
        cc.director.getCollisionManager().enabledDrawBoundingBox = false;
    };
    frappy.prototype.start = function () {
    };
    frappy.prototype.update = function (dt) {
        // 
    };
    frappy.prototype.onDestroy = function () {
    };
    frappy.prototype.onClickClose = function () {
        GlobalEmit_1.default.instance.messageEmit.emit("CloseLayer", "frappy");
        this.close();
    };
    frappy.prototype.onClickStart = function () {
        if (this.dragon) {
            var control_scrip = this.dragon.getComponent(dragon_control_1.default);
            if (control_scrip) {
                control_scrip.reStart();
            }
        }
    };
    __decorate([
        property(cc.Node)
    ], frappy.prototype, "dragon", void 0);
    frappy = __decorate([
        ccclass
    ], frappy);
    return frappy;
}(Dialog_1.default));
exports.default = frappy;

cc._RF.pop();