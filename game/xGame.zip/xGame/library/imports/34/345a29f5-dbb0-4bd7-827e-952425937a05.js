"use strict";
cc._RF.push(module, '345a2n127BL14J+lSQlk3oF', 'DToast');
// Script/layers/DToast.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Dialog_1 = require("../core/Dialog");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Toast = /** @class */ (function (_super) {
    __extends(Toast, _super);
    function Toast() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    //start () {}
    // update (dt) {}
    Toast.prototype.onInit = function (data) {
    };
    Toast = __decorate([
        ccclass
    ], Toast);
    return Toast;
}(Dialog_1.default));
exports.default = Toast;

cc._RF.pop();