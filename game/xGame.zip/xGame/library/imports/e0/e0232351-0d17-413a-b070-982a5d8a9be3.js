"use strict";
cc._RF.push(module, 'e0232NRDRdBOrBwmCpdipvj', 'HttpClient');
// Script/utils/net/HttpClient.ts

Object.defineProperty(exports, "__esModule", { value: true });
var HttpClient = /** @class */ (function () {
    function HttpClient() {
    }
    /**
     * 对http发起请求
     */
    HttpClient.prototype.request = function (_a) {
        var _b = _a.method, method = _b === void 0 ? "GET" : _b, _c = _a.url, url = _c === void 0 ? null : _c, _d = _a.data, data = _d === void 0 ? null : _d, _e = _a.timeout, timeout = _e === void 0 ? 5000 : _e, _f = _a.headMap, headMap = _f === void 0 ? null : _f, _g = _a.onDone, onDone = _g === void 0 ? null : _g, _h = _a.onError, onError = _h === void 0 ? null : _h, _j = _a.onTimeout, onTimeout = _j === void 0 ? null : _j, _k = _a.onProgress, onProgress = _k === void 0 ? null : _k, _l = _a.onUploadProgress, onUploadProgress = _l === void 0 ? null : _l;
        var http = new XMLHttpRequest();
        var clearListener = function () {
            http.onreadystatechange =
                http.onprogress =
                    http.onabort =
                        http.onerror =
                            http.ontimeout = null;
            if (http.upload) {
                http.upload.onprogress = null;
            }
        };
        http.timeout = timeout;
        http.open(method, url, true);
        http.onreadystatechange = function (ev) {
            // console.log("onreadystatechange", ev)
            switch (http.readyState) {
                case 1: //OPENED  (未发送)
                    break;
                case 2: //HEADERS_RECEIVED (已获取响应头)
                    break;
                case 3: //LOADING (正在下载响应体)
                    break;
                case 4: //DONE (请求完成)
                    if (http.status == 200) {
                        if (onDone) {
                            onDone(http.responseText);
                        }
                    }
                    else {
                        if (onError) {
                            onError(http.responseText);
                        }
                    }
                    clearListener();
                    break;
            }
        };
        http.onprogress = function (ev) {
            // console.log("onprogress", ev)
            if (onProgress) {
                onProgress(ev.loaded, ev.total);
            }
        };
        http.onabort = function (ev) {
            // console.log("onabort", ev)
            if (onError) {
                onError(ev);
            }
            clearListener();
        };
        http.onerror = function (ev) {
            // console.log("onerror", ev)
            if (onError) {
                onError(ev);
            }
            clearListener();
        };
        http.ontimeout = function (ev) {
            // console.log("ontimeout", ev)
            if (onTimeout) {
                onTimeout();
            }
            clearListener();
        };
        if (http.upload) {
            http.upload.onprogress = function (ev) {
                if (onUploadProgress) {
                    onUploadProgress(ev.loaded, ev.total);
                }
            };
        }
        if (headMap) {
            for (var key in headMap) {
                var value = headMap[key];
                http.setRequestHeader(key, value);
            }
        }
        http.send(data);
    };
    return HttpClient;
}());
exports.default = HttpClient;

cc._RF.pop();