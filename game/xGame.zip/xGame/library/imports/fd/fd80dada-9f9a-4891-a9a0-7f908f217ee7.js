"use strict";
cc._RF.push(module, 'fd80dran5pIkamgf5CPIX7n', 'TableInit');
// Script/config/cfg/TableInit.ts

Object.defineProperty(exports, "__esModule", { value: true });
var cropconfig_1 = require("./cropconfig");
var isInit = false;
var list = { cropconfig: cropconfig_1.cropconfigInit, };
function initTable(value) {
    if (isInit) {
        return;
    }
    cropconfig_1.cropconfigInit;
    isInit = true;
    for (var key in list) {
        var init = list[key];
        var data = value[key];
        if (data) {
            init(data.k, data.v);
        }
        else {
            init();
        }
    }
}
exports.initTable = initTable;

cc._RF.pop();