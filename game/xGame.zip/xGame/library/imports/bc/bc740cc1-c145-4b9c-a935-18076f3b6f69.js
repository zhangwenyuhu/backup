"use strict";
cc._RF.push(module, 'bc740zBwUVLnKk1GAdvO29p', 'pinball');
// Script/layers/pinball/pinball.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Dialog_1 = require("../../core/Dialog");
var GlobalEmit_1 = require("../../core/GlobalEmit");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var pinball = /** @class */ (function (_super) {
    __extends(pinball, _super);
    function pinball() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.root = null;
        _this.ball = null;
        _this.board = null;
        _this.bDragingBoard = false;
        _this.preBoardTouch = cc.v2(0, 0);
        return _this;
    }
    pinball.prototype.onInit = function (data) {
    };
    pinball.prototype.onload = function () {
    };
    pinball.prototype.start = function () {
        cc.director.getCollisionManager().enabled = true;
        cc.director.getCollisionManager().enabledDebugDraw = true;
        this.touchBoard();
    };
    pinball.prototype.touchBoard = function () {
        this.board.on(cc.Node.EventType.TOUCH_START, function (e) {
        }, this);
        this.board.on(cc.Node.EventType.TOUCH_MOVE, function (e) {
            var pos = this.board.getParent().convertTouchToNodeSpaceAR(e);
            if (this.bDragingBoard) {
                this.board.x += pos.x - this.preBoardTouch.x;
            }
            this.bDragingBoard = true;
            this.preBoardTouch = pos;
        }, this);
        this.board.on(cc.Node.EventType.TOUCH_END, function (e) {
            this.bDragingBoard = false;
        }, this);
        this.board.on(cc.Node.EventType.TOUCH_CANCEL, function (e) {
            this.bDragingBoard = false;
        }, this);
    };
    pinball.prototype.update = function (dt) {
        // 
    };
    pinball.prototype.onDestroy = function () {
        cc.director.getCollisionManager().enabled = false;
        cc.director.getCollisionManager().enabledDebugDraw = false;
    };
    pinball.prototype.onClickClose = function () {
        GlobalEmit_1.default.instance.messageEmit.emit("CloseLayer", "pinball");
        this.close();
    };
    pinball.prototype.onClickStart = function () {
    };
    __decorate([
        property(cc.Node)
    ], pinball.prototype, "root", void 0);
    __decorate([
        property(cc.Node)
    ], pinball.prototype, "ball", void 0);
    __decorate([
        property(cc.Node)
    ], pinball.prototype, "board", void 0);
    pinball = __decorate([
        ccclass
    ], pinball);
    return pinball;
}(Dialog_1.default));
exports.default = pinball;

cc._RF.pop();