"use strict";
cc._RF.push(module, 'c9dd9+ELARCjLZOUkZyn/Gy', 'SafeData');
// Script/config/lib/SafeData.ts

Object.defineProperty(exports, "__esModule", { value: true });
// ------------------ B ------------------
function bshift23encode(s) {
    var s1t = [];
    for (var _i = 0, s_1 = s; _i < s_1.length; _i++) {
        var c = s_1[_i];
        s1t.push(String.fromCharCode((c.charCodeAt() + 23) % 65536));
    }
    return s1t.join("");
    // return s.split('').map(e=>String.fromCharCode(
    //     (e.charCodeAt()+23)%65536
    // )).join('')
}
function bshift23decode(s) {
    var s1t = [];
    for (var _i = 0, s_2 = s; _i < s_2.length; _i++) {
        var c = s_2[_i];
        s1t.push(String.fromCharCode((c.charCodeAt() - 23) % 65536));
    }
    return s1t.join("");
    // return s.split('').map(e=>String.fromCharCode(
    //     (e.charCodeAt()-23)%65536
    // )).join('')
}
function b64decode(s) {
    s = s.split("").reverse().join("");
    return Base64.decode(s);
}
function encode(value, log) {
    if (log === void 0) { log = false; }
    var type = typeof value;
    if (type == "number") {
        //对数字进行加密
        if (value % 1 === 0) {
            return "a" + bshift23encode(value.toString(16));
        }
        else {
            return "A" + bshift23encode(value.toString());
        }
    }
    else if (type == "string") {
        //对字符串进行加密
        return "R" + bshift23encode(value);
    }
    else if (type == "boolean") {
        //对布尔值进行加密
        return value ? "f" : "t";
    }
    else {
        return value;
    }
}
function decode(value, log) {
    if (log === void 0) { log = false; }
    var type = typeof value;
    if (type == "string") {
        var type_1 = value[0];
        value = value.substr(1);
        if (type_1 == "A") {
            return parseFloat(bshift23decode(value));
        }
        else if (type_1 == "a") {
            //解密数字
            return parseInt(bshift23decode(value), 16);
        }
        else if (type_1 == "R") {
            //解密字符串
            return bshift23decode(value);
        }
        else if (type_1 == "f") {
            return true;
        }
        else if (type_1 == "t") {
            return false;
        }
        else if (type_1 == "N") {
            return parseFloat(b64decode(value));
        }
        else if (type_1 == "n") {
            //解密数字
            var _a = value.split("I"), left = _a[0], right = _a[1];
            left = ~-parseInt(left, 36);
            var rr = ~-parseInt(right, 36);
            right = rr / Math.pow(10, rr.toString().length);
            return left >= 0 ? left + right : left - right;
        }
        else if (type_1 == "s") {
            //解密字符串
            return b64decode(value);
        }
    }
    else {
        return value;
    }
}
// ------------------------ B ----------------------
window["encode"] = encode;
window["decode"] = decode;
function build(target, property) {
    var value = target[property];
    var type = typeof value;
    delete target[property];
    Object.defineProperty(target, property, {
        get: function () {
            return decode(this["__" + property + "__"]);
        },
        set: function (value) {
            this["__" + property + "__"] = encode(value);
        }
    });
}
var DataFactory = /** @class */ (function () {
    function DataFactory() {
        this._creatorMap = {};
        this._creatorList = [];
    }
    DataFactory.prototype.addCreator = function (className, creator) {
        this._creatorMap[className] = creator;
        this._creatorList.push({ className: className, creator: creator });
    };
    DataFactory.prototype.create = function (className) {
        var creator = this._creatorMap[className];
        if (creator) {
            return new creator();
        }
        return null;
    };
    Object.defineProperty(DataFactory.prototype, "creatorList", {
        get: function () {
            return this._creatorList;
        },
        enumerable: true,
        configurable: true
    });
    DataFactory.instance = new DataFactory;
    return DataFactory;
}());
exports.DataFactory = DataFactory;
function SafeClass(className) {
    return function (ctor) {
        var safeclass = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            try {
                ctor.apply(this, args);
            }
            catch (e) {
                console.error("@SafeClass(" + className + ")(", args, ")\u6784\u9020\u5931\u8D25");
                throw e;
            }
            for (var key in this) {
                if (this.hasOwnProperty(key)) {
                    var value = this[key];
                    var type = typeof value;
                    build(this, key);
                    this[key] = value;
                }
            }
            this._classname_ = className;
            return this;
        };
        safeclass.prototype = ctor.prototype;
        DataFactory.instance.addCreator(className, safeclass);
        return safeclass;
    };
}
exports.SafeClass = SafeClass;
function SafeProperty(target, property) {
    var value = target[property];
    build(target, property);
    target[property] = value;
}
exports.SafeProperty = SafeProperty;

cc._RF.pop();