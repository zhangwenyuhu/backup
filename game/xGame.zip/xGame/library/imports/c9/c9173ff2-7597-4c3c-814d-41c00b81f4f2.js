"use strict";
cc._RF.push(module, 'c9173/ydZdMPIFNQcALgfTy', 'redpointUtil');
// Script/utils/redpointUtil.ts

Object.defineProperty(exports, "__esModule", { value: true });
var RedPoint;
(function (RedPoint) {
    RedPoint["banqian"] = "banqian";
    RedPoint["activity"] = "activity";
    RedPoint["ac_login"] = "ac_login";
})(RedPoint = exports.RedPoint || (exports.RedPoint = {}));
// 红点功能
/*
    红点加入流程:
    1.注册红点逻辑名称和判断函数,如果不是首层红点注册时需传入首层红点名
    2.注册红点ui节点名,用于显示和隐藏
    3.调用刷新函数刷新红点

    ex:
    1.红点系统解锁
    2.红点暂时忽略(用于某段时间不显示红点)
 */
var redpointUtil = /** @class */ (function () {
    function redpointUtil() {
        // key:节点对应的逻辑名称,func:红点判断函数,child:子节点,node:自身节点,ignore:忽略红点
        this.redpool = {};
        this.unlockRed = true; // 当前红点功能是否解锁                      
        this.redpoints = {};
    }
    Object.defineProperty(redpointUtil, "instance", {
        get: function () {
            if (!this._instance)
                this._instance = new redpointUtil();
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    redpointUtil.prototype.initRedPool = function () {
        this.initData();
        this.registFunc(RedPoint.banqian, this.funTest.bind(this));
        this.registFunc(RedPoint.activity);
        this.registFunc(RedPoint.ac_login, this.funTest.bind(this), RedPoint.activity);
    };
    // 注册红点忽略  如果忽略则不显示 不忽略则走正常逻辑
    redpointUtil.prototype.registerIgnoreRed = function (bIgnore, redName, root) {
        var redItem = this.getItem(redName);
        if (redItem) {
            redItem.ignore = bIgnore;
        }
        if (root) {
            this.freshRed(root);
        }
    };
    // 本次登录的红点不显示
    redpointUtil.prototype.valideRed = function (redName, bHide) {
        if (!this.redpoints) {
            this.redpoints = {};
        }
        this.redpoints[redName] = bHide;
    };
    redpointUtil.prototype.registNode = function (selfName, redNode) {
        var redItem = this.getItem(selfName);
        if (redItem) {
            redItem.node = redNode;
        }
        else {
            console.error("未找到该节点~");
        }
    };
    // 针对某个节点进行刷新
    redpointUtil.prototype.freshRed = function (name) {
        this.freshRedEx(name);
    };
    // 所有红点进行一次刷新
    redpointUtil.prototype.freshRedPool = function () {
        var _this = this;
        Object.keys(this.redpool).forEach(function (key) {
            _this.freshRed(key);
        });
    };
    // 红点解锁
    redpointUtil.prototype.resetUnlockRed = function () {
        var preFlag = this.unlockRed;
        this.unlockRed = true;
        if (preFlag != this.unlockRed) {
            this.freshRedPool();
        }
    };
    redpointUtil.prototype.initData = function () {
        this.unlockRed = true;
    };
    redpointUtil.prototype.funTest = function () {
        return true;
    };
    redpointUtil.prototype.registFunc = function (selfName, fun, parentName) {
        if (this.getItem(selfName)) {
            console.error("已存在该节点~");
            return;
        }
        if (parentName) {
            var pareItem = this.getItem(parentName);
            if (pareItem) {
                if (!pareItem.child) {
                    pareItem.child = {};
                }
                pareItem.child[selfName] = { func: fun };
            }
            else {
                console.error("父节点不存在~");
            }
        }
        else {
            this.redpool[selfName] = {};
            this.redpool[selfName] = { func: fun };
        }
    };
    redpointUtil.prototype.getItem = function (name) {
        var _this = this;
        var item;
        for (var key in this.redpool) {
            if (key === name) {
                item = this.redpool[key];
            }
            if (this.redpool[key].child) {
                var childRed = this.redpool[key].child;
                for (var subKey in childRed) {
                    if (subKey === name) {
                        item = childRed[subKey];
                    }
                }
            }
        }
        if (!item) {
            Object.keys(this.redpool).forEach(function (key) {
                var res = _this.getItemInChild(name, _this.redpool[key]);
                item = res ? res : item;
            });
        }
        return item;
    };
    redpointUtil.prototype.getItemInChild = function (name, item) {
        var _this = this;
        if (!name || !item || !item.child) {
            return null;
        }
        var result = null;
        Object.keys(item.child).forEach(function (key) {
            if (key === name) {
                result = item.child[key];
            }
            else {
                var res = _this.getItemInChild(name, item.child[key].child);
                result = res ? res : result;
            }
        });
        return result;
    };
    // 获取某个节点的根节点
    redpointUtil.prototype.getRootName = function (childName) {
        var _this = this;
        var rootName = "";
        Object.keys(this.redpool).forEach(function (key) {
            if (key === childName) {
                rootName = key;
            }
            else {
                if (_this.bExistInChild(childName, _this.redpool[key])) {
                    rootName = key;
                }
            }
        });
        return rootName;
    };
    // 判断某个节点的子节点中是否存在某个节点
    redpointUtil.prototype.bExistInChild = function (name, item) {
        var _this = this;
        if (!name || !item || !item.child) {
            return false;
        }
        var bFind = false;
        Object.keys(item.child).forEach(function (key) {
            if (key === name) {
                bFind = true;
            }
            else {
                if (item.child[key].child) {
                    var res = _this.bExistInChild(name, item.child[key].child);
                    bFind = res ? res : bFind;
                }
            }
        });
        return bFind;
    };
    // 刷新某个节点
    redpointUtil.prototype.freshRedEx = function (name) {
        var rootName = this.getRootName(name);
        if (rootName && this.redpool[rootName]) {
            var rootItem = this.redpool[rootName];
            var bVisible = false;
            if (rootItem.child) {
                bVisible = this.freshChildRed(rootItem);
            }
            else {
                bVisible = rootItem.func ? rootItem.func() : false;
            }
            bVisible = rootItem.ignore ? false : bVisible;
            if (rootItem.node && cc.isValid(rootItem.node)) {
                rootItem.node.active = this.unlockRed ? bVisible : false;
            }
            else {
                console.error("redpoint root-" + rootName + " node is not valid~");
            }
        }
        else {
            console.error("redpoint root-" + rootName + " is not register~");
        }
    };
    redpointUtil.prototype.freshChildRed = function (item) {
        var _this = this;
        if (!item) {
            return false;
        }
        var result = false;
        if (!item.child) {
            result = item.func ? item.func() : false;
        }
        else {
            Object.keys(item.child).forEach(function (key) {
                var res = _this.freshChildRed(item.child[key]);
                result = res ? res : result;
            });
        }
        result = item.ignore ? false : result;
        result = this.unlockRed ? result : false;
        if (item.node && cc.isValid(item.node)) {
            item.node.active = result;
        }
        return result;
    };
    redpointUtil.prototype.printRedLog = function (name, valid) {
        return;
    };
    return redpointUtil;
}());
exports.default = redpointUtil;

cc._RF.pop();