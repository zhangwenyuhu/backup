"use strict";
cc._RF.push(module, '7d11bpeDZBEGYrwGYCPSfa+', 'StorageCenter');
// Script/storage/data/StorageCenter.ts

Object.defineProperty(exports, "__esModule", { value: true });
//import UserData from "./UserData";
var StorageBase_1 = require("../base/StorageBase");
var StorageCenter = /** @class */ (function (_super) {
    __extends(StorageCenter, _super);
    //userData = new UserData
    function StorageCenter() {
        return _super.call(this) || this;
    }
    Object.defineProperty(StorageCenter, "instance", {
        get: function () {
            if (this._instance == null) {
                this._instance = new StorageCenter();
            }
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    StorageCenter.prototype.reset = function () {
        //this.userData = new UserData
    };
    StorageCenter.prototype.applyServerReward = function (reward) {
    };
    StorageCenter.prototype.fixData = function () {
        //this.userData.boxDatas.fixData();
        //this.farmSkinData.fixData();
    };
    return StorageCenter;
}(StorageBase_1.default));
exports.default = StorageCenter;

cc._RF.pop();