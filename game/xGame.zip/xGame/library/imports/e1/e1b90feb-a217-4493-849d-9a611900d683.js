"use strict";
cc._RF.push(module, 'e1b90/rohdEk4SdmmEZANaD', 'Helloworld');
// Script/Helloworld.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Scene_1 = require("../Script/core/Scene");
var Core_1 = require("./core/Core");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label = null;
        _this.text = '';
        _this.circle_pro = null;
        _this.gameScene = "xgame";
        return _this;
    }
    Helloworld.prototype.onload = function () {
        this.circle_pro.progress = 0;
        cc.director.preloadScene(this.gameScene, function () { });
    };
    Helloworld.prototype.start = function () {
        // init logic
        this.label.string = this.text;
        this.scheduleOnce(function () {
            //Core.instance.pushScene(this.gameScene);
        }, 3.5);
        this.schedule(function () {
            //this.updateCirclePro(this.getCirclePro()+0.05);
        }, 1);
        Core_1.default.instance.pushScene(this.gameScene);
    };
    Helloworld.prototype.update = function (dt) {
        // 
        //this.updateCirclePro(this.getCirclePro()+0.005);
    };
    Helloworld.prototype.onDestroy = function () {
    };
    Helloworld.prototype.updateCirclePro = function (flPro) {
        var pro = flPro > 1.00 ? 1.00 : flPro;
        pro = pro < 0 ? 0 : pro;
        if (this.getCirclePro() == pro) {
            return;
        }
        this.circle_pro.progress = pro;
        if (this.getCirclePro() == 1) {
            Core_1.default.instance.pushScene(this.gameScene);
        }
        console.log("xgame circle progress: " + pro);
    };
    Helloworld.prototype.getCirclePro = function () {
        if (this.circle_pro && cc.isValid(this.circle_pro)) {
            return this.circle_pro.progress;
        }
        return 0;
    };
    __decorate([
        property(cc.Label)
    ], Helloworld.prototype, "label", void 0);
    __decorate([
        property
    ], Helloworld.prototype, "text", void 0);
    __decorate([
        property(cc.ProgressBar)
    ], Helloworld.prototype, "circle_pro", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(Scene_1.default));
exports.default = Helloworld;

cc._RF.pop();