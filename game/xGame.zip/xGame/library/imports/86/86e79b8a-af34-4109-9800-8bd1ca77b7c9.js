"use strict";
cc._RF.push(module, '86e79uKrzRBCZgAi9HKd7fJ', 'UserData');
// Script/storage/data/UserData.ts

Object.defineProperty(exports, "__esModule", { value: true });
var SafeData_1 = require("../base/SafeData");
var DataBase_1 = require("../base/DataBase");
var UserData = /** @class */ (function (_super) {
    __extends(UserData, _super);
    function UserData() {
        var _this = _super.call(this) || this;
        _this.userLv = 1; //用户等级  
        _this._ap = 0; //体力
        return _this;
    }
    Object.defineProperty(UserData.prototype, "ap", {
        get: function () {
            return this._ap;
        },
        set: function (value) {
            this._ap = value;
            //GlobalEmit.instance.messsgeEmit.emit("UpdateAp");
        },
        enumerable: true,
        configurable: true
    });
    UserData = __decorate([
        SafeData_1.SafeClass("UserData")
    ], UserData);
    return UserData;
}(DataBase_1.default));
exports.default = UserData;

cc._RF.pop();