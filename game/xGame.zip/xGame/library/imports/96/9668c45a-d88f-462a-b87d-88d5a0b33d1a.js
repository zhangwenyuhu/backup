"use strict";
cc._RF.push(module, '9668cRa2I9GKrh9iNWgsz0a', 'follow');
// Script/layers/test/follow.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var follow = /** @class */ (function (_super) {
    __extends(follow, _super);
    function follow() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.target = null;
        return _this;
    }
    // use this for initialization
    follow.prototype.onLoad = function () {
    };
    follow.prototype.start = function () {
        // 由于需要键盘操作所以只能在 PC 才可用
        this.node.active = !cc.sys.isMobile || CC_PREVIEW;
        if (!this.target) {
            return;
        }
        var follow = cc.follow(this.target, cc.rect(0, 0, 4000, 750));
        this.node.runAction(follow);
    };
    __decorate([
        property(cc.Node)
    ], follow.prototype, "target", void 0);
    follow = __decorate([
        ccclass
    ], follow);
    return follow;
}(cc.Component));
exports.default = follow;

cc._RF.pop();