"use strict";
cc._RF.push(module, 'be11dDcqFJKwIaHSikdyEeT', 'GlobalEmit');
// Script/core/GlobalEmit.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GlobalEmit = /** @class */ (function () {
    function GlobalEmit() {
        this.messageEmit = new cc.EventTarget();
    }
    Object.defineProperty(GlobalEmit, "instance", {
        get: function () {
            if (!this._instance)
                this._instance = new GlobalEmit();
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    return GlobalEmit;
}());
exports.default = GlobalEmit;

cc._RF.pop();