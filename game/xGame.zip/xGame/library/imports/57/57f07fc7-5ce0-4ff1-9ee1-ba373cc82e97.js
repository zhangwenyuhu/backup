"use strict";
cc._RF.push(module, '57f07/HXOBP8Z7hujc8yC6X', 'ConfigTool');
// Script/config/lib/ConfigTool.ts

Object.defineProperty(exports, "__esModule", { value: true });
var encrypt_1 = require("./encrypt");
var SafeData_1 = require("./SafeData");
exports.SafeClass = SafeData_1.SafeClass;
var ConfigTool = /** @class */ (function () {
    function ConfigTool() {
    }
    ConfigTool.decryptTable = function (objf, ekey, datastr) {
        var data = JSON.parse(encrypt_1.Mencrypt.decrypt2(datastr, ekey));
        var config = [];
        for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
            var record = data_1[_i];
            var obj = objf();
            for (var key in record) {
                obj[key] = record[key];
            }
            config.push(obj);
        }
        return config;
    };
    return ConfigTool;
}());
exports.default = ConfigTool;
function merge(cls, data) {
    var store = new cls();
    for (var key in data) {
        store[key] = data[key];
    }
    return store;
}
exports.merge = merge;
function mergelist(cls, data) {
    var stores = [];
    for (var i = 0; i < data.length; i++) {
        stores.push(merge(cls, data[i]));
    }
    return stores;
}
exports.mergelist = mergelist;

cc._RF.pop();