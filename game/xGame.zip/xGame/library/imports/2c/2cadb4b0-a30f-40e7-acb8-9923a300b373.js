"use strict";
cc._RF.push(module, '2cadbSwow9A56y4mSOjALNz', 'RussiaBlock');
// Script/layers/block/RussiaBlock.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Dialog_1 = require("../../core/Dialog");
var GlobalEmit_1 = require("../../core/GlobalEmit");
var MapHelper_1 = require("./MapHelper");
var Core_1 = require("../../core/Core");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var block_width = 30;
var block_height = 30;
var blockType = [
    [{ x: 0, y: 0 }, { x: 0, y: -1 }, { x: 0, y: -2 }, { x: 0, y: -3 }],
    [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 2, y: 0 }, { x: 3, y: 0 }],
    [{ x: 0, y: 0 }, { x: 0, y: -1 }, { x: 1, y: 0 }, { x: 1, y: -1 }],
    [{ x: 0, y: 0 }, { x: 0, y: -1 }, { x: 0, y: -2 }, { x: 1, y: -2 }],
    [{ x: 0, y: -1 }, { x: 1, y: -1 }, { x: 2, y: -1 }, { x: 2, y: 0 }],
    [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 1, y: -1 }, { x: 1, y: -2 }],
    [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 2, y: 0 }, { x: 0, y: -1 }],
    [{ x: 1, y: 0 }, { x: 0, y: -1 }, { x: 1, y: -1 }, { x: 2, y: -1 }],
    [{ x: 0, y: -1 }, { x: 1, y: 0 }, { x: 1, y: -1 }, { x: 1, y: -2 }],
    [{ x: 0, y: 0 }, { x: 1, y: 0 }, { x: 2, y: 0 }, { x: 1, y: -1 }],
    [{ x: 0, y: 0 }, { x: 0, y: -1 }, { x: 0, y: -2 }, { x: 1, y: -1 }],
];
var gameStatu;
(function (gameStatu) {
    gameStatu[gameStatu["stand"] = 0] = "stand";
    gameStatu[gameStatu["play"] = 1] = "play";
    gameStatu[gameStatu["pause"] = 2] = "pause";
    gameStatu[gameStatu["end"] = 3] = "end";
})(gameStatu || (gameStatu = {}));
var RussiaBlock = /** @class */ (function (_super) {
    __extends(RussiaBlock, _super);
    function RussiaBlock() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.root = null;
        _this.block_item = null;
        _this.board = null;
        _this.sample = null;
        _this._statu = gameStatu.stand;
        _this._blockPool = []; // 方块pool
        _this._runningBlocks = []; // 下降中的方块
        _this._currBlocks = []; // 当前静止的方块
        _this._blockSameple = [];
        _this._sampleIndex = 0;
        return _this;
    }
    RussiaBlock.prototype.getBlockNode = function () {
        if (this._blockPool.length != 0) {
            return this._blockPool.pop();
        }
        var newBlock = cc.instantiate(this.block_item);
        //newBlock.parent = this.board;
        return newBlock;
    };
    RussiaBlock.prototype.pushToPool = function (block) {
        block.x = 0;
        block.y = 0;
        block.active = false;
        this._blockPool.push(block);
    };
    Object.defineProperty(RussiaBlock.prototype, "gameStatu", {
        get: function () {
            return this._statu;
        },
        set: function (value) {
            this._statu = value;
        },
        enumerable: true,
        configurable: true
    });
    RussiaBlock.prototype.nextblocks = function () {
        var _this = this;
        if (this._runningBlocks.length != 0 || this.gameStatu != gameStatu.play) {
            return;
        }
        var max = blockType.length;
        var index = Math.floor(Math.random() * max);
        index = index < max ? index : max - 1;
        var blocks = blockType[index];
        var preX = Math.floor(MapHelper_1.default.instance._width_count / 2);
        var preY = MapHelper_1.default.instance._height_count - 1;
        var gameOver = blocks.some(function (v, i, arr) {
            var over = false;
            over = !MapHelper_1.default.instance.isValid(v.x + preX, v.y + preY);
            return over;
        });
        if (gameOver) {
            Core_1.default.instance.toast("游戏结束!");
            this.russiaGameEnd();
            return;
        }
        blocks.forEach(function (v, i, arr) {
            var tmp = {};
            tmp.x = v.x + preX;
            tmp.y = v.y + preY;
            tmp.valid = false;
            tmp.node = _this.getBlockNode();
            _this._runningBlocks.push(tmp);
        });
        // node
        this._runningBlocks.forEach(function (v, i, arr) {
            v.node.parent = _this.board;
            v.valid = true;
            v.node.x = MapHelper_1.default.instance.getPosX(v.x);
            v.node.y = MapHelper_1.default.instance.getPosY(v.y);
            v.node.active = true;
            v.node.scale = 0.6;
        });
    };
    RussiaBlock.prototype.checkRunningBlock = function () {
        var _this = this;
        if (this._runningBlocks.length == 0 || this.gameStatu != gameStatu.play) {
            return;
        }
        var down = this._runningBlocks.every(function (v, i, arr) {
            var nextStep = !MapHelper_1.default.instance.isValid(v.x, v.y - 1);
            return nextStep;
        });
        if (down) {
            // 下降一格
            this._runningBlocks.forEach(function (v, i, arr) {
                v.y -= 1;
            });
        }
        else {
            // 停止
            this._runningBlocks.forEach(function (v, i, arr) {
                MapHelper_1.default.instance.validBlock(v.x, v.y, 0);
                _this._currBlocks.push(v);
            });
            this._runningBlocks = [];
            this.scheduleOnce(function () {
                _this.nextblocks();
            }, 0.3);
        }
        this.freshRunningBlockUI();
    };
    RussiaBlock.prototype.freshRunningBlockUI = function () {
        this._runningBlocks.forEach(function (v, i, arr) {
            if (v.node && v.valid) {
                v.node.x = MapHelper_1.default.instance.getPosX(v.x);
                v.node.y = MapHelper_1.default.instance.getPosY(v.y);
            }
        });
    };
    RussiaBlock.prototype.russiaGameStart = function () {
        var _this = this;
        this.gameStatu = gameStatu.play;
        this.nextblocks();
        this.schedule(function () {
            _this.checkRunningBlock();
        }, 0.35);
    };
    RussiaBlock.prototype.russiaGameEnd = function () {
        this.board.removeAllChildren(true);
        this._runningBlocks = [];
        this._blockPool = [];
        this._currBlocks = [];
        this.gameStatu = gameStatu.stand;
    };
    RussiaBlock.prototype.onInit = function (data) {
    };
    RussiaBlock.prototype.onload = function () {
        MapHelper_1.default.instance.initMapInfo(this.board.width, this.board.height, block_width, block_height);
    };
    RussiaBlock.prototype.start = function () {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyPressed, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyReleased, this);
    };
    RussiaBlock.prototype.update = function (dt) {
        // 
    };
    RussiaBlock.prototype.onDestroy = function () {
    };
    RussiaBlock.prototype.onClickClose = function () {
        GlobalEmit_1.default.instance.messageEmit.emit("CloseLayer", "RussiaBlock");
        this.close();
    };
    RussiaBlock.prototype.onClickStart = function () {
        this.russiaGameStart();
        //this.BlockSample();
    };
    RussiaBlock.prototype.onKeyPressed = function (event) {
        var keyCode = event.keyCode;
        if (this.gameStatu != gameStatu.play) {
            return;
        }
        switch (keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                break;
            case cc.macro.KEY.w:
            case cc.macro.KEY.up:
                break;
        }
    };
    RussiaBlock.prototype.onKeyReleased = function (event) {
        var keyCode = event.keyCode;
        if (this.gameStatu != gameStatu.play) {
            return;
        }
        switch (keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                break;
            case cc.macro.KEY.w:
            case cc.macro.KEY.up:
                break;
        }
    };
    RussiaBlock.prototype.BlockSample = function () {
        var _this = this;
        // data
        var blocks = blockType[this._sampleIndex];
        var cached = this._blockSameple.length == blocks.length;
        var preX = Math.floor(MapHelper_1.default.instance._width_count / 2);
        var preY = MapHelper_1.default.instance._height_count - 1;
        if (cached) {
            blocks.forEach(function (v, i, arr) {
                _this._blockSameple[i].x = v.x + preX;
                _this._blockSameple[i].y = v.y + preY;
                _this._blockSameple[i].valid = true;
            });
        }
        else {
            this._blockSameple = [];
            blocks.forEach(function (v, i, arr) {
                var tmp = {};
                tmp.x = v.x + preX;
                tmp.y = v.y + preY;
                tmp.valid = false;
                tmp.node = _this.getBlockNode();
                _this._blockSameple.push(tmp);
            });
        }
        // ui
        this._blockSameple.forEach(function (v, i, arr) {
            v.node.parent = _this.board;
            v.valid = true;
            v.node.x = MapHelper_1.default.instance.getPosX(v.x);
            v.node.y = MapHelper_1.default.instance.getPosY(v.y);
            v.node.active = true;
            v.node.scale = 0.5;
        });
        this._sampleIndex++;
        this._sampleIndex = this._sampleIndex >= blockType.length ? 0 : this._sampleIndex;
    };
    __decorate([
        property(cc.Node)
    ], RussiaBlock.prototype, "root", void 0);
    __decorate([
        property(cc.Node)
    ], RussiaBlock.prototype, "block_item", void 0);
    __decorate([
        property(cc.Node)
    ], RussiaBlock.prototype, "board", void 0);
    __decorate([
        property(cc.Node)
    ], RussiaBlock.prototype, "sample", void 0);
    RussiaBlock = __decorate([
        ccclass
    ], RussiaBlock);
    return RussiaBlock;
}(Dialog_1.default));
exports.default = RussiaBlock;

cc._RF.pop();