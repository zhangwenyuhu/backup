"use strict";
cc._RF.push(module, '1a0d99XD9FOYpdPKVRogUL7', 'xgame');
// Script/scenes/xgame.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Scene_1 = require("../core/Scene");
var Core_1 = require("../core/Core");
var utilTest_1 = require("../utils/utilTest");
var GlobalEmit_1 = require("../core/GlobalEmit");
var TableInit_1 = require("../config/cfg/TableInit");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var xgame = /** @class */ (function (_super) {
    __extends(xgame, _super);
    function xgame() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label = null;
        _this.baseKey = "";
        _this.centerKey = "";
        return _this;
    }
    xgame.prototype.onload = function () {
    };
    xgame.prototype.start = function () {
        // 界面ui框架初始化
        Core_1.default.instance.init();
        // 本地配置表初始化
        TableInit_1.initTable({});
        this.valideEvent(true);
        this.test();
    };
    xgame.prototype.update = function (dt) {
        // 
    };
    xgame.prototype.onDestroy = function () {
        Core_1.default.instance.off(Core_1.default.SHOW);
        Core_1.default.instance.off(Core_1.default.HIDE);
        this.valideEvent(false);
    };
    xgame.prototype.onClickBottom = function (sender) {
        if (sender) {
            var target = sender.currentTarget;
            if (target) {
                if (target.name === "btn_test") {
                    Core_1.default.instance.showLayer("prefabs/test");
                }
                else if (target.name === "btn_frappy") {
                    Core_1.default.instance.showLayer("prefabs/frappydragon");
                }
                else if (target.name === "btn_frappyunlimit") {
                    Core_1.default.instance.showLayer("prefabs/frappyunlimit");
                }
                else if (target.name === "btn_pinball") {
                    Core_1.default.instance.showLayer("prefabs/pinball");
                }
                else if (target.name === "btn_tank") {
                    Core_1.default.instance.showLayer("prefabs/tank");
                }
                else if (target.name === "btn_block") {
                    Core_1.default.instance.showLayer("prefabs/russiablock");
                }
            }
        }
    };
    xgame.prototype.valideEvent = function (valide) {
        if (valide) {
            GlobalEmit_1.default.instance.messageEmit.on("CloseLayer", function (e) {
                console.log("close layer~");
            });
        }
        else {
            GlobalEmit_1.default.instance.messageEmit.off("CloseLayer");
        }
    };
    // 
    xgame.prototype.test = function () {
        //this.testEncrypt()
        //utilTest.instance.testStorage()
        //this.testMath();
        //utilTest.instance.testCfg();
    };
    xgame.prototype.testEncrypt = function () {
        utilTest_1.default.instance.testEncryption();
    };
    xgame.prototype.testMath = function () {
        var outputJiaodu = function (value) {
            var outJd = 0;
            if (value) {
                outJd = (value * 180) / Math.PI;
            }
            console.log("偏移角度: " + outJd);
        };
        var value = Math.atan2(1, 0);
        outputJiaodu(value);
        value = Math.atan2(1, 1);
        outputJiaodu(value);
        value = Math.atan2(0, 1);
        outputJiaodu(value);
        value = Math.atan2(-1, 1);
        outputJiaodu(value);
        value = Math.atan2(-1, 0);
        outputJiaodu(value);
        value = Math.atan2(-1, -1);
        outputJiaodu(value);
        value = Math.atan2(0, -1);
        outputJiaodu(value);
        value = Math.atan2(1, -1);
        outputJiaodu(value);
    };
    __decorate([
        property(cc.Label)
    ], xgame.prototype, "label", void 0);
    xgame = __decorate([
        ccclass
    ], xgame);
    return xgame;
}(Scene_1.default));
exports.default = xgame;

cc._RF.pop();