"use strict";
cc._RF.push(module, '7e285r9A1BGtJBlkj9RKqub', 'frappycontrol');
// Script/layers/frappyunlimit/frappycontrol.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("../../core/Core");
var frappymanager_1 = require("./frappymanager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var frappycontrol = /** @class */ (function (_super) {
    __extends(frappycontrol, _super);
    function frappycontrol() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 是否向上
        _this.bUpTouch = false;
        // 横向移动控制变量
        _this.moveX = 0;
        // 纵向移动控制变量
        _this.moveY = 0;
        _this.upSpeed = 200;
        _this.downFrame = 8;
        return _this;
    }
    frappycontrol.prototype.onload = function () {
    };
    frappycontrol.prototype.start = function () {
        //add keyboard input listener to call turnLeft and turnRight
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyPressed, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyReleased, this);
        cc.director.getCollisionManager().enabled = true;
        //cc.director.getCollisionManager().enabledDebugDraw = true;
    };
    frappycontrol.prototype.isPlaying = function () {
        return (frappymanager_1.default.instance.gameStatu == frappymanager_1.Frappy_Statu.playing);
    };
    frappycontrol.prototype.resetFrappy = function () {
        this.node.x = 0;
        this.node.y = 0;
        this.bUpTouch = false;
        this.moveX = 0;
        this.moveY = 0;
    };
    frappycontrol.prototype.onKeyPressed = function (event) {
        var keyCode = event.keyCode;
        if (!this.isPlaying()) {
            return;
        }
        switch (keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                this.moveX = -200;
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                this.moveX = 200;
                break;
            case cc.macro.KEY.w:
            case cc.macro.KEY.up:
                this.bUpTouch = true;
                this.moveY = this.upSpeed;
                break;
        }
    };
    frappycontrol.prototype.onKeyReleased = function (event) {
        var keyCode = event.keyCode;
        if (!this.isPlaying()) {
            return;
        }
        switch (keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                this.moveX = 0;
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                this.moveX = 0;
                break;
            case cc.macro.KEY.w:
            case cc.macro.KEY.up:
                this.bUpTouch = false;
                break;
        }
    };
    frappycontrol.prototype.onCollisionEnter = function (other, self) {
        console.log("frappy collision enter");
        //this.node.color = cc.Color.RED;
        Core_1.default.instance.toast("Game Over~");
        frappymanager_1.default.instance.gameStatu = frappymanager_1.Frappy_Statu.over;
    };
    frappycontrol.prototype.onCollisionStay = function (other, self) {
    };
    frappycontrol.prototype.onCollisionExit = function (other) {
        console.log("frappy collision exit");
    };
    frappycontrol.prototype.update = function (dt) {
        if (!this.isPlaying()) {
            return;
        }
        //console.log("update: "+dt);
        if (this.moveX == 0) {
            // 纵向速度
            this.moveY = this.bUpTouch ? this.moveY : (this.moveY - this.downFrame);
            this.node.y += this.moveY * dt;
        }
        else {
            this.node.x += this.moveX * dt;
        }
    };
    frappycontrol.prototype.onDestroy = function () {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyPressed, this);
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyReleased, this);
        cc.director.getCollisionManager().enabled = false;
    };
    frappycontrol = __decorate([
        ccclass
    ], frappycontrol);
    return frappycontrol;
}(cc.Component));
exports.default = frappycontrol;

cc._RF.pop();