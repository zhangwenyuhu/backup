"use strict";
cc._RF.push(module, '64f1d1EiTNALJYErSUwsIo/', 'frappyunlimit');
// Script/layers/frappyunlimit/frappyunlimit.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Dialog_1 = require("../../core/Dialog");
var GlobalEmit_1 = require("../../core/GlobalEmit");
var block_1 = require("./block");
var frappymanager_1 = require("./frappymanager");
var frappycontrol_1 = require("./frappycontrol");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var frappyunlimit = /** @class */ (function (_super) {
    __extends(frappyunlimit, _super);
    function frappyunlimit() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.frappy = null;
        _this.board = null;
        _this.gameLayer = null;
        _this.blockArr = [];
        _this.blockPool = [];
        _this.uniqueTag = 0;
        _this.popBlockSpeed = 1;
        _this.lastBlockPos = cc.v2(700, -200);
        _this.blockLength = 300;
        _this.minDis = 100;
        return _this;
    }
    frappyunlimit.prototype.onInit = function (data) {
    };
    frappyunlimit.prototype.onload = function () {
    };
    frappyunlimit.prototype.start = function () {
    };
    frappyunlimit.prototype.update = function (dt) {
        // 
        this.gameControl();
    };
    frappyunlimit.prototype.onDestroy = function () {
        this.resetBlock();
    };
    frappyunlimit.prototype.onClickClose = function () {
        GlobalEmit_1.default.instance.messageEmit.emit("CloseLayer", "frappyunlimit");
        this.close();
    };
    frappyunlimit.prototype.onClickStart = function () {
        if (this.gameStatu == frappymanager_1.Frappy_Statu.stand) {
            this.gameStart();
        }
        else if (this.gameStatu == frappymanager_1.Frappy_Statu.playing) {
        }
        else if (this.gameStatu == frappymanager_1.Frappy_Statu.pause) {
        }
        else if (this.gameStatu == frappymanager_1.Frappy_Statu.over) {
            this.gameLayer.removeAllChildren();
            this.resetBlock();
            var f_script = this.frappy.getComponent(frappycontrol_1.default);
            if (f_script) {
                f_script.resetFrappy();
            }
            this.gameStart();
        }
    };
    Object.defineProperty(frappyunlimit.prototype, "gameStatu", {
        get: function () {
            return frappymanager_1.default.instance.gameStatu;
        },
        set: function (value) {
            frappymanager_1.default.instance.gameStatu = value;
        },
        enumerable: true,
        configurable: true
    });
    frappyunlimit.prototype.gameStart = function () {
        var _this = this;
        this.gameStatu = frappymanager_1.Frappy_Statu.playing;
        this.schedule(function () {
            _this.runBlock();
        }, this.popBlockSpeed);
    };
    frappyunlimit.prototype.gameControl = function () {
        if (this.gameStatu == frappymanager_1.Frappy_Statu.playing) {
            this.checkRunningBlock();
        }
    };
    frappyunlimit.prototype.gameOver = function () {
        this.gameStatu = frappymanager_1.Frappy_Statu.over;
        this.resetBlock();
    };
    frappyunlimit.prototype.runBlock = function () {
        if (this.gameStatu != frappymanager_1.Frappy_Statu.playing) {
            console.error("game over,no more block");
            return;
        }
        var tempBlock = this.getBlockRobot();
        this.gameLayer.addChild(tempBlock);
        var blockScript = tempBlock.getComponent(block_1.default);
        if (blockScript) {
            blockScript.tag = this.getUniqueTag();
            blockScript.bValide = true;
            blockScript.resetPos(this.getNewPos(false).x, this.getNewPos(false).y);
        }
        var l_rand = Math.random() * 10;
        if (l_rand % 2 == 1) {
            var t_block = this.getBlockRobot();
            this.gameLayer.addChild(t_block);
            var t_script = t_block.getComponent(block_1.default);
            if (t_script) {
                t_script.tag = this.getUniqueTag();
                t_script.bValide = true;
                t_script.resetPos(this.getNewPos(true).x, this.getNewPos(true).y);
            }
        }
    };
    frappyunlimit.prototype.resetBlock = function () {
        this.blockArr = [];
        this.blockPool = [];
    };
    frappyunlimit.prototype.getUniqueTag = function () {
        this.uniqueTag++;
        return this.uniqueTag;
    };
    frappyunlimit.prototype.getBlockRobot = function () {
        if (this.blockPool.length < 1) {
            var blockRobot = cc.instantiate(this.board);
            console.log("Frappy new block~");
            return blockRobot;
        }
        else {
            var block_2 = this.blockPool.pop();
            console.log("Frappy used block~");
            return block_2;
        }
    };
    frappyunlimit.prototype.getNewPos = function (bSameX) {
        var px = 0;
        var py = 0;
        var l_height = cc.winSize.height;
        if (bSameX) {
            px = this.lastBlockPos.x;
            if (this.lastBlockPos.y < 0) {
                var minY = this.lastBlockPos.y + this.minDis + this.blockLength;
                py = minY + Math.random() * 100;
            }
            else {
                var maxY = this.lastBlockPos.y - this.minDis - this.blockLength;
                py = maxY - Math.random() * 100;
            }
        }
        else {
            px = this.lastBlockPos.x + Math.random() * 50;
            py = Math.random() * l_height - l_height / 2;
        }
        this.lastBlockPos = cc.v2(px, py);
        return this.lastBlockPos;
    };
    frappyunlimit.prototype.checkRunningBlock = function () {
        for (var index = 0; index < this.blockArr.length; index++) {
            var blockNode = this.blockArr[index];
            var blockScript = blockNode.getComponent(block_1.default);
            if (blockScript) {
                if (!blockScript.bValide) {
                    this.blockPool.push(blockNode);
                    this.blockArr.splice(index, 1);
                    break;
                }
            }
        }
    };
    __decorate([
        property(cc.Node)
    ], frappyunlimit.prototype, "frappy", void 0);
    __decorate([
        property(cc.Node)
    ], frappyunlimit.prototype, "board", void 0);
    __decorate([
        property(cc.Node)
    ], frappyunlimit.prototype, "gameLayer", void 0);
    frappyunlimit = __decorate([
        ccclass
    ], frappyunlimit);
    return frappyunlimit;
}(Dialog_1.default));
exports.default = frappyunlimit;

cc._RF.pop();