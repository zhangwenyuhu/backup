"use strict";
cc._RF.push(module, 'f4f5fCmV7FKsKj+ZeCTUlUr', 'Scene');
// Script/core/Scene.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Scene = /** @class */ (function (_super) {
    __extends(Scene, _super);
    function Scene() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(Scene.prototype, "data", {
        get: function () {
            return this._data;
        },
        set: function (value) {
            this._data = value;
        },
        enumerable: true,
        configurable: true
    });
    // 适配屏幕
    Scene.prototype.adaptScreen = function () {
        var screenSize = cc.view.getFrameSize();
        console.log("屏幕大小 w: " + screenSize.width + " h: " + screenSize.height);
        cc.Canvas.instance.designResolution = cc.size(750, 1334);
        var mask = cc.find("mask");
        if (screenSize.width / screenSize.height > 750 / 1334) {
            cc.view.setResolutionPolicy(cc.ResolutionPolicy.FIXED_HEIGHT);
            cc.Canvas.instance.fitHeight = true;
            cc.Canvas.instance.fitWidth = false;
            console.log("屏幕适配 fixHeight");
            if (mask) {
                mask.active = true;
                mask.zIndex = 999;
            }
        }
        else {
            cc.view.setResolutionPolicy(cc.ResolutionPolicy.FIXED_WIDTH);
            cc.Canvas.instance.fitHeight = false;
            cc.Canvas.instance.fitWidth = true;
            console.log("屏幕适配 fixWidth");
            if (mask) {
                mask.active = false;
            }
        }
    };
    Scene.prototype._bindNode = function () {
        var _this = this;
        //绑定$开头的节点到_开头的同名属性上
        var searchFun = function (node) {
            if (node.name[0] === "$") {
                _this["_" + node.name.slice(1)] = node;
            }
            for (var i = 0; i < node.children.length; ++i) {
                searchFun(node.children[i]);
            }
        };
        searchFun(this.node.parent);
    };
    /**
     * 当界面加载完成后执行，界面数据由此传入
     * @param data
     */
    Scene.prototype.onInit = function (data) {
    };
    Scene.prototype.playClickEffect = function () {
    };
    Scene = __decorate([
        ccclass
    ], Scene);
    return Scene;
}(cc.Component));
exports.default = Scene;

cc._RF.pop();