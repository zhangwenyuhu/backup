"use strict";
cc._RF.push(module, '5db00n7IlhBJ7iWMPg71Q7g', 'logicChain');
// Script/utils/logicChain.ts

Object.defineProperty(exports, "__esModule", { value: true });
var logicResult = /** @class */ (function () {
    function logicResult() {
        this.success = true; //执行结果
        this.nextData = null; //向下传递的数据
        this.extra = undefined;
    }
    return logicResult;
}());
exports.logicResult = logicResult;
var logicChain = /** @class */ (function () {
    function logicChain() {
    }
    /**
     * 链接下一个逻辑
     * @param next
     */
    logicChain.prototype.link = function (next) {
        this._next = next;
        logicChain.total++;
        return next;
    };
    /**
     * 执行逻辑并返回结果
     */
    logicChain.prototype.execute = function (data) {
        return __awaiter(this, void 0, Promise, function () {
            var result;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.logic(data)];
                    case 1:
                        result = _a.sent();
                        if (!(result.success && this._next)) return [3 /*break*/, 3];
                        logicChain.current++;
                        return [4 /*yield*/, this._next.execute(result.nextData)];
                    case 2:
                        _a.sent();
                        _a.label = 3;
                    case 3: return [2 /*return*/, result];
                }
            });
        });
    };
    /**
     * 子类需要实现该函数
     */
    logicChain.prototype.logic = function (data) {
        return __awaiter(this, void 0, Promise, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve, reject) { resolve(new logicResult()); })];
            });
        });
    };
    logicChain.total = 0;
    logicChain.current = 0;
    return logicChain;
}());
exports.default = logicChain;

cc._RF.pop();