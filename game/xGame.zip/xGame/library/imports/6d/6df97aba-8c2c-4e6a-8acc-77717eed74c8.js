"use strict";
cc._RF.push(module, '6df97q6jCxOaorMd3F+7XTI', 'HttpGameClient');
// Script/utils/net/HttpGameClient.ts

Object.defineProperty(exports, "__esModule", { value: true });
var HttpClient_1 = require("./HttpClient");
var GameClient_1 = require("./GameClient");
var Core_1 = require("../../core/Core");
var Log_1 = require("../../core/Log");
var md5_1 = require("../crypt/md5");
var log = new Log_1.default({ tags: ["HttpClient"] });
var HttpGameClient = /** @class */ (function (_super) {
    __extends(HttpGameClient, _super);
    function HttpGameClient() {
        var _this = _super.call(this) || this;
        _this._client = new HttpClient_1.default();
        _this._requestIndex = 0;
        _this._retryCount = 3;
        /**
         * 获取token对外接口
         */
        _this.getToken = null;
        /**
         * 获取账号服返回的gametoken
         */
        _this.getGameToken = null;
        /**
         * 获取openId
         */
        _this.getOpenId = null;
        /**
         * 获取roleId对外接口
         */
        _this.getRoleId = null;
        /**
         * 获取appid
         */
        _this.getAppId = function () {
            throw new Error("未设置APPID");
        };
        return _this;
    }
    HttpGameClient.prototype.connect = function () {
        //http 不需要连接
    };
    HttpGameClient.prototype.request = function (action, data, callback, _a) {
        var _b = _a === void 0 ? {} : _a, version = _b.version, tag = _b.tag, name = _b.name, modal = _b.modal, downloadProgress = _b.downloadProgress, uploadProgress = _b.uploadProgress, errorCallback = _b.errorCallback, serverHost = _b.serverHost;
        this._requestIndex++; //每次请求拥有新的id
        var requestData = {
            appId: this.getAppId ? this.getAppId() : undefined,
            role: this.getRoleId ? this.getRoleId() : undefined,
            // token:this._token,//token
            index: this._requestIndex,
            retry: 0,
            v: version,
            t: tag,
            name: name,
            data: data
        };
        this.requestFromData(action, requestData, callback, { modal: modal, downloadProgress: downloadProgress, uploadProgress: uploadProgress, errorCallback: errorCallback, serverHost: serverHost });
    };
    HttpGameClient.prototype.requestFromData = function (action, requestData, callback, _a, isRetry, modalIndex) {
        var _this = this;
        var _b = _a === void 0 ? {} : _a, modal = _b.modal, downloadProgress = _b.downloadProgress, uploadProgress = _b.uploadProgress, errorCallback = _b.errorCallback, serverHost = _b.serverHost;
        if (isRetry === void 0) { isRetry = false; }
        if (modalIndex === void 0) { modalIndex = -1; }
        var sign = "";
        var now = Date.now();
        // if (this.roleId) {
        var makeSign = function (data) {
            var str = JSON.stringify(data) + (_this.token || "") + now;
            // console.log(`str:`, str);
            var sign = md5_1.Md5.hashStr(str);
            var ary = [];
            // console.log(`加密前:`, sign);
            sign.split("").forEach(function (c, i) {
                ary.push(String.fromCharCode((c.charCodeAt(0) + i % 4)));
            });
            return ary.join("");
        };
        if (!serverHost) {
            sign = makeSign(requestData);
        }
        // }
        var data = JSON.stringify(requestData);
        log.warn("request", action, data);
        var search = this.searchExt ? this.searchExt() : "";
        var url;
        if (this._protocol == "https" && this._port == 443) {
            url = this._protocol + "://" + (serverHost || this._host) + "/" + action + search;
        }
        else if (this._protocol == "http" && this._port == 80) {
            url = this._protocol + "://" + (serverHost || this._host) + "/" + action + search;
        }
        else {
            url = this._protocol + "://" + (serverHost || this._host) + ":" + this._port + "/" + action + search;
        }
        var index = modalIndex == -1 ? Core_1.default.instance.loadingIndex : modalIndex;
        //重试不重复打开模态
        if (!isRetry && modal && this._showLoadingModalCallback) {
            this._showLoadingModalCallback(index, action);
        }
        var headMap = {};
        headMap["Content-Type"] = "application/json;charset=utf-8";
        headMap["token"] = this._token || "";
        headMap["role"] = this._roleId;
        headMap["sign"] = sign;
        headMap["ts"] = now;
        headMap["appId"] = this.getAppId();
        this._client.request({
            method: "POST",
            url: url,
            data: data,
            headMap: headMap,
            onDone: function (data) {
                //进行回调
                if (typeof (data) == 'string' && data.length > 4000) {
                    //log.warn("response", action, data.substr(0, 4000))
                }
                else {
                    //log.warn("response", action, data);
                }
                var newData = JSON.parse(data);
                callback({
                    succeed: newData.ok, code: newData.c, message: newData.m, data: typeof newData.r == "string" ? JSON.parse(newData.r) : newData.r
                });
                if (modal && _this._closeLoadingModalCallback) {
                    _this._closeLoadingModalCallback(index, action);
                }
            },
            onError: function (error) {
                var retry = function () {
                    //重试函数
                    if (modal) {
                        _this._showLoadingModalCallback(index, action);
                    }
                    requestData.retry++;
                    _this.requestFromData(action, requestData, callback, { modal: modal, downloadProgress: downloadProgress, uploadProgress: uploadProgress, errorCallback: errorCallback, serverHost: serverHost }, true, index);
                };
                if (requestData.retry > _this._retryCount) {
                    //多次请求无果
                    if (errorCallback) {
                        errorCallback(error, retry); //当请求捕获错误时，则不进行全局错误回调
                    }
                    else if (_this._errorCallback) {
                        _this._errorCallback(error, retry);
                    }
                    if (modal && _this._closeLoadingModalCallback) {
                        _this._closeLoadingModalCallback(index, action);
                    }
                    //log.error("多次请求无果");
                }
                else {
                    requestData.retry++;
                    _this.requestFromData(action, requestData, callback, { modal: modal, downloadProgress: downloadProgress, uploadProgress: uploadProgress, errorCallback: errorCallback, serverHost: serverHost }, true, index);
                }
                //log.error(`OnError:`, error);
                if (requestData.retry > _this._retryCount && (error.indexOf('ssl hand shake error') != -1 || error.indexOf('证书无效') != -1)) {
                    if (_this._sslHandShakeErrorCallBack) {
                        _this._sslHandShakeErrorCallBack(index, action);
                    }
                }
            },
            onTimeout: function () {
                //超时进行重试
                var retry = function () {
                    //重试函数
                    if (modal) {
                        _this._showLoadingModalCallback(index, action);
                    }
                    requestData.retry++;
                    _this.requestFromData(action, requestData, callback, { modal: modal, downloadProgress: downloadProgress, uploadProgress: uploadProgress, errorCallback: errorCallback, serverHost: serverHost }, true, index);
                };
                if (requestData.retry > _this._retryCount) {
                    //多次请求无果
                    if (errorCallback) {
                        errorCallback("timeout", retry); //当请求捕获错误时，则不进行全局错误回调
                    }
                    else if (_this._errorCallback) {
                        _this._errorCallback("timeout", retry);
                    }
                    if (modal && _this._closeLoadingModalCallback) {
                        _this._closeLoadingModalCallback(index, action);
                    }
                    //log.error("多次请求无果");
                }
                else {
                    requestData.retry++;
                    _this.requestFromData(action, requestData, callback, { modal: modal, downloadProgress: downloadProgress, uploadProgress: uploadProgress, errorCallback: errorCallback, serverHost: serverHost }, true, index);
                }
            },
            onProgress: function (loaded, total) {
                if (downloadProgress) {
                    downloadProgress(loaded, total);
                }
            },
            onUploadProgress: function (loaded, total) {
                if (uploadProgress) {
                    uploadProgress(loaded, total);
                }
            }
        });
    };
    Object.defineProperty(HttpGameClient.prototype, "retryCount", {
        get: function () {
            return this._retryCount;
        },
        set: function (value) {
            this._retryCount = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(HttpGameClient.prototype, "client", {
        get: function () {
            return this._client;
        },
        enumerable: true,
        configurable: true
    });
    return HttpGameClient;
}(GameClient_1.default));
exports.default = HttpGameClient;

cc._RF.pop();