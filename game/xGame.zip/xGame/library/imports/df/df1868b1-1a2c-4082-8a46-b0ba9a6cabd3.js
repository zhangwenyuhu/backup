"use strict";
cc._RF.push(module, 'df186ixGixAgopGsLqabKvT', 'DataBase');
// Script/config/lib/DataBase.ts

Object.defineProperty(exports, "__esModule", { value: true });
var DataBase = /** @class */ (function () {
    function DataBase() {
    }
    return DataBase;
}());
exports.default = DataBase;

cc._RF.pop();