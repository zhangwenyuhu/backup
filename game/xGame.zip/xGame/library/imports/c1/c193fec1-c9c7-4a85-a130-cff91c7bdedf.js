"use strict";
cc._RF.push(module, 'c193f7BycdKhaEwz/kce97f', 'CV');
// Script/storage/base/CV.ts

// codecs version
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    cversion: 'B$'
};

cc._RF.pop();