"use strict";
cc._RF.push(module, '3e8ebO8QKVBjJqBpTY2eiR1', 'LoginData');
// Script/storage/data/LoginData.ts

Object.defineProperty(exports, "__esModule", { value: true });
var DataBase_1 = require("../base/DataBase");
var SafeData_1 = require("../base/SafeData");
var LoginData = /** @class */ (function (_super) {
    __extends(LoginData, _super);
    function LoginData() {
        var _this = _super.call(this) || this;
        _this.id = 0;
        _this.avatarUrl = null;
        _this.nickName = null;
        _this.isNew = false;
        _this.version = "1.0.0"; //游戏版本号
        _this.wxAccount = ""; //微信号
        _this.openWa = 0; //是否公开微信号
        return _this;
    }
    LoginData = __decorate([
        SafeData_1.SafeClass("LoginData")
    ], LoginData);
    return LoginData;
}(DataBase_1.default));
exports.default = LoginData;

cc._RF.pop();