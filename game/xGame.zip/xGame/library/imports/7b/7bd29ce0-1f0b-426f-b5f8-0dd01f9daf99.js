"use strict";
cc._RF.push(module, '7bd29zgHwtCb7X4DdAfna+Z', 'dataCheck');
// Script/login/dataCheck.ts

Object.defineProperty(exports, "__esModule", { value: true });
var logicChain_1 = require("../Utils/logicChain");
/**
 * 数据检查
 */
var dataCheck = /** @class */ (function (_super) {
    __extends(dataCheck, _super);
    function dataCheck() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    dataCheck.prototype.logic = function () {
        return __awaiter(this, void 0, Promise, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        var reuslt = new logicChain_1.logicResult;
                        //向下传递数据
                        reuslt.nextData = {
                            data: {}
                        };
                        resolve(reuslt);
                    })];
            });
        });
    };
    return dataCheck;
}(logicChain_1.default));
exports.default = dataCheck;

cc._RF.pop();