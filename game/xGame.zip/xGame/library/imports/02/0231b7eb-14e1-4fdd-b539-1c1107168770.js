"use strict";
cc._RF.push(module, '0231bfrFOFP3bU5HBEHFodw', 'Info');
// Script/Info.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * info
 */
var GameInfo = /** @class */ (function () {
    function GameInfo() {
        this.mode = "release";
        this.version = "1.0.1";
        this.resVersion = 25;
    }
    return GameInfo;
}());
var Info = GameInfo;
exports.default = new Info();

cc._RF.pop();