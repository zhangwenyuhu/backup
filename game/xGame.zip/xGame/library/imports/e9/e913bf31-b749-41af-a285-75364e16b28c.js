"use strict";
cc._RF.push(module, 'e913b8xt0lBr6KFdTZOFrKM', 'login');
// Script/login/login.ts

Object.defineProperty(exports, "__esModule", { value: true });
var logicChain_1 = require("../Utils/logicChain");
/**
 * 登陆
 */
var login = /** @class */ (function (_super) {
    __extends(login, _super);
    function login() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    login.prototype.logic = function (data) {
        return __awaiter(this, void 0, Promise, function () {
            var _this = this;
            return __generator(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        var reuslt = new logicChain_1.logicResult;
                        var loginLogic;
                        loginLogic = function () { return __awaiter(_this, void 0, void 0, function () {
                            var loginCallback;
                            return __generator(this, function (_a) {
                                loginCallback = function (data) {
                                    // 数据处理
                                    // 向下传递数据
                                    reuslt.nextData = {
                                        data: {
                                            data: data
                                        }
                                    };
                                    resolve(reuslt);
                                };
                                try {
                                    //await gssdk.login({});
                                    console.log("登录完成");
                                    loginCallback({});
                                }
                                catch (e) {
                                    console.error('登录异常:', e);
                                }
                                return [2 /*return*/];
                            });
                        }); };
                        setTimeout(function () {
                            loginLogic();
                        }, 3000);
                    })];
            });
        });
    };
    return login;
}(logicChain_1.default));
exports.default = login;

cc._RF.pop();