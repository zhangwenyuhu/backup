"use strict";
cc._RF.push(module, '5c263HQsMlDoZ2aWcm+SATM', 'frappymanager');
// Script/layers/frappyunlimit/frappymanager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Frappy_Statu;
(function (Frappy_Statu) {
    Frappy_Statu[Frappy_Statu["stand"] = 0] = "stand";
    Frappy_Statu[Frappy_Statu["playing"] = 1] = "playing";
    Frappy_Statu[Frappy_Statu["pause"] = 2] = "pause";
    Frappy_Statu[Frappy_Statu["over"] = 3] = "over";
})(Frappy_Statu = exports.Frappy_Statu || (exports.Frappy_Statu = {}));
var frappymanager = /** @class */ (function () {
    function frappymanager() {
        this._gameStatu = Frappy_Statu.stand;
    }
    frappymanager_1 = frappymanager;
    Object.defineProperty(frappymanager, "instance", {
        get: function () {
            if (!this._instance) {
                this._instance = new frappymanager_1();
            }
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(frappymanager.prototype, "gameStatu", {
        get: function () {
            return this._gameStatu;
        },
        set: function (value) {
            this._gameStatu = value;
        },
        enumerable: true,
        configurable: true
    });
    var frappymanager_1;
    frappymanager._instance = null;
    frappymanager = frappymanager_1 = __decorate([
        ccclass
    ], frappymanager);
    return frappymanager;
}());
exports.default = frappymanager;

cc._RF.pop();