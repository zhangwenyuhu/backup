"use strict";
cc._RF.push(module, 'ae5bfTtdeBE5Z1qwtvVU8Pi', 'wall');
// Script/layers/test/wall.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var WallType;
(function (WallType) {
    WallType[WallType["Left"] = 0] = "Left";
    WallType[WallType["Right"] = 1] = "Right";
    WallType[WallType["Top"] = 2] = "Top";
    WallType[WallType["Bottom"] = 3] = "Bottom";
})(WallType || (WallType = {}));
;
var Helloworld = /** @class */ (function (_super) {
    __extends(Helloworld, _super);
    function Helloworld() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.width = 6;
        _this.type = WallType.Left;
        return _this;
    }
    Helloworld.prototype.onload = function () {
    };
    Helloworld.prototype.start = function () {
        var collider = this.getComponent(cc.BoxCollider);
        if (!collider) {
            return;
        }
        var node = this.node;
        var type = this.type;
        var width = cc.winSize.width;
        var height = cc.winSize.height;
        var wallWidth = this.width;
        /*
        if (type === WallType.Left) {
            node.height = height;
            node.width = wallWidth;
            node.x = 0;
            node.y = height/2;
        }
        else if (type === WallType.Right) {
            node.height = height;
            node.width = wallWidth;
            node.x = width;
            node.y = height/2;
        }
        else if (type === WallType.Top) {
            node.width = width;
            node.height = wallWidth;
            node.x = width/2;
            node.y = height;
        }
        else if (type === WallType.Bottom) {
            node.width = width;
            node.height = wallWidth;
            node.x = width/2;
            node.y = 0;
        }
        */
        collider.size = node.getContentSize();
    };
    Helloworld.prototype.update = function (dt) {
        // 
    };
    Helloworld.prototype.onDestroy = function () {
    };
    __decorate([
        property
    ], Helloworld.prototype, "width", void 0);
    __decorate([
        property
    ], Helloworld.prototype, "type", void 0);
    Helloworld = __decorate([
        ccclass
    ], Helloworld);
    return Helloworld;
}(cc.Component));
exports.default = Helloworld;

cc._RF.pop();