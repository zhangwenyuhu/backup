"use strict";
cc._RF.push(module, '23be1AkV+NKa78NlmFfAKj+', 'bullet');
// Script/layers/tank/bullet.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var bullet = /** @class */ (function (_super) {
    __extends(bullet, _super);
    function bullet() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.lifeSec = 3;
        _this._speed = cc.v2(0, 0);
        _this.perSec = 0;
        _this.bValide = true;
        _this.tag = 0;
        _this.group = 0;
        return _this;
    }
    bullet.prototype.onload = function () {
    };
    bullet.prototype.start = function () {
        var collider = this.getComponent(cc.CircleCollider);
        if (!collider) {
            return;
        }
    };
    bullet.prototype.checkMove = function () {
        if (this.bValide) {
            this.node.x += this._speed.x;
            this.node.y += this._speed.y;
        }
    };
    bullet.prototype.checkLife = function (dt) {
        this.perSec += dt;
        //console.log("bullet dt: " + this.perSec);
        if (this.perSec >= 1) {
            this.lifeSec--;
            this.perSec = 0;
            console.log("bullet tag:" + this.tag + " valid:" + this.bValide + " lifeSec:" + this.lifeSec);
            if (this.lifeSec <= 0) {
                this.bValide = false;
                this.node.active = false;
            }
        }
    };
    bullet.prototype.update = function (dt) {
        if (this.tag == 0) {
            return;
        }
        //console.log("bullet tag:"+this.tag+" valid:"+this.bValide+" px:"+this.node.x+" py:"+this.node.y);
        //this.node.active = this.bValide;
        this.checkLife(dt);
        this.checkMove();
    };
    bullet.prototype.onDestroy = function () {
    };
    bullet.prototype.reSet = function () {
        this.bValide = true;
        this.node.active = true;
        this.lifeSec = 3;
    };
    Object.defineProperty(bullet.prototype, "speed", {
        get: function () {
            return this._speed;
        },
        set: function (value) {
            console.log("bullet spx:" + value.x + " spy:" + value.y + " tag:" + this.tag);
            this._speed = value;
        },
        enumerable: true,
        configurable: true
    });
    bullet.prototype.setPos = function (p) {
        this.node.x = p.x;
        this.node.y = p.y;
    };
    bullet.prototype.getNowPos = function () {
        return cc.v2(this.node.x, this.node.y);
        //return cc.v2(Math.floor(this.node.x), Math.floor(this.node.y));
    };
    bullet.prototype.onCollisionEnter = function (other, self) {
        console.log("bullet collision enter");
        this.bValide = false;
    };
    bullet.prototype.onCollisionStay = function (other, self) {
        console.log("bullet collision stay");
        this.bValide = false;
    };
    bullet.prototype.onCollisionExit = function (other) {
        console.log("bullet collision exit");
        this.bValide = false;
    };
    bullet = __decorate([
        ccclass
    ], bullet);
    return bullet;
}(cc.Component));
exports.default = bullet;

cc._RF.pop();