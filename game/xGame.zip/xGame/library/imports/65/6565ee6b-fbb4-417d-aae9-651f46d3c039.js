"use strict";
cc._RF.push(module, '6565e5r+7RBfarpZR9G08A5', 'LocalStorage');
// Script/storage/base/LocalStorage.ts

Object.defineProperty(exports, "__esModule", { value: true });
var xxtea_1 = require("../../utils/crypt/xxtea");
var Info_1 = require("../../Info");
var CV_1 = require("./CV");
var cversion = CV_1.default.cversion;
var LocalStorage = /** @class */ (function () {
    function LocalStorage() {
    }
    Object.defineProperty(LocalStorage, "encryptKey", {
        get: function () {
            return this._encryptKey;
        },
        set: function (v) {
            this._encryptKey = v;
        },
        enumerable: true,
        configurable: true
    });
    LocalStorage._setItem = function (key, value, encrypt, async) {
        if (encrypt === void 0) { encrypt = true; }
        if (async === void 0) { async = false; }
        if (encrypt) {
            value = xxtea_1.XXTEA.encryptToBase64Ex1(value, LocalStorage.defaultEncryptKey);
        }
        if (window["wx"]) {
            if (async) {
                wx.setStorage({ key: key, data: value, complete: function () { } });
            }
            else {
                return wx.setStorageSync(key, value);
            }
        }
        else {
            return cc.sys.localStorage.setItem(key, value);
        }
    };
    LocalStorage.setItem = function (key, value, encrypt, async) {
        if (encrypt === void 0) { encrypt = true; }
        if (async === void 0) { async = false; }
        LocalStorage._setItem('himini$z', cversion + Info_1.default.version, false, async);
        return LocalStorage._setItem(key, value, encrypt, async);
    };
    LocalStorage.getItem = function (key, encrypt) {
        if (encrypt === void 0) { encrypt = true; }
        var value;
        if (window["wx"]) {
            value = wx.getStorageSync(key);
        }
        else {
            value = cc.sys.localStorage.getItem(key);
        }
        if (encrypt) {
            var newValue = void 0;
            newValue = xxtea_1.XXTEA.decryptFromBase64Ex1(value, LocalStorage.defaultEncryptKey);
            return newValue;
        }
        return value;
    };
    LocalStorage.defaultEncryptKey = "^sdEF\n'r\r*@2\t!#~-+j;#$gnjl;csa`";
    LocalStorage._encryptKey = "^sdEF\n'r\r*@2\t!#~-+j;#$gnjl;csa`";
    return LocalStorage;
}());
exports.default = LocalStorage;

cc._RF.pop();