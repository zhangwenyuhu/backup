import ExcelManager from "./ExcelManager";
import JsonToLua from "./JsonToLua";
import * as path from "path"
import AutoPath, { AutoPathInfo } from "./quick_library/AutoPath";
import { XXTEA } from './xxtea';

type FiledType="any"|"uid"|"number"|"number[]"|"bool"|"bool[]"|"string"|"string*"|"object"|"object[]"|"fk"

class Field{
    name:string
    describe:string
    type:FiledType

    //外键
    fkTableName:string|undefined
    fkFieldName:string|undefined
    translate:boolean=false;
    constructor(name:string,describe:string,type:FiledType){
        this.name=name
        this.describe=describe
        this.type=type
    }
}


export default class Table{
    protected _path:string;
    protected _autoPathInfo:AutoPathInfo;//用于记录auto文件夹所标注的目标信息 版本 语言 平台
    protected _name:string;
    protected _fieldList:Field[]=[];
    protected _data:any[]=[];

    public encrypt_data:string=""
    public encrypt_key:string=""

    /**
     * 表格信息
     * @param excelpath 表格所在路径
     * @param data 表格数据
     */
    constructor(excelpath:string,data:any){
        this._path=excelpath;
        this._name=path.basename(excelpath,path.extname(excelpath));
        let info=AutoPath.instance.getAutoPathInfoFromFilepath(excelpath);
        if(info){
            this._autoPathInfo=info.info;
        }else{
            this._autoPathInfo=new AutoPathInfo();//默认信息
        }
        if(data.length<=3){
            return;
        }

        for(let i=0;i<data[1].length;i++){
            //第一行 注释
            //第二行 字段名
            //第三行 字段类型

            let des:string=String(data[0][i]).trim()
            let name:string=String(data[1][i]).trim()            
            let type:string=String(data[2][i]).trim()
            let fkTableName:string|undefined
            let fkFieldName:string|undefined
            let translate=false

            let typeList=["any","uid","number","number[]","bool","bool[]","string","object","object[]"]
            if(typeList.indexOf(type.toLowerCase())!=-1){
                //常规类型
            }else if(type.substr(0,2).toLowerCase()=="fk"){
                //外键
                let param=type.split(/\s+/)
                if(param.length<3){
                    console.error(`表 ${this._name} 外键 ${type} 配置错误`)
                    return;
                }

                fkTableName=param[1]
                fkFieldName=param[2]
                type="fk"
            }else if(type=="string*"){
                type="string"
                translate=true;
            }else{
                //不支持的类型
                type="any"
            }

            let field=new Field(name,des,type as any)
            field.fkTableName=fkTableName
            field.fkFieldName=fkFieldName
            field.translate=translate;

            this._fieldList.push(field)
        }

        //对每一行数据进行计算
        for(let i=3;i<data.length;i++){
            let line=[];
            let lineData=data[i];
            for(let l=0;l<lineData.length;l++){
                let data=lineData[l]
                let field=this._fieldList[l];
                if(field)
                    line.push(this.getNewData(field,data,i+1));
            }
            this._data.push(line)
        }

    }

    protected getNewData(field:Field,data:any,lineNumber:number):any{
        if(field.type=="any"){
            //any不做任何处理
            return data
        }else if(field.type=="uid"){
            let newValue= parseInt(data);
            if(isNaN(newValue)){
                newValue=0;
                console.error(`表${this._name} 行${lineNumber} 字段${field.name} uid类型值填写错误 ${data}`)
            }
            return newValue;
        }else if(field.type=="number"){
            if(data==undefined || data=="")
                data=0;
            let newValue= parseFloat(data);
            if(isNaN(newValue)){
                newValue=0;
                console.error(`表${this._name} 行${lineNumber} 字段${field.name} number类型值填写错误 ${data}`)                
            }
            return newValue;
        }else if(field.type=="number[]"){
            if(data==undefined || data=="" || data=="[]")
                data=null;

            if(typeof data=="number"){
                return [data];
            }else if(typeof data=="string"){
                data=data.replace(/\[|\]/g,"");
                let list=data.split(/,|;/)
                let result=[]
                for(let i=0;i<list.length;i++){
                    let v=parseFloat(list[i])
                    if(isNaN(v)){
                        v=0
                        console.error(`表${this._name} 行${lineNumber} 字段${field.name} number[]类型值填写错误 ${data}`)
                    }
                    result.push(v)
                }
                return result;
            }else{
                return [];
            }
        }else if(field.type=="bool"){
            if(data==undefined || data=="")
                data=false;

            if(typeof data =="boolean"){
                return data
            }else if(String(data).toLowerCase()=="false" || String(data)=="0"){
                return false;
            }else if(String(data).toLowerCase()=="true" || String(data)=="1"){
                return true;
            }else{
                return Boolean(data);
            }
        }else if(field.type=="bool[]"){
            if(data==undefined || data=="" || data=="[]")
                data=null;

            if(typeof data=="boolean"){
                return [data];
            }else if(typeof data=="string"){
                data=data.replace(/\[|\]/g,"");
                let list=data.split(/,|;/)
                let result=[]
                for(let i=0;i<list.length;i++){
                    let v=list[i]
                    if(v.toLowerCase()=="false" || v=="0"){
                        result.push(false);
                    }else if(v.toLowerCase()=="true" || v=="1"){
                        result.push(true);
                    }else{
                        result.push(Boolean(data))
                    }
                }
                return result;
            }else{
                return []
            }
        }else if(field.type=="string"){
            if(data==null){
                return ""
            }
            return String(data);
        }else if(field.type=="string*"){
            if(data==null){
                return ""
            }
            return String(data);
        }else if(field.type=="object"){
            try{
                let json=eval("(function(){return "+String(data)+"})()");
                return json;
            }catch(e){
                console.error(`表${this._name} 行${lineNumber} 字段${field.name} object类型值填写错误 ${data}`)
                return {}
            }
        }else if(field.type=="object[]"){
            try{
                let json=eval("(function(){return "+String(data)+"})()");
                if(json==null){
                    return []
                }
                if(json instanceof Array==false){
                    return [json]
                }
                return json;
            }catch(e){
                console.error(`表${this._name} 行${lineNumber} 字段${field.name} object[]类型值填写错误 ${data}`)
                return []
            }
        }else if(field.type=="fk"){
            if(isNaN(parseInt(data))){
                console.error(`表${this._name} 行${lineNumber} 字段${field.name} fk类型值填写错误 ${data}`)
            }
            return data
        }
    }

    get fileName(){
        return this._name
    }

    /** 
     * 检查表格格式是否错误
    */
    checkError(){
        //检查 uid 和 fk
        for(let i=0;i<this._fieldList.length;i++){
            let field=this._fieldList[i];
            if(field.type=="uid"){
                //唯一ID 检查
                let map=[]
                for(let j=0;j<this._data.length;j++){
                    let line=this._data[j]
                    let v=line[i];//找到相应的值
                    if(map[v]==true){
                        console.error(`表${this._name} 行${j+4} 字段${field.name} 出现重复值 ${v}`)
                    }
                    map[v]=true;
                }
            }else if(field.type=="fk"){
                //外键检查
                let fkTable=ExcelManager.instance.getTableByName(field.fkTableName as string,this._autoPathInfo);
                if(fkTable==null){
                    console.error(`${this._autoPathInfo.key} 表${this._name} 字段${field.name} 无法找到外键表 ${field.fkTableName}`)
                    continue;
                }
                let list=fkTable.getFieldValueList(field.fkFieldName as string)
                for(let j=0;j<this._data.length;j++){
                    let line=this._data[j]
                    let v=line[i];//找到相应的值

                    if(list.indexOf(v)==-1){
                        console.error(`表${this._name} 行${j+4} 字段${field.name} 无法找到外键值 ${v}`)                        
                    }
                }
            }
        }
    }

    /**
     * 获取指定字段的值列表
     * @param fieldName 字段名称 
     */
    getFieldValueList(fieldName:string):any[]{
        let result=[];
        for(let i=0;i<this._fieldList.length;i++){
            if(this._fieldList[i].name==fieldName){
                for(let j=0;j<this._data.length;j++){
                    let line=this._data[j]
                    result.push(line[i])
                }
                break;
            }
        }

        return result;
    }

    protected getJsonData():string{
        let result="[\n"
        for(let i=0;i<this._data.length;i++){
            let line=this._data[i]
            let value=JSON.stringify(line);
            if(i!=0)
                result+=",";
            result+=value+"\n"
        }
        result+="]"
        return result;
    }

    /**
     * 导出JS代码
     * @param temp 模板
     */
    exportJS(temp:string):string{
        let data=this.getJsonData();
        temp=temp.replace("{{DATA}}",data)

        //生成NOTE定义信息
        let note=""
        for(let i=0;i<this._fieldList.length;i++){
            let field=this._fieldList[i]
            let line=`${field.name} ${field.type} ${field.describe} \r`
            note+=line
        }
        temp=temp.replace("{{NOTE}}",note);

        //生成 Filed 变量
        let filed="["
        for(let i=0;i<this._fieldList.length;i++){
            let field=this._fieldList[i]
            let line=`"${field.name}",`
            filed+=line
        }
        filed+="]";
        temp=temp.replace("{{FILED}}",filed);
        
        return temp;
    }
    
    /**
     * 导出TS代码
     * @param temp 模板
     */
    exportTS(temp:string):string{
        let data=this.getJsonData();

        const lettersr = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
                            // +'_~!@#$%^&*()+`-={}:"|[];<>?,./'
                            +'_#%^&@*=+-'
        const letterst:string[]=lettersr.split('')
        // letterst=letterst.concat([
            // '\\\\',
            // '\\n','\\r','\\t',
        // ])
        let pswlen=Math.random()*128+64
        let pswt=[]
        for(let i=0;i<pswlen;i++){
            const c=letterst[Math.floor(Math.random()*letterst.length)]
            pswt.push(c)
        }
        let psw=pswt.join('').replace("'","\\'").replace('"','\\"')

        let className=`${this.fileName}Row`
        let encryptKey=psw

        let dataTable:any[][]=eval(data)
        let dataRecords=[]
        for(let row of dataTable){
            let rowRecords=[]
            for(let i in row){
                let col=row[i]
                let field=this._fieldList[i]
                let record=`"${field.name}":${JSON.stringify(col)}`
                rowRecords.push(record)
            }
            let rowRecordString=`\t{ ${rowRecords.join(',\t')}}`

            dataRecords.push(rowRecordString)
        }
        let dataRecordsString=`[\n${dataRecords.join(',\n')}\n]`
        let encryptDataRecordsString=XXTEA.encryptToBase64(dataRecordsString,"fmrarm"+encryptKey)
        let note=""
        temp=temp.replace("{{NOTE}}",note);
        temp=temp.replace(/{{CLASSNAME}}/g,className);
        temp=temp.replace(/{{FILENAME}}/g,this.fileName);
        temp=temp.replace(/{{ENCRYPT_KEY}}/g,encryptKey);

        let defaultValueMap:{[key:string]:any}={
            uid:0,
            string:"''",
            number:0,
            boolean:false,
            any:'{}',
        }
        // let defaultValueMap=(type)=>{
        //     if(type=='string'){
        //         return ''
        //     }
        // }
        //生成Type定义信息
        let filed='\n'
        for(let i=0;i<this._fieldList.length;i++){
            let field=this._fieldList[i]
            let type=field.type
            if(type=="object"){
                type="any";
            }
            let line=`\t${field.name}?:${type} = ${defaultValueMap[type]}\t//${field.describe}\n`
            filed+=line
        }
        temp=temp.replace("{{FILED}}",filed);

        temp=temp.replace("{{DATA}}",dataRecordsString)
        temp=temp.replace("{{ENCRYPT_DATA}}",encryptDataRecordsString)
        
        this.encrypt_key=encryptKey
        this.encrypt_data=encryptDataRecordsString

        return temp;
    }

    /**
     * 导出Lua代码
     * @param temp 模板
     */
    exportLua(temp:string):string{
        let data=this.getJsonData();
        let lua=JsonToLua.to(data);
        temp=temp.replace("{{DATA}}",lua)

        //生成Type定义信息
        let note=""
        for(let i=0;i<this._fieldList.length;i++){
            let field=this._fieldList[i]
            let line=`${field.name} ${field.type} ${field.describe} \r`
            note+=line
        }
        temp=temp.replace("{{NOTE}}",note);
        
        //生成 Filed 变量
        let filed="{"
        for(let i=0;i<this._fieldList.length;i++){
            let field=this._fieldList[i]
            let line=`"${field.name}",`
            filed+=line
        }
        filed+="}";
        temp=temp.replace("{{FILED}}",filed);

        return temp;
    }

    get path(){
        return this._path
    }

    get autoPathInfo(){
        return this._autoPathInfo;
    }

}