import * as fs from "fs"
import * as path from "path"
import * as xlsx from "node-xlsx"
import Table from "./Table";
import { AutoPathInfo } from "./quick_library/AutoPath";
export default class ExcelManager{

    public static instance=new ExcelManager();

    protected _autoPathMap:{[key:string]:Table[]}={};
    protected _autoPathList:Table[][]=[];
    protected _list:Table[]=[];

    constructor(){
    }

    async build(buildPath:string){
        
        let buildPromiseList:Promise<void>[]=[];

        let list=fs.readdirSync(buildPath);
        for(let i=0;i<list.length;i++){
            let p=list[i];
            //点开头的为隐藏文件
            if(path.basename(p)[0]=="." || path.basename(p)[0]=="~"){
                continue;
            }
            let state=fs.statSync(path.join(buildPath,p))
            if(state.isDirectory()){
                //继续向子目录查找
                buildPromiseList.push(this.build(path.join(buildPath,p)))
            }else if(path.extname(p)==".xlsx"){
                //找到xls文件
                buildPromiseList.push(this.buildExcel(path.join(buildPath,p)));
            }
        }

        for(let i=0;i<buildPromiseList.length;i++){
            await buildPromiseList[i];
        }
    }

    protected async buildExcel(excel:string){
        var promise=new Promise<void>((resolve, reject)=>{

            fs.readFile(excel,(err,buffer)=>{
                if(err){
                    console.error(err)
                    resolve();
                    return;
                }
                let parsed:any=xlsx.parse(buffer);
                let sheet1=parsed[0];
                if(sheet1){
                    let table=new Table(excel,sheet1.data);
                    this._list.push(table)    
                }

                resolve();
            });

        });
        return promise;
    }

    /**
     * 对所有文件进行分析，并分组。
     * 产生不同版本所包含的文件。
     */
    buildAutoPathMap(){
        //资源分类
        for(let i=0;i<this._list.length;i++){
            let table=this._list[i];
            let group=this._autoPathMap[table.autoPathInfo.key]
            if(group==null){
                group=this._autoPathMap[table.autoPathInfo.key]=[]
                this._autoPathList.push(group)
            }
            group.push(table);
        }
        //生成list排序
        this._autoPathList.sort((a,b):number=>{
            return a[0].autoPathInfo.order(b[0].autoPathInfo);
        })
    }

    getTableByName(name:string,info:AutoPathInfo):Table|null{
        //根据表格名 获取文件 逆向查找满足条件的列表
        for(let i=this._autoPathList.length-1;i>=0;i--){
            let list=this._autoPathList[i];
            let p=list[0].autoPathInfo;
            if(info.equal(p) || info.checkParent(p)){
                //上级目录，可能存在需要的表格
                for(let ii=0;ii<list.length;ii++){
                    if(list[ii].fileName==name){
                        return list[ii];
                    }
                }
            }
        }
        return null;
    }
    get tableList():Table[]{
        return this._list.concat();
    }
}