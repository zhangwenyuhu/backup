import * as yargs from "yargs"
import * as fs from "fs"
import * as path from "path"
import ExcelManager from "./ExcelManager";
import AutoPath from "./quick_library/AutoPath";

let jsDefaultTemp=`
/*{{NOTE}}*/
var f={{FILED}}
var _={{DATA}}
`

let tsDefaultTemp=`
/*{{NOTE}}*/

import { SafeClass } from '../framework/ConfigTool';
import ConfigTool from '../framework/ConfigTool';
import DataBase from '../framework/DataBase';

// predef types
type uid=number;

@SafeClass('{{CLASSNAME}}')
export class {{CLASSNAME}} extends DataBase{{{FILED}}}

/*
var {{FILENAME}}:{{CLASSNAME}}[]={{DATA}}
*/

let {{FILENAME}}:{{CLASSNAME}}[]=[]

export function {{FILENAME}}Init(
	key:string='{{ENCRYPT_KEY}}',
	data:string='{{ENCRYPT_DATA}}'
){
    let newTable=ConfigTool.decryptTable(
		()=>{
			return new {{CLASSNAME}}()
		},
		'fmrarm'+key,
		data
    )
    for(let r of newTable){
        {{FILENAME}}.push(r);
    }
}

export default {{FILENAME}}
`

let tsDefaultEmptyTemp=`
/*{{NOTE}}*/

import { SafeClass } from '../framework/ConfigTool';
import ConfigTool from '../framework/ConfigTool';
import DataBase from '../framework/DataBase';

// predef types
type uid=number;

@SafeClass('{{CLASSNAME}}')
export class {{CLASSNAME}} extends DataBase{{{FILED}}}

let {{FILENAME}}:{{CLASSNAME}}[]=[]

export function {{FILENAME}}Init(
	key:string='',
	data:string=''
){
    let newTable=ConfigTool.decryptTable(
		()=>{
			return new {{CLASSNAME}}()
		},
		'fmrarm'+key,
		data
    )
    for(let r of newTable){
        {{FILENAME}}.push(r);
    }
}

export default {{FILENAME}}
`

let tsDefaultInitTemp=`
{{IMPORTTABLE}}
let isInit=false
let list={{TABLEINITMAP}}
export function initTable(value:{[key:string]:{k:string,v:string}}){
    if(isInit){
        return;
    }
    isInit=true;
    for(let key in list){
        let init=list[key]
        let data=value[key]
        if(data){
            init(data.k,data.v)
        }else{
            init();
        }
    }
}
`

let luaDefaultTemp=`
--[[{{NOTE}}]]
local f={{FILED}}
local _={{DATA}}

return require "Table".new(f,_)
`

let argv=yargs.usage('Usage: $0 -s [path] -d [path]')//使用示例
            .alias('s', 'src')

            .alias('d', 'dist')

            .alias('c', 'checkonly')
            .default('c',false)

            .alias('t', 'type')
            .choices('t', ['js','ts','ets','lua'])

            .alias('p','temp')

            .alias('i','init')//初始化对象

            .alias('g','group')//组合表数据

            .demand(["src","type"])//必填参数

            .describe('s', 'excel文件源路径')
            .describe('d', '导出文件的目标路径')
            .describe('c', `是否仅仅检查文件正确性，而不进行导出。默认针对excel第二行的格式进行检查，参数如下：
uid 唯一id，如果该列有重复项，则会产生错误
number 数字
number[] 数字数组，使用;,进行数组分割
bool 可填写数字(1,0) 或 字符串(true,false)
bool[] 是否形数组，使用;,进行数组分割
string 字符串
object 可填写json格式的对象，应完全按照json格式填写对象
object[] 可填写json对象数组，应完全按照json对象格式进行数据填写

fk tableName fieldName 指向另一张表的ID

`)
            .describe('t', '导出的数据格式')
            .describe('p', `导出所使用的模板。如果不填，则使用默认模板。模板中使用{{DATA}}来替代数据，{{TYPE}}作为申明信息。
默认JS模板：
${jsDefaultTemp}
默认TS模板：
${tsDefaultTemp}
默认LUA模板：
${luaDefaultTemp}
`)

            .help('help')
            .argv;

// console.log(argv)

async function run(){
    //创建表格管理器
    console.log("加载表格")
    await ExcelManager.instance.build(argv.src);
    ExcelManager.instance.buildAutoPathMap();

    console.log("检查表格正确性")
    let list=ExcelManager.instance.tableList
    for(let i=0;i<list.length;i++){
        let table=list[i]
        table.checkError();
    }

    let temp:string="";
    if(argv.type=="js"){
        temp=jsDefaultTemp
    }else if(argv.type=="ts"){
        temp=tsDefaultTemp
    }else if(argv.type=="ets"){
        temp=tsDefaultEmptyTemp
    }else if(argv.type=="lua"){
        temp=luaDefaultTemp
    }
    //加载模板
    if(argv.temp){
        temp=fs.readFileSync(argv.temp,"utf-8")
    }
    console.log("开始导出，使用模板：",temp);

    //遍历导出
    let buildPromiseList:Promise<void>[]=[];
    if(! argv.checkonly && argv.dist)for(let i=0;i<list.length;i++){
        let table=list[i]
        let exportData:string;
        let extName:string;
        if(argv.type=="js"){
            extName=".js"
            exportData=table.exportJS(temp)
        }else if(argv.type=="ts" || argv.type=="ets"){
            extName=".ts"            
            exportData=table.exportTS(temp)
        }else if(argv.type=="lua"){
            extName=".lua"            
            exportData=table.exportLua(temp)
        }

        let promise=new Promise<void>((resolve, reject)=>{
            console.log("正在导出 ",table.fileName+extName);
            let exportPath= AutoPath.instance.convertPath(table.path,argv.dist);
            if(exportPath==null){
                console.log("导出失败 无法找到目标文件夹 ",table.autoPathInfo.key);
                resolve();
            }else{
                console.log(path.join(exportPath,"../",table.fileName+extName))
                fs.writeFile(path.join(exportPath,"../",table.fileName+extName),exportData,()=>{
                    resolve();
                });
            }
        })
        buildPromiseList.push(promise)
    }
    for(let i=0;i<buildPromiseList.length;i++){
        await buildPromiseList[i]
    }

    if(argv.init){
        //导出初始化类
        if(argv.type=="ts"||argv.type=="ets"){
            //生成模板
            let extName=".ts"
            let initTable=tsDefaultInitTemp

            let IMPORTTABLE=""
            let TABLEINITMAP="{"

            for(let i=0;i<list.length;i++){
                let t=list[i]
                IMPORTTABLE+=`import { ${t.fileName}Init } from "./${t.fileName}";\n`
                TABLEINITMAP+=`${t.fileName}:${t.fileName}Init,`;
            }
            TABLEINITMAP+="}";

            initTable=initTable.replace(/{{IMPORTTABLE}}/g,IMPORTTABLE)
            initTable=initTable.replace(/{{TABLEINITMAP}}/g,TABLEINITMAP)
            
            fs.writeFileSync(path.join(argv.dist,"TableInit"+extName),initTable);

        }
    }
    if(argv.group){
        if(argv.type=="ts"||argv.type=="ets"){
            //组合所有表数据
            let data:any={}

            for(let i=0;i<list.length;i++){
                let t=list[i]
                data[t.fileName]={k:t.encrypt_key,v:t.encrypt_data}
            }
            fs.writeFileSync(path.join(argv.dist,"table.json"),JSON.stringify(data));
        }
    }
}

run().then(function(){
    console.log("执行完毕")
})

