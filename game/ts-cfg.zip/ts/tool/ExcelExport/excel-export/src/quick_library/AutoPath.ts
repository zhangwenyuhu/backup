import * as fs from "fs"
import * as path from "path"

//默认key
const defaultkey:"default"="default";
//平台关键字
const platformList:string[]=["ios","android","winphone","html5"]

export type Platform="default"|"ios"|"android"|"winphone"|"html5"

export class AutoPathInfo{

    /**
     * 文件夹所标注的版本
     */
    version:number=0;
    
    /**
     * 文件夹所指向的平台
     */
    platform:Platform=defaultkey;

    /**
     * 语言版本 可以是任意字符（关键字除外）
     */
    language:string=defaultkey;

    /**
     * 比较两个目录含义是否相同
     * @param info 
     */
    equal(info:AutoPathInfo){
        return this.version==info.version && this.language==info.language && this.platform==info.platform;
    }

    /**
     * 获取字符串key
     */
    get key():string{
        return `${this.version}_${this.language}_${this.platform}`
    }

    /**
     * 对元素进行排序 按照后面覆盖前面的准则进行排序
     * 平台和语言 只与 default 存在排序关系
     * 版本则由数字进行排序
     * 
     * 平台->ios,default    先平台 再 default
     * 语言->xxx,default    先语言 再 default
     * 版本->0,1,2,3,4 从小到大
     * 
     * 例如 default ios_v1 v1 v2 进行目标为iosv2的资源排序 应排序为 default v1 ios_v1 v2
     * 如果平台、语言完全相同，则比较版本优先
     * 如果平台、语言不同，但是其中一个值是default 则 依然比较版本优先
     * 如果此时，版本也相同，则比按值 与 default 进行排序 为 default 值。如果 default->ios
     * 否则没可比性，返回0
     * @param info 对比者
     */
    order(info:AutoPathInfo):number{
        if(this.platform==info.platform && this.language==info.language){
            //平台 语言完全相同
            return this.version-info.version //从小到大
        }else if(this.platform==info.platform &&this.language!=info.language 
            && (this.language=="default"||info.language=="default")||
            this.language==info.language &&this.platform!=info.platform 
            && (this.platform=="default"||info.platform=="default")
        ){
            //有一个值是default
            if(this.version==info.version){
                //版本也相同 default 排在前面
                if(this.platform==info.platform){
                    if(this.language=="default"){
                        return -1;
                    }else return 1;
                }else{
                    if(this.platform=="default"){
                        return -1;
                    }else return 1;
                }
            }else{
                return this.version-info.version //从小到大
            }
        }else{
            //排序无意义
            return 0;
        }
    }

    /**
     * 检查parent 是否是自身的上级目录
     * 例如 v2 的上级目录 可以是 v1 v0
     * ios的上级目录是 default
     * en的上级目录是default 
     */
    checkParent(parent:AutoPathInfo):boolean{
        if(this.equal(parent)){
            //完全相同肯定不是parent
            return false;
        }
        if(this.platform!=parent.platform &&parent.platform!="default"){
            return false;
        }
        if(this.language!=parent.language && parent.language!="default"){
            return false;
        }
        if(this.version==parent.version){
            if(parent.platform=="default"||parent.language=="default"){
                return true;
            }else{
                return false;
            }
        }else{
            return this.version>parent.version
        }
    }
}

export default class AutoPath{

    static readonly instance:AutoPath=new AutoPath();

    constructor(){

    }
    
    /**
     * 获取特殊文件夹的信息
     */
    getAutoPathInfo(name:string):AutoPathInfo{
        let info:AutoPathInfo=new AutoPathInfo()
        let nameList=name.toLocaleLowerCase().replace(/\s/g,"").split(/_+/);
        for(let i=0;i<nameList.length;i++){
            let key=nameList[i]
            if(key==""){
                continue;
            }
            if(key[0]=="v" && key.charCodeAt(1)>="0".charCodeAt(0) && key.charCodeAt(1)<="9".charCodeAt(0)){
                //发现版本号
                info.version=parseInt(key.substr(1));
            }else if(platformList.indexOf(key)!=-1){
                //发现平台信息
                info.platform=key as Platform
            }else{
                //语言版本
                info.language=key
            }
        }
        return info;
    }

    /**
     * 获取文件的自动路径名称
     */
    getAutoPathInfoFromFilepath(filepath:string):{info:AutoPathInfo,key:string}|null{
        //向上查找 __开头的文件夹 并分析其文件夹信息
        let pathlist=filepath.split(/\/|\\/);
        for(let i=pathlist.length-1;i>=0;i--){
            let p=pathlist[i];
            if(p.substr(0,2)=="__"){
                //发现特殊目录 分析目录信息 并返回
                let info=this.getAutoPathInfo(p);
                return {info:info,key:p};
            }
        }
        return null;
    }

    /**
     * 转换 带有 ${auto} 的路径至目标目录 结果目录包含文件名
     * 如果无法找到目标目录，则返回null
     * @param sourcefile 原文件路径 /sourcepath/__v0_en/xx/xx.txt
     * @param targetpath 目标文件路径 /targetpath/${auto}/xx/xx，如果目标文件夹无${auto}则不进行处理直接返回
     * @return /targetpath/__v0_en/xx/xx/xx/xx.txt
     */
    convertPath(sourcefile:string,targetpath:string):string|null{

        if(targetpath.indexOf("${auto}")==-1){
            return path.join(targetpath,path.basename(sourcefile));//非自动化处理目录
        }

        let p=targetpath.split("${auto}")
        let left=p[0]
        let right=p[1] || ""

        //分析文件路径中的__开始的特殊目录
        let sourceinfo=this.getAutoPathInfoFromFilepath(sourcefile);
        if(sourceinfo==null){
            //如果无特殊目录 则设置为默认info
            sourceinfo={info:new AutoPathInfo(),key:""}
        }

        //找到目标下对应的目录
        let files=fs.readdirSync(left);
        for(let i=0;i<files.length;i++){
            let name=files[i]
            if(name.substr(0,2)=="__"){
                //发现特殊文件夹
                let info=this.getAutoPathInfo(name)
                if(info.equal(sourceinfo.info)){
                    //发现相同含义目录 找到目标
                    //生成新的目录，left+name+right
                    let sourcesubpath=""
                    if(sourceinfo.key!=""){
                        sourcesubpath=sourcefile.substr(sourcefile.lastIndexOf(sourceinfo.key)+sourceinfo.key.length+1)
                    }else{
                        sourcesubpath=path.basename(sourcefile);
                    }
                    return path.join(left,name,right,sourcesubpath)
                }
            }else{
                //非特殊文件夹 忽略
                if(name[0]!=".")
                    console.log("忽略",name);
            }
        }

        return null;
    }
}