declare module 'node-xlsx' {
    interface XLSX {
        build(worksheets:any, options?:any):void;
        parse(mixed:any, options?:any):void;
    }
    var xlsx:XLSX;
    export =xlsx;
}