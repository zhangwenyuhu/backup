export default class JsonToLua{

    static isFirtNumber(str:string):boolean{
        let code=str.charCodeAt(0);
        return code>="0".charCodeAt(0) && code<="9".charCodeAt(0);
    }

    //规则：1、中括号转大括号 2、冒号转等号 3、引号结束后面如果是冒号,则应该是key，去除引号
    static to(json:string):string{
        let result="";

        let isStr:boolean=false;
        let strType:string="";
        let str:string="";
        for(let i=0;i<json.length;i++){
            let char=json[i];
            if(isStr){
                //当前正在字符串中
                if(char==strType){//找到结束符
                    if(str.length>0 && str[str.length-1]=="\\"){
                        //这不是真的结束符 是转义
                        str+=char;
                    }else{
                        //字符串结束
                        isStr=false;
                        if(json[i+1]==":"){
                            //后面是冒号 则说明是key 需要去除引号
                            if(str.indexOf('.')!=-1 || this.isFirtNumber(str)){
                                //包含异常字符 或是纯数字
                                result+="['"+str+"']";
                            }else{
                                result+=str;
                            }
                        }else{
                            result+='"'+str+'"';
                        }
                    }
                }else{
                    str+=char;
                }
            }else{
                if(char=="["){
                    result+="{"
                }else if(char=="]"){
                    result+="}"
                }else if(char==":"){
                    result+="="
                }else if(char=="\""){
                    isStr=true;
                    strType="\""
                    str="";
                }else if(char==","){
                    //检查前面是否有null，如果有则替换成nil
                    if(result.substr(result.length-4,4)=="null"){
                        result=result.replace(/null$/,"nil");
                    }
                    result+=",";
                }else{
                    result+=char;
                }
            }
        }

        return result;
    }
}