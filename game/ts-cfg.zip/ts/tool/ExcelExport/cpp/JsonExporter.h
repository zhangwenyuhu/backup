#ifndef JSONEXPORTER_H
#define JSONEXPORTER_H

#include "ExcelExporter.h"

class JsonExporter:public IExporter
{
public:
    JsonExporter();

    virtual void start();
    virtual void end();
    virtual void startObject();
    virtual void endObject();
    virtual void setData(const QString& key,const QString& value);
    virtual QString getResult();
    virtual void clear();

};

#endif // JSONEXPORTER_H
