#include "JsonExporter.h"

JsonExporter::JsonExporter()
{

}


void JsonExporter::start(){

}

void JsonExporter::end(){

}

void JsonExporter::startObject(){

}

void JsonExporter::endObject(){

}

void JsonExporter::setData(const QString& key,const QString& value){

}

QString JsonExporter::getResult(){

}

void JsonExporter::clear(){

}
