#include "ExcelExporter.h"

ExcelExporter::ExcelExporter()
{

}

ExcelExporter::~ExcelExporter()
{
    for(auto doc:_excels){
        delete doc;
    }
}

TableColumnType ExcelExporter::getTableColumnType(const QString& type){
    QMap<QString,TableColumnType> typeMap;
    typeMap["id"]=TableColumnType::ID;
    typeMap["fid"]=TableColumnType::FID;
    typeMap["string"]=TableColumnType::STRING;
    typeMap["int"]=TableColumnType::INT;
    typeMap["number"]=TableColumnType::NUMBER;
    typeMap["bool"]=TableColumnType::BOOL;

    typeMap["fid[]"]=TableColumnType::FID_ARRAY;
    typeMap["string[]"]=TableColumnType::STRING_ARRAY;
    typeMap["int[]"]=TableColumnType::INT_ARRAY;
    typeMap["number[]"]=TableColumnType::NUMBER_ARRAY;
    typeMap["bool[]"]=TableColumnType::BOOL_ARRAY;

    if(typeMap.find(type)==typeMap.end()){
        return TableColumnType::NONE;
    }

    return typeMap[type];

}

void ExcelExporter::addFile(QFileInfo file)
{
    QXlsx::Document* doc=new QXlsx::Document(file.absoluteFilePath());
    _excels.push_back(doc);
    _excelNameMap[file.baseName()]=doc;
    _nameToPathMap[file.baseName()]=file;

    //acrroding to the first 2 rows,get table structure
    QMap<QString,TableColumnType> columMap;

    for (int column = doc.dimension().firstRow(); column < doc.dimension().columnCount(); column++) {
        QXlsx::Cell *name = doc.cellAt(0, column);
        QXlsx::Cell *type = doc.cellAt(1, column);

        if(name==nullptr){
            printf("error format,file %s row %d colume %d",file.baseName().toStdString().c_str(),0,column);
            continue;
        }
        if(type==nullptr){
            printf("error format,file %s row %d colume %d",file.baseName().toStdString().c_str(),1,column);
            continue;
        }

        auto t=this->getTableColumnType(type->value().toString());
        if(t==TableColumnType::NONE){
            printf("type undefine,type %s file %s row %d colume %d",
                   type->value().toString(),
                   file.baseName().toStdString().c_str(),
                   1,column);
            continue;
        }

        columMap[name->value().toString()]=t;
    }

    _columnTypeMap[file.baseName()]=columMap;
}

QString ExcelExporter::checkFormat()
{
    for(auto i=_excelNameMap.begin();i!=_excelNameMap.end();i++){
        auto info=_columnTypeMap[i.key().baseName()];
        auto& doc=i.value();

        QMap<int,int> idMap;

        //skip the first 2 rows
        for (int row = 2; row < doc.dimension().rowCount(); row++) {
            for (int column = doc.dimension().firstRow(); column < doc.dimension().columnCount(); column++) {
                QXlsx::Cell* cname=doc.cellAt(0, column);
                auto ctype= info[cname->value().toString()];

                auto value=((QXlsx::Cell*)doc.cellAt(row, column))->value();
                switch (ctype) {
                case TableColumnType::ID:
                    if(value.type()~=QVariant::Type::Int){
                        printf("data type error,file %s row %d colume %d",i.key().baseName().toStdString().c_str(),row,column);
                        continue;
                    }
                    int id=value.toInt();
                    if(idMap.find(id)~=idMap.end()){
                        printf("id repeat error,file %s row %d colume %d",i.key().baseName().toStdString().c_str(),row,column);
                        continue;
                    }
                    idMap[id]=id;

                    break;
                case TableColumnType::FID:
                    if(value.type()~=QVariant::Type::Int){
                        printf("data type error,file %s row %d colume %d",i.key().baseName().toStdString().c_str(),row,column);
                        continue;
                    }
                    int id=value.toInt();
                    auto name=cname->value().toString();
                    auto ftableName=name.left(name.length()-2);

                    if(this->_excelNameMap.find(ftableName)==_excelNameMap.end()){
                        printf("table is not exist,fid %s file %s row %d colume %d",ftableName.toStdString().c_str(),i.key().baseName().toStdString().c_str(),row,column);
                        continue;
                    }

                    bool isfind=false;
                    auto fdoc=this->_excelNameMap[ftableName];
                    for (int row = 2; row < fdoc.dimension().rowCount(); row++) {
                        QXlsx::Cell* fvalue=doc.cellAt(row, 0);
                        if(fvalue->value().type()==QVariant::Type::Int){
                            if(fvalue->value().toInt()==id){
                                isfind=true;
                                break;
                            }
                        }
                    }
                    if(!isfind)
                        printf("fid is not exist,fid %s file %s row %d colume %d",ftableName.toStdString().c_str(),i.key().baseName().toStdString().c_str(),row,column);

                    break;
                case TableColumnType::STRING:

                    break;
                case TableColumnType::INT:

                    break;
                case TableColumnType::NUMBER:

                    break;
                case TableColumnType::BOOL:

                    break;
                case TableColumnType::FID_ARRAY:

                    break;
                case TableColumnType::STRING_ARRAY:

                    break;
                case TableColumnType::INT_ARRAY:

                    break;
                case TableColumnType::NUMBER_ARRAY:

                    break;
                case TableColumnType::BOOL_ARRAY:

                    break;
                default:
                    break;
                }
            }
        }
    }
}

QString ExcelExporter::run(const IExporter& exporter,const QDir& destination)
{

}

