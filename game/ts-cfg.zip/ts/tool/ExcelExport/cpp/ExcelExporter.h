#ifndef EXCELEXPORTER_H
#define EXCELEXPORTER_H

#include <QTextStream>
#include <stdio.h>

#include "xlsx/xlsxdocument.h"

#include <QFile>
#include <QFileInfo>
#include <QDir>
#include <QDirIterator>
#include <QVariant>
#include <QMap>

class IExporter{
public:
    virtual void start()=0;
    virtual void end()=0;
    virtual void startObject()=0;
    virtual void endObject()=0;
    virtual void setData(const QString& key,const QString& value)=0;
    virtual QString getResult()=0;
    virtual void clear()=0;
};

enum TableColumnType{
    NONE,

    ID,
    FID,
    STRING,
    INT,
    NUMBER,
    BOOL,

    FID_ARRAY,
    STRING_ARRAY,
    INT_ARRAY,
    NUMBER_ARRAY,
    BOOL_ARRAY

};

class ExcelExporter
{
private:
    QList<QXlsx::Document*> _excels;
    QMap<QString,QXlsx::Document*> _excelNameMap;
    QMap<QString,QFileInfo> _nameToPathMap;
    QMap<QString,QMap<QString,TableColumnType>> _columnTypeMap;

    TableColumnType getTableColumnType(const QString& type);

public:
    ExcelExporter();
    ~ExcelExporter();

    void addFile(QFileInfo file);
    QString checkFormat();
    QString run(const IExporter& exporter,const QDir& destination);
};

#endif // EXCELEXPORTER_H
