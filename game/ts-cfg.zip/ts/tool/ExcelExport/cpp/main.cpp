#include <QCoreApplication>
#include <QCommandLineParser>

#include <QTextStream>
#include <stdio.h>

#include <QFile>
#include <QFileInfo>
#include <QDir>
#include <QDirIterator>
#include <QVariant>
#include <QMap>

#include "xlsx/xlsxdocument.h"

#include "ExcelExporter.h"
#include "JsonExporter.h"

QTextStream cin(stdin,  QIODevice::ReadOnly);
QTextStream cout(stdout,  QIODevice::WriteOnly);
QTextStream cerr(stderr,  QIODevice::WriteOnly);



inline QList<QFileInfo> getExcelFileList(QFileInfo& fileInfo){
    QList<QFileInfo> result;
    if(fileInfo.isFile() &&fileInfo.suffix()=="xlsx"){
        result.push_back(fileInfo.absolutePath());
    }else if(fileInfo.isDir()){
        QDir dir(fileInfo.absolutePath());
        QDirIterator iter(dir,QDirIterator::Subdirectories);

        while (iter.hasNext())
        {
            iter.next();
            QFileInfo info=iter.fileInfo();
            if (info.isFile()&&info.suffix()=="xlsx")
            {
                result.push_back(info);
            }
        }
    }
    return result;
}


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    a.setOrganizationName("JasonWu");
    a.setApplicationName("Excel Export");
    a.setApplicationVersion("1.0.0.0");

    QCommandLineParser parser;

    parser.addHelpOption();
    parser.addVersionOption();

    parser.addOption(QCommandLineOption(QStringList() << "s" << "source", "Set the source path of Excel file.","source"));
    parser.addOption(QCommandLineOption(QStringList() << "d" << "destination", "Set the destination path of result file.","destination"));
    parser.addOption(QCommandLineOption(QStringList() << "t" << "type", "Set the result file type(xml,json),default json.","type","json"));

    if(argc==0 || !parser.parse(a.arguments())){
        cerr<<"Parameters error.\n";
        cout<<parser.helpText();
        return 0;
    }

    if(parser.isSet("help")){
        cout<<parser.helpText();
        return 0;
    }

    if(parser.isSet("version")){
        cout<<a.applicationName()<<" "<<a.applicationVersion()<<" by "<<a.organizationName()<<"\n";
        return 0;
    }

    if(!parser.isSet("source")){
        cerr<<"Parameter source is not exist.\n";
        cout<<parser.helpText();
        return 0;
    }

    //loading excel files
    ExcelExporter exporter;

    auto source=parser.value("source");
    auto type=parser.value("type");

    QFileInfo sourceInfo(source);
    if(! sourceInfo.exists()){
        cerr<<source<<" is not exist.\n";
        return 0;
    }

    auto excelList=getExcelFileList(sourceInfo);
    for(auto& file:excelList){
        cout<<"loading "<<file.fileName()<<"\n";
        try{
            exporter.addFile(file);
        }catch(QString exception){
            cerr<<exception<<"\n";
        }
    }

    //check file format
    cout<<exporter.checkFormat()<<"\n";


    //export file
    if(parser.isSet("destination")){
        QString destination= parser.value("destination");
        if(type=="json"){
            exporter.run(JsonExporter(),destination);
        }else if(type=="xml"){

        }
    }


    return 0;
}
