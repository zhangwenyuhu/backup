
export class Sound{

    /**
     * 文件url
     */
    protected _url:string

    /**
     * 是否循环播放
     */
    protected _loop:boolean

    /**
     * 音量
     */
    protected _volume:number

    /**
     * 当前音效的id
     */
    protected _id:number=-1

    /**
     * 音频对象
     */
    protected _clip:cc.AudioClip


    /**
     * 当前音频的状态
     */
    protected _state:"play"|"stop"|"pause"="stop"

    /**
     * 当音频播放完成触发
     */
    onFinish:()=>void=null;

    /**
     * 音效播放类
     * @param url 播放的音频地址，一旦创建不可修改
     * @param loop 是否循环播放
     * @param volume 音量
     */
    constructor(url:string,loop:boolean=false,volume:number=1.0){
        this._url=url
        this._loop=loop
        this._volume=volume

        cc.loader.loadRes(url,cc.AudioClip,(err:Error,audio:cc.AudioClip)=>{
            if (err){
                console.error("load audio failed="+url)
                console.error(err)
                return
            }
            this._clip=audio;

            if(this._state=="stop"){//已经是停止状态，没必要播放
                return;
            }

            this._id=cc.audioEngine.play(this._clip,this._loop,this._volume);
            if(this._state=="pause"){
                //立即暂停
                this.pause();
            }

            cc.audioEngine.setFinishCallback(this._id,()=>{
                if(this.onFinish)this.onFinish()
            });
            
        })

    }

    /**
     * 暂停本音效
     */
    pause(){
        if(this._state=="pause"){
            return;
        }
        this._state="pause"
        if(this._id==-1){
            return;
        }
        cc.audioEngine.pause(this._id);
    }
    /**
     * 继续本音效
     */
    resume(){
        if(this._state!="pause"){
            return;
        }
        this._state="play"
        if(this._id==-1){
            return;
        }
        cc.audioEngine.resume(this._id);
    }
    /**
     * 停止本音效
     */
    stop(){
        if(this._state=="stop"){
            return;
        }
        if(this._id==-1){
            return;
        }
        cc.audioEngine.stop(this._id);
        this._state="stop";
        this._id=-1;
    }

    /**
     * 重新播放本音效
     */
    play(){
        if(this._state!="stop"){
            return;
        }
        this._state="play";
        if(this._clip){
            this._id=cc.audioEngine.play(this._clip,this._loop,this._volume);
            cc.audioEngine.setFinishCallback(this._id,()=>{
                if(this.onFinish)this.onFinish()
            });
        }
    }

    get id(){
        return this._id
    }

    get clip(){
        return this._clip
    }

    get state(){
        return this._state
    }

    set volume(v){
        if(v!=this.volume){
            return;
        }
        this._volume=v;

        if(this._id!=-1){
            cc.audioEngine.setVolume(this._id,v);
        }
    }

    get volume(){
        return this._volume
    }

    get loop(){
        return this._loop
    }

    get url(){
        return this._url
    }
}

export default class MusicHelper {
    /**
     * 
     * @param url 
     * @param loop 
     * @param volume 
     * @returns 声音控制对象
     */
    public static play(url:string,loop:boolean=false,volume:number=1.0):Sound{
        let sound=new Sound(url,loop,volume)
        sound.play();//立即播放
        return sound
    }

}