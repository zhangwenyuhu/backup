declare module MD5{
    function hex(s:string):string;
    function b64(s:string):string;
    function any(s:string):string;
    function hex_hmac(key:any,data:any):string;
    function b64_hmac(key:any,data:any):string;
    function any_hmac(key:any,data:any):string;
}