/**
 * https://developers.weixin.qq.com/minigame/dev/
 */
declare module wx{

    //https://developers.weixin.qq.com/minigame/dev/document/open-api/data/KVData.html
    class KVData{
        key:string
        value:string
    }

    //https://developers.weixin.qq.com/minigame/dev/document/open-api/data/UserGameData.html
    class UserGameData {
        //用户的微信头像 url
        avatarUrl:string 

        //用户的微信昵称
        nickname:string

        //用户的 openid
        openid:string

        //用户的托管 KV 数据列表
        KVDataList:KVData[] 
    }

    class UserInfo{
        avatarUrl:string//用户头像图片 url	
        city:string//用户所在城市	
        country:string//用户所在国家	
        gender:number//用户性别	
        language:string//显示 country province city 所用的语言	
        nickName:string//用户昵称	
        openId:string//用户 openId	
        province:string//用户所在省份
    }

    class OpenDataContext{
        canvas:any

        /**
         * 向开放数据域发送消息
         * @param message 要发送的消息，message 中及嵌套对象中 key 的 value 只能是 primitive value。即 number、string、boolean、null、undefined。
         */
        postMessage(message);
    }

    class ShareOption{
        title?:string	        //转发标题，不传则默认使用当前小游戏的昵称。	
        imageUrl?:string	        //转发显示图片的链接，可以是网络图片路径或本地图片文件路径或相对代码包根目录的图片文件路径。	
        query?:string	        //查询字符串，必须是 key1=val1&key2=val2 的格式。从这条转发消息进入后，可通过 wx.onLaunch() 或 wx.onShow 获取启动参数中的 query。
    }

    class InnerAudioContext {
        //属性
        src:string 
        //音频资源的地址
        
        autoplay:boolean 
        //是否自动播放
        
        loop:boolean 
        //是否循环播放
        
        obeyMuteSwitch:boolean 
        //是否遵循系统静音开关，当此参数为 false 时，即使用户打开了静音开关，也能继续发出声音
        
        duration:number 
        //当前音频的长度，单位 s。只有在当前有合法的 src 时返回
        
        currentTime:number 
        //当前音频的播放位置，单位 s。只有在当前有合法的 src 时返回，时间不取整，保留小数点后 6 位
        
        paused:boolean 
        //当前是是否暂停或停止状态，true 表示暂停或停止，false 表示正在播放
        
        buffered:number 
        //音频缓冲的时间点，仅保证当前播放时间点到此时间点内容已缓冲
        
        volume:number 
        //音量。范围 0~1。
        
        //方法
        play()
        //播放
        
        pause()
        //暂停。暂停后的音频再播放会从暂停处开始播放
        
        stop()
        //停止。停止后的音频再播放会从头开始播放。
        
        seek(position:number )
        //跳转到指定位置，单位 s
        
        destroy()
        //销毁当前实例
        
        onCanplay(callback:Function )
        //监听音频进入可以播放状态的事件
        
        offCanplay(callback:Function )
        //取消监听音频进入可以播放状态的事件
        
        onPlay(callback:Function )
        //监听音频播放事件
        
        offPlay(callback:Function )
        //取消监听音频播放事件
        
        onPause(callback:Function )
        //监听音频暂停事件
        
        offPause(callback:Function )
        //取消监听音频暂停事件
        
        onStop(callback:Function )
        //监听音频停止事件
        
        offStop(callback:Function )
        //取消监听音频停止事件
        
        onEnded(callback:Function )
        //监听音频自然播放至结束的事件
        
        offEnded(callback:Function )
        //取消监听音频自然播放至结束的事件
        
        onTimeUpdate(callback:Function )
        //监听音频播放进度更新事件
        
        offTimeUpdate(callback:Function )
        //取消监听音频播放进度更新事件
        
        onError(callback:Function )
        //监听音频播放错误事件
        
        offError(callback:Function )
        //取消监听音频播放错误事件
        
        onWaiting(callback:Function )
        //监听音频加载中事件，当音频因为数据不足，需要停下来加载时会触发
        
        offWaiting(callback:Function )
        //取消监听音频加载中事件，当音频因为数据不足，需要停下来加载时会触发
        
        onSeeking(callback:Function )
        //监听音频进行跳转操作的事件
        
        offSeeking(callback:Function )
        //取消监听音频进行跳转操作的事件
        
        onSeeked(callback:Function )
        //监听音频完成跳转操作的事件
        
        offSeeked(callback:Function )
        //取消监听音频完成跳转操作的事件
        
        play()
        //播放
        
        pause()
        //暂停。暂停后的音频再播放会从暂停处开始播放
        
        stop()
        //停止。停止后的音频再播放会从头开始播放。
        
        seek(position:number )
        //跳转到指定位置，单位 s
        
        destroy()
        //销毁当前实例
    }

    class SystemInfo{
        brand:string//	手机品牌	1.5.0
        model:string//	手机型号	
        pixelRatio:number//	设备像素比	
        screenWidth:number//	屏幕宽度	1.1.0
        screenHeight:number//	屏幕高度	1.1.0
        windowWidth:number//	可使用窗口宽度	
        windowHeight:number//	可使用窗口高度	
        language:string//	微信设置的语言	
        version:string//	微信版本号	
        system:string//	操作系统版本	
        platform:string//	客户端平台	
        fontSizeSetting:number//	用户字体大小设置。以“我-设置-通用-字体大小”中的设置为准，单位 px。	1.5.0
        SDKVersion:string//	客户端基础库版本	1.1.0
        benchmarkLevel:number//	性能等级，-2 或 0：该设备无法运行小游戏，-1：性能未知，>=1 设备性能值，该值越高，设备性能越好(目前设备最高不到50)	1.8.0
        battery:number//	电量，范围 1 - 100	1.9.0
        wifiSignal:number//	wifi 信号强度，范围 0 - 4	1.9.0
    }


    /**
     * https://developers.weixin.qq.com/minigame/dev/document/open-api/data/wx.getFriendCloudStorage.html
     * 拉取当前用户所有同玩好友的托管数据。该接口只可在开放数据域下使用
     * @param obj 
     * keyList	Array.<string>	要拉取的 key 列表	
     * success	function		接口调用成功的回调函数	
     * fail	    function		接口调用失败的回调函数	
     * complete	function	    接口调用结束的回调函数（调用成功、失败都会执行）
     */
    function getFriendCloudStorage(obj:{keyList:string[],success?:(res:{data:UserGameData[]})=>void,fail?:Function,complete?:Function}):void;

    /**
     * https://developers.weixin.qq.com/minigame/dev/document/open-api/data/wx.getUserCloudStorage.html
     * 获取当前用户托管数据当中对应 key 的数据。该接口只可在开放数据域下使用
     * @param obj 
     * keyList	Array.<string>	要拉取的 key 列表	
     * success	function		接口调用成功的回调函数	
     * fail	    function		接口调用失败的回调函数	
     * complete	function	    接口调用结束的回调函数（调用成功、失败都会执行）
     */
    function getUserCloudStorage(obj:{keyList:string[],success?:(res:{data:UserGameData[]})=>void,fail?:Function,complete?:Function})

    /**
     * https://developers.weixin.qq.com/minigame/dev/document/open-api/data/wx.getUserInfo.html
     * 在无须用户授权的情况下，批量获取用户信息。该接口只在开放数据域下可用
     * wx.getUserInfo({
            openIdList: ['selfOpenId', 'ownAP0b9qt6AzvYOSWOX8VX8KMq0', 'ownAP0QJHIN2w3X60EUsj2Vah5Ig', 'ownAP0f8ANWUCcloXN1oZPfxtz0g'],
            lang: 'zh_CN',
            success: (res) = > {
                console.log('success', res.data)
            },
            fail: (res) = > {
                reject(res)
            }
        })
     */
    function getUserInfo(obj:{openIdList?:string[],lang?:"en"|"zh_CN"|"zh_TW",success?:(res:{userInfo:UserInfo})=>void,fail?:Function,complete?:Function})


    /**
     * 在小游戏是通过群分享卡片打开的情况下，可以通过调用该接口获取群同玩成员的游戏数据。该接口只可在开放数据域下使用。
     */
    function getGroupCloudStorage(obj:{shareTicket:string,keyList:string[],success?:(res:{data:UserGameData[]})=>void,fail?:Function,complete?:Function})

    /**
     * 只有开放数据域能调用，获取主域和开放数据域共享的 sharedCanvas
     */
    function getSharedCanvas():any


    /**
     * https://developers.weixin.qq.com/minigame/dev/document/open-api/data/wx.removeUserCloudStorage.html
     * 删除用户托管数据当中对应 key 的数据。
     */
    function removeUserCloudStorage(obj:{keyList:string[],success?:Function,fail?:Function,complete?:Function})

    /**
     * https://developers.weixin.qq.com/minigame/dev/tutorial/open-ability/open-data.html
     * https://developers.weixin.qq.com/minigame/dev/document/open-api/data/wx.setUserCloudStorage.html
     * 对用户托管数据进行写数据操作，允许同时写多组 KV 数据。
     */
    function setUserCloudStorage(obj:{KVDataList:KVData[],success?:Function,fail?:Function,complete?:Function})

    /**
     * 返回小程序启动参数
     * https://developers.weixin.qq.com/minigame/dev/document/system/life-cycle/wx.getLaunchOptionsSync.html
     */
    function getLaunchOptionsSync():{scene:string,query:any,path?:string,isSticky:boolean,shareTicket:string,referrerInfo:{appId:string,extraData:any}}

    /**
     * 监听小游戏回到前台的事件
     * https://developers.weixin.qq.com/minigame/dev/document/system/life-cycle/wx.onShow.html
     */
    function onShow(callback:(res:{scene:string,query:any,shareTicket:string})=>void);
    function onHide(callback:Function);
    function offHide(callback:Function);
    function offShow(callback:Function);

    /**
     * 退出当前小游戏
     * https://developers.weixin.qq.com/minigame/dev/document/system/life-cycle/wx.exitMiniProgram.html
     */
    function exitMiniProgram(obj:{success?:Function,fail?:Function,complete?:Function});

    //https://developers.weixin.qq.com/minigame/dev/document/open-api/data/removeUserStorage.html
    //POST https://api.weixin.qq.com/wxa/remove_user_storage?access_token=ACCESS_TOKEN&signature=SIGNATURE&openid=OPENID&sig_method=SIG_METHOD
    /**
     *  access_token	string		是	接口调用凭证
        openid	        string		是	用户唯一标识符
        appid	        string		是	小程序 appId
        signature	    string		是	用户登录态签名，签名算法请参考用户登录态签名算法
        sig_method	    string		是	用户登录态签名的哈希方法，如hmac_sha256等，请参考用户登录态签名算法
        key             string		是	要删除的数据key列表

        curl - d '{ "key":["gold", "score"] }'\'https://api.weixin.qq.com/wxa/remove_user_storage?access_token=ACCESS_TOKEN&signature=SIGNATURE&openid=OPENID&sig_method=SIG_METHOD'
     */


     /**
      * setUserStorage
      * 
      * access_token	string		是	接口调用凭证
        openid	string		是	用户唯一标识符
        appid	string		是	小程序 appId
        signature	string		是	用户登录态签名，签名算法请参考用户登录态签名算法
        sig_method	string		是	用户登录态签名的哈希方法，如hmac_sha256等，请参考用户登录态签名算法
        kv_list	Object		是	要上报的数据
      */

    /**
     * https://developers.weixin.qq.com/minigame/dev/document/open-api/data/removeUserStorage.html
     * 小游戏可以通过本接口删除已经上报到微信的key-value数据
     * POST https://api.weixin.qq.com/wxa/remove_user_storage?access_token=ACCESS_TOKEN&signature=SIGNATURE&openid=OPENID&sig_method=SIG_METHOD
     */

     /**
      * https://developers.weixin.qq.com/minigame/dev/document/open-api/data/setUserStorage.html
      */

    /**
     * https://developers.weixin.qq.com/minigame/dev/document/location/wx.getLocation.html
     * 获取当前的地理位置、速度。当用户离开小程序后，此接口无法调用；当用户点击“显示在聊天顶部”时，此接口可继续调用。
     * type wgs84 返回 gps 坐标，gcj02 返回可用于 wx.openLocation 的坐标	
     */
    function getLocation(obj:{type?:string,success?:(res:{
        latitude:number,longitude:number,speed:number,accuracy:number,altitude:number,verticalAccuracy:number,horizontalAccuracy:number
    })=>void,fail?:Function,complete?:Function});


    /**
     * 通过 wx.login 接口获得的用户登录态拥有一定的时效性。用户越久未使用小程序，用户登录态越有可能失效。反之如果用户一直在使用小程序，则用户登录态一直保持有效。具体时效逻辑由微信维护，对开发者透明。开发者只需要调用 wx.checkSession 接口检测当前用户登录态是否有效。登录态过期后开发者可以再调用 wx.login 获取新的用户登录态。
     */
    function checkSession(obj:{success?:Function,fail?:Function,complete?:Function});

    /**
     * 调用接口获取登录凭证（code）进而换取用户登录态信息，包括用户的唯一标识（openid） 及本次登录的 会话密钥（session_key）等。用户数据的加解密通讯需要依赖会话密钥完成。
     * success=>res.code 用户登录凭证（有效期五分钟）。开发者需要在开发者服务器后台调用 code2accessToken，使用 code 换取 openid 和 session_key 等信息
     * https://developers.weixin.qq.com/minigame/dev/document/open-api/login/wx.login.html
     */
    function login(obj:{success?:(res:{code:string})=>void,fail?:Function,complete?:Function});


    /**
     * https://developers.weixin.qq.com/minigame/dev/document/open-api/login/code2accessToken.html
     * code2accessToken
        登录凭证校验，开发者服务器使用 临时登录凭证code 获取 session_key 和 openid 等。

        请求地址
        GET https://api.weixin.qq.com/sns/jscode2session?appid=APPID&secret=SECRET&js_code=JSCODE&grant_type=authorization_code
     */


     /**
      * 获取开放数据域
      */
    function getOpenDataContext():OpenDataContext;

    /**
     * 监听主域发送的消息
     * @param callback 
     */
    function onMessage(callback)



    //Banner 广告
    class BannerAd {
        //属性
        adUnitId:string 
        style:{
            left:number//		banner 广告组件的左上角横坐标	
            top:number//		banner 广告组件的左上角纵坐标	
            width:number//		banner 广告组件的宽度。最小 300，最大至 屏幕宽度（屏幕宽度可以通过 wx.getSystemInfoSync() 获取）。
            height:number//		banner 广告组件的高度
            realWidth:number//		banner 广告组件经过缩放后真实的宽度
        };
        //方法
        show();//显示 banner 广告
        hide();//隐藏 banner 广告
        destroy();//销毁 banner 广告
        onResize(callback:Function);//监听隐藏 banner 广告
        offResize(callback:Function);//取消监听隐藏 banner 广告
        onLoad(callback:Function);//监听banner 广告加载事件
        offLoad(callback:Function);//取消监听banner 广告加载事件
        onError(callback:Function);//监听banner 广告错误事件
        offError(callback:Function);//取消监听banner 广告错误事件
    }
    /**
     * 创建Banner 广告组件
     * @param obj 
     * @param adUnitId
     * @param style
     */
    function createBannerAd(obj:{adUnitId:string,style:{left?:number,top?:number,width?:number,height?:number}}):BannerAd;

    //激励视频广告
    class RewardedVideoAd {
        //属性
        adUnitId:string 
        //方法
        load();//隐藏激励视频广告
        show();//显示激励视频广告。激励视频广告将从屏幕下方推入。
        destroy();//销毁 banner 广告
        onResize(callback:Function);//监听隐藏 banner 广告
        offResize(callback:Function);//取消监听隐藏 banner 广告
        onLoad(callback:Function);//监听激励视频广告加载事件
        offLoad(callback:Function);//取消监听激励视频广告加载事件
        onError(callback:Function);//监听激励视频错误事件
        offError(callback:Function);//取消监听激励视频错误事件
        onClose(callback:Function);//监听用户点击 关闭广告 按钮的事件
        offClose(callback:Function);//取消监听用户点击 关闭广告 按钮的事件
    }


    /**
     * 创建激励视频广告组件
     * @param obj 
     */
    function createRewardedVideoAd(obj:{adUnitId:string}):RewardedVideoAd;
    /**
     * 获取转发详细信息
     * 
     * @param obj 
     *   shareTicket		shareTicket	
     *   success	    	接口调用成功的回调函数	
     *   fail				接口调用失败的回调函数	
     *   complete		    接口调用结束的回调函数（调用成功、失败都会执行）
     */
    function getShareInfo(obj:{shareTicket:string, success?:(res:{errMsg:string, encryptedData:string, iv:string})=>void, fail?:Function, complete?:Function});

    /**
     * 隐藏转发按钮
     */
    function hideShareMenu(obj:{success?:Function, fail?:Function, complete?:Function});

    /**
     * 监听用户点击右上角菜单的“转发”按钮时触发的事件
     * @param callback 
     * 返回值 ShareOption
     */
    function onShareAppMessage(callback:()=>{title?:string, imageUrl?:string, query?:string});
    
    /**
     * 取消监听用户点击右上角菜单的“转发”按钮时触发的事件
     * @param callback 
     */
    function offShareAppMessage(callback);

    /**
     * 显示当前页面的转发按钮
     * @param obj 
     *  withShareTicket	boolean		是	是否使用带 shareTicket 若为false 通讯录界面不可多选 转发后长按没有反应
        success	        function		    否	接口调用成功的回调函数	
        fail	        unction		    否	接口调用失败的回调函数	
        complete	    function		否	接口调用结束的回调函数（调用成功、失败都会执行）
     */
    function showShareMenu(obj:{withShareTicket:boolean, success?:Function, fail?:Function, complete?:Function});

    /**
     * 主动拉起转发，进入选择通讯录界面。
     * @param obj 
     *  title	string		否	转发标题，不传则默认使用当前小游戏的昵称。	
        imageUrl	string		否	转发显示图片的链接，可以是网络图片路径或本地图片文件路径或相对代码包根目录的图片文件路径。	
        query	string		否	查询字符串，从这条转发消息进入后，可通过 wx.onLaunch() 或 wx.onShow 获取启动参数中的 query。必须是 key1=val1&key2=val2 的格式。
     */
    function shareAppMessage(obj?:{title?:string, imageUrl?:string, query?:string,success?:Function, fail?:Function, complete?:Function});

    /**
     * 更新转发属性
     * @param obj 
     *  withShareTicket	boolean		是	是否使用带 shareTicket 若为false 通讯录界面不可多选 转发后长按没有反应
        success	function		否	接口调用成功的回调函数	
        fail	function		否	接口调用失败的回调函数	
        complete	function		否	接口调用结束的回调函数（调用成功、失败都会执行）
     */
    function updateShareMenu(obj:{withShareTicket:boolean, success?:Function, fail?:Function, complete?:Function});


    function clearStorage(obj:{success?:Function, fail?:Function, complete?:Function});

    function clearStorageSync();

    function getStorage(obj:{key:string,success?:Function, fail?:Function, complete?:Function});
    function getStorageSync(key:string):string

    function getStorageInfo(obj:{success:(res:{keys:string[],currentSize:number,limitSize:number})=>void, fail?:Function, complete?:Function});

    function getStorageInfoSync():{keys:string[],currentSize:number,limitSize:number}

    function removeStorage(obj:{key:string,success?:Function, fail?:Function, complete?:Function});

    function removeStorageSync(key:string)

    function setStorage(obj:{key:string,data:string,success?:Function, fail?:Function, complete?:Function})
    
    function setStorageSync(key:string,data:string)

    /**
     !zh 可以修改渲染帧率。默认渲染帧率为 60 帧每秒。修改后，requestAnimationFrame 的回调频率会发生改变。
     * @param fps 
     * 帧率，有效范围 1 - 60。
     */
    function setPreferredFramesPerSecond(fps:number)

    function onMemoryWarning(cb:(res:{level:number})=>void);

    function triggerGC()

    function createInnerAudioContext():InnerAudioContext
    

    function getSystemInfoSync():SystemInfo


    //退出微信小游戏
    function exitMiniProgram(obj:{success?:Function, fail?:Function, complete?:Function});

    class UpdateManager{
        
        //监听检查更新结果回调
        onCheckForUpdate(callback:(res:{hasUpdate:boolean})=>void)

        //监听更新包下载成功回调
        onUpdateReady(callback:Function)

        //监听更新包下载失败回调
        onUpdateFailed(callback:Function)

        //应用更新包并重启
        applyUpdate()

    }

    //获取微信更新管理器
    function getUpdateManager():UpdateManager;

    function showLoading(object:Object)
    function hideLoading(object:Object)
    //全局错误捕获
    function onError(callback:(res:{message:string,stack:string})=>void);

    function showModal(obj:{
        title:string//		是	提示的标题	
        content:string//		是	提示的内容	
        cancelText:string//		是	取消按钮的文字，最多 4 个字符串	
        confirmText:string//		是	确认按钮的文字，最多 4 个字符串	
        showCancel?:boolean//	true	否	是否显示取消按钮	
        cancelColor?:string//	#000000	否	取消按钮的文字颜色，必须是 16 进制格式的颜色字符串	
        confirmColor?:string//	#3cc51f	否	确认按钮的文字颜色，必须是 16 进制格式的颜色字符串	
        success?:(res:{confirm:boolean,cancel:boolean})=>void//		否	接口调用成功的回调函数	
        fail?:Function//		否	接口调用失败的回调函数	
        complete?:Function//		否	接口调用结束的回调函数（调用成功、失败都会执行）
    })

    class UserInfoButton{
        text:string //按钮上的文本，仅当 type 为 text 时有效
        image:string //按钮的背景图片，仅当 type 为 image 时有效
        style:{
            left?:number//		是	左上角横坐标	
            top?:number//		是	左上角纵坐标	
            width?:number//		是	宽度	
            height?:number//		是	高度	
            backgroundColor?:string//		是	背景颜色	
            borderColor?:string//		是	边框颜色	
            borderWidth?:number//		是	边框宽度	
            borderRadius?:number//		是	边框圆角	
            textAlign?:"left"|"center"|"right"//		是	文本的水平居中方式	
            fontSize?:number//		是	字号	
            lineHeight?:number//		是	文本的行高
            color?: string,

        }//		是	按钮的样式 

        //显示用户信息按钮
        show()

        //隐藏用户信息按钮
        hide()

        //销毁用户信息按钮
        destroy()

        //监听用户信息按钮点击事件
        onTap(callback:Function)

        //取消监听用户信息按钮点击事件
        offTap(callback:Function)

        //显示用户信息按钮
        show()

        //隐藏用户信息按钮
        hide()

        //销毁用户信息按钮
        destroy()
    }

    function createUserInfoButton(obj:{
        type:string,//		是	按钮的类型	text 可以设置背景色和文本的按钮     image只能设置背景贴图的按钮，背景贴图会直接拉伸到按钮的宽高
        text?:string,//		是	按钮上的文本，仅当 type 为 text 时有效	
        image?:string,//		是	按钮的背景图片，仅当 type 为 image 时有效	
        style:{
            left?:number//		是	左上角横坐标	
            top?:number//		是	左上角纵坐标	
            width?:number//		是	宽度	
            height?:number//		是	高度	
            backgroundColor?:string//		是	背景颜色	
            borderColor?:string//		是	边框颜色	
            borderWidth?:number//		是	边框宽度	
            borderRadius?:number//		是	边框圆角	
            textAlign?:"left"|"center"|"right"//		是	文本的水平居中方式	
            fontSize?:number//		是	字号	
            lineHeight?:number//		是	文本的行高
            color?: string,

        }//		是	按钮的样式
    }):UserInfoButton

    function openCustomerServiceConversation(object:Object)

    //发起米大师支付
    //https://developers.weixin.qq.com/minigame/dev/document/midas-payment/wx.requestMidasPayment.html
    function requestMidasPayment(req:{
        mode	        :string//		是	支付的类型，不同的支付类型有各自额外要传的附加参数。	
        env?	        :number//	0	否	环境配置	
        offerId	        :string//		是	在米大师侧申请的应用 id	
        currencyType	:string//		是	币种	
        platform?	    :string//		否	申请接入时的平台，platform 与应用id有关。	
        buyQuantity?	:number//		否	购买数量。mode=game 时必填。购买数量。详见 buyQuantity 限制说明。	
        zoneId?	        :string//	1	否	分区 ID	
        success?	    :Function//		否	接口调用成功的回调函数	
        fail?	        :(res:{errMsg:string,errCode:number})=>void//		否	接口调用失败的回调函数	
        complete?	    :Function//		否	接口调用结束的回调函数（调用成功、失败都会执行）
    });

    //预览图片，调用之后会在新打开的页面中全屏预览传入的图片，预览的过程中用户可以进行保存图片、发送给朋友等操作
    function previewImage(req:{
        current?:string//urls 的第一张	否	当前显示图片的链接	
        urls:string[]//		是	需要预览的图片链接列表	
        success?:()=>void//		否	接口调用成功的回调函数	
        fail?:()=>void//		否	接口调用失败的回调函数	
        complete?:()=>void//		否	接口调用结束的回调函数（调用成功、失败都会执行）        
    })

    function showToast(params:{
        title:string,
        icon?:{
            success:string,
            loading:string,
        },
        image?:string,
        duration?:number,
        success?:Function,
        fail?:Function,
        complete?:Function,
    });
    



}
