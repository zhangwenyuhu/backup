let unitNum=[null,'K','M','B','T','aa','bb','cc','dd','ee','ff','gg','hh','ii','jj','kk','ll','mm','nn','oo','pp','qq','rr','ss','tt','uu','vv','ww','xx','yy','zz','Aa','Bb','Cc','Dd','Ee','Ff','Gg','Hh','Ii','Jj','Kk','Ll','Mm','Nn','Oo','Pp','Qq','Rr','Ss','Tt','Uu','Vv','Ww','Xx','Yy','Zz','AA','BB','CC','DD','EE','FF','GG','HH','II','JJ','KK','LL','MM','NN','OO','PP','QQ','RR','SS','TT','UU','VV','WW','XX','YY','ZZ']
let unitNumBigMap=[];
for(let i=0;i<unitNum.length;i++){
    unitNumBigMap.push(new BigNumber("1" + "0".repeat(i*3)))
}

export class BigNumberHelper{
    
    static convertUnitNumber(gold: number, unit?: string): BigNumber {
        if (unit == null || unit == "" || unit == "undefined") {
            return new BigNumber(gold)
        }
        let index=unitNum.indexOf(unit);
        if(index==-1){
            index=0;
        }
        let unitObj=unitNumBigMap[index]
        cc.assert(unitObj)
        return unitObj.multipliedBy(gold)
    }
    static convertUnitString(value:string):BigNumber{
        let matchList=value.match(/[a-zA-Z]+/)
        if(!matchList||matchList.length==0){
            return new BigNumber(value)
        }else{
            let unit=matchList[0]
            let num=parseFloat(value)
            return this.convertUnitNumber(num,unit);
        }
    }

    static convertNumStr2UnitStr(value: string, offset: number = 0, fixedNum: number = 2):string {
        value=value.split('.')[0]
        let count = Math.floor((value.length-1) / 3);
        if (count == 0) {
            return value;
        }
        count -= offset;
        // var unitObj = unitconfig.where(a => a.unitid == count).single
        let unit=unitNum[count]
        if(unit==null){//兼容 显示最后的单位
            count=unitNum.length-1;
            unit=unitNum[count]
        }

        let expdiv=count * 3
        const zlen=value.length-expdiv
        let znum=value.substr(0,zlen)
        let fnum=value.substr(zlen,fixedNum)
        if(fnum.lastIndexOf('00')==(fixedNum-2) || !fnum){
            return `${znum}${unit || ''}`
        }else{
            return `${znum}.${fnum}${unit || ''}`
        }
        return null
    }

}