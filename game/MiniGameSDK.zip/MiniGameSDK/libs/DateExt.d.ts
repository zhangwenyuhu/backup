
interface Date{
	format(format:string):string;
	rawformat(format:string):string;
}
