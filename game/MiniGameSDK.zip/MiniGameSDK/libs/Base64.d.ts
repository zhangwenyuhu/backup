module Base64{
    declare function atob(v:any);
    declare function btoa(v:any);
    declare function utob(v:any);
    declare function encode(v:any);
    declare function encodeURI(v:any);
    declare function btou(v:any);
    declare function decode(v:any);
}
