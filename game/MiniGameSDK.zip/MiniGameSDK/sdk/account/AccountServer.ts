import HttpGameClient from "../../net/HttpGameClient";
import core from "../../core/Core";

export default class AccountServer{

    static readonly gameClient:HttpGameClient=new HttpGameClient();

    /**
     * 用户登录接口(用户首次进入游戏调用)
     */
    static userLogin(
        data:{
            code:string,
            system:number,//系统类型  0:android  1:ios
            launchOptionsQuery?:any,//启动参数query 
            launchOptionsPath?:any, //启动参数path
            channelId?:number;//渠道id
            clientSystemInfo:any;//系统信息
            extraData?:any;//扩展数据
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:{
                userId:number,
                openId?:string,
                serviceTimestamp:number
                dataTimestamp:number//上次存档的时间戳
                nickname:string,
                profileImg:string,
                backupTime:number//上传存档时间 秒
                userNew:false,//是否为新用户
                shareSwitch:{
                   
                },
                gameCurrency:{
                    gold: string,
                    diamond: string,
                    seed: string        
                },
                createTime: string,//创建时间
                channelId: number,//渠道id

                encryptKey:string,//存档加密key
                token:string,//登陆token

                gametoken:string//用于游戏服的登陆信息
            }
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request(`user/login?v=${core.info.version}&resv=${core.info.resVersion}`,data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    // 微信解密
    static wxDecrypt(
        data:{
            encryptedData:string,
            iv:string,
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data: string, // 解密后数据
        })=>void,
        modal:boolean=true,
        errorCallback:(error:any,retry:()=>void)=>void=null
    ){
        this.gameClient.request(`wxcode/wxDecrypt?v=${core.info.version}&resv=${core.info.resVersion}`,data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    //分享关联用户列表接口
    static getShareRelationList(
        data:{
            sign:string,
            size:number,
            onlyNew:number
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:{
                shareRelations:{
                    userId:number,
                    relationId:number,
                    sign:string,
                    nickname:string,
                    profileImg:string,
                    joinTimestamp:string,
                    userNew:boolean,
                }[]
            }
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
        this.gameClient.request(`share/getShareRelationList?v=${core.info.version}&resv=${core.info.resVersion}`,data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }
}