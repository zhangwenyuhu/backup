import core, { LayerType } from "../../core/Core";

type DevelopItem={
    type:"input"|"check"|"button"|"label"
    label:string
    commitLabel?:string
    get?:()=>string|boolean
    set?:(v:string|boolean)=>void
    enabled?:()=>boolean
    click?:()=>void
}
export class DevelopTool {
    static readonly instance=new DevelopTool

    protected _itemList:DevelopItem[]=[]

    protected _developBtn:cc.Node;

    constructor(){

    }

    /**
     * 显示开发按钮
     */
    showDevelopButton(){
        if(!this._developBtn){

            core.init()

            this._developBtn=new cc.Node
            this._developBtn.position = cc.p(690,1230)
            this._developBtn.color=cc.Color.RED;
            let label=this._developBtn.addComponent(cc.Label)
            label.string="DEBUG"
            label.fontSize=30
            label.lineHeight=30

            let isDown=false;
            this._developBtn.on(cc.Node.EventType.TOUCH_START,(e:cc.Event.EventTouch)=>{
                isDown=true;
            })

            this._developBtn.on(cc.Node.EventType.TOUCH_MOVE,(e:cc.Event.EventTouch)=>{
                if(isDown){
                    this._developBtn.position=e.getLocation()
                }
            })

            this._developBtn.on(cc.Node.EventType.TOUCH_END,(e:cc.Event.EventTouch)=>{
                isDown=false;
                if(e.getStartLocation().fuzzyEquals(e.getLocation(),5)){
                    this.showDevelopDialog();
                }
            })
            
        }
        if(this._developBtn.getParent()==null){
            core.debugLayer.addChild(this._developBtn);
        }
    }

    /**
     * 隐藏开发按钮
     */
    hideDevelopButton(){
        if(this._developBtn && this._developBtn.getParent()){
            this._developBtn.removeFromParent(false);
        }
    }

    /**
     * 显示开发对话框
     */
    showDevelopDialog(){
        core.showLayer("scripts/framework/sdk/devtool/res/DDevelopDialog",{modalWindow:false,layer:LayerType.DEBUG});
    }

    /**
     * 隐藏开发对话框
     */
    hideDevelopDialog(){
        core.closeLayer("scripts/framework/sdk/devtool/res/DDevelopDialog")
    }

    /**
     * 注册string类型的开发选项
     * @param label 描述标签
     * @param commitLabel 按钮标签
     * @param get 获取值函数
     * @param set 设置值函数
     */
    registerInput(label:string,commitLabel:string,get:()=>string,set:(value:string)=>void){
        this._itemList.push({type:"input",label,commitLabel,get,set})
    }

    /**
     * 注册bool类型的开发选项
     * @param label 描述标签
     * @param get 获取值函数
     * @param set 设置值函数
     */
    registerCheck(label:string,get:()=>boolean,set:(value:boolean)=>void){
        this._itemList.push({type:"check",label,get,set})
    }

    /**
     * 注册按钮
     * @param label 描述标签
     * @param enabled 按钮是否启用
     * @param click 点击回调
     */
    registerButton(label:string,enabled:()=>boolean,click:()=>void){
        this._itemList.push({type:"button",label,enabled,click})
    }

    /**
     * 注册标签
     * @param label 描述表现
     * @param get 获取的值
     */
    registerLabel(label:string,get:()=>string){
        this._itemList.push({type:"label",label,get})
    }

    /**
     * 添加默认的开发选项
     */
    registerDefault(){
        this.registerCheck("显示帧数",()=>{
            return cc["debug"].isDisplayStats()
        },(value)=>{
            cc["debug"].setDisplayStats(value)
        })

        this.registerInput("帧数","设置",()=>{
            return cc.game.getFrameRate()+""
        },(value:string)=>{
            cc.game.setFrameRate(parseInt(value))
        });
    }

    /**
     * 选项列表
     */
    get itemList(){
        return this._itemList;
    }

}

var develop=DevelopTool.instance
export default develop