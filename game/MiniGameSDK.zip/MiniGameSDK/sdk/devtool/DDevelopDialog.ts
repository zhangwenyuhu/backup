import Dialog from "../../core/Dialog";
import develop from "./DevelopTool";

const {ccclass, property} = cc._decorator;

@ccclass
export default class DDevelopDialog extends Dialog {

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}

    start () {
        cc.find("root",this.node).setContentSize(cc.winSize)

    }

    // update (dt) {}

    onInit(data:any){
        //创建选项列表


        let inputItem=cc.find("root/list/view/content/inputItem",this.node)
        let checkItem=cc.find("root/list/view/content/checkItem",this.node)
        let buttonItem=cc.find("root/list/view/content/buttonItem",this.node)
        let labelItem=cc.find("root/list/view/content/labelItem",this.node)
        let content=cc.find("root/list/view/content",this.node)
        inputItem.removeFromParent()
        checkItem.removeFromParent()
        buttonItem.removeFromParent()
        labelItem.removeFromParent()

        let closeBtn=cc.find("root/closeBtn",this.node);
        closeBtn.on(cc.Node.EventType.TOUCH_END,()=>{
            this.close()
        })

        for(let item of develop.itemList){
            try{
                switch(item.type){
                    case "input":
                        {
                            let node=cc.instantiate(inputItem)
                            cc.find("label",node).getComponent(cc.Label).string=item.label
                            let input=cc.find("input",node).getComponent(cc.EditBox)
                            input.string=item.get() as string
                            cc.find("commit/Label",node).getComponent(cc.Label).string=item.commitLabel;
                            cc.find("commit",node).on(cc.Node.EventType.TOUCH_END,()=>{
                                item.set(input.string)
                            })
                            content.addChild(node);
                        }
                    break;
                    case "check":
                        {
                            let node=cc.instantiate(checkItem)
                            cc.find("label",node).getComponent(cc.Label).string=item.label
                            let toggle=cc.find("check",node).getComponent(cc.Toggle)
                            toggle.isChecked=item.get() as boolean
                            cc.find("check",node).on(cc.Node.EventType.TOUCH_END,()=>{
                                setTimeout(()=>{
                                    item.set(toggle.isChecked)
                                })
                            })
                            content.addChild(node);
                        }
                    break;
                    case "button":
                        {
                            let node=cc.instantiate(buttonItem)
                            cc.find("label",node).getComponent(cc.Label).string=item.label
                            let btn = cc.find("commit",node).getComponent(cc.Button)
                            btn.interactable=item.enabled();
                            cc.find("commit",node).on(cc.Node.EventType.TOUCH_END,()=>{
                                item.click();
                            })
                            content.addChild(node);
                        }
                    break;
                    case "label":
                        {
                            let node=cc.instantiate(labelItem)
                            cc.find("label",node).getComponent(cc.Label).string=item.label
                            let value=cc.find("value",node).getComponent(cc.EditBox)
                            value.string=item.get() as string
                            content.addChild(node);
                        }
                    break;
                }
            }catch(e){
                console.error(e);
            }
            
        }
        
    }
}
