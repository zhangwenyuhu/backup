import { LogicChainItem, LogicResult } from "../../core/LogicChain";
import core from "../../core/Core";
import i18n from "../../core/I18N";
import ServerV1 from "../server_v1/ServerV1";
import { LoginData } from "../../data/LoginData";
import LocalStorage from "../../core/LocalStorage";
import featureSwitch from "../../core/FeatureSwitch";
import storage from "../../core/StorageCenter";
import ServerLoginData from "../../data/ServerLoginData";

export const SYSTEM = {
    ANDROID: 1,
    IOS : 2,
    OTHER : 3,
}


/**
 * 普通登陆，用于网页测试等。
 */
export default class WXLogin extends LogicChainItem{
    public async logic(data:any):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{
            //内部测试登陆
            let reuslt=new LogicResult

            let loginLogic
            let onLoginError=()=>{
                core.showDialog(i18n.locString('network.error'),()=>{
                    //校对时间
                    ServerV1.gameGetSystemTime({}, res => {
                        core.serverTimeOffset = res.data - new Date().getTime();
                        //进入登录流程
                        loginLogic()
                    });
                })
            }

            loginLogic=()=>{
                if(window["wx"]){
                    if (wx.getOpenDataContext && typeof wx.getOpenDataContext == "function"){
                        wx.getOpenDataContext().postMessage({action:"initSubDomain",value:''})
                    }
                }

                wx.login({
                    success: (res: { code: string }) => {

                        let run=() => {
                            //请求服务器连接

                            let loginCallback=(data)=>{
                                //玩家数据
                                if (data.succeed) {

                                    //设置渠道信息
                                    LoginData.saved.createTime=data.data.createTime
                                    LoginData.saved.channelId=data.data.channelId || 0
                                    LoginData.saved.token=data.data.token
                                    LoginData.saved.roleId=data.data.userId
                                    LoginData.saved.openId=data.data.openId
                                    
                                    ServerLoginData.setLoginData(data.data)

                                    if(data.data.shareSwitch){
                                        for(let key in data.data.shareSwitch){
                                            featureSwitch.setFeature(key,data.data.shareSwitch[key]=="1")
                                        }
                                    }
                                                        
                                    if(data.data.encryptKey){
                                        LocalStorage.encryptKey=data.data.encryptKey
                                    }else{
                                        console.error("服务器没传递存档key")
                                    }

                                    if(window["wx"]){
                                        if (wx.getOpenDataContext && typeof wx.getOpenDataContext == "function"){
                                            wx.getOpenDataContext().postMessage({action:"setOpenId",value:data.data.openId})
                                        }
                                    }
                    

                                    //启动定时备份数据
                                    let backupTime=data.data.backupTime

                                    LocalStorage.setItem(storage.roleIdKey,data.data.userId.toString(),false);//保存至本地

                                    //向下传递数据
                                    reuslt.nextData={data:data,timestamp: data.data.dataTimestamp,gameCurrency:data.data.gameCurrency,avatarUrl:data.data.profileImg,
                                        nickName:data.data.nickname,
                                        isNew:data.data.userNew,roleId:data.data.userId}
                                    resolve(reuslt)

                                } else {
                                    console.error("登陆失败")
                                    onLoginError()
                                }
                            }

                            let roleId = LocalStorage.getItem(storage.roleIdKey,false);
                            if(roleId){
                                //保存roleId
                                LoginData.saved.roleId = parseInt(roleId);
                            }
                            // if (roleId) {
                            //     //直接使用该角色ID
                            //     ServerV1.gameClient.roleId = parseInt(roleId);
                            //     ServerV1.userGetUserInfo({ userId: ServerV1.gameClient.roleId }, (data) => {
                            //         loginCallback(data);
                            //     });
                            // }else{
                                let option = wx.getLaunchOptionsSync()
                                console.log("LaunchOptions",option);
                                let launchOptionsPath=option.path
                                let launchOptionsQuery=option.query
                                if(option&&option.referrerInfo){
                                    var extraData=option.referrerInfo.extraData;
                                }
                                // let launchOptions:string = "";
                                // let launchType = "";
                                // if (option.query.scene){
                                //     launchOptions = option.query.scene;
                                //     launchType = "scene"
                                // }else if(option.path && option.path != "index" && option.path != "index.html"){
                                //     launchOptions = option.path;
                                //     launchType = "path"
                                // }
                                let platform = wx.getSystemInfoSync().platform
                                let system = (platform == "android") ? SYSTEM.ANDROID : (platform == "ios" ? SYSTEM.IOS : SYSTEM.OTHER);

                                ServerV1.userLogin({ code: res.code ,launchOptionsPath:launchOptionsPath,launchOptionsQuery:launchOptionsQuery,system:system,clientSystemInfo:wx.getSystemInfoSync(),extraData:extraData}, (data) => {
                                    LocalStorage.setItem(storage.roleIdKey,data.data.userId.toString(),false);//保存至本地
                                    loginCallback(data);
                                },true,(error)=>{
                                    core.showDialog(i18n.locString('network.error'),()=>{
                                        loginLogic();
                                    },{okText:"重试"})
                                });
                            // }

                        }

                        run();
                        // 暂时不进行授权
                        
                    }, fail: (data) => {
                        console.error("微信登陆失败", data)
                        onLoginError()
                    }
                })
            }
            loginLogic();
        })
    }
}