import { LogicChainItem, LogicResult } from "../../core/LogicChain";
import LocalStorage from "../../core/LocalStorage";
import storage from "../../core/StorageCenter";
import { LoginData } from "../../data/LoginData";
import ServerV1 from "../server_v1/ServerV1";
import featureSwitch from "../../core/FeatureSwitch";
import ServerLoginData from "../../data/ServerLoginData";

/**
 * 普通登陆，用于网页测试等。
 */
export default class NormalLogin extends LogicChainItem{
    public async logic(data:any):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{
            //内部测试登陆
            let reuslt=new LogicResult
            let roleId = LocalStorage.getItem(storage.roleIdKey,false);
            console.log("roleId",roleId,parseInt(roleId))
            if (roleId) {
                //直接使用该角色ID
                LoginData.saved.roleId = parseInt(roleId);
                ServerV1.userGetUserInfo({ userId: LoginData.saved.roleId }, (data) => {
                    if (data.succeed) {
                        //设置渠道信息
                        LoginData.saved.createTime=data.data.createTime
                        LoginData.saved.channelId=data.data.channelId || 0
                        LoginData.saved.token=data.data.token
                        LoginData.saved.roleId=data.data.userId
                        
                        ServerLoginData.setLoginData(data.data)
                        
                        if(data.data.shareSwitch){
                            for(let key in data.data.shareSwitch){
                                featureSwitch.setFeature(key,data.data.shareSwitch[key]=="1")
                            }
                        }

                        if(data.data.encryptKey){
                            LocalStorage.encryptKey=data.data.encryptKey
                        }

                        //向下传递数据
                        reuslt.nextData={data:data,timestamp: data.data.dataTimestamp,gameCurrency:data.data.gameCurrency}
                        resolve(reuslt)
                    } else {
                        console.error("登陆失败")
                    }
                })
            } else {
                //创建新角色
                ServerV1.loginTest({}, (data) => {
                    //玩家数据
                    if (data.succeed) {

                        //设置渠道信息
                        LoginData.saved.createTime=data.data.createTime
                        LoginData.saved.channelId=data.data.channelId || 0
                        LoginData.saved.token=data.data.token
                        LoginData.saved.roleId=data.data.userId
                        
                        ServerLoginData.setLoginData(data.data)

                        if(data.data.shareSwitch){
                            for(let key in data.data.shareSwitch){
                                featureSwitch.setFeature(key,data.data.shareSwitch[key]=="1")
                            }
                        }

                        LocalStorage.setItem(storage.roleIdKey,data.data.userId.toString(),false);//保存至本地

                        if(data.data.encryptKey){
                            LocalStorage.encryptKey=data.data.encryptKey
                        }

                        //向下传递数据
                        reuslt.nextData={data:data,timestamp: data.data.dataTimestamp,gameCurrency:data.data.gameCurrency}
                        resolve(reuslt)
                    } else {
                        console.error("登陆失败")
                    }
                })
            }
        })
    }
}