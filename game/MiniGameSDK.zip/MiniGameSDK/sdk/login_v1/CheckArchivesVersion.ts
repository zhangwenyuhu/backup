import { LogicChainItem, LogicResult } from "../../core/LogicChain";
import storage from "../../core/StorageCenter";
import { LoginData } from "../../data/LoginData";
import core from "../../core/Core";

/**
 * 验证存档版本
 */
export default class CheckArchivesVersion extends LogicChainItem{
    public async logic({data,timestamp,gameCurrency}:{data:any,timestamp:number,gameCurrency:any}):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{
            let reuslt=new LogicResult
            reuslt.nextData={data:data,timestamp:timestamp,gameCurrency:gameCurrency}

            let dataVersion=!LoginData.saved.version?"1.0.0":LoginData.saved.version
            let gameVersion=!core.info.version?"1.0.0":core.info.version
            let dataVersionList=dataVersion.split('.')
            let gameVersionList=gameVersion.split('.')
            if(parseInt(gameVersionList[0])>=parseInt(dataVersionList[0])||
                parseInt(gameVersionList[1])>=parseInt(dataVersionList[1])||
                parseInt(gameVersionList[2])>=parseInt(dataVersionList[2])
            ){
                console.log(`存档版本 ${dataVersion} >> ${gameVersion}`)
            }else{
                //取消提示，直接兼容
                console.log(`存档版本 ${dataVersion} >> ${gameVersion}`)
                // Core.instance.showDialog(`存档版本与游戏不匹配\n存档版本${dataVersion} >> 游戏版本${gameVersion}`,()=>{
                // },{okText:"确定"})
            }

            //修改当前存档版本
            LoginData.saved.version=core.info.version;

            resolve(reuslt);
        })
    }
}