import { LogicChainItem, LogicResult } from "../../core/LogicChain";


/**
 * 应用服务器奖励
 */
export default class ApplyServerReward extends LogicChainItem{

    applyReward:(gameCurrency:any)=>void=null

    constructor(applyReward:(data:any)=>void){
        super();
        this.applyReward=applyReward;
    }


    public async logic({data,timestamp,gameCurrency}:{data:any,timestamp:number,gameCurrency:any}):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{
            let reuslt=new LogicResult
            reuslt.nextData={data:data,timestamp:timestamp,gameCurrency:gameCurrency}
            //接受服务器发送的奖励
            if(gameCurrency){
                this.applyReward(gameCurrency)
            }
            resolve(reuslt);
        })
    }
}