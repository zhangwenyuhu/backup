import { LogicChainItem, LogicResult } from "../../core/LogicChain";
import ServerV1 from "../server_v1/ServerV1";
import core from "../../core/Core";

/**
 * 检查服务器是否要进行强制跟新，如果是则通过微信API验证客户端版本
 */
export default class WXForceUpdate extends LogicChainItem{
    public async logic(data:any):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{
            let result=new LogicResult();
            
            if (window['wx'] && typeof wx.getUpdateManager === "function"){
                        
                ServerV1.checkForceUpdate({version:core.info.version},(data)=>{
                    console.log(`check update ${data.data.needUpdate}`)
                    // wx.hideLoading({})
                    if(data.data.needUpdate){
                        wx.showLoading({title:"检查更新中...",mask:true})
                        let updateManager = wx.getUpdateManager()
                        if (updateManager){
                            updateManager.onCheckForUpdate((hasUpdate)=>{
                                console.log("检查更新开始:")
                                if(hasUpdate.hasUpdate){
                                    console.log('有更新')
                                    // wx.showLoading({title:"检查更新中...",mask:true})
                                }else{
                                    console.log('没有更新')
                                    wx.hideLoading({})
                                    result.success=true;
                                    resolve(result)
                                }
                            })

                            updateManager.onUpdateReady(()=>{
                                console.log("更新完成")
                                wx.hideLoading({})
                                wx.showModal(
                                    {
                                        title:"提示",
                                        content:"已更新到新版本了呦~",
                                        confirmText:"重启游戏",
                                        cancelText:"重启游戏",
                                        showCancel:false,success:(res)=>{
                                            if(res.confirm){
                                                wx.getUpdateManager().applyUpdate()
                                            } 
                                        }
                                    }
                                )
                            })

                            updateManager.onUpdateFailed(()=>{
                                console.log("更新失败")
                                wx.hideLoading({})
                                wx.showModal(
                                    {
                                        title:"提示",
                                        content:"更新失败,请重启游戏",
                                        confirmText:"重启游戏",
                                        cancelText:"重启游戏",
                                        showCancel:false,success:(res)=>{
                                            if(res.confirm){
                                                wx.getUpdateManager().applyUpdate()
                                            } 
                                        }
                                    }
                                )
                            })
                        }
                    }else{
                        result.success=true;
                        resolve(result)
                    }
                }) 
            }else{
                result.success=true;
                resolve(result)
            }

        })
    }
}