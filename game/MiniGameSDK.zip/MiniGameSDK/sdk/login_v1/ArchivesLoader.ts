import { LogicChainItem, LogicResult } from "../../core/LogicChain";
import storage from "../../core/StorageCenter";
import { XXTEA } from "../../libs/xxtea";
import ServerV1 from "../server_v1/ServerV1";
import { LoginData } from "../../data/LoginData";
import core from "../../core/Core";
import LocalStorage from "../../core/LocalStorage";


/**
 * 加载存档
 */
export default class ArchivesLoader extends LogicChainItem{
    public async logic({data,timestamp,gameCurrency,avatarUrl,nickName,isNew,roleId}:{data:any,timestamp:number,gameCurrency:any,avatarUrl:string,nickName:string,isNew:boolean,roleId:number}):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{
            let reuslt=new LogicResult
            reuslt.nextData={data:data,timestamp:timestamp,gameCurrency:gameCurrency}

            console.log("存档",storage.isSaved,storage.timestamp,timestamp)
            if (timestamp != null && timestamp != 0 ) {
                //需要比较服务器的版本
                if (storage.isSaved && storage.timestamp >= timestamp) {
                    //使用本地存档
                    console.log("使用本地存档")
                    try{
                        storage.loadFromLocalStorage();//加载游戏存档
                        LoginData.saved.avatarUrl = avatarUrl;
                        LoginData.saved.nickName = nickName;
                        LoginData.saved.isNew  = isNew;
                        LoginData.saved.roleId = roleId;
                        reuslt.nextData["timestamp"] = storage.timestamp
                        resolve(reuslt);
                    }catch(e){
                        console.log(e)
                        core.showDialog("存档解析失败",()=>{
                        },{okText:"确定"})            
                    }
                } else {
                    //使用服务器存档
                    console.log("使用服务器存档")
                    ServerV1.backupGetBackup({ userId: roleId }, (res) => {
                        if (res.succeed && res.data) {
                            try{
                                let saveStr=XXTEA.decryptFromBase64Ex1(res.data.backupData,LocalStorage.encryptKey)
                                storage.load(JSON.parse(saveStr))
                                resolve(reuslt);
                            }catch(e){
                                console.log(e)
                                core.showDialog("存档解析失败",()=>{
                                },{okText:"确定"})                    
                            }
                        } else {
                            //失败则直接启动
                            try{
                                storage.loadFromLocalStorage();//加载游戏存档
                                LoginData.saved.avatarUrl = avatarUrl;
                                LoginData.saved.nickName = nickName;
                                LoginData.saved.isNew  = isNew;
                                LoginData.saved.roleId = roleId;
                                reuslt.nextData["timestamp"] = storage.timestamp
                                resolve(reuslt);
                            }catch(e){
                                console.log(e)
                                core.showDialog("存档解析失败",()=>{
                                },{okText:"确定"})                    
                            }
                        }
                    })
                }
            } else {
                //直接加载本地的
                try{
                    storage.loadFromLocalStorage();//加载游戏存档
                    LoginData.saved.avatarUrl = avatarUrl;
                    LoginData.saved.nickName = nickName;
                    LoginData.saved.isNew  = isNew;
                    LoginData.saved.roleId = roleId;
                    reuslt.nextData["timestamp"] = storage.timestamp
                    resolve(reuslt);
                }catch(e){
                    console.log(e)
                    core.showDialog("存档解析失败",()=>{
                    },{okText:"确定"})            
                }

            }
        })
    }
}