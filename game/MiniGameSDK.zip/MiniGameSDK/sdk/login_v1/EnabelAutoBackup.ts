import { LogicChainItem, LogicResult } from "../../core/LogicChain";
import AutoDataBackup from "../server_v1/AutoDataBackup";



/**
 * 验证存档版本
 */
export default class EnabelAutoBackup extends LogicChainItem{
    public async logic({data,timestamp,gameCurrency}:{data:any,timestamp:number,gameCurrency:any}):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{
            let reuslt=new LogicResult
            reuslt.nextData={data:data,timestamp:timestamp,gameCurrency:gameCurrency}

            AutoDataBackup.onStartBackup(data.data.backupTime)

            resolve(reuslt);
        })
    }
}