import { LogicChainItem, LogicResult } from "../../core/LogicChain";
import ServerV1 from "../server_v1/ServerV1";
import core from "../../core/Core";
import i18n from "../../core/I18N";


/**
 * 加载服务器数据表，必须加载成功
 */
export default class TableLoader extends LogicChainItem{

    //需要在函数中执行initTable
    loadTable:(data:any)=>void=null

    constructor(loadTable:(data:any)=>void){
        super();
        this.loadTable=loadTable;
    }

    public async logic(data:any):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{
            let result=new LogicResult();
            let loadTableFile=(callback,error)=>{
                ServerV1.gameClient.client.request(
                    {method:"GET",url:window["wxDownloader"].REMOTE_SERVER_ROOT+"/res/table.json",onDone:(data)=>{
                        console.log("loadTableFile",data);
                        callback(JSON.parse(data))
                    },onTimeout:()=>{
                        error("timeout")
                    },onError:()=>{
                        error("error")
                    }}
                )
            }
            if(window["wx"] && window["wxDownloader"].REMOTE_SERVER_ROOT){
                //微信下执行，必然读取服务器上的数据表
                let load=()=>{
                    loadTableFile((data)=>{
                        console.log("加载服务器数据表成功")
                        this.loadTable(data)//使用数据表
                        resolve(result);
                    },(err)=>{
                        console.log(err,"数据表加载失败")
                        core.showDialog(i18n.locString('network.error'),()=>{
                            load();
                        },{okText:"重试"})
                    })
                }
                load();
            }else{
                console.log("使用本地数据表")
                this.loadTable({})//使用默认表初始化    
                resolve(result);
            }
        })
    }
}