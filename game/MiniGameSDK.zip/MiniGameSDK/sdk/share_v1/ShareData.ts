import { SafeClass } from "../../core/SafeData";
import storage from "../../core/StorageCenter";
import Share from "./Share";
import core from "../../core/Core";


export enum ShareType{
    /**
     * 普通分享 以分享类型进行关联分组
     */
    NORMAL=0,
    /**
     * 以一天的某个时间点进行分组
     */
    DAY=1,
    /**
     * 从分享时，开始计时，一定时间内都用同一个分享组，该时间可以进行修改，以延长时间
     */
    TIME=2,
}


@SafeClass("ShareLog")
export class ShareLog{
    /**
     * 分享key
     */
    key:string = null
    /**
     * 分享类型
     */
    type:ShareType = ShareType.NORMAL
    hour?:number = 0
    duration?:number = 0

    /**
     * 最终使用的分享文件信息id
     */
    shareId:string = null
    
    /**
     * 最终的key
     */
    sign:string = null
    /**
     * 分享的地址
     */
    query:string = null
    /**
     * 分享的时间
     */
    time:number = 0

    /**
     * 分享的相关数据
     */
    info?:{openGId:string}

    isTimeOut(): boolean {
        if(this.type == ShareType.DAY){
            let sharetime = new Date(this.time)
            let endtime = sharetime
            if(sharetime.getHours() >= this.hour){
                endtime.setDate(sharetime.getDate()+1)
                endtime.setHours(this.hour,0,0,0)
            }else{
                endtime.setHours(this.hour,0,0,0)
            }

            return core.serverTime.getTime() > endtime.getTime()
        }
        return false
    }
}

@SafeClass("ShareData")
export class ShareData{
    shareList:ShareLog[]=[];
    groupMap:{}={};//保存已分享的群id

    /**
     * 获取存档中保存的实例
     */
    static get saved():ShareData{
        let data:ShareData=storage.getSavedData("shareData")
        if(!data){
            data=new ShareData()
            storage.setSavedData("shareData",data)
        }
        return data;
    }

    public getShareLog(key:string,type:ShareType):ShareLog{
        if(this.shareList){   
            let ret =  this.shareList.find((a)=>{
                return a.key == key && a.type == type
            })

            return ret
        }        
    }
}