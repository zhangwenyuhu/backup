import LogicChain, { LogicResult, LogicChainItem } from "../../core/LogicChain";
import ServerV1 from "../server_v1/ServerV1";
import { LoginData } from "../../data/LoginData";
import LogCommit, { LogPoint } from "../log_v1/LogCommit";

/**
 * 如果是点击分享的内容进来，则将该进来的用户关联到分享者
 */
export default class ShareRelation extends LogicChainItem{

    showdata:any = null
    constructor(showdata:any=null){
        super()
        this.showdata = showdata
    }

    public async logic(data:any):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{
            let reuslt=new LogicResult

            if (window['wx']) {
                let launch = this.showdata ? this.showdata : wx.getLaunchOptionsSync()
                console.log("分享关联")
                console.log(launch)
                let relationId,sign,type;
                if(launch.query.relationId && launch.query.sign){
                    relationId = launch.query.relationId;
                    sign = launch.query.sign;
                    type=launch.query.key;
                }else if(launch.query.scene){
                    let str = decodeURIComponent(launch.query.scene)
                    let reg = RegExp(/^relationId=(\d)+pyq$/)
                    console.log(str,reg.test(str));
                    if (reg.test(str)){
                        console.log(reg.exec(str));
                        let id = reg.exec(str)[1];
                        console.log(id,parseInt(id) ,id && parseInt(id));
                        if(id && parseInt(id)){
                            relationId = id;
                            sign = `${LoginData.saved.roleId}pyq`
                            type='9'
                            console.log(relationId,sign);
                        }
                    }else{
                        console.log("提交渠道日志");
                        LogCommit.instance.commit(LogPoint.SOURCE,{})
                    }
                }
                console.log(relationId,sign);
                if (relationId && sign) {
                    LogCommit.instance.commit(LogPoint.FENGXIANG_JIAZAI,{shareId:launch.query.sign,shareContentId:launch.query.shareID})
                    if(launch.shareTicket){
                        wx.getShareInfo({
                            shareTicket: launch.shareTicket, success: (res) => {
                                ServerV1.shareAddShareRelation({ shareUserId:relationId, sign: sign, userNew: LoginData.saved.isNew,sType:type.toString(),encryptedData:res.encryptedData,iv:res.iv,addSelf:launch.query.addSelf=="true"?1:0,wordId:parseInt(launch.query.shareID)}, (data) => {
                                    console.log(`addShareRelation：${data.message}`);
                                    // if(callback){
                                    //     callback(relationId,sign,type,data,launch.query.name);
                                    // }
                                })
                            }
                        })
                    }else{
                        ServerV1.shareAddShareRelation({ shareUserId:relationId, sign: sign, userNew: LoginData.saved.isNew,sType:type.toString(),wordId:launch.query.shareID,addSelf:launch.query.addSelf=="true"?1:0}, (data) => {
                            console.log("shareAddShareRelation:" + data.message)
    
                        })
                    }
                }
            }

            resolve(reuslt);
        })
    }
}