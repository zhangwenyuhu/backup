import { LogicChainItem, LogicResult } from "../../core/LogicChain";
import ServerV1 from "../server_v1/ServerV1";
import core from "../../core/Core";
import Share from "../share_v1/Share";

/**
 * 加载用于分享的数据，不必必须下载完成
 */
export default class ShareLoader extends LogicChainItem{
    public async logic(data:any):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{
            let result=new LogicResult();
            ServerV1.gameClient.client.request(
                {method:"GET",url:core.info.shareConfigUrl,onDone:(data)=>{
                    console.log("share","加载分享日志",data);
                    Share.instance.shareConfig=JSON.parse(data).shareContent;
                    if(window['wx']){
                        wx.showShareMenu({withShareTicket:true});
                        wx.onShareAppMessage(()=>{
                            let config = Share.instance.shareConfig[Math.floor(Share.instance.shareConfig.length * Math.random())]
                            return {title:config.shareContent,imageUrl:config.sharePicUrl}
                        })
                    }
                }}
            )
            //分享数据直接回调，不等待
            resolve(result);
        })
    }
}