import { Log } from "../../core/Log";
import { SafeClass } from "../../core/SafeData";
import core from "../../core/Core";
import { LoginData } from "../../data/LoginData";
import ServerV1 from "../server_v1/ServerV1";
import storage from "../../core/StorageCenter";
import { ShareType, ShareData, ShareLog } from "./ShareData";
import AccountServer from "../account/AccountServer";

var log=new Log({tags:["share"]});

export class ShareConfig{
    /**
     * 确定哪些分享key可以使用 "0"可用于任何分享
     */
    shareFrom:string

    /**
     * 分享的ID
     */
    shareID:string
    /**
     * 分享的图片
     */
    sharePicUrl:string
    /**
     * 分享的内容
     */
    shareContent:string
}


export default class Share{
    static instance=new Share;
    constructor(){

    }

    serverType:"ServerV1"|"AccountServer"="ServerV1"

    /**
     * 分享的列表
     */
    shareConfig:ShareConfig[]=null;

    /**
     * 生成分享数据结构
     * @param key 分享的分组ID
     * @param type 分享的类型
     * @param hour 当type==DAY时，用来表示分享签名失效的时间点。例如hour==5，则从5点到次日4:59期间，都只会使用一个分享key，以进行分组
     * @param duration 当type==TIME时，表示使用同一个key持续的时间。单位毫秒。
     */
    public createShareData(key:string,type:ShareType,config:ShareConfig,{hour,duration,addSelf,extData}:{hour?:number,duration?:number,addSelf?:boolean,extData?:string}={}):ShareLog{
        let data=new ShareLog();
        data.key=key;
        data.type=type;
        data.hour=hour;
        data.duration=duration;
        data.shareId=config.shareID;

        let serverTime=core.serverTime
        data.time=serverTime.getTime();

        if(type==ShareType.NORMAL){
            data.sign=key
        }else if(type==ShareType.DAY){
            //检查时间点判断是否过了今天
            let oldData=this.getShareLog(key,type)
            if(oldData){
                let endTime=new Date(oldData.time)
                if(endTime.getHours()>=oldData.hour){
                    //下一天 刷新
                    endTime.setDate(endTime.getDate()+1);
                    endTime.setHours(oldData.hour,0,0,0);
                }else{
                    //当前刷新
                    endTime.setHours(oldData.hour,0,0,0);
                }
                if(endTime.getTime()>serverTime.getTime()){
                    //重用原来的数据
                    return oldData;
                }
            }
            //创建新的
            data.sign=key+`${serverTime.getFullYear()}${serverTime.getMonth()+1}${serverTime.getDate()}`
        }else if(type==ShareType.TIME){
            //检查时间
            let oldData=this.getShareLog(key,type)
            if(oldData && oldData.time+oldData.duration>serverTime.getTime()){
                //重用原来的数据
                return oldData;
            }
            //创建新的
            data.sign=key+`${serverTime.getTime()}`
        }
        data.query=`key=${key}&type=${type}&relationId=${LoginData.saved.roleId}&sign=${data.sign}&shareID=${config.shareID}&addSelf=${addSelf||false}&extData=${extData}`

        return data;
    }

    public getShareConfigBy(shareId:string){
        let config = this.shareConfig.find((a)=>{
            return a.shareID == shareId
        })
        return config
    }

    public getShareConfigByLog(log:ShareLog): ShareConfig{
        return this.getShareConfigBy(log.shareId)
    }
    /**
     * 发起分享
     * @param key 分享的分组ID
     * @param type 分享的类型
     * ### 扩展参数
     * * hour 当type==DAY时，用来表示分享签名失效的时间点。例如hour==5，则从5点到次日4:59期间，都只会使用一个分享key，以进行分组
     * * duration 当type==TIME时，表示使用同一个key持续的时间。单位毫秒。
     * * mustGroup 必须为分享对群，如果设置为true，只有分享到群才会回调
     * * addSelf 是否允许添加自己
     * * extData 扩展数据，会传入分享数据的query中
     */
    public share(key:string,type:ShareType,{hour,duration,mustGroup,addSelf,extData}:{hour?:number,duration?:number,mustGroup?:boolean,mustDifferentGroup?:boolean,addSelf?:boolean,extData?:string}={},success?:(isGroup:boolean,log:ShareLog)=>void,fail?:(data?:any)=>void){
        let configList=this.shareConfig.where(a=>a.shareFrom==key);        
        configList=configList.length>0?configList:this.shareConfig.where(a=>a.shareFrom=="0");
        let config=configList[Math.floor(configList.length*Math.random())]

        let data=this.createShareData(key,type,config,{hour,duration,addSelf,extData});

        log.info("发起分享",data);
        if(window["wx"]==null){
            fail("非微信环境")
            return;
        }
        wx.shareAppMessage({title:config.shareContent, imageUrl:config.sharePicUrl, query:data.query, success:(res)=>{
            let isGroup=res.shareTickets && res.shareTickets.length>0;
            if (!mustGroup||mustGroup&&isGroup){
                this.setShareLog(data);//记录日志
                if(isGroup){
                    let ticketId = res.shareTickets[0];
                    wx.getShareInfo({
                        shareTicket: ticketId, success: (res) => {
                            this.wxDecrypt({
                                encryptedData: res.encryptedData,
                                iv: res.iv,
                            }, (dd) => {
                                console.log('分享回来解密后数据:', dd)
                                if (dd.succeed) {
                                    let destr = dd.data
                                    let groupInfo = destr != "" ? JSON.parse(destr) : null;
                                    data.info=groupInfo
                                    if(success){
                                        success(isGroup,data)
                                    }
                                    ShareData.saved.groupMap[data.info.openGId]=true
                                } else {
                                    wx.showToast({ title: '服务器错误' });
                                    if(success){
                                        success(isGroup,data)
                                    }
                                }
                            }, false, (err, retry) => {
                                wx.showToast({ title: '服务器错误' });
                                if(success){
                                    success(isGroup,data)
                                }
                            })
                        }
                    })
                }else{
                    if(success){
                        success(isGroup,data)
                    }
                }
            }else if(mustGroup && !isGroup){
                log.warn("没有分享到群",data)
                if(fail)
                    fail("没有分享到群")
            }
        },fail:()=>{
            log.info("分享取消",data);
            if(fail)
                fail();
        }});
    }

    /**
     * 获取分享日志
     */
    public getShareLog(key:string,type:ShareType):ShareLog{
        return ShareData.saved.shareList.find(a=>a.key==key&&a.type==type);
    }

    /**
     * 添加、替换现有的分享日志
     */
    public setShareLog(log:ShareLog){
        let list=ShareData.saved.shareList;
        list.remove(list.where(a=>a.key==log.key && a.type==log.type))
        list.push(log);
    }

    protected wxDecrypt(
        data:{
        encryptedData:string,
        iv:string,
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data: string, // 解密后数据
        })=>void,
        modal:boolean=true,
        errorCallback:(error:any,retry:()=>void)=>void=null
    ){
        if(this.serverType=="ServerV1"){
            ServerV1.wxDecrypt(data,callback,modal,errorCallback);
        }else if(this.serverType=="AccountServer"){
            AccountServer.wxDecrypt(data,callback,modal,errorCallback);
        }
    }

    protected getShareRelationList(
        data:{
            sign:string,
            size:number,
            onlyNew:number
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:{
                shareRelations:{
                    userId:number,
                    relationId:number,
                    sign:string,
                    nickname:string,
                    profileImg:string,
                    joinTimestamp:string,
                    userNew:boolean,
                }[]
            }
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null
    ){
        if(this.serverType=="ServerV1"){
            ServerV1.shareGetShareRelationList(data,callback,modal,errorCallback);
        }else if(this.serverType=="AccountServer"){
            AccountServer.getShareRelationList(data,callback,modal,errorCallback);
        }
    }

    /**
     * 根据分享日志获取分享列表
     * @param shareLog 分享日志
     * @param size 列表长度
     * @param onlyNew 是否只需要新玩家
     * @param callback 回调
     * @param showBlockLayer 是否显示遮挡层 
     */
    public getRelationList(shareLog:ShareLog,size:number,onlyNew:boolean,callback:(list:{
        userId:number,
        relationId:number,
        sign:string,
        nickname:string,
        profileImg:string,
        joinTimestamp:string,
        userNew:boolean,
    }[])=>void,showBlockLayer:boolean=true){
        log.info("获取关联列表",shareLog)
        this.getShareRelationList({sign:shareLog.sign, size:size, onlyNew:onlyNew?1:0}, (data)=>{
            let list=data.data.shareRelations
            log.info("分享列表",list,list.length)
            callback(list);
        }, showBlockLayer)
    }

}