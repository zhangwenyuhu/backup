import { LogicChainItem, LogicResult } from "../../core/LogicChain";
import ServerV1 from "../server_v1/ServerV1";
import core from "../../core/Core";

/**
 * 同步服务器的时间
 */
export default class SyncServerTime extends LogicChainItem{
    public async logic(data:any):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{
            let result=new LogicResult();
            ServerV1.gameGetSystemTime({}, res => {
                core.serverTimeOffset = res.data - new Date().getTime();
                resolve(result);
            });
        });
    }
}