import LocalStorage from "../../core/LocalStorage";
import storage from "../../core/StorageCenter";
import ServerV1 from "./ServerV1";
import core from "../../core/Core";
import log from "../../core/Log";

class AutoDataBackup{
	static timerid=null
	static currentBackupTime:number=300

	static rescheduleBackup(){
		this.onStartBackup(this.currentBackupTime)
	}

	static onStartBackup(backupTime:number){
		if((typeof backupTime !='number') || (backupTime==NaN)){
			backupTime=301*1000
		}else{
			backupTime*=1000
		}
		let backupTimeMin=1*1000
		if(backupTime<backupTimeMin){
			backupTime=backupTimeMin
		}
		let backupTimeMax=1000000000
		if(backupTime>backupTimeMax){
			log.warn('备份时间过大,会导致timeout立即执行')
			log.error('备份时间过大,会导致timeout立即执行')
			backupTime=24*3600*1000
		}
		console.log('AutoDataBackup.onStartBackup:',backupTime)

		this.currentBackupTime=backupTime/1000

		if(this.timerid){
			clearTimeout(this.timerid)
			this.timerid=null
		}
		this.timerid=setTimeout(()=>{
			let localData=LocalStorage.getItem(storage.storageKey,false) || ''
			if(this.timerid){
				clearTimeout(this.timerid)
				this.timerid=null
			}
			this.timerid=setTimeout(()=>{
				this.onStartBackup(backupTime/1000)
			},backupTime)
			
			console.log('ServerV1.backupSave')
			ServerV1.backupSave({
				secretKey:LocalStorage.encryptKey,
				timestamp:core.serverTime.getTime().toString(),
				backupData:localData,
				especially:0,
			},(data)=>{
				if (data.succeed) {
					this.onStartBackup(data.data)
				}else{
					this.onStartBackup(backupTime/1000)
				}
			},false,(err,retry)=>{
				//捕获错误
				console.log("备份存档失败")
			})
		},backupTime)
	}
	
	/**
	 * 立即上传存档至服务器
	 * * 注意，这里是从本地存储中读取的存档。因此可能由于自动存档的时间间隔而产生存档的误差，如果需要保证存档的及时性，应该先调用storage.saveToLocalStorage()
	 */
	static backup(){
		let localData=LocalStorage.getItem(storage.storageKey,false) || ''
		console.log('start ServerV1.backupSave')
		ServerV1.backupSave({
			secretKey:LocalStorage.encryptKey,
			timestamp:core.serverTime.getTime().toString(),
			backupData:localData,
			especially:1,
		},(data)=>{
			console.warn("主动备份存档成功")
			AutoDataBackup.rescheduleBackup()
		},false,(err,retry)=>{
			//捕获错误
			console.error("主动备份存档失败")
		})
	}
}

export default AutoDataBackup
