import HttpGameClient from "../../net/HttpGameClient";
import core from "../../core/Core";
import { ConsumeLog } from "../../data/ConsumeLog";
import { LoginData } from "../../data/LoginData";

export enum OrderState{
    fail=2,
    ok=1,
    unknown=0,
}

// 订单信息
export type OrderInfoRaw={
    id:string //订单id
    userId:string //用户id
    quantity :number //扣款金额
    title :string //标题
    outTradeNo :string //订单号,以此为准
    goodsId :number //商品id
    state :number //状态(0:失败,1:成功,2:未知)
    time:number //订单生成时间
}

// 订单信息
export type OrderInfo={
    outTradeNo :string //订单号,以此为准,例如: "20002_1_1530164811210"
	state :OrderState //状态(0:未知,1:成功,2:失败)
	goodsId :number //商品id
	time:number //订单生成时间
}

export default class ServerV1{
    static readonly gameClient:HttpGameClient=new HttpGameClient();

    /**
     * 用户登录接口(用户首次进入游戏调用)
     */
    static loginTest(
        data:{
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:{
                userId:number,
                openId?:string,
                serviceTimestamp:number
                dataTimestamp:number//上次存档的时间戳
                nickname:string,
                profileImg:string,
                backupTime:number,//上传存档时间 秒
                userNew:false,//是否为新用户
                shareSwitch:{
                    
                },
                gameCurrency:{
                    gold: string,
                    diamond: string,
                    seed: string        
                },
                createTime: string,//创建时间
                channelId: number//渠道id

                encryptKey:string,//存档加密key
                token:string,//登陆token 

            }
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request("user/loginTest",data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    /**
     * 用户登录接口(用户首次进入游戏调用)
     */
    static userLogin(
        data:{
            code:string,
            system:number,//系统类型  0:android  1:ios
            launchOptionsQuery?:any,//启动参数query 
            launchOptionsPath?:any, //启动参数path
            channelId?:number;//渠道id
            clientSystemInfo:any;//系统信息
            extraData?:any;//扩展数据
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:{
                userId:number,
                openId?:string,
                serviceTimestamp:number
                dataTimestamp:number//上次存档的时间戳
                nickname:string,
                profileImg:string,
                backupTime:number//上传存档时间 秒
                userNew:false,//是否为新用户
                shareSwitch:{
                   
                },
                gameCurrency:{
                    gold: string,
                    diamond: string,
                    seed: string        
                },
                createTime: string,//创建时间
                channelId: number,//渠道id

                encryptKey:string,//存档加密key
                token:string,//登陆token
            }
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request("user/login",data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    /**
     * 用户信息接口
     */
    static userGetUserInfo(
        data:{
            userId:string
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:{
                userId:number,
                openId?:string,
                serviceTimestamp:number
                dataTimestamp:number//上次存档的时间戳
                nickname:string,
                profileImg:string,
                backupTime:number,//上传存档时间 秒

                shareSwitch:{
  
                },
                gameCurrency:{
                    gold: string,
                    diamond: string,
                    seed: string        
                },
                createTime: string,//创建时间
                channelId: number//渠道id

                encryptKey:string,//存档加密key
                token:string,//登陆token getUserInfo 接口下可能拿不到

            }
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request("user/getUserInfo",data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    /**
     * 保存用户信息
     */
    static userSaveUserInfo(
        data:{
            userId:string,
            nickName:string,
            headImgUrl:string,
            iv?:any,
            encryptedData?:any,
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request("user/saveUserInfo",data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    /**
     * 保存游戏数据
     */
    static backupSave(
        data:{
            secretKey:string,
            timestamp:string,
            backupData:string,
            especially:number, // 0默认间隔5分钟,1无间隔
            diamondLog?:string, //统计数据
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data?:number//刷新提交的间隔时间，如果有
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            data.diamondLog=ConsumeLog.saved.getRecords()
            console.error('正在备份')
            this.gameClient.request("backup/save",data,(data)=>{
                if(data.succeed){
                    ConsumeLog.saved.clearRecords()
                }
                callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    //获取用户保存的最近一条游戏备份
    static backupGetBackup(
        data:{
            userId:number
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:{backupData:string,secretKey:string,timestamp:number}//最新保存的数据
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request("backup/getBackup",data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    //分享关联用户接口
    static shareAddShareRelation(
        data:{
            shareUserId:string,
            sign:string,
            userNew:boolean,
            sType?:any,
            wordId:any,
            iv?:any,
            addSelf:any,
            encryptedData?:any
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request("share/addShareRelation",data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    //分享关联用户列表接口
    static shareGetShareRelationList(
        data:{
            sign:string,
            size:number,
            onlyNew:number
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:{
                shareRelations:{
                    userId:number,
                    relationId:number,
                    sign:string,
                    nickname:string,
                    profileImg:string,
                    joinTimestamp:string,
                    userNew:boolean,
                }[]
            }
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
        this.gameClient.request("share/getShareRelationList",data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    //获取服务器时间
    static gameGetSystemTime(
        data:{},
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:number//服务器时间
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request("game/getSystemTime",data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    //获取是否需要强更
    
    static checkForceUpdate(
        data:{
            version:string,
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:{
                needUpdate:boolean,
                newVersion:number,
            }
        })=>void,modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request("version",data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }
    
    
    static getWxErCode(
        data:{
            scene:string,
        },
        callback:(data:any)=>void,modal:boolean=false,errorCallback:(err:any,retry:()=>void)=>void=null){
            this.gameClient.request("/wxcode/bindingWxErCode",data,(data)=>{
                callback(data);
            },{modal:modal,errorCallback:errorCallback})
    }

    static getPromotionList(
        data:{
            
        },
        callback:(data:any)=>void,modal:boolean=false,errorCallback:(err:any,retry:()=>void)=>void=null){
            this.gameClient.request("/game/getPromotionList",data,(data)=>{
                callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }
    
    // 检查订单扣款状态
    static orderCheckWxOrderState(
        data:{
            // quantity:number,//消费金额
            // goodsId:number,//商品id
            // title:string,//商品名称
            // state:2|1|0,//0未知 1成功 2失败
            // errCode?:number,//错误码
            outTradeNo:string//客户端自己形成的唯一订单标识
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data:0|1//0未充值 1已充值
        })=>void,modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
        
        this.gameClient.request("order/synchronizeWxOrder",data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    // 请求服务器生成订单
    static orderGenWxOrder(
        data:{
            quantity:number,//消费金额
            goodsId:number,//商品id
            title:string,//商品标题
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data: OrderInfo, //订单信息
        })=>void,
        modal:boolean=false,
        errorCallback:(error:any,retry:()=>void)=>void=null
    ){
        this.gameClient.request("order/createWxOrder",data,(data)=>{
            if(data.succeed && (data.data instanceof Object)){
                data.data.time=data.data.createTime
            }
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    // 请求历史差异订单
    static orderReqDiffOrderList(
        data:{
            /*
             * 历史订单检查点时间
             *  如果为0,则返回全部历史订单
             *  如果不为0,则返回该时间点之后的所有历史订单
             */
            time:number,
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data: OrderInfoRaw[], // 历史订单列表
        })=>void,
        modal:boolean=false,
        errorCallback:(error:any,retry:()=>void)=>void=null
    ){
        this.gameClient.request("order/getWxOrderList",data,(data)=>{
            // if(wdebug){
            //     data.data=[
            //         {createTime:1530360114000,goodsId:9,id:null,outTradeNo:"20002_209_1530360114388",quantity:1,state:1,time:1530360114000,title:"com.farm.p60",userId:209}
            //     ]
            // }
            if(data.succeed && (data.data instanceof Array)){
                for(let info of data.data){
                    info.time=info.createTime
                }
            }
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }
    // 微信解密
    static wxDecrypt(
        data:{
            encryptedData:string,
            iv:string,
        },
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            data: string, // 解密后数据
        })=>void,
        modal:boolean=true,
        errorCallback:(error:any,retry:()=>void)=>void=null
    ){
        this.gameClient.request("wxcode/wxDecrypt",data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    static wxAuth(cb:Function){
        if(!window["wx"]){
            return cb && cb()
        }
        
        wx.getUserInfo({
            openIdList: ["selfOpenId"],
            lang: 'zh_CN',
            success: (res) => {
                console.log("用户授权", res)
                LoginData.saved.isAuthorize = true;
                let roleRes: any = res;
                let roleData: wx.UserInfo = res.userInfo;

                if (roleData) {
                    LoginData.saved.nickName = roleData.nickName
                    LoginData.saved.avatarUrl = roleData.avatarUrl
                }

                if (roleData) {
                    ServerV1.userSaveUserInfo({
                        userId: String(LoginData.saved.roleId),
                        headImgUrl: roleData.avatarUrl,
                        nickName: roleData.nickName,
                        iv:roleRes.iv,
                        encryptedData:roleRes.encryptedData
                    }, res => {
                        console.log("提交用户信息 succeed=", res.succeed)
                    })
                }
                if(cb) cb()

            },
            fail: (res) => {
                console.error("用户拒绝授权", res)
                if(cb) cb()
            }
        })
    }
}

ServerV1.gameClient.searchExt=()=>{
    return `?v=${core.info.version}&resv=${core.info.resVersion}`
}
