import core from "../../core/Core";
import { LoginData } from "../../data/LoginData";
import ServerV1 from "../server_v1/ServerV1";
import { ShareLog } from "../share_v1/ShareData";
import Share, { ShareConfig } from "../share_v1/Share";

export enum LogPoint {
    FENGXIANG_JIAZAI = 0,//	载入页	入口ID，分享ID，分享内容ID
    ERROR = 1024,//异常
    SOURCE = 1025,//渠道
    SIZE = 1026,//用户本地文件大小
    LOGIN = 2001,//点击减少拖拉机CD时间邀请 ID，分享ID，分享内容ID
}

export default class LogCommit{
    static readonly instance:LogCommit=new LogCommit
    constructor(){

    }

    /**
     * 用户构建日志所传递的属性
     */
    applyLog:(data:any)=>void;

    /**
     * 提交日志打点
     */
    commit(point: LogPoint | number, data: { shareId?: string, shareContentId?: string } | any) {

        if ((!core.info.logUrl) || (core.info.logUrl == "")) {
            console.log("commitLog in dev", point,data);
            return
        }
        data["userId"] = LoginData.saved.roleId//用户ID
        data["version"] = core.info.version
        data["resVersion"] = core.info.resVersion
        data["model"] = core.info.mode
        if (window['wx'])
            data["systemInfo"] = wx.getSystemInfoSync()//所有系统信息

        data["createTime"] = LoginData.saved.createTime//账号创建信息
        data["channelId"] = LoginData.saved.channelId //系统渠道信息

        if(this.applyLog){
            this.applyLog(data);
        }

        ServerV1.gameClient.client.request(
            {
                method: "POST", url: core.info.logUrl,headMap:{"Content-Type":"application/json;charset=utf-8"}, data: JSON.stringify({ point: point, data: data, t: core.serverTime.getTime() }), onDone: (data) => {
                    console.log("commitLog", data);
                }
            }
        )
    }

    commitShareLog(point: LogPoint | number,log:ShareLog){
        if (log){
            let cfg:ShareConfig = Share.instance.getShareConfigByLog(log)
            this.commit(point,{shareId:cfg.shareID,shareContentId:cfg.shareContent,sign:log.sign})
        }
    }
}
