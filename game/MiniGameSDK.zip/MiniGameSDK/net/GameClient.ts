export default abstract class GameClient{
    
    protected _protocol:string="https"//协议
    protected _host:string="localhost"//主机名
    protected _port:number=443//端口号

    protected _messageCallback:Function
    protected _errorCallback:(error:any,retry:()=>void)=>void;
    protected _disconnectCallback:Function

    protected _sslHandShakeErrorCallBack:(index:number,url:string)=>void=null;  //客户端时间不对导致握手错误

    protected _showLoadingModalCallback:(index:number,url:string)=>void=null;//显示模态化遮挡层
    protected _closeLoadingModalCallback:(index:number,url:string)=>void=null;//隐藏模态遮挡层

    constructor() {

    }

    /**
     * 发起连接，如果已经连接将重新连接
     */
    abstract connect();

    /**
     * 发起对服务器的请求
     */
    abstract request(action,data,callback);

    /**
     * 设置服务器推送的消息回调
     */
    setMessageCallback(callback){
        this._messageCallback=callback
    }

    /**
     * 当发生错误时的统一回调
     */
    setErrorCallback(callback:(error:any,retry:()=>void)=>void){
        this._errorCallback=callback;
    }

    /**
     * 设置断开连接回调
     */
    setDisconnectCallback(callback){
        this._disconnectCallback=callback;
    }

    get host(){
        return this._host
    }

    set host(value){
        this._host=value
    }

    get port(){
        return this._port
    }

    set port(value){
        this._port=value
    }

    get protocol(){
        return this._protocol
    }

    set protocol(value){
        this._protocol=value
    }

    set url(value:string){
        let sp=value.split(/:\/\/|:/g)
        this._protocol=sp[0]
        this._host=sp[1]
        this._port=parseInt(sp[2])
        if(this._port==null || isNaN(this._port)){
            if(this._protocol=="http"){
                this._port=80
            }else if(this._protocol=="https"){
                this._port=443
            }else if(this._protocol=="ws"){
                this._port=80
            }else if(this._protocol=="wss"){
                this._port=443
            }
        }
    }

    get url():string{
        return `${this._protocol}://${this._host}:${this._port}`
    }

    public set showModalCallback(callback:(index:number,url:string)=>void){
        this._showLoadingModalCallback=callback;
    }

    public set closeModalCallback(callback:(index:number,url:string)=>void){
        this._closeLoadingModalCallback=callback;
    }

    public set sslHandShakeErrorCallBack(callback:(index:number,url:string)=>void){
        this._sslHandShakeErrorCallBack = callback;
    }

    public get showModalCallback(){
        return this._showLoadingModalCallback;
    }

    public get closeModalCallback(){
        return this._closeLoadingModalCallback;
    }

    public get sslHandShakeErrorCallBack(){
        return this._sslHandShakeErrorCallBack;
    }


}