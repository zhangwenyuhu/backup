import HttpClient from "./HttpClient";
import GameClient from "./GameClient";
import { Log } from "../core/Log";

type ResponseData={index:number,code:string,success:boolean,data:any}
type RequestData={index:number,code:string,data:any}
type RequestInfo={
    index:number,
    code:string,
    callback:(msg:object,netDelay:number) => void,
    modal:boolean,
    time:number
}

let log:Log=new Log({tags:["SocketClient"]})
export default class SocketGameClient extends GameClient{
    protected _client:WebSocket
    protected _requestIndex=0;
    protected _connected: boolean = false;
    protected _connecting: boolean = false;

    protected _callIndex:number=0;
    protected _serverCallbackList:Array<RequestInfo> =[]//等待服务器回调的请求

    protected _connectCallback:()=>void=null;//连接成功回调

    protected _heartbeatIntervalHandler:any=null;
    protected _heartbeatInterval:number=5000;//心跳时间间隔
    protected _receiveHeartbeat:boolean=true;//是否已经收到心跳数据

    protected _messageTime:number=0;//最近一次收到数据的时间

    constructor(){
        super()
    }

    connect(callback:()=>void=null){
        if (this._connecting || this._connected)
        return;

        this._client = new WebSocket(`${this._protocol}://${this._host}:${this._port}`);

        this._client.onopen = (ev: Event)=>{ this.onOpenHandler(ev)};
        this._client.onclose =(ev: CloseEvent)=>{ this.onCloseHandler(ev)};
        this._client.onmessage =(ev: MessageEvent)=>{ this.onMessageHandler(ev)};
        this._client.onerror =(ev: Event)=>{ this.onErrorHandler(ev)};

        this._connecting = true;
        this._serverCallbackList=[];//清空请求列表

        this._connectCallback=callback;
    }

    protected startHeartbeat(){
        if(this._heartbeatIntervalHandler!==null){
            return;
        }
        this._receiveHeartbeat=true;
        this._heartbeatIntervalHandler=setInterval(()=>{
            
            if(this._receiveHeartbeat==false){
                log.error("心跳没了");
                this.stopHeartbeat();
                this._client.close();
            }

            //当间隔内收到过网络数据，则不发送心跳。降低心跳数量。
            if(this._messageTime+this._heartbeatInterval <= new Date().getTime() ){
                this._client.send("HB");
                this._receiveHeartbeat=false;
                log.warn("发送心跳")
            }

        },this._heartbeatInterval);
    }
    protected stopHeartbeat(){
        clearInterval(this._heartbeatIntervalHandler)
        this._heartbeatIntervalHandler=null;
    }

    public onOpenHandler(ev: Event): any {
        this._connecting = false;
        this._connected = true;

        if(this._connectCallback){
            this._connectCallback();
        }

        this.startHeartbeat();
    }

    public onCloseHandler(ev: CloseEvent): any {
        this._connected = false;
        this._connecting = false;

        //由于已经断开，所有请求都会失效，因此模态都要隐藏掉
        for (var i = 0; i < this._serverCallbackList.length; i++) {
            var call = this._serverCallbackList[i];
            if(call.modal && this._closeLoadingModalCallback){
                this._closeLoadingModalCallback(call.index,call.code)
            }
        }

        this._client=null;

        //前端应该弹出提示框，让玩家重连等
        if(this._disconnectCallback)
            this._disconnectCallback()

        this.stopHeartbeat();
    }

    public onMessageHandler(ev: MessageEvent): any {

        this._messageTime=new Date().getTime();

        var bytes = ev.data as string
        if(bytes=="HB"){
            this._receiveHeartbeat=true;
            log.warn("收到心跳")
            return;
        }

        log.warn("收到数据",bytes)
        
        let sp1=bytes.indexOf(" ")
        let sp2=bytes.indexOf(" ",sp1+1)
        let type=bytes.substr(0,sp1)
        let action=bytes.substr(sp1+1,sp2-sp1-1)
        let data=bytes.substr(sp2+1)
        
        if(type=='1'){
            //调用的回调
            let sp=JSON.parse(data) as ResponseData
            for (var i = 0; i < this._serverCallbackList.length; i++) {
                var callback = this._serverCallbackList[i];
                let netDelay=new Date().getTime()-callback.time
                log.warn(callback.code,"延迟",netDelay)
                if(callback.index==sp.index){
                    try{
                        callback.callback(sp,netDelay);
                    }catch(e){
                        log.error(e)
                    }
                    this._serverCallbackList.splice(i,1);

                    if(callback.modal && this._closeLoadingModalCallback){
                        this._closeLoadingModalCallback(sp.index,sp.code)
                    }

                    break;
                }
            }
            
        }else if(type=='2'){
            //服务器通知
            this._messageCallback(action,JSON.parse(data));
        }else{
            log.error("未知的数据格式",bytes)
        }

    }


    public onErrorHandler(ev: Event): any {
        this._connected = false;
        this._connecting = false;

        //由于已经断开，所有请求都会失效，因此模态都要隐藏掉
        for (var i = 0; i < this._serverCallbackList.length; i++) {
            var call = this._serverCallbackList[i];
            if(call.modal && this._closeLoadingModalCallback){
                this._closeLoadingModalCallback(call.index,call.code)
            }
        }
        
        this._client=null;

        if(this._errorCallback)
            this._errorCallback(ev,null);
        
        this.stopHeartbeat();
    }

    public get connected(): boolean {
        return this._connected;
    }

    public get connecting(): boolean {
        return this._connecting;
    }

    request(action:string,data:any,callback:(data:ResponseData)=>void,modal:boolean=false){
        cc.assert(this._connected,"必须在连接状态才能发送请求")

        this._requestIndex++;//每次请求拥有新的id
        var requestData:RequestData={
            index:this._requestIndex,
            code:action,
            data:data
        }
        let pack=`${action} ${JSON.stringify(requestData)}`
        let info={
            index:requestData.index,
            code:action,
            callback:callback,
            modal:modal,
            time:new Date().getTime()//发起请求的时间
        }
        this._serverCallbackList.push(info)

        if(modal && this._showLoadingModalCallback){
            this._showLoadingModalCallback(requestData.index,action)
        }

        log.warn("请求数据",pack)
        this._client.send(pack);
    }

    close(){
        //断开现有连接
        this.stopHeartbeat();
        if(this._client){
            try{
                this._client.close();
            }catch{}
            this._client=null
        }
        this._connected=false
        this._connecting=false
    }

}