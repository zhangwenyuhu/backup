import HttpClient from "./HttpClient";
import GameClient from "./GameClient";
import { Log } from "../core/Log";
import core from "../core/Core";
import { LoginData } from "../data/LoginData";

type ResponseData={succeed:boolean,code:0|number,message:"success"|string,data:any}
type RequestData={appId:any,role:any,index:number,retry:number,time?:any,data:any}

let log:Log=new Log({tags:["HttpClient"]})
export default class HttpGameClient extends GameClient{
    protected _client:HttpClient=new HttpClient()
    protected _requestIndex=0;
    protected _retryCount:number=3;
    
    public searchExt:()=>string;

    /**
     * ##是否开启签名
     * ###当开启后，将自动组合token+数据，生成md5
     */
    public signature:boolean=false;

    constructor(){
        super()
    }

    connect(){
        //http 不需要连接
    }

    /**
     * 获取客户端的时间，如果返回空，则不会传输
     */
    public getTime:()=>number=()=>{
        return null;
    }

    /**
     * 获取token对外接口
     */
    public getToken:()=>string=()=>{
        return LoginData.saved.token
    }

    /**
     * 对外接口 获取账号服返回的gametoken
     */
    public getGameToken:()=>string=()=>{
        return LoginData.saved.gameToken
    }

    /**
     * 获取openId
     */
    public getOpenId:()=>string=()=>{
        return LoginData.saved.openId;
    }

    /**
     * 获取roleId对外接口
     */
    public getRoleId:()=>string=()=>{
        return LoginData.saved.roleId
    }

    /**
     * 获取appid
     */
    public getAppId:()=>string=()=>{
        return core.info.appId
    }


    /**
     * 发起服务器请求
     * @param action 请求的相对url
     * @param data 请求的数据
     * @param callback 请求的回调
     * ### 扩展数据
     * * modal 是否模态窗口
     * * downloadProgress 下载进度
     * * uploadProgress 上传进度
     * * errorCallback 错误回调 这里可以拿到retry函数
     */
    request(action,data,callback:(data:ResponseData)=>void,
        {modal,downloadProgress,uploadProgress,errorCallback}:{
            modal?:boolean,
            downloadProgress?:(loaded:number,total:number)=>void,
            uploadProgress?:(loaded:number,total:number)=>void,
            errorCallback?:(error:any,retry:()=>void)=>void}={}
    ){
        this._requestIndex++;//每次请求拥有新的id
        var requestData:RequestData={
            appId:core.info.appId,
            role:this.getRoleId(),//请求用户
            // token:this._token,//token
            index:this._requestIndex,//请求索引
            retry:0,//是否重试
            data:data
        }
        let time=this.getTime()
        if(time!=null){
            requestData.time=time;
        }

        this.requestFromData(action,requestData,callback,{modal,downloadProgress,uploadProgress,errorCallback});
    }

    protected requestFromData(action,requestData:RequestData,callback:(data:ResponseData)=>void,
        {modal,downloadProgress,uploadProgress,errorCallback}:{modal?:boolean,downloadProgress?:(loaded:number,total:number)=>void,uploadProgress?:(loaded:number,total:number)=>void,errorCallback?:(error:any,retry:()=>void)=>void}={},
        isRetry=false,modalIndex=-1
    ){

        let data=JSON.stringify(requestData)
        log.warn("request",action,data);

        let search=this.searchExt?this.searchExt():"";

        let url:string
        if(this._protocol=="https" && this._port==443){
            url=`${this._protocol}://${this._host}/${action}${search}`
        }else if(this._protocol=="http" && this._port==80){
            url=`${this._protocol}://${this._host}/${action}${search}`
        }else{
            url=`${this._protocol}://${this._host}:${this._port}/${action}${search}`
        }

        let index=modalIndex==-1?core.loadingIndex:modalIndex
        //重试不重复打开模态
        if(!isRetry && modal && this._showLoadingModalCallback){
            this._showLoadingModalCallback(index,action);
        }

        let token=this.getToken()

        let headMap:any={}
        headMap["Content-Type"]="application/json;charset=utf-8"
        if(token){
            headMap["token"]=token
        }
        if(this.getRoleId&&this.getRoleId()){
            headMap["role"]=this.getRoleId()
        }
        if(this.getOpenId&&this.getOpenId()){
            headMap["openId"]=this.getOpenId()
        }
        if(this.getAppId&&this.getAppId()){
            headMap["appId"]=this.getAppId()
        }

        if(this.getGameToken && this.getGameToken()){
            headMap["Authorization"]="Bearer "+this.getGameToken();
        }

        if(this.signature){
            //进行数据签名
            let sign=data
            if(token!=null){
                sign=token.substr(token.length/2)+data
            }
            sign=MD5.hex(sign);
            headMap["sign"]=sign;
            console.log("sign",sign)
        }

        this._client.request({
            method:"POST",
            url:url,
            data:data,
            headMap:headMap,
            onDone:(data)=>{
                //进行回调
                if(typeof(data)=='string' && data.length>4000){
                    log.warn("response",action,data.substr(0,4000))
                }else{
                    log.warn("response",action,data);
                }

                let newData=JSON.parse(data);
                if(newData.ok!=undefined){
                    callback({succeed:newData.ok,code:newData.c,message:newData.m,data:newData.r});
                }else{
                    callback(newData);
                }

                if(modal && this._closeLoadingModalCallback){
                    this._closeLoadingModalCallback(index,action);
                }
            },
            onError:(error)=>{

                let retry=()=>{
                    //重试函数
                    if(modal){
                        this._showLoadingModalCallback(index,action);
                    }
                    requestData.retry++
                    this.requestFromData(action,requestData,callback,{modal:modal,downloadProgress:downloadProgress,uploadProgress:uploadProgress},true,index);
                }

                if(requestData.retry>this._retryCount){
                    //多次请求无果

                    if(errorCallback){
                        errorCallback(error,retry);//当请求捕获错误时，则不进行全局错误回调
                    }else if(this._errorCallback){
                        this._errorCallback(error,retry)
                    }
                    if(modal && this._closeLoadingModalCallback){
                        this._closeLoadingModalCallback(index,action);
                    }    
                    log.error("多次请求无果");
                }else{
                    requestData.retry++
                    this.requestFromData(action,requestData,callback,{modal:modal,downloadProgress:downloadProgress,uploadProgress:uploadProgress},true,index);
                }
                log.error(error);
                if(requestData.retry > this._retryCount && ((error as string).indexOf('ssl hand shake error') != -1 || (error as string).indexOf('证书无效') != -1)){
                    if(this._sslHandShakeErrorCallBack){
                        this._sslHandShakeErrorCallBack(index,action)
                    }
                }
            },
            onTimeout:()=>{
                //超时进行重试

                let retry=()=>{
                    //重试函数
                    if(modal){
                        this._showLoadingModalCallback(index,action);
                    }
                    requestData.retry++
                    this.requestFromData(action,requestData,callback,{modal:modal,downloadProgress:downloadProgress,uploadProgress:uploadProgress},true,index);
                }

                if(requestData.retry>this._retryCount){
                    //多次请求无果
                    if(errorCallback){
                        errorCallback("timeout",retry);//当请求捕获错误时，则不进行全局错误回调
                    }else if(this._errorCallback){
                        this._errorCallback("timeout",retry)
                    }
                    if(modal && this._closeLoadingModalCallback){
                        this._closeLoadingModalCallback(index,action);
                    }    
                    log.error("多次请求无果");
                }else{
                    requestData.retry++
                    this.requestFromData(action,requestData,callback,{modal:modal,downloadProgress:downloadProgress,uploadProgress:uploadProgress},true,index);
                }
            },
            onProgress:(loaded:number,total:number)=>{
                if(downloadProgress){
                    downloadProgress(loaded,total)
                }
            },
            onUploadProgress:(loaded:number,total:number)=>{
                if(uploadProgress){
                    uploadProgress(loaded,total)
                }
            }
        })
    }

    get retryCount(){
        return this._retryCount
    }
    set retryCount(value){
        this._retryCount=value
    }

    get client(){
        return this._client;
    }
}