/**
 * * 用于帧同步逻辑的实现。服务器下发一个随机数作为种子。
 * * 客户端对种子计算得到固定的随机数序列
 */
export default class SeedRandom{
    min:number=0
    max:number=1000000
    seed:number;//当前的种子
    constructor(startSeed){
        this.seed=startSeed
    }

    /**
     * 创建新的随机数 范围为0~1
     */
    next():number{
        this.seed = (this.seed * 9301 + 49297) % 233280;
        return this.seed / 233280.0;
    }
}