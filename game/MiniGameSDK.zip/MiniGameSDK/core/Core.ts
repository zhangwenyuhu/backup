import Scene from "./Scene"
import Dialog from './Dialog';
import i18n from "./I18N";
import { Log } from "./Log";
import InfoBase from "./InfoBase";

let log=new Log({tags:["core"]})

/**
 * 场景数据，每个场景在创建是都会附带这份数据。
 * 用于对节点和数据的维护
 */
export class SceneData{
    protected static _index:number=0;

    /**
     * 获取持续累加的索引
     */
    public static get index(){
        return ++this._index;
    }

    protected _index:number
    protected _name:string
    protected _data:Object

    /**
     * 创建场景数据
     * @param name 场景的名称
     * @param data 场景需要传入的数据
     */
    public constructor(name:string,data:Object){
        this._index=SceneData.index;
        this._name=name
        this._data=data
    }

    /**
     * 当前场景的索引id
     */
    public get index():number{
        return this._index;
    }

    /**
     * 获取场景的名称
     */
    public get name():string{
        return this._name
    }

    /**
     * 获取场景的数据
     */
    public get data():Object{
        return this._data
    }

}

/**
 * 图层显示的类型
 */
export enum LayerType{
    /**
     * 常规弹框
     */
    FLOAT,
    /**
     * 相对重要的信息弹框，通常为toast。
     * 层级比FLOAT高
     */
    INFO,
    /**
     * 最高的层级，通常用来显示调试工具等
     */
    DEBUG
}

/**
 * 图层数据，每个图层在创建是都会附带这份数据。
 * 用于对节点和数据的维护
 */
export class LayerData{
    protected static _index:number=0;
    /**
     * 获取持续累加的索引
     */
    public static get index(){
        return ++this._index;
    }

    protected _index:number
    protected _url:string
    protected _prefab:cc.Prefab
    protected _data:Object
    protected _node:cc.Node
    protected _layerType:LayerType

    protected _isCancel:boolean;

    /**
     * 图层数据
     * @param prefab 图层的预制体
     * @param data 图层的数据
     * @param node 图层的节点
     * @param layerType 图层所在的位置
     * @param url 图层的地址
     */
    public constructor(prefab:cc.Prefab=null,data:Object=null,node:cc.Node=null,layerType:LayerType=null,url:string=null){
        this._index=LayerData.index;
        this._prefab=prefab
        this._data=data
        this._node=node
        this._layerType=layerType
        this._url=url
    }

    /**
     * 获取图层的id
     */
    public get index():number{
        return this._index;
    }

    /**
     * 获取图层的url
     */
    public get url():string{
        return this._url;
    }

    /**
     * 获取图层的预制体
     */
    public get prefab():cc.Prefab{
        return this._prefab
    }

    /**
     * 获取图层的数据
     */
    public get data():Object{
        return this._data
    }

    /**
     * 获取图层的节点
     */
    public get node():cc.Node{
        return this._node
    }

    /**
     * 获取图层的显示类型
     */
    public get layerType():LayerType{
        return this._layerType
    }

    /**
     * 是否取消
     */
    public get isCancel(){
        return this._isCancel
    }

    /**
     * 取消加载
     */
    public cancel(){
        this._isCancel=true;
    }

}

class CacheLayerInfo{
    url:string
    data:{data?:any,modalWindow?:boolean,layer?:LayerType,single?:boolean,cache?:boolean,modalTouch?:boolean,callback?:(layerData:LayerData)=>void}
}

/**
 * 核心库，主要用于场景和图层的管理。
 * 其次还附带toast、应用info、程序隐藏显示事件、gc事件等
 */
export class Core extends cc.EventTarget{
    protected static _instance:Core
    /**
     * 获取Core的全局实例
     */
    public static get instance():Core{
        if(!this._instance)
            this._instance=new Core();
        return this._instance;
    };

    /**
     * 当框架初始化完成触发
     */
    static readonly INIT:string="init"
    /**
     * 当游戏从后台进入时触发
     */
    static readonly SHOW:string="show"
    /**
     * 当游戏进入后台时触发
     */
    static readonly HIDE:string="hide"
    /**
     * 当游戏调用GC时触发
     */
    static readonly GC:string="gc"
    protected _isShowed:boolean=true
    /**
     * 当前游戏是否在前台
     */
    public get isShowed():boolean{
        return this._isShowed;
    }
    protected _loadingIndex=0;
    /**
     * 当前总共产生的loading总数
     */
    public get loadingIndex(){
        return this._loadingIndex++;
    }

    /**
     * 当显示toast时的屏幕偏移值
     */
    public toastOffset=cc.p(0,0)


    protected _sceneLoadingList:{index:number,scene:SceneData,callback:()=>void}[]=[];//准备要加载的场景

    protected _sceneList:Array<SceneData>=new Array<SceneData>()
    protected _layerList:Array<LayerData>=new Array<LayerData>()
    protected _cachedLayer:Array<CacheLayerInfo> = new Array<CacheLayerInfo>()

    protected _floatLayer:cc.Node;
    protected _infoLayer:cc.Node;
    protected _debugLayer:cc.Node;

    protected _showLoadingModalCallback:(index:number,url:string)=>void=null;//显示模态化遮挡层
    protected _closeLoadingModalCallback:(index:number,url:string)=>void=null;//隐藏模态遮挡层

    protected _bgTexture:cc.Texture2D;

    protected get bgTexture(){
        if(!this._bgTexture){
            this._bgTexture = new cc.Texture2D();
            let array=new Uint8Array(new ArrayBuffer(16))
            array[0]=array[1]=array[2]=0;array[3]=255;
            array[4]=array[5]=array[6]=0;array[7]=255;
            array[8]=array[9]=array[10]=0;array[11]=255;
            array[12]=array[13]=array[14]=0;array[15]=255;
           
            this._bgTexture.initWithData(array,cc.Texture2D.PixelFormat.RGBA8888,2,2);
        }
        return this._bgTexture;
        
    }


    public constructor(){
        super();
        if(window["wx"] && wx["onMemoryWarning"]){
            log.info("已注册内存警告")
            wx.onMemoryWarning((res)=>{
                log.info("触发内存GC")
                wx.triggerGC();//触发内存警告
                this.emit(Core.GC)
            })
        }
        
        if (window["wx"]) {
            wx.onShow((res) => {
                if(this._isShowed==false){
                    this.emit(Core.SHOW,res)
                    this._isShowed=true;
                }
            })
            wx.onHide(() => {
                if(this._isShowed){
                    this.emit(Core.HIDE)
                    this._isShowed=false;
                }
            })
        } else {
            cc.game.on(cc.game.EVENT_SHOW, () => {
                if(this._isShowed==false){
                    this.emit(Core.SHOW)
                    this._isShowed=true;
                }
            })
            cc.game.on(cc.game.EVENT_HIDE, () => {
                if(this._isShowed){
                    this.emit(Core.HIDE)
                    this._isShowed=false;
                }
            })
        }

    }

    /**
     * 初始化场景，构建基础图层
     * 浮动层
     * 信息层
     * debug层
     */
    public init():void{
        if(this._floatLayer){
            return;
        }

        log.info("initialize Scene");

        var nowScene=cc.director.getScene();

        this._floatLayer=new cc.Node("floatLayer")
        this._infoLayer=new cc.Node("infoLayer")
        this._debugLayer=new cc.Node("debugLayer")

        nowScene.addChild(this._floatLayer,100)
        nowScene.addChild(this._infoLayer,200)
        nowScene.addChild(this._debugLayer,300)

        cc.game.addPersistRootNode(this._floatLayer)
        cc.game.addPersistRootNode(this._infoLayer)
        cc.game.addPersistRootNode(this._debugLayer)

        log.info("Scene init complete");

        //设置与cocos编辑器中一样的背景色，这样变亮属性效果可以跟在cocos编辑器中一样
        cc.director.setClearColor(cc.color(52,52,52))
    }


    protected openScene(scene:SceneData,callback:()=>void=null):void{
        let index = this.showLoading(scene.name)
        
        let load=({index,scene,callback})=>{
            cc.director.loadScene(scene.name,()=>{
                //对场景进行数据绑定
                var newScene=cc.director.getScene();
                var sceneComponents= newScene.getComponentsInChildren(Scene)
    
                for(let comp of sceneComponents){
                    comp.data=scene.data
                    comp.onInit(scene.data)
                }
    
                //执行场景初始化
                newScene.emit(Core.INIT);
    
                this.closeLoading(index,scene.name)
    
                if(callback){
                    callback();
                }

                if(this._sceneLoadingList.length>0){
                    load(this._sceneLoadingList.shift());
                }
                
            });
        }

        if(cc.director["_loadingScene"]){
            //已经在加载某个场景，此时需要进行排队。
            this._sceneLoadingList.push({index,scene,callback})
        }else{
            load({index,scene,callback})
        }
        
    }

    /**
     * 压入场景
     * @param name 场景的名称
     * @param data 传递给场景的数据
     * @param callback 回调
     */
    public pushScene(name:string,data?:any,callback:()=>void=null):SceneData{
        var scene=new SceneData(name,data)

        this._sceneList.push(scene)

        var result=this.openScene(scene,callback);
        return scene;
    }

    /**
     * 弹出场景
     * @param callback 回调
     */
    public popScene(callback:()=>void=null):SceneData{
        //已经是顶部场景
        if(this._sceneList.length<=1){
            log.warn("no available scenes");
            return null;
        }
        
        this._sceneList.pop()
                
        var scene=this._sceneList[this._sceneList.length-1]
        if(!scene){
            return;
        }

        var result=this.openScene(scene,callback);
        return scene;
    }

    /**
     * 切换场景
     * @param name 场景的名称
     * @param data 传递给场景的数据
     * @param callback 回调
     */
    public replaceScene(name:string,data?:any,callback:()=>void=null):SceneData{
        if(this._sceneList.length>0)
            this._sceneList.pop();

        return this.pushScene(name,data,callback)
    }

    /**
     * 获取当前的场景
     */
    public get currentScene(){
        return this._sceneList[this._sceneList.length-1]
    }
    

    /**
     * 通过预制资源 显示图层
     */
    protected showLayerPrefab(layerData:LayerData,prefab:cc.Prefab,data:object,modalWindow:boolean=true,layer:LayerType=LayerType.FLOAT,url:string=null,modalTouch:boolean=null):LayerData{
        var node=cc.instantiate(prefab)
        var dialogComp= node.getComponent(Dialog)

        var size=cc.winSize
        if(modalWindow){
            //初始模态背景
            var bg=new cc.Node("modalBg");
            bg.setContentSize(size.width,size.height)
            var btn=bg.addComponent(cc.Button);
            node.addChild(bg,-1);
            
            var graphics=bg.addComponent(cc.Sprite)
            graphics.spriteFrame = new cc.SpriteFrame(this.bgTexture);
            graphics.node.scale = 1000;
            graphics.node.opacity = 200;

            if(modalTouch){
                bg.once(cc.Node.EventType.TOUCH_END,()=>{
                    dialogComp.close();
                })
            }
        }

        
        if(dialogComp && dialogComp.allowModifyPosition){
            //使用编辑器中默认坐标
            node.setPosition((size.width)/2+node.x,(size.height)/2+node.y)//偏移半个屏幕，使其在中间
        }else{
            node.setPosition((size.width)/2,(size.height)/2)//强制居中
        }

        //绑定数据
        if(dialogComp){
            dialogComp.data=data
            dialogComp.onInit(data);
        }

        switch(layer){
            case LayerType.FLOAT:
                this._floatLayer.addChild(node,dialogComp.getZIndex())
            break
            case LayerType.INFO:
                this._infoLayer.addChild(node,dialogComp.getZIndex())
            break
            case LayerType.DEBUG:
                this._debugLayer.addChild(node,dialogComp.getZIndex())
            break
        }

        //入场动画
        dialogComp.playEnterAnimation(()=>{
        })

        layerData["_node"]=node
        layerData["_prefab"]=prefab

        return layerData;
    }

    public getLayerCount(ltype:LayerType){
        let count = 0
        for(let i = 0; i < this._layerList.length; i++){
            if(this._layerList[i].layerType == ltype){
                count ++
            }
        }
        return count
    }

    /**
     * 显示图层对话框
     * @param url 对话框地址
     * ### 扩展参数
     * * data 传递给图层的数据
     * * modalWindow 是否进入模态模式
     * * cache cache如果有相同类型,暂不显示, layer 只支持为 float
     * * layer 所显示的图层位置
     * * single 是否只允许弹出一个弹框
     * * callback 弹框显示后的回调
     */
    public showLayer(url:string,{data,modalWindow,layer,single,cache,modalTouch,callback}:
        {data?:any,modalWindow?:boolean,layer?:LayerType,single?:boolean,cache?:boolean,modalTouch?:boolean,callback?:(layerData:LayerData)=>void}={modalWindow:true,single:true,layer:LayerType.FLOAT}){
        
        if(cache && (layer == LayerType.FLOAT || layer == null)){
            //we set layertype to float as default for cache 
            layer = layer? layer || layer:LayerType.FLOAT
            if(this.getLayerCount(layer) > 0 ) {
                console.warn(`${url} cached`);
                let cachedInfo = new CacheLayerInfo
                cachedInfo.url = url
                cachedInfo.data = {data,modalWindow,layer,single,cache,modalTouch,callback}
                this._cachedLayer.push(cachedInfo)
                return
            }
        }
        
        if(single && this.isLayerShown(url)){
            console.warn(`${url} is already opened`);
            return;
        }
        
        let index = this.showLoading(url)
        
        //创建图层信息
        let layerData=new LayerData(null,data,null,layer,url)
        this._layerList.push(layerData)

        let loadRes=()=>{
            cc.loader.loadRes(url,(err:Error,prefab:cc.Prefab)=>{
    
                if(layerData.isCancel){
                    return;//已经被取消
                }
    
                if(!prefab || prefab instanceof cc.Prefab == false){
                    log.error("无法找到对话框",url)
                    this.closeLoading(index,url)
                    
                    this.resLoadRetry(()=>{
                        loadRes();
                    })
                    return
                }
    
                this.closeLoading(index,url)
            
                if(prefab){
                    var l=this.showLayerPrefab(layerData,prefab,data,modalWindow,layer,url,modalTouch)
                    if(callback){
                        callback(l)
                    }
                }else{
                    log.error(err)
                }
            })
        }
        loadRes()

    }

    protected wxGC(){
        if(window['wx']){
            wx.triggerGC()
            setTimeout(()=>{
                wx.triggerGC()
            },5000)
        }
    }

    /**
     * 判断某个图层是否显示
     * @param data 根图层有关的数据
     */
    public isLayerShown(data:number|string|LayerData|cc.Node):boolean{
        var layerData:LayerData
        if(typeof data == "number"){
            layerData=this._layerList.find(a=>a.index==data)
        }else if(typeof data=="string"){
            layerData=this._layerList.find(a=>a.url==data)
        }else if(data instanceof LayerData){
            layerData=data
        }else if(data instanceof cc.Node){
            layerData=this._layerList.find(a=>a.node==data)
        }
        return !!layerData
    }

    /**
     * 关闭图层
     */
    public closeLayer(data:number|string|LayerData|cc.Node){
        var layerData:LayerData
        if(typeof data == "number"){
            layerData=this._layerList.find(a=>a.index==data)
        }else if(typeof data=="string"){
            layerData=this._layerList.find(a=>a.url==data)
        }else if(data instanceof LayerData){
            layerData=data
        }else if(data instanceof cc.Node){
            layerData=this._layerList.find(a=>a.node==data)
        }

        if(!layerData){
            log.warn("no layer",data)
            return
        }

        if(layerData.node==null){
            //未加载完全
            layerData.cancel()
            this._layerList.remove(layerData)
            log.info(data,"未加载完成，被调用关闭逻辑","加载被取消")
            this.checkCachedLayer()
            return;
        }

        let dialogComp= layerData.node.getComponent(Dialog)
        if(dialogComp){
            if(dialogComp.isClosing){//已经在关闭状态了
                return;
            }
            if(dialogComp.onClose()===true){
                //对话框被取消关闭
                log.info(layerData,"对话框在onClose被取消关闭")
                return;
            }
            dialogComp['_isClosing']=true;
            dialogComp.playLeaveAnimation(()=>{
                layerData.node.destroy()
                this._layerList.remove(layerData)
                this.checkCachedLayer()

            })
        }else{
            layerData.node.destroy()
            this._layerList.remove(layerData)
            this.checkCachedLayer()
        }
    }

    /**
     * 检查是否有cached layer 需要显示
     */
    public checkCachedLayer(){
        if (this._cachedLayer.length > 0 && this.getLayerCount(this._cachedLayer[0].data.layer) == 0) {
            let cachedInfo = this._cachedLayer.shift()
            this.showLayer(cachedInfo.url,cachedInfo.data)
        }

    }

    /**
     * 设置需要实现模态层的回调
     */
    public set showModalCallback(callback:(index:number,url:string)=>void){
        this._showLoadingModalCallback=callback;
    }

    /**
     * 设置关闭模态层的回调
     */
    public set closeModalCallback(callback:(index:number,url:string)=>void){
        this._closeLoadingModalCallback=callback;
    }

    public showLoading(value: string) : number{
        let index = this.loadingIndex
        if(this._showLoadingModalCallback){
            this._showLoadingModalCallback(index,value)
        }
        return index
    }

    public closeLoading(index: number,value: string){
        if(this._closeLoadingModalCallback){
            this._closeLoadingModalCallback(index,value)
        }
    }
    /**
     * 获取图层列表
     */
    public getLayerList():Array<LayerData>{
        return this._layerList.concat()
    }

    /**
     * 弹出简单信息 结束后关闭
     * @param text toast文字内容
     * ### 扩展参数
     * * prefab toast所使用的预制体
     * * icon toast所使用的图标
     */
    public toast(text:string, {prefab,icon}:{prefab?:string,icon?:cc.SpriteFrame}={prefab:"dialogs/DToast",icon:null}){
        let url=prefab
        let data={label:text,icon:icon}
        let layerData=new LayerData(null,data,null,LayerType.INFO,url)
        this._layerList.push(layerData)

        cc.loader.loadRes(prefab, cc.Prefab,(err:Error,prefab:cc.Prefab):void=>{
            if(!prefab || prefab instanceof cc.Prefab == false){
                log.error("无法找到对话框" + prefab)
                return
            }
            //显示图层
    
            var layer=this.showLayerPrefab(layerData,prefab,data,false,LayerType.INFO);

            //进行toast 偏移
            layer.node.x+=this.toastOffset.x;
            layer.node.y+=this.toastOffset.y;
            
            layer.node.once(Dialog.ENTER_ANIMATION_FINISHED,()=>{
                this.closeLayer(layer);
            });
        })
    }

    protected resLoadRetry(retry:()=>void){
        this.showDialog(i18n.locString("network.error"),()=>{
            retry();
        })
    }

    /**
     * 打开系统对话框
     * @param message 对话框内容
     * @param callback 回调函数 可收到点击true或false
     * ### 扩展参数
     * * title 对话框标题
     * * okText 对话框确定按钮文字
     * * cancelText 取消按钮文字
     * * cancelable 是否允许点击取消
     */
    public showDialog(message:string,callback:(v:boolean)=>void,{title,okText,cancelText,cancelable}:{title?:string,okText?:string,cancelText?:string,cancelable?:boolean}={title:"友情提示",okText:"确定",cancelText:"取消",cancelable:false}){
        if(window["wx"]){
            //微信弹框
            title = title || "友情提示";
            okText = okText || "确定";
            cancelText = cancelText || "取消";
            cancelable = cancelable || false;
            wx.showModal({title:title,content:message,showCancel:cancelable,confirmText:okText,cancelText:cancelText,success:(res)=>{
                if(cancelable){
                    callback(res.confirm);
                }else{
                    callback(true);
                }
            },fail:()=>{
                callback(false);
            }})
        }else{
            //系统默认弹框
            setTimeout(()=>{
                if(cancelable){
                    callback(confirm(message));
                }else{
                    alert(message);
                    callback(true);
                }
            },1000)
        }
    }

    protected _serverTimeOffset:number=0;//与服务器的时间差

    /**
     * 获取当前设置的与服务器产生的时间偏移值
     */
    get serverTimeOffset(){
        return this._serverTimeOffset
    }

    /**
     * 设置当前设置的与服务器产生的时间偏移值，用于客户端时间转换为服务器端时间
     */
    set serverTimeOffset(value){
        this._serverTimeOffset=value;
    }

    /**
     * 获取当前服务器时间
     */
    get serverTime():Date{
        return new Date(new Date().getTime()+this._serverTimeOffset);
    }

    /**
     * 获取当前的游戏配置信息
     */
    public info:InfoBase;

    /**
     * 获取当前的浮动图层
     */
    public get floatLayer():cc.Node{
        return this._floatLayer
    }
    /**
     * 获取当前的信息图层
     */
    public get infoLayer():cc.Node{
        return this._infoLayer
    }

    /**
     * 获取当前的调试图层
     */
    public get debugLayer():cc.Node{
        return this._debugLayer
    }

}

var core=Core.instance
export default core;