import { DataFactory } from "./SafeData";
import LocalStorage from "./LocalStorage";
import log from "./Log";
import core from "./Core";

export class StorageCenter{

    /**
     * 存储数据所使用的key
     */
    public storageKey:string="glee_storage"
    /**
     * 存储保存时间所使用的key
     */
    public timestampKey:string="glee_storage_timestamp"
    /**
     * 存储角色id所使用的key
     */
    public roleIdKey:string="glee_roleId";

    /**
     * 自动存储的时间间隔
     */
    public autoInterval:number=20*1000

    protected _autoSave:boolean=false
    protected _saveHandler:any=null
    protected _storageMap:{[key:string]:Object}={};

    /**
     * 当自动存储时，会产生该回调
     */
    public onAutoSave:()=>void=null;//当默认保存时，触发

    static readonly instance=new StorageCenter()



    constructor(){
        
    }

    /**
     * 设置是否自动存储
     */
    set autoSave(value:boolean){
        if(this._autoSave==value){
            return;
        }
        this._autoSave=value

        if(this._autoSave){
            this._saveHandler=setInterval(()=>{
                this.saveToLocalStorage();
                if(this.onAutoSave)
                    this.onAutoSave()
            },this.autoInterval)
        }else{
            clearInterval(this._saveHandler);
        }
    }

    /**
     * 获取当前是否自动存储
     */
    get autoSave(){
        return this._autoSave
    }

    /**
     * 保存存档到本地存储
     */
    saveToLocalStorage(){
        let data=this.save()
        let storage=JSON.stringify(data)
        LocalStorage.setItem(this.storageKey,storage);//保存游戏存档
        let serverTime=core.serverTime
        LocalStorage.setItem(this.timestampKey,serverTime.getTime().toString());//保存时间戳key
    }

    /**
     * 从本地存储读取存档
     */
    loadFromLocalStorage(){
        let storage=LocalStorage.getItem(this.storageKey);
        if(!storage){
            return;
        }
        try{
            let data=JSON.parse(storage);
            this.load(data);
        }catch(e){
            log.error("存档解析失败",storage)
            throw new Error("存档解析失败")
        }
    }

    /**
     * 保存玩家数据至字符串
     */
    public save():any{
        let result:any={}
        for (const key in this._storageMap) {
            let data=this._storageMap[key]
            if (data) {
                result[key]=this.saveObject(data);
            }
        }
        return result;
    }

    /**
     * 加载玩家数据字符串
     */
    public load(data:any){
        for (const key in data) {
            this._storageMap[key]=this.loadObject(data[key]);
        }
    }

    /**
     * 保存对象
     * @param obj 对象数据
     * @returns 保存后的数据
     */
    public saveObject(obj:any):any{
        if(obj&&obj["_classname_"]){//安全加密对象
            //遍历所有已经设置的属性，保存类名
            let result:any={}            
            result.__class__= obj['_classname_'];
            for (const key in obj) {
                if (obj.hasOwnProperty(key)) {
                    if(obj.needSave && !obj.needSave(key)){
                        continue;//跳过保存
                    }
                    if(key.startsWith("__")&&key.endsWith("__")){
                        //属性
                        let newkey=key.substring(2,key.length-2);
                        let value=obj[key];
                        result[newkey]=this.saveObject(value);
                    }
                }
            }
            return result;
        }else if(obj instanceof Array){
            //保存数组对象
            let result=[]
            for(let i=0;i<obj.length;i++){
                result.push(this.saveObject(obj[i]))
            }
            return result;
        }else if(obj instanceof Object){
            //常规对象数据
            let result:any={}            
            for (const key in obj) {
                if (obj.hasOwnProperty(key)) {
                    result[key]=this.saveObject(obj[key]);
                }
            }
            return result;
        }else{
            //普通数据
            return obj;
        }
    }

    /**
     * 从对象中加载数据
     * @param obj 对象
     */
    public loadObject(obj:any):any{ 
        if(obj instanceof Array){
            let result=[]
            for(let i=0;i<obj.length;i++){
                result.push(this.loadObject(obj[i]))
            }
            return result;
        }else if(obj instanceof Object){
            //对象
            if(obj.__class__){
                //数据模型
                let result=DataFactory.instance.create(obj.__class__)
                if(result){
                    for (const key in obj) {
                        if (key!="__class__" && obj.hasOwnProperty(key)) {
                            result["__"+key+"__"]=this.loadObject(obj[key]);
                        }
                    }
                    if(result["loadFinish"]){
                        result["loadFinish"]();
                    }
                    return result;
                }else{
                    log.error("存档解析错误，无法找到模型",obj.__class__)
                    return null;
                }
            }else{
                //常规对象
                let result:any={}            
                for (const key in obj) {
                    if (obj.hasOwnProperty(key)) {
                        result[key]=this.loadObject(obj[key]);
                    }
                }
                return result;    
            }
        }else{
            //普通数据
            return obj;
        }
    }

    /**
     * 本地是否已经有存档
     */
    get isSaved(){
        let data=LocalStorage.getItem(this.storageKey)
        return data!=null&&data!=""
    }

    /**
     * 获取最新保存的存档的时间戳
     * 如果获取失败返回0
     */
    get timestamp(){
        let time=LocalStorage.getItem(this.timestampKey);
        if(time){
            let t=parseInt(time)
            if(!isNaN(t)){
                return t;
            }else{
                return 0;
            }
        }else{
            return 0;
        }
    }

    /**
     * 获取已存入的数据
     * @param key 数据的key
     */
    getSavedData(key:string):any{
        return this._storageMap[key]
    }

    /**
     * 将数据存入
     * @param key key
     * @param data 数据
     */
    setSavedData(key:string,data:object){
        this._storageMap[key]=data
    }

    /**
     * 重置存储
     */
    reset(){
        this._storageMap={}
    }

}

var storage=StorageCenter.instance
export default storage;