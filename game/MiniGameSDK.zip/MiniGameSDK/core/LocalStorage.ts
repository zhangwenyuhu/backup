import { XXTEA } from "../libs/xxtea";
import core from "./Core";

export default class LocalStorage{
    
    static _encryptKey:string="^sdEF\n'r\r*@2\t!#~-+j;#$gnjl;csa`"
    static _defaultKey="^sdEF\n'r\r*@2\t!#~-+j;#$gnjl;csa`"
    
    /**
     * 设置当前的加密秘钥
     */
    static set encryptKey(v){
        this._encryptKey=v
    }
    /**
     * 获取当前的加密秘钥
     */
    static get encryptKey(){
        return this._encryptKey
    }

    protected static _setItem(key:string,value:string,encrypt:boolean=true){
        if(encrypt){
            if(this._encryptKey==this._defaultKey){
                core.showDialog("存档key错误",()=>{})
                console.error("存档key错误");
            }
            value=XXTEA.encryptToBase64Ex1(value,LocalStorage.encryptKey)
        }
        if(window["wx"]){
            return wx.setStorageSync(key,value)
        }else{
            return cc.sys.localStorage.setItem(key,value)
        }
    }

    /**
     * 设置一个存储项
     * @param key 存储key
     * @param value 存储的值
     * @param encrypt 是否加密
     */
    static setItem(key:string,value:string,encrypt:boolean=true){
        return LocalStorage._setItem(key,value,encrypt)
    }
    /**
     * 获取一个存储项
     * @param key 存储的key
     * @param encrypt 数据存储时，是否被加密
     */
    static getItem(key:string,encrypt:boolean=true){
        let value
        if(window["wx"]){
            value=wx.getStorageSync(key)
        }else{
            value= cc.sys.localStorage.getItem(key)
        }
        if(encrypt){
            let newValue:string
            newValue=XXTEA.decryptFromBase64Ex1(value,LocalStorage.encryptKey)
            return newValue
        }
        return value
    }
}