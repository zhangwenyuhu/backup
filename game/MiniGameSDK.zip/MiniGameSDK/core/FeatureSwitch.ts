export class FeatureSwitch{
    static readonly instance=new FeatureSwitch

    protected switchMap:{[key:string]:any}={}

    /**
     * 设置功能的开启和关闭
     * @param key 功能key
     * @param enabled 是否开启
     */
    setFeature(key:string,enabled:boolean){
        this.switchMap[key]=enabled
    }

    /**
     * 检查某项功能是否开启
     * @param key 
     */
    checkFeature(key:string){
        return this.switchMap[key]==true;
    }

}

var featureSwitch=FeatureSwitch.instance
export default featureSwitch