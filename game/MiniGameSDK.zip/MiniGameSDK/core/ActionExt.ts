export class BrightnessTo extends cc.ActionInterval{
    protected _toBrightness:number
    protected _fromBrightness:number
    constructor(duration:number, brightness:number){
        super();
        this._toBrightness = brightness;
        cc.ActionInterval.prototype['initWithDuration'].call(this, duration)
    }

    clone() {
        var action = new BrightnessTo(this['_duration'],this._toBrightness);
        return action;
    }

    update(time) {
        time = this['_computeEaseTime'](time);
        var fromBrightness = this._fromBrightness !== undefined ? this._fromBrightness : 0;
        this['target'].brightness = fromBrightness + (this._toBrightness - fromBrightness) * time;
    }

    startWithTarget(target:cc.Node) {
        cc.ActionInterval.prototype['startWithTarget'].call(this, target);
        this._fromBrightness = target.brightness;
    }

}

export class ActionHelper{

    static readonly instance=new ActionHelper();

    /**
     * 所有子节点的 action
     * @param node 节点
     * @param self 自己是否也执行
     */
    stopChildrenAllAction(node:cc.Node,self:boolean=false){
        if(self){
            node.stopAllActions();
        }
        let children=node.children
        for(let n of children){
            this.stopChildrenAllAction(n,true);
        }
    }


    /**
     * 对所有子节点执行action
     * @param node 节点
     * @param action 动作
     * @param self 自己是否也执行
     */
    runChildrenAction(node:cc.Node,action:cc.Action,self:boolean=false){
        if(self){
            node.runAction(action.clone());
        }
        let children=node.children
        for(let n of children){
            this.runChildrenAction(n,action.clone(),true);
        }
    }
}