export default class InfoBase{
    /**
     * 游戏的启动模式。
     * 可以是 开发、测试、发布
     * 
     */
    mode:"develop"|"test"|"release"="develop"

    /**
     * APPID 一般为微信ID
     */
    appId:string=""

    /**
     * 游戏当前的版本号，需要手动编辑
     */
    version:string="1.0.0"

    /**
     * 游戏的资源版本号，每次发布的时候会自动+1
     */
    resVersion:number=0

    /**
     * 游戏的服务器地址例如 https://xzxxxx.com
     */
    gameUrl:string=""

    /**
     * 账号服 https
     */
    accountServer:string=""

    /**
     * 日志服务器地址
     */
    logUrl:string=""

    /**
     * 游戏cdn地址
     */
    cdnUrl:string=""

    /**
     * 游戏分享信息配置文件地址
     */
    shareConfigUrl:string=""

    /**
     * 支付id
     */
    offerId:string="";

    /**
     * 支付时，是否使用安全沙箱
     */
    chargeSandbox:boolean=true;
}