export class I18N{

    static readonly instance=new I18N()
    
    langMap:{[key:string]:string}={}

    /**
     * 应用语言表
     * @param list 语言列表 必须是 key value 的形式
     */
    applyTable(list:{key:string,value:string}[]){
        this.langMap={}
        for(let v of list){
            this.langMap[v.key]=v.value
        }
    }

    /**
     * 根据key获取文字内容
     * @param key 
     */
    locString(key:string):string{
        if(this.langMap[key]){
            return this.langMap[key]
        }else{
            return key
        }
    }

    /**
     * 根据多语言数据格式化文本
     * ###例如
     * * key="pet.get"
     * * value="恭喜你获得${petName},好好保护它吧！"
     * * format("pet.get",petName)
     * @param key 语言key
     * @param args 参数，支持字符串数组
     */
    format(key:string,args:{[key:string]:any}){
        //以 ${} 作为替换词匹配
        let value=this.locString(key);
        let list=value.match(/\${[a-zA-Z0-9]+}/g)
        for(let m of list){
            let key=m.replace(/\$|{|}/g,"")
            value=value.replace(m,String(args[key]));
        }
        return value;
    }
    
}

var i18n=I18N.instance
export default i18n