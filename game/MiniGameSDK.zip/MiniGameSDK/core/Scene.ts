const {ccclass, property} = cc._decorator;

@ccclass
export default class Scene extends cc.Component {

    protected _data:any;//当前被绑定的数据

    public set data(value:any){
        this._data=value;
    }

    public get data():any{
        return this._data
    }

    /**
     * 当界面加载完成后执行，界面数据由此传入
     * @param data 
     */
    public onInit(data:any){
    }
    
}
