
export class LogicResult{
    success:boolean=true;//执行结果
    nextData:any=null;//向下传递的数据
}

export class LogicChainItem{
    constructor(){

    }

    /**
     * 子类需要实现该函数
     */
    public async logic(data:any):Promise<LogicResult>{
        return new Promise<LogicResult>((resolve,reject)=>{resolve(new LogicResult())})
    }
}

export default class LogicChain{
    protected _itemList:LogicChainItem[]=[];

    protected _progress:(current:number,total:number)=>void=null;

    constructor(){

    }
    
    /**
     * 链接下一个逻辑
     * @param next 
     */
    link(next:LogicChainItem){
        this._itemList.push(next)
        return this;
    }

    /**
     * 执行逻辑并返回结果
     */
    async execute(data:any){
        for(let i=0;i<this._itemList.length;i++){
            let item=this._itemList[i]
            let result= await item.logic(data);
            if(!result.success){
                return;
            }
            data=result.nextData;
            if(this._progress){
                this._progress(i+1,this._itemList.length);
            }
        }
    }

    /**
     * 获取逻辑链进度函数
     */
    get progress(){
        return this._progress
    }

    /**
     * 设置逻辑链进度函数
     */
    set progress(value){
        this._progress=value
    }
}