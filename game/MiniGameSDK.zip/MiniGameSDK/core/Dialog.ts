import core from './Core';

const {ccclass, property} = cc._decorator;

@ccclass
export default class Dialog extends cc.Component {

    public static ENTER_ANIMATION_FINISHED="enterAnimationFinished"
    public static LEAVE_ANIMATION_FINISHED="leaveAnimationFinished"

    protected _data:any;//当前被绑定的数据

    protected _isClosing:boolean=false;//是否正在关闭

    /**
     * 设置用户数据
     */
    public set data(value:any){
        this._data=value;
    }

    /**
     * 获取用户数据
     */
    public get data():any{
        return this._data
    }

    /**
     * 对话框打开后是否通过代码将对话框居中，如果勾选则会保留弹框本身的坐标
     */
    @property({
        tooltip:'对话框打开后是否通过代码将对话框居中，如果勾选则会保留弹框本身的坐标',
        displayName:'自定义位置',
    })
    allowModifyPosition:boolean=false

    /**
     * 入场动画列表，弹框打开时，每个动画都会被播放
     */
    @property({
        tooltip:'入场动画列表，弹框打开时，每个动画都会被播放',
        type:[cc.AnimationClip],
        displayName:'入场动画',
    })
    enterAnims:cc.AnimationClip[]=[]

    /**
     * 离场动画列表，弹框关闭时，每个动画都会被播放
     */
    @property({
        tooltip:'离场动画列表，弹框关闭时，每个动画都会被播放',
        type:[cc.AnimationClip],
        displayName:'离场动画',
    })
    leaveAnims:cc.AnimationClip[]=[]

    @property({
        tooltip:"入场音效",
        type:cc.AudioClip,
        displayName:"入场音效",
    })
    enterSound:cc.AudioClip = null


    @property({
        tooltip:"离场音效",
        type:cc.AudioClip,
        displayName:"离场音效",
    })
    leaveSound:cc.AudioClip = null

    /**
     * 播放入场动画,core中对话框打开时，默认会执行这个逻辑
     * @param finished 回调函数
     */
    public playEnterAnimation(finished:()=>void){
        var anim = this.node.getComponent(cc.Animation)
        let isPlay=false;
        if (anim) {
            for(let animclip of this.enterAnims){
                if(animclip==undefined){
                    continue;
                }
                if(!anim.getClips().find(item=>item && item.name==animclip.name)){
                    anim.addClip(animclip)
                }
                anim.playAdditive(animclip.name)
                isPlay=true;
            }
            anim.once("finished", ()=>{
                finished();
                this.scheduleOnce(()=>{
                    this.node.emit(Dialog.ENTER_ANIMATION_FINISHED);
                },0)
            });
        }
        if(!isPlay){
            finished();
            this.scheduleOnce(()=>{
                this.node.emit(Dialog.ENTER_ANIMATION_FINISHED);
            },0);
        }

        if(this.enterSound){
             cc.audioEngine.play(this.enterSound,false,1.0)
        }
    }

    /**
     * 播放入场动画,core中对话框打开时，默认会执行这个逻辑
     * @param finished 回调函数
     */
    public playLeaveAnimation(finished:()=>void){
        var anim = this.node.getComponent(cc.Animation)
        let isPlay=false;
        if (anim) {
            for(let animclip of this.leaveAnims){
                if(animclip==undefined){
                    continue;
                }
                if(!anim.getClips().find(item=>item && item.name==animclip.name)){
                    anim.addClip(animclip)
                }
                anim.playAdditive(animclip.name)
                isPlay=true;
            }
            anim.once("finished", ()=>{
                finished();
                this.node.emit(Dialog.LEAVE_ANIMATION_FINISHED);
            });
        }
        if(!isPlay){
            finished();
            this.node.emit(Dialog.LEAVE_ANIMATION_FINISHED);
        }

        if(this.leaveSound){
             cc.audioEngine.play(this.leaveSound,false,1.0)
        }
    }

    /**
     * 当界面加载完成后执行，界面数据由此传入
     * 该逻辑将在start之后执行
     * @param data 
     */
    public onInit(data:any){
        
    }
    
    /**
     * 关闭当前对话框
     */
    close(){
        if(this.isClosing){
            return;
        }
        core.closeLayer(this.node)
    }

    get isClosing(){
        return this._isClosing
    }

    /**
     * 要对话框要被关闭时的回调
     * @returns 当返回true时，则对话框会取消关闭
     */
    onClose():boolean{
        return null;
    }

    /**
     * 指定层级的zorder
     */
    getZIndex():number{
        return 0
    }
}