/**
 * hint

	cc.instantiate
	cc.isValid
	destroy
	cc.director
	cc.game
	
	// ctor() {}
	// update (dt) {}
	// lateUpdate(dt) {}
	// onDestroy() {}
	// onEnable() {}
	// onDisable() {}
	
 !zh
 计时器停止，会 emit('timerlabel:on-timer-stop',{time:this._lefttime})
 时间到零，会 emit('timerlabel:on-timeout')
 */

const {ccclass, property} = cc._decorator;

@ccclass
export default class TimerLabel extends cc.Component {

	// onLoad () {}
	@property
	_timeformat:string='yyyy-MM-dd/hh-mm-ss';
	
	//阶段性触发函数
	@property
	_lasTrigger:Function=null

	//触发阶段时间
	@property
	_callTime:number=0

	//是否可以出发阶段性操作
	@property
	_isTouchlastFun:boolean=false

	@property({
		tooltip:"时间格式"
	})
	set timeformat(format){
		this._needUpdate=true
		this._timeformat=format
		// this.updateDate()
	}
	get timeformat():string{
		return this._timeformat
	}

	@property
	_lefttime:number=10;


	@property({
		tooltip:"倒计时时长（单位：秒）"
	})

	set lasTrigger(F:Function)
	{
		this._lasTrigger=F;
	}

	get lasTrigger():Function
	{
		return this._lasTrigger
	}

	set callTime(dt:number)
	{
		this._callTime=dt
	}

	get callTime():number
	{
		return this._callTime
	}

	set isTouchlastFun(bool:boolean)
	{
		this._isTouchlastFun=bool
	}

	set lefttime(dt:number){
		this._needUpdate=true
		this._lefttime=dt
		// this.updateDate()
	}
	get lefttime():number{
		return this._lefttime
	}
	protected _needUpdate=true;

	_labelComponent:cc.Label;

	@property
	_shallStartJustNow:boolean=true
	@property({
		tooltip:"立即开始倒计时"
	})
	set shallStartJustNow(b:boolean){
		this._shallStartJustNow=b
	}
	get shallStartJustNow():boolean{
		return this._shallStartJustNow
	}

	@property
	get formattedTime():string{
		return this._formattedTime
	}
	_formattedTime:string=''

	_timercallback=null


	@property
	_endtip:string = "";

	@property
	get endTip():string{
		return this._endtip
	}
	set endTip(v:string){
		this._endtip = v
	}

	onLoad(){
	}

	start () {
		this._labelComponent=this.node.getComponent(cc.Label)

		cc.assert(this._labelComponent,'error: 定时器标签 缺少依赖的 cc.Label 组件')

		this.updateDate()

		this._timercallback=(dt)=>{
			if(!this._needUpdate){
				return
			}
			this._lefttime=this._lefttime-dt
			if(this._lefttime<0){
				this._lefttime=0
				this._needUpdate=false
			}
			this.triggerEvent()
			this.updateDate()
			if(!this._needUpdate){
				this.node.emit('timerlabel:on-timer-stop',{time:this._lefttime})
				if(this._lefttime==0){
					this.node.emit('timerlabel:on-timeout')
				}
			}
		}
		
		if(this._shallStartJustNow){
			this.resumeTimer()
		}
	}

	public resumeTimer(){
		if(this._timercallback){
			this.unschedule(this._timercallback)
			this.schedule(this._timercallback,0.25)
		}
	}
	
	public pauseTimer(){
		if(this._timercallback){
			this.unschedule(this._timercallback)
		}
	}

	public triggerEvent()
	{
		if (this._isTouchlastFun)
		{
			if(this._lefttime<this._callTime)
			{
				console.log('当前的触发时间==',this._callTime,this._lefttime)
				if (this._lasTrigger)
				{
					this._lasTrigger()
					this._lasTrigger=null
					this._callTime=0
					this._isTouchlastFun=false
				}
			}
		}
	}
	public updateDate(){
		if((!this._labelComponent) || (!cc.isValid(this._labelComponent))){
			this._labelComponent=this.node.getComponent(cc.Label)
			if((!this._labelComponent) || (!cc.isValid(this._labelComponent))){
				console.error("invalid label for TimerLabel, Label component is missing !")
				return
			}
		}
		
		let date=new Date(Math.max(this._lefttime,0)*1000)
		let dateString=date.rawformat(this._timeformat)
		this._formattedTime=dateString
		this._labelComponent.string=dateString

		if(this._lefttime <= 0){
			this.showEndTip()
		}
	}

	public showEndTip(){
		if(this._endtip && this._endtip.length > 0){
			this._labelComponent.string = this._endtip
		}
	}
}
