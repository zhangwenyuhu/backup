const {ccclass, property} = cc._decorator;

let isRootNode=function(node:cc.Node){
    return (!node) || (node['_prefab'] && node['_prefab'].root==node) || (node instanceof cc.Scene) || false
}

function _parseNodePath(node:cc.Node):string[]{
    let names=[]
    let curParent:cc.Node=node
    while(!isRootNode(curParent)){
        names.unshift(curParent.name)
        curParent=curParent.parent
    }
    // names.unshift(curParent.name)
    return names
}

export function parseNodePath(node:cc.Node):string{
    return _parseNodePath(node).join('/')
}

export function parseRelativePath(node:cc.Node,curnode:cc.Node):string{
    let curnames=_parseNodePath(curnode)
    let nodenames=_parseNodePath(node)
    let commonMax=0
    for(let i=0;i<Math.min(curnames.length,nodenames.length);i++){
        if(curnames[i]!=nodenames[i]){
            commonMax=i
            break
        }
    }

    let indexPath=nodenames.slice(commonMax).join('/')
    let backPath='../'.repeat(nodenames.length-commonMax)
    let rpath=backPath+indexPath
    return rpath
}

// @usage:
/* example
let label=findWithPath('ethteh/../ethteh/sdf/34e<Label>')
*/
export function findWithPath<T extends cc.Node|cc.Component>(path:string,node?:cc.Node):T{
    if (path == null) {
        cc.errorID(5600);
        return null;
    }
    if (!node) {
        var scene = cc.director.getScene();
        if (!scene) {
            if (CC_DEV) {
                cc.warnID(5601);
            }
            return null;
        }
        else if (CC_DEV && !scene.isValid) {
            cc.warnID(5602);
            return null;
        }
        node = scene;
    }else if (CC_DEV && !node.isValid) {
        cc.warnID(5603);
        return null;
    }

    let curcomp:T
    let curnode:cc.Node=node
    let ext=null
    let ret=path.match(/^(.*)\<(\w+)\>$/)
    if(ret){
        ext=ret[2]
        path=ret[1]
    }
    let names=path.split('/')
    for(let name of names){
        if(name=='..'){
            curnode=curnode.parent
        }else{
            curnode=curnode.getChildByName(name)
        }
    }
    if(ext){
        curcomp=<T>curnode.getComponent(cc[ext] || ext)
    }
    return <T>(curcomp || curnode)
}

// @usage:
// 使用相对路径寻址
/* example
class A extends cc.Component{
    @nodepath(cc.Node)
    node:cc.Node=null

    @nodepath(cc.Label)
    label:cc.Label=null

    ...
}
    */
export function nodepath(...arg){
    return function(target,pname){
        let spname=Symbol('spname_'+pname)
        // property(cc.Node)(target,pname)
        property.apply(window,arg)(target,pname)
        Object.defineProperty(target,pname,{
            get: function () {
                if (CC_EDITOR) {
                    if(this.node){
                        let result=this[spname] && findWithPath(this[spname],this.node);
                        if(arg[0].prototype instanceof cc.Component){
                            return result && result.getComponent(arg[0])
                        }else{
                            return result
                        }
                    }else{
                        return this[spname]
                    }
                }
                else {
                    return this[spname];
                }
            },
            set: function (value) {
                if (CC_EDITOR) {
                    if(!this.node){
                        if(typeof(value)=='string'){
                            this[spname]=value
                        }
                        return
                    }
                    let setNode=value
                    if(value instanceof cc.Component){
                        setNode=value.node
                    }
                    this[spname] = value && parseRelativePath(setNode,this.node)
                }
                else {
                    this[spname]=value
                }
            },
            enumerable: true,
            configurable: true
        })
    }
}
