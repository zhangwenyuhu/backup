/**
 * 开关类，用于记录当前有哪些功能是开启的
 */
export default class Switch{
    static instance=new Switch()

    protected _switchData:{[key:string]:boolean}={}
    constructor(){

    }

    /**
     * 初始化数据，需要传入一个功能Map
     * @param data 
     */
    initData(data:{[key:string]:boolean}){
        this._switchData=data
    }

    /**
     * 应用服务器提供的开关数据
     * @param data 值 0|'0'|false 关闭  1|'1'|true 开启 
     */
    applyData(data:{[key:string]:any}){
        for(let key in data){
            let value=data[key];
            this._switchData[key]=value==1||value=='1'||value==true;
        }
    }

    /**
     * 检查功能模块是否开启
     */
    check(key:string):boolean{
        return this._switchData[key]===true;
    }
}