//所登录服务器信息

export default class ServerLoginData {
    protected static _data: {
        userId: number,
        openId?: string,
        serviceTimestamp: number, 
        service24Timestamp:number,//明天的0点
        dataTimestamp: number//上次存档的时间戳
        nickname: string,
        profileImg: string,
        backupTime: number,//上传存档时间 秒

        shareSwitch: {

        },
        gameCurrency: {
            gold: string,
            diamond: string,
            seed: string
        },
        createTime: string,//创建时间
        channelId: number//渠道id

        encryptKey: string,//存档加密key
        token: string,//登陆token getUserInfo 接口下可能拿不到
    } = null

    public static setLoginData(data: any) {
        this._data = data
    }

    public static getLoginData() {
        return this._data
    }

    public static getService24Timestamp() {
        return this._data.service24Timestamp
    }

    //调整第二天0点 时间点
    public static updateServer24Timestamp(servertime:number){
        if(this._data && this._data.service24Timestamp){
            if(this._data.service24Timestamp > servertime){
                let newt = new Date(servertime)
                newt.setDate(newt.getDate()+1)
                this._data.service24Timestamp = newt.setHours(0,0,0,0)
                console.warn("Service24Timestamp updated!")
            }
        }
    }
}