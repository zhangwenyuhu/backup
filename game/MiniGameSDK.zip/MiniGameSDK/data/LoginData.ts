import { SafeClass } from "../core/SafeData";
import storage from "../core/StorageCenter";

@SafeClass("LoginData")
export class LoginData{
    /**
     * 可以是角色的id 也可以是openid，是服务器唯一的角色key
     */
    roleId:any=null;
    /**
     * token数据
     */
    token:any=null;

    /**
     * 游戏服务器token数据
     */
    gameToken:any=null;

    /**
     * 登陆的openid
     */
    openId:string=null;
    /**
     * 当前用户是否授权
     */
    isAuthorize:boolean=false;
    /**
     * 头像url
     */
    avatarUrl:string=null;
    /**
     * 昵称
     */
    nickName:string=null;
    /**
     * 是否是新用户
     */
    isNew:boolean=false;
    /**
     * 创建时间
     */
    createTime:any=null;

    /**
     * 渠道id
     */
    channelId:any=null;

    /**
     * 游戏版本号
     */
    version:string="1.0.0";

    /**
     * 获取存档中的实例
     */
    static get saved():LoginData{
        let data:LoginData=storage.getSavedData("loginData")
        if(!data){
            data=new LoginData()
            storage.setSavedData("loginData",data)
        }
        return data;
    }
}