import { SafeClass } from "../core/SafeData";
import core from "../core/Core";
import storage from "../core/StorageCenter";

export type ConsumeInfo={
	// 记录唯一id
	recordid?:string
	//钻石减少/新增原因
	reason:string
	//当前钻石数量
	current:number
	//钻石增加/减少数量
	diff:number
	//时间戳
	time?:number
	// 类型:钻石/金币等
	stuff?:number
	// 是增加还是减少
	isIncrease?:boolean
}

export type ConsumeInfoRaw={
	// 记录唯一id
	recordid?:string
	//减少/新增原因
	reason:string
	//当前数量
	current:number
	//增加/减少数量
	diff:number
	//时间戳
	time:number
	// 类型:钻石/金币等
	stuff:number
	// 是增加还是减少
	isIncrease:boolean

}

@SafeClass('ConsumeLog')
export class ConsumeLog{
	
	protected records:ConsumeInfoRaw[]=[]

	_curtimestamp=''
	_idindex:number=0
	/**
	 * 获取唯一的记录id
	 */
	protected genRecordID():string{
		let timestamp=core.serverTime.getTime().toString()
		if(timestamp!=this._curtimestamp){
			this._idindex=0
		}else{
			this._idindex++
		}
		let id=timestamp+'_'+this._idindex
		return id
	}

	/**
	 * 添加消费记录
	 * @param info 
	 */
	public addRecord(info:ConsumeInfoRaw){
		info.recordid=this.genRecordID()
		this.records.push(info)
	}

	/**
	 * 获取消费记录列表
	 */
	getRecords(){
		let data=JSON.stringify(this.records)
		return data
	}

	/**
	 * 清空消费记录
	 */
	clearRecords(){
		this.records=[]
	}
	
	/**
	 * 获取当前存档保存的实例
	 */
	static get saved():ConsumeLog{
        let data:ConsumeLog=storage.getSavedData("consumeLog")
        if(!data){
            data=new ConsumeLog()
            storage.setSavedData("consumeLog",data)
        }
        return data;
    }
}