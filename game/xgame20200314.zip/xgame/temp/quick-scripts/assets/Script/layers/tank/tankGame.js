(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/layers/tank/tankGame.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '02322D08fxF/qSyWUFtBRB9', 'tankGame', __filename);
// Script/layers/tank/tankGame.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Dialog_1 = require("../../core/Dialog");
var GlobalEmit_1 = require("../../core/GlobalEmit");
var tank_1 = require("./tank");
var bullet_1 = require("./bullet");
var tankControl_1 = require("./tankControl");
var Core_1 = require("../../core/Core");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Dir;
(function (Dir) {
    Dir[Dir["up"] = 1] = "up";
    Dir[Dir["down"] = 2] = "down";
    Dir[Dir["left"] = 3] = "left";
    Dir[Dir["right"] = 4] = "right";
})(Dir || (Dir = {}));
var tankGame = /** @class */ (function (_super) {
    __extends(tankGame, _super);
    function tankGame() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.root = null;
        _this.tank = null;
        _this.bullet = null;
        _this.gameLayer = null;
        _this.bulletArr = [];
        _this.bulletPool = [];
        _this.uniqueTag = 0;
        _this.bPlaying = false;
        _this.tankSpeed = 1.5;
        _this.player = null;
        return _this;
    }
    tankGame.prototype.onInit = function (data) {
    };
    tankGame.prototype.onload = function () {
    };
    tankGame.prototype.start = function () {
        cc.director.getCollisionManager().enabled = true;
        cc.director.getCollisionManager().enabledDebugDraw = true;
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyPressed, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyReleased, this);
    };
    tankGame.prototype.update = function (dt) {
        // 
        this.syncGameStatu();
        this.checkRunningBullet();
    };
    tankGame.prototype.onDestroy = function () {
        cc.director.getCollisionManager().enabled = false;
        cc.director.getCollisionManager().enabledDebugDraw = false;
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyPressed, this);
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyReleased, this);
    };
    tankGame.prototype.onClickClose = function () {
        GlobalEmit_1.default.instance.messageEmit.emit("CloseLayer", "tank");
        this.close();
    };
    tankGame.prototype.onClickStart = function () {
        this.gameStart();
    };
    tankGame.prototype.syncGameStatu = function () {
        this.bPlaying = tankControl_1.default.instance.gameStatu == tankControl_1.TankGame_Statu.playing;
    };
    tankGame.prototype.isPlaying = function () {
        return this.bPlaying;
    };
    tankGame.prototype.fire = function () {
        // 释放子弹
        var playerScript = this.player.getComponent(tank_1.default);
        if (!playerScript) {
            return;
        }
        var firePos = playerScript.getFirePos();
        var playerSp = playerScript.getLastSpeed();
        tankControl_1.default.instance.BornBullet(888, playerScript.getFirePos(), cc.v2(playerSp.x * 3, playerSp.y * 3));
    };
    tankGame.prototype.onKeyPressed = function (event) {
        var keyCode = event.keyCode;
        if (!this.isPlaying()) {
            return;
        }
        switch (keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                this.playerControl(Dir.left);
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                this.playerControl(Dir.right);
                break;
            case cc.macro.KEY.w:
            case cc.macro.KEY.up:
                this.playerControl(Dir.up);
                break;
            case cc.macro.KEY.s:
            case cc.macro.KEY.down:
                this.playerControl(Dir.down);
                break;
            case cc.macro.KEY.k:
                this.fire();
                break;
        }
    };
    tankGame.prototype.onKeyReleased = function (event) {
        var keyCode = event.keyCode;
        if (!this.isPlaying()) {
            return;
        }
        switch (keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                this.playerControl(Dir.left, true);
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                this.playerControl(Dir.right, true);
                break;
            case cc.macro.KEY.w:
            case cc.macro.KEY.up:
                this.playerControl(Dir.up, true);
                break;
            case cc.macro.KEY.s:
            case cc.macro.KEY.down:
                this.playerControl(Dir.down, true);
                break;
        }
    };
    tankGame.prototype.playerControl = function (value, bCancel) {
        if (!this.isPlaying()) {
            return;
        }
        var playerScript = this.player.getComponent(tank_1.default);
        if (!playerScript) {
            return;
        }
        var spx = playerScript.speed.x;
        var spy = playerScript.speed.y;
        //spx = spx==0?1:spx;
        //spy = spy==0?1:0;
        if (value == Dir.up) {
            spy = this.tankSpeed;
            if (bCancel) {
                spy = 0;
            }
            //playerScript.speed = cc.v2(playerScript.speed.x,Math.abs(playerScript.speed.y));
        }
        else if (value == Dir.down) {
            spy = -this.tankSpeed;
            if (bCancel) {
                spy = 0;
            }
            //playerScript.speed = cc.v2(playerScript.speed.x,-Math.abs(playerScript.speed.y));
        }
        else if (value == Dir.left) {
            spx = -this.tankSpeed;
            if (bCancel) {
                spx = 0;
            }
            //playerScript.speed = cc.v2(-Math.abs(playerScript.speed.x), playerScript.speed.y);
        }
        else if (value == Dir.right) {
            spx = this.tankSpeed;
            if (bCancel) {
                spx = 0;
            }
            //playerScript.speed = cc.v2(Math.abs(playerScript.speed.x), playerScript.speed.y);
        }
        playerScript.speed = cc.v2(spx, spy);
    };
    tankGame.prototype.runBullet = function (group, p, sp) {
        if (!this.isPlaying()) {
            console.error("game over,no more block");
            return;
        }
        var tempBullet = this.getBullet();
        tempBullet.active = true;
        tempBullet.parent = this.gameLayer;
        var bulletScript = tempBullet.getComponent(bullet_1.default);
        if (bulletScript) {
            bulletScript.tag = this.getUniqueTag();
            bulletScript.bValide = true;
            bulletScript.group = group;
            bulletScript.setPos(p);
            bulletScript.reSet();
            bulletScript.speed = sp;
            this.bulletArr.push(tempBullet);
        }
    };
    tankGame.prototype.resetBullet = function () {
        this.bulletArr = [];
        this.bulletPool = [];
    };
    tankGame.prototype.getUniqueTag = function () {
        this.uniqueTag++;
        return this.uniqueTag;
    };
    tankGame.prototype.getBullet = function () {
        if (this.bulletPool.length < 1) {
            var blockRobot = cc.instantiate(this.bullet);
            console.log("Tank new bullet~");
            return blockRobot;
        }
        else {
            var block = this.bulletPool.pop();
            console.log("Tank used bullet~");
            return block;
        }
    };
    tankGame.prototype.checkRunningBullet = function () {
        for (var index = 0; index < this.bulletArr.length; index++) {
            var blockNode = this.bulletArr[index];
            var blockScript = blockNode.getComponent(bullet_1.default);
            if (blockScript) {
                if (!blockScript.bValide) {
                    this.bulletPool.push(blockNode);
                    this.bulletArr.splice(index, 1);
                    break;
                }
            }
        }
    };
    tankGame.prototype.gameControl = function () {
        if (this.isPlaying()) {
            this.checkRunningBullet();
        }
    };
    tankGame.prototype.gameStart = function () {
        if (this.bPlaying) {
            Core_1.default.instance.toast("game playing");
            return;
        }
        this.bPlaying = true;
        tankControl_1.default.instance.gameStatu = tankControl_1.TankGame_Statu.playing;
        tankControl_1.default.instance.gameCenter = this.node;
        this.player = cc.instantiate(this.tank);
        this.player.parent = this.gameLayer;
        var tankScript = this.player.getComponent(tank_1.default);
        if (tankScript) {
            tankScript.bSelf = true;
            tankScript.bValide = true;
            tankScript.group = 888;
            tankScript.tag = this.getUniqueTag();
            tankScript.speed = cc.v2(0, 1);
            tankScript.setPos(cc.v2(cc.winSize.width / 2, cc.winSize.height / 2));
        }
    };
    tankGame.prototype.gameOver = function () {
        this.bPlaying = false;
        tankControl_1.default.instance.gameCenter = null;
        tankControl_1.default.instance.gameStatu = tankControl_1.TankGame_Statu.over;
        this.resetBullet();
        Core_1.default.instance.toast("游戏结束~");
    };
    __decorate([
        property(cc.Node)
    ], tankGame.prototype, "root", void 0);
    __decorate([
        property(cc.Node)
    ], tankGame.prototype, "tank", void 0);
    __decorate([
        property(cc.Node)
    ], tankGame.prototype, "bullet", void 0);
    __decorate([
        property(cc.Node)
    ], tankGame.prototype, "gameLayer", void 0);
    tankGame = __decorate([
        ccclass
    ], tankGame);
    return tankGame;
}(Dialog_1.default));
exports.default = tankGame;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=tankGame.js.map
        