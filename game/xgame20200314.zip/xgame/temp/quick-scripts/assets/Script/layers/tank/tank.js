(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/layers/tank/tank.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e441aIHRhREd5dCqsUnf/ut', 'tank', __filename);
// Script/layers/tank/tank.ts

Object.defineProperty(exports, "__esModule", { value: true });
var bullet_1 = require("./bullet");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var tank = /** @class */ (function (_super) {
    __extends(tank, _super);
    function tank() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._speed = cc.v2(0, 0);
        _this.bValide = true;
        _this.bSelf = false;
        _this.tag = 0;
        _this.group = 0;
        _this.lastSpeed = cc.v2(0, 1);
        _this.tankRadius = 32;
        _this.bulletRadius = 16;
        _this.tankImage = null;
        return _this;
    }
    tank_1 = tank;
    tank.prototype.onload = function () {
    };
    tank.prototype.start = function () {
        var collider = this.getComponent(cc.CircleCollider);
        if (!collider) {
            return;
        }
        //this.schedule(this.checkTankMove,1);
    };
    tank.prototype.checkTankMove = function () {
        if (this.bValide) {
            this.node.x += this._speed.x;
            this.node.y += this._speed.y;
        }
    };
    tank.prototype.update = function (dt) {
        this.checkTankMove();
        if (!(this.speed.x == 0 && this.speed.y == 0)) {
            this.tankImage.rotation = this.getDirOffset();
            this.lastSpeed = this.speed;
        }
    };
    tank.prototype.onDestroy = function () {
    };
    // 返回资源的旋转角度
    tank.prototype.getDirOffset = function () {
        if (!this._speed) {
            return 0;
        }
        if (this._speed.x == 0 && this._speed.y == 0) {
            return 0;
        }
        //获取相对于x轴正轴的偏转弧度
        var offHd = Math.atan2(this._speed.y, this._speed.x);
        // 偏转角度
        var offJd = (offHd * 180) / Math.PI;
        // 旋转角度
        if (offJd >= 0) {
            if (offJd <= 90) {
                return 90 - offJd;
            }
            else {
                return 360 - offJd + 90;
            }
        }
        else {
            return -offJd + 90;
        }
    };
    Object.defineProperty(tank.prototype, "speed", {
        get: function () {
            return this._speed;
        },
        set: function (value) {
            //console.log("tank setSpeed x: "+value.x+" y: "+value.y);
            this._speed = value;
        },
        enumerable: true,
        configurable: true
    });
    tank.prototype.setPos = function (p) {
        this.node.x = p.x;
        this.node.y = p.y;
    };
    tank.prototype.getLastSpeed = function () {
        return this.lastSpeed;
    };
    tank.prototype.getFirePos = function () {
        var radius = Math.sqrt(Math.abs(this.lastSpeed.x * this.lastSpeed.x) + Math.abs(this.lastSpeed.y * this.lastSpeed.y));
        var addRadius = this.tankRadius + this.bulletRadius + 5;
        return cc.v2(this.node.x + (this.lastSpeed.x * addRadius) / radius, this.node.y + (this.lastSpeed.y * addRadius) / radius);
    };
    tank.prototype.getNowPos = function () {
        return cc.v2(this.node.x, this.node.y);
        //return cc.v2(Math.floor(this.node.x), Math.floor(this.node.y));
    };
    tank.prototype.onCollisionEnter = function (other, self) {
        console.log("tank collision enter");
        // 1st step 
        // get pre aabb, go back before collision
        var otherAabb = other.world.aabb;
        var otherPreAabb = other.world.preAabb.clone();
        var selfAabb = self.world.aabb;
        var selfPreAabb = self.world.preAabb.clone();
    };
    tank.prototype.onCollisionStay = function (other, self) {
        console.log("tank collision stay");
    };
    tank.prototype.onCollisionExit = function (other) {
        console.log("tank collision exit");
    };
    tank.prototype.collision = function (collNode) {
        var tankScript = collNode.getComponent(tank_1);
        if (tankScript) {
            if (tankScript.group == this.group) {
                return;
            }
            else {
                this.bValide = false;
            }
        }
        var bulletScript = collNode.getComponent(bullet_1.default);
        if (bulletScript) {
            if (bulletScript.group == this.group) {
                return;
            }
            else {
                this.bValide = false;
            }
        }
    };
    tank.prototype.checkImage = function () {
        var imageNode = this.node.getChildByName("image");
        if (imageNode) {
        }
    };
    var tank_1;
    __decorate([
        property(cc.Node)
    ], tank.prototype, "tankImage", void 0);
    tank = tank_1 = __decorate([
        ccclass
    ], tank);
    return tank;
}(cc.Component));
exports.default = tank;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=tank.js.map
        