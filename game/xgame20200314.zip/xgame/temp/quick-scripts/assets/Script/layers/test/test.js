(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/layers/test/test.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '403b7s+lzZKAo2X4bIMHxX3', 'test', __filename);
// Script/layers/test/test.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Dialog_1 = require("../../core/Dialog");
var GlobalEmit_1 = require("../../core/GlobalEmit");
var Core_1 = require("../../core/Core");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var test = /** @class */ (function (_super) {
    __extends(test, _super);
    function test() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    //@property(cc.Label)
    //label: cc.Label = null;
    test.prototype.onInit = function (data) {
    };
    test.prototype.onload = function () {
    };
    test.prototype.onEnable = function () {
        //cc.director.getCollisionManager().enabled = true;
        //cc.director.getCollisionManager().enabledDebugDraw = true;
        //cc.director.getCollisionManager().enabledDrawBoundingBox = true;
    };
    test.prototype.onDisable = function () {
        //cc.director.getCollisionManager().enabled = false;
        //cc.director.getCollisionManager().enabledDebugDraw = false;
        //cc.director.getCollisionManager().enabledDrawBoundingBox = false;
    };
    test.prototype.start = function () {
    };
    test.prototype.update = function (dt) {
        // 
    };
    test.prototype.onDestroy = function () {
    };
    test.prototype.onClickClose = function () {
        GlobalEmit_1.default.instance.messageEmit.emit("CloseLayer", "test");
        Core_1.default.instance.closeLayer("prefabs/test");
        //this.close();
    };
    test = __decorate([
        ccclass
    ], test);
    return test;
}(Dialog_1.default));
exports.default = test;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=test.js.map
        