(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/layers/frappy/fra_follow.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'bd5b8SbPoJOpr27i27KBwOi', 'fra_follow', __filename);
// Script/layers/frappy/fra_follow.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var fra_follow = /** @class */ (function (_super) {
    __extends(fra_follow, _super);
    function fra_follow() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.target = null;
        return _this;
    }
    // use this for initialization
    fra_follow.prototype.onLoad = function () {
    };
    fra_follow.prototype.start = function () {
        // 由于需要键盘操作所以只能在 PC 才可用
        this.node.active = !cc.sys.isMobile || CC_PREVIEW;
        if (!this.target) {
            return;
        }
        var follow = cc.follow(this.target, cc.rect(0, 0, 4000, 750));
        this.node.runAction(follow);
    };
    __decorate([
        property(cc.Node)
    ], fra_follow.prototype, "target", void 0);
    fra_follow = __decorate([
        ccclass
    ], fra_follow);
    return fra_follow;
}(cc.Component));
exports.default = fra_follow;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=fra_follow.js.map
        