(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/layers/frappyunlimit/block.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '34f96lpAjBFxoxO/LxkPhIk', 'block', __filename);
// Script/layers/frappyunlimit/block.ts

Object.defineProperty(exports, "__esModule", { value: true });
var frappymanager_1 = require("./frappymanager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var block = /** @class */ (function (_super) {
    __extends(block, _super);
    function block() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.bValide = true;
        _this.tag = 0;
        _this.moveSpeed = -5;
        _this.endPosX = -750;
        _this.prePx = 0;
        _this.prePy = 0;
        return _this;
    }
    block.prototype.onload = function () {
    };
    block.prototype.start = function () {
        var collider = this.getComponent(cc.BoxCollider);
        if (!collider) {
            return;
        }
        this.scheduleOnce(this.printPos, 1);
    };
    block.prototype.update = function (dt) {
        if (this.isPlaying() && this.tag != 0) {
            this.robotRun();
        }
    };
    block.prototype.isPlaying = function () {
        return (frappymanager_1.default.instance.gameStatu == frappymanager_1.Frappy_Statu.playing);
    };
    block.prototype.onDestroy = function () {
    };
    block.prototype.printPos = function () {
        var _this = this;
        this.schedule(function () {
            if (Math.floor(_this.prePx) == Math.floor(_this.node.x) && Math.floor(_this.prePy) == Math.floor(_this.node.y)) {
            }
            else {
                console.log("tag: " + _this.tag + " Px: " + Math.floor(_this.node.x) + " Py: " + Math.floor(_this.node.y));
                _this.prePx = _this.node.x;
                _this.prePy = _this.node.y;
            }
        }, 1);
    };
    block.prototype.resetPos = function (px, py) {
        this.node.x = px;
        this.node.y = py;
        console.log("resetPos tag: " + this.tag + " Px: " + Math.floor(this.node.x) + " Py: " + Math.floor(this.node.y));
    };
    block.prototype.getNowPos = function () {
        return cc.v2(Math.floor(this.node.x), Math.floor(this.node.y));
    };
    block.prototype.robotRun = function () {
        if (this.bValide) {
            this.node.active = true;
            this.node.x += this.moveSpeed;
            this.checkValide();
        }
        else {
            this.node.active = false;
        }
    };
    block.prototype.checkValide = function () {
        //this.bValide = (this.node.x<this.endPosX);
        var dis = this.node.x - this.endPosX;
        this.bValide = dis > 0 ? true : false;
    };
    block = __decorate([
        ccclass
    ], block);
    return block;
}(cc.Component));
exports.default = block;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=block.js.map
        