(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/core/Core.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a53f83S639OoaqgIRmVufWl', 'Core', __filename);
// Script/core/Core.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Scene_1 = require("./Scene");
var Dialog_1 = require("./Dialog");
var Log_1 = require("./Log");
var log = new Log_1.default({ tags: ["core"] });
var SceneData = /** @class */ (function () {
    function SceneData(name, data) {
        this._index = SceneData.index;
        this._name = name;
        this._data = data;
    }
    Object.defineProperty(SceneData, "index", {
        get: function () {
            return ++this._index;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SceneData.prototype, "index", {
        get: function () {
            return this._index;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SceneData.prototype, "name", {
        get: function () {
            return this._name;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SceneData.prototype, "data", {
        get: function () {
            return this._data;
        },
        enumerable: true,
        configurable: true
    });
    SceneData._index = 0;
    return SceneData;
}());
exports.SceneData = SceneData;
var LayerType;
(function (LayerType) {
    LayerType[LayerType["FLOAT"] = 0] = "FLOAT";
    LayerType[LayerType["INFO"] = 1] = "INFO";
    LayerType[LayerType["DEBUG"] = 2] = "DEBUG";
})(LayerType = exports.LayerType || (exports.LayerType = {}));
var EventType = /** @class */ (function () {
    function EventType() {
    }
    /**
     * 界面初始化完成
     */
    EventType.INIT = "onInit";
    return EventType;
}());
exports.EventType = EventType;
var LayerData = /** @class */ (function () {
    function LayerData(prefab, data, node, layerType, url) {
        this._index = SceneData.index;
        this._prefab = prefab;
        this._data = data;
        this._node = node;
        this._layerType = layerType;
        this._url = url;
    }
    Object.defineProperty(LayerData, "index", {
        get: function () {
            return ++this._index;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LayerData.prototype, "index", {
        get: function () {
            return this._index;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LayerData.prototype, "url", {
        get: function () {
            return this._url;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LayerData.prototype, "prefab", {
        get: function () {
            return this._prefab;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LayerData.prototype, "data", {
        get: function () {
            return this._data;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LayerData.prototype, "node", {
        get: function () {
            return this._node;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LayerData.prototype, "layerType", {
        get: function () {
            return this._layerType;
        },
        enumerable: true,
        configurable: true
    });
    LayerData._index = 0;
    return LayerData;
}());
exports.LayerData = LayerData;
/**
 * 界面框架 核心类 用于管理界面等
 */
var Core = /** @class */ (function (_super) {
    __extends(Core, _super);
    function Core() {
        var _this = _super.call(this) || this;
        _this.allScreenLayerNum = 0;
        _this._isShowed = true;
        _this._loadingIndex = 0;
        _this.bgSp = null;
        _this.toastOffset = cc.p(0, 0);
        _this._sceneList = new Array();
        _this._layerList = new Array();
        _this._showLoadingModalCallback = null; //显示模态化遮挡层
        _this._closeLoadingModalCallback = null; //隐藏模态遮挡层
        cc.game.on(cc.game.EVENT_SHOW, function () {
            if (_this._isShowed == false) {
                _this.emit(Core.SHOW);
                _this._isShowed = true;
            }
        });
        cc.game.on(cc.game.EVENT_HIDE, function () {
            if (_this._isShowed) {
                _this.emit(Core.HIDE);
                _this._isShowed = false;
            }
        });
        return _this;
    }
    Object.defineProperty(Core, "instance", {
        get: function () {
            if (!this._instance)
                this._instance = new Core();
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    ;
    Object.defineProperty(Core.prototype, "isShowed", {
        get: function () {
            return this._isShowed;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Core.prototype, "loadingIndex", {
        get: function () {
            return this._loadingIndex++;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * 初始化场景，构建基础图层
     * 浮动层
     * 信息层
     * debug层
     */
    Core.prototype.init = function () {
        if (this._floatLayer) {
            return;
        }
        log.info("initialize Scene");
        var nowScene = cc.director.getScene();
        this._floatLayer = new cc.Node("floatLayer");
        this._infoLayer = new cc.Node("infoLayer");
        this._debugLayer = new cc.Node("debugLayer");
        nowScene.addChild(this._floatLayer, 100);
        nowScene.addChild(this._infoLayer, 200);
        nowScene.addChild(this._debugLayer, 300);
        cc.game.addPersistRootNode(this._floatLayer);
        cc.game.addPersistRootNode(this._infoLayer);
        cc.game.addPersistRootNode(this._debugLayer);
        log.info("Scene init complete");
    };
    Core.prototype.openScene = function (scene, callback) {
        var _this = this;
        if (callback === void 0) { callback = null; }
        var index = this.loadingIndex;
        if (this._showLoadingModalCallback)
            this._showLoadingModalCallback(index, scene.name);
        return cc.director.loadScene(scene.name, function () {
            //对场景进行数据绑定
            var newScene = cc.director.getScene();
            var sceneComponents = newScene.getComponents(Scene_1.default);
            for (var _i = 0, sceneComponents_1 = sceneComponents; _i < sceneComponents_1.length; _i++) {
                var comp = sceneComponents_1[_i];
                comp.data = scene.data;
                comp.onInit(scene.data);
            }
            //执行场景初始化
            newScene.dispatchEvent(new cc.Event.EventCustom(EventType.INIT, false));
            if (_this._closeLoadingModalCallback)
                _this._closeLoadingModalCallback(index, scene.name);
            if (callback) {
                callback();
            }
        });
    };
    /**
     * 压入场景
     */
    Core.prototype.pushScene = function (name, data, callback) {
        if (callback === void 0) { callback = null; }
        var scene = new SceneData(name, data);
        this._sceneList.push(scene);
        var result = this.openScene(scene, callback);
        return scene;
    };
    /**
     * 弹出场景
     */
    Core.prototype.popScene = function (callback) {
        if (callback === void 0) { callback = null; }
        //已经是顶部场景
        if (this._sceneList.length <= 1) {
            if (cc.director.getScene()) {
                //cc.director.popScene()
            }
            log.warn("no available scenes");
            return null;
        }
        this._sceneList.pop();
        var scene = this._sceneList[this._sceneList.length - 1];
        var result = this.openScene(scene, callback);
        return scene;
    };
    /**
     * 切换场景
     */
    Core.prototype.replaceScene = function (name, data, callback) {
        if (callback === void 0) { callback = null; }
        this.popScene();
        return this.pushScene(name, data, callback);
    };
    Object.defineProperty(Core.prototype, "currentScene", {
        /**
         * 获取当前的场景
         */
        get: function () {
            return this._sceneList[this._sceneList.length - 1];
        },
        enumerable: true,
        configurable: true
    });
    /**
     * 通过预制资源 显示图层
     */
    Core.prototype.showLayerPrefab = function (prefab, data, modalWindow, layer, url) {
        var _this = this;
        if (modalWindow === void 0) { modalWindow = true; }
        if (layer === void 0) { layer = LayerType.FLOAT; }
        if (url === void 0) { url = null; }
        var node = cc.instantiate(prefab);
        var size = cc.director.getWinSize();
        size = cc.winSize;
        if (modalWindow) {
            //初始模态背景
            var bg = new cc.Node("modalBg");
            bg.setContentSize(size.width, size.height);
            bg.addComponent(cc.Button);
            node.addChild(bg, -1);
            // var graphics=bg.addComponent(cc.Graphics)
            // graphics.fillColor=new cc.Color(0,0,0,Math.ceil(256*0.8-0.9))
            // graphics.fillRect(0,0,size.width,size.height)
            // bg.scale=5;
            // cc.Node['touchNum'] = 0;
            var sprite_1 = bg.addComponent(cc.Sprite);
            sprite_1.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            sprite_1.type = cc.Sprite.Type.SLICED;
            if (!this.bgSp) {
                cc.loader.loadRes("image/common/splash", cc.SpriteFrame, function (err, sf) {
                    if (!err) {
                        sprite_1.spriteFrame = sf;
                        _this.bgSp = sf;
                    }
                });
            }
            else {
                sprite_1.spriteFrame = this.bgSp;
            }
            bg.color = cc.color(0, 0, 0, 255);
            bg.opacity = Math.ceil(256 * 0.8 - 0.9);
            bg.setContentSize(cc.size(2000, 2000));
        }
        var dialogComponents = node.getComponents(Dialog_1.default);
        node.setPosition((size.width) / 2, (size.height) / 2);
        for (var _i = 0, dialogComponents_1 = dialogComponents; _i < dialogComponents_1.length; _i++) {
            var comp = dialogComponents_1[_i];
            if (comp.allowModifyPosition) {
                node.setPosition((size.width) / 2 + node.x, (size.height) / 2 + node.y);
                break;
            }
        }
        //绑定数据
        for (var _a = 0, dialogComponents_2 = dialogComponents; _a < dialogComponents_2.length; _a++) {
            var comp = dialogComponents_2[_a];
            comp.data = data;
            comp.onInit(data);
        }
        switch (layer) {
            case LayerType.FLOAT:
                this._floatLayer.addChild(node);
                break;
            case LayerType.INFO:
                this._infoLayer.addChild(node);
                break;
            case LayerType.DEBUG:
                this._debugLayer.addChild(node);
                break;
        }
        //默认第一个是打开动画
        /*
        var anim = node.getComponent(cc.Animation) || node.getComponentInChildren(cc.Animation)
        if (anim != null) {
            // 播放打开动画
            var animclip:cc.AnimationClip=null
            // 优先采用内定值
            animclip=node.getComponent(Dialog).openAnim
            if(animclip){
                if(!anim.getClips().find(item=>item && item.name==animclip.name)){
                    if(anim.getClips().length==1){
                        // 避免填入第二个
                        anim['_clips'].push(null)
                    }
                    anim.addClip(animclip)
                }
            }else{
                animclip=anim.getClips()[0]
            }

            if(animclip){
                anim.stop()
                anim.playAdditive(animclip.name)
            }
        }*/
        //绑定数据
        for (var _b = 0, dialogComponents_3 = dialogComponents; _b < dialogComponents_3.length; _b++) {
            var comp = dialogComponents_3[_b];
            comp['_onInit']();
        }
        var layerData = new LayerData(prefab, data, node, layer, url);
        this._layerList.push(layerData);
        return layerData;
    };
    Core.prototype.showLayer = function (url, _a) {
        var _this = this;
        var _b = _a === void 0 ? { modalWindow: true, layer: LayerType.FLOAT } : _a, data = _b.data, modalWindow = _b.modalWindow, layer = _b.layer, callback = _b.callback;
        if (this.isLayerShown(url)) {
            console.warn(url + " is already opened");
            return;
        }
        var index = this.loadingIndex;
        if (this._showLoadingModalCallback)
            this._showLoadingModalCallback(index, url);
        cc.loader.loadRes(url, function (err, prefab) {
            if (!prefab || prefab instanceof cc.Prefab == false) {
                log.error("无法找到对话框", url);
                if (_this._closeLoadingModalCallback)
                    _this._closeLoadingModalCallback(index, url);
                _this.resLoadRetry(function () {
                    _this.showLayer(url, { data: data, modalWindow: modalWindow, layer: layer, callback: callback });
                });
                return;
            }
            if (_this._closeLoadingModalCallback)
                _this._closeLoadingModalCallback(index, url);
            if (prefab) {
                var l = _this.showLayerPrefab(prefab, data, modalWindow, layer, url);
                if (callback) {
                    callback(l);
                }
            }
            else {
                log.error(err);
            }
        });
    };
    Core.prototype.wxGC = function () {
    };
    Core.prototype.isLayerShown = function (data) {
        var layerData = this._layerList.where(function (a) { return a.url == data; }).single;
        return !!layerData;
    };
    /**
     * 关闭图层
     */
    Core.prototype.closeLayer = function (data) {
        var layerData;
        if (typeof data == "number") {
            layerData = this._layerList.where(function (a) { return a.index == data; }).single;
        }
        else if (typeof data == "string") {
            layerData = this._layerList.where(function (a) { return a.url == data; }).single;
        }
        else if (data instanceof LayerData) {
            layerData = data;
        }
        else if (data instanceof cc.Node) {
            layerData = this._layerList.where(function (a) { return a.node == data; }).single;
        }
        if (!layerData) {
            log.warn("no layer", data);
            return;
        }
        var isValidAnim = false;
        /*
        // 优先采用内定动画
        var anim = layerData.node.getComponent(cc.Animation) || layerData.node.getComponentInChildren(cc.Animation)
        var animclip=null
            //默认第2个是打开动画
        if (anim != null) {
            animclip = layerData.node.getComponent(Dialog).closeAnim
            if(!animclip){
                if(anim.getClips().length>=2 && anim.getClips()[1]){
                    let state=anim.getAnimationState(anim.getClips()[1].name)
                    if(state.repeatCount!=Infinity && state.duration<2){
                        isValidAnim=true
                    }else{
                        // console.warn('关闭对话框时,第二个动画为无限循环动画或者时长超过2秒,则不使用第二个动画作为关闭动画')
                    }
                }
            }else{
                isValidAnim=true
            }

            if(isValidAnim){
                animclip=animclip || anim.getClips()[1]
                if(!anim.getClips().find(info=>info && info.name==animclip.name)){
                    if(anim.getClips().length==0){
                        anim['_clips'].push(null)
                    }
                    anim.addClip(animclip)
                }
            }
        }
        if(isValidAnim){
            anim.play(animclip.name)
            anim.once("finished", ()=>{
                // layerData.node.removeFromParent(true);
                layerData.node.destroy()
                this._layerList.remove(layerData)
                // cc.Node['touchNum'] =0;
            })
        }else{
            // layerData.node.removeFromParent(true);
            layerData.node.destroy()
            this._layerList.remove(layerData)
            // cc.Node['touchNum'] =0;
        }
        */
        layerData.node.destroy();
        this._layerList.remove(layerData);
    };
    Core.prototype.closeAllLayer = function () {
        var excludeLayer = {
            "prefabs/dialogs/Loading": 1,
            "prefabs/dialogs/DGuide2": 1
        };
        for (var i = this._layerList.length - 1; i >= 0; --i) {
            if (!excludeLayer[this._layerList[i].url]) {
                this.closeLayer(this._layerList[i].url);
            }
        }
    };
    Object.defineProperty(Core.prototype, "showModalCallback", {
        set: function (callback) {
            this._showLoadingModalCallback = callback;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Core.prototype, "closeModalCallback", {
        set: function (callback) {
            this._closeLoadingModalCallback = callback;
        },
        enumerable: true,
        configurable: true
    });
    Core.prototype.getLayerList = function () {
        return this._layerList.concat();
    };
    /**
     * 弹出简单信息 结束后关闭
     */
    Core.prototype.toast = function (text, _a) {
        var _this = this;
        var _b = _a === void 0 ? { prefab: "prefabs/toast", icon: null } : _a, prefab = _b.prefab, icon = _b.icon;
        cc.loader.loadRes(prefab, cc.Prefab, function (err, prefab) {
            if (!prefab || prefab instanceof cc.Prefab == false) {
                log.error("无法找到对话框" + prefab);
                return;
            }
            //显示图层
            var layer = _this.showLayerPrefab(prefab, {}, false, LayerType.INFO);
            //进行toast 偏移
            layer.node.x += _this.toastOffset.x;
            layer.node.y += _this.toastOffset.y;
            //设置节点大小
            var rootNode = cc.find("root", layer.node);
            cc.assert(rootNode);
            var labelNode = cc.find("root/label", layer.node);
            var iconNode = cc.find("root/icon", layer.node);
            var bgNode = cc.find("root/bg", layer.node);
            if (labelNode) {
                var label = labelNode.getComponent(cc.Label);
                if (label) {
                    label.string = text;
                    setTimeout(function () {
                        var size = label.node.getContentSize();
                        size.width += 20;
                        size.height += 20;
                        if (bgNode) {
                            bgNode.setContentSize(size);
                        }
                    }, 0);
                }
                var richText = labelNode.getComponent(cc.RichText);
                if (richText) {
                    richText.string = text;
                    setTimeout(function () {
                        var size = richText.node.getContentSize();
                        size.width += 20;
                        size.height += 20;
                        if (bgNode) {
                            bgNode.setContentSize(size);
                        }
                    }, 0);
                }
            }
            if (iconNode && icon) {
                var sprite = iconNode.getComponent(cc.Sprite);
                if (sprite) {
                    sprite.spriteFrame = icon;
                }
            }
            if (rootNode) {
                var anim = rootNode.getComponent(cc.Animation);
                if (anim) {
                    var onFinished = function (e) {
                        anim.off("finished", onFinished);
                        _this.closeLayer(layer);
                    };
                    anim.once("finished", onFinished);
                    var stat = anim.play("ToastClip");
                }
                else {
                    setTimeout(function () {
                        _this.closeLayer(layer);
                    }, 1000);
                }
            }
        });
    };
    Core.prototype.resLoadRetry = function (retry) {
        this.showDialog('network_error', function () {
            retry();
        });
    };
    /**
     * 打开对话框
     */
    Core.prototype.showDialog = function (message, callback, _a) {
        var _b = _a === void 0 ? { title: "友情提示", okText: "确定", cancelText: "取消", cancelable: false } : _a, title = _b.title, okText = _b.okText, cancelText = _b.cancelText, cancelable = _b.cancelable;
        if (false) {
            // vivo信息弹出框
            qg.showDialog({
                title: title || "友情提示",
                message: message,
                buttons: [
                    {
                        text: okText || "确定",
                        color: "#33dd44"
                    },
                    {
                        text: cancelText || "取消",
                        color: "#33dd44"
                    }
                ],
                success: function (data) {
                    if (data && data.index) {
                        console.log("vivo 弹窗选择按钮序号: " + data.index);
                    }
                    if (cancelable) {
                        callback((data && data.index == 1));
                    }
                    else {
                        callback(true);
                    }
                },
                cancel: function () {
                    console.log("vivo 弹窗选择 取消");
                    callback(true);
                },
                fail: function (data, code) {
                    console.error("vivo 弹窗选择 失败");
                    callback(false);
                }
            });
        }
        else {
            //系统默认弹框
            if (cancelable) {
                callback(confirm(message));
            }
            else {
                alert(message);
                callback(true);
            }
        }
    };
    //事件
    Core.SHOW = "show";
    Core.HIDE = "hide";
    return Core;
}(cc.EventTarget));
exports.default = Core;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Core.js.map
        