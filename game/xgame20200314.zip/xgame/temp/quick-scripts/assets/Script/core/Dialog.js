(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/core/Dialog.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '895923KQktG2IoIDMGY2M1r', 'Dialog', __filename);
// Script/core/Dialog.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Core_1 = require("./Core");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Dialog = /** @class */ (function (_super) {
    __extends(Dialog, _super);
    function Dialog() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // @property({
        //     tooltip:'启用缓存'
        // })
        // retain:boolean=false
        _this.allowModifyPosition = false;
        _this.openAnim = null;
        _this.closeAnim = null;
        _this.loopBGAnim = [];
        return _this;
    }
    Object.defineProperty(Dialog.prototype, "data", {
        get: function () {
            return this._data;
        },
        set: function (value) {
            this._data = value;
        },
        enumerable: true,
        configurable: true
    });
    Dialog.prototype._onInit = function () {
        var anim = this.node.getComponent(cc.Animation) || this.node.getComponentInChildren(cc.Animation);
        if (anim != null) {
            if (anim.getClips().length < 2) {
                anim['_clips'].push(null);
            }
            if (anim.getClips().length < 2) {
                anim['_clips'].push(null);
            }
            var _loop_1 = function (animclip) {
                if (!anim.getClips().find(function (item) { return item && item.name == animclip.name; })) {
                    anim.addClip(animclip);
                }
                anim.playAdditive(animclip.name);
            };
            for (var _i = 0, _a = this.loopBGAnim; _i < _a.length; _i++) {
                var animclip = _a[_i];
                _loop_1(animclip);
            }
        }
    };
    /**
     * 当界面加载完成后执行，界面数据由此传入
     * @param data
     */
    Dialog.prototype.onInit = function (data) {
    };
    Dialog.prototype.close = function () {
        Core_1.default.instance.closeLayer(this.node);
        this.onClose();
    };
    Dialog.prototype.onClose = function () {
    };
    Dialog.prototype.播放点击音效 = function () {
        return this.playClickEffect();
    };
    Dialog.prototype.playClickEffect = function () {
    };
    Dialog.prototype.关闭对话框 = function () {
        return this.close();
    };
    __decorate([
        property({
            tooltip: '使用自定义位置',
            displayName: '使用自定义位置',
        })
    ], Dialog.prototype, "allowModifyPosition", void 0);
    __decorate([
        property({
            tooltip: '弹出动画',
            type: cc.AnimationClip,
            displayName: '弹出动画',
        })
    ], Dialog.prototype, "openAnim", void 0);
    __decorate([
        property({
            tooltip: '关闭动画',
            type: cc.AnimationClip,
            displayName: '关闭动画',
        })
    ], Dialog.prototype, "closeAnim", void 0);
    __decorate([
        property({
            tooltip: '背景动画',
            type: [cc.AnimationClip],
            displayName: '背景动画',
        })
    ], Dialog.prototype, "loopBGAnim", void 0);
    Dialog = __decorate([
        ccclass
    ], Dialog);
    return Dialog;
}(cc.Component));
exports.default = Dialog;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Dialog.js.map
        