(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Info.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '0231bfrFOFP3bU5HBEHFodw', 'Info', __filename);
// Script/Info.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * info
 */
var GameInfo = /** @class */ (function () {
    function GameInfo() {
        this.mode = "release";
        this.version = "1.0.1";
        this.resVersion = 25;
    }
    return GameInfo;
}());
var Info = GameInfo;
exports.default = new Info();

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Info.js.map
        