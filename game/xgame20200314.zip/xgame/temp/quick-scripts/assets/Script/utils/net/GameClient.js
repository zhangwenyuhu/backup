(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/utils/net/GameClient.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '1e0effKetRP7ZxeD2fxvykI', 'GameClient', __filename);
// Script/utils/net/GameClient.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameClient = /** @class */ (function () {
    function GameClient() {
        this._serverTimeOffset = 0; //与服务器的时间差
        this._protocol = "https"; //协议
        this._host = "localhost"; //主机名
        this._port = 443; //端口号
        this._openId = '';
        this._showLoadingModalCallback = null; //显示模态化遮挡层
        this._closeLoadingModalCallback = null; //隐藏模态遮挡层
    }
    /**
     * 设置服务器推送的消息回调
     */
    GameClient.prototype.setMessageCallback = function (callback) {
        this._messageCallback = callback;
    };
    /**
     * 当发生错误时的统一回调
     */
    GameClient.prototype.setErrorCallback = function (callback) {
        this._errorCallback = callback;
    };
    /**
     * 设置断开连接回调
     */
    GameClient.prototype.setDisconnectCallback = function (callback) {
        this._disconnectCallback = callback;
    };
    Object.defineProperty(GameClient.prototype, "roleId", {
        get: function () {
            return this._roleId;
        },
        set: function (value) {
            this._roleId = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameClient.prototype, "token", {
        get: function () {
            return this._token;
        },
        set: function (value) {
            this._token = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameClient.prototype, "serverTimeOffset", {
        get: function () {
            return this._serverTimeOffset;
        },
        set: function (value) {
            this._serverTimeOffset = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameClient.prototype, "host", {
        get: function () {
            return this._host;
        },
        set: function (value) {
            this._host = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameClient.prototype, "port", {
        get: function () {
            return this._port;
        },
        set: function (value) {
            this._port = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameClient.prototype, "protocol", {
        get: function () {
            return this._protocol;
        },
        set: function (value) {
            this._protocol = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameClient.prototype, "openId", {
        get: function () {
            return this._openId;
        },
        set: function (value) {
            this._openId = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameClient.prototype, "serverTime", {
        /**
         * 获取当前服务器时间
         */
        get: function () {
            return new Date(new Date().getTime() + this._serverTimeOffset);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameClient.prototype, "showModalCallback", {
        set: function (callback) {
            this._showLoadingModalCallback = callback;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameClient.prototype, "closeModalCallback", {
        set: function (callback) {
            this._closeLoadingModalCallback = callback;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GameClient.prototype, "sslHandShakeErrorCallBack", {
        set: function (callback) {
            this._sslHandShakeErrorCallBack = callback;
        },
        enumerable: true,
        configurable: true
    });
    return GameClient;
}());
exports.default = GameClient;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GameClient.js.map
        