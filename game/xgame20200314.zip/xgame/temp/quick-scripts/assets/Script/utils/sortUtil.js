(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/utils/sortUtil.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '3f0bdviZIlJKovXL3GGhKq3', 'sortUtil', __filename);
// Script/utils/sortUtil.ts

Object.defineProperty(exports, "__esModule", { value: true });
var sortUtil = /** @class */ (function () {
    function sortUtil() {
    }
    Object.defineProperty(sortUtil, "instance", {
        get: function () {
            if (!this._instance) {
                this._instance = new sortUtil();
            }
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    sortUtil.prototype.test = function () {
        var a = [12, 3, 6, 2, 9, 4, 1, 8, 7, 19, 15, 13, 16, 18, 28, 26, 27, 33, 38, 35, 37, 36, 32, 31, 5, 6, 8, 2, 99, 100, 85, 62, 72, 1];
        a = this.s_bubble(a);
    };
    // 冒泡
    sortUtil.prototype.s_bubble = function (arr) {
        var len = arr.length;
        var tmp = 0;
        for (var i = 0; i < len; i++) {
            for (var j = i + 1; j < len; j++) {
                if (arr[i] > arr[j]) {
                    tmp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = tmp;
                }
            }
        }
        return arr;
    };
    // 快速
    sortUtil.prototype.s_quick = function (arr) {
        var qUpSort = function (resArr, left, right) {
            if (right <= left) {
                console.log("sort end left: " + left + " right: " + right);
                return;
            }
            var initLeft = left;
            var initRight = right;
            var keyNum = resArr[left];
            while (right > left) {
                while (right > left && resArr[right] > keyNum) {
                    right--;
                }
                resArr[left] = resArr[right];
                resArr[right] = keyNum;
                while (right > left && resArr[left] < keyNum) {
                    left++;
                }
                resArr[right] = resArr[left];
                resArr[left] = keyNum;
            }
            qUpSort(resArr, initLeft, left - 1);
            qUpSort(resArr, left + 1, initRight);
        };
        qUpSort(arr, 0, arr.length);
        return arr;
    };
    return sortUtil;
}());
exports.default = sortUtil;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=sortUtil.js.map
        