export default abstract class DataBase{
    
}