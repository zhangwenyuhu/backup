const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","supplytype","supplyname","unlock","stoneID1","number1","stoneID2","number2","stoneID3","number3","artifactstone","dust","herochip","chipnumber","describe",]

export class supplyconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 资源点类型（1普通|2高级）
         **/
        @SafeProperty
        supplytype?:number

        /**
         * 资源点名称
         **/
        @SafeProperty
        supplyname?:string

        /**
         * 解锁关卡
         **/
        @SafeProperty
        unlock?:number

        /**
         * 原石ID
         **/
        @SafeProperty
        stoneID1?:number

        /**
         * 掉落数量
         **/
        @SafeProperty
        number1?:any

        /**
         * 原石ID
         **/
        @SafeProperty
        stoneID2?:number

        /**
         * 掉落数量
         **/
        @SafeProperty
        number2?:any

        /**
         * 原石ID
         **/
        @SafeProperty
        stoneID3?:number

        /**
         * 掉落数量
         **/
        @SafeProperty
        number3?:any

        /**
         * 神器强化石掉落
         **/
        @SafeProperty
        artifactstone?:any

        /**
         * 粉尘掉落
         **/
        @SafeProperty
        dust?:any

        /**
         * 英雄碎片
         **/
        @SafeProperty
        herochip?:number

        /**
         * 英雄碎片掉落数量
         **/
        @SafeProperty
        chipnumber?:any

        /**
         * 描述
         **/
        @SafeProperty
        describe?:string

}

let supplyconfig:supplyconfigRow []=[];

var rowData=
[
    [1001,1,"快餐车补给站",1,10536,[2,4],0,null,0,null,[0,1]],
    [1002,1,"别墅补给站",4,10537,[2,4],0,null,0,null,[0,1]],
    [1003,1,"咖啡屋补给站",8,10538,[2,4],0,null,0,null,[0,1]],
    [1004,1,"荷鲁斯号补给站",64,10539,[3,5],0,null,0,null,[0,1]],
    [1005,1,"尼罗河城餐厅补给站",68,10540,[3,5],0,null,0,null,[0,1]],
    [1006,1,"国家银行补给站",72,10541,[3,5],0,null,0,null,[0,1]],
    [1007,1,"探险帐篷补给站",116,10542,[4,6],0,null,0,null,[0,1]],
    [1008,1,"狮身人面像补给站",124,10543,[4,6],0,null,0,null,[0,1]],
    [1009,1,"凯布利圣坛补给站",132,10544,[4,6],0,null,0,null,[0,1]],
    [1010,1,"万寿古阁补给站",232,10545,[5,7],0,null,0,null,[0,1]],
    [1011,1,"城隍庙门补给站",244,10546,[5,7],0,null,0,null,[0,1]],
    [1012,1,"大雄宝殿补给站",256,10547,[5,7],0,null,0,null,[0,1]],
    [1013,1,"枫丹白露宫补给站",376,10548,[6,8],0,null,0,null,[0,1]],
    [1014,1,"贞德号补给站",392,10549,[6,8],0,null,0,null,[0,1]],
    [1015,1,"马德里大道补给站",408,10550,[6,8],0,null,0,null,[0,1]],
    [1016,1,"钟楼补给站",576,10551,[7,9],0,null,0,null,[0,1]],
    [1017,1,"花神咖啡馆补给站",596,10552,[7,9],0,null,0,null,[0,1]],
    [1018,1,"丽兹酒店补给站",616,10553,[7,9],0,null,0,null,[0,1]],
    [2001,2,"金门大桥补给站",30,0,null,0,null,0,null,null,10,10129,2,""],
    [2002,2,"帝国大厦补给站",60,0,null,0,null,0,null,null,10,10131,2],
    [2003,2,"法老纪念碑补给站",80,0,null,0,null,0,null,null,10,10112,2,""],
    [2004,2,"观光顶楼补给站",108,0,null,0,null,0,null,null,15,10114,2],
    [2005,2,"阿努比斯之门补给站",140,0,null,0,null,0,null,null,15,10121,2,""],
    [2006,2,"摇滚酒吧补给站",196,0,null,0,null,0,null,null,15,10122,2],
    [2007,2,"漫步小路补给站",220,0,null,0,null,0,null,null,20,10102,2,""],
    [2008,2,"海关大楼补给站",280,0,null,0,null,0,null,null,20,10104,2],
    [2009,2,"摩天轮补给站",352,0,null,0,null,0,null,null,20,10453,2],
    [2010,2,"巴黎圣母院补给站",424,0,null,0,null,0,null,null,25,10129,3],
    [2011,2,"新桥补给站",472,0,null,0,null,0,null,null,25,10131,3],
    [2012,2,"卢浮宫补给站",520,0,null,0,null,0,null,null,25,10112,3],
    [2013,2,"旺多姆广场补给站",636,0,null,0,null,0,null,null,30,10114,3],
    [2014,2,"热气球补给站",700,0,null,0,null,0,null,null,30,10121,3],
    [2015,2,"丁香园咖啡馆补给站",764,0,null,0,null,0,null,null,30,10122,3],
    [2016,2,"凯旋门补给站",796,0,null,0,null,0,null,null,40,10102,3],
    [2017,2,"丽芙酒吧补给站",828,0,null,0,null,0,null,null,40,10104,3],
    [2018,2,"皇家丽舍酒店补给站",860,0,null,0,null,0,null,null,40,10453,3],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new supplyconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    supplyconfig .push(r);

}

export default supplyconfig
