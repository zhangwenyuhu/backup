const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["uid","Key","Value",]

export class stringConfigRow{

        /**
         * uid
         **/
        @SafeProperty
        uid?:uid

        /**
         * Key
         **/
        @SafeProperty
        Key?:key

        /**
         * Value
         **/
        @SafeProperty
        Value?:string

}

let stringConfig:stringConfigRow []=[];

var rowData=
[
    [1,"key_no_enough","没有足够的${name}"],
    [2,"key_level_limited","已达等级上限"],
    [3,"key_equip_type_1","力量"],
    [4,"key_equip_type_2","智力"],
    [5,"key_equip_type_3","敏捷"],
    [6,"key_atk","攻击"],
    [7,"key_def","防御"],
    [8,"key_hp","生命"],
    [9,"key_crit_rate","暴击率"],
    [10,"key_hit","命中"],
    [11,"key_dodge","闪避"],
    [12,"key_speed","移速"],
    [13,"key_recovery_second","每秒恢复"],
    [14,"key_magic_resist","魔法减伤率"],
    [15,"key_phy_resist","物理减伤率"],
    [16,"key_lift_leech","吸血等级"],
    [17,"key_no_equipable_equip","没有可装备的${place}"],
    [18,"key_equip_place_1","武器"],
    [19,"key_equip_place_2","盔甲"],
    [20,"key_equip_place_3","头盔"],
    [21,"key_equip_place_4","鞋子"],
    [22,"key_best_equip","已经是最好的装备"],
    [23,"key_faction_1","武装"],
    [24,"key_faction_2","机械"],
    [25,"key_faction_3","变种"],
    [26,"key_faction_4","僵尸"],
    [27,"key_faction_5","超能"],
    [28,"key_faction_6","毁灭"],
    [29,"key_none","无"],
    [30,"key_equip_addition_camp","[${faction}]英雄穿戴后，装备属性提升${percentage}。"],
    [31,"key_equip_star","强化等级"],
    [32,"key_max_level","最大等级MAX"],
    [33,"key_already_select_all","已全选"],
    [34,"key_please_select_strong_equip","请选择强化物品"],
    [35,"key_strong_exp_overflow","强化经验已满"],
    [36,"key_rank_limited","已达进阶上限"],
    [37,"key_no_enough_evolution_heroes","没有足够的进阶材料"],
    [38,"key_no_need_reset_hero","英雄无需重置"],
    [39,"key_select_almost_one_hero","一次最多选择1个英雄"],
    [40,"key_hero_split_select_limit","一次最多只能遣散${count}英雄"],
    [41,"key_select_share_hero_overflow","最多只能共享${count}个英雄"],
    [42,"key_power","战斗力"],
    [43,"key_level","等级"],
    [44,"key_equip","装备"],
    [45,"key_artifact","神器"],
    [46,"key_no_equip","当前没有穿戴${name}"],
    [47,"key_or","或"],
    [48,"key_hero","英雄"],
    [49,"key_no_slot","没有位置了"],
    [50,"key_building_passed","已解放"],
    [51,"key_crit_harm","暴击伤害"],
    [52,"key_more_than","${count}个以上"],
    [53,"key_chapter","第${chapter}章"],
    [54,"key_hero_limited","只能上阵${count}个英雄"],
    [55,"key_same_hero_limited","同名英雄无法同时上阵"],
    [56,"key_please_select_fight_hero","请选择上阵英雄"],
    [57,"key_shop_refresh_success","商品刷新成功"],
    [58,"key_building_already_passed","净化后的建筑会持续产出挂机奖励"],
    [59,"key_full_level","已满级"],
    [60,"key_goto_evolution","前往进化"],
    [61,"key_level_sharing","英雄等级共享中"],
    [62,"key_level_limited_by_evolution","进化英雄可提高等级上限"],
    [63,"key_equip_career1","力量型英雄的专属装备，力量英雄坚强而勇猛，是战斗中最值得信赖的伙伴。"],
    [64,"key_equip_career2","智力型英雄的专属装备，智力英雄善于借助魔法的力量和智慧进行战斗。"],
    [65,"key_equip_career3","敏捷型英雄的专属装备，敏捷英雄身手矫健，锋利的武器和轻便的护甲使他们迅捷如风。"],
    [66,"key_buy_hero_grid","购买5个格子"],
    [67,"key_please_pass_prev_chapter","请先通关上一章节！"],
    [68,"key_chapter_passed","该章节已通关!"],
    [69,"key_friend_tip1","你还没有好友,快去加一些吧！"],
    [70,"key_friend_tip2","今天已赠送过了"],
    [71,"key_friend_tip3","今天已领取过了"],
    [72,"key_input_union_name_or_id","请输入公会名称或ID"],
    [73,"key_player_signature_default","玩家懒，什么都没有设置。"],
    [74,"key_not_evolution_materials","不是进阶材料"],
    [75,"key_max_hero_grid","英雄格子数已满！"],
    [76,"key_input_union_name","请输入公会名称"],
    [77,"key_content_max_length","${name}最多不超过${count1}个中文或${count2}个字母"],
    [78,"key_lottery_times_no_enough","抽卡次数不足"],
    [79,"key_union_notice_default","会长很懒，暂无公告"],
    [80,"key_server_id","服务器"],
    [81,"key_online","在线"],
    [82,"key_date_ago","${count}天前"],
    [83,"key_hour_ago","${count}小时前"],
    [84,"key_minute_ago","${count}分钟前"],
    [85,"key_second_ago","${count}秒前"],
    [86,"key_offline","离线"],
    [87,"key_diamond_lottery","钻石抽卡"],
    [88,"key_friendship_lottery","友情点抽卡"],
    [89,"key_race","联盟"],
    [90,"key_hero_locked","英雄已锁定"],
    [91,"key_hero_unlocked","英雄已解锁"],
    [92,"key_union_name_repeat","公会名已存在"],
    [93,"key_union_member_count","公会人数：${count}"],
    [94,"key_union_apply_count","申请数量：${count}"],
    [95,"key_union_enter_mode0","直接加入"],
    [96,"key_union_enter_mode1","批准加入"],
    [97,"key_union_enter_mode2","不可加入"],
    [98,"key_union_member_full","公会成员已满"],
    [99,"key_union_level_more_than","玩家等级不足"],
    [100,"key_input","请输入${name}"],
    [101,"key_union_name","公会名称"],
    [102,"key_union_notice","公会公告"],
    [103,"key_mail_title","邮件标题"],
    [104,"key_mail_content","邮件内容"],
    [105,"key_union_id","公会ID"],
    [106,"key_sure_to_exit_union","退出后1小时内无法再次申请加入公会，个人活跃无法转移到其他公会。您确定要退出公会？"],
    [107,"key_president_cannot_exit_union","会长不能退出公会"],
    [108,"key_appoint_to_vice_president","升为长老"],
    [109,"key_appoint_to_member","降为会员"],
    [110,"key_assignment_tip1","完成每日任务可获得活跃度,达到一定数量即可领取活跃宝箱"],
    [111,"key_artifact_skill_unlock","强化${count}星解锁"],
    [112,"key_max_star","已达最大星级"],
    [113,"key_union_job1","会长"],
    [114,"key_union_job2","长老"],
    [115,"key_union_job3","会员"],
    [116,"key_player_name","玩家昵称"],
    [117,"key_player_signature","玩家签名"],
    [118,"key_friend_tip4","没有搜索到该玩家"],
    [119,"key_friend_tip5","请输入正确的名称或ID"],
    [120,"key_friend_tip6","没有要处理的好友申请"],
    [121,"key_friend_tip7","确定删除该好友吗？"],
    [122,"key_friend_tip8","删除成功"],
    [123,"key_friend_tip9","没有可领取的和赠送的"],
    [124,"key_max_level2","已满级"],
    [125,"key_no_claim","没有可领取的奖励"],
    [126,"key_free_first","首次免费"],
    [127,"key_in_cooling","等待重置"],
    [128,"key_speed_x1","战斗速度设置为默认速度"],
    [129,"key_speed_x2","战斗速度设置为2倍速"],
    [130,"key_skill_auto","自动释放必杀技能"],
    [131,"key_faction_filter_0","显示全部英雄！"],
    [132,"key_faction_filter_1","只显示武装英雄！"],
    [133,"key_faction_filter_2","只显示机械英雄！"],
    [134,"key_faction_filter_3","只显示变种英雄！"],
    [135,"key_faction_filter_4","只显示僵尸英雄！"],
    [136,"key_faction_filter_5","只显示超能英雄！"],
    [137,"key_faction_filter_6","只显示毁灭英雄！"],
    [138,"key_exist_nickname","已存在的昵称"],
    [139,"key_gender_0","性别"],
    [140,"key_gender_1","男"],
    [141,"key_gender_2","女"],
    [142,"key_friend_tip10","空闲中"],
    [143,"key_friend_tip11","没有要处理的申请消息"],
    [144,"key_friend_tip12","已自动处理所有佣兵申请"],
    [145,"key_friend_tip13","已忽略所有申请"],
    [146,"key_friend_tip14","好友申请已发送"],
    [147,"key_confirm_ok","确定"],
    [148,"key_confirm_cancel","取消"],
    [149,"key_xuanshang_tip1","个人悬赏${count}次"],
    [150,"key_xuanshang_tip2","团队悬赏${count}次"],
    [151,"key_xuanshang_tip3","当前悬赏任务不需要刷新"],
    [152,"key_xuanshang_tip4","该英雄正在执行任务"],
    [153,"key_xuanshang_tip5","派遣英雄已满"],
    [154,"key_xuanshang_tip6","我的派遣英雄已满"],
    [155,"key_common_tip1","任务未完成"],
    [156,"key_common_tip2","该好友主力阵容为空"],
    [157,"key_common_tip3","未上榜"],
    [158,"key_no_suit_equip","没有合适的装备"],
    [159,"key_lottery_tip1","抽卡达到一定次数可以获得累积奖励哦"],
    [160,"key_lottery_tip2","再抽取${times}次英雄即可获得累计奖励"],
    [161,"key_lottery_tip3","现在有可以领取的抽卡奖励哦"],
    [162,"key_sure_to_join_blacklist","确认将对方加入黑名单，将解除好友关系，不再收到对方聊天及申请消息"],
    [163,"key_current_mission","当前关卡：${house}-${level}"],
    [164,"key_common_tip4","挑战首领"],
    [165,"key_common_tip5","挑战摩天楼"],
    [166,"key_common_tip6","该玩家已被你拉入黑名单"],
    [167,"key_common_tip7","该玩家已经是你的好友了"],
    [168,"key_common_tip8","未找到挑战记录"],
    [169,"key_common_tip9","公会成员"],
    [170,"key_common_tip10","好友"],
    [171,"key_common_tip11","赠送和领取友情点次数已达上限"],
    [172,"key_common_tip12","对悬赏任务进行刷新?"],
    [173,"key_common_tip13","刷新"],
    [174,"key_common_tip14","今日赠送友情点次数已达上限"],
    [175,"key_common_tip15","今日可领取友情点次数已达上限"],
    [176,"key_common_tip16","可同时申请数达到上限"],
    [177,"key_common_tip17","每人最多可同时借用3个英雄"],
    [178,"key_common_tip18","每周只能使用一次佣兵"],
    [179,"key_common_tip19","雇佣英雄只能同时上场一个"],
    [180,"key_no_enough_material","没有足够的材料"],
    [181,"key_strong_exp","强化经验"],
    [182,"key_signature","签名"],
    [183,"key_change_success","修改成功"],
    [184,"key_avatar","头像"],
    [185,"key_select_main_troop","请选择${count}个英雄"],
    [186,"key_nickname_cannot_same_with_old","新昵称不能与老昵称相同"],
    [187,"key_no_split_hero","无可遣散英雄"],
    [188,"key_sure_to_dismiss_union","公会解散后，所有成员变为无公会状态，归属原公会的个人贡献和公会资金都将清空"],
    [189,"key_union_apply_send","入会申请已发送"],
    [190,"key_in_other_union","玩家已加入其他公会"],
    [191,"key_same_union_name","公会名称相同"],
    [192,"key_modify_success","修改成功"],
    [193,"key_union_dismiss","${name}公会已解散"],
    [194,"key_operate_success","操作成功"],
    [195,"key_send_success","发送成功"],
    [196,"key_vip_unlock","VIP${level}解锁"],
    [197,"key_sure_to_transform_prisident","是否将会长职位移交给${name}？"],
    [198,"key_sure_to_appointment_vice","是否将${name}任命为长老，长老将拥有除了任命会长，任命长老之外的一切权力？"],
    [199,"key_sure_to_appointment_member","是否将${name}降职为成员？"],
    [200,"key_sure_to_kickout","是否将${name}驱逐出公会？"],
    [201,"key_evolute_to_upgrade","需要进阶才能升级"],
    [202,"key_all_mission_passed","已完成全部关卡"],
    [203,"key_select_faction_card","选择一个联盟，可获得对应的精英英雄！"],
    [204,"key_faction_tip_1","武装联盟英雄，克制变种联盟英雄，被机械联盟英雄克制。"],
    [205,"key_faction_tip_2","机械联盟英雄，克制武装联盟英雄，被僵尸联盟英雄克制。"],
    [206,"key_faction_tip_3","变种联盟英雄，克制僵尸联盟英雄，被武装联盟英雄克制。"],
    [207,"key_faction_tip_4","僵尸联盟英雄，克制机械联盟英雄，被变种联盟英雄克制。"],
    [208,"key_faction_tip_5","超能联盟英雄，只和毁灭联盟英雄互相克制。"],
    [209,"key_faction_tip_6","毁灭联盟英雄，只和超能联盟英雄互相克制。"],
    [210,"key_career_tip_1","力量型英雄，可造成物理伤害！"],
    [211,"key_career_tip_2","智力型英雄，可造成魔法伤害！"],
    [212,"key_career_tip_3","敏捷型英雄，可造成物理伤害！"],
    [213,"key_only_show_faction_hero","只显示${faction}英雄！"],
    [214,"key_claim","领 取"],
    [215,"key_free_times","免费(${count1}/${count2})"],
    [216,"key_click_hero_to_dispatch","请点击英雄头像派遣！"],
    [217,"key_activity_remain_time","剩余时间：${time}"],
    [218,"key_rank","第${rank}名"],
    [219,"key_leichong_desc","<b><color=#133470>累计充值</c><color=#F5F5BC> ${cost} </c><color=#133470>元可领取</c><color=${color}>(${cur}/${total})</c><b>"],
    [220,"key_leixiao_desc","<b><color=#133470>累计消耗</c><color=#F5F5BC> ${cost} </c><img src='benefit_icon_diamond'/><color=#133470>可领取</c><color=${color}>(${cur}/${total})</c><b>"],
    [221,"key_goto_recharge","去充值"],
    [222,"key_claimed","已领取"],
    [223,"key_activity_finished","活动已结束"],
    [224,"key_accum_signday","累计签到${day}天"],
    [225,"key_energyrecoveradd","受伤回能"],
    [226,"key_rapid","迅捷等级"],
    [227,"key_skill_upgrade","技能升级"],
    [228,"key_day","第${day}天"],
    [229,"key_currency","¥"],
    [230,"key_please_input_exchange_code","请输入兑换码"],
    [231,"key_exchange_code_error","兑换码验证失败"],
    [232,"key_activity_after_time","${time}后结束"],
    [233,"key_discount","${discount}折"],
    [234,"key_remain_count","今日剩余次数：${cur}/${total}"],
    [235,"key_after_reborn","${time}后复活"],
    [236,"key_challenge_limit","今日挑战次数已达上限"],
    [237,"key_boss_no_reborn","复活期间不可挑战"],
    [238,"key_wan","${count}万"],
    [239,"key_no_rank","未上榜"],
    [240,"key_day_lock","第${day}天尚未解锁"],
    [241,"key_sure_to_cost_diamond","确认消耗${count}钻石？"],
    [242,"key_hero_less_than","英雄少于${count}个，无法进入共享花坛"],
    [243,"key_unlock_flower_slot","确认消耗${count}钻石，解锁占位"],
    [244,"key_please_unlock_slot","请先解锁前面的占位"],
    [245,"key_impeach_success","弹劾发起成功！"],
    [246,"key_bind_account","账号绑定"],
    [247,"key_binded","已绑定"],
    [248,"key_no_enough_union_point","公会活跃度不足"],
    [249,"key_no_permission_openhunt","需要会长或长老才能开启${name}"],
    [250,"key_mission","关卡"],
    [251,"key_scroll_to_bottom","已到最底部"],
    [252,"key_chess_circle","圈"],
    [253,"key_chess_block","格"],
    [254,"key_desc_1","天"],
    [255,"key_desc_2","小时"],
    [256,"key_desc_3","分钟"],
    [257,"key_desc_4","生命"],
    [258,"key_desc_5","攻击"],
    [259,"key_desc_6","防御"],
    [260,"key_desc_7","暴击"],
    [261,"key_desc_8","吸血"],
    [262,"key_desc_9","闪避"],
    [263,"key_desc_10","命中"],
    [264,"key_desc_11","礼包已结束,无法购买!"],
    [265,"key_desc_12","超级摩天楼"],
    [266,"key_desc_13","机械之窟"],
    [267,"key_desc_14","变种之柱"],
    [268,"key_desc_15","僵尸之墓"],
    [269,"key_desc_16","已申请人数"],
    [270,"key_desc_17","第${count}层"],
    [271,"key_desc_18","正在帮助 ${name} 执行任务"],
    [272,"key_desc_19","正在档案台中休息"],
    [273,"key_desc_20","双倍领取"],
    [274,"key_desc_21","领取奖励"],
    [275,"key_desc_22","前 往"],
    [276,"key_desc_23","激活礼包"],
    [277,"key_desc_24","钻石"],
    [278,"key_desc_25","净化建筑"],
    [279,"key_desc_26","礼包已结束,无法领取.未领取的奖励稍后将会通过邮件发送"],
    [280,"key_desc_27","请先激活成长礼包"],
    [281,"key_desc_28","后结束"],
    [282,"key_desc_29","已结束"],
    [283,"key_desc_30","已拥有"],
    [284,"key_desc_31","领取"],
    [285,"key_desc_32","观看"],
    [286,"key_desc_33","可以从每日任务和每周任务宝箱中获取"],
    [287,"key_desc_34","通过智慧树的考验可获得智慧徽章"],
    [288,"key_desc_35","继续领取需要解锁高级礼包,是否前往解锁?"],
    [289,"key_desc_36","去解锁"],
    [290,"key_desc_37","续期"],
    [291,"key_desc_38","购买"],
    [292,"key_desc_39","免费"],
    [293,"key_desc_40","礼包已售罄"],
    [294,"key_desc_41","活动已结束,请下次再来"],
    [295,"key_desc_42","礼包已领取"],
    [296,"key_desc_43","vip等级已达到最高"],
    [297,"key_desc_44","小时后消失"],
    [298,"key_desc_45","活动已结束 排名公示中"],
    [299,"key_desc_46","活动倒计时"],
    [300,"key_desc_47","心愿骰子数量不足"],
    [301,"key_desc_48","普通骰子数量不足"],
    [302,"key_desc_49","已经穷到小偷都无法下手了"],
    [303,"key_desc_50","累计完成"],
    [304,"key_desc_51","免费获得一个普通骰子"],
    [305,"key_desc_52","今日已获取"],
    [306,"key_desc_53","次"],
    [307,"key_desc_54","领取"],
    [308,"key_desc_55","活动已结束,请下期活动再来"],
    [309,"key_desc_56","骰子数量不足10个"],
    [310,"key_desc_57","领取和赠送成功"],
    [311,"key_desc_58","赠送成功"],
    [312,"key_desc_59","领取成功"],
    [313,"key_desc_60","免费刷新"],
    [314,"key_desc_61","暂无玩家达成奖励进度"],
    [315,"key_desc_62","未找到战斗记录"],
    [316,"key_desc_63","限时开放,周${openTime}开启"],
    [317,"key_desc_64","伤害量"],
    [318,"key_desc_65","治疗量"],
    [319,"key_desc_66","承受伤害量"],
    [320,"key_desc_67","需要"],
    [321,"key_desc_68","个"],
    [322,"key_desc_69","英雄"],
    [323,"key_desc_70","没有符合条件的英雄可派遣"],
    [324,"key_desc_71","派遣英雄不满足条件"],
    [325,"key_pass_mission","通关章节${buildingId}-${missionId}"],
    [326,"key_chapter_progress","副本“${name}”进度超过${progress}%"],
    [327,"key_chapter_condition","副本解锁条件"],
    [328,"key_open_wonder","开启冒险"],
    [329,"key_continue_wonder","继续冒险"],
    [330,"key_need_close_current_wonder","需要关闭“${name}”，才能开启冒险"],
    [331,"key_please_select_battle_hero","请选择出战${count}位英雄"],
    [332,"key_assist_hero_limit","只能邀请${count}位英雄助阵"],
    [333,"key_please_select_assist_hero","必须选择${count}位英雄助阵"],
    [334,"key_dungeon_no_enough_challenge","今日已没有剩余的挑战次数"],
    [335,"key_dungeon_finish_mission","地牢关卡已全部通关"],
    [336,"key_layer_no","第${count}层"],
    [337,"key_empty_bag","背包中没有任何东西"],
    [338,"key_developing","敬请期待"],
    [339,"key_auto_skill_tip","主动释放控制类必杀技可以更好掌握\n时机打断敌方施法"],
    [340,"key_hero_duty_1","输出"],
    [341,"key_hero_duty_2","辅助"],
    [342,"key_hero_duty_3","坦克"],
    [343,"key_hero_duty_4","控制"],
    [344,"key_goto_strong_equip_tip","未满星的蓝色装备及以上才可以进行强化"],
    [345,"key_market_title10","成长礼包"],
    [346,"key_market_title11","活跃礼包"],
    [347,"key_market_title12","智慧树礼包"],
    [348,"key_market_title20","每日特惠"],
    [349,"key_market_title21","每周特惠"],
    [350,"key_market_title22","每月特惠"],
    [351,"key_market_title23","钻石商城"],
    [352,"key_market_title30","僵尸骰子"],
    [353,"key_market_title31","夺宝奇兵"],
    [354,"key_market_title32","世界BOSS"],
    [355,"key_monthcard_remain_day","月卡剩余${day}"],
    [356,"key_vip_bonus","VIP${level} 奖励"],
    [357,"key_vip_privilege","VIP${level} 特权"],
    [358,"key_active_gift_tip","<b><color=#3e779f>可以从</c><color=#b6a047>每日任务</c><color=#3e779f>和</c><color=#b6a047>每周任务</c><color=#3e779f>宝箱中获得</c></b>"],
    [359,"key_wisdom_gift_tip","<b><color=#3e779f>通过</c><color=#b6a047>智慧树的考验</c><color=#3e779f>可获得</c><color=#b6a047>智慧徽章</c></b>"],
    [360,"key_gift_finished","该礼包已结束,无法领取,未领取的奖励\n稍后将会通过邮件发送"],
    [361,"key_claim_gift_tip","继续领取需要解锁高级礼包,是否前往解锁?"],
    [362,"key_goto_unlock","去解锁"],
    [363,"key_finished","已结束"],
    [364,"key_gift_sell_out","礼包已售罄"],
    [365,"key_come_back_again","，请下次再来"],
    [366,"key_gift_claimed","礼包已领取"],
    [367,"key_free","免费"],
    [368,"key_skip_battle_tip","可跳过 智慧树考验、超级摩天楼、奇妙时空"],
    [369,"key_no_enough_ex","${name}不足，无法升级。是否前往获取更多${name}?"],
    [370,"key_goto","前往"],
    [371,"key_bonus_reset_time","奖励重置倒计时"],
    [372,"key_alert_title","友情提示"],
    [373,"key_network_error","网络连接失败，请检查网络或者稍后再试"],
    [374,"key_buy","购买"],
    [375,"key_renewal","续期"],
    [376,"key_star","${count}星"],
    [377,"key_active_gift","激活礼包"],
    [378,"key_remain_active_time","剩余激活时间"],
    [379,"key_no_buy_gift","该礼包已结束，无法购买"],
    [380,"key_dungeon_process","第${level}层"],
    [381,"key_dungeon_hero_leave","您的英雄已经离家出走，今日的地牢挑战无法继续"],
    [382,"key_not_in_union","您未加入任何公会"],
    [383,"key_guild_join_cd","加入新公会后，需要等待${time}后可使用"],
    [384,"key_skip_ad","已为您跳过广告"],
    [385,"key_lottery_chance","抽卡概率"],
    [386,"key_genius_point_not_enough","${name}不足，无法点亮"],
    [387,"key_genius_point0","普通天赋点"],
    [388,"key_genius_point1","中级天赋点"],
    [389,"key_genius_point2","高级天赋点"],
    [390,"key_property_addition","属性加成："],
    [391,"key_auto_energy","每秒回能"],
    [392,"key_hit_energy","攻击回能"],
    [393,"key_be_hit_energy","受击回能"],
    [394,"key_interval_cd","普攻间隔"],
    [395,"key_arrive","需达到"],
    [396,"key_update_package","有新版本可更新，请重启游戏！"],
    [397,"key_dungeon_assist_less_than","助力英雄不满两名，无法开启挑战"],
    [398,"key_passed","已通关"],
    [399,"key_need_select_fruit","需要选择${count}个果实"],
    [400,"key_fruit_tip1","<b><color=#66769c>果实最多可携带${count}个</c></b>"],
    [401,"key_fruit_tip2","<b><color=#66769c>果实最多可携带${count}个，</c><color=#3dd439>勾选的果实会进入背包中！</color></b>"],
    [402,"key_market_title33","探趣寻宝"],
    [403,"key_dungeon_finish_mission_ex","史诗级英雄最高通关${count}层！恭喜你已全部通关"],
    [404,"key_skill_harm","技能伤害"],
    [405,"key_skill_speed","迅捷等级"],
    [406,"key_genius_unlock_condition","该英雄地牢通关${level}层解锁"],
    [407,"key_sawling_tip","消耗${count}个普通天赋果，种下${name}天赋种子。"],
    [408,"key_reset_genius_confirm","洗点需消耗1颗${name}，\n洗点后，将返还该英雄全部天赋果，\n确认洗点吗？"],
    [409,"key_dungeon_arrive","地牢探险需达到${count}层"],
    [410,"key_genius_skill_unlock_condition","(解锁条件：${name}Lv.${lv})"],
    [411,"key_duty_tip_1","持续造成高额伤害"],
    [412,"key_duty_tip_2","协助团队主力英雄，提供加成和增益效果"],
    [413,"key_duty_tip_3","有极强的生存能力，可以站在队伍的前排帮助队友抵挡伤害"],
    [414,"key_duty_tip_4","战斗过程中控制敌方，可以给我方提供巨大的战斗优势。"],
    [415,"key_next_save_point","下一个存档点第${level}层"],
    [416,"key_dungeon_tip","派遣一名英雄，前往地牢探险吧！"],
    [417,"key_dungeon_progress","${name}的探险进度："],
    [418,"key_sure_to_next_dungeon","还有未探索到的奖励，确定放弃吗？"],
    [419,"key_select_max_fruit","果实最多携带${count}个"],
    [420,"key_no_valid_hero_for_dungeon","没有满${level}级以上的英雄可派遣"],
    [421,"key_weekcard_remain_day","周卡剩余${day}"],
    [422,"key_monthcard_tip","月卡时长增加30天"],
    [423,"key_weekcard_tip","周卡时长增加7天"],
    [424,"key_dungeon_guide_reward","每层地牢都有不少宝藏，走动一下，可千万别错过"],
    [425,"key_dungeon_guide_fruit","属性果实可以大幅度提升你的战力，最多可携带3个哦！"],
    [426,"key_dungeon_guide_door","恭喜你勇士！可以继续通关下一层了"],
    [427,"key_no_valid_hero_for_dungeon_ex","${level}级以下的英雄不可派遣"],
    [428,"key_temporary_no","暂无${name}"],
    [429,"key_dungeon_finished","今日地牢探险已重置，请重新进入"],
    [430,"key_dungeon_all_passed","${name}的地牢探险全部通关"],
    [431,"key_dungeon_refresh_hero_confirm","是否花费${count}钻石，重新更新一批助力英雄？"],
    [432,"key_dungeon_fight_hero_limit","每日只能派遣${count}位英雄"],
    [433,"key_pass_mission_to_unlock","(${cur}/${total})通关${houseId}-${level}解锁${name}"],
    [434,"key_at_least_select_battle_hero","至少选择1位英雄出战"],
    [435,"key_dungeon_select_tip","每日可派遣2名英雄，确定只选择一名英雄前往探险么？"],
    [436,"key_activity_finish_tip","活动已结束，未领取的奖励稍后通过邮件发送"],
    [437,"key_today_charge","今日已充值￥${amount}"],
    [438,"key_charge_more","再充${amount}元，可领取"],
    [439,"key_activity_end","活动结束"],
    [440,"key_click_receive","点击领取"],
    [441,"key_total_charge","累计￥${amount}"],
    [442,"key_dungeon_hero_passed","该英雄已全部通关，请选择其他英雄"],
    [443,"key_artifact_level_limit","已达强化上限，请提升玩家等级至${level1}"],
    [444,"key_artifact_level_max","已达强化上限${level1}"],
    [445,"key_no_path_found","路上有障碍物，无法通过"],
    [446,"key_artifact_star_max","已进阶至最高星级"],
    [447,"key_artifact_piece_not_enough","神器碎片不足，请前往【公会寻宝】获得"],
    [448,"key_artifact_good_not_enough","强化石不足，请前往【公会寻宝】获得"],
    [449,"key_artifact_max_level","已达到最高等级"],
    [450,"key_artifact_need_levelup","玩家等级提升至${level}级可继续强化"],
    [451,"key_artifact_evo_text1","进 阶"],
    [452,"key_artifact_evo_text2","已满阶"],
    [453,"key_artifact_level_text1","已满级"],
    [454,"key_upgrade","升${level}级"],
    [455,"key_expired","已过期"],
    [456,"key_material_tip1","今日可购买次数已用完，提升VIP等级可以增加可购买次数上限"],
    [457,"key_material_tip2","提升VIP等级"],
    [458,"key_name_max_length","超过最长名字限制，请重新输入"],
    [459,"key_hero_be_locked","该英雄已被锁定"],
    [460,"key_not_evo_material","不是进阶材料"],
    [461,"key_need_evo","英雄升至稀有品阶可升星"],
    [462,"key_star_max","星级已是最高"],
    [463,"key_evo_max","品阶已是最高"],
    [464,"key_need_levelup","英雄等级提升至${level}级可升星"],
    [465,"key_not_star_material","不是升星材料"],
    [466,"key_not_merge_material","不是合成材料"],
    [467,"key_star_not_reach","星级未达到要求"],
    [468,"key_merge_no_material","合成材料不足"],
    [469,"key_cannot_star","不能升星"],
    [470,"key_star_level_limit","升星等级限制"],
    [471,"key_evolution_reach_star","英雄升至${level}星可继续进阶"],
    [472,"key_choose_evo_material","请选择进阶材料"],
    [473,"key_choose_star_material","请选择升星材料"],
    [474,"key_choose_merge_material","请选择合成材料"],
    [475,"key_merge_no_hero","缺少${rankName}的${heroName}"],
    [476,"key_need_rank_level","英雄提升至${quality}品阶${level}级可升星"],
    [477,"key_name_not_valid","请使用汉字、数字或字母哦"],
    [478,"key_evolution_type1","进阶"],
    [479,"key_evolution_type2","升星"],
    [480,"key_evolution_type3","合成"],
    [481,"key_player_level_unlock","${level}级解锁"],
    [482,"key_exchange_limit_count","兑换次数不足"],
    [483,"key_exchange_no_hero","您还未放入兑换的英雄"],
    [484,"key_exchange_no_good","所需材料不足"],
    [485,"key_exchange_has_quality_hero","此次兑换中有较为珍贵的英雄，是否确认兑换？"],
    [486,"key_exchange_text1","兑换"],
    [487,"key_exchange_text2","材料不足"],
    [488,"key_exchange_text3","无限制"],
    [489,"key_exchange_text4","可兑换${count}次"],
    [490,"key_exchange_hero_rank_fit","您没有${rank}品阶的英雄"],
    [491,"key_exchange_has_hero","该英雄已被放入其他兑换格中"],
    [492,"key_exchange_has_choose_hero","已经选择了英雄"],
    [493,"key_arena_challenge_time","已挑战次数：${time}"],
    [494,"key_claimable","可领取"],
    [495,"key_arena_max_score_target","历史最高分达到${score}分"],
    [496,"key_artifact_lvup_tip","英雄穿戴神器后可以享受神器带来的属性加成效果"],
    [497,"key_wave","第${wave}波"],
    [498,"key_exchange_time_out","兑换次数已用完"],
    [499,"key_exchange_equip_rank_fit","您没有${rank}品阶的装备"],
    [500,"key_exchange_has_equip","该装备已被放入其他兑换格中"],
    [501,"key_exchange_has_choose_equip","已经选择了装备"],
    [502,"key_exchange_no_hero_put","您未放入英雄，是否退出？"],
    [503,"key_exchange_no_equip_put","您未放入装备，是否退出？"],
    [504,"key_exchange_has_quality_equip","此次兑换中有被强化过的装备，是否确认兑换？"],
    [505,"key_exchange_no_equip","您还未放入兑换的装备"],
    [506,"key_exchange_no_hero_fit","您没有符合的英雄"],
    [507,"key_exchange_no_equip_fit","您没有符合的装备"],
    [508,"key_unlock_avatar_tip1","获得该英雄，可解锁此头像"],
    [509,"key_unlock_avatar_tip2","培养该英雄至史诗品质，可解锁此头像"],
    [510,"key_vip_unlock2","vip等级达到${level}级解锁"],
    [511,"key_pass_mission_unlock","通关${buildingId}-${levelId}解锁"],
    [512,"key_wait_power_recovery","请等待体力恢复"],
    [513,"key_searching","搜寻中..."],
    [514,"key_search_result","搜寻结果"],
    [515,"key_search_time","搜寻${time}次"],
    [516,"key_no_enough_buy_tili_times","请等待体力恢复，每${minute}分钟自动恢复1点体力"],
    [517,"key_no_enough_buy_tili_times2","提升VIP等级可增加购买次数上限"],
    [518,"key_select_buy_tili_times","请选择体力购买次数 "],
    [519,"key_breach","突 破"],
    [520,"key_unlock_skill","解锁技能"],
    [521,"key_buy_tili_success","体力购买成功"],
    [522,"key_supply_power_tip","每10分钟自动恢复一点"],
    [523,"key_no_enough_senior_search_time","没有足够的高级搜寻次数"],
    [524,"key_times","${count}次"],
    [525,"key_no_enough_supply_reset_times","高级搜寻重置次数已用完"],
    [526,"key_no_enough_supply_reset_times2","提升VIP等级可增加高级搜寻的重置次数"],
    [527,"key_supply_search_count","搜寻${time}次"],
    [528,"key_buy_tili_tip","<b><color=#37504B>VIP提升至</c><color=#7C3E14>${vip}级</c><color=#37504B>可以增加</c><color=#7C3E14>${count}次</c><color=#37504B>体力购买次数</c></b>"],
    [529,"key_fetter_own_heroes","拥有${hero1}，${hero2}"],
    [530,"key_no_need_rollback_hero","英雄无需回退"],
    [531,"key_equip_level_limited","装备强化等级已达上限"],
    [532,"key_sure_to_inherit_equip","是否选择将替换前装备的养成转换到替换后的装备上"],
    [533,"key_equip_rank_limited","装备品质已达上限"],
    [534,"key_equip_merge_no_enough_material","装备合成材料不足"],
    [535,"key_equip_merge_tower_limited","装备合成需要摩天楼达到${tower}层"],
    [536,"key_sure_to_merge_equip","合成装备后，消耗的装备中的资源将返还"],
    [537,"key_equip_charging_lv_limited","装备充能等级已达上限"],
    [538,"key_sure_to_reset_before_split_equip","可消耗${count}钻石先重生再分解"],
    [539,"key_equip_no_reset","装备已是初始状态，无需重生"],
    [540,"key_sure_to_reset_equip","确认消耗${count}钻石进行装备重生？"],
    [541,"key_sure_to_split_equip","确认进行装备分解？"],
    [542,"key_equip_no_camp","该装备没有专属联盟"],
    [543,"key_equip_recast_tip","<b><color=#455F5A>${faction}联盟英雄穿戴后，装备属性提升</c><color=#007E09>${value}</color><color=#455F5A>，是否保留该属性？</c></b>"],
    [544,"key_pieces","${count}件"],
    [545,"key_no_inherit_equip_in_flowerpot","花坛祭司中没有可继承的同类型装备"],
    [546,"key_evolution_type4","升星"],
    [547,"key_auto_550","超级月卡已过期"],
    [548,"key_auto_551","毒箭木开启成功"],
    [549,"key_auto_552","商品不存在"],
    [550,"key_auto_553","钻石不足"],
    [551,"key_auto_554","购买成功"],
    [552,"key_auto_555","删除已读邮件成功"],
    [553,"key_auto_556","没有可领取的邮件"],
    [554,"key_auto_557","刷新成功"],
    [555,"key_auto_558","战斗版本错误"],
    [556,"key_auto_559","该礼包已结束,无法购买"],
    [557,"key_auto_560","您已不在群组"],
    [558,"key_auto_561","不能发送空白聊天！"],
    [559,"key_auto_562","挑战令不足"],
    [560,"key_auto_563","今日挑战令购买次数已达上限"],
    [561,"key_auto_564","没有足够的奇异花"],
    [562,"key_auto_565","请先设置终极奖励吧"],
    [563,"key_auto_566","终极奖励已领取,请前往下一层再设置"],
    [564,"key_auto_567","暂无昔日榜单"],
    [565,"key_auto_568","请明天再来"],
    [566,"key_auto_569","没有符合条件的英雄可派遣!"],
    [567,"key_auto_570","当前没有符合条件的英雄可派遣"],
    [568,"key_auto_571","克隆挑战券不足"],
    [569,"key_auto_572","请选择需要合成的英雄"],
    [570,"key_auto_573","该功能即将开放！"],
    [571,"key_auto_574","即将开放"],
    [572,"key_auto_575","心愿骰子数量不足!"],
    [573,"key_auto_576","普通骰子数量不足!"],
    [574,"key_auto_577","当前没有记录"],
    [575,"key_auto_578","今日次数已用完"],
    [576,"key_auto_579","公会已满员"],
    [577,"key_auto_580","暂未开放,敬请期待"],
    [578,"key_auto_581","公会争霸活动已结束"],
    [579,"key_auto_582","今日红包已领取,请明天再来"],
    [580,"key_auto_583","完成成就可领取奖励"],
    [581,"key_auto_584","今日次数已用尽,请明日再来"],
    [582,"key_auto_585","材料不足!"],
    [583,"key_auto_586","今日强化已达上限,请明日再来"],
    [584,"key_auto_587","公会列表已刷新"],
    [585,"key_auto_588","未找到您搜索的公会"],
    [586,"key_auto_589","今日免费刷新次数已用完"],
    [587,"key_auto_590","请设置上阵英雄"],
    [588,"key_auto_591","设置成功"],
    [589,"key_auto_592","找不到对手请稍后再试"],
    [590,"key_auto_593","角斗士硬币达到上限,无法领取"],
    [591,"key_auto_594","您已经强到找不到对手了"],
    [592,"key_auto_595","请上阵英雄"],
    [593,"key_auto_596","智慧树已刷新"],
    [594,"key_auto_597","当前还未获得果实"],
    [595,"key_auto_598","重生药剂数量不足"],
    [596,"key_auto_599","没有需要复活的英雄！"],
    [597,"key_auto_600","所有英雄已全部恢复满状态！"],
    [598,"key_auto_601","请选择一个英雄"],
    [599,"key_auto_602","碎片不足"],
    [600,"key_auto_603","已领取所有奖励"],
    [601,"key_auto_604","暂无可领取奖励"],
    [602,"key_auto_605","请选择想要兑换的物品"],
    [603,"key_auto_606","无法抵达"],
    [604,"key_auto_607","已收集完所有宝箱"],
    [605,"key_auto_608","已收集完所有水晶宝箱"],
    [606,"key_auto_609","当前资源点正在被攻击"],
    [607,"key_auto_610","英雄已阵亡，复活后才能上阵！"],
    [608,"key_auto_611","该英雄已在其他组上阵"],
    [609,"key_auto_612","该玩家今日接收礼物次数已用尽"],
    [610,"key_auto_613","活动已结束！"],
    [611,"key_auto_614","兑换次数已达上限"],
    [612,"key_auto_615","宝藏碎片不足"],
    [613,"key_auto_616","尚未获得神器"],
    [614,"key_auto_617","该英雄每天只能挑战一次"],
    [615,"key_auto_618","拥有该英雄后即可挑战"],
    [616,"key_auto_619","当前没有可重炼的锻造属性"],
    [617,"key_auto_620","请先开启新手基金"],
    [618,"key_auto_621","未到领取时间"],
    [619,"key_auto_622","已购买新手基金,不用重复购买"],
    [620,"key_auto_623","勇士之证不足"],
    [621,"key_auto_624","高阶勇士之证不足"],
    [622,"key_auto_625","未达成解锁条件，不可领取"],
    [623,"key_auto_626","已达上限"],
    [624,"key_auto_627","活力药剂使用成功！"],
    [625,"key_auto_628","已切断敌方粮草"],
    [626,"key_auto_629","暂未开放"],
    [627,"key_auto_630","随机复活1名英雄成功！"],
    [628,"key_auto_631","您已被禁言"],
    [629,"key_auto_632","该英雄正在共享花坛中，不能进阶"],
    [630,"key_power_tip","总战力是最高5个不相同英雄的战力之和"],
    [634,"key_auto_634","发言过快，${p1}秒后可发言"],
    [635,"key_auto_635","限时开放,周${p1}开启"],
    [636,"key_auto_636","还需要${p1}点能量，便可领取十连抽！"],
    [637,"key_auto_637","该奖励已用尽,请选择其他奖励"],
    [638,"key_auto_638","通关摩天楼${p1}层解锁合成该装备"],
    [639,"key_auto_639","VIP${p1}解锁一键派遣功能"],
    [640,"key_auto_640","VIP${p1}解锁一键领取功能"],
    [641,"key_auto_641","${p1}"],
    [642,"key_auto_642","使用${p1}联盟的英雄上阵可以造成20%额外伤害与20%伤害减免"],
    [643,"key_auto_643","公会等级${p1}解锁公会副本"],
    [644,"key_auto_644","${p1}后开启活动报名"],
    [645,"key_auto_645","队伍${p1}上阵英雄数量不足"],
    [646,"key_auto_646","占领的资源点不能超过${p1}个"],
    [647,"key_auto_647","今日奖励已领取,请明日再来"],
    [648,"key_auto_648","通关${p1}-${p2}即可领取"],
    [649,"key_auto_649","请先激活成长礼包!"],
    [650,"key_auto_650","需要${p1}个 ${p2} ${p3}"],
    [651,"key_auto_651","需要${p1}名${p2}${p3}英雄"],
    [652,"key_auto_652","需要${p1}名任意阵容${p2}英雄"],
    [653,"key_auto_653","需要1个 ${p1} ${p2}"],
    [654,"key_auto_654","需要1名${p1}${p2}英雄"],
    [655,"key_auto_655","需要1名任意阵容${p1}英雄"],
    [656,"key_auto_656","遭遇陷阱，${p1}型英雄损失了${p2}%血量"],
    [657,"key_auto_657","${p1}陷阱已解除"],
    [658,"key_applyjoin","申请加入"],
    [659,"key_quickjoin","加入"],
    [660,"key_union_active_tip","公会活跃值:公会成员每获得一点个人活跃值,就贡献1点公会活跃值"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new stringConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

export let stringConfigMap:{

    /** {"uid":1,"Key":"key_no_enough","Value":"没有足够的${name}"} */
    key_no_enough?:stringConfigRow

    /** {"uid":2,"Key":"key_level_limited","Value":"已达等级上限"} */
    key_level_limited?:stringConfigRow

    /** {"uid":3,"Key":"key_equip_type_1","Value":"力量"} */
    key_equip_type_1?:stringConfigRow

    /** {"uid":4,"Key":"key_equip_type_2","Value":"智力"} */
    key_equip_type_2?:stringConfigRow

    /** {"uid":5,"Key":"key_equip_type_3","Value":"敏捷"} */
    key_equip_type_3?:stringConfigRow

    /** {"uid":6,"Key":"key_atk","Value":"攻击"} */
    key_atk?:stringConfigRow

    /** {"uid":7,"Key":"key_def","Value":"防御"} */
    key_def?:stringConfigRow

    /** {"uid":8,"Key":"key_hp","Value":"生命"} */
    key_hp?:stringConfigRow

    /** {"uid":9,"Key":"key_crit_rate","Value":"暴击率"} */
    key_crit_rate?:stringConfigRow

    /** {"uid":10,"Key":"key_hit","Value":"命中"} */
    key_hit?:stringConfigRow

    /** {"uid":11,"Key":"key_dodge","Value":"闪避"} */
    key_dodge?:stringConfigRow

    /** {"uid":12,"Key":"key_speed","Value":"移速"} */
    key_speed?:stringConfigRow

    /** {"uid":13,"Key":"key_recovery_second","Value":"每秒恢复"} */
    key_recovery_second?:stringConfigRow

    /** {"uid":14,"Key":"key_magic_resist","Value":"魔法减伤率"} */
    key_magic_resist?:stringConfigRow

    /** {"uid":15,"Key":"key_phy_resist","Value":"物理减伤率"} */
    key_phy_resist?:stringConfigRow

    /** {"uid":16,"Key":"key_lift_leech","Value":"吸血等级"} */
    key_lift_leech?:stringConfigRow

    /** {"uid":17,"Key":"key_no_equipable_equip","Value":"没有可装备的${place}"} */
    key_no_equipable_equip?:stringConfigRow

    /** {"uid":18,"Key":"key_equip_place_1","Value":"武器"} */
    key_equip_place_1?:stringConfigRow

    /** {"uid":19,"Key":"key_equip_place_2","Value":"盔甲"} */
    key_equip_place_2?:stringConfigRow

    /** {"uid":20,"Key":"key_equip_place_3","Value":"头盔"} */
    key_equip_place_3?:stringConfigRow

    /** {"uid":21,"Key":"key_equip_place_4","Value":"鞋子"} */
    key_equip_place_4?:stringConfigRow

    /** {"uid":22,"Key":"key_best_equip","Value":"已经是最好的装备"} */
    key_best_equip?:stringConfigRow

    /** {"uid":23,"Key":"key_faction_1","Value":"武装"} */
    key_faction_1?:stringConfigRow

    /** {"uid":24,"Key":"key_faction_2","Value":"机械"} */
    key_faction_2?:stringConfigRow

    /** {"uid":25,"Key":"key_faction_3","Value":"变种"} */
    key_faction_3?:stringConfigRow

    /** {"uid":26,"Key":"key_faction_4","Value":"僵尸"} */
    key_faction_4?:stringConfigRow

    /** {"uid":27,"Key":"key_faction_5","Value":"超能"} */
    key_faction_5?:stringConfigRow

    /** {"uid":28,"Key":"key_faction_6","Value":"毁灭"} */
    key_faction_6?:stringConfigRow

    /** {"uid":29,"Key":"key_none","Value":"无"} */
    key_none?:stringConfigRow

    /** {"uid":30,"Key":"key_equip_addition_camp","Value":"[${faction}]英雄穿戴后，装备属性提升${percentage}。"} */
    key_equip_addition_camp?:stringConfigRow

    /** {"uid":31,"Key":"key_equip_star","Value":"强化等级"} */
    key_equip_star?:stringConfigRow

    /** {"uid":32,"Key":"key_max_level","Value":"最大等级MAX"} */
    key_max_level?:stringConfigRow

    /** {"uid":33,"Key":"key_already_select_all","Value":"已全选"} */
    key_already_select_all?:stringConfigRow

    /** {"uid":34,"Key":"key_please_select_strong_equip","Value":"请选择强化物品"} */
    key_please_select_strong_equip?:stringConfigRow

    /** {"uid":35,"Key":"key_strong_exp_overflow","Value":"强化经验已满"} */
    key_strong_exp_overflow?:stringConfigRow

    /** {"uid":36,"Key":"key_rank_limited","Value":"已达进阶上限"} */
    key_rank_limited?:stringConfigRow

    /** {"uid":37,"Key":"key_no_enough_evolution_heroes","Value":"没有足够的进阶材料"} */
    key_no_enough_evolution_heroes?:stringConfigRow

    /** {"uid":38,"Key":"key_no_need_reset_hero","Value":"英雄无需重置"} */
    key_no_need_reset_hero?:stringConfigRow

    /** {"uid":39,"Key":"key_select_almost_one_hero","Value":"一次最多选择1个英雄"} */
    key_select_almost_one_hero?:stringConfigRow

    /** {"uid":40,"Key":"key_hero_split_select_limit","Value":"一次最多只能遣散${count}英雄"} */
    key_hero_split_select_limit?:stringConfigRow

    /** {"uid":41,"Key":"key_select_share_hero_overflow","Value":"最多只能共享${count}个英雄"} */
    key_select_share_hero_overflow?:stringConfigRow

    /** {"uid":42,"Key":"key_power","Value":"战斗力"} */
    key_power?:stringConfigRow

    /** {"uid":43,"Key":"key_level","Value":"等级"} */
    key_level?:stringConfigRow

    /** {"uid":44,"Key":"key_equip","Value":"装备"} */
    key_equip?:stringConfigRow

    /** {"uid":45,"Key":"key_artifact","Value":"神器"} */
    key_artifact?:stringConfigRow

    /** {"uid":46,"Key":"key_no_equip","Value":"当前没有穿戴${name}"} */
    key_no_equip?:stringConfigRow

    /** {"uid":47,"Key":"key_or","Value":"或"} */
    key_or?:stringConfigRow

    /** {"uid":48,"Key":"key_hero","Value":"英雄"} */
    key_hero?:stringConfigRow

    /** {"uid":49,"Key":"key_no_slot","Value":"没有位置了"} */
    key_no_slot?:stringConfigRow

    /** {"uid":50,"Key":"key_building_passed","Value":"已解放"} */
    key_building_passed?:stringConfigRow

    /** {"uid":51,"Key":"key_crit_harm","Value":"暴击伤害"} */
    key_crit_harm?:stringConfigRow

    /** {"uid":52,"Key":"key_more_than","Value":"${count}个以上"} */
    key_more_than?:stringConfigRow

    /** {"uid":53,"Key":"key_chapter","Value":"第${chapter}章"} */
    key_chapter?:stringConfigRow

    /** {"uid":54,"Key":"key_hero_limited","Value":"只能上阵${count}个英雄"} */
    key_hero_limited?:stringConfigRow

    /** {"uid":55,"Key":"key_same_hero_limited","Value":"同名英雄无法同时上阵"} */
    key_same_hero_limited?:stringConfigRow

    /** {"uid":56,"Key":"key_please_select_fight_hero","Value":"请选择上阵英雄"} */
    key_please_select_fight_hero?:stringConfigRow

    /** {"uid":57,"Key":"key_shop_refresh_success","Value":"商品刷新成功"} */
    key_shop_refresh_success?:stringConfigRow

    /** {"uid":58,"Key":"key_building_already_passed","Value":"净化后的建筑会持续产出挂机奖励"} */
    key_building_already_passed?:stringConfigRow

    /** {"uid":59,"Key":"key_full_level","Value":"已满级"} */
    key_full_level?:stringConfigRow

    /** {"uid":60,"Key":"key_goto_evolution","Value":"前往进化"} */
    key_goto_evolution?:stringConfigRow

    /** {"uid":61,"Key":"key_level_sharing","Value":"英雄等级共享中"} */
    key_level_sharing?:stringConfigRow

    /** {"uid":62,"Key":"key_level_limited_by_evolution","Value":"进化英雄可提高等级上限"} */
    key_level_limited_by_evolution?:stringConfigRow

    /** {"uid":63,"Key":"key_equip_career1","Value":"力量型英雄的专属装备，力量英雄坚强而勇猛，是战斗中最值得信赖的伙伴。"} */
    key_equip_career1?:stringConfigRow

    /** {"uid":64,"Key":"key_equip_career2","Value":"智力型英雄的专属装备，智力英雄善于借助魔法的力量和智慧进行战斗。"} */
    key_equip_career2?:stringConfigRow

    /** {"uid":65,"Key":"key_equip_career3","Value":"敏捷型英雄的专属装备，敏捷英雄身手矫健，锋利的武器和轻便的护甲使他们迅捷如风。"} */
    key_equip_career3?:stringConfigRow

    /** {"uid":66,"Key":"key_buy_hero_grid","Value":"购买5个格子"} */
    key_buy_hero_grid?:stringConfigRow

    /** {"uid":67,"Key":"key_please_pass_prev_chapter","Value":"请先通关上一章节！"} */
    key_please_pass_prev_chapter?:stringConfigRow

    /** {"uid":68,"Key":"key_chapter_passed","Value":"该章节已通关!"} */
    key_chapter_passed?:stringConfigRow

    /** {"uid":69,"Key":"key_friend_tip1","Value":"你还没有好友,快去加一些吧！"} */
    key_friend_tip1?:stringConfigRow

    /** {"uid":70,"Key":"key_friend_tip2","Value":"今天已赠送过了"} */
    key_friend_tip2?:stringConfigRow

    /** {"uid":71,"Key":"key_friend_tip3","Value":"今天已领取过了"} */
    key_friend_tip3?:stringConfigRow

    /** {"uid":72,"Key":"key_input_union_name_or_id","Value":"请输入公会名称或ID"} */
    key_input_union_name_or_id?:stringConfigRow

    /** {"uid":73,"Key":"key_player_signature_default","Value":"玩家懒，什么都没有设置。"} */
    key_player_signature_default?:stringConfigRow

    /** {"uid":74,"Key":"key_not_evolution_materials","Value":"不是进阶材料"} */
    key_not_evolution_materials?:stringConfigRow

    /** {"uid":75,"Key":"key_max_hero_grid","Value":"英雄格子数已满！"} */
    key_max_hero_grid?:stringConfigRow

    /** {"uid":76,"Key":"key_input_union_name","Value":"请输入公会名称"} */
    key_input_union_name?:stringConfigRow

    /** {"uid":77,"Key":"key_content_max_length","Value":"${name}最多不超过${count1}个中文或${count2}个字母"} */
    key_content_max_length?:stringConfigRow

    /** {"uid":78,"Key":"key_lottery_times_no_enough","Value":"抽卡次数不足"} */
    key_lottery_times_no_enough?:stringConfigRow

    /** {"uid":79,"Key":"key_union_notice_default","Value":"会长很懒，暂无公告"} */
    key_union_notice_default?:stringConfigRow

    /** {"uid":80,"Key":"key_server_id","Value":"服务器"} */
    key_server_id?:stringConfigRow

    /** {"uid":81,"Key":"key_online","Value":"在线"} */
    key_online?:stringConfigRow

    /** {"uid":82,"Key":"key_date_ago","Value":"${count}天前"} */
    key_date_ago?:stringConfigRow

    /** {"uid":83,"Key":"key_hour_ago","Value":"${count}小时前"} */
    key_hour_ago?:stringConfigRow

    /** {"uid":84,"Key":"key_minute_ago","Value":"${count}分钟前"} */
    key_minute_ago?:stringConfigRow

    /** {"uid":85,"Key":"key_second_ago","Value":"${count}秒前"} */
    key_second_ago?:stringConfigRow

    /** {"uid":86,"Key":"key_offline","Value":"离线"} */
    key_offline?:stringConfigRow

    /** {"uid":87,"Key":"key_diamond_lottery","Value":"钻石抽卡"} */
    key_diamond_lottery?:stringConfigRow

    /** {"uid":88,"Key":"key_friendship_lottery","Value":"友情点抽卡"} */
    key_friendship_lottery?:stringConfigRow

    /** {"uid":89,"Key":"key_race","Value":"联盟"} */
    key_race?:stringConfigRow

    /** {"uid":90,"Key":"key_hero_locked","Value":"英雄已锁定"} */
    key_hero_locked?:stringConfigRow

    /** {"uid":91,"Key":"key_hero_unlocked","Value":"英雄已解锁"} */
    key_hero_unlocked?:stringConfigRow

    /** {"uid":92,"Key":"key_union_name_repeat","Value":"公会名已存在"} */
    key_union_name_repeat?:stringConfigRow

    /** {"uid":93,"Key":"key_union_member_count","Value":"公会人数：${count}"} */
    key_union_member_count?:stringConfigRow

    /** {"uid":94,"Key":"key_union_apply_count","Value":"申请数量：${count}"} */
    key_union_apply_count?:stringConfigRow

    /** {"uid":95,"Key":"key_union_enter_mode0","Value":"直接加入"} */
    key_union_enter_mode0?:stringConfigRow

    /** {"uid":96,"Key":"key_union_enter_mode1","Value":"批准加入"} */
    key_union_enter_mode1?:stringConfigRow

    /** {"uid":97,"Key":"key_union_enter_mode2","Value":"不可加入"} */
    key_union_enter_mode2?:stringConfigRow

    /** {"uid":98,"Key":"key_union_member_full","Value":"公会成员已满"} */
    key_union_member_full?:stringConfigRow

    /** {"uid":99,"Key":"key_union_level_more_than","Value":"玩家等级不足"} */
    key_union_level_more_than?:stringConfigRow

    /** {"uid":100,"Key":"key_input","Value":"请输入${name}"} */
    key_input?:stringConfigRow

    /** {"uid":101,"Key":"key_union_name","Value":"公会名称"} */
    key_union_name?:stringConfigRow

    /** {"uid":102,"Key":"key_union_notice","Value":"公会公告"} */
    key_union_notice?:stringConfigRow

    /** {"uid":103,"Key":"key_mail_title","Value":"邮件标题"} */
    key_mail_title?:stringConfigRow

    /** {"uid":104,"Key":"key_mail_content","Value":"邮件内容"} */
    key_mail_content?:stringConfigRow

    /** {"uid":105,"Key":"key_union_id","Value":"公会ID"} */
    key_union_id?:stringConfigRow

    /** {"uid":106,"Key":"key_sure_to_exit_union","Value":"退出后1小时内无法再次申请加入公会，个人活跃无法转移到其他公会。您确定要退出公会？"} */
    key_sure_to_exit_union?:stringConfigRow

    /** {"uid":107,"Key":"key_president_cannot_exit_union","Value":"会长不能退出公会"} */
    key_president_cannot_exit_union?:stringConfigRow

    /** {"uid":108,"Key":"key_appoint_to_vice_president","Value":"升为长老"} */
    key_appoint_to_vice_president?:stringConfigRow

    /** {"uid":109,"Key":"key_appoint_to_member","Value":"降为会员"} */
    key_appoint_to_member?:stringConfigRow

    /** {"uid":110,"Key":"key_assignment_tip1","Value":"完成每日任务可获得活跃度,达到一定数量即可领取活跃宝箱"} */
    key_assignment_tip1?:stringConfigRow

    /** {"uid":111,"Key":"key_artifact_skill_unlock","Value":"强化${count}星解锁"} */
    key_artifact_skill_unlock?:stringConfigRow

    /** {"uid":112,"Key":"key_max_star","Value":"已达最大星级"} */
    key_max_star?:stringConfigRow

    /** {"uid":113,"Key":"key_union_job1","Value":"会长"} */
    key_union_job1?:stringConfigRow

    /** {"uid":114,"Key":"key_union_job2","Value":"长老"} */
    key_union_job2?:stringConfigRow

    /** {"uid":115,"Key":"key_union_job3","Value":"会员"} */
    key_union_job3?:stringConfigRow

    /** {"uid":116,"Key":"key_player_name","Value":"玩家昵称"} */
    key_player_name?:stringConfigRow

    /** {"uid":117,"Key":"key_player_signature","Value":"玩家签名"} */
    key_player_signature?:stringConfigRow

    /** {"uid":118,"Key":"key_friend_tip4","Value":"没有搜索到该玩家"} */
    key_friend_tip4?:stringConfigRow

    /** {"uid":119,"Key":"key_friend_tip5","Value":"请输入正确的名称或ID"} */
    key_friend_tip5?:stringConfigRow

    /** {"uid":120,"Key":"key_friend_tip6","Value":"没有要处理的好友申请"} */
    key_friend_tip6?:stringConfigRow

    /** {"uid":121,"Key":"key_friend_tip7","Value":"确定删除该好友吗？"} */
    key_friend_tip7?:stringConfigRow

    /** {"uid":122,"Key":"key_friend_tip8","Value":"删除成功"} */
    key_friend_tip8?:stringConfigRow

    /** {"uid":123,"Key":"key_friend_tip9","Value":"没有可领取的和赠送的"} */
    key_friend_tip9?:stringConfigRow

    /** {"uid":124,"Key":"key_max_level2","Value":"已满级"} */
    key_max_level2?:stringConfigRow

    /** {"uid":125,"Key":"key_no_claim","Value":"没有可领取的奖励"} */
    key_no_claim?:stringConfigRow

    /** {"uid":126,"Key":"key_free_first","Value":"首次免费"} */
    key_free_first?:stringConfigRow

    /** {"uid":127,"Key":"key_in_cooling","Value":"等待重置"} */
    key_in_cooling?:stringConfigRow

    /** {"uid":128,"Key":"key_speed_x1","Value":"战斗速度设置为默认速度"} */
    key_speed_x1?:stringConfigRow

    /** {"uid":129,"Key":"key_speed_x2","Value":"战斗速度设置为2倍速"} */
    key_speed_x2?:stringConfigRow

    /** {"uid":130,"Key":"key_skill_auto","Value":"自动释放必杀技能"} */
    key_skill_auto?:stringConfigRow

    /** {"uid":131,"Key":"key_faction_filter_0","Value":"显示全部英雄！"} */
    key_faction_filter_0?:stringConfigRow

    /** {"uid":132,"Key":"key_faction_filter_1","Value":"只显示武装英雄！"} */
    key_faction_filter_1?:stringConfigRow

    /** {"uid":133,"Key":"key_faction_filter_2","Value":"只显示机械英雄！"} */
    key_faction_filter_2?:stringConfigRow

    /** {"uid":134,"Key":"key_faction_filter_3","Value":"只显示变种英雄！"} */
    key_faction_filter_3?:stringConfigRow

    /** {"uid":135,"Key":"key_faction_filter_4","Value":"只显示僵尸英雄！"} */
    key_faction_filter_4?:stringConfigRow

    /** {"uid":136,"Key":"key_faction_filter_5","Value":"只显示超能英雄！"} */
    key_faction_filter_5?:stringConfigRow

    /** {"uid":137,"Key":"key_faction_filter_6","Value":"只显示毁灭英雄！"} */
    key_faction_filter_6?:stringConfigRow

    /** {"uid":138,"Key":"key_exist_nickname","Value":"已存在的昵称"} */
    key_exist_nickname?:stringConfigRow

    /** {"uid":139,"Key":"key_gender_0","Value":"性别"} */
    key_gender_0?:stringConfigRow

    /** {"uid":140,"Key":"key_gender_1","Value":"男"} */
    key_gender_1?:stringConfigRow

    /** {"uid":141,"Key":"key_gender_2","Value":"女"} */
    key_gender_2?:stringConfigRow

    /** {"uid":142,"Key":"key_friend_tip10","Value":"空闲中"} */
    key_friend_tip10?:stringConfigRow

    /** {"uid":143,"Key":"key_friend_tip11","Value":"没有要处理的申请消息"} */
    key_friend_tip11?:stringConfigRow

    /** {"uid":144,"Key":"key_friend_tip12","Value":"已自动处理所有佣兵申请"} */
    key_friend_tip12?:stringConfigRow

    /** {"uid":145,"Key":"key_friend_tip13","Value":"已忽略所有申请"} */
    key_friend_tip13?:stringConfigRow

    /** {"uid":146,"Key":"key_friend_tip14","Value":"好友申请已发送"} */
    key_friend_tip14?:stringConfigRow

    /** {"uid":147,"Key":"key_confirm_ok","Value":"确定"} */
    key_confirm_ok?:stringConfigRow

    /** {"uid":148,"Key":"key_confirm_cancel","Value":"取消"} */
    key_confirm_cancel?:stringConfigRow

    /** {"uid":149,"Key":"key_xuanshang_tip1","Value":"个人悬赏${count}次"} */
    key_xuanshang_tip1?:stringConfigRow

    /** {"uid":150,"Key":"key_xuanshang_tip2","Value":"团队悬赏${count}次"} */
    key_xuanshang_tip2?:stringConfigRow

    /** {"uid":151,"Key":"key_xuanshang_tip3","Value":"当前悬赏任务不需要刷新"} */
    key_xuanshang_tip3?:stringConfigRow

    /** {"uid":152,"Key":"key_xuanshang_tip4","Value":"该英雄正在执行任务"} */
    key_xuanshang_tip4?:stringConfigRow

    /** {"uid":153,"Key":"key_xuanshang_tip5","Value":"派遣英雄已满"} */
    key_xuanshang_tip5?:stringConfigRow

    /** {"uid":154,"Key":"key_xuanshang_tip6","Value":"我的派遣英雄已满"} */
    key_xuanshang_tip6?:stringConfigRow

    /** {"uid":155,"Key":"key_common_tip1","Value":"任务未完成"} */
    key_common_tip1?:stringConfigRow

    /** {"uid":156,"Key":"key_common_tip2","Value":"该好友主力阵容为空"} */
    key_common_tip2?:stringConfigRow

    /** {"uid":157,"Key":"key_common_tip3","Value":"未上榜"} */
    key_common_tip3?:stringConfigRow

    /** {"uid":158,"Key":"key_no_suit_equip","Value":"没有合适的装备"} */
    key_no_suit_equip?:stringConfigRow

    /** {"uid":159,"Key":"key_lottery_tip1","Value":"抽卡达到一定次数可以获得累积奖励哦"} */
    key_lottery_tip1?:stringConfigRow

    /** {"uid":160,"Key":"key_lottery_tip2","Value":"再抽取${times}次英雄即可获得累计奖励"} */
    key_lottery_tip2?:stringConfigRow

    /** {"uid":161,"Key":"key_lottery_tip3","Value":"现在有可以领取的抽卡奖励哦"} */
    key_lottery_tip3?:stringConfigRow

    /** {"uid":162,"Key":"key_sure_to_join_blacklist","Value":"确认将对方加入黑名单，将解除好友关系，不再收到对方聊天及申请消息"} */
    key_sure_to_join_blacklist?:stringConfigRow

    /** {"uid":163,"Key":"key_current_mission","Value":"当前关卡：${house}-${level}"} */
    key_current_mission?:stringConfigRow

    /** {"uid":164,"Key":"key_common_tip4","Value":"挑战首领"} */
    key_common_tip4?:stringConfigRow

    /** {"uid":165,"Key":"key_common_tip5","Value":"挑战摩天楼"} */
    key_common_tip5?:stringConfigRow

    /** {"uid":166,"Key":"key_common_tip6","Value":"该玩家已被你拉入黑名单"} */
    key_common_tip6?:stringConfigRow

    /** {"uid":167,"Key":"key_common_tip7","Value":"该玩家已经是你的好友了"} */
    key_common_tip7?:stringConfigRow

    /** {"uid":168,"Key":"key_common_tip8","Value":"未找到挑战记录"} */
    key_common_tip8?:stringConfigRow

    /** {"uid":169,"Key":"key_common_tip9","Value":"公会成员"} */
    key_common_tip9?:stringConfigRow

    /** {"uid":170,"Key":"key_common_tip10","Value":"好友"} */
    key_common_tip10?:stringConfigRow

    /** {"uid":171,"Key":"key_common_tip11","Value":"赠送和领取友情点次数已达上限"} */
    key_common_tip11?:stringConfigRow

    /** {"uid":172,"Key":"key_common_tip12","Value":"对悬赏任务进行刷新?"} */
    key_common_tip12?:stringConfigRow

    /** {"uid":173,"Key":"key_common_tip13","Value":"刷新"} */
    key_common_tip13?:stringConfigRow

    /** {"uid":174,"Key":"key_common_tip14","Value":"今日赠送友情点次数已达上限"} */
    key_common_tip14?:stringConfigRow

    /** {"uid":175,"Key":"key_common_tip15","Value":"今日可领取友情点次数已达上限"} */
    key_common_tip15?:stringConfigRow

    /** {"uid":176,"Key":"key_common_tip16","Value":"可同时申请数达到上限"} */
    key_common_tip16?:stringConfigRow

    /** {"uid":177,"Key":"key_common_tip17","Value":"每人最多可同时借用3个英雄"} */
    key_common_tip17?:stringConfigRow

    /** {"uid":178,"Key":"key_common_tip18","Value":"每周只能使用一次佣兵"} */
    key_common_tip18?:stringConfigRow

    /** {"uid":179,"Key":"key_common_tip19","Value":"雇佣英雄只能同时上场一个"} */
    key_common_tip19?:stringConfigRow

    /** {"uid":180,"Key":"key_no_enough_material","Value":"没有足够的材料"} */
    key_no_enough_material?:stringConfigRow

    /** {"uid":181,"Key":"key_strong_exp","Value":"强化经验"} */
    key_strong_exp?:stringConfigRow

    /** {"uid":182,"Key":"key_signature","Value":"签名"} */
    key_signature?:stringConfigRow

    /** {"uid":183,"Key":"key_change_success","Value":"修改成功"} */
    key_change_success?:stringConfigRow

    /** {"uid":184,"Key":"key_avatar","Value":"头像"} */
    key_avatar?:stringConfigRow

    /** {"uid":185,"Key":"key_select_main_troop","Value":"请选择${count}个英雄"} */
    key_select_main_troop?:stringConfigRow

    /** {"uid":186,"Key":"key_nickname_cannot_same_with_old","Value":"新昵称不能与老昵称相同"} */
    key_nickname_cannot_same_with_old?:stringConfigRow

    /** {"uid":187,"Key":"key_no_split_hero","Value":"无可遣散英雄"} */
    key_no_split_hero?:stringConfigRow

    /** {"uid":188,"Key":"key_sure_to_dismiss_union","Value":"公会解散后，所有成员变为无公会状态，归属原公会的个人贡献和公会资金都将清空"} */
    key_sure_to_dismiss_union?:stringConfigRow

    /** {"uid":189,"Key":"key_union_apply_send","Value":"入会申请已发送"} */
    key_union_apply_send?:stringConfigRow

    /** {"uid":190,"Key":"key_in_other_union","Value":"玩家已加入其他公会"} */
    key_in_other_union?:stringConfigRow

    /** {"uid":191,"Key":"key_same_union_name","Value":"公会名称相同"} */
    key_same_union_name?:stringConfigRow

    /** {"uid":192,"Key":"key_modify_success","Value":"修改成功"} */
    key_modify_success?:stringConfigRow

    /** {"uid":193,"Key":"key_union_dismiss","Value":"${name}公会已解散"} */
    key_union_dismiss?:stringConfigRow

    /** {"uid":194,"Key":"key_operate_success","Value":"操作成功"} */
    key_operate_success?:stringConfigRow

    /** {"uid":195,"Key":"key_send_success","Value":"发送成功"} */
    key_send_success?:stringConfigRow

    /** {"uid":196,"Key":"key_vip_unlock","Value":"VIP${level}解锁"} */
    key_vip_unlock?:stringConfigRow

    /** {"uid":197,"Key":"key_sure_to_transform_prisident","Value":"是否将会长职位移交给${name}？"} */
    key_sure_to_transform_prisident?:stringConfigRow

    /** {"uid":198,"Key":"key_sure_to_appointment_vice","Value":"是否将${name}任命为长老，长老将拥有除了任命会长，任命长老之外的一切权力？"} */
    key_sure_to_appointment_vice?:stringConfigRow

    /** {"uid":199,"Key":"key_sure_to_appointment_member","Value":"是否将${name}降职为成员？"} */
    key_sure_to_appointment_member?:stringConfigRow

    /** {"uid":200,"Key":"key_sure_to_kickout","Value":"是否将${name}驱逐出公会？"} */
    key_sure_to_kickout?:stringConfigRow

    /** {"uid":201,"Key":"key_evolute_to_upgrade","Value":"需要进阶才能升级"} */
    key_evolute_to_upgrade?:stringConfigRow

    /** {"uid":202,"Key":"key_all_mission_passed","Value":"已完成全部关卡"} */
    key_all_mission_passed?:stringConfigRow

    /** {"uid":203,"Key":"key_select_faction_card","Value":"选择一个联盟，可获得对应的精英英雄！"} */
    key_select_faction_card?:stringConfigRow

    /** {"uid":204,"Key":"key_faction_tip_1","Value":"武装联盟英雄，克制变种联盟英雄，被机械联盟英雄克制。"} */
    key_faction_tip_1?:stringConfigRow

    /** {"uid":205,"Key":"key_faction_tip_2","Value":"机械联盟英雄，克制武装联盟英雄，被僵尸联盟英雄克制。"} */
    key_faction_tip_2?:stringConfigRow

    /** {"uid":206,"Key":"key_faction_tip_3","Value":"变种联盟英雄，克制僵尸联盟英雄，被武装联盟英雄克制。"} */
    key_faction_tip_3?:stringConfigRow

    /** {"uid":207,"Key":"key_faction_tip_4","Value":"僵尸联盟英雄，克制机械联盟英雄，被变种联盟英雄克制。"} */
    key_faction_tip_4?:stringConfigRow

    /** {"uid":208,"Key":"key_faction_tip_5","Value":"超能联盟英雄，只和毁灭联盟英雄互相克制。"} */
    key_faction_tip_5?:stringConfigRow

    /** {"uid":209,"Key":"key_faction_tip_6","Value":"毁灭联盟英雄，只和超能联盟英雄互相克制。"} */
    key_faction_tip_6?:stringConfigRow

    /** {"uid":210,"Key":"key_career_tip_1","Value":"力量型英雄，可造成物理伤害！"} */
    key_career_tip_1?:stringConfigRow

    /** {"uid":211,"Key":"key_career_tip_2","Value":"智力型英雄，可造成魔法伤害！"} */
    key_career_tip_2?:stringConfigRow

    /** {"uid":212,"Key":"key_career_tip_3","Value":"敏捷型英雄，可造成物理伤害！"} */
    key_career_tip_3?:stringConfigRow

    /** {"uid":213,"Key":"key_only_show_faction_hero","Value":"只显示${faction}英雄！"} */
    key_only_show_faction_hero?:stringConfigRow

    /** {"uid":214,"Key":"key_claim","Value":"领 取"} */
    key_claim?:stringConfigRow

    /** {"uid":215,"Key":"key_free_times","Value":"免费(${count1}/${count2})"} */
    key_free_times?:stringConfigRow

    /** {"uid":216,"Key":"key_click_hero_to_dispatch","Value":"请点击英雄头像派遣！"} */
    key_click_hero_to_dispatch?:stringConfigRow

    /** {"uid":217,"Key":"key_activity_remain_time","Value":"剩余时间：${time}"} */
    key_activity_remain_time?:stringConfigRow

    /** {"uid":218,"Key":"key_rank","Value":"第${rank}名"} */
    key_rank?:stringConfigRow

    /** {"uid":219,"Key":"key_leichong_desc","Value":"<b><color=#133470>累计充值</c><color=#F5F5BC> ${cost} </c><color=#133470>元可领取</c><color=${color}>(${cur}/${total})</c><b>"} */
    key_leichong_desc?:stringConfigRow

    /** {"uid":220,"Key":"key_leixiao_desc","Value":"<b><color=#133470>累计消耗</c><color=#F5F5BC> ${cost} </c><img src='benefit_icon_diamond'/><color=#133470>可领取</c><color=${color}>(${cur}/${total})</c><b>"} */
    key_leixiao_desc?:stringConfigRow

    /** {"uid":221,"Key":"key_goto_recharge","Value":"去充值"} */
    key_goto_recharge?:stringConfigRow

    /** {"uid":222,"Key":"key_claimed","Value":"已领取"} */
    key_claimed?:stringConfigRow

    /** {"uid":223,"Key":"key_activity_finished","Value":"活动已结束"} */
    key_activity_finished?:stringConfigRow

    /** {"uid":224,"Key":"key_accum_signday","Value":"累计签到${day}天"} */
    key_accum_signday?:stringConfigRow

    /** {"uid":225,"Key":"key_energyrecoveradd","Value":"受伤回能"} */
    key_energyrecoveradd?:stringConfigRow

    /** {"uid":226,"Key":"key_rapid","Value":"迅捷等级"} */
    key_rapid?:stringConfigRow

    /** {"uid":227,"Key":"key_skill_upgrade","Value":"技能升级"} */
    key_skill_upgrade?:stringConfigRow

    /** {"uid":228,"Key":"key_day","Value":"第${day}天"} */
    key_day?:stringConfigRow

    /** {"uid":229,"Key":"key_currency","Value":"¥"} */
    key_currency?:stringConfigRow

    /** {"uid":230,"Key":"key_please_input_exchange_code","Value":"请输入兑换码"} */
    key_please_input_exchange_code?:stringConfigRow

    /** {"uid":231,"Key":"key_exchange_code_error","Value":"兑换码验证失败"} */
    key_exchange_code_error?:stringConfigRow

    /** {"uid":232,"Key":"key_activity_after_time","Value":"${time}后结束"} */
    key_activity_after_time?:stringConfigRow

    /** {"uid":233,"Key":"key_discount","Value":"${discount}折"} */
    key_discount?:stringConfigRow

    /** {"uid":234,"Key":"key_remain_count","Value":"今日剩余次数：${cur}/${total}"} */
    key_remain_count?:stringConfigRow

    /** {"uid":235,"Key":"key_after_reborn","Value":"${time}后复活"} */
    key_after_reborn?:stringConfigRow

    /** {"uid":236,"Key":"key_challenge_limit","Value":"今日挑战次数已达上限"} */
    key_challenge_limit?:stringConfigRow

    /** {"uid":237,"Key":"key_boss_no_reborn","Value":"复活期间不可挑战"} */
    key_boss_no_reborn?:stringConfigRow

    /** {"uid":238,"Key":"key_wan","Value":"${count}万"} */
    key_wan?:stringConfigRow

    /** {"uid":239,"Key":"key_no_rank","Value":"未上榜"} */
    key_no_rank?:stringConfigRow

    /** {"uid":240,"Key":"key_day_lock","Value":"第${day}天尚未解锁"} */
    key_day_lock?:stringConfigRow

    /** {"uid":241,"Key":"key_sure_to_cost_diamond","Value":"确认消耗${count}钻石？"} */
    key_sure_to_cost_diamond?:stringConfigRow

    /** {"uid":242,"Key":"key_hero_less_than","Value":"英雄少于${count}个，无法进入共享花坛"} */
    key_hero_less_than?:stringConfigRow

    /** {"uid":243,"Key":"key_unlock_flower_slot","Value":"确认消耗${count}钻石，解锁占位"} */
    key_unlock_flower_slot?:stringConfigRow

    /** {"uid":244,"Key":"key_please_unlock_slot","Value":"请先解锁前面的占位"} */
    key_please_unlock_slot?:stringConfigRow

    /** {"uid":245,"Key":"key_impeach_success","Value":"弹劾发起成功！"} */
    key_impeach_success?:stringConfigRow

    /** {"uid":246,"Key":"key_bind_account","Value":"账号绑定"} */
    key_bind_account?:stringConfigRow

    /** {"uid":247,"Key":"key_binded","Value":"已绑定"} */
    key_binded?:stringConfigRow

    /** {"uid":248,"Key":"key_no_enough_union_point","Value":"公会活跃度不足"} */
    key_no_enough_union_point?:stringConfigRow

    /** {"uid":249,"Key":"key_no_permission_openhunt","Value":"需要会长或长老才能开启${name}"} */
    key_no_permission_openhunt?:stringConfigRow

    /** {"uid":250,"Key":"key_mission","Value":"关卡"} */
    key_mission?:stringConfigRow

    /** {"uid":251,"Key":"key_scroll_to_bottom","Value":"已到最底部"} */
    key_scroll_to_bottom?:stringConfigRow

    /** {"uid":252,"Key":"key_chess_circle","Value":"圈"} */
    key_chess_circle?:stringConfigRow

    /** {"uid":253,"Key":"key_chess_block","Value":"格"} */
    key_chess_block?:stringConfigRow

    /** {"uid":254,"Key":"key_desc_1","Value":"天"} */
    key_desc_1?:stringConfigRow

    /** {"uid":255,"Key":"key_desc_2","Value":"小时"} */
    key_desc_2?:stringConfigRow

    /** {"uid":256,"Key":"key_desc_3","Value":"分钟"} */
    key_desc_3?:stringConfigRow

    /** {"uid":257,"Key":"key_desc_4","Value":"生命"} */
    key_desc_4?:stringConfigRow

    /** {"uid":258,"Key":"key_desc_5","Value":"攻击"} */
    key_desc_5?:stringConfigRow

    /** {"uid":259,"Key":"key_desc_6","Value":"防御"} */
    key_desc_6?:stringConfigRow

    /** {"uid":260,"Key":"key_desc_7","Value":"暴击"} */
    key_desc_7?:stringConfigRow

    /** {"uid":261,"Key":"key_desc_8","Value":"吸血"} */
    key_desc_8?:stringConfigRow

    /** {"uid":262,"Key":"key_desc_9","Value":"闪避"} */
    key_desc_9?:stringConfigRow

    /** {"uid":263,"Key":"key_desc_10","Value":"命中"} */
    key_desc_10?:stringConfigRow

    /** {"uid":264,"Key":"key_desc_11","Value":"礼包已结束,无法购买!"} */
    key_desc_11?:stringConfigRow

    /** {"uid":265,"Key":"key_desc_12","Value":"超级摩天楼"} */
    key_desc_12?:stringConfigRow

    /** {"uid":266,"Key":"key_desc_13","Value":"机械之窟"} */
    key_desc_13?:stringConfigRow

    /** {"uid":267,"Key":"key_desc_14","Value":"变种之柱"} */
    key_desc_14?:stringConfigRow

    /** {"uid":268,"Key":"key_desc_15","Value":"僵尸之墓"} */
    key_desc_15?:stringConfigRow

    /** {"uid":269,"Key":"key_desc_16","Value":"已申请人数"} */
    key_desc_16?:stringConfigRow

    /** {"uid":270,"Key":"key_desc_17","Value":"第${count}层"} */
    key_desc_17?:stringConfigRow

    /** {"uid":271,"Key":"key_desc_18","Value":"正在帮助 ${name} 执行任务"} */
    key_desc_18?:stringConfigRow

    /** {"uid":272,"Key":"key_desc_19","Value":"正在档案台中休息"} */
    key_desc_19?:stringConfigRow

    /** {"uid":273,"Key":"key_desc_20","Value":"双倍领取"} */
    key_desc_20?:stringConfigRow

    /** {"uid":274,"Key":"key_desc_21","Value":"领取奖励"} */
    key_desc_21?:stringConfigRow

    /** {"uid":275,"Key":"key_desc_22","Value":"前 往"} */
    key_desc_22?:stringConfigRow

    /** {"uid":276,"Key":"key_desc_23","Value":"激活礼包"} */
    key_desc_23?:stringConfigRow

    /** {"uid":277,"Key":"key_desc_24","Value":"钻石"} */
    key_desc_24?:stringConfigRow

    /** {"uid":278,"Key":"key_desc_25","Value":"净化建筑"} */
    key_desc_25?:stringConfigRow

    /** {"uid":279,"Key":"key_desc_26","Value":"礼包已结束,无法领取.未领取的奖励稍后将会通过邮件发送"} */
    key_desc_26?:stringConfigRow

    /** {"uid":280,"Key":"key_desc_27","Value":"请先激活成长礼包"} */
    key_desc_27?:stringConfigRow

    /** {"uid":281,"Key":"key_desc_28","Value":"后结束"} */
    key_desc_28?:stringConfigRow

    /** {"uid":282,"Key":"key_desc_29","Value":"已结束"} */
    key_desc_29?:stringConfigRow

    /** {"uid":283,"Key":"key_desc_30","Value":"已拥有"} */
    key_desc_30?:stringConfigRow

    /** {"uid":284,"Key":"key_desc_31","Value":"领取"} */
    key_desc_31?:stringConfigRow

    /** {"uid":285,"Key":"key_desc_32","Value":"观看"} */
    key_desc_32?:stringConfigRow

    /** {"uid":286,"Key":"key_desc_33","Value":"可以从每日任务和每周任务宝箱中获取"} */
    key_desc_33?:stringConfigRow

    /** {"uid":287,"Key":"key_desc_34","Value":"通过智慧树的考验可获得智慧徽章"} */
    key_desc_34?:stringConfigRow

    /** {"uid":288,"Key":"key_desc_35","Value":"继续领取需要解锁高级礼包,是否前往解锁?"} */
    key_desc_35?:stringConfigRow

    /** {"uid":289,"Key":"key_desc_36","Value":"去解锁"} */
    key_desc_36?:stringConfigRow

    /** {"uid":290,"Key":"key_desc_37","Value":"续期"} */
    key_desc_37?:stringConfigRow

    /** {"uid":291,"Key":"key_desc_38","Value":"购买"} */
    key_desc_38?:stringConfigRow

    /** {"uid":292,"Key":"key_desc_39","Value":"免费"} */
    key_desc_39?:stringConfigRow

    /** {"uid":293,"Key":"key_desc_40","Value":"礼包已售罄"} */
    key_desc_40?:stringConfigRow

    /** {"uid":294,"Key":"key_desc_41","Value":"活动已结束,请下次再来"} */
    key_desc_41?:stringConfigRow

    /** {"uid":295,"Key":"key_desc_42","Value":"礼包已领取"} */
    key_desc_42?:stringConfigRow

    /** {"uid":296,"Key":"key_desc_43","Value":"vip等级已达到最高"} */
    key_desc_43?:stringConfigRow

    /** {"uid":297,"Key":"key_desc_44","Value":"小时后消失"} */
    key_desc_44?:stringConfigRow

    /** {"uid":298,"Key":"key_desc_45","Value":"活动已结束 排名公示中"} */
    key_desc_45?:stringConfigRow

    /** {"uid":299,"Key":"key_desc_46","Value":"活动倒计时"} */
    key_desc_46?:stringConfigRow

    /** {"uid":300,"Key":"key_desc_47","Value":"心愿骰子数量不足"} */
    key_desc_47?:stringConfigRow

    /** {"uid":301,"Key":"key_desc_48","Value":"普通骰子数量不足"} */
    key_desc_48?:stringConfigRow

    /** {"uid":302,"Key":"key_desc_49","Value":"已经穷到小偷都无法下手了"} */
    key_desc_49?:stringConfigRow

    /** {"uid":303,"Key":"key_desc_50","Value":"累计完成"} */
    key_desc_50?:stringConfigRow

    /** {"uid":304,"Key":"key_desc_51","Value":"免费获得一个普通骰子"} */
    key_desc_51?:stringConfigRow

    /** {"uid":305,"Key":"key_desc_52","Value":"今日已获取"} */
    key_desc_52?:stringConfigRow

    /** {"uid":306,"Key":"key_desc_53","Value":"次"} */
    key_desc_53?:stringConfigRow

    /** {"uid":307,"Key":"key_desc_54","Value":"领取"} */
    key_desc_54?:stringConfigRow

    /** {"uid":308,"Key":"key_desc_55","Value":"活动已结束,请下期活动再来"} */
    key_desc_55?:stringConfigRow

    /** {"uid":309,"Key":"key_desc_56","Value":"骰子数量不足10个"} */
    key_desc_56?:stringConfigRow

    /** {"uid":310,"Key":"key_desc_57","Value":"领取和赠送成功"} */
    key_desc_57?:stringConfigRow

    /** {"uid":311,"Key":"key_desc_58","Value":"赠送成功"} */
    key_desc_58?:stringConfigRow

    /** {"uid":312,"Key":"key_desc_59","Value":"领取成功"} */
    key_desc_59?:stringConfigRow

    /** {"uid":313,"Key":"key_desc_60","Value":"免费刷新"} */
    key_desc_60?:stringConfigRow

    /** {"uid":314,"Key":"key_desc_61","Value":"暂无玩家达成奖励进度"} */
    key_desc_61?:stringConfigRow

    /** {"uid":315,"Key":"key_desc_62","Value":"未找到战斗记录"} */
    key_desc_62?:stringConfigRow

    /** {"uid":316,"Key":"key_desc_63","Value":"限时开放,周${openTime}开启"} */
    key_desc_63?:stringConfigRow

    /** {"uid":317,"Key":"key_desc_64","Value":"伤害量"} */
    key_desc_64?:stringConfigRow

    /** {"uid":318,"Key":"key_desc_65","Value":"治疗量"} */
    key_desc_65?:stringConfigRow

    /** {"uid":319,"Key":"key_desc_66","Value":"承受伤害量"} */
    key_desc_66?:stringConfigRow

    /** {"uid":320,"Key":"key_desc_67","Value":"需要"} */
    key_desc_67?:stringConfigRow

    /** {"uid":321,"Key":"key_desc_68","Value":"个"} */
    key_desc_68?:stringConfigRow

    /** {"uid":322,"Key":"key_desc_69","Value":"英雄"} */
    key_desc_69?:stringConfigRow

    /** {"uid":323,"Key":"key_desc_70","Value":"没有符合条件的英雄可派遣"} */
    key_desc_70?:stringConfigRow

    /** {"uid":324,"Key":"key_desc_71","Value":"派遣英雄不满足条件"} */
    key_desc_71?:stringConfigRow

    /** {"uid":325,"Key":"key_pass_mission","Value":"通关章节${buildingId}-${missionId}"} */
    key_pass_mission?:stringConfigRow

    /** {"uid":326,"Key":"key_chapter_progress","Value":"副本“${name}”进度超过${progress}%"} */
    key_chapter_progress?:stringConfigRow

    /** {"uid":327,"Key":"key_chapter_condition","Value":"副本解锁条件"} */
    key_chapter_condition?:stringConfigRow

    /** {"uid":328,"Key":"key_open_wonder","Value":"开启冒险"} */
    key_open_wonder?:stringConfigRow

    /** {"uid":329,"Key":"key_continue_wonder","Value":"继续冒险"} */
    key_continue_wonder?:stringConfigRow

    /** {"uid":330,"Key":"key_need_close_current_wonder","Value":"需要关闭“${name}”，才能开启冒险"} */
    key_need_close_current_wonder?:stringConfigRow

    /** {"uid":331,"Key":"key_please_select_battle_hero","Value":"请选择出战${count}位英雄"} */
    key_please_select_battle_hero?:stringConfigRow

    /** {"uid":332,"Key":"key_assist_hero_limit","Value":"只能邀请${count}位英雄助阵"} */
    key_assist_hero_limit?:stringConfigRow

    /** {"uid":333,"Key":"key_please_select_assist_hero","Value":"必须选择${count}位英雄助阵"} */
    key_please_select_assist_hero?:stringConfigRow

    /** {"uid":334,"Key":"key_dungeon_no_enough_challenge","Value":"今日已没有剩余的挑战次数"} */
    key_dungeon_no_enough_challenge?:stringConfigRow

    /** {"uid":335,"Key":"key_dungeon_finish_mission","Value":"地牢关卡已全部通关"} */
    key_dungeon_finish_mission?:stringConfigRow

    /** {"uid":336,"Key":"key_layer_no","Value":"第${count}层"} */
    key_layer_no?:stringConfigRow

    /** {"uid":337,"Key":"key_empty_bag","Value":"背包中没有任何东西"} */
    key_empty_bag?:stringConfigRow

    /** {"uid":338,"Key":"key_developing","Value":"敬请期待"} */
    key_developing?:stringConfigRow

    /** {"uid":339,"Key":"key_auto_skill_tip","Value":"主动释放控制类必杀技可以更好掌握\n时机打断敌方施法"} */
    key_auto_skill_tip?:stringConfigRow

    /** {"uid":340,"Key":"key_hero_duty_1","Value":"输出"} */
    key_hero_duty_1?:stringConfigRow

    /** {"uid":341,"Key":"key_hero_duty_2","Value":"辅助"} */
    key_hero_duty_2?:stringConfigRow

    /** {"uid":342,"Key":"key_hero_duty_3","Value":"坦克"} */
    key_hero_duty_3?:stringConfigRow

    /** {"uid":343,"Key":"key_hero_duty_4","Value":"控制"} */
    key_hero_duty_4?:stringConfigRow

    /** {"uid":344,"Key":"key_goto_strong_equip_tip","Value":"未满星的蓝色装备及以上才可以进行强化"} */
    key_goto_strong_equip_tip?:stringConfigRow

    /** {"uid":345,"Key":"key_market_title10","Value":"成长礼包"} */
    key_market_title10?:stringConfigRow

    /** {"uid":346,"Key":"key_market_title11","Value":"活跃礼包"} */
    key_market_title11?:stringConfigRow

    /** {"uid":347,"Key":"key_market_title12","Value":"智慧树礼包"} */
    key_market_title12?:stringConfigRow

    /** {"uid":348,"Key":"key_market_title20","Value":"每日特惠"} */
    key_market_title20?:stringConfigRow

    /** {"uid":349,"Key":"key_market_title21","Value":"每周特惠"} */
    key_market_title21?:stringConfigRow

    /** {"uid":350,"Key":"key_market_title22","Value":"每月特惠"} */
    key_market_title22?:stringConfigRow

    /** {"uid":351,"Key":"key_market_title23","Value":"钻石商城"} */
    key_market_title23?:stringConfigRow

    /** {"uid":352,"Key":"key_market_title30","Value":"僵尸骰子"} */
    key_market_title30?:stringConfigRow

    /** {"uid":353,"Key":"key_market_title31","Value":"夺宝奇兵"} */
    key_market_title31?:stringConfigRow

    /** {"uid":354,"Key":"key_market_title32","Value":"世界BOSS"} */
    key_market_title32?:stringConfigRow

    /** {"uid":355,"Key":"key_monthcard_remain_day","Value":"月卡剩余${day}"} */
    key_monthcard_remain_day?:stringConfigRow

    /** {"uid":356,"Key":"key_vip_bonus","Value":"VIP${level} 奖励"} */
    key_vip_bonus?:stringConfigRow

    /** {"uid":357,"Key":"key_vip_privilege","Value":"VIP${level} 特权"} */
    key_vip_privilege?:stringConfigRow

    /** {"uid":358,"Key":"key_active_gift_tip","Value":"<b><color=#3e779f>可以从</c><color=#b6a047>每日任务</c><color=#3e779f>和</c><color=#b6a047>每周任务</c><color=#3e779f>宝箱中获得</c></b>"} */
    key_active_gift_tip?:stringConfigRow

    /** {"uid":359,"Key":"key_wisdom_gift_tip","Value":"<b><color=#3e779f>通过</c><color=#b6a047>智慧树的考验</c><color=#3e779f>可获得</c><color=#b6a047>智慧徽章</c></b>"} */
    key_wisdom_gift_tip?:stringConfigRow

    /** {"uid":360,"Key":"key_gift_finished","Value":"该礼包已结束,无法领取,未领取的奖励\n稍后将会通过邮件发送"} */
    key_gift_finished?:stringConfigRow

    /** {"uid":361,"Key":"key_claim_gift_tip","Value":"继续领取需要解锁高级礼包,是否前往解锁?"} */
    key_claim_gift_tip?:stringConfigRow

    /** {"uid":362,"Key":"key_goto_unlock","Value":"去解锁"} */
    key_goto_unlock?:stringConfigRow

    /** {"uid":363,"Key":"key_finished","Value":"已结束"} */
    key_finished?:stringConfigRow

    /** {"uid":364,"Key":"key_gift_sell_out","Value":"礼包已售罄"} */
    key_gift_sell_out?:stringConfigRow

    /** {"uid":365,"Key":"key_come_back_again","Value":"，请下次再来"} */
    key_come_back_again?:stringConfigRow

    /** {"uid":366,"Key":"key_gift_claimed","Value":"礼包已领取"} */
    key_gift_claimed?:stringConfigRow

    /** {"uid":367,"Key":"key_free","Value":"免费"} */
    key_free?:stringConfigRow

    /** {"uid":368,"Key":"key_skip_battle_tip","Value":"可跳过 智慧树考验、超级摩天楼、奇妙时空"} */
    key_skip_battle_tip?:stringConfigRow

    /** {"uid":369,"Key":"key_no_enough_ex","Value":"${name}不足，无法升级。是否前往获取更多${name}?"} */
    key_no_enough_ex?:stringConfigRow

    /** {"uid":370,"Key":"key_goto","Value":"前往"} */
    key_goto?:stringConfigRow

    /** {"uid":371,"Key":"key_bonus_reset_time","Value":"奖励重置倒计时"} */
    key_bonus_reset_time?:stringConfigRow

    /** {"uid":372,"Key":"key_alert_title","Value":"友情提示"} */
    key_alert_title?:stringConfigRow

    /** {"uid":373,"Key":"key_network_error","Value":"网络连接失败，请检查网络或者稍后再试"} */
    key_network_error?:stringConfigRow

    /** {"uid":374,"Key":"key_buy","Value":"购买"} */
    key_buy?:stringConfigRow

    /** {"uid":375,"Key":"key_renewal","Value":"续期"} */
    key_renewal?:stringConfigRow

    /** {"uid":376,"Key":"key_star","Value":"${count}星"} */
    key_star?:stringConfigRow

    /** {"uid":377,"Key":"key_active_gift","Value":"激活礼包"} */
    key_active_gift?:stringConfigRow

    /** {"uid":378,"Key":"key_remain_active_time","Value":"剩余激活时间"} */
    key_remain_active_time?:stringConfigRow

    /** {"uid":379,"Key":"key_no_buy_gift","Value":"该礼包已结束，无法购买"} */
    key_no_buy_gift?:stringConfigRow

    /** {"uid":380,"Key":"key_dungeon_process","Value":"第${level}层"} */
    key_dungeon_process?:stringConfigRow

    /** {"uid":381,"Key":"key_dungeon_hero_leave","Value":"您的英雄已经离家出走，今日的地牢挑战无法继续"} */
    key_dungeon_hero_leave?:stringConfigRow

    /** {"uid":382,"Key":"key_not_in_union","Value":"您未加入任何公会"} */
    key_not_in_union?:stringConfigRow

    /** {"uid":383,"Key":"key_guild_join_cd","Value":"加入新公会后，需要等待${time}后可使用"} */
    key_guild_join_cd?:stringConfigRow

    /** {"uid":384,"Key":"key_skip_ad","Value":"已为您跳过广告"} */
    key_skip_ad?:stringConfigRow

    /** {"uid":385,"Key":"key_lottery_chance","Value":"抽卡概率"} */
    key_lottery_chance?:stringConfigRow

    /** {"uid":386,"Key":"key_genius_point_not_enough","Value":"${name}不足，无法点亮"} */
    key_genius_point_not_enough?:stringConfigRow

    /** {"uid":387,"Key":"key_genius_point0","Value":"普通天赋点"} */
    key_genius_point0?:stringConfigRow

    /** {"uid":388,"Key":"key_genius_point1","Value":"中级天赋点"} */
    key_genius_point1?:stringConfigRow

    /** {"uid":389,"Key":"key_genius_point2","Value":"高级天赋点"} */
    key_genius_point2?:stringConfigRow

    /** {"uid":390,"Key":"key_property_addition","Value":"属性加成："} */
    key_property_addition?:stringConfigRow

    /** {"uid":391,"Key":"key_auto_energy","Value":"每秒回能"} */
    key_auto_energy?:stringConfigRow

    /** {"uid":392,"Key":"key_hit_energy","Value":"攻击回能"} */
    key_hit_energy?:stringConfigRow

    /** {"uid":393,"Key":"key_be_hit_energy","Value":"受击回能"} */
    key_be_hit_energy?:stringConfigRow

    /** {"uid":394,"Key":"key_interval_cd","Value":"普攻间隔"} */
    key_interval_cd?:stringConfigRow

    /** {"uid":395,"Key":"key_arrive","Value":"需达到"} */
    key_arrive?:stringConfigRow

    /** {"uid":396,"Key":"key_update_package","Value":"有新版本可更新，请重启游戏！"} */
    key_update_package?:stringConfigRow

    /** {"uid":397,"Key":"key_dungeon_assist_less_than","Value":"助力英雄不满两名，无法开启挑战"} */
    key_dungeon_assist_less_than?:stringConfigRow

    /** {"uid":398,"Key":"key_passed","Value":"已通关"} */
    key_passed?:stringConfigRow

    /** {"uid":399,"Key":"key_need_select_fruit","Value":"需要选择${count}个果实"} */
    key_need_select_fruit?:stringConfigRow

    /** {"uid":400,"Key":"key_fruit_tip1","Value":"<b><color=#66769c>果实最多可携带${count}个</c></b>"} */
    key_fruit_tip1?:stringConfigRow

    /** {"uid":401,"Key":"key_fruit_tip2","Value":"<b><color=#66769c>果实最多可携带${count}个，</c><color=#3dd439>勾选的果实会进入背包中！</color></b>"} */
    key_fruit_tip2?:stringConfigRow

    /** {"uid":402,"Key":"key_market_title33","Value":"探趣寻宝"} */
    key_market_title33?:stringConfigRow

    /** {"uid":403,"Key":"key_dungeon_finish_mission_ex","Value":"史诗级英雄最高通关${count}层！恭喜你已全部通关"} */
    key_dungeon_finish_mission_ex?:stringConfigRow

    /** {"uid":404,"Key":"key_skill_harm","Value":"技能伤害"} */
    key_skill_harm?:stringConfigRow

    /** {"uid":405,"Key":"key_skill_speed","Value":"迅捷等级"} */
    key_skill_speed?:stringConfigRow

    /** {"uid":406,"Key":"key_genius_unlock_condition","Value":"该英雄地牢通关${level}层解锁"} */
    key_genius_unlock_condition?:stringConfigRow

    /** {"uid":407,"Key":"key_sawling_tip","Value":"消耗${count}个普通天赋果，种下${name}天赋种子。"} */
    key_sawling_tip?:stringConfigRow

    /** {"uid":408,"Key":"key_reset_genius_confirm","Value":"洗点需消耗1颗${name}，\n洗点后，将返还该英雄全部天赋果，\n确认洗点吗？"} */
    key_reset_genius_confirm?:stringConfigRow

    /** {"uid":409,"Key":"key_dungeon_arrive","Value":"地牢探险需达到${count}层"} */
    key_dungeon_arrive?:stringConfigRow

    /** {"uid":410,"Key":"key_genius_skill_unlock_condition","Value":"(解锁条件：${name}Lv.${lv})"} */
    key_genius_skill_unlock_condition?:stringConfigRow

    /** {"uid":411,"Key":"key_duty_tip_1","Value":"持续造成高额伤害"} */
    key_duty_tip_1?:stringConfigRow

    /** {"uid":412,"Key":"key_duty_tip_2","Value":"协助团队主力英雄，提供加成和增益效果"} */
    key_duty_tip_2?:stringConfigRow

    /** {"uid":413,"Key":"key_duty_tip_3","Value":"有极强的生存能力，可以站在队伍的前排帮助队友抵挡伤害"} */
    key_duty_tip_3?:stringConfigRow

    /** {"uid":414,"Key":"key_duty_tip_4","Value":"战斗过程中控制敌方，可以给我方提供巨大的战斗优势。"} */
    key_duty_tip_4?:stringConfigRow

    /** {"uid":415,"Key":"key_next_save_point","Value":"下一个存档点第${level}层"} */
    key_next_save_point?:stringConfigRow

    /** {"uid":416,"Key":"key_dungeon_tip","Value":"派遣一名英雄，前往地牢探险吧！"} */
    key_dungeon_tip?:stringConfigRow

    /** {"uid":417,"Key":"key_dungeon_progress","Value":"${name}的探险进度："} */
    key_dungeon_progress?:stringConfigRow

    /** {"uid":418,"Key":"key_sure_to_next_dungeon","Value":"还有未探索到的奖励，确定放弃吗？"} */
    key_sure_to_next_dungeon?:stringConfigRow

    /** {"uid":419,"Key":"key_select_max_fruit","Value":"果实最多携带${count}个"} */
    key_select_max_fruit?:stringConfigRow

    /** {"uid":420,"Key":"key_no_valid_hero_for_dungeon","Value":"没有满${level}级以上的英雄可派遣"} */
    key_no_valid_hero_for_dungeon?:stringConfigRow

    /** {"uid":421,"Key":"key_weekcard_remain_day","Value":"周卡剩余${day}"} */
    key_weekcard_remain_day?:stringConfigRow

    /** {"uid":422,"Key":"key_monthcard_tip","Value":"月卡时长增加30天"} */
    key_monthcard_tip?:stringConfigRow

    /** {"uid":423,"Key":"key_weekcard_tip","Value":"周卡时长增加7天"} */
    key_weekcard_tip?:stringConfigRow

    /** {"uid":424,"Key":"key_dungeon_guide_reward","Value":"每层地牢都有不少宝藏，走动一下，可千万别错过"} */
    key_dungeon_guide_reward?:stringConfigRow

    /** {"uid":425,"Key":"key_dungeon_guide_fruit","Value":"属性果实可以大幅度提升你的战力，最多可携带3个哦！"} */
    key_dungeon_guide_fruit?:stringConfigRow

    /** {"uid":426,"Key":"key_dungeon_guide_door","Value":"恭喜你勇士！可以继续通关下一层了"} */
    key_dungeon_guide_door?:stringConfigRow

    /** {"uid":427,"Key":"key_no_valid_hero_for_dungeon_ex","Value":"${level}级以下的英雄不可派遣"} */
    key_no_valid_hero_for_dungeon_ex?:stringConfigRow

    /** {"uid":428,"Key":"key_temporary_no","Value":"暂无${name}"} */
    key_temporary_no?:stringConfigRow

    /** {"uid":429,"Key":"key_dungeon_finished","Value":"今日地牢探险已重置，请重新进入"} */
    key_dungeon_finished?:stringConfigRow

    /** {"uid":430,"Key":"key_dungeon_all_passed","Value":"${name}的地牢探险全部通关"} */
    key_dungeon_all_passed?:stringConfigRow

    /** {"uid":431,"Key":"key_dungeon_refresh_hero_confirm","Value":"是否花费${count}钻石，重新更新一批助力英雄？"} */
    key_dungeon_refresh_hero_confirm?:stringConfigRow

    /** {"uid":432,"Key":"key_dungeon_fight_hero_limit","Value":"每日只能派遣${count}位英雄"} */
    key_dungeon_fight_hero_limit?:stringConfigRow

    /** {"uid":433,"Key":"key_pass_mission_to_unlock","Value":"(${cur}/${total})通关${houseId}-${level}解锁${name}"} */
    key_pass_mission_to_unlock?:stringConfigRow

    /** {"uid":434,"Key":"key_at_least_select_battle_hero","Value":"至少选择1位英雄出战"} */
    key_at_least_select_battle_hero?:stringConfigRow

    /** {"uid":435,"Key":"key_dungeon_select_tip","Value":"每日可派遣2名英雄，确定只选择一名英雄前往探险么？"} */
    key_dungeon_select_tip?:stringConfigRow

    /** {"uid":436,"Key":"key_activity_finish_tip","Value":"活动已结束，未领取的奖励稍后通过邮件发送"} */
    key_activity_finish_tip?:stringConfigRow

    /** {"uid":437,"Key":"key_today_charge","Value":"今日已充值￥${amount}"} */
    key_today_charge?:stringConfigRow

    /** {"uid":438,"Key":"key_charge_more","Value":"再充${amount}元，可领取"} */
    key_charge_more?:stringConfigRow

    /** {"uid":439,"Key":"key_activity_end","Value":"活动结束"} */
    key_activity_end?:stringConfigRow

    /** {"uid":440,"Key":"key_click_receive","Value":"点击领取"} */
    key_click_receive?:stringConfigRow

    /** {"uid":441,"Key":"key_total_charge","Value":"累计￥${amount}"} */
    key_total_charge?:stringConfigRow

    /** {"uid":442,"Key":"key_dungeon_hero_passed","Value":"该英雄已全部通关，请选择其他英雄"} */
    key_dungeon_hero_passed?:stringConfigRow

    /** {"uid":443,"Key":"key_artifact_level_limit","Value":"已达强化上限，请提升玩家等级至${level1}"} */
    key_artifact_level_limit?:stringConfigRow

    /** {"uid":444,"Key":"key_artifact_level_max","Value":"已达强化上限${level1}"} */
    key_artifact_level_max?:stringConfigRow

    /** {"uid":445,"Key":"key_no_path_found","Value":"路上有障碍物，无法通过"} */
    key_no_path_found?:stringConfigRow

    /** {"uid":446,"Key":"key_artifact_star_max","Value":"已进阶至最高星级"} */
    key_artifact_star_max?:stringConfigRow

    /** {"uid":447,"Key":"key_artifact_piece_not_enough","Value":"神器碎片不足，请前往【公会寻宝】获得"} */
    key_artifact_piece_not_enough?:stringConfigRow

    /** {"uid":448,"Key":"key_artifact_good_not_enough","Value":"强化石不足，请前往【公会寻宝】获得"} */
    key_artifact_good_not_enough?:stringConfigRow

    /** {"uid":449,"Key":"key_artifact_max_level","Value":"已达到最高等级"} */
    key_artifact_max_level?:stringConfigRow

    /** {"uid":450,"Key":"key_artifact_need_levelup","Value":"玩家等级提升至${level}级可继续强化"} */
    key_artifact_need_levelup?:stringConfigRow

    /** {"uid":451,"Key":"key_artifact_evo_text1","Value":"进 阶"} */
    key_artifact_evo_text1?:stringConfigRow

    /** {"uid":452,"Key":"key_artifact_evo_text2","Value":"已满阶"} */
    key_artifact_evo_text2?:stringConfigRow

    /** {"uid":453,"Key":"key_artifact_level_text1","Value":"已满级"} */
    key_artifact_level_text1?:stringConfigRow

    /** {"uid":454,"Key":"key_upgrade","Value":"升${level}级"} */
    key_upgrade?:stringConfigRow

    /** {"uid":455,"Key":"key_expired","Value":"已过期"} */
    key_expired?:stringConfigRow

    /** {"uid":456,"Key":"key_material_tip1","Value":"今日可购买次数已用完，提升VIP等级可以增加可购买次数上限"} */
    key_material_tip1?:stringConfigRow

    /** {"uid":457,"Key":"key_material_tip2","Value":"提升VIP等级"} */
    key_material_tip2?:stringConfigRow

    /** {"uid":458,"Key":"key_name_max_length","Value":"超过最长名字限制，请重新输入"} */
    key_name_max_length?:stringConfigRow

    /** {"uid":459,"Key":"key_hero_be_locked","Value":"该英雄已被锁定"} */
    key_hero_be_locked?:stringConfigRow

    /** {"uid":460,"Key":"key_not_evo_material","Value":"不是进阶材料"} */
    key_not_evo_material?:stringConfigRow

    /** {"uid":461,"Key":"key_need_evo","Value":"英雄升至稀有品阶可升星"} */
    key_need_evo?:stringConfigRow

    /** {"uid":462,"Key":"key_star_max","Value":"星级已是最高"} */
    key_star_max?:stringConfigRow

    /** {"uid":463,"Key":"key_evo_max","Value":"品阶已是最高"} */
    key_evo_max?:stringConfigRow

    /** {"uid":464,"Key":"key_need_levelup","Value":"英雄等级提升至${level}级可升星"} */
    key_need_levelup?:stringConfigRow

    /** {"uid":465,"Key":"key_not_star_material","Value":"不是升星材料"} */
    key_not_star_material?:stringConfigRow

    /** {"uid":466,"Key":"key_not_merge_material","Value":"不是合成材料"} */
    key_not_merge_material?:stringConfigRow

    /** {"uid":467,"Key":"key_star_not_reach","Value":"星级未达到要求"} */
    key_star_not_reach?:stringConfigRow

    /** {"uid":468,"Key":"key_merge_no_material","Value":"合成材料不足"} */
    key_merge_no_material?:stringConfigRow

    /** {"uid":469,"Key":"key_cannot_star","Value":"不能升星"} */
    key_cannot_star?:stringConfigRow

    /** {"uid":470,"Key":"key_star_level_limit","Value":"升星等级限制"} */
    key_star_level_limit?:stringConfigRow

    /** {"uid":471,"Key":"key_evolution_reach_star","Value":"英雄升至${level}星可继续进阶"} */
    key_evolution_reach_star?:stringConfigRow

    /** {"uid":472,"Key":"key_choose_evo_material","Value":"请选择进阶材料"} */
    key_choose_evo_material?:stringConfigRow

    /** {"uid":473,"Key":"key_choose_star_material","Value":"请选择升星材料"} */
    key_choose_star_material?:stringConfigRow

    /** {"uid":474,"Key":"key_choose_merge_material","Value":"请选择合成材料"} */
    key_choose_merge_material?:stringConfigRow

    /** {"uid":475,"Key":"key_merge_no_hero","Value":"缺少${rankName}的${heroName}"} */
    key_merge_no_hero?:stringConfigRow

    /** {"uid":476,"Key":"key_need_rank_level","Value":"英雄提升至${quality}品阶${level}级可升星"} */
    key_need_rank_level?:stringConfigRow

    /** {"uid":477,"Key":"key_name_not_valid","Value":"请使用汉字、数字或字母哦"} */
    key_name_not_valid?:stringConfigRow

    /** {"uid":478,"Key":"key_evolution_type1","Value":"进阶"} */
    key_evolution_type1?:stringConfigRow

    /** {"uid":479,"Key":"key_evolution_type2","Value":"升星"} */
    key_evolution_type2?:stringConfigRow

    /** {"uid":480,"Key":"key_evolution_type3","Value":"合成"} */
    key_evolution_type3?:stringConfigRow

    /** {"uid":481,"Key":"key_player_level_unlock","Value":"${level}级解锁"} */
    key_player_level_unlock?:stringConfigRow

    /** {"uid":482,"Key":"key_exchange_limit_count","Value":"兑换次数不足"} */
    key_exchange_limit_count?:stringConfigRow

    /** {"uid":483,"Key":"key_exchange_no_hero","Value":"您还未放入兑换的英雄"} */
    key_exchange_no_hero?:stringConfigRow

    /** {"uid":484,"Key":"key_exchange_no_good","Value":"所需材料不足"} */
    key_exchange_no_good?:stringConfigRow

    /** {"uid":485,"Key":"key_exchange_has_quality_hero","Value":"此次兑换中有较为珍贵的英雄，是否确认兑换？"} */
    key_exchange_has_quality_hero?:stringConfigRow

    /** {"uid":486,"Key":"key_exchange_text1","Value":"兑换"} */
    key_exchange_text1?:stringConfigRow

    /** {"uid":487,"Key":"key_exchange_text2","Value":"材料不足"} */
    key_exchange_text2?:stringConfigRow

    /** {"uid":488,"Key":"key_exchange_text3","Value":"无限制"} */
    key_exchange_text3?:stringConfigRow

    /** {"uid":489,"Key":"key_exchange_text4","Value":"可兑换${count}次"} */
    key_exchange_text4?:stringConfigRow

    /** {"uid":490,"Key":"key_exchange_hero_rank_fit","Value":"您没有${rank}品阶的英雄"} */
    key_exchange_hero_rank_fit?:stringConfigRow

    /** {"uid":491,"Key":"key_exchange_has_hero","Value":"该英雄已被放入其他兑换格中"} */
    key_exchange_has_hero?:stringConfigRow

    /** {"uid":492,"Key":"key_exchange_has_choose_hero","Value":"已经选择了英雄"} */
    key_exchange_has_choose_hero?:stringConfigRow

    /** {"uid":493,"Key":"key_arena_challenge_time","Value":"已挑战次数：${time}"} */
    key_arena_challenge_time?:stringConfigRow

    /** {"uid":494,"Key":"key_claimable","Value":"可领取"} */
    key_claimable?:stringConfigRow

    /** {"uid":495,"Key":"key_arena_max_score_target","Value":"历史最高分达到${score}分"} */
    key_arena_max_score_target?:stringConfigRow

    /** {"uid":496,"Key":"key_artifact_lvup_tip","Value":"英雄穿戴神器后可以享受神器带来的属性加成效果"} */
    key_artifact_lvup_tip?:stringConfigRow

    /** {"uid":497,"Key":"key_wave","Value":"第${wave}波"} */
    key_wave?:stringConfigRow

    /** {"uid":498,"Key":"key_exchange_time_out","Value":"兑换次数已用完"} */
    key_exchange_time_out?:stringConfigRow

    /** {"uid":499,"Key":"key_exchange_equip_rank_fit","Value":"您没有${rank}品阶的装备"} */
    key_exchange_equip_rank_fit?:stringConfigRow

    /** {"uid":500,"Key":"key_exchange_has_equip","Value":"该装备已被放入其他兑换格中"} */
    key_exchange_has_equip?:stringConfigRow

    /** {"uid":501,"Key":"key_exchange_has_choose_equip","Value":"已经选择了装备"} */
    key_exchange_has_choose_equip?:stringConfigRow

    /** {"uid":502,"Key":"key_exchange_no_hero_put","Value":"您未放入英雄，是否退出？"} */
    key_exchange_no_hero_put?:stringConfigRow

    /** {"uid":503,"Key":"key_exchange_no_equip_put","Value":"您未放入装备，是否退出？"} */
    key_exchange_no_equip_put?:stringConfigRow

    /** {"uid":504,"Key":"key_exchange_has_quality_equip","Value":"此次兑换中有被强化过的装备，是否确认兑换？"} */
    key_exchange_has_quality_equip?:stringConfigRow

    /** {"uid":505,"Key":"key_exchange_no_equip","Value":"您还未放入兑换的装备"} */
    key_exchange_no_equip?:stringConfigRow

    /** {"uid":506,"Key":"key_exchange_no_hero_fit","Value":"您没有符合的英雄"} */
    key_exchange_no_hero_fit?:stringConfigRow

    /** {"uid":507,"Key":"key_exchange_no_equip_fit","Value":"您没有符合的装备"} */
    key_exchange_no_equip_fit?:stringConfigRow

    /** {"uid":508,"Key":"key_unlock_avatar_tip1","Value":"获得该英雄，可解锁此头像"} */
    key_unlock_avatar_tip1?:stringConfigRow

    /** {"uid":509,"Key":"key_unlock_avatar_tip2","Value":"培养该英雄至史诗品质，可解锁此头像"} */
    key_unlock_avatar_tip2?:stringConfigRow

    /** {"uid":510,"Key":"key_vip_unlock2","Value":"vip等级达到${level}级解锁"} */
    key_vip_unlock2?:stringConfigRow

    /** {"uid":511,"Key":"key_pass_mission_unlock","Value":"通关${buildingId}-${levelId}解锁"} */
    key_pass_mission_unlock?:stringConfigRow

    /** {"uid":512,"Key":"key_wait_power_recovery","Value":"请等待体力恢复"} */
    key_wait_power_recovery?:stringConfigRow

    /** {"uid":513,"Key":"key_searching","Value":"搜寻中..."} */
    key_searching?:stringConfigRow

    /** {"uid":514,"Key":"key_search_result","Value":"搜寻结果"} */
    key_search_result?:stringConfigRow

    /** {"uid":515,"Key":"key_search_time","Value":"搜寻${time}次"} */
    key_search_time?:stringConfigRow

    /** {"uid":516,"Key":"key_no_enough_buy_tili_times","Value":"请等待体力恢复，每${minute}分钟自动恢复1点体力"} */
    key_no_enough_buy_tili_times?:stringConfigRow

    /** {"uid":517,"Key":"key_no_enough_buy_tili_times2","Value":"提升VIP等级可增加购买次数上限"} */
    key_no_enough_buy_tili_times2?:stringConfigRow

    /** {"uid":518,"Key":"key_select_buy_tili_times","Value":"请选择体力购买次数 "} */
    key_select_buy_tili_times?:stringConfigRow

    /** {"uid":519,"Key":"key_breach","Value":"突 破"} */
    key_breach?:stringConfigRow

    /** {"uid":520,"Key":"key_unlock_skill","Value":"解锁技能"} */
    key_unlock_skill?:stringConfigRow

    /** {"uid":521,"Key":"key_buy_tili_success","Value":"体力购买成功"} */
    key_buy_tili_success?:stringConfigRow

    /** {"uid":522,"Key":"key_supply_power_tip","Value":"每10分钟自动恢复一点"} */
    key_supply_power_tip?:stringConfigRow

    /** {"uid":523,"Key":"key_no_enough_senior_search_time","Value":"没有足够的高级搜寻次数"} */
    key_no_enough_senior_search_time?:stringConfigRow

    /** {"uid":524,"Key":"key_times","Value":"${count}次"} */
    key_times?:stringConfigRow

    /** {"uid":525,"Key":"key_no_enough_supply_reset_times","Value":"高级搜寻重置次数已用完"} */
    key_no_enough_supply_reset_times?:stringConfigRow

    /** {"uid":526,"Key":"key_no_enough_supply_reset_times2","Value":"提升VIP等级可增加高级搜寻的重置次数"} */
    key_no_enough_supply_reset_times2?:stringConfigRow

    /** {"uid":527,"Key":"key_supply_search_count","Value":"搜寻${time}次"} */
    key_supply_search_count?:stringConfigRow

    /** {"uid":528,"Key":"key_buy_tili_tip","Value":"<b><color=#37504B>VIP提升至</c><color=#7C3E14>${vip}级</c><color=#37504B>可以增加</c><color=#7C3E14>${count}次</c><color=#37504B>体力购买次数</c></b>"} */
    key_buy_tili_tip?:stringConfigRow

    /** {"uid":529,"Key":"key_fetter_own_heroes","Value":"拥有${hero1}，${hero2}"} */
    key_fetter_own_heroes?:stringConfigRow

    /** {"uid":530,"Key":"key_no_need_rollback_hero","Value":"英雄无需回退"} */
    key_no_need_rollback_hero?:stringConfigRow

    /** {"uid":531,"Key":"key_equip_level_limited","Value":"装备强化等级已达上限"} */
    key_equip_level_limited?:stringConfigRow

    /** {"uid":532,"Key":"key_sure_to_inherit_equip","Value":"是否选择将替换前装备的养成转换到替换后的装备上"} */
    key_sure_to_inherit_equip?:stringConfigRow

    /** {"uid":533,"Key":"key_equip_rank_limited","Value":"装备品质已达上限"} */
    key_equip_rank_limited?:stringConfigRow

    /** {"uid":534,"Key":"key_equip_merge_no_enough_material","Value":"装备合成材料不足"} */
    key_equip_merge_no_enough_material?:stringConfigRow

    /** {"uid":535,"Key":"key_equip_merge_tower_limited","Value":"装备合成需要摩天楼达到${tower}层"} */
    key_equip_merge_tower_limited?:stringConfigRow

    /** {"uid":536,"Key":"key_sure_to_merge_equip","Value":"合成装备后，消耗的装备中的资源将返还"} */
    key_sure_to_merge_equip?:stringConfigRow

    /** {"uid":537,"Key":"key_equip_charging_lv_limited","Value":"装备充能等级已达上限"} */
    key_equip_charging_lv_limited?:stringConfigRow

    /** {"uid":538,"Key":"key_sure_to_reset_before_split_equip","Value":"可消耗${count}钻石先重生再分解"} */
    key_sure_to_reset_before_split_equip?:stringConfigRow

    /** {"uid":539,"Key":"key_equip_no_reset","Value":"装备已是初始状态，无需重生"} */
    key_equip_no_reset?:stringConfigRow

    /** {"uid":540,"Key":"key_sure_to_reset_equip","Value":"确认消耗${count}钻石进行装备重生？"} */
    key_sure_to_reset_equip?:stringConfigRow

    /** {"uid":541,"Key":"key_sure_to_split_equip","Value":"确认进行装备分解？"} */
    key_sure_to_split_equip?:stringConfigRow

    /** {"uid":542,"Key":"key_equip_no_camp","Value":"该装备没有专属联盟"} */
    key_equip_no_camp?:stringConfigRow

    /** {"uid":543,"Key":"key_equip_recast_tip","Value":"<b><color=#455F5A>${faction}联盟英雄穿戴后，装备属性提升</c><color=#007E09>${value}</color><color=#455F5A>，是否保留该属性？</c></b>"} */
    key_equip_recast_tip?:stringConfigRow

    /** {"uid":544,"Key":"key_pieces","Value":"${count}件"} */
    key_pieces?:stringConfigRow

    /** {"uid":545,"Key":"key_no_inherit_equip_in_flowerpot","Value":"花坛祭司中没有可继承的同类型装备"} */
    key_no_inherit_equip_in_flowerpot?:stringConfigRow

    /** {"uid":546,"Key":"key_evolution_type4","Value":"升星"} */
    key_evolution_type4?:stringConfigRow

    /** {"uid":547,"Key":"key_auto_550","Value":"超级月卡已过期"} */
    key_auto_550?:stringConfigRow

    /** {"uid":548,"Key":"key_auto_551","Value":"毒箭木开启成功"} */
    key_auto_551?:stringConfigRow

    /** {"uid":549,"Key":"key_auto_552","Value":"商品不存在"} */
    key_auto_552?:stringConfigRow

    /** {"uid":550,"Key":"key_auto_553","Value":"钻石不足"} */
    key_auto_553?:stringConfigRow

    /** {"uid":551,"Key":"key_auto_554","Value":"购买成功"} */
    key_auto_554?:stringConfigRow

    /** {"uid":552,"Key":"key_auto_555","Value":"删除已读邮件成功"} */
    key_auto_555?:stringConfigRow

    /** {"uid":553,"Key":"key_auto_556","Value":"没有可领取的邮件"} */
    key_auto_556?:stringConfigRow

    /** {"uid":554,"Key":"key_auto_557","Value":"刷新成功"} */
    key_auto_557?:stringConfigRow

    /** {"uid":555,"Key":"key_auto_558","Value":"战斗版本错误"} */
    key_auto_558?:stringConfigRow

    /** {"uid":556,"Key":"key_auto_559","Value":"该礼包已结束,无法购买"} */
    key_auto_559?:stringConfigRow

    /** {"uid":557,"Key":"key_auto_560","Value":"您已不在群组"} */
    key_auto_560?:stringConfigRow

    /** {"uid":558,"Key":"key_auto_561","Value":"不能发送空白聊天！"} */
    key_auto_561?:stringConfigRow

    /** {"uid":559,"Key":"key_auto_562","Value":"挑战令不足"} */
    key_auto_562?:stringConfigRow

    /** {"uid":560,"Key":"key_auto_563","Value":"今日挑战令购买次数已达上限"} */
    key_auto_563?:stringConfigRow

    /** {"uid":561,"Key":"key_auto_564","Value":"没有足够的奇异花"} */
    key_auto_564?:stringConfigRow

    /** {"uid":562,"Key":"key_auto_565","Value":"请先设置终极奖励吧"} */
    key_auto_565?:stringConfigRow

    /** {"uid":563,"Key":"key_auto_566","Value":"终极奖励已领取,请前往下一层再设置"} */
    key_auto_566?:stringConfigRow

    /** {"uid":564,"Key":"key_auto_567","Value":"暂无昔日榜单"} */
    key_auto_567?:stringConfigRow

    /** {"uid":565,"Key":"key_auto_568","Value":"请明天再来"} */
    key_auto_568?:stringConfigRow

    /** {"uid":566,"Key":"key_auto_569","Value":"没有符合条件的英雄可派遣!"} */
    key_auto_569?:stringConfigRow

    /** {"uid":567,"Key":"key_auto_570","Value":"当前没有符合条件的英雄可派遣"} */
    key_auto_570?:stringConfigRow

    /** {"uid":568,"Key":"key_auto_571","Value":"克隆挑战券不足"} */
    key_auto_571?:stringConfigRow

    /** {"uid":569,"Key":"key_auto_572","Value":"请选择需要合成的英雄"} */
    key_auto_572?:stringConfigRow

    /** {"uid":570,"Key":"key_auto_573","Value":"该功能即将开放！"} */
    key_auto_573?:stringConfigRow

    /** {"uid":571,"Key":"key_auto_574","Value":"即将开放"} */
    key_auto_574?:stringConfigRow

    /** {"uid":572,"Key":"key_auto_575","Value":"心愿骰子数量不足!"} */
    key_auto_575?:stringConfigRow

    /** {"uid":573,"Key":"key_auto_576","Value":"普通骰子数量不足!"} */
    key_auto_576?:stringConfigRow

    /** {"uid":574,"Key":"key_auto_577","Value":"当前没有记录"} */
    key_auto_577?:stringConfigRow

    /** {"uid":575,"Key":"key_auto_578","Value":"今日次数已用完"} */
    key_auto_578?:stringConfigRow

    /** {"uid":576,"Key":"key_auto_579","Value":"公会已满员"} */
    key_auto_579?:stringConfigRow

    /** {"uid":577,"Key":"key_auto_580","Value":"暂未开放,敬请期待"} */
    key_auto_580?:stringConfigRow

    /** {"uid":578,"Key":"key_auto_581","Value":"公会争霸活动已结束"} */
    key_auto_581?:stringConfigRow

    /** {"uid":579,"Key":"key_auto_582","Value":"今日红包已领取,请明天再来"} */
    key_auto_582?:stringConfigRow

    /** {"uid":580,"Key":"key_auto_583","Value":"完成成就可领取奖励"} */
    key_auto_583?:stringConfigRow

    /** {"uid":581,"Key":"key_auto_584","Value":"今日次数已用尽,请明日再来"} */
    key_auto_584?:stringConfigRow

    /** {"uid":582,"Key":"key_auto_585","Value":"材料不足!"} */
    key_auto_585?:stringConfigRow

    /** {"uid":583,"Key":"key_auto_586","Value":"今日强化已达上限,请明日再来"} */
    key_auto_586?:stringConfigRow

    /** {"uid":584,"Key":"key_auto_587","Value":"公会列表已刷新"} */
    key_auto_587?:stringConfigRow

    /** {"uid":585,"Key":"key_auto_588","Value":"未找到您搜索的公会"} */
    key_auto_588?:stringConfigRow

    /** {"uid":586,"Key":"key_auto_589","Value":"今日免费刷新次数已用完"} */
    key_auto_589?:stringConfigRow

    /** {"uid":587,"Key":"key_auto_590","Value":"请设置上阵英雄"} */
    key_auto_590?:stringConfigRow

    /** {"uid":588,"Key":"key_auto_591","Value":"设置成功"} */
    key_auto_591?:stringConfigRow

    /** {"uid":589,"Key":"key_auto_592","Value":"找不到对手请稍后再试"} */
    key_auto_592?:stringConfigRow

    /** {"uid":590,"Key":"key_auto_593","Value":"角斗士硬币达到上限,无法领取"} */
    key_auto_593?:stringConfigRow

    /** {"uid":591,"Key":"key_auto_594","Value":"您已经强到找不到对手了"} */
    key_auto_594?:stringConfigRow

    /** {"uid":592,"Key":"key_auto_595","Value":"请上阵英雄"} */
    key_auto_595?:stringConfigRow

    /** {"uid":593,"Key":"key_auto_596","Value":"智慧树已刷新"} */
    key_auto_596?:stringConfigRow

    /** {"uid":594,"Key":"key_auto_597","Value":"当前还未获得果实"} */
    key_auto_597?:stringConfigRow

    /** {"uid":595,"Key":"key_auto_598","Value":"重生药剂数量不足"} */
    key_auto_598?:stringConfigRow

    /** {"uid":596,"Key":"key_auto_599","Value":"没有需要复活的英雄！"} */
    key_auto_599?:stringConfigRow

    /** {"uid":597,"Key":"key_auto_600","Value":"所有英雄已全部恢复满状态！"} */
    key_auto_600?:stringConfigRow

    /** {"uid":598,"Key":"key_auto_601","Value":"请选择一个英雄"} */
    key_auto_601?:stringConfigRow

    /** {"uid":599,"Key":"key_auto_602","Value":"碎片不足"} */
    key_auto_602?:stringConfigRow

    /** {"uid":600,"Key":"key_auto_603","Value":"已领取所有奖励"} */
    key_auto_603?:stringConfigRow

    /** {"uid":601,"Key":"key_auto_604","Value":"暂无可领取奖励"} */
    key_auto_604?:stringConfigRow

    /** {"uid":602,"Key":"key_auto_605","Value":"请选择想要兑换的物品"} */
    key_auto_605?:stringConfigRow

    /** {"uid":603,"Key":"key_auto_606","Value":"无法抵达"} */
    key_auto_606?:stringConfigRow

    /** {"uid":604,"Key":"key_auto_607","Value":"已收集完所有宝箱"} */
    key_auto_607?:stringConfigRow

    /** {"uid":605,"Key":"key_auto_608","Value":"已收集完所有水晶宝箱"} */
    key_auto_608?:stringConfigRow

    /** {"uid":606,"Key":"key_auto_609","Value":"当前资源点正在被攻击"} */
    key_auto_609?:stringConfigRow

    /** {"uid":607,"Key":"key_auto_610","Value":"英雄已阵亡，复活后才能上阵！"} */
    key_auto_610?:stringConfigRow

    /** {"uid":608,"Key":"key_auto_611","Value":"该英雄已在其他组上阵"} */
    key_auto_611?:stringConfigRow

    /** {"uid":609,"Key":"key_auto_612","Value":"该玩家今日接收礼物次数已用尽"} */
    key_auto_612?:stringConfigRow

    /** {"uid":610,"Key":"key_auto_613","Value":"活动已结束！"} */
    key_auto_613?:stringConfigRow

    /** {"uid":611,"Key":"key_auto_614","Value":"兑换次数已达上限"} */
    key_auto_614?:stringConfigRow

    /** {"uid":612,"Key":"key_auto_615","Value":"宝藏碎片不足"} */
    key_auto_615?:stringConfigRow

    /** {"uid":613,"Key":"key_auto_616","Value":"尚未获得神器"} */
    key_auto_616?:stringConfigRow

    /** {"uid":614,"Key":"key_auto_617","Value":"该英雄每天只能挑战一次"} */
    key_auto_617?:stringConfigRow

    /** {"uid":615,"Key":"key_auto_618","Value":"拥有该英雄后即可挑战"} */
    key_auto_618?:stringConfigRow

    /** {"uid":616,"Key":"key_auto_619","Value":"当前没有可重炼的锻造属性"} */
    key_auto_619?:stringConfigRow

    /** {"uid":617,"Key":"key_auto_620","Value":"请先开启新手基金"} */
    key_auto_620?:stringConfigRow

    /** {"uid":618,"Key":"key_auto_621","Value":"未到领取时间"} */
    key_auto_621?:stringConfigRow

    /** {"uid":619,"Key":"key_auto_622","Value":"已购买新手基金,不用重复购买"} */
    key_auto_622?:stringConfigRow

    /** {"uid":620,"Key":"key_auto_623","Value":"勇士之证不足"} */
    key_auto_623?:stringConfigRow

    /** {"uid":621,"Key":"key_auto_624","Value":"高阶勇士之证不足"} */
    key_auto_624?:stringConfigRow

    /** {"uid":622,"Key":"key_auto_625","Value":"未达成解锁条件，不可领取"} */
    key_auto_625?:stringConfigRow

    /** {"uid":623,"Key":"key_auto_626","Value":"已达上限"} */
    key_auto_626?:stringConfigRow

    /** {"uid":624,"Key":"key_auto_627","Value":"活力药剂使用成功！"} */
    key_auto_627?:stringConfigRow

    /** {"uid":625,"Key":"key_auto_628","Value":"已切断敌方粮草"} */
    key_auto_628?:stringConfigRow

    /** {"uid":626,"Key":"key_auto_629","Value":"暂未开放"} */
    key_auto_629?:stringConfigRow

    /** {"uid":627,"Key":"key_auto_630","Value":"随机复活1名英雄成功！"} */
    key_auto_630?:stringConfigRow

    /** {"uid":628,"Key":"key_auto_631","Value":"您已被禁言"} */
    key_auto_631?:stringConfigRow

    /** {"uid":629,"Key":"key_auto_632","Value":"该英雄正在共享花坛中，不能进阶"} */
    key_auto_632?:stringConfigRow

    /** {"uid":630,"Key":"key_power_tip","Value":"总战力是最高5个不相同英雄的战力之和"} */
    key_power_tip?:stringConfigRow

    /** {"uid":634,"Key":"key_auto_634","Value":"发言过快，${p1}秒后可发言"} */
    key_auto_634?:stringConfigRow

    /** {"uid":635,"Key":"key_auto_635","Value":"限时开放,周${p1}开启"} */
    key_auto_635?:stringConfigRow

    /** {"uid":636,"Key":"key_auto_636","Value":"还需要${p1}点能量，便可领取十连抽！"} */
    key_auto_636?:stringConfigRow

    /** {"uid":637,"Key":"key_auto_637","Value":"该奖励已用尽,请选择其他奖励"} */
    key_auto_637?:stringConfigRow

    /** {"uid":638,"Key":"key_auto_638","Value":"通关摩天楼${p1}层解锁合成该装备"} */
    key_auto_638?:stringConfigRow

    /** {"uid":639,"Key":"key_auto_639","Value":"VIP${p1}解锁一键派遣功能"} */
    key_auto_639?:stringConfigRow

    /** {"uid":640,"Key":"key_auto_640","Value":"VIP${p1}解锁一键领取功能"} */
    key_auto_640?:stringConfigRow

    /** {"uid":641,"Key":"key_auto_641","Value":"${p1}"} */
    key_auto_641?:stringConfigRow

    /** {"uid":642,"Key":"key_auto_642","Value":"使用${p1}联盟的英雄上阵可以造成20%额外伤害与20%伤害减免"} */
    key_auto_642?:stringConfigRow

    /** {"uid":643,"Key":"key_auto_643","Value":"公会等级${p1}解锁公会副本"} */
    key_auto_643?:stringConfigRow

    /** {"uid":644,"Key":"key_auto_644","Value":"${p1}后开启活动报名"} */
    key_auto_644?:stringConfigRow

    /** {"uid":645,"Key":"key_auto_645","Value":"队伍${p1}上阵英雄数量不足"} */
    key_auto_645?:stringConfigRow

    /** {"uid":646,"Key":"key_auto_646","Value":"占领的资源点不能超过${p1}个"} */
    key_auto_646?:stringConfigRow

    /** {"uid":647,"Key":"key_auto_647","Value":"今日奖励已领取,请明日再来"} */
    key_auto_647?:stringConfigRow

    /** {"uid":648,"Key":"key_auto_648","Value":"通关${p1}-${p2}即可领取"} */
    key_auto_648?:stringConfigRow

    /** {"uid":649,"Key":"key_auto_649","Value":"请先激活成长礼包!"} */
    key_auto_649?:stringConfigRow

    /** {"uid":650,"Key":"key_auto_650","Value":"需要${p1}个 ${p2} ${p3}"} */
    key_auto_650?:stringConfigRow

    /** {"uid":651,"Key":"key_auto_651","Value":"需要${p1}名${p2}${p3}英雄"} */
    key_auto_651?:stringConfigRow

    /** {"uid":652,"Key":"key_auto_652","Value":"需要${p1}名任意阵容${p2}英雄"} */
    key_auto_652?:stringConfigRow

    /** {"uid":653,"Key":"key_auto_653","Value":"需要1个 ${p1} ${p2}"} */
    key_auto_653?:stringConfigRow

    /** {"uid":654,"Key":"key_auto_654","Value":"需要1名${p1}${p2}英雄"} */
    key_auto_654?:stringConfigRow

    /** {"uid":655,"Key":"key_auto_655","Value":"需要1名任意阵容${p1}英雄"} */
    key_auto_655?:stringConfigRow

    /** {"uid":656,"Key":"key_auto_656","Value":"遭遇陷阱，${p1}型英雄损失了${p2}%血量"} */
    key_auto_656?:stringConfigRow

    /** {"uid":657,"Key":"key_auto_657","Value":"${p1}陷阱已解除"} */
    key_auto_657?:stringConfigRow

    /** {"uid":658,"Key":"key_applyjoin","Value":"申请加入"} */
    key_applyjoin?:stringConfigRow

    /** {"uid":659,"Key":"key_quickjoin","Value":"加入"} */
    key_quickjoin?:stringConfigRow

    /** {"uid":660,"Key":"key_union_active_tip","Value":"公会活跃值:公会成员每获得一点个人活跃值,就贡献1点公会活跃值"} */
    key_union_active_tip?:stringConfigRow

}={}

for(let r of tableData){
    stringConfig .push(r);

    stringConfigMap [r. Key ] =r;

}

export default stringConfig
