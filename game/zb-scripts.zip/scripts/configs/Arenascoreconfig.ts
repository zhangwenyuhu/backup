const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","seasonscore","scorereset","winreward",]

export class ArenascoreconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 赛季积分
         **/
        @SafeProperty
        seasonscore?:number[]

        /**
         * 积分重置
         **/
        @SafeProperty
        scorereset?:number

        /**
         * 胜利奖励（随机一种）
         **/
        @SafeProperty
        winreward?:any

}

let Arenascoreconfig:ArenascoreconfigRow []=[];

var rowData=
[
    [1,[0,1000],1000,[[10001,90000],[10004,10]]],
    [2,[1001,1300],1000,[[10001,90000],[10004,10]]],
    [3,[1301,1600],1300,[[10001,90000],[10004,10]]],
    [4,[1601,1900],1600,[[10001,90000],[10004,10]]],
    [5,[1901,2200],1900,[[10001,90000],[10004,20]]],
    [6,[2201,2500],2200,[[10001,90000],[10004,20]]],
    [7,[2501,2800],2500,[[10001,90000],[10004,20]]],
    [8,[2801,3100],2800,[[10001,90000],[10004,20]]],
    [9,[3101,3400],3100,[[10001,90000],[10004,20]]],
    [10,[3401,3700],3400,[[10001,90000],[10004,40]]],
    [11,[3701,4000],3700,[[10001,90000],[10004,40]]],
    [12,[4001,50000],4000,[[10001,90000],[10004,40]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new ArenascoreconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    Arenascoreconfig .push(r);

}

export default Arenascoreconfig
