const { SafeClass, decryptTable ,SafeProperty} = slib;



type uid=number;
type key=string;
type fk=number;
 
var fields =["id","name","statusTree","aiTree","resID","normalAttackCfg","skills","speed","hp",]

export class heroFightConfigRow{
	
    
        /**
         * 键
         **/
        
        id?:uid=null

        
        
    
        /**
         * 英雄名
         **/
        @SafeProperty
        name?:string=null

        
        
    
        /**
         * 状态树配置
         **/
        @SafeProperty
        statusTree?:string=null

        
        
    
        /**
         * ai树配置
         **/
        @SafeProperty
        aiTree?:string=null

        
        
    
        /**
         * 资源ID
         **/
        @SafeProperty
        resID?:string=null

        
        
    
        /**
         * 普攻
         **/
        @SafeProperty
        normalAttackCfg?:number=null

        
        
    
        /**
         * 技能配置
         **/
        @SafeProperty
        skills?:number[]=null

        
        
    
        /**
         * 移动速度
         **/
        @SafeProperty
        speed?:number=null

        
        
    
        /**
         * 基础血量
         **/
        @SafeProperty
        hp?:number=null

        
        
    
}

let heroFightConfig:heroFightConfigRow []=[]


/**
[
    [2,"铁树","","","tieshu",1000,[],100,1000],
    [3,"沙僧","","","shaseng",1004,[],101,1001],
    
]
**/




export function heroFightConfigInit (

    
	key:string='AMhGbf0cnlMCWWviPheroFightConfigGOK+GK*--s8V2wUd',
	data:string='XOy+OQK8zfh0VmNibIEQISToKLTx8JsXw4KOvkVMVHGGDFCAZicdib6LBajelGB+BScmAD2CYCKyfYG892C/t+NXouFyGzSnm/7A83xm12U='
    
){
    let newTable=decryptTable(
        ()=>{
            return new heroFightConfigRow ()
        },
        fields,
        'fmrarm'+key,
        data,true
    ) as heroFightConfigRow []
    for(let r of newTable){
        heroFightConfig .push(r);
        
    }
}

export default heroFightConfig
