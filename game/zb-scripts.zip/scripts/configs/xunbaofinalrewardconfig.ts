const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","finalreward","unlockfloor","unlockstage","getlimit","weight",]

export class xunbaofinalrewardconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 终极大奖
         **/
        @SafeProperty
        finalreward?:any

        /**
         * 解锁层数
         **/
        @SafeProperty
        unlockfloor?:number

        /**
         * 解锁关卡
         **/
        @SafeProperty
        unlockstage?:number

        /**
         * 领取上限
         **/
        @SafeProperty
        getlimit?:number

        /**
         * 权重
         **/
        @SafeProperty
        weight?:number

}

let xunbaofinalrewardconfig:xunbaofinalrewardconfigRow []=[];

var rowData=
[
    [1,[10458,60],1,1,3,20],
    [2,[10439,60],2,1,3,20],
    [3,[10111,60],2,1,3,20],
    [4,[10075,1],5,1,3,20],
    [5,[10120,60],5,1,3,20],
    [6,[10456,60],5,1,3,20],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new xunbaofinalrewardconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    xunbaofinalrewardconfig .push(r);

}

export default xunbaofinalrewardconfig
