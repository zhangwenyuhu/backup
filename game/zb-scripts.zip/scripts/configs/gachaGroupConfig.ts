const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","Weight3_4","Weight2_4","Weight2_2","Weight1_1","Weight4_4","ShowProbability",]

export class gachaGroupConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * SSR/紫色权重
         **/
        @SafeProperty
        Weight3_4?:number

        /**
         * SR/紫色权重
         **/
        @SafeProperty
        Weight2_4?:number

        /**
         * SR/蓝色权重
         **/
        @SafeProperty
        Weight2_2?:number

        /**
         * R/绿色权重
         **/
        @SafeProperty
        Weight1_1?:number

        /**
         * UR/绿色权重
         **/
        @SafeProperty
        Weight4_4?:number

        /**
         * 显示概率
         **/
        @SafeProperty
        ShowProbability?:number[]

}

let gachaGroupConfig:gachaGroupConfigRow []=[];

var rowData=
[
    [1,3,17,380,600,0,[0.003,0.397,0.6]],
    [2,50,0,400,550,0,[0.05,0.4,0.55]],
    [3,30,15,415,550,0,[0.0297,0.4257,0.5446]],
    [4,90,45,865,0,0,[0.09,0.91,0]],
    [5,90,45,865,0,0,[0.09,0.91,0]],
    [6,90,45,865,0,0,[0.09,0.91,0]],
    [7,90,45,865,0,0,[0.09,0.91,0]],
    [8,5,10,415,550,0,[0.0153,0.4237,0.561]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new gachaGroupConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    gachaGroupConfig .push(r);

}

export default gachaGroupConfig
