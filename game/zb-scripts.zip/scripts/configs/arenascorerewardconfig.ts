const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","score","reward",]

export class arenascorerewardconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 分数要求
         **/
        @SafeProperty
        score?:number

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:any

}

let arenascorerewardconfig:arenascorerewardconfigRow []=[];

var rowData=
[
    [1,1010,[[10002,20],[10062,2]]],
    [2,1030,[[10002,30],[10062,2]]],
    [3,1050,[[10002,30],[10062,3]]],
    [4,1100,[[10002,50],[10062,5]]],
    [5,1200,[[10002,50],[10062,5]]],
    [6,1300,[[10002,100],[10062,5]]],
    [7,1400,[[10002,100],[10062,10]]],
    [8,1600,[[10002,100],[10062,10]]],
    [9,1800,[[10002,200]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new arenascorerewardconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    arenascorerewardconfig .push(r);

}

export default arenascorerewardconfig
