const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","SpacetimeID","Eventtype","Fruit1","Fruit2","Fruit3",]

export class spacetimefruitconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 时空ID
         **/
        @SafeProperty
        SpacetimeID?:number

        /**
         * 怪物类型
         **/
        @SafeProperty
        Eventtype?:number

        /**
         * 蓝果实权重
         **/
        @SafeProperty
        Fruit1?:number

        /**
         * 紫果实权重
         **/
        @SafeProperty
        Fruit2?:number

        /**
         * 金果实权重
         **/
        @SafeProperty
        Fruit3?:number

}

let spacetimefruitconfig:spacetimefruitconfigRow []=[];

var rowData=
[
    [1001,1,1001,100,0,0],
    [1002,1,1002,20,70,10],
    [1003,1,1003,0,0,100],
    [2001,2,1001,100,0,0],
    [2002,2,1002,20,70,10],
    [2003,2,1003,0,0,100],
    [3001,3,1001,100,0,0],
    [3002,3,1002,20,70,10],
    [3003,3,1003,0,0,100],
    [4001,4,1001,90,10,0],
    [4002,4,1002,20,75,5],
    [4003,4,1003,0,0,100],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new spacetimefruitconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    spacetimefruitconfig .push(r);

}

export default spacetimefruitconfig
