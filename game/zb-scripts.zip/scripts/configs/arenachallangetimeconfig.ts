const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","arenatype","resettype","time","wintime","reward","describe",]

export class arenachallangetimeconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 竞技场类型
作者:
1普通
2高阶
         **/
        @SafeProperty
        arenatype?:number

        /**
         * 重置类型（1天/2赛季）
         **/
        @SafeProperty
        resettype?:number

        /**
         * 挑战次数
         **/
        @SafeProperty
        time?:number

        /**
         * 胜利次数
         **/
        @SafeProperty
        wintime?:number

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:any

        /**
         * 文本描述
         **/
        @SafeProperty
        describe?:string

}

let arenachallangetimeconfig:arenachallangetimeconfigRow []=[];

var rowData=
[
    [1,1,2,5,0,[[10006,1]]],
    [2,1,2,10,0,[[10006,1]]],
    [3,1,2,20,0,[[10006,2]]],
    [4,1,2,30,0,[[10006,3]]],
    [5,1,2,40,0,[[10007,2]]],
    [6,1,2,50,0,[[10007,3]]],
    [7,2,1,3,0,[[10477,3]],"高阶竞技场挑战%S次"],
    [8,2,1,5,0,[[10477,5]],"高阶竞技场挑战%S次"],
    [9,2,1,10,0,[[10477,8]],"高阶竞技场挑战%S次"],
    [10,2,1,0,2,[[10493,5]],"高阶竞技场胜利%S次"],
    [11,2,1,0,5,[[10493,10]],"高阶竞技场胜利%S次"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new arenachallangetimeconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    arenachallangetimeconfig .push(r);

}

export default arenachallangetimeconfig
