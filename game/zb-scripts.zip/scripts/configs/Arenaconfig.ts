const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","rankrange","scorerange","matetype","playernumber","winscoreget","winscorereduce","losescorereduce","losescoreget",]

export class ArenaconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 排名范围（当前排名减该值）
         **/
        @SafeProperty
        rankrange?:number[]

        /**
         * 积分百分比范围
         **/
        @SafeProperty
        scorerange?:number[]

        /**
         * 匹配类型
         **/
        @SafeProperty
        matetype?:number

        /**
         * 人数
         **/
        @SafeProperty
        playernumber?:number

        /**
         * 胜利积分增加
         **/
        @SafeProperty
        winscoreget?:number[]

        /**
         * 胜利对方积分减少
         **/
        @SafeProperty
        winscorereduce?:number[]

        /**
         * 失败积分减少
         **/
        @SafeProperty
        losescorereduce?:number[]

        /**
         * 失败对方积分增加
         **/
        @SafeProperty
        losescoreget?:number[]

}

let Arenaconfig:ArenaconfigRow []=[];

var rowData=
[
    [1,[200,101],[],1,1,[18,23],[18,23],[1,2],[0,2]],
    [2,[100,31],[],1,1,[14,18],[14,18],[2,3],[2,3]],
    [3,[30,11],[],1,1,[10,14],[10,14],[3,4],[3,4]],
    [4,[10,1],[],1,1,[7,10],[7,10],[6,10],[6,10]],
    [5,[-1,-10],[],1,1,[2,3],[2,3],[10,12],[10,12]],
    [6,[],[1.35,1.5],2,1,[18,23],[18,23],[1,2],[0,2]],
    [7,[],[1.2,1.35],2,1,[14,18],[14,18],[2,3],[2,3]],
    [8,[],[1,1.2],2,1,[10,14],[10,14],[3,4],[3,4]],
    [9,[],[1,1.2],2,1,[10,14],[10,14],[3,4],[3,4]],
    [10,[],[0.9,1],2,1,[5,7],[5,7],[10,12],[10,12]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new ArenaconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    Arenaconfig .push(r);

}

export default Arenaconfig
