const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","quality","name","spine","CritRate","HarmAbsorbLv","Hpper","Atkper","Defper","M_DeHarmRate","P_DeHarmRate","Special","Chat","Price","ResolveNum","skip","skipStr","SkinHead",]

export class skinconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 品质
         **/
        @SafeProperty
        quality?:number

        /**
         * 名称
         **/
        @SafeProperty
        name?:string

        /**
         * spine
         **/
        @SafeProperty
        spine?:string

        /**
         * 暴击增加
         **/
        @SafeProperty
        CritRate?:number

        /**
         * 吸血等级
         **/
        @SafeProperty
        HarmAbsorbLv?:number

        /**
         * 生命增加百分比
         **/
        @SafeProperty
        Hpper?:number

        /**
         * 攻击增加百分比
         **/
        @SafeProperty
        Atkper?:number

        /**
         * 防御增加百分比
         **/
        @SafeProperty
        Defper?:number

        /**
         * 魔法减伤率
         **/
        @SafeProperty
        M_DeHarmRate?:number

        /**
         * 物理减伤率
         **/
        @SafeProperty
        P_DeHarmRate?:number

        /**
         * 特殊效果
         **/
        @SafeProperty
        Special?:number

        /**
         * 特殊对话
         **/
        @SafeProperty
        Chat?:string

        /**
         * 碎片售价
当为空时，表示为付费皮肤，价值填在store表中
         **/
        @SafeProperty
        Price?:number

        /**
         * 分解数量
         **/
        @SafeProperty
        ResolveNum?:number

        /**
         * 获取途径
         **/
        @SafeProperty
        skip?:number

        /**
         * 无获取途径描述
获取途径无法跳转时，读取此文本描述
         **/
        @SafeProperty
        skipStr?:string

        /**
         * 解锁头像
         **/
        @SafeProperty
        SkinHead?:number

}

let skinconfig:skinconfigRow []=[];

var rowData=
[
    [50001,1,"鸣人","mingren",0.02,0,0.05,0.05,0.05,0.05,0.05,998001,"强大的分身",40,10,3,"限时活动中获得",20057],
    [50002,1,"莫莉卡","anyenvwang",0,0,0.05,0.05,0,0,0,0,"",0,10,41,"限时活动中获得",20048],
    [50003,1,"鸣人","dabai",0.02,0,0.05,0.05,0.05,0.05,0.05,998001,"强大的分身",40,10,0,"限时活动中获得",20015],
    [50004,1,"鸣人","jiqimao",0.02,0,0.05,0.05,0.05,0.05,0.05,998001,"强大的分身",40,10,41,"限时活动中获得",20016],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new skinconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    skinconfig .push(r);

}

export default skinconfig
