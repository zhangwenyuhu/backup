const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","Condition","Rank","pro",]

export class xsLvConfigRow{

        /**
         * 等级
         **/
        @SafeProperty
        Id?:uid

        /**
         * 升级需求
         **/
        @SafeProperty
        Condition?:number[]

        /**
         * 任务等级
         **/
        @SafeProperty
        Rank?:number[]

        /**
         * 对应概率
         **/
        @SafeProperty
        pro?:number[]

}

let xsLvConfig:xsLvConfigRow []=[];

var rowData=
[
    [1,[1,15],[1,2],[70,30]],
    [2,[2,20],[1,2,3],[50,40,10]],
    [3,[3,30],[1,2,3,4],[45,30,20,5]],
    [4,[4,30],[2,3,4,5],[55,30,10,5]],
    [5,[5,40],[2,3,4,5],[40,40,15,5]],
    [6,[],[3,4,5],[72,20,8]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new xsLvConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    xsLvConfig .push(r);

}

export default xsLvConfig
