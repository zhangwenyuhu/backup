const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","schedule","equiplevel",]

export class mazeshoplevelconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 副本进度
         **/
        @SafeProperty
        schedule?:number

        /**
         * 装备等级
         **/
        @SafeProperty
        equiplevel?:number

}

let mazeshoplevelconfig:mazeshoplevelconfigRow []=[];

var rowData=
[
    [1,1,1],
    [2,13,2],
    [3,41,3],
    [4,77,4],
    [5,113,5],
    [6,153,6],
    [7,233,7],
    [8,353,8],
    [9,563,9],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new mazeshoplevelconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    mazeshoplevelconfig .push(r);

}

export default mazeshoplevelconfig
