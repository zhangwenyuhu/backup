const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","stage","reward",]

export class medalstagerewardconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 主线关卡
         **/
        @SafeProperty
        stage?:number

        /**
         * 战略点奖励
         **/
        @SafeProperty
        reward?:any

}

let medalstagerewardconfig:medalstagerewardconfigRow []=[];

var rowData=
[
    [1,50,[10567,10]],
    [2,100,[10567,10]],
    [3,150,[10567,10]],
    [4,200,[10567,10]],
    [5,250,[10567,10]],
    [6,300,[10567,10]],
    [7,350,[10567,10]],
    [8,400,[10567,10]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new medalstagerewardconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    medalstagerewardconfig .push(r);

}

export default medalstagerewardconfig
