const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","time","reward",]

export class onlinegiftconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 累计在线时长（秒）
         **/
        @SafeProperty
        time?:number

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:any

}

let onlinegiftconfig:onlinegiftconfigRow []=[];

var rowData=
[
    [1,150,[[10001,5000]]],
    [2,390,[[10002,100]]],
    [3,690,[[10003,1000]]],
    [4,1050,[[10060,30]]],
    [5,1530,[[10001,10000]]],
    [6,2130,[[10002,100]]],
    [7,2850,[[10003,2000]]],
    [8,3570,[[10060,30]]],
    [9,4290,[[10001,15000]]],
    [10,5010,[[10002,150]]],
    [11,5910,[[10003,7000]]],
    [12,6810,[[10060,60]]],
    [13,7710,[[10001,20000]]],
    [14,8610,[[10002,200]]],
    [15,9810,[[10003,15000]]],
    [16,10710,[[10060,60]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new onlinegiftconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    onlinegiftconfig .push(r);

}

export default onlinegiftconfig
