const { SafeProperty } = slib;

import Stageconfig,{StageconfigRow} from "./Stageconfig"

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","levelname","stage","Diamond",]

export class growUpConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 关卡名称
         **/
        @SafeProperty
        levelname?:string

        /**
         * 关卡进度
         **/
        @SafeProperty
        stage?:fk

        protected _fkstage?:StageconfigRow=undefined
        /**
         * 关卡进度
         **/
        get stageData(){
            if(this._fkstage===undefined){
                this._fkstage=Stageconfig.find(a=>a.ID==this.stage);
            }
            return this._fkstage;
        }

        /**
         * 钻石奖励
         **/
        @SafeProperty
        Diamond?:number

}

let growUpConfig:growUpConfigRow []=[];

var rowData=
[
    [1,"警察局",12,800],
    [2,"斯特兰书屋",40,800],
    [3,"埃及剧院",76,800],
    [4,"观光顶楼",108,1000],
    [5,"神秘金字塔",156,1000],
    [6,"摇滚酒吧",196,1000],
    [7,"万寿古阁",232,1200],
    [8,"静安寺",268,1200],
    [9,"东方明珠",316,1200],
    [10,"歌剧院",340,1500],
    [11,"丰古碑",364,1500],
    [12,"贞德号",392,1500],
    [13,"卡西诺超市",456,1500],
    [14,"卢浮宫",520,1500],
    [15,"钟楼",576,1500],
    [16,"丽兹酒店",616,1500],
    [17,"埃菲尔铁塔",668,1500],
    [18,"圣图安市场",732,2000],
    [19,"凯旋门",796,2000],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new growUpConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    growUpConfig .push(r);

}

export default growUpConfig
