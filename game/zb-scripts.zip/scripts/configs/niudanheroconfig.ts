const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","specifichero","hero",]

export class niudanheroconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 英雄池
         **/
        @SafeProperty
        specifichero?:number

        /**
         * 类型
作者:
1.固定
2.随机

         **/
        @SafeProperty
        hero?:number

}

let niudanheroconfig:niudanheroconfigRow []=[];

var rowData=
[
    [1,20038,1],
    [2,20039,1],
    [3,20062,1],
    [4,20048,1],
    [5,20033,2],
    [6,20046,2],
    [7,20034,2],
    [8,20015,2],
    [9,20024,2],
    [10,20007,2],
    [11,20006,2],
    [12,20008,2],
    [13,20009,2],
    [14,20025,2],
    [15,20035,2],
    [16,20036,2],
    [17,20045,2],
    [18,20049,2],
    [19,20052,2],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new niudanheroconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    niudanheroconfig .push(r);

}

export default niudanheroconfig
