const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","EqPLv","EqPCost1","EqOutfitID","coefficient",]

export class equippowerConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 充能等级（默认为0）
         **/
        @SafeProperty
        EqPLv?:number

        /**
         * 充能消耗（充到该等级，道具ID：数量）
         **/
        @SafeProperty
        EqPCost1?:any

        /**
         * 激活装备套装ID
         **/
        @SafeProperty
        EqOutfitID?:number

        /**
         * 充能系数
         **/
        @SafeProperty
        coefficient?:number

}

let equippowerConfig:equippowerConfigRow []=[];

var rowData=
[
    [1,1,[[10560,20]],0,0.05],
    [2,2,[[10560,60]],0,0.1],
    [3,3,[[10560,100]],0,0.15],
    [4,4,[[10560,120]],0,0.2],
    [5,5,[[10560,120],[10561,1]],1,0.3],
    [6,6,[[10560,140],[10561,1]],1,0.35],
    [7,7,[[10560,150],[10561,1]],1,0.4],
    [8,8,[[10560,180],[10561,1]],1,0.5],
    [9,9,[[10560,180],[10561,2]],2,0.6],
    [10,10,[[10560,190],[10561,2]],2,0.65],
    [11,11,[[10560,200],[10561,2]],2,0.7],
    [12,12,[[10560,210],[10561,2]],2,0.8],
    [13,13,[[10560,220],[10561,3]],3,0.95],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new equippowerConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    equippowerConfig .push(r);

}

export default equippowerConfig
