const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","Key","tips","battleId","playerLevel","viptreatment","priority","charge","viplevel","newModule","spriteFrame","describe","totaldescribe","go","lock",]

export class unlockConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        Id?:uid

        /**
         * 键
         **/
        @SafeProperty
        Key?:key

        /**
         * 未解锁提示语
         **/
        @SafeProperty
        tips?:string

        /**
         * 通关战役
         **/
        @SafeProperty
        battleId?:number

        /**
         * 玩家等级
         **/
        @SafeProperty
        playerLevel?:number

        /**
         * vip提前解锁
1.vip可提前解锁该功能

         **/
        @SafeProperty
        viptreatment?:number

        /**
         * 解锁优先级
没有填写的不填写数字
填写数字的则显示，
显示顺序由小到大依次排序（1>9）
         **/
        @SafeProperty
        priority?:number

        /**
         * 是否充值
         **/
        @SafeProperty
        charge?:bool

        /**
         * VIP等级
         **/
        @SafeProperty
        viplevel?:number

        /**
         * 新功能
         **/
        @SafeProperty
        newModule?:number

        /**
         * 图片
         **/
        @SafeProperty
        spriteFrame?:string

        /**
         * 功能描述
         **/
        @SafeProperty
        describe?:string

        /**
         * 详细描述
         **/
        @SafeProperty
        totaldescribe?:string

        /**
         * 前往
         **/
        @SafeProperty
        go?:string

        /**
         * 是否显示锁图标
         **/
        @SafeProperty
        lock?:number

}

let unlockConfig:unlockConfigRow []=[];

var rowData=
[
    [1,"抽卡机","通关4-4解锁",12,1,0,1,false,0,0,"unlock_icon_lottery","在抽卡机中可以召唤英雄","使用抽卡券或者钻石可以召唤出新的英雄","家园",1],
    [2,"花房","通关4-4解锁",12,1,0,2,false,0,0,"unlock_icon_evolution","可以提升英雄品阶","可以使用不同的材料提升英雄品阶，品阶越高，英雄能力越强","家园",1],
    [3,"摩天楼","通关5-4解锁",16,1,0,1,false,0,1,"unlock_icon_tower","挑战怪物，赢取奖励","通关每层都会获得大量奖励","挑战",1],
    [4,"档案台","即将开放",9999,1,0,1,false,0,1,"unlock_icon_lottery","组合羁绊，提升实力","组合相应的英雄，可以提升你的英雄属性","家园",1],
    [5,"共享花坛","通关27-4解锁",112,1,0,1,false,0,1,"unlock_icon_share","设置花坛祭司，共享等级","花坛祭司可以把自己的最低等级共享给其他英雄","家园",1],
    [6,"商店","通关4-4解锁",12,1,0,3,false,0,0,"","可以购买多样商品","商店中可以购买大量商品","家园",1],
    [7,"资源回收站","通关4-4解锁",12,1,0,0,false,0,0,"unlock_icon_recycle","回收废弃资源","不用的资源可以在回收站进行回收","家园",1],
    [8,"公会","通关9-4解锁",32,1,0,1,false,0,1,"unlock_icon_union","寻找伙伴，共同发展","找到志同道合的伙伴，可以共享自己的资源","家园",1],
    [9,"荣誉榜","通关10-4解锁",36,1,0,1,false,0,0,"","荣誉的象征","能在这里出现，那真的是最大的荣耀","家园",1],
    [10,"悬赏大厅","通关7-4解锁",24,1,0,1,false,0,1,"unlock_icon_xuanshang","完成悬赏任务，获取奖励","派出英雄完成悬赏任务，可以获得不菲的回报","挑战",1],
    [11,"竞技场","通关11-4解锁",40,1,0,1,false,0,1,"unlock_icon_pvp","与其他玩家皇城PK","想要证明自己的实力吗？那就去竞技场吧","挑战",1],
    [12,"智慧树考验","通关8-4解锁",28,1,0,1,false,0,1,"unlock_icon_wisdom","接受考验，提升战力","想要通关，那你需要一定的智慧","挑战",1],
    [13,"家园","家园还被僵尸占领着，通关4-4后可进入家园",12,1,0,0,false,0,0,"","家园按钮","家园按钮","",1],
    [14,"挑战","通往挑战的路被僵尸堵住了，通关5-4后可开启挑战",16,1,0,0,false,0,0,"","挑战按钮","挑战按钮","",1],
    [15,"智慧树礼包","通关40-8解锁",220,1,0,0,false,0,0,"","智慧树的礼包","智慧树的礼包","",0],
    [16,"遣散商店","通关4-4解锁",12,1,0,0,false,0,0,"","遣散商店","遣散商店","",0],
    [17,"迷宫商店","通关8-4解锁",28,1,0,0,false,0,0,"","迷宫商店","迷宫商店","",0],
    [18,"工会商店","通关9-4解锁",999999,1,0,0,false,0,0,"","工会商店","工会商店","",0],
    [19,"战斗加速","",1,1,0,0,false,1,0,"","战斗加速","战斗加速","",0],
    [20,"限时礼包","通关6-4解锁",20,1,0,0,false,0,0,"","限时礼包","限时礼包","",0],
    [21,"开服竞赛","通关4-4解锁",12,1,0,0,false,0,0,"","开服竞赛","开服竞赛","",0],
    [22,"七日签到","通关2-3解锁",4,1,0,0,false,0,0,"","七日签到","七日签到","",0],
    [23,"消费竞赛","通关4-4解锁",12,1,0,0,false,0,0,"","消费竞赛","消费竞赛","",0],
    [24,"充值竞赛","通关4-4解锁",12,1,0,0,false,0,0,"","充值竞赛","充值竞赛","",0],
    [25,"公告","通关5-4解锁",16,10,0,0,false,0,0,"","公告开启","公告开启","",0],
    [26,"活动","通关2-3解锁",4,1,0,0,false,0,0,"","限时促销","限时促销","",0],
    [27,"福利","通关1-1解锁",1,1,0,0,false,0,0,"","福利","福利","",0],
    [28,"首充礼包","通关2-3解锁",4,1,0,0,false,0,0,"","首充礼包","首充礼包","",0],
    [29,"净化先锋","通关8-4解锁",28,1,0,2,false,0,0,"","净化先锋","净化先锋","",0],
    [30,"世界BOSS","通关12-4解锁",44,15,0,0,false,0,0,"","世界BOSS","世界BOSS","",0],
    [31,"夺宝奇兵","通关10-4解锁",36,15,0,0,false,0,0,"","夺宝奇兵","夺宝奇兵","",0],
    [32,"棋盘活动","通关6-4解锁",20,10,0,0,false,0,0,"","棋盘活动","棋盘活动","",0],
    [33,"任务","通关2-3解锁",4,1,0,1,false,0,0,"","任务","任务","",0],
    [34,"好友","通关2-3解锁",4,1,0,0,false,0,0,"","好友","好友","",0],
    [35,"邮件","通关2-3解锁",4,1,0,0,false,0,0,"","邮件","邮件","",0],
    [36,"背包","通关2-3解锁",4,1,0,0,false,0,0,"","背包","背包","",0],
    [37,"快速挂机","通关2-3解锁",4,1,0,2,false,0,0,"","快速挂机","快速挂机","",0],
    [38,"新手任务","通关2-3解锁",4,1,0,0,false,0,0,"","","","",0],
    [39,"种族高塔","通关46-8解锁",288,1,0,1,false,0,0,"","","","",0],
    [40,"奇妙时空","通关32-8解锁",156,1,0,1,false,0,1,"unlock_icon_ziyuan","奇妙时空","丰富的地形机制，考验你的聪明才智","",1],
    [41,"新手礼包","通关2-3解锁",4,1,0,0,false,0,0,"","新手礼包","新手礼包","",0],
    [42,"成长礼包","通关6-4解锁",20,1,0,0,false,0,0,"","成长礼包","成长礼包","",0],
    [43,"世界频道发言权限","通关10-4解锁聊天功能",36,1,0,0,false,0,0,"","发言","发言","",0],
    [44,"高阶竞技场","通关30-4解锁",136,1,0,1,false,0,0,"","高阶竞技场","高阶竞技场","",0],
    [45,"每日周月礼包","通关2-1解锁",2,1,0,0,false,2,0,"","礼包","礼包"],
    [46,"地牢","通关28-8且拥有史诗品阶的英雄解锁",999999,1,0,1,false,0,0,"","地牢","只有通过地牢试炼的，才是真正的英雄。地牢中可获得大量的能够提升天赋的松子果","",1],
    [47,"在线奖励","通关4-1解锁",9,1,0,0,false,0,0,"","在线奖励","在线奖励"],
    [48,"探趣寻宝","通关10-4解锁",36,15,0,0,false,0,0,"","探趣寻宝","探趣寻宝","",0],
    [49,"新手基金","通关2-1解锁",2,1,0,0,true,0,0,"","新手基金","新手基金"],
    [50,"新手光环","通关2-3解锁",4,1,0,0,false,0,0,"","新手光环","新手光环"],
    [51,"新手学堂","通关3-2解锁",6,1,0,0,false,0,0,"","新手学堂","新手学堂"],
    [52,"神器","通关3-2解锁",6,1,0,0,false,0,0,"","神器","神器","",0],
    [53,"战斗回放与任务目标","通关3-4解锁",8,1,0,0,false,0,0,"","战斗回放与任务目标","战斗回放与任务目标","",0],
    [54,"跑马灯","通关4-4解锁",12,1,0,0,false,0,0,"0","跑马灯","跑马灯","",0],
    [55,"资源副本","通关13-4解锁",48,1,0,0,false,0,1,"unlock_icon_ziyuan","资源副本","通过每日挑战可以获得大量资源","",1],
    [56,"扭蛋机","通关27-8或VIP6解锁",116,1,0,0,false,6,0,"","扭蛋机","扭蛋机","",0],
    [57,"英雄获取","通关4-4解锁",12,1,0,0,false,0,0,"","获取","获取","",0],
    [58,"活跃礼包","通关8-4解锁",28,1,0,0,false,0,0,"","活跃礼包","活跃礼包","",0],
    [59,"寻宝","通关9-4解锁",32,1,0,0,false,0,0,"","寻宝","转动寻宝转盘，获得丰厚奖励","",1],
    [60,"合成","通关15-4解锁",56,1,0,0,false,0,0,"","合成","合成","",0],
    [61,"升星","通关12-4解锁",44,1,0,0,false,0,0,"","升星","升星"],
    [62,"克隆大作战","通关16-4解锁",60,1,0,0,false,0,0,"","克隆","克隆"],
    [63,"资源征收","通关2-1解锁",999999,1,0,0,false,0,0,"","征收","征收","",0],
    [64,"主线关卡跳过","通关27-8",116,1,0,0,false,0,0,"","主线跳过","主线跳过","",0],
    [65,"装备合成","通关17-4解锁",64,1,0,0,false,0,0,"","装备合成","装备合成","",0],
    [66,"装备充能","通关18-4解锁",68,1,0,0,false,0,0,"","装备充能","装备充能","",0],
    [67,"装备重铸","通关19-4解锁",72,1,0,0,false,0,0,"","装备重铸","装备重铸","",0],
    [68,"装备升星","通关20-4解锁",76,1,0,0,false,0,0,"","装备升星","装备升星","",0],
    [69,"神器锻造","通关21-4解锁",80,1,0,0,false,0,0,"","神器锻造","神器锻造","",0],
    [70,"勋章","通关22-4解锁",84,1,0,0,false,0,0,"","勋章","勋章"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new unlockConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

export let unlockConfigMap:{

    /** {"Id":1,"Key":"抽卡机","tips":"通关4-4解锁","battleId":12,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"unlock_icon_lottery","describe":"在抽卡机中可以召唤英雄","totaldescribe":"使用抽卡券或者钻石可以召唤出新的英雄","go":"家园","lock":1} */
    抽卡机?:unlockConfigRow

    /** {"Id":2,"Key":"花房","tips":"通关4-4解锁","battleId":12,"playerLevel":1,"viptreatment":0,"priority":2,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"unlock_icon_evolution","describe":"可以提升英雄品阶","totaldescribe":"可以使用不同的材料提升英雄品阶，品阶越高，英雄能力越强","go":"家园","lock":1} */
    花房?:unlockConfigRow

    /** {"Id":3,"Key":"摩天楼","tips":"通关5-4解锁","battleId":16,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":1,"spriteFrame":"unlock_icon_tower","describe":"挑战怪物，赢取奖励","totaldescribe":"通关每层都会获得大量奖励","go":"挑战","lock":1} */
    摩天楼?:unlockConfigRow

    /** {"Id":4,"Key":"档案台","tips":"即将开放","battleId":9999,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":1,"spriteFrame":"unlock_icon_lottery","describe":"组合羁绊，提升实力","totaldescribe":"组合相应的英雄，可以提升你的英雄属性","go":"家园","lock":1} */
    档案台?:unlockConfigRow

    /** {"Id":5,"Key":"共享花坛","tips":"通关27-4解锁","battleId":112,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":1,"spriteFrame":"unlock_icon_share","describe":"设置花坛祭司，共享等级","totaldescribe":"花坛祭司可以把自己的最低等级共享给其他英雄","go":"家园","lock":1} */
    共享花坛?:unlockConfigRow

    /** {"Id":6,"Key":"商店","tips":"通关4-4解锁","battleId":12,"playerLevel":1,"viptreatment":0,"priority":3,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"可以购买多样商品","totaldescribe":"商店中可以购买大量商品","go":"家园","lock":1} */
    商店?:unlockConfigRow

    /** {"Id":7,"Key":"资源回收站","tips":"通关4-4解锁","battleId":12,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"unlock_icon_recycle","describe":"回收废弃资源","totaldescribe":"不用的资源可以在回收站进行回收","go":"家园","lock":1} */
    资源回收站?:unlockConfigRow

    /** {"Id":8,"Key":"公会","tips":"通关9-4解锁","battleId":32,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":1,"spriteFrame":"unlock_icon_union","describe":"寻找伙伴，共同发展","totaldescribe":"找到志同道合的伙伴，可以共享自己的资源","go":"家园","lock":1} */
    公会?:unlockConfigRow

    /** {"Id":9,"Key":"荣誉榜","tips":"通关10-4解锁","battleId":36,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"荣誉的象征","totaldescribe":"能在这里出现，那真的是最大的荣耀","go":"家园","lock":1} */
    荣誉榜?:unlockConfigRow

    /** {"Id":10,"Key":"悬赏大厅","tips":"通关7-4解锁","battleId":24,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":1,"spriteFrame":"unlock_icon_xuanshang","describe":"完成悬赏任务，获取奖励","totaldescribe":"派出英雄完成悬赏任务，可以获得不菲的回报","go":"挑战","lock":1} */
    悬赏大厅?:unlockConfigRow

    /** {"Id":11,"Key":"竞技场","tips":"通关11-4解锁","battleId":40,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":1,"spriteFrame":"unlock_icon_pvp","describe":"与其他玩家皇城PK","totaldescribe":"想要证明自己的实力吗？那就去竞技场吧","go":"挑战","lock":1} */
    竞技场?:unlockConfigRow

    /** {"Id":12,"Key":"智慧树考验","tips":"通关8-4解锁","battleId":28,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":1,"spriteFrame":"unlock_icon_wisdom","describe":"接受考验，提升战力","totaldescribe":"想要通关，那你需要一定的智慧","go":"挑战","lock":1} */
    智慧树考验?:unlockConfigRow

    /** {"Id":13,"Key":"家园","tips":"家园还被僵尸占领着，通关4-4后可进入家园","battleId":12,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"家园按钮","totaldescribe":"家园按钮","go":"","lock":1} */
    家园?:unlockConfigRow

    /** {"Id":14,"Key":"挑战","tips":"通往挑战的路被僵尸堵住了，通关5-4后可开启挑战","battleId":16,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"挑战按钮","totaldescribe":"挑战按钮","go":"","lock":1} */
    挑战?:unlockConfigRow

    /** {"Id":15,"Key":"智慧树礼包","tips":"通关40-8解锁","battleId":220,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"智慧树的礼包","totaldescribe":"智慧树的礼包","go":"","lock":0} */
    智慧树礼包?:unlockConfigRow

    /** {"Id":16,"Key":"遣散商店","tips":"通关4-4解锁","battleId":12,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"遣散商店","totaldescribe":"遣散商店","go":"","lock":0} */
    遣散商店?:unlockConfigRow

    /** {"Id":17,"Key":"迷宫商店","tips":"通关8-4解锁","battleId":28,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"迷宫商店","totaldescribe":"迷宫商店","go":"","lock":0} */
    迷宫商店?:unlockConfigRow

    /** {"Id":18,"Key":"工会商店","tips":"通关9-4解锁","battleId":999999,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"工会商店","totaldescribe":"工会商店","go":"","lock":0} */
    工会商店?:unlockConfigRow

    /** {"Id":19,"Key":"战斗加速","tips":"","battleId":1,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":1,"newModule":0,"spriteFrame":"","describe":"战斗加速","totaldescribe":"战斗加速","go":"","lock":0} */
    战斗加速?:unlockConfigRow

    /** {"Id":20,"Key":"限时礼包","tips":"通关6-4解锁","battleId":20,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"限时礼包","totaldescribe":"限时礼包","go":"","lock":0} */
    限时礼包?:unlockConfigRow

    /** {"Id":21,"Key":"开服竞赛","tips":"通关4-4解锁","battleId":12,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"开服竞赛","totaldescribe":"开服竞赛","go":"","lock":0} */
    开服竞赛?:unlockConfigRow

    /** {"Id":22,"Key":"七日签到","tips":"通关2-3解锁","battleId":4,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"七日签到","totaldescribe":"七日签到","go":"","lock":0} */
    七日签到?:unlockConfigRow

    /** {"Id":23,"Key":"消费竞赛","tips":"通关4-4解锁","battleId":12,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"消费竞赛","totaldescribe":"消费竞赛","go":"","lock":0} */
    消费竞赛?:unlockConfigRow

    /** {"Id":24,"Key":"充值竞赛","tips":"通关4-4解锁","battleId":12,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"充值竞赛","totaldescribe":"充值竞赛","go":"","lock":0} */
    充值竞赛?:unlockConfigRow

    /** {"Id":25,"Key":"公告","tips":"通关5-4解锁","battleId":16,"playerLevel":10,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"公告开启","totaldescribe":"公告开启","go":"","lock":0} */
    公告?:unlockConfigRow

    /** {"Id":26,"Key":"活动","tips":"通关2-3解锁","battleId":4,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"限时促销","totaldescribe":"限时促销","go":"","lock":0} */
    活动?:unlockConfigRow

    /** {"Id":27,"Key":"福利","tips":"通关1-1解锁","battleId":1,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"福利","totaldescribe":"福利","go":"","lock":0} */
    福利?:unlockConfigRow

    /** {"Id":28,"Key":"首充礼包","tips":"通关2-3解锁","battleId":4,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"首充礼包","totaldescribe":"首充礼包","go":"","lock":0} */
    首充礼包?:unlockConfigRow

    /** {"Id":29,"Key":"净化先锋","tips":"通关8-4解锁","battleId":28,"playerLevel":1,"viptreatment":0,"priority":2,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"净化先锋","totaldescribe":"净化先锋","go":"","lock":0} */
    净化先锋?:unlockConfigRow

    /** {"Id":30,"Key":"世界BOSS","tips":"通关12-4解锁","battleId":44,"playerLevel":15,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"世界BOSS","totaldescribe":"世界BOSS","go":"","lock":0} */
    世界BOSS?:unlockConfigRow

    /** {"Id":31,"Key":"夺宝奇兵","tips":"通关10-4解锁","battleId":36,"playerLevel":15,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"夺宝奇兵","totaldescribe":"夺宝奇兵","go":"","lock":0} */
    夺宝奇兵?:unlockConfigRow

    /** {"Id":32,"Key":"棋盘活动","tips":"通关6-4解锁","battleId":20,"playerLevel":10,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"棋盘活动","totaldescribe":"棋盘活动","go":"","lock":0} */
    棋盘活动?:unlockConfigRow

    /** {"Id":33,"Key":"任务","tips":"通关2-3解锁","battleId":4,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"任务","totaldescribe":"任务","go":"","lock":0} */
    任务?:unlockConfigRow

    /** {"Id":34,"Key":"好友","tips":"通关2-3解锁","battleId":4,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"好友","totaldescribe":"好友","go":"","lock":0} */
    好友?:unlockConfigRow

    /** {"Id":35,"Key":"邮件","tips":"通关2-3解锁","battleId":4,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"邮件","totaldescribe":"邮件","go":"","lock":0} */
    邮件?:unlockConfigRow

    /** {"Id":36,"Key":"背包","tips":"通关2-3解锁","battleId":4,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"背包","totaldescribe":"背包","go":"","lock":0} */
    背包?:unlockConfigRow

    /** {"Id":37,"Key":"快速挂机","tips":"通关2-3解锁","battleId":4,"playerLevel":1,"viptreatment":0,"priority":2,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"快速挂机","totaldescribe":"快速挂机","go":"","lock":0} */
    快速挂机?:unlockConfigRow

    /** {"Id":38,"Key":"新手任务","tips":"通关2-3解锁","battleId":4,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"","totaldescribe":"","go":"","lock":0} */
    新手任务?:unlockConfigRow

    /** {"Id":39,"Key":"种族高塔","tips":"通关46-8解锁","battleId":288,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"","totaldescribe":"","go":"","lock":0} */
    种族高塔?:unlockConfigRow

    /** {"Id":40,"Key":"奇妙时空","tips":"通关32-8解锁","battleId":156,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":1,"spriteFrame":"unlock_icon_ziyuan","describe":"奇妙时空","totaldescribe":"丰富的地形机制，考验你的聪明才智","go":"","lock":1} */
    奇妙时空?:unlockConfigRow

    /** {"Id":41,"Key":"新手礼包","tips":"通关2-3解锁","battleId":4,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"新手礼包","totaldescribe":"新手礼包","go":"","lock":0} */
    新手礼包?:unlockConfigRow

    /** {"Id":42,"Key":"成长礼包","tips":"通关6-4解锁","battleId":20,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"成长礼包","totaldescribe":"成长礼包","go":"","lock":0} */
    成长礼包?:unlockConfigRow

    /** {"Id":43,"Key":"世界频道发言权限","tips":"通关10-4解锁聊天功能","battleId":36,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"发言","totaldescribe":"发言","go":"","lock":0} */
    世界频道发言权限?:unlockConfigRow

    /** {"Id":44,"Key":"高阶竞技场","tips":"通关30-4解锁","battleId":136,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"高阶竞技场","totaldescribe":"高阶竞技场","go":"","lock":0} */
    高阶竞技场?:unlockConfigRow

    /** {"Id":45,"Key":"每日周月礼包","tips":"通关2-1解锁","battleId":2,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":2,"newModule":0,"spriteFrame":"","describe":"礼包","totaldescribe":"礼包"} */
    每日周月礼包?:unlockConfigRow

    /** {"Id":46,"Key":"地牢","tips":"通关28-8且拥有史诗品阶的英雄解锁","battleId":999999,"playerLevel":1,"viptreatment":0,"priority":1,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"地牢","totaldescribe":"只有通过地牢试炼的，才是真正的英雄。地牢中可获得大量的能够提升天赋的松子果","go":"","lock":1} */
    地牢?:unlockConfigRow

    /** {"Id":47,"Key":"在线奖励","tips":"通关4-1解锁","battleId":9,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"在线奖励","totaldescribe":"在线奖励"} */
    在线奖励?:unlockConfigRow

    /** {"Id":48,"Key":"探趣寻宝","tips":"通关10-4解锁","battleId":36,"playerLevel":15,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"探趣寻宝","totaldescribe":"探趣寻宝","go":"","lock":0} */
    探趣寻宝?:unlockConfigRow

    /** {"Id":49,"Key":"新手基金","tips":"通关2-1解锁","battleId":2,"playerLevel":1,"viptreatment":0,"priority":0,"charge":true,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"新手基金","totaldescribe":"新手基金"} */
    新手基金?:unlockConfigRow

    /** {"Id":50,"Key":"新手光环","tips":"通关2-3解锁","battleId":4,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"新手光环","totaldescribe":"新手光环"} */
    新手光环?:unlockConfigRow

    /** {"Id":51,"Key":"新手学堂","tips":"通关3-2解锁","battleId":6,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"新手学堂","totaldescribe":"新手学堂"} */
    新手学堂?:unlockConfigRow

    /** {"Id":52,"Key":"神器","tips":"通关3-2解锁","battleId":6,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"神器","totaldescribe":"神器","go":"","lock":0} */
    神器?:unlockConfigRow

    /** {"Id":53,"Key":"战斗回放与任务目标","tips":"通关3-4解锁","battleId":8,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"战斗回放与任务目标","totaldescribe":"战斗回放与任务目标","go":"","lock":0} */
    战斗回放与任务目标?:unlockConfigRow

    /** {"Id":54,"Key":"跑马灯","tips":"通关4-4解锁","battleId":12,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"0","describe":"跑马灯","totaldescribe":"跑马灯","go":"","lock":0} */
    跑马灯?:unlockConfigRow

    /** {"Id":55,"Key":"资源副本","tips":"通关13-4解锁","battleId":48,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":1,"spriteFrame":"unlock_icon_ziyuan","describe":"资源副本","totaldescribe":"通过每日挑战可以获得大量资源","go":"","lock":1} */
    资源副本?:unlockConfigRow

    /** {"Id":56,"Key":"扭蛋机","tips":"通关27-8或VIP6解锁","battleId":116,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":6,"newModule":0,"spriteFrame":"","describe":"扭蛋机","totaldescribe":"扭蛋机","go":"","lock":0} */
    扭蛋机?:unlockConfigRow

    /** {"Id":57,"Key":"英雄获取","tips":"通关4-4解锁","battleId":12,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"获取","totaldescribe":"获取","go":"","lock":0} */
    英雄获取?:unlockConfigRow

    /** {"Id":58,"Key":"活跃礼包","tips":"通关8-4解锁","battleId":28,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"活跃礼包","totaldescribe":"活跃礼包","go":"","lock":0} */
    活跃礼包?:unlockConfigRow

    /** {"Id":59,"Key":"寻宝","tips":"通关9-4解锁","battleId":32,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"寻宝","totaldescribe":"转动寻宝转盘，获得丰厚奖励","go":"","lock":1} */
    寻宝?:unlockConfigRow

    /** {"Id":60,"Key":"合成","tips":"通关15-4解锁","battleId":56,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"合成","totaldescribe":"合成","go":"","lock":0} */
    合成?:unlockConfigRow

    /** {"Id":61,"Key":"升星","tips":"通关12-4解锁","battleId":44,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"升星","totaldescribe":"升星"} */
    升星?:unlockConfigRow

    /** {"Id":62,"Key":"克隆大作战","tips":"通关16-4解锁","battleId":60,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"克隆","totaldescribe":"克隆"} */
    克隆大作战?:unlockConfigRow

    /** {"Id":63,"Key":"资源征收","tips":"通关2-1解锁","battleId":999999,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"征收","totaldescribe":"征收","go":"","lock":0} */
    资源征收?:unlockConfigRow

    /** {"Id":64,"Key":"主线关卡跳过","tips":"通关27-8","battleId":116,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"主线跳过","totaldescribe":"主线跳过","go":"","lock":0} */
    主线关卡跳过?:unlockConfigRow

    /** {"Id":65,"Key":"装备合成","tips":"通关17-4解锁","battleId":64,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"装备合成","totaldescribe":"装备合成","go":"","lock":0} */
    装备合成?:unlockConfigRow

    /** {"Id":66,"Key":"装备充能","tips":"通关18-4解锁","battleId":68,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"装备充能","totaldescribe":"装备充能","go":"","lock":0} */
    装备充能?:unlockConfigRow

    /** {"Id":67,"Key":"装备重铸","tips":"通关19-4解锁","battleId":72,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"装备重铸","totaldescribe":"装备重铸","go":"","lock":0} */
    装备重铸?:unlockConfigRow

    /** {"Id":68,"Key":"装备升星","tips":"通关20-4解锁","battleId":76,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"装备升星","totaldescribe":"装备升星","go":"","lock":0} */
    装备升星?:unlockConfigRow

    /** {"Id":69,"Key":"神器锻造","tips":"通关21-4解锁","battleId":80,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"神器锻造","totaldescribe":"神器锻造","go":"","lock":0} */
    神器锻造?:unlockConfigRow

    /** {"Id":70,"Key":"勋章","tips":"通关22-4解锁","battleId":84,"playerLevel":1,"viptreatment":0,"priority":0,"charge":false,"viplevel":0,"newModule":0,"spriteFrame":"","describe":"勋章","totaldescribe":"勋章"} */
    勋章?:unlockConfigRow

}={}

for(let r of tableData){
    unlockConfig .push(r);

    unlockConfigMap [r. Key ] =r;

}

export default unlockConfig
