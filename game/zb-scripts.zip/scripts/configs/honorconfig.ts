const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","type","heroscore","stageprogress","floor","diamond",]

export class honorconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 类型
         **/
        @SafeProperty
        type?:number

        /**
         * 英雄积分要求
         **/
        @SafeProperty
        heroscore?:number

        /**
         * 关卡进度（章）
         **/
        @SafeProperty
        stageprogress?:any

        /**
         * 摩天楼（层）
         **/
        @SafeProperty
        floor?:number

        /**
         * 钻石奖励
         **/
        @SafeProperty
        diamond?:number

}

let honorconfig:honorconfigRow []=[];

var rowData=
[
    [1001,1,5800,null,0,50],
    [1002,1,9800,null,0,50],
    [1003,1,13800,null,0,50],
    [1004,1,17800,null,0,50],
    [1005,1,21800,null,0,50],
    [1006,1,25800,null,0,50],
    [1007,1,29800,null,0,50],
    [1008,1,33800,null,0,50],
    [1009,1,37800,null,0,50],
    [1010,1,41800,null,0,50],
    [1011,1,45800,null,0,50],
    [1012,1,49800,null,0,50],
    [1013,1,53800,null,0,50],
    [1014,1,57800,null,0,50],
    [1015,1,61800,null,0,50],
    [1016,1,65800,null,0,50],
    [1017,1,69800,null,0,50],
    [1018,1,73800,null,0,50],
    [1019,1,77800,null,0,50],
    [2001,2,0,5,0,50],
    [2002,2,0,6,0,50],
    [2003,2,0,7,0,50],
    [2004,2,0,8,0,50],
    [2005,2,0,9,0,50],
    [2006,2,0,10,0,50],
    [2007,2,0,11,0,50],
    [2008,2,0,12,0,50],
    [2009,2,0,13,0,50],
    [2010,2,0,14,0,50],
    [2011,2,0,15,0,50],
    [2012,2,0,16,0,50],
    [2013,2,0,17,0,50],
    [2014,2,0,18,0,50],
    [2015,2,0,19,0,50],
    [2016,2,0,20,0,50],
    [3001,3,0,null,100,50],
    [3002,3,0,null,125,50],
    [3003,3,0,null,150,50],
    [3004,3,0,null,175,50],
    [3005,3,0,null,200,50],
    [3006,3,0,null,225,50],
    [3007,3,0,null,250,50],
    [3008,3,0,null,275,50],
    [3009,3,0,null,300,50],
    [3010,3,0,null,325,50],
    [3011,3,0,null,350,50],
    [3012,3,0,null,375,50],
    [3013,3,0,null,400,50],
    [3014,3,0,null,425,50],
    [3015,3,0,null,450,50],
    [3016,3,0,null,475,50],
    [3017,3,0,null,500,50],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new honorconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    honorconfig .push(r);

}

export default honorconfig
