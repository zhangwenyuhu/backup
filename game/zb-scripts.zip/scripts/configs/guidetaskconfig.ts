const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","tasktitle","tasktype","lasttask","nexttask","value","value2","describe","reward",]

export class guidetaskconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 任务标题
         **/
        @SafeProperty
        tasktitle?:string

        /**
         * 任务类型
         **/
        @SafeProperty
        tasktype?:number

        /**
         * 前置任务
         **/
        @SafeProperty
        lasttask?:number

        /**
         * 后置任务
         **/
        @SafeProperty
        nexttask?:number

        /**
         * 参数值
         **/
        @SafeProperty
        value?:number

        /**
         * 参数值2
         **/
        @SafeProperty
        value2?:number

        /**
         * 任务描述
         **/
        @SafeProperty
        describe?:string

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:any

}

let guidetaskconfig:guidetaskconfigRow []=[];

var rowData=
[
    [1001,"净化快餐车",3006,0,1002,1,0,"净化建筑快餐车",[[10003,500]]],
    [1002,"海草升10级",5001,1001,1003,20012,10,"将你的海草升级到10级",[[10002,30]]],
    [1003,"穿装备",5002,1002,1004,1,0,"给一位英雄穿上装备",[[10001,500]]],
    [1004,"3个英雄升10级",5003,1003,1005,3,10,"将任意3个英雄升级至10级",[[10003,2000]]],
    [1005,"净化咖啡屋",3006,1004,1006,8,0,"净化建筑咖啡屋",[[10002,50]]],
    [1006,"挂机奖励",5007,1005,1007,1,0,"领取一次挂机奖励",[[10031,1]]],
    [1007,"突破20级",5004,1006,1008,1,20,"将任意1个英雄升级至20级",[[10041,1]]],
    [1008,"净化警察局",3006,1007,1009,12,0,"净化建筑警察局",[[10060,30]]],
    [1009,"获得紫色英雄",3014,1008,1010,1,0,"获得1个紫色英雄",[[10032,1]]],
    [1010,"升级紫色英雄",5005,1009,1011,1,10,"将1个紫色英雄升级到10级",[[10002,50]]],
    [1011,"快速挂机",1007,1010,1012,1,0,"领取一次快速挂机奖励",[[10008,20]]],
    [1012,"取个名字",3015,1011,1013,0,0,"给自己取个响亮的名字",[[10002,100]]],
    [1013,"净化小教堂",3006,1012,1014,16,0,"净化建筑小教堂",[[10006,2]]],
    [1014,"智慧树考验",5006,1013,1015,1,0,"参加一次智慧树的考验",[[10002,100]]],
    [1015,"净化干洗店",3006,1014,1016,20,0,"净化建筑干洗店",[[10006,3]]],
    [1016,"摩天楼5层",3003,1015,0,5,0,"通关摩天楼第5层",[[10060,60]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new guidetaskconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    guidetaskconfig .push(r);

}

export default guidetaskconfig
