const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","Key","value",]

export class defaultConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        Id?:uid

        /**
         * 键
         **/
        @SafeProperty
        Key?:key

        /**
         * 值
         **/
        @SafeProperty
        value?:any

}

let defaultConfig:defaultConfigRow []=[];

var rowData=
[
    [1,"heroDiamond",100],
    [2,"gachaRank4Counts",30],
    [3,"gachaWishCoefficient",2],
    [4,"gacha100Reward","[[10075,1]]"],
    [5,"nonusehero"],
    [6,"heroRankLimit","1;10"],
    [7,"resolveHeroCoin",160],
    [8,"resolveHeroDust",5],
    [9,"friendsnumberlimit",30],
    [10,"friendpointsendlimit",30],
    [11,"friendpointgetlimit",20],
    [12,"arenafreetime",2],
    [13,"guildcreateconsum",500],
    [14,"maxallowfaction",3],
    [15,"factionnoticenumber",50],
    [16,"daypeopleactivelimit",100],
    [17,"changejoinlevel","0;10;15;20;25;30;35;40;45;50;55;60;65;70;75;80"],
    [18,"guildexitcd",3600],
    [19,"heroboxstart",90],
    [20,"heroboxbuyspend","100;100;150;150;200;200;250;250;300;300;450;450;500;500"],
    [21,"heroboxperbuy",5],
    [22,"togetherapplylimit",5],
    [23,"mercenaryweekwin",1],
    [24,"friendheroquality",6],
    [25,"goldshow","0;15;30;120;360;720"],
    [26,"quickprofit","0;50;100;200;200;300;300;400;400;500"],
    [27,"heroinitialicon","20001;20002;20003;20004;20005"],
    [28,"arenaticketprice",100],
    [29,"idletimelimit",720],
    [30,"quickprofitbuy",4],
    [31,"quickprofittime",120],
    [32,"helpherolimit",6],
    [33,"arenafirstscore",1000],
    [34,"artifactunlock",46],
    [35,"goldshoweffect","0.2;60;360;720"],
    [36,"changenameprice",200],
    [37,"huntbossopen",10],
    [38,"huntbossduration",4],
    [39,"huntbosstimelimit",3],
    [40,"boss1goodsshow","10002;10068;30111;30113;30414;30424"],
    [41,"boss2goodsshow","10002;10068;30111;30113;30413;30414"],
    [42,"huntboss","99001;99002"],
    [43,"gebulindaytime",2],
    [44,"jianhundaytime",2],
    [45,"factioncoindrop",65],
    [46,"factiongoldget",2.67],
    [47,"factiondiamond",0.1],
    [48,"diamondboxdrop","[[10070,0.5],[10071,0.3],[10072,0.15],[10073,0.05]]"],
    [49,"factionresetname",500],
    [50,"mazediamond",150],
    [51,"eliteguard",1.25],
    [52,"mazefixation","[[10562,1],[10043,4],[10067,200]]"],
    [53,"mazerandom",1],
    [54,"initialhero","[[20029,1,2],[20028,1,2]]"],
    [55,"mazebossbattle",1.15],
    [56,"HYLBkaifang",8],
    [57,"HYLBCD",49],
    [58,"ZHSCD",44],
    [59,"herorewardnumber","[[10062,0],[10062,0],[10062,0]]"],
    [60,"factionbossblood",2000],
    [61,"gachaInitial",0],
    [62,"arenatimelimit",15],
    [63,"equipdroptime",120],
    [64,"dustdroptime",30],
    [65,"taskresetcost",50],
    [66,"energyspeedup",2],
    [67,"energyspeedupstop",5],
    [68,"mazebattlenumber","0.15;0.05;1.7;0.2"],
    [69,"energystartadd",550],
    [70,"energyaddstop",28],
    [71,"worldbossspend","100;150;200;250;300"],
    [72,"challengeticket",150],
    [73,"bloodratio",0.01],
    [74,"zombieposition",13],
    [75,"playerkillzombie","[[10002,200]]"],
    [76,"zombiekillplayer",1],
    [77,"flowerunlock",5],
    [78,"flowerunlockbuy","300;300;400;400;500;500;800;800;1200;1500"],
    [79,"videogift","[[10061,2],[10002,20]]"],
    [80,"tryonheroblood",100000000],
    [81,"guaranteeepic",2],
    [82,"wuzhaungopen","1;5;7"],
    [83,"jixieopen","2;5;7"],
    [84,"bianzhongopen","3;6;7"],
    [85,"jiangshiopen","4;6;7"],
    [86,"dungeonhero","100;150;200;250;300"],
    [87,"guidemazebattlenumber","0.12;0.04;1.7;0.2"],
    [88,"factiongoldgetnew","63100;6.2242;62.823;15000"],
    [89,"pioneertoplimit",10],
    [90,"stagefailtime",5],
    [91,"heroconversationtime","4;3"],
    [92,"battlecoinhavelimit",500000],
    [93,"battlecoinboxnumber",10000],
    [94,"normalmonthcardvideo",3],
    [95,"arenahighfreetime",5],
    [96,"arenahighprice","450;450;450;600;600;600;900;900;900;1200;1200;1200;1500;1500"],
    [97,"arenahighticketnumber",3],
    [98,"factionwalletnumber",30],
    [99,"battleboxdrop",0.03],
    [100,"geniusbegin",5],
    [101,"videoopen",0],
    [102,"artfitchange",20],
    [103,"rechargepopup",8],
    [104,"arenascoremate",1200],
    [105,"pioneerpower","7;14;21"],
    [106,"dilaoputonglimit",60],
    [107,"dilaolvlimit",30],
    [108,"genuineunlock",10],
    [109,"fundover",10],
    [110,"wheelCounts","100;20"],
    [111,"wheelLevel","2;3"],
    [112,"wheelTen","0;0"],
    [113,"wheelTenGift","[[10060,0]]"],
    [114,"wheelShopCurr","10;0"],
    [115,"wheelRenovate","100;200;400;600;800;1000"],
    [116,"wheelAdvRenovate",1000],
    [117,"wheelTenCost","8;10"],
    [118,"dilaounlock",6],
    [119,"flowernumber1",25],
    [120,"flowernumber2",5],
    [121,"WheatheDisplay","1;2;3;4"],
    [122,"resourcefreetime",2],
    [123,"resourcebuytime",0],
    [124,"resourcebuyprice","50;100;150;200;250;300;300;300;300;300"],
    [125,"resourcerecycletime",10],
    [126,"recycleprice",20],
    [127,"niudanrandomnumber",6],
    [128,"recyclepercent",0.3],
    [129,"niudandiamond",500],
    [130,"niudanfloors",5],
    [131,"namelength",200],
    [132,"GachaVideoTime",120],
    [133,"gachaprice",200],
    [134,"wheelprice",300],
    [135,"niudanprice",500],
    [136,"gachatenprice",1800],
    [137,"niudantenprice",5000],
    [138,"highbattlecoinhavelimit",500000],
    [139,"highbattlecoinboxnumber",10000],
    [140,"liketimelimit",3],
    [141,"likereward","[10001,8000]"],
    [142,"monthcardquickprofit",6],
    [143,"Srherostarlimit",0],
    [144,"smonthcardquickprofit",8],
    [145,"dilaoherorank",7],
    [146,"battlenumberequip","3.7;0.2;4.6;3.8;3.8;4.8;3;7400;4500;4500;740;7400;2300;2300;3700;370;1500;7400;7400;7400"],
    [147,"battlenumberhero","3.7;0.2;4.6;3.8;3.8;4.8;3;7400;4500;4500;740;7400;2300;2300;3700;370;1500;7400;7400;7400;1.2;1700"],
    [148,"pyygachagive",1],
    [149,"pyyonceprice",20],
    [150,"goldlack","0;29;7"],
    [151,"explack","0;29;7"],
    [152,"dustlack","8;1;7"],
    [153,"artifactstonelack",31],
    [154,"drawlack","8;37"],
    [155,"skybuildbattlenumber",1.3],
    [156,"clonefreetime",2],
    [157,"clonezero",2],
    [158,"cloneresetcost","300;400;500;500;500"],
    [159,"cloneresettime",3],
    [160,"cloneticketlack",39],
    [161,"moguhomestar","1;2;3"],
    [162,"supplybasictime",3],
    [163,"supplyresettime",1],
    [164,"supplyresetprice","300;300;350;350;400;400;400;400;400"],
    [165,"tiliuplimit",60],
    [166,"tiliautoadd",600],
    [167,"tilibuy",60],
    [168,"tilibuyprice","50;100;150;150;200;200;300;300;300;300;300;300"],
    [169,"tilibuylimit",3],
    [170,"normalsupply",5],
    [171,"advancedsupply",10],
    [172,"supplybasicresetbuytime",3],
    [173,"tupoherolevel",20],
    [174,"normalfindtime",10],
    [175,"equipreborncost",20],
    [176,"heroreset",20],
    [177,"heroresolve",200],
    [178,"wisdomTreeStonereward","0.5;0.5"],
    [179,"arenarefresh",10],
    [180,"searchfreetime",1],
    [181,"factionsearchfreetime",1],
    [182,"searchtimebuy","50;100;150;200"],
    [183,"searchtimebuylimit",0],
    [184,"higharenaoriginalscore",1000],
    [185,"higharenalowscore",500],
    [186,"unionresetprice",2000],
    [187,"uniontechfreereset",1],
    [188,"bajiaocitimebuy",3],
    [189,"bajiaocibuyprice","200;300;400;400;400;400;400"],
    [190,"dujianmutimebuy",3],
    [191,"dujianmubuyprice","200;300;400;400;400;400;400"],
    [192,"ruodianfaction","0.2;0.2;0.2;0.2;0.1;0.1"],
    [193,"Resist",0.2],
    [194,"atk",0.2],
    [195,"GuildDungeonLimit",1],
    [196,"GuildDungeonAttackNum",10],
    [197,"yunxingless","8;32"],
    [198,"engineless","1;24;32;42"],
    [199,"enginemirroless","24;32;42"],
    [200,"factiontechreset",1000],
    [201,"factionenergylimit",20],
    [202,"factionenergycost",5],
    [203,"factionenergyget",10],
    [204,"factionenergybuylimit",5],
    [205,"factionenergybuyprice","100;120;140;160;180;200;220;240;260"],
    [206,"factionenergybuynumber",10],
    [207,"factionhavelimit",3],
    [208,"factionjoinlimit",1],
    [209,"factionproducespeed",60],
    [210,"factionjoinlimitadd","40;30;20;10;5"],
    [211,"factionbattlespecialbox",5],
    [212,"medalless",24],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new defaultConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

export let defaultConfigMap:{

    /** {"Id":1,"Key":"heroDiamond","value":100} */
    heroDiamond?:defaultConfigRow

    /** {"Id":2,"Key":"gachaRank4Counts","value":30} */
    gachaRank4Counts?:defaultConfigRow

    /** {"Id":3,"Key":"gachaWishCoefficient","value":2} */
    gachaWishCoefficient?:defaultConfigRow

    /** {"Id":4,"Key":"gacha100Reward","value":"[[10075,1]]"} */
    gacha100Reward?:defaultConfigRow

    /** {"Id":5,"Key":"nonusehero"} */
    nonusehero?:defaultConfigRow

    /** {"Id":6,"Key":"heroRankLimit","value":"1;10"} */
    heroRankLimit?:defaultConfigRow

    /** {"Id":7,"Key":"resolveHeroCoin","value":160} */
    resolveHeroCoin?:defaultConfigRow

    /** {"Id":8,"Key":"resolveHeroDust","value":5} */
    resolveHeroDust?:defaultConfigRow

    /** {"Id":9,"Key":"friendsnumberlimit","value":30} */
    friendsnumberlimit?:defaultConfigRow

    /** {"Id":10,"Key":"friendpointsendlimit","value":30} */
    friendpointsendlimit?:defaultConfigRow

    /** {"Id":11,"Key":"friendpointgetlimit","value":20} */
    friendpointgetlimit?:defaultConfigRow

    /** {"Id":12,"Key":"arenafreetime","value":2} */
    arenafreetime?:defaultConfigRow

    /** {"Id":13,"Key":"guildcreateconsum","value":500} */
    guildcreateconsum?:defaultConfigRow

    /** {"Id":14,"Key":"maxallowfaction","value":3} */
    maxallowfaction?:defaultConfigRow

    /** {"Id":15,"Key":"factionnoticenumber","value":50} */
    factionnoticenumber?:defaultConfigRow

    /** {"Id":16,"Key":"daypeopleactivelimit","value":100} */
    daypeopleactivelimit?:defaultConfigRow

    /** {"Id":17,"Key":"changejoinlevel","value":"0;10;15;20;25;30;35;40;45;50;55;60;65;70;75;80"} */
    changejoinlevel?:defaultConfigRow

    /** {"Id":18,"Key":"guildexitcd","value":3600} */
    guildexitcd?:defaultConfigRow

    /** {"Id":19,"Key":"heroboxstart","value":90} */
    heroboxstart?:defaultConfigRow

    /** {"Id":20,"Key":"heroboxbuyspend","value":"100;100;150;150;200;200;250;250;300;300;450;450;500;500"} */
    heroboxbuyspend?:defaultConfigRow

    /** {"Id":21,"Key":"heroboxperbuy","value":5} */
    heroboxperbuy?:defaultConfigRow

    /** {"Id":22,"Key":"togetherapplylimit","value":5} */
    togetherapplylimit?:defaultConfigRow

    /** {"Id":23,"Key":"mercenaryweekwin","value":1} */
    mercenaryweekwin?:defaultConfigRow

    /** {"Id":24,"Key":"friendheroquality","value":6} */
    friendheroquality?:defaultConfigRow

    /** {"Id":25,"Key":"goldshow","value":"0;15;30;120;360;720"} */
    goldshow?:defaultConfigRow

    /** {"Id":26,"Key":"quickprofit","value":"0;50;100;200;200;300;300;400;400;500"} */
    quickprofit?:defaultConfigRow

    /** {"Id":27,"Key":"heroinitialicon","value":"20001;20002;20003;20004;20005"} */
    heroinitialicon?:defaultConfigRow

    /** {"Id":28,"Key":"arenaticketprice","value":100} */
    arenaticketprice?:defaultConfigRow

    /** {"Id":29,"Key":"idletimelimit","value":720} */
    idletimelimit?:defaultConfigRow

    /** {"Id":30,"Key":"quickprofitbuy","value":4} */
    quickprofitbuy?:defaultConfigRow

    /** {"Id":31,"Key":"quickprofittime","value":120} */
    quickprofittime?:defaultConfigRow

    /** {"Id":32,"Key":"helpherolimit","value":6} */
    helpherolimit?:defaultConfigRow

    /** {"Id":33,"Key":"arenafirstscore","value":1000} */
    arenafirstscore?:defaultConfigRow

    /** {"Id":34,"Key":"artifactunlock","value":46} */
    artifactunlock?:defaultConfigRow

    /** {"Id":35,"Key":"goldshoweffect","value":"0.2;60;360;720"} */
    goldshoweffect?:defaultConfigRow

    /** {"Id":36,"Key":"changenameprice","value":200} */
    changenameprice?:defaultConfigRow

    /** {"Id":37,"Key":"huntbossopen","value":10} */
    huntbossopen?:defaultConfigRow

    /** {"Id":38,"Key":"huntbossduration","value":4} */
    huntbossduration?:defaultConfigRow

    /** {"Id":39,"Key":"huntbosstimelimit","value":3} */
    huntbosstimelimit?:defaultConfigRow

    /** {"Id":40,"Key":"boss1goodsshow","value":"10002;10068;30111;30113;30414;30424"} */
    boss1goodsshow?:defaultConfigRow

    /** {"Id":41,"Key":"boss2goodsshow","value":"10002;10068;30111;30113;30413;30414"} */
    boss2goodsshow?:defaultConfigRow

    /** {"Id":42,"Key":"huntboss","value":"99001;99002"} */
    huntboss?:defaultConfigRow

    /** {"Id":43,"Key":"gebulindaytime","value":2} */
    gebulindaytime?:defaultConfigRow

    /** {"Id":44,"Key":"jianhundaytime","value":2} */
    jianhundaytime?:defaultConfigRow

    /** {"Id":45,"Key":"factioncoindrop","value":65} */
    factioncoindrop?:defaultConfigRow

    /** {"Id":46,"Key":"factiongoldget","value":2.67} */
    factiongoldget?:defaultConfigRow

    /** {"Id":47,"Key":"factiondiamond","value":0.1} */
    factiondiamond?:defaultConfigRow

    /** {"Id":48,"Key":"diamondboxdrop","value":"[[10070,0.5],[10071,0.3],[10072,0.15],[10073,0.05]]"} */
    diamondboxdrop?:defaultConfigRow

    /** {"Id":49,"Key":"factionresetname","value":500} */
    factionresetname?:defaultConfigRow

    /** {"Id":50,"Key":"mazediamond","value":150} */
    mazediamond?:defaultConfigRow

    /** {"Id":51,"Key":"eliteguard","value":1.25} */
    eliteguard?:defaultConfigRow

    /** {"Id":52,"Key":"mazefixation","value":"[[10562,1],[10043,4],[10067,200]]"} */
    mazefixation?:defaultConfigRow

    /** {"Id":53,"Key":"mazerandom","value":1} */
    mazerandom?:defaultConfigRow

    /** {"Id":54,"Key":"initialhero","value":"[[20029,1,2],[20028,1,2]]"} */
    initialhero?:defaultConfigRow

    /** {"Id":55,"Key":"mazebossbattle","value":1.15} */
    mazebossbattle?:defaultConfigRow

    /** {"Id":56,"Key":"HYLBkaifang","value":8} */
    HYLBkaifang?:defaultConfigRow

    /** {"Id":57,"Key":"HYLBCD","value":49} */
    HYLBCD?:defaultConfigRow

    /** {"Id":58,"Key":"ZHSCD","value":44} */
    ZHSCD?:defaultConfigRow

    /** {"Id":59,"Key":"herorewardnumber","value":"[[10062,0],[10062,0],[10062,0]]"} */
    herorewardnumber?:defaultConfigRow

    /** {"Id":60,"Key":"factionbossblood","value":2000} */
    factionbossblood?:defaultConfigRow

    /** {"Id":61,"Key":"gachaInitial","value":0} */
    gachaInitial?:defaultConfigRow

    /** {"Id":62,"Key":"arenatimelimit","value":15} */
    arenatimelimit?:defaultConfigRow

    /** {"Id":63,"Key":"equipdroptime","value":120} */
    equipdroptime?:defaultConfigRow

    /** {"Id":64,"Key":"dustdroptime","value":30} */
    dustdroptime?:defaultConfigRow

    /** {"Id":65,"Key":"taskresetcost","value":50} */
    taskresetcost?:defaultConfigRow

    /** {"Id":66,"Key":"energyspeedup","value":2} */
    energyspeedup?:defaultConfigRow

    /** {"Id":67,"Key":"energyspeedupstop","value":5} */
    energyspeedupstop?:defaultConfigRow

    /** {"Id":68,"Key":"mazebattlenumber","value":"0.15;0.05;1.7;0.2"} */
    mazebattlenumber?:defaultConfigRow

    /** {"Id":69,"Key":"energystartadd","value":550} */
    energystartadd?:defaultConfigRow

    /** {"Id":70,"Key":"energyaddstop","value":28} */
    energyaddstop?:defaultConfigRow

    /** {"Id":71,"Key":"worldbossspend","value":"100;150;200;250;300"} */
    worldbossspend?:defaultConfigRow

    /** {"Id":72,"Key":"challengeticket","value":150} */
    challengeticket?:defaultConfigRow

    /** {"Id":73,"Key":"bloodratio","value":0.01} */
    bloodratio?:defaultConfigRow

    /** {"Id":74,"Key":"zombieposition","value":13} */
    zombieposition?:defaultConfigRow

    /** {"Id":75,"Key":"playerkillzombie","value":"[[10002,200]]"} */
    playerkillzombie?:defaultConfigRow

    /** {"Id":76,"Key":"zombiekillplayer","value":1} */
    zombiekillplayer?:defaultConfigRow

    /** {"Id":77,"Key":"flowerunlock","value":5} */
    flowerunlock?:defaultConfigRow

    /** {"Id":78,"Key":"flowerunlockbuy","value":"300;300;400;400;500;500;800;800;1200;1500"} */
    flowerunlockbuy?:defaultConfigRow

    /** {"Id":79,"Key":"videogift","value":"[[10061,2],[10002,20]]"} */
    videogift?:defaultConfigRow

    /** {"Id":80,"Key":"tryonheroblood","value":100000000} */
    tryonheroblood?:defaultConfigRow

    /** {"Id":81,"Key":"guaranteeepic","value":2} */
    guaranteeepic?:defaultConfigRow

    /** {"Id":82,"Key":"wuzhaungopen","value":"1;5;7"} */
    wuzhaungopen?:defaultConfigRow

    /** {"Id":83,"Key":"jixieopen","value":"2;5;7"} */
    jixieopen?:defaultConfigRow

    /** {"Id":84,"Key":"bianzhongopen","value":"3;6;7"} */
    bianzhongopen?:defaultConfigRow

    /** {"Id":85,"Key":"jiangshiopen","value":"4;6;7"} */
    jiangshiopen?:defaultConfigRow

    /** {"Id":86,"Key":"dungeonhero","value":"100;150;200;250;300"} */
    dungeonhero?:defaultConfigRow

    /** {"Id":87,"Key":"guidemazebattlenumber","value":"0.12;0.04;1.7;0.2"} */
    guidemazebattlenumber?:defaultConfigRow

    /** {"Id":88,"Key":"factiongoldgetnew","value":"63100;6.2242;62.823;15000"} */
    factiongoldgetnew?:defaultConfigRow

    /** {"Id":89,"Key":"pioneertoplimit","value":10} */
    pioneertoplimit?:defaultConfigRow

    /** {"Id":90,"Key":"stagefailtime","value":5} */
    stagefailtime?:defaultConfigRow

    /** {"Id":91,"Key":"heroconversationtime","value":"4;3"} */
    heroconversationtime?:defaultConfigRow

    /** {"Id":92,"Key":"battlecoinhavelimit","value":500000} */
    battlecoinhavelimit?:defaultConfigRow

    /** {"Id":93,"Key":"battlecoinboxnumber","value":10000} */
    battlecoinboxnumber?:defaultConfigRow

    /** {"Id":94,"Key":"normalmonthcardvideo","value":3} */
    normalmonthcardvideo?:defaultConfigRow

    /** {"Id":95,"Key":"arenahighfreetime","value":5} */
    arenahighfreetime?:defaultConfigRow

    /** {"Id":96,"Key":"arenahighprice","value":"450;450;450;600;600;600;900;900;900;1200;1200;1200;1500;1500"} */
    arenahighprice?:defaultConfigRow

    /** {"Id":97,"Key":"arenahighticketnumber","value":3} */
    arenahighticketnumber?:defaultConfigRow

    /** {"Id":98,"Key":"factionwalletnumber","value":30} */
    factionwalletnumber?:defaultConfigRow

    /** {"Id":99,"Key":"battleboxdrop","value":0.03} */
    battleboxdrop?:defaultConfigRow

    /** {"Id":100,"Key":"geniusbegin","value":5} */
    geniusbegin?:defaultConfigRow

    /** {"Id":101,"Key":"videoopen","value":0} */
    videoopen?:defaultConfigRow

    /** {"Id":102,"Key":"artfitchange","value":20} */
    artfitchange?:defaultConfigRow

    /** {"Id":103,"Key":"rechargepopup","value":8} */
    rechargepopup?:defaultConfigRow

    /** {"Id":104,"Key":"arenascoremate","value":1200} */
    arenascoremate?:defaultConfigRow

    /** {"Id":105,"Key":"pioneerpower","value":"7;14;21"} */
    pioneerpower?:defaultConfigRow

    /** {"Id":106,"Key":"dilaoputonglimit","value":60} */
    dilaoputonglimit?:defaultConfigRow

    /** {"Id":107,"Key":"dilaolvlimit","value":30} */
    dilaolvlimit?:defaultConfigRow

    /** {"Id":108,"Key":"genuineunlock","value":10} */
    genuineunlock?:defaultConfigRow

    /** {"Id":109,"Key":"fundover","value":10} */
    fundover?:defaultConfigRow

    /** {"Id":110,"Key":"wheelCounts","value":"100;20"} */
    wheelCounts?:defaultConfigRow

    /** {"Id":111,"Key":"wheelLevel","value":"2;3"} */
    wheelLevel?:defaultConfigRow

    /** {"Id":112,"Key":"wheelTen","value":"0;0"} */
    wheelTen?:defaultConfigRow

    /** {"Id":113,"Key":"wheelTenGift","value":"[[10060,0]]"} */
    wheelTenGift?:defaultConfigRow

    /** {"Id":114,"Key":"wheelShopCurr","value":"10;0"} */
    wheelShopCurr?:defaultConfigRow

    /** {"Id":115,"Key":"wheelRenovate","value":"100;200;400;600;800;1000"} */
    wheelRenovate?:defaultConfigRow

    /** {"Id":116,"Key":"wheelAdvRenovate","value":1000} */
    wheelAdvRenovate?:defaultConfigRow

    /** {"Id":117,"Key":"wheelTenCost","value":"8;10"} */
    wheelTenCost?:defaultConfigRow

    /** {"Id":118,"Key":"dilaounlock","value":6} */
    dilaounlock?:defaultConfigRow

    /** {"Id":119,"Key":"flowernumber1","value":25} */
    flowernumber1?:defaultConfigRow

    /** {"Id":120,"Key":"flowernumber2","value":5} */
    flowernumber2?:defaultConfigRow

    /** {"Id":121,"Key":"WheatheDisplay","value":"1;2;3;4"} */
    WheatheDisplay?:defaultConfigRow

    /** {"Id":122,"Key":"resourcefreetime","value":2} */
    resourcefreetime?:defaultConfigRow

    /** {"Id":123,"Key":"resourcebuytime","value":0} */
    resourcebuytime?:defaultConfigRow

    /** {"Id":124,"Key":"resourcebuyprice","value":"50;100;150;200;250;300;300;300;300;300"} */
    resourcebuyprice?:defaultConfigRow

    /** {"Id":125,"Key":"resourcerecycletime","value":10} */
    resourcerecycletime?:defaultConfigRow

    /** {"Id":126,"Key":"recycleprice","value":20} */
    recycleprice?:defaultConfigRow

    /** {"Id":127,"Key":"niudanrandomnumber","value":6} */
    niudanrandomnumber?:defaultConfigRow

    /** {"Id":128,"Key":"recyclepercent","value":0.3} */
    recyclepercent?:defaultConfigRow

    /** {"Id":129,"Key":"niudandiamond","value":500} */
    niudandiamond?:defaultConfigRow

    /** {"Id":130,"Key":"niudanfloors","value":5} */
    niudanfloors?:defaultConfigRow

    /** {"Id":131,"Key":"namelength","value":200} */
    namelength?:defaultConfigRow

    /** {"Id":132,"Key":"GachaVideoTime","value":120} */
    GachaVideoTime?:defaultConfigRow

    /** {"Id":133,"Key":"gachaprice","value":200} */
    gachaprice?:defaultConfigRow

    /** {"Id":134,"Key":"wheelprice","value":300} */
    wheelprice?:defaultConfigRow

    /** {"Id":135,"Key":"niudanprice","value":500} */
    niudanprice?:defaultConfigRow

    /** {"Id":136,"Key":"gachatenprice","value":1800} */
    gachatenprice?:defaultConfigRow

    /** {"Id":137,"Key":"niudantenprice","value":5000} */
    niudantenprice?:defaultConfigRow

    /** {"Id":138,"Key":"highbattlecoinhavelimit","value":500000} */
    highbattlecoinhavelimit?:defaultConfigRow

    /** {"Id":139,"Key":"highbattlecoinboxnumber","value":10000} */
    highbattlecoinboxnumber?:defaultConfigRow

    /** {"Id":140,"Key":"liketimelimit","value":3} */
    liketimelimit?:defaultConfigRow

    /** {"Id":141,"Key":"likereward","value":"[10001,8000]"} */
    likereward?:defaultConfigRow

    /** {"Id":142,"Key":"monthcardquickprofit","value":6} */
    monthcardquickprofit?:defaultConfigRow

    /** {"Id":143,"Key":"Srherostarlimit","value":0} */
    Srherostarlimit?:defaultConfigRow

    /** {"Id":144,"Key":"smonthcardquickprofit","value":8} */
    smonthcardquickprofit?:defaultConfigRow

    /** {"Id":145,"Key":"dilaoherorank","value":7} */
    dilaoherorank?:defaultConfigRow

    /** {"Id":146,"Key":"battlenumberequip","value":"3.7;0.2;4.6;3.8;3.8;4.8;3;7400;4500;4500;740;7400;2300;2300;3700;370;1500;7400;7400;7400"} */
    battlenumberequip?:defaultConfigRow

    /** {"Id":147,"Key":"battlenumberhero","value":"3.7;0.2;4.6;3.8;3.8;4.8;3;7400;4500;4500;740;7400;2300;2300;3700;370;1500;7400;7400;7400;1.2;1700"} */
    battlenumberhero?:defaultConfigRow

    /** {"Id":148,"Key":"pyygachagive","value":1} */
    pyygachagive?:defaultConfigRow

    /** {"Id":149,"Key":"pyyonceprice","value":20} */
    pyyonceprice?:defaultConfigRow

    /** {"Id":150,"Key":"goldlack","value":"0;29;7"} */
    goldlack?:defaultConfigRow

    /** {"Id":151,"Key":"explack","value":"0;29;7"} */
    explack?:defaultConfigRow

    /** {"Id":152,"Key":"dustlack","value":"8;1;7"} */
    dustlack?:defaultConfigRow

    /** {"Id":153,"Key":"artifactstonelack","value":31} */
    artifactstonelack?:defaultConfigRow

    /** {"Id":154,"Key":"drawlack","value":"8;37"} */
    drawlack?:defaultConfigRow

    /** {"Id":155,"Key":"skybuildbattlenumber","value":1.3} */
    skybuildbattlenumber?:defaultConfigRow

    /** {"Id":156,"Key":"clonefreetime","value":2} */
    clonefreetime?:defaultConfigRow

    /** {"Id":157,"Key":"clonezero","value":2} */
    clonezero?:defaultConfigRow

    /** {"Id":158,"Key":"cloneresetcost","value":"300;400;500;500;500"} */
    cloneresetcost?:defaultConfigRow

    /** {"Id":159,"Key":"cloneresettime","value":3} */
    cloneresettime?:defaultConfigRow

    /** {"Id":160,"Key":"cloneticketlack","value":39} */
    cloneticketlack?:defaultConfigRow

    /** {"Id":161,"Key":"moguhomestar","value":"1;2;3"} */
    moguhomestar?:defaultConfigRow

    /** {"Id":162,"Key":"supplybasictime","value":3} */
    supplybasictime?:defaultConfigRow

    /** {"Id":163,"Key":"supplyresettime","value":1} */
    supplyresettime?:defaultConfigRow

    /** {"Id":164,"Key":"supplyresetprice","value":"300;300;350;350;400;400;400;400;400"} */
    supplyresetprice?:defaultConfigRow

    /** {"Id":165,"Key":"tiliuplimit","value":60} */
    tiliuplimit?:defaultConfigRow

    /** {"Id":166,"Key":"tiliautoadd","value":600} */
    tiliautoadd?:defaultConfigRow

    /** {"Id":167,"Key":"tilibuy","value":60} */
    tilibuy?:defaultConfigRow

    /** {"Id":168,"Key":"tilibuyprice","value":"50;100;150;150;200;200;300;300;300;300;300;300"} */
    tilibuyprice?:defaultConfigRow

    /** {"Id":169,"Key":"tilibuylimit","value":3} */
    tilibuylimit?:defaultConfigRow

    /** {"Id":170,"Key":"normalsupply","value":5} */
    normalsupply?:defaultConfigRow

    /** {"Id":171,"Key":"advancedsupply","value":10} */
    advancedsupply?:defaultConfigRow

    /** {"Id":172,"Key":"supplybasicresetbuytime","value":3} */
    supplybasicresetbuytime?:defaultConfigRow

    /** {"Id":173,"Key":"tupoherolevel","value":20} */
    tupoherolevel?:defaultConfigRow

    /** {"Id":174,"Key":"normalfindtime","value":10} */
    normalfindtime?:defaultConfigRow

    /** {"Id":175,"Key":"equipreborncost","value":20} */
    equipreborncost?:defaultConfigRow

    /** {"Id":176,"Key":"heroreset","value":20} */
    heroreset?:defaultConfigRow

    /** {"Id":177,"Key":"heroresolve","value":200} */
    heroresolve?:defaultConfigRow

    /** {"Id":178,"Key":"wisdomTreeStonereward","value":"0.5;0.5"} */
    wisdomTreeStonereward?:defaultConfigRow

    /** {"Id":179,"Key":"arenarefresh","value":10} */
    arenarefresh?:defaultConfigRow

    /** {"Id":180,"Key":"searchfreetime","value":1} */
    searchfreetime?:defaultConfigRow

    /** {"Id":181,"Key":"factionsearchfreetime","value":1} */
    factionsearchfreetime?:defaultConfigRow

    /** {"Id":182,"Key":"searchtimebuy","value":"50;100;150;200"} */
    searchtimebuy?:defaultConfigRow

    /** {"Id":183,"Key":"searchtimebuylimit","value":0} */
    searchtimebuylimit?:defaultConfigRow

    /** {"Id":184,"Key":"higharenaoriginalscore","value":1000} */
    higharenaoriginalscore?:defaultConfigRow

    /** {"Id":185,"Key":"higharenalowscore","value":500} */
    higharenalowscore?:defaultConfigRow

    /** {"Id":186,"Key":"unionresetprice","value":2000} */
    unionresetprice?:defaultConfigRow

    /** {"Id":187,"Key":"uniontechfreereset","value":1} */
    uniontechfreereset?:defaultConfigRow

    /** {"Id":188,"Key":"bajiaocitimebuy","value":3} */
    bajiaocitimebuy?:defaultConfigRow

    /** {"Id":189,"Key":"bajiaocibuyprice","value":"200;300;400;400;400;400;400"} */
    bajiaocibuyprice?:defaultConfigRow

    /** {"Id":190,"Key":"dujianmutimebuy","value":3} */
    dujianmutimebuy?:defaultConfigRow

    /** {"Id":191,"Key":"dujianmubuyprice","value":"200;300;400;400;400;400;400"} */
    dujianmubuyprice?:defaultConfigRow

    /** {"Id":192,"Key":"ruodianfaction","value":"0.2;0.2;0.2;0.2;0.1;0.1"} */
    ruodianfaction?:defaultConfigRow

    /** {"Id":193,"Key":"Resist","value":0.2} */
    Resist?:defaultConfigRow

    /** {"Id":194,"Key":"atk","value":0.2} */
    atk?:defaultConfigRow

    /** {"Id":195,"Key":"GuildDungeonLimit","value":1} */
    GuildDungeonLimit?:defaultConfigRow

    /** {"Id":196,"Key":"GuildDungeonAttackNum","value":10} */
    GuildDungeonAttackNum?:defaultConfigRow

    /** {"Id":197,"Key":"yunxingless","value":"8;32"} */
    yunxingless?:defaultConfigRow

    /** {"Id":198,"Key":"engineless","value":"1;24;32;42"} */
    engineless?:defaultConfigRow

    /** {"Id":199,"Key":"enginemirroless","value":"24;32;42"} */
    enginemirroless?:defaultConfigRow

    /** {"Id":200,"Key":"factiontechreset","value":1000} */
    factiontechreset?:defaultConfigRow

    /** {"Id":201,"Key":"factionenergylimit","value":20} */
    factionenergylimit?:defaultConfigRow

    /** {"Id":202,"Key":"factionenergycost","value":5} */
    factionenergycost?:defaultConfigRow

    /** {"Id":203,"Key":"factionenergyget","value":10} */
    factionenergyget?:defaultConfigRow

    /** {"Id":204,"Key":"factionenergybuylimit","value":5} */
    factionenergybuylimit?:defaultConfigRow

    /** {"Id":205,"Key":"factionenergybuyprice","value":"100;120;140;160;180;200;220;240;260"} */
    factionenergybuyprice?:defaultConfigRow

    /** {"Id":206,"Key":"factionenergybuynumber","value":10} */
    factionenergybuynumber?:defaultConfigRow

    /** {"Id":207,"Key":"factionhavelimit","value":3} */
    factionhavelimit?:defaultConfigRow

    /** {"Id":208,"Key":"factionjoinlimit","value":1} */
    factionjoinlimit?:defaultConfigRow

    /** {"Id":209,"Key":"factionproducespeed","value":60} */
    factionproducespeed?:defaultConfigRow

    /** {"Id":210,"Key":"factionjoinlimitadd","value":"40;30;20;10;5"} */
    factionjoinlimitadd?:defaultConfigRow

    /** {"Id":211,"Key":"factionbattlespecialbox","value":5} */
    factionbattlespecialbox?:defaultConfigRow

    /** {"Id":212,"Key":"medalless","value":24} */
    medalless?:defaultConfigRow

}={}

for(let r of tableData){
    defaultConfig .push(r);

    defaultConfigMap [r. Key ] =r;

}

export default defaultConfig
