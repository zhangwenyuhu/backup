const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","type","parameter","time","gears","storeId","discount",]

export class timeGiftConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 触发条件类型
         **/
        @SafeProperty
        type?:number

        /**
         * 触发参数
         **/
        @SafeProperty
        parameter?:number

        /**
         * 限时时长(小时)
         **/
        @SafeProperty
        time?:number

        /**
         * 进度
         **/
        @SafeProperty
        gears?:number

        /**
         * 充值项
         **/
        @SafeProperty
        storeId?:number

        /**
         * 显示折扣
         **/
        @SafeProperty
        discount?:number

}

let timeGiftConfig:timeGiftConfigRow []=[];

var rowData=
[
    [1,1,20,2,2,16,0.2],
    [2,1,40,2,2,17,0.2],
    [3,1,60,2,3,18,0.2],
    [4,2,40,2,1,16,0.2],
    [5,2,80,2,2,17,0.2],
    [6,2,120,2,2,17,0.2],
    [7,1,10,2,1,15,0.2],
    [8,1,80,2,4,50,0.2],
    [9,1,100,2,4,50,0.2],
    [10,1,110,2,4,50,0.2],
    [11,1,120,2,4,50,0.2],
    [12,1,130,2,4,50,0.2],
    [13,1,140,2,4,50,0.2],
    [14,1,150,2,4,50,0.2],
    [15,2,160,2,3,18,0.2],
    [16,2,200,2,3,50,0.2],
    [17,2,240,2,3,50,0.2],
    [18,2,280,2,3,50,0.2],
    [19,3,50,2,2,50,0.2],
    [20,3,100,2,3,50,0.2],
    [21,3,130,2,3,50,0.2],
    [22,3,160,2,3,50,0.2],
    [23,4,30,2,4,50,0.2],
    [24,4,60,2,4,50,0.2],
    [25,2,320,2,3,50,0.2],
    [26,2,360,2,3,50,0.2],
    [27,2,400,2,3,50,0.2],
    [28,2,440,2,3,50,0.2],
    [29,2,460,2,4,50,0.2],
    [30,2,500,2,4,50,0.2],
    [31,2,540,2,4,50,0.2],
    [32,2,570,2,4,50,0.2],
    [33,2,604,2,4,50,0.2],
    [34,2,638,2,4,50,0.2],
    [35,2,672,2,4,50,0.2],
    [36,2,706,2,4,50,0.2],
    [37,2,740,2,4,50,0.2],
    [38,2,774,2,4,50,0.2],
    [39,2,808,2,4,50,0.2],
    [40,2,842,2,4,50,0.2],
    [41,2,876,2,4,50,0.2],
    [45,3,190,2,4,50,0.2],
    [46,3,220,2,4,50,0.2],
    [47,3,250,2,4,50,0.2],
    [48,3,280,2,4,50,0.2],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new timeGiftConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    timeGiftConfig .push(r);

}

export default timeGiftConfig
