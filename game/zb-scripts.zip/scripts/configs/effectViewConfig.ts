const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","Path","Anim","MountPoint","Loop","Note","LayerIndex","BuffName","HeroId","AutoHide","Stop","overturn",]

export class effectViewConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 特效路径
         **/
        @SafeProperty
        Path?:string

        /**
         * 特效动画
         **/
        @SafeProperty
        Anim?:string[]

        /**
         * 挂载点
         **/
        @SafeProperty
        MountPoint?:string

        /**
         * 是否循环
         **/
        @SafeProperty
        Loop?:bool

        /**
         * 备注
         **/
        @SafeProperty
        Note?:string

        /**
         * 层级
         **/
        @SafeProperty
        LayerIndex?:number

        /**
         * buff名称
         **/
        @SafeProperty
        BuffName?:string

        /**
         * 针对英雄
         **/
        @SafeProperty
        HeroId?:string

        /**
         * 自动隐藏
         **/
        @SafeProperty
        AutoHide?:bool

        /**
         * 特写时停止
         **/
        @SafeProperty
        Stop?:bool

        /**
         * 是否跟目标单位方向一致
         **/
        @SafeProperty
        overturn?:bool

}

let effectViewConfig:effectViewConfigRow []=[];

var rowData=
[
    [100000,"effect/TieshuOnHit/1002",["1002"],"shouji",false,"普攻受击特效",1,"","",true,true,false],
    [100001,"effect/TieshuSkill1/1003",["skill"],"",false,"金枪地刺",0,"","",true,true,true],
    [100002,"effect/TieshuOnHit/1002",["1002"],"shouji",false,"金枪地刺受击特效",0,"","",true,true,false],
    [100003,"effect/Jiangshi_JiqirenOnhit/1001",["skill"],"shouji",false,"机器人普攻受击特效",0,"","",true,true,false],
    [100004,"effect/ShasengBullet/2001",["skill"],"",true,"沙僧子弹-----废弃",0,"","",true,true,true],
    [100005,"effect/ShasengOnHit/1004",["skill"],"shouji",false,"沙僧受击",0,"","",true,true,true],
    [100006,"effect/ShasengSkill1/1118",["1118"],"shouji",false,"沙僧技能受击",0,"","",true,true,true],
    [100007,"effect/YumiSkill1/1006",["1006"],"",false,"玉米受击",0,"","",true,true,true],
    [100008,"effect/MeiduiOnHit/1010",["skill"],"shouji",false,"美队受击",0,"","",true,true,true],
    [100009,"buff/MeiduiSkill1/3003",["start","loop"],"shouji",true,"美队护盾",0,"护盾","20037",true,true,false],
    [100010,"effect/HuacaiOnHit/1007",["1007"],"shouji",false,"花菜受击",0,"","",true,true,false],
    [100011,"effect/HuacaiSkill1/1008",["1008"],"shouji",false,"花菜受击",0,"","",true,true,false],
    [100012,"buff/HuacaiSkill2/3002",["hudunchuxian","hudun"],"shouji",true,"花菜护盾",0,"护盾","20004",true,true,false],
    [100013,"buff/TieshuPassive1/3001",["skill"],"headbuff",true,"加强吸血等级",0,"加强吸血","",true,true,true],
    [100014,"buff/TieshuPassive1/3001",["skill"],"headbuff",true,"加强吸血",0,"加强吸血","",true,true,true],
    [100015,"effect/DabaiBullet/2002",["2002"],"",false,"大白子弹",0,"","",true,true,true],
    [100016,"effect/DabaiOnHit/1016",["1016"],"shouji",false,"大白受击",0,"","",true,true,true],
    [100017,"buff/DabaiSkill1/3006",["3006"],"",false,"大白治疗",0,"","",true,true,true],
    [100018,"buff/CommonBuff/buff",["meihuo"],"headbuff",true,"大白魅惑",0,"反转阵营","",true,true,true],
    [100019,"effect/LeishenOnHit/1009",["skill"],"shouji",false,"雷神受击",0,"","",true,true,true],
    [100020,"effect/LvdengxiaOnHit/1014",["skill"],"shouji",false,"绿灯侠受击",0,"","",true,true,true],
    [100021,"effect/LvdengxiaPassive1/3003",["start","loop"],"shouji",true,"绿灯侠护盾",0,"","20014",true,true,false],
    [100022,"effect/LvdengxiaSkill1/1013",["skill"],"",false,"绿灯侠受击",0,"","",true,true,true],
    [100023,"buff/LvdengxiaSkill2/3004",["3004_start","3004_loop","3004_end"],"",true,"绿灯侠藤蔓",0,"","",true,true,false],
    [100024,"effect/LongzhongshirenhuaOnHit/1017",["1017"],"shouji",false,"食人花受击",0,"","",true,true,true],
    [100025,"effect/LongzhongshirenhuaSkill/1015",["1015"],"shouji",false,"食人花技能1",0,"","",true,true,true],
    [100026,"effect/HuluoboOnHit/1012",["1012"],"",false,"胡萝卜受击",0,"","",true,true,true],
    [100027,"effect/HuluoboSkill1/1011",["1011"],"",false,"胡萝卜受击",0,"","",true,true,true],
    [100028,"effect/HuluoboSkill2/8001",["8001"],"",false,"胡萝卜受击",0,"","",true,true,true],
    [100029,"buff/BoshiPassive2/3028",["3028"],"shouji",true,"博士睡眠",0,"睡眠","",true,true,true],
    [100030,"effect/BoshiBullet/2003",["2003"],"",true,"博士子弹",0,"","",true,false,true],
    [100031,"effect/BoshiOnHit/1021",["1021"],"shouji",false,"博士受击",0,"","",true,true,true],
    [100032,"effect/BoshiSkill1/4001",["4001"],"",false,"博士技能1",0,"","",true,true,true],
    [100033,"effect/BoshiSkill2/1022",["1022"],"shouji",false,"博士技能2",0,"","",true,true,true],
    [100034,"effect/BoshiSkill2Bullet/2004",["2004"],"",true,"博士技能2子弹",0,"","",true,true,true],
    [100035,"effect/HudiOnHit/1018",["1018"],"shouji",false,"胡迪受击",0,"","",true,true,true],
    [100036,"effect/HudiSkill1/1019",["1019"],"",false,"胡迪技能1",0,"","",true,true,true],
    [100037,"effect/XiangyuantankeOnHit/1023",["1023"],"",false,"香橼受击",0,"","",true,true,true],
    [100038,"effect/XiangyuantankeSkill1/1024",["1024"],"",false,"香橼技能1",0,"","",true,true,true],
    [100039,"effect/XianrenzhangOnHit/1025",["1025"],"shouji",false,"仙人掌受击",0,"","",true,true,false],
    [100040,"effect/XianrenzhangSkill2/1026",["1026"],"shouji",false,"仙人掌技能2",0,"","",true,true,true],
    [100041,"effect/YangcongzhadanOnHit/1027",["1027"],"shouji",false,"洋葱受击",0,"","",true,true,true],
    [100042,"effect/YangtaofashiBullet/2005",["2005"],"",true,"杨桃子弹",0,"","",true,true,false],
    [100043,"effect/YangtaofashiOnHit/1028",["1028"],"shouji",false,"杨桃受击",0,"","",true,true,true],
    [100044,"effect/YangtaofashiSkill/1029",["1029"],"",false,"杨桃技能",0,"","",true,true,true],
    [100045,"effect/ZhusunOnHit/1020",["1020"],"shouji",false,"竹笋受击",0,"","",true,true,true],
    [100046,"effect/ShasengBullet2/2006",["2006"],"",true,"沙僧子弹2",0,"","",true,true,true],
    [100047,"effect/SishiOnHit/1031",["1031"],"shouji",false,"死侍受击",0,"","",true,true,false],
    [100048,"effect/SishiPassive1/1034",["up"],"shouji",false,"死侍被动1",0,"","",true,true,true],
    [100049,"effect/SishiPassive2/1033",["1033"],"shouji",true,"死侍被动2",0,"","",true,true,true],
    [100050,"effect/SishiSkill1/1032",["1032"],"shouji",false,"死侍大招",1,"","",true,true,true],
    [100051,"effect/MeiduiPassive1/1030",["1030"],"shouji",false,"美队护盾",0,"","",true,true,false],
    [100052,"buff/Tongyong_zhiliao/3011",["3011"],"",false,"通用治疗",0,"持续恢复生命","",true,true,true],
    [100053,"effect/YangcongzhadanSkill2/7001",["7001"],"",false,"洋葱瘴气",0,"","",true,true,true],
    [100054,"effect/RenzheguiOnHit/1036",["1036"],"shouji",false,"忍者龟受击",0,"","",true,true,true],
    [100055,"effect/RenzheguiSkill1/1037",["1037"],"shouji",false,"忍者龟技能1",0,"","",true,true,true],
    [100056,"effect/ShenqinvxiaOnHit/1038",["1038"],"shouji",false,"神奇女侠普攻",0,"","",true,true,true],
    [100057,"effect/ShenqinvxiaSkill2/1039",["1039"],"shouji",false,"神奇女侠技能2-1",0,"","",true,true,true],
    [100058,"buff/ShenqinvxiaoSkill2/3012",["3012"],"shouji",true,"神奇女侠技能2-2",0,"","",true,true,true],
    [100059,"effect/ShenqinvxiaSkill2Bullet/2010",["2010"],"",true,"神奇女侠技能2-3",0,"","",true,true,true],
    [100060,"effect/ShenqinvxiaPassive1/1040",["1040_start","1040_loop","1040_end"],"",false,"神奇女侠被动1-1",0,"","",true,true,true],
    [100061,"effect/ShenqinvxiaPassive1Bullet/2009",["2009"],"",true,"神奇女侠被动1-2",0,"","",false,true,true],
    [100062,"effect/ChaorenOnHit/1025",["1025"],"shouji",false,"超人普攻",0,"","",true,true,false],
    [100063,"buff/ChaorenSkill2/3017",["3017_start","3017_loop","3017_end"],"shouji",true,"超人技能2",0,"","",true,true,true],
    [100064,"effect/HaicaoOnHit/1048",["1048"],"shouji",false,"海草普攻1-1",0,"","",true,true,false],
    [100065,"effect/HaicaoBullet1/2013",["2013"],"",true,"海草普攻1-2",0,"","",true,true,true],
    [100066,"effect/HaicaoSkill1/7004",["7004"],"",false,"海草技能1",0,"","",true,true,true],
    [100067,"effect/HaicaoSkill2/1049",["1049"],"shouji",false,"海草技能2-1",0,"","",true,true,true],
    [100068,"effect/HaicaoBullet2/2014",["skill2"],"",false,"海草技能2-2",0,"","",true,true,true],
    [100069,"effect/HaicaoPassive1/3014",["3014"],"",false,"海草技能3",0,"","",true,true,true],
    [100070,"effect/YingshanhongBullet1/2016",["2016"],"",true,"映山红普攻1-1",0,"","",true,true,true],
    [100071,"effect/YingshanhongOnHit/1054",["1054"],"shouji",false,"映山红普攻1-2",0,"","",true,true,false],
    [100072,"effect/YingshanhongSkill1/7005",["7005"],"",false,"映山红技能1",0,"","",true,true,true],
    [100073,"effect/YingshanhongBullet2/2017",["2017"],"",true,"映山红技能2-1",0,"","",true,true,true],
    [100074,"effect/YingshanhongSkill2/1055",["1055"],"shouji",false,"映山红技能2-2",0,"","",true,true,true],
    [100075,"buff/YingshanhongBuff1/3015",["3015"],"",true,"映山红技能2-3",0,"","",true,true,true],
    [100076,"buff/YingshanhongBuff2/3016",["3016"],"shouji",true,"映山红技能3",0,"","",true,true,true],
    [100077,"effect/FanhaixinOnHit/1050",["1050"],"shouji",false,"范海辛普攻1",0,"","",true,true,false],
    [100078,"effect/FanhaixinBullet/2015",["2015"],"",true,"范海辛普攻2",0,"","",true,true,true],
    [100079,"effect/FanhaixinSkill1/1051",["1051"],"headbuff",false,"范海辛技能1",0,"","",true,true,true],
    [100080,"effect/FanhaixinSkill2/1052",["1052"],"shouji",false,"范海辛技能2-1",0,"","",true,true,true],
    [100081,"effect/FanhaixinPassive1/1053",["1053"],"shouji",false,"范海辛技能2-2",0,"","",true,true,true],
    [100082,"effect/JiqimaoSkill1/6001",["6001"],"",false,"机器猫技能1",0,"","",true,true,true],
    [100083,"effect/MiebaOnHit/1056",["attack"],"shouji",false,"灭霸普攻",0,"","",true,true,true],
    [100084,"effect/MiebaSkill1/8002",["8002_start","8002_loop","8002_end"],"root",false,"灭霸技能1",-1,"","",true,true,true],
    [100085,"buff/MiebaSkill2/3018",["skill2"],"shouji",false,"灭霸技能2",0,"","",true,true,true],
    [100086,"effect/ElingqishiSkill1/6002",["skill1"],"",false,"恶灵骑士技能1",0,"","",true,true,true],
    [100087,"buff/ElingqishiPassive1/3019",["3019_loop"],"",true,"恶灵骑士被动1",0,"","",true,true,true],
    [100088,"effect/TieshuSkill1Effect/7006",["7006"],"",false,"铁树技能文件",0,"","",true,true,true],
    [100089,"effect/YumiOnHit/1061",["1061"],"shouji",false,"玉米受击",0,"","",true,true,true],
    [100090,"effect/XiangyuantankeBullet2/2024",["2024"],"",true,"香橼技能2",0,"","",true,true,true],
    [100091,"effect/XiangyuantankeBullet/2018",["2018"],"",true,"香橼技能1子弹",0,"","",true,true,true],
    [100092,"effect/LeishenSkill1/1059",["1059"],"shouji",false,"雷神技能1",0,"","",true,true,true],
    [100093,"buff/CommonBuff/buff",["baoji"],"headbuff",true,"暴击率",0,"暴击率","",true,true,true],
    [100094,"buff/CommonBuff/buff",["chenmo"],"headbuff",true,"禁魔",0,"禁魔","",true,true,true],
    [100095,"buff/CommonBuff/buff",["fangyu","pofang"],"headbuff",true,"防御",0,"防御","",true,true,true],
    [100096,"buff/CommonBuff2/buff2",["gongjilishangsheng","gongjilixiajiang"],"headbuff",true,"加强攻击",0,"加强攻击","",true,true,true],
    [100097,"buff/CommonBuff/buff",["kongju"],"headbuff",true,"恐惧",0,"逃跑","",true,true,true],
    [100098,"buff/CommonBuff2/buff2",["xuanyun"],"headbuff",true,"眩晕",0,"眩晕","",true,true,true],
    [100099,"buff/CommonBuff/buff",["pofang"],"headbuff",true,"易伤",0,"易伤","",true,true,true],
    [100100,"buff/CommonBuff/buff",["xixue"],"headbuff",true,"加强吸血",0,"加强吸血","",true,true,true],
    [100101,"effect/AersasiOnHit/1045",["1045"],"shouji",false,"阿尔萨斯普攻受击",0,"","",true,true,true],
    [100102,"effect/AersasiSkill1/1046",["1046"],"",false,"阿尔萨斯1-1",0,"","",true,true,true],
    [100103,"buff/Tongyong_hudun/3009",["3009"],"",false,"通用护盾",0,"","",true,true,false],
    [100104,"effect/AersasiSkill2/1047",["1047"],"shouji",false,"阿尔萨斯2-1",0,"","",true,true,true],
    [100105,"effect/AersasiBullet/2012",["1045"],"",true,"阿尔萨斯2-2",0,"","",true,true,true],
    [100106,"effect/DegulaBullet/2011",["2011"],"",false,"德古拉弹道",0,"","",true,true,true],
    [100107,"effect/DegulaOnHit/1042",["1042"],"shouji",false,"德古拉普攻受击",0,"","",true,true,true],
    [100108,"effect/DegulaSkill1/7003",["7003_start","7003_loop","7003_end"],"",true,"德古拉技能1",0,"","",true,true,true],
    [100109,"effect/DegulaSkill2/1044",["1044_start","1044_loop","1044_end"],"",true,"德古拉技能2",0,"","",true,true,true],
    [100110,"effect/DegulaPassive1/1043",["1043"],"shouji",false,"德古拉被动受击",0,"","",true,true,true],
    [100111,"effect/GangtiexiaOnHit/1060",["1060"],"shouji",false,"钢铁侠受击",0,"","",true,true,true],
    [100112,"effect/GangtiexiaBullet/2021",["2021"],"",true,"钢铁侠弹道",0,"","",true,true,true],
    [100113,"effect/GaojimoguBullet/2026",["2026"],"",true,"蘑菇弹道",0,"","",true,true,true],
    [100114,"effect/GaojimoguOnHit/1071",["1071"],"shouji",false,"蘑菇受击",0,"","",true,true,true],
    [100115,"effect/GaojimoguSkill1/7007",["7007"],"",false,"蘑菇技能1",0,"","",true,true,true],
    [100116,"effect/GaojimoguSkill2/1072",["1072"],"shouji",false,"蘑菇技能2",0,"","",true,true,true],
    [100117,"effect/GeluteOnHit/1062",["1062"],"shouji",false,"格鲁特普攻受击",0,"","",true,true,true],
    [100118,"effect/GeluteSkill1/1063",["1063"],"shouji",false,"格鲁特1技能受击",0,"","",true,true,true],
    [100119,"buff/GelutePassive2/3020",["3020_start","3020_loop","3020_end"],"shouji",false,"格鲁特被动2",0,"","",true,true,true],
    [100120,"effect/HuimieboshiBullet/2028",["2028"],"",true,"普攻弹道",0,"","",true,true,true],
    [100121,"effect/HuimieboshiOnHit/1076",["1076"],"shouji",false,"普攻受击特效",0,"","",true,true,false],
    [100122,"effect/HuimieboshiSkill1/4003",["4003"],"",false,"毁灭博士技能1",0,"","",true,true,true],
    [100123,"effect/HuimieboshiSkill2_1/6004",["6004_start"],"shouji",false,"毁灭博士技能2-1生成",0,"","",true,true,true],
    [100124,"effect/HuimieboshiSkill2_2/6004",["6004_loop"],"shouji",true,"毁灭博士技能2-2循环",0,"","",true,true,true],
    [100125,"effect/HuimieboshiSkill2_3/6004",["6004_end"],"shouji",false,"毁灭博士技能2-3消失",0,"","",true,true,true],
    [100126,"effect/HuimieboshiPassive1/1078",["1078"],"",false,"毁灭博士被动1",0,"","",true,true,true],
    [100127,"buff/HuimieboshiPassive2/3023",["3023"],"",false,"毁灭博士被动2",0,"","",true,true,true],
    [100128,"effect/LabahuaOnHit1/1064",["1064"],"shouji",false,"喇叭花加血",0,"","",true,true,true],
    [100129,"effect/LabahuaOnHit2/1065",["1065"],"shouji",false,"喇叭花攻击伤害",0,"","",true,true,true],
    [100130,"effect/LabahuaSkill1/1066",["1066"],"shouji",false,"喇叭花技能1",0,"","",true,true,true],
    [100131,"effect/LabahuaSkill2/1067",["1067"],"shouji",false,"喇叭花技能2",0,"","",true,true,true],
    [100132,"effect/LabahuaBullet/2023",["2023_gonji_1"],"",true,"喇叭花弹道攻击",0,"","",true,true,true],
    [1001321,"effect/LabahuaBullet/2023",["2023_zhiliao_1"],"",true,"喇叭花弹道治疗",0,"","",true,true,true],
    [100133,"effect/LanboOnHit/1035",["1035"],"shouji",false,"兰博shouji",0,"","",true,true,true],
    [100134,"effect/LanboOnHitBullet/2007",["2007"],"",true,"兰博弹道",0,"","",true,true,true],
    [100135,"effect/LanboSkill1Bullet/2008",["2008"],"",false,"兰博技能1",0,"","",true,true,true],
    [100136,"effect/LanboSkill2/7002",["7002"],"",false,"兰博技能2",0,"","",true,true,false],
    [100137,"effect/ZhizhuxiaBullet/2027",["2027"],"",true,"蜘蛛侠弹道",0,"","",true,true,true],
    [100138,"effect/ZhizhuxiaOnHit/1073",["1073"],"shouji",false,"蜘蛛侠普攻shouji",0,"","",true,true,true],
    [100139,"effect/ZhizhuxiaSkill1_1/1074",["1074"],"shouji",false,"蜘蛛侠技能1受击1",0,"","",true,true,true],
    [100140,"effect/ZhizhuxiaSkill1_2/1075",["1075"],"shouji",false,"蜘蛛侠技能1受击2",0,"","",true,true,true],
    [100141,"buff/ZhizhuxiaPassive1Buff1/3021",["3021"],"shouji",true,"蜘蛛侠被动毒烟",0,"","",true,true,true],
    [100142,"buff/ZhizhuxiaPassive1Buff2/3022",["1036"],"",false,"蜘蛛侠被动爆炸",0,"","",true,true,true],
    [100143,"effect/ZhizhuxiaPassive1/6003",["6003"],"",false,"蜘蛛茧",0,"","",true,true,true],
    [100144,"effect/ShirenhuaSkill1/1068",["skill1"],"",false,"食人花技能1",0,"","",true,true,true],
    [100145,"effect/ShirenhuaSkill2/1069",["1069"],"shouji",false,"食人花技能2",0,"","",true,true,true],
    [100146,"effect/ShirenhuaPassive1/1070",["1070"],"shouji",false,"食人花被动",0,"","",true,true,true],
    [100147,"effect/ShirenhuaBullet/2025",["2025"],"",false,"食人花灵魂",0,"","",true,true,true],
    [100148,"effect/XiaochouBullet/2019",["2019"],"",true,"小丑弹道",0,"","",true,true,true],
    [100149,"effect/XiaochouOnHit/1057",["1057"],"shouji",false,"小丑普攻受击",0,"","",true,true,true],
    [100150,"effect/XiaochouSkill1/4002",["4002"],"",false,"小丑技能1",0,"","",true,true,true],
    [100151,"effect/XiaochouSkill2Bullet/2020",["2020"],"",true,"小丑技能2火球",0,"","",true,true,true],
    [100152,"effect/XiaochouSkill2/1058",["1058"],"shouji",false,"小丑技能2受击",0,"","",true,true,true],
    [100153,"effect/LanboSkill1/1041",["skill1"],"shouji",false,"兰博技能1",0,"","",true,true,true],
    [100154,"buff/XiaochouPassive1/3024",["3024"],"shouji",true,"小丑被动1护盾",0,"护盾","20032",true,true,false],
    [100155,"buff/LvdengxiaPassive1/3008",["3008"],"",false,"绿灯侠被动",0,"","",true,true,true],
    [100156,"effect/ElingqishiOnHit/1014",["skill"],"shouji",false,"恶灵骑士普攻受击",0,"","",true,true,true],
    [100157,"buff/ElingqishiPassive1/3019",["3019_start"],"shouji",false,"恶灵骑士护盾开始",0,"","",true,true,true],
    [100158,"buff/ElingqishiPassive1/3019",["3019_loop"],"shouji",true,"恶灵骑士护盾循环",0,"护盾","20006",true,true,true],
    [100159,"buff/ElingqishiPassive1/3019",["3019_end"],"shouji",false,"恶灵骑士护盾结束",0,"","",true,true,true],
    [100160,"effect/DujianmuSkill1/3025",["3025"],"shouji",true,"毒箭木受击",0,"","",true,true,false],
    [100161,"effect/ZhizhuxiaSkill2/7008",["7008"],"",false,"蜘蛛侠2技能",0,"","",true,true,true],
    [100162,"buff/CommonBuff2/buff2",["wudi"],"headbuff",true,"无敌",0,"无敌","",true,true,true],
    [100163,"buff/CommonBuff/buff",["chenmo"],"headbuff",true,"限制技能",0,"限制技能","",true,true,true],
    [100164,"buff/CommonBuff2/buff2",["wufashanbi"],"headbuff",true,"无法闪避",0,"","",true,true,true],
    [100165,"buff/CommonBuff2/buff2","","headbuff",true,"无法移动",0,"","",true,true,true],
    [100166,"buff/CommonBuff2/buff2",["zhongdu"],"headbuff",true,"中毒",0,"中毒","",true,true,true],
    [100167,"effect/ChaorenSkill/4004",["4004"],"",false,"超人大招",0,"","",true,true,true],
    [100168,"buff/ZhongjiezheSkill1/3026",["3026"],"shouji",false,"终结者1技能",0,"","",true,true,false],
    [100169,"effect/ShenqinvxiaSkill1/1079",["1079"],"shouji",false,"神奇女侠1技能受击",0,"","",true,true,true],
    [100170,"buff/GangtiexiaPassive1/3027",["3027"],"shouji",true,"钢铁侠被动1",0,"","",true,true,true],
    [100171,"effect/Jinengshifang/jinengshifang",["jinengshifang"],"shouji",false,"技能释放",0,"","",true,true,false],
    [100172,"effect/JichujiangshiOnHit/1080",["1080"],"shouji",false,"僵尸受击",0,"","",true,true,true],
    [100173,"effect/YumiBullet/2029",["2029"],"",true,"玉米弹道",0,"","",true,true,false],
    [100174,"buff/CommonBuff2/buff2",["gongjilixiajiang"],"headbuff",true,"攻击下降",0,"降低攻击","",true,true,false],
    [100175,"effect/ZhizhuxiaSkill1_01/6007",["6007"],"",false,"蜘蛛侠技能1-1",0,"","",true,true,true],
    [100176,"effect/ZhizhuxiaSkill1_02/6008",["6008"],"",false,"蜘蛛侠技能1-2",0,"","",true,true,true],
    [100177,"effect/ZhizhuxiaSkill1_03/6009",["6009"],"",false,"蜘蛛侠技能1-3",0,"","",true,true,true],
    [100178,"effect/ZhizhuxiaSkill1_04/6010",["6010"],"",false,"蜘蛛侠技能1-4",0,"","",true,true,true],
    [100179,"effect/ZhizhuxiaSkill1_05/6011",["6011"],"",false,"蜘蛛侠技能1-5",0,"","",true,true,true],
    [100180,"effect/jiqimaoSkill1_1/6012",["6012"],"",false,"机器猫大招",0,"","",true,true,true],
    [100181,"effect/Gangtiexiaskill1bullet/2030",["2030"],"shouji",false,"钢铁侠大招喷射",0,"","",true,true,true],
    [100182,"effect/Chaorenskill1Onhit/1081",["1081"],"",false,"超人大招受击",0,"","",true,true,true],
    [100183,"effect/DajiangshiPassive/3029",["3029"],"shouji",true,"大僵尸护盾",0,"","20043",true,true,true],
    [100184,"effect/JiefeiOnHit/2007",["2007"],"",false,"劫匪僵尸受击",0,"","",true,true,true],
    [100185,"effect/JiefeiSkill1OnHit/1082",["1082"],"shouji",false,"劫匪僵尸1技能受击",0,"","",true,true,true],
    [100186,"effect/JiefeiSkill1Bullet/2031",["2031"],"",true,"劫匪僵尸1技能子弹",0,"","",true,true,true],
    [100187,"effect/JiefeiSkill2OnHit/1083",["1083"],"shouji",false,"劫匪僵尸2技能受击",0,"","",true,true,true],
    [100188,"effect/JinmaoshiwangOnHit/1084",["1084"],"shouji",false,"金毛狮王普攻与技能受击",0,"","",true,true,true],
    [100189,"effect/JinganglangOnHit/1085",["1085"],"shouji",false,"金刚狼受击",0,"","",true,true,true],
    [100190,"effect/LinkeOnHit/1086",["1086"],"shouji",false,"林克受击",0,"","",true,true,true],
    [100191,"effect/ShenQiHudun/SQ-jkdlp",["animation2"],"shouji",true,"神器护盾",0,"神器护盾类","",true,true,true],
    [100192,"effect/ShenQiChongjibo/SQ-yzmf",["animation1"],"",false,"神器冲击波",0,"","",true,true,true],
    [100193,"effect/AnYeNvWangBullet/2042",["2042"],"",true,"暗夜女王弹道",0,"","",true,true,true],
    [100194,"effect/AnYeNvWangOnHit/1107",["1107"],"shouji",false,"暗夜女王普攻受击",0,"","",true,true,true],
    [100195,"effect/AnYeNvWangSkill1/7009",["7009"],"",false,"暗夜女王大招",0,"","",true,true,true],
    [100196,"effect/AnYeNvWangSkill3OnHit/1108",["1108"],"shouji",false,"暗夜女王3技能受击",0,"","",true,true,true],
    [100197,"effect/AnYeNvWangSkill4/2043",["2043"],"",true,"暗夜女王蝙蝠子弹",0,"","",true,true,true],
    [100198,"effect/HaliboteBullet1/2034",["2034"],"",true,"哈利波特普攻弹道",0,"","",true,true,true],
    [100199,"effect/HaliboteSkillOnhit/1090",["1090"],"shouji",false,"哈利波特普攻受击",0,"","",true,true,true],
    [100200,"effect/HaliboteSkill2/6014",["6014"],"",false,"哈利波特2技能召唤",0,"","",true,true,true],
    [100201,"effect/HaliboteSkill3/6013",["6013"],"",false,"哈利波特3技能技能召唤",0,"","",true,true,true],
    [100202,"effect/DandingOnhit/1095",["1095"],"shouji",false,"但丁普攻受击",0,"","",true,true,true],
    [100203,"effect/DandingSkill1Onhit/1096",["1096"],"shouji",false,"但丁大招受击",0,"","",true,true,true],
    [100204,"effect/DandingSkill2Bullet/2036",["2036"],"",true,"但丁2技能子弹",0,"","",true,true,true],
    [100205,"effect/DandingSkill2Onhit/1097",["1097"],"shouji",false,"但丁2技能受击",0,"","",true,true,true],
    [100206,"effect/DandingSkill2Zhaohuan/2037",["2037"],"shouji",true,"但丁二技能召唤闪电球",0,"恶灵","",true,true,true],
    [100207,"effect/KuituosiOnhit/1098",["1098"],"shouji",false,"奎托斯普攻/大招受击",0,"","",true,true,true],
    [100208,"effect/KuituosiBullet/2038",["2038"],"",true,"奎托斯鞭子",0,"","",true,true,true],
    [100209,"effect/KuituosiOnhit2/1099",["1099"],"shouji",false,"奎托斯2技能受击",0,"","",true,true,true],
    [100210,"effect/KuituosiPassive1/3033",["3033"],"shouji",true,"奎托斯4技能丢能",0,"","",true,true,true],
    [100211,"effect/YumiNewOnhit/1111",["1111"],"shouji",false,"玉米受击",0,"","",true,true,true],
    [100212,"effect/YumiNewSkill1/8005",["8005"],"",false,"玉米大招受击",0,"","",true,true,true],
    [100213,"effect/YinhezhanshiBullet1/2039",["2039"],"",true,"银河战士变身普攻子弹",0,"","",true,true,true],
    [100214,"effect/YinhezhanshiOnhit/1100",["1100"],"shouji",false,"银河战士变身普攻受击",0,"","",true,true,true],
    [100215,"effect/YinhezhanshiSkill1/2040",["2040"],"zidan",false,"银河战士1技能瞄准",0,"","",true,true,true],
    [100216,"effect/YinhezhanshiSkill1Bullet/2041",["2041"],"",true,"银河战士1技能子弹",0,"","",true,true,true],
    [100217,"effect/YinhezhanshiSkill2/8003",["8003"],"",true,"银河战士2技能脚底",-1,"","",true,true,true],
    [100219,"buff/MeiduiSkill1/3003",["start","loop"],"shouji",true,"银河战士被动1",0,"护盾","20052",true,true,true],
    [100220,"effect/HaiwangOnhit/1101",["1101"],"shouji",false,"海王普攻受击",0,"","",true,true,true],
    [100221,"effect/HaiwangSkill1/8004",["8004"],"",false,"海王大招",0,"","",true,true,true],
    [100222,"effect/HaiwangSkill2/1103",["1103"],"",false,"海王2技能水",0,"","",true,true,true],
    [100223,"effect/HaiwangPassive1/1102",["1102"],"shouji",false,"海王被动1受击",0,"","",true,true,true],
    [100224,"effect/HaiwangPassive2/3036",["3036"],"",false,"海王被动2",0,"","",true,true,true],
    [100225,"effect/HaiwangPassive/3040",["3040"],"shouji",false,"海王被动变身",0,"","",true,true,true],
    [100226,"effect/LeimuSkill1/3032",["3032"],"",false,"蕾姆大招",0,"","",true,true,true],
    [100227,"effect/LeimuSkill2Bullet/2035",["2035"],"",false,"蕾姆技能2茶壶废弃",0,"","",true,true,true],
    [100228,"effect/LeimuSkill2Onhit/1092",["1092"],"shouji",false,"蕾姆技能2受击",0,"","",true,true,true],
    [100229,"effect/LeimuOnhit/1091",["1091"],"shouji",false,"蕾姆普攻受击",0,"","",true,true,true],
    [100230,"effect/LeimuSkill2Bullet01/2035",["2035"],"",false,"蕾姆一个茶壶 一个茶杯",0,"","",true,true,true],
    [100231,"effect/LeimuSkill2Bullet02/2044",["2044"],"",false,"蕾姆一个茶壶 两个茶杯",0,"","",true,true,true],
    [100232,"effect/LeimuSkill2Bullet03/2045",["2045"],"",false,"一个茶壶 两个茶杯 1个叉子",0,"","",true,true,true],
    [100233,"effect/LeimuSkill2Bullet04/2046",["2046"],"",false,"一个茶壶 两个茶杯 一个碟子",0,"","",true,true,true],
    [100234,"effect/YinhezhanshiSkill2jiaodi/3042",["3042_start","3042_loop","3042_end"],"shouji",true,"银河战士脚底石油",0,"石油缠绕","",true,true,true],
    [100235,"buff/CommonBuff2/buff2",["zhongdu"],"headbuff",true,"中毒",0,"蜘蛛侠中毒","",true,true,true],
    [100236,"effect/SaiyarenOnhit/1113",["1113"],"shouji",false,"赛亚人普攻受击",0,"","",true,true,true],
    [100237,"effect/SaiyarenSkill1/3041",["3041"],"shouji",true,"赛亚人大招变身buff",0,"","",true,true,true],
    [100238,"effect/SaiyarenSkill2Bullet/2047",["2047"],"",true,"赛亚人二技能子弹",0,"","",true,true,true],
    [100239,"effect/SaiyarenBigSkill2Bullet/2048",["2048"],"",true,"变身赛亚人二技能子弹",0,"","",true,true,true],
    [100240,"effect/SaiyarenSkill2Onhit/1114",["1114"],"shouji",false,"赛亚人二技能受击",0,"","",true,true,true],
    [100241,"effect/SaiyarenBigSkill2Onhit/1115",["1115"],"shouji",false,"变身赛亚人二技能受击",0,"","",true,true,true],
    [100242,"effect/MingrenOnhit/1093",["1093"],"shouji",false,"鸣人普攻受击",0,"","",true,true,true],
    [100243,"effect/MingrenSkill1skill2/6015",["6015"],"",false,"鸣人1/2技能爆炸",0,"","",true,true,true],
    [100244,"effect/MingrenPassive1/1094",["1094"],"shouji",false,"鸣人被动1爆炸",0,"","",true,true,true],
    [100245,"effect/Tongyonghudun/3009",["3009"],"shouji",true,"通用护盾",0,"护盾","",true,true,true],
    [100246,"effect/Artifact02/6016",["6016"],"",false,"石中剑",0,"","",true,true,true],
    [100247,"effect/Artifact03/6017",["6017"],"",false,"风暴战斧",0,"","",true,true,true],
    [100248,"effect/Artifact04/6018",["6018_start","6018_loop","6018_end"],"",false,"杰克轮盘",0,"","",true,true,true],
    [100249,"effect/Artifact05/6019",["6019_start"],"",false,"死海文书出现",0,"","",true,true,true],
    [100250,"effect/Artifact06/6020",["6020_start","6020_loop","6020_end"],"headbuff",false,"魔戒",0,"","",true,true,true],
    [100251,"effect/Artifact07/6021",["6021_start","6021_loop","6021_end"],"",false,"法老面具",0,"","",true,true,true],
    [100252,"effect/Artifact01/6022",["6022"],"",false,"灭霸手套",0,"","",true,true,true],
    [100253,"effect/Artifact01Onhit/1116",["1116"],"shouji",false,"灭霸手套受击",0,"","",true,true,true],
    [100254,"effect/Artifact05/6019",["6019_loop"],"",false,"死海文书循环",-1,"","",true,true,true],
    [100255,"effect/Artifact05/6019",["6019_end"],"",false,"死海文书消失",-1,"","",true,true,true],
    [100256,"effect/Artifact01High/6023",["6023"],"",false,"灭霸高级特效",0,"","",true,true,true],
    [100257,"effect/Artifact01OnhitHigh/1117",["1117"],"shouji",false,"灭霸高级shouji",0,"","",true,true,true],
    [100258,"effect/feijijiangshi01/2049",["2049"],"",true,"飞机僵尸导弹",0,"","",true,true,true],
    [100259,"effect/feijijiangshi02/7010",["7010"],"",false,"飞机僵尸导弹受击特效",0,"","",true,true,true],
    [100260,"effect/feijijiangshi03/7011",["7011"],"",false,"飞机僵尸回血",0,"","",true,true,true],
    [100261,"effect/feijijiangshi04/2050",["2050"],"",true,"飞机僵尸治疗包",0,"","",true,true,true],
    [100262,"effect/BanzangOnHit/1109",["1109"],"shouji",false,"半藏普攻和被动2受击",0,"","",true,true,true],
    [100263,"effect/BanzangSkill1OnHit/1110",["1110"],"shouji",false,"半藏技能1和被动1受击",0,"","",true,true,true],
    [100264,"effect/Banzangskill2/3039",["3039"],"shouji",true,"半藏技能2护盾",0,"护盾","20054",true,true,true],
    [100265,"effect/shasengbullettouming/2999",["2999"],"",true,"沙僧透明子弹",0,"","",true,true,true],
    [100266,"effect/AerteliusiOnhit/1104",["1104"],"shouji",false,"阿尔特留斯普攻受击",0,"","",true,true,true],
    [100267,"effect/AerteliusiSkill1Onhit/1105",["1105"],"shouji",false,"阿尔特留斯受击",0,"","",true,true,true],
    [100268,"effect/AerteliusiOnhit2/1106",["1106"],"shouji",false,"阿尔特留斯刺受击",0,"","",true,true,true],
    [100269,"effect/AerteliusiPassive2/3037",["3037"],"shouji",false,"阿尔特留斯被动",0,"阿尔特留斯强化","",true,true,true],
    [100270,"effect/DuomamuBullet/2050",["2050"],"",true,"多玛姆普攻子弹",0,"","",true,true,true],
    [100271,"effect/DuomamuOnhit01/1119",["1119"],"shouji",false,"多玛姆普攻受击",0,"","",true,true,true],
    [100272,"effect/DuomamuPassive2/4006",["start","loop","finish"],"shouji",true,"多玛姆被动2",0,"","",true,true,true],
    [100273,"effect/DuomamuSkill1Bullet1/2051",["2051"],"",true,"多玛姆大招子弹1",0,"","",true,true,true],
    [100274,"effect/DuomamuSkill1Bullet2/2052",["2052"],"",true,"多玛姆大招子弹2",0,"","",true,true,true],
    [100275,"effect/DuomamuSkill1Onhit1/1120",["1120"],"shouji",false,"多玛姆大招受击1",0,"","",true,true,true],
    [100276,"effect/DuomamuSkill1Onhit2/1121",["1121"],"shouji",false,"多玛姆大招受击2",0,"","",true,true,true],
    [100277,"effect/DuomamuSkill1Bullet3/2053",["2053"],"",true,"分裂子弹，受击用1120",0,"","",true,true,true],
    [100278,"effect/DuomamuPassive1/3037",["3037"],"shouji",true,"多玛姆被动1",0,"","",true,true,true],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new effectViewConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    effectViewConfig .push(r);

}

export default effectViewConfig
