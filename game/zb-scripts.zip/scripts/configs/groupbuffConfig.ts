const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","des","groupby","devilnum","atkadd","hpadd","defadd","energyrecoveradd","critadd","critharmadd","skillspeedadd",]

export class groupbuffConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        Id?:uid

        /**
         * 描述
         **/
        @SafeProperty
        des?:string

        /**
         * 同种族英雄分组
傅圣杰:
(队伍中英雄按照种族进行分组统计并降序排列,结果排除1）
半神在统计时排除，统计结果中加在数组第一位。
恶魔在统计时排除。以下buff同时激活时可叠加
         **/
        @SafeProperty
        groupby?:number[]

        /**
         * 恶魔英雄统计数量（大于等于）
         **/
        @SafeProperty
        devilnum?:number

        /**
         * 攻击加成
         **/
        @SafeProperty
        atkadd?:number

        /**
         * 生命加成
         **/
        @SafeProperty
        hpadd?:number

        /**
         * 防御加成
         **/
        @SafeProperty
        defadd?:number

        /**
         * 受伤回能
         **/
        @SafeProperty
        energyrecoveradd?:number

        /**
         * 暴击
         **/
        @SafeProperty
        critadd?:number

        /**
         * 暴击伤害
         **/
        @SafeProperty
        critharmadd?:number

        /**
         * 急速
         **/
        @SafeProperty
        skillspeedadd?:number

}

let groupbuffConfig:groupbuffConfigRow []=[];

var rowData=
[
    [1,"上阵同联盟的3名英雄可以激活",[3],0,0,0],
    [2,"上阵同联盟的3名英雄和另一联盟的2名英雄可以激活",[3,2],0,0,0],
    [3,"上阵同联盟的4名英雄可以激活",[4],0,0,0],
    [4,"上阵同联盟的5名英雄可以激活",[5],0,0,0],
    [5,"恶魔buff1",[],1,0,0,0],
    [6,"恶魔buff2",[],2,0,0,0,0],
    [7,"恶魔buff3",[],3,0,0,0,0,0],
    [8,"恶魔buff4",[],4,0,0,0,0,0,0],
    [9,"恶魔buff5",[],5,0,0,0,0,0,0,0],
    [10,"上阵不同联盟的5名英雄可以激活",[],0,0,0],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new groupbuffConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    groupbuffConfig .push(r);

}

export default groupbuffConfig
