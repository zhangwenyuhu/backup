const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","EqOutfitID","EqOutfitName","EqOutfit2","EqOutfit3","EqOutfit4",]

export class equipoutfitConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 装备套装ID
         **/
        @SafeProperty
        EqOutfitID?:number

        /**
         * 套装名字
         **/
        @SafeProperty
        EqOutfitName?:any

        /**
         * 2件套加成(属性类型，数值）
         **/
        @SafeProperty
        EqOutfit2?:any

        /**
         * 3件套加成
         **/
        @SafeProperty
        EqOutfit3?:any

        /**
         * 4件套加成
         **/
        @SafeProperty
        EqOutfit4?:any

}

let equipoutfitConfig:equipoutfitConfigRow []=[];

var rowData=
[
    [1,1,"星辉",[[2,0.02]],[[4,0.02]],[[2,0.04],[4,0.04],[21,0.1]]],
    [2,2,"月华",[[2,0.03]],[[4,0.03]],[[2,0.05],[4,0.05],[21,0.12]]],
    [3,3,"日曜",[[2,0.04]],[[4,0.04]],[[2,0.06],[4,0.06],[21,0.15]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new equipoutfitConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    equipoutfitConfig .push(r);

}

export default equipoutfitConfig
