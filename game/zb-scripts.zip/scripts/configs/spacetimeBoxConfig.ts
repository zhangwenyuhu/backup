const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","BoxID","BoxType","Reward",]

export class spacetimeBoxConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 宝箱ID
         **/
        @SafeProperty
        BoxID?:number

        /**
         * 宝箱类型
         **/
        @SafeProperty
        BoxType?:number

        /**
         * 奖励内容
         **/
        @SafeProperty
        Reward?:any

}

let spacetimeBoxConfig:spacetimeBoxConfigRow []=[];

var rowData=
[
    [1,1,1,[10001,100]],
    [2,2,1,[10001,150]],
    [3,3,1,[10001,500]],
    [4,4,2,[10002,100]],
    [5,5,2,[10002,200]],
    [6,6,2,[10002,300]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new spacetimeBoxConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    spacetimeBoxConfig .push(r);

}

export default spacetimeBoxConfig
