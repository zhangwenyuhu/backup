const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","circlerank","reward",]

export class circlerankconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 排名
         **/
        @SafeProperty
        circlerank?:any

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:any

}

let circlerankconfig:circlerankconfigRow []=[];

var rowData=
[
    [1,[1,1],[[10530,1],[10521,120],[10493,100]]],
    [2,[2,2],[[10554,1],[10521,60],[10493,50]]],
    [3,[3,3],[[10555,1],[10521,40],[10493,30]]],
    [4,[4,10],[[10521,20],[10493,20]]],
    [5,[11,20],[[10521,15],[10493,10]]],
    [6,[21,50],[[10521,10],[10493,5]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new circlerankconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    circlerankconfig .push(r);

}

export default circlerankconfig
