const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","ranking","scoreadd",]

export class ArenahighestrankconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 王者名次
         **/
        @SafeProperty
        ranking?:number

        /**
         * 积分增长率（小时）
         **/
        @SafeProperty
        scoreadd?:number

}

let Arenahighestrankconfig:ArenahighestrankconfigRow []=[];

var rowData=
[
    [1,1,100],
    [2,2,100],
    [3,3,100],
    [4,4,100],
    [5,5,100],
    [6,6,100],
    [7,7,100],
    [8,8,100],
    [9,9,100],
    [10,10,100],
    [11,11,100],
    [12,12,100],
    [13,13,100],
    [14,14,100],
    [15,15,100],
    [16,16,100],
    [17,17,100],
    [18,18,100],
    [19,19,100],
    [20,20,100],
    [21,21,100],
    [22,22,100],
    [23,23,100],
    [24,24,100],
    [25,25,100],
    [26,26,100],
    [27,27,100],
    [28,28,100],
    [29,29,100],
    [30,30,100],
    [31,31,100],
    [32,32,100],
    [33,33,100],
    [34,34,100],
    [35,35,100],
    [36,36,100],
    [37,37,100],
    [38,38,100],
    [39,39,100],
    [40,40,100],
    [41,41,100],
    [42,42,100],
    [43,43,100],
    [44,44,100],
    [45,45,100],
    [46,46,100],
    [47,47,100],
    [48,48,100],
    [49,49,100],
    [50,50,100],
    [51,51,100],
    [52,52,100],
    [53,53,100],
    [54,54,100],
    [55,55,100],
    [56,56,100],
    [57,57,100],
    [58,58,100],
    [59,59,100],
    [60,60,100],
    [61,61,100],
    [62,62,100],
    [63,63,100],
    [64,64,100],
    [65,65,100],
    [66,66,100],
    [67,67,100],
    [68,68,100],
    [69,69,100],
    [70,70,100],
    [71,71,100],
    [72,72,100],
    [73,73,100],
    [74,74,100],
    [75,75,100],
    [76,76,100],
    [77,77,100],
    [78,78,100],
    [79,79,100],
    [80,80,100],
    [81,81,100],
    [82,82,100],
    [83,83,100],
    [84,84,100],
    [85,85,100],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new ArenahighestrankconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    Arenahighestrankconfig .push(r);

}

export default Arenahighestrankconfig
