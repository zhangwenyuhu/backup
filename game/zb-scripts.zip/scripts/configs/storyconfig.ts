const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","stage","dialogue","hero","where","offsitey",]

export class storyconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 关卡ID
         **/
        @SafeProperty
        stage?:number

        /**
         * 对话
         **/
        @SafeProperty
        dialogue?:string

        /**
         * 对话英雄
         **/
        @SafeProperty
        hero?:string

        /**
         * 对话类型
zhangchenxue:
0：战斗开始
1：战斗结束
2：地牢
         **/
        @SafeProperty
        where?:number

        /**
         * 坐标偏移
         **/
        @SafeProperty
        offsitey?:number

}

let storyconfig:storyconfigRow []=[];

var rowData=
[
    [1,10,"<b><color=#000000>这僵尸数量丝毫不见变少！回头神器没找到，咱哥几个命搭进去了…</c><b>","guide_yumi",0,500],
    [2,10,"<b><color=#000000>我们没有回头路！既然选择了，就要走下去！</c><b>","guide_haicao",0,500],
    [3,10,"<b><color=#000000>成！回头这票干成了，超级英雄里也能加上俺老棒菜的名儿</c><b>","guide_yumi",0,500],
    [4,10,"<b><color=#000000>前面的路凶险着呢！先别想这些美事！</c><b>","guide_haicao",0,500],
    [5,12,"<b><color=#000000>这！这是什么鬼！</c><b>","guide_yumi",0,500],
    [6,12,"<b><color=#000000>怎么又来一个！全都是冲着神器来的，怎么办！</c><b>","guide_haicao",0,500],
    [7,12,"<b><color=#000000>咦嘿嘿！我会怕？</c><b>","guide_xiaochou",0,500],
    [8,13,"<b><color=#000000>丑爷！你听！这教堂有人喊救命</c><b>","guide_yumi",0,500],
    [9,13,"<b><color=#000000>愣着干什么！救人要紧！</c><b>","guide_xiaochou",0,500],
    [10,15,"<b><color=#000000>你们感受到没？一种奇怪的能量，亦正亦邪？</c><b>","guide_haicao",0,500],
    [11,15,"<b><color=#000000>海草！你不老实嗷！咋还开始嘲讽咱丑爷了呢！</c><b>","guide_haicao",0,500],
    [12,15,"<b><color=#000000>...</c><b>","guide_yumi",0,500],
    [13,16,"<b><color=#000000>*#&￥%%！&肉！*#&￥￥&神器@*@！</c><b>","guide_leishen",0,500],
    [14,16,"<b><color=#000000>我说什么来着！？原来那股亦正亦邪的能量竟然是…他</c><b>","guide_haicao",0,500],
    [15,16,"<b><color=#000000>啧啧…真应该给你这流口水的样子拍下来！真是丢人丢到家了</c><b>","guide_xiaochou",0,500],
    [16,16,"<b><color=#000000>我…这是怎么了…本来，我是想去教堂调查神器的踪迹。</c><b>","guide_leishen",1,500],
    [17,16,"<b><color=#000000>结果，进来后，一尊法老巨像“噌”的窜出来，盯着我！后来...我便丧失了意识</c><b>","guide_leishen",1,500],
    [18,16,"<b><color=#000000>又是神器，应该就在这附近…我们要迅速！不然会有更多人遇害。</c><b>","guide_haicao",1,500],
    [19,5,"<b><color=#000000>哎妈呀！钢铁侠咋都被b毒影响成这样儿了呢！</c><b>","guide_yumi",0,500],
    [20,5,"<b><color=#000000>再也听不到那句“我爱你三千遍了！”</c><b>","guide_haicao",0,500],
    [21,5,"<b><color=#000000>*#&￥%%！&锁定！*#&￥￥&敌@*@方！</c><b>","guide_gtx",0,500],
    [22,5,"<b><color=#000000>蠢货！你们要是给他打醒！也许他醒来后，愿意给你念一念这令人作呕的台词！</c><b>","guide_xiaochou",0,500],
    [1000,1000,"<b><color=#000000>到达指定关卡，才会进行存档。否则会从上一个存档点重新开始哦</c><b>","guide_xiaochou",2,500],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new storyconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    storyconfig .push(r);

}

export default storyconfig
