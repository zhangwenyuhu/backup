const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","rewardtype","goodsID","quality","prob",]

export class dialrewardConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 奖励库类型
         **/
        @SafeProperty
        rewardtype?:number

        /**
         * 道具
         **/
        @SafeProperty
        goodsID?:any

        /**
         * 品质
普通蓝：1
特殊紫：2
超值金：3
         **/
        @SafeProperty
        quality?:number

        /**
         * 随机权重
         **/
        @SafeProperty
        prob?:number

}

let dialrewardConfig:dialrewardConfigRow []=[];

var rowData=
[
    [1001,1,[[10001,10000]],1,100],
    [1002,1,[[10061,5]],2,50],
    [1003,1,[[10008,20]],1,100],
    [1004,1,[[10006,1]],3,25],
    [1005,1,[[10060,10]],1,100],
    [1006,1,[[10002,20]],1,100],
    [1007,1,[[10068,200]],2,50],
    [1008,1,[[10001,10000]],1,100],
    [2001,2,[[10001,20000]],1,100],
    [2002,2,[[10061,10]],2,50],
    [2003,2,[[10008,30]],1,100],
    [2004,2,[[10006,2]],3,15],
    [2005,2,[[10060,15]],1,100],
    [2006,2,[[10002,30]],1,100],
    [2007,2,[[10068,300]],2,50],
    [2008,2,[[10001,20000]],1,110],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new dialrewardConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    dialrewardConfig .push(r);

}

export default dialrewardConfig
