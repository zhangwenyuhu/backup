const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","reward","probability","importance",]

export class niudanconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 奖励内容
         **/
        @SafeProperty
        reward?:any

        /**
         * 概率
Trace:
万分之一

         **/
        @SafeProperty
        probability?:number

        /**
         * 重要程度
zhangchenxue:
1.红
2.金
3.紫
4.蓝
5.绿

         **/
        @SafeProperty
        importance?:number

}

let niudanconfig:niudanconfigRow []=[];

var rowData=
[
    [2,[10002,30000],1,1],
    [3,[30911,1],7,2],
    [4,[30912,1],7],
    [5,[30913,1],7],
    [6,[30914,1],7],
    [7,[30921,1],7],
    [8,[30922,1],7],
    [9,[30923,1],7],
    [10,[30924,1],7],
    [11,[30931,1],7],
    [12,[30932,1],7],
    [13,[30933,1],7],
    [14,[30934,1],7],
    [15,[10011,1],350,2],
    [16,[10012,1],350],
    [17,[10013,1],350],
    [18,[10014,1],350],
    [19,[10016,1],350],
    [20,[10017,1],350],
    [21,[10493,1],350],
    [22,[10096,1],450,3],
    [23,[10092,1],80,3],
    [24,[10093,1],80],
    [25,[10094,1],80],
    [26,[10095,1],80],
    [27,[10035,2],450,4],
    [28,[10045,2],450],
    [29,[10023,2],450],
    [30,[10088,1],225,0],
    [31,[10089,1],225],
    [32,[10090,1],225],
    [33,[10091,1],225],
    [34,[10043,5],936,0],
    [35,[10033,5],936,0],
    [36,[10021,5],936,0],
    [37,[10008,50],936,0],
    [38,[10480,5],501,4],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new niudanconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    niudanconfig .push(r);

}

export default niudanconfig
