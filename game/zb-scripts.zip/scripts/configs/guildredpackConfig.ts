const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","guildpeople","person",]

export class guildredpackConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 公会人数
         **/
        @SafeProperty
        guildpeople?:number[]

        /**
         * 抢红包数量
         **/
        @SafeProperty
        person?:number

}

let guildredpackConfig:guildredpackConfigRow []=[];

var rowData=
[
    [1,[0,50],30],
    [2,[51,100],30],
    [3,[101,150],35],
    [4,[151,200],35],
    [5,[201,250],40],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new guildredpackConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    guildredpackConfig .push(r);

}

export default guildredpackConfig
