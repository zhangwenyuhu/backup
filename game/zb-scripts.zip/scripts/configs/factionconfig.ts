const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","job","jobnumber","allowapply","setjoinlevel","changebulletin","expelviceboss","expelmember","addviceboss","sendnormalmail","sendallmail","transferboss","dissolve","openvenery","shopbuy","leavefaction","changename",]

export class factionconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 职位
         **/
        @SafeProperty
        job?:string

        /**
         * 人数上限
         **/
        @SafeProperty
        jobnumber?:number

        /**
         * 批准入盟申请
         **/
        @SafeProperty
        allowapply?:number

        /**
         * 设置入盟等级
         **/
        @SafeProperty
        setjoinlevel?:number

        /**
         * 修改工会公告
         **/
        @SafeProperty
        changebulletin?:number

        /**
         * 踢出副会长
         **/
        @SafeProperty
        expelviceboss?:number

        /**
         * 踢出成员
         **/
        @SafeProperty
        expelmember?:number

        /**
         * 任命副会长
         **/
        @SafeProperty
        addviceboss?:number

        /**
         * 发送个人邮件
         **/
        @SafeProperty
        sendnormalmail?:number

        /**
         * 发送全员邮件
         **/
        @SafeProperty
        sendallmail?:number

        /**
         * 转让会长职位
         **/
        @SafeProperty
        transferboss?:number

        /**
         * 解散工会
         **/
        @SafeProperty
        dissolve?:number

        /**
         * 开启团队狩猎
         **/
        @SafeProperty
        openvenery?:number

        /**
         * 工会商店购买
         **/
        @SafeProperty
        shopbuy?:number

        /**
         * 离开公会
         **/
        @SafeProperty
        leavefaction?:number

        /**
         * 修改工会名
         **/
        @SafeProperty
        changename?:number

}

let factionconfig:factionconfigRow []=[];

var rowData=
[
    [1,"会长",1,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
    [2,"长老",2,1,0,1,0,1,0,1,1,0,0,1,1,1,0],
    [3,"成员",999,0,0,0,0,0,0,1,0,0,0,0,1,1,0],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new factionconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    factionconfig .push(r);

}

export default factionconfig
