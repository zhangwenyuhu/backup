const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","ArtifactID","order","tasktype","tasknumber","skip","vipunlock",]

export class artifactunlockConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 神器ID
         **/
        @SafeProperty
        ArtifactID?:number

        /**
         * 解锁顺序
         **/
        @SafeProperty
        order?:number

        /**
         * 任务类型
         **/
        @SafeProperty
        tasktype?:number

        /**
         * 任务要求
         **/
        @SafeProperty
        tasknumber?:number

        /**
         * 跳转
         **/
        @SafeProperty
        skip?:number

        /**
         * VIP解锁
         **/
        @SafeProperty
        vipunlock?:number

}

let artifactunlockConfig:artifactunlockConfigRow []=[];

var rowData=
[
    [1,40001,2,3001,156,12,0],
    [2,40001,2,3003,90,1,0],
    [3,40001,2,3016,5,9,0],
    [4,40001,2,3004,30,0,0],
    [5,40002,5,3001,712,12,0],
    [6,40002,5,3003,170,1,0],
    [7,40002,5,8001,3,3,0],
    [8,40002,5,8006,4,1,0],
    [9,40003,4,3001,512,12,0],
    [10,40003,4,3008,180,14,0],
    [11,40003,4,8004,8,13,0],
    [12,40003,4,8002,5,9,0],
    [13,40004,6,8005,8,16,8],
    [14,40004,6],
    [15,40004,6],
    [16,40004,6],
    [17,40005,7],
    [18,40005,7],
    [19,40005,7],
    [20,40005,7],
    [21,40006,3,3001,376,12,0],
    [22,40006,3,3002,7,7,0],
    [23,40006,3,3007,100,5,0],
    [24,40006,3,8002,1,9,0],
    [25,40007,1,3001,20,12,0],
    [26,40007,1,3005,30,15,0],
    [27,40007,1,3014,1,3,0],
    [28,40007,1,3003,1,1,0],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new artifactunlockConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    artifactunlockConfig .push(r);

}

export default artifactunlockConfig
