const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","Cost","Diamond1","Diamond2","resource","equipreward",]

export class yuekaConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 价格
         **/
        @SafeProperty
        Cost?:number

        /**
         * 立即获得钻石
         **/
        @SafeProperty
        Diamond1?:number

        /**
         * 每日钻石奖励
         **/
        @SafeProperty
        Diamond2?:number

        /**
         * 每日资源奖励
         **/
        @SafeProperty
        resource?:any

        /**
         * 装备
         **/
        @SafeProperty
        equipreward?:any

}

let yuekaConfig:yuekaConfigRow []=[];

var rowData=
[
    [1,30,300,100,null,[30531,1]],
    [2,98,980,400,null,null],
    [3,12,120,0,[[10032,1],[10042,1]],[[10032,2],[10042,2],[10477,1]]],
    [4,198,1980,0,[[10007,1],[10006,2]],[10007,10]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new yuekaConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    yuekaConfig .push(r);

}

export default yuekaConfig
