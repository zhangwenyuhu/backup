const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","type","hurtmax","factiongold","gold",]

export class huntrewardconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 类型（1哥布林2远古剑魂）
         **/
        @SafeProperty
        type?:number

        /**
         * 伤害最高
         **/
        @SafeProperty
        hurtmax?:number

        /**
         * 公会币
         **/
        @SafeProperty
        factiongold?:number

        /**
         * 金币
         **/
        @SafeProperty
        gold?:number

}

let huntrewardconfig:huntrewardconfigRow []=[];

var rowData=
[
    [1001,1,150000,200,1000],
    [1002,1,200000,300,2000],
    [1003,1,300000,400,3000],
    [1004,1,500000,500,4000],
    [1005,1,1000000,600,5000],
    [1006,1,1500000,700,6000],
    [1007,1,2000000,800,7000],
    [1008,1,5000000,900,8000],
    [1009,1,8000000,1000,9000],
    [1010,1,12000000,1100,10000],
    [2001,2,150000,200,1000],
    [2002,2,200000,300,2000],
    [2003,2,300000,400,3000],
    [2004,2,500000,500,4000],
    [2005,2,1000000,600,5000],
    [2006,2,1500000,700,6000],
    [2007,2,2000000,800,7000],
    [2008,2,5000000,900,8000],
    [2009,2,8000000,1000,9000],
    [2010,2,12000000,1100,10000],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new huntrewardconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    huntrewardconfig .push(r);

}

export default huntrewardconfig
