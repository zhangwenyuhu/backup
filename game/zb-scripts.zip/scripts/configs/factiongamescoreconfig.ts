const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","stage","promote","winreward","failreward","limitreward","getreward","bonuslimit","totalscore","stagereward","monsterscore",]

export class factiongamescoreconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 阶段
         **/
        @SafeProperty
        stage?:number

        /**
         * 晋级积分要求
         **/
        @SafeProperty
        promote?:number

        /**
         * 到达阶段工会胜利总奖励
         **/
        @SafeProperty
        winreward?:any

        /**
         * 到达阶段工会失败总奖励
         **/
        @SafeProperty
        failreward?:any

        /**
         * 未达到积分要求的安慰奖
         **/
        @SafeProperty
        limitreward?:any

        /**
         * 玩家领奖所需积分比例
         **/
        @SafeProperty
        getreward?:number

        /**
         * 最低对抗奖励积分需求
         **/
        @SafeProperty
        bonuslimit?:number

        /**
         * 满讨伐度积分
         **/
        @SafeProperty
        totalscore?:number

        /**
         * 成就通关奖励（只能领一次）
         **/
        @SafeProperty
        stagereward?:any

        /**
         * 怪物军团每日增长积分
         **/
        @SafeProperty
        monsterscore?:number

}

let factiongamescoreconfig:factiongamescoreconfigRow []=[];

var rowData=
[
    [1,1,200,[[10002,10000],[10001,1000000]],[[10002,5000],[10001,500000]],[10001,1000],0.05,14,100,[[10002,100],[10001,1000]],200],
    [2,2,300,[[10002,10000],[10001,1000000]],[[10002,5000],[10001,500000]],[10001,1000],0.05,14,100,[[10002,100],[10001,1000]],300],
    [3,3,400,[[10002,10000],[10001,1000000]],[[10002,5000],[10001,500000]],[10001,1000],0.05,14,100,[[10002,100],[10001,1000]],400],
    [4,4,500,[[10002,10000],[10001,1000000]],[[10002,5000],[10001,500000]],[10001,1000],0.05,14,100,[[10002,100],[10001,1000]],500],
    [5,5,600,[[10002,10000],[10001,1000000]],[[10002,5000],[10001,500000]],[10001,1000],0.05,14,100,[[10002,100],[10001,1000]],600],
    [6,6,700,[[10002,10000],[10001,1000000]],[[10002,5000],[10001,500000]],[10001,1000],0.05,14,100,[[10002,100],[10001,1000]],700],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new factiongamescoreconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    factiongamescoreconfig .push(r);

}

export default factiongamescoreconfig
