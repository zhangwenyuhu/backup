const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","numberofplies","reward","number","weight",]

export class xunbaorewardconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 生效层数
zhangchenxue:
数字相同的为同一个奖池
         **/
        @SafeProperty
        numberofplies?:number[]

        /**
         * 奖励
普通：goodsconfig

         **/
        @SafeProperty
        reward?:any

        /**
         * 数量
         **/
        @SafeProperty
        number?:number

        /**
         * 权重
         **/
        @SafeProperty
        weight?:number

}

let xunbaorewardconfig:xunbaorewardconfigRow []=[];

var rowData=
[
    [1001,[1,1],[10017,2],1,30],
    [1002,[1,1],[10011,2],1,30],
    [1003,[1,1],[10007,2],1,30],
    [1004,[1,1],[10061,10],2,50],
    [1005,[1,1],[10052,1],2,100],
    [1006,[1,1],[10006,2],2,100],
    [1007,[1,1],[10033,2],6,50],
    [1008,[1,1],[10481,2],10,30],
    [1009,[1,1],[10480,2],10,30],
    [2001,[2,4],[10017,3],2,30],
    [2002,[2,4],[10011,3],2,30],
    [2003,[2,4],[10007,2],2,30],
    [2004,[2,4],[10061,30],3,50],
    [2005,[2,4],[10052,2],3,100],
    [2006,[2,4],[10006,5],3,100],
    [2007,[2,4],[10033,5],4,50],
    [2008,[2,4],[10481,5],8,30],
    [2009,[2,4],[10480,5],8,30],
    [3001,[5,20],[10013,5],2,30],
    [3002,[5,20],[10012,5],2,30],
    [3003,[5,20],[10007,2],2,30],
    [3004,[5,20],[10061,30],3,50],
    [3005,[5,20],[10052,2],3,100],
    [3006,[5,20],[10006,5],3,100],
    [3007,[5,20],[10033,5],4,50],
    [3008,[5,20],[10481,5],8,30],
    [3009,[5,20],[10480,5],8,30],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new xunbaorewardconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    xunbaorewardconfig .push(r);

}

export default xunbaorewardconfig
