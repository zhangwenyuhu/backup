const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","groupname","showrank","hero1","source1","skip01","hero2","source2","skip02","hero3","source3","skip03","hero4","source4","skip04","hero5","source5","skip05","centre","reason","star","startype",]

export class herointroduceconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 组合名
         **/
        @SafeProperty
        groupname?:string

        /**
         * 5英雄展示品质
         **/
        @SafeProperty
        showrank?:string

        /**
         * 英雄1
         **/
        @SafeProperty
        hero1?:number

        /**
         * 途径1
         **/
        @SafeProperty
        source1?:string

        /**
         * 跳转
         **/
        @SafeProperty
        skip01?:string

        /**
         * 英雄2
         **/
        @SafeProperty
        hero2?:number

        /**
         * 途径2
         **/
        @SafeProperty
        source2?:string

        /**
         * 跳转
         **/
        @SafeProperty
        skip02?:string

        /**
         * 英雄3
         **/
        @SafeProperty
        hero3?:number

        /**
         * 途径3
         **/
        @SafeProperty
        source3?:string

        /**
         * 跳转
         **/
        @SafeProperty
        skip03?:string

        /**
         * 英雄4
         **/
        @SafeProperty
        hero4?:number

        /**
         * 途径4
         **/
        @SafeProperty
        source4?:string

        /**
         * 跳转
         **/
        @SafeProperty
        skip04?:string

        /**
         * 英雄5
         **/
        @SafeProperty
        hero5?:number

        /**
         * 途径5
         **/
        @SafeProperty
        source5?:string

        /**
         * 跳转
         **/
        @SafeProperty
        skip05?:string

        /**
         * 核心英雄
         **/
        @SafeProperty
        centre?:any

        /**
         * 推荐理由
         **/
        @SafeProperty
        reason?:string

        /**
         * 星级
         **/
        @SafeProperty
        star?:number

        /**
         * 星icon类型
1.黄
2.紫
         **/
        @SafeProperty
        startype?:number

}

let herointroduceconfig:herointroduceconfigRow []=[];

var rowData=
[
    [1,"武装加成队","4;4;4;4;4",20037,"","3",20034,"","21;20;3",20055,"","25;3",20046,"","3",20033,"","17;18;3",20037,"武装阵营以奇异博士为核心，相互辅助，持续不断释放各种必杀技，可以合成UR级武装英雄：半藏，超强输出震慑全场",5,1],
    [2,"机械加成队","4;4;4;4;4",20053,"","21;3",20052,"","3",20017,"","21;3",20018,"","3",20053,"","3",20015,"机械阵容以海王为核心，霸道的控制让敌人寸步难行，可以合成UR级机械英雄：阿尔特留斯，强硬控制且拥有无视防御的输出",5,1],
    [3,"变种加成队","4;4;4;4;4",20024,"","21;3",20025,"","3",20026,"","3",20045,"","3",20049,"","3",20024,"变种阵容以格鲁特为核心，有着各种冲脸的硬汉，狂暴输出加上吸血，让对面的脆皮英雄无法招架",5,1],
    [4,"僵尸加成队","4;4;4;4;4",20009,"","16|6;3",20007,"","3",20050,"","3",20051,"","3",20006,"","3",20007,"僵尸阵容以德古拉为核心，双法师持续输出，队友的怒气控制，让对方无法释放技能，可以合成UR级僵尸英雄：鸣人，召唤分身干扰战场，吸收成吨伤害",5,1],
    [5,"毁天灭地","7;7;7;7;7",20038,"","16|10;3",20039,"","23;3",20048,"","3",20054,"","35",20062,"","3",20039,"极限超能与毁灭阵容能带来大量伤害与控制，结合服部半藏的猛烈输出，伤害拉满",6,2],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new herointroduceconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    herointroduceconfig .push(r);

}

export default herointroduceconfig
