const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","days","chargenumber","reward",]

export class newplayerchargeconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 天数
         **/
        @SafeProperty
        days?:number

        /**
         * 充值价格
         **/
        @SafeProperty
        chargenumber?:number

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:any

}

let newplayerchargeconfig:newplayerchargeconfigRow []=[];

var rowData=
[
    [1,1,12,[[10060,15],[10041,2],[10031,2]]],
    [2,1,68,[[10060,45],[10006,3],[10041,2]]],
    [3,1,198,[[10006,8],[10031,5],[10480,100]]],
    [4,2,12,[[10060,60],[10041,2],[10031,2]]],
    [5,2,98,[[10061,60],[10006,5],[10031,3]]],
    [6,2,198,[[10006,8],[10031,5],[10480,100]]],
    [7,3,12,[[10060,60],[10041,2],[10031,2]]],
    [8,3,98,[[10061,60],[10006,5],[10031,3]]],
    [9,3,198,[[10006,8],[10031,5],[10480,100]]],
    [10,4,12,[[10060,60],[10041,2],[10031,2]]],
    [11,4,198,[[10006,8],[10031,5],[10480,100]]],
    [12,4,328,[[10006,10],[10031,10],[10493,5]]],
    [13,5,12,[[10060,60],[10041,2],[10031,2]]],
    [14,5,198,[[10006,8],[10031,5],[10480,100]]],
    [15,5,328,[[10006,10],[10031,10],[10493,5]]],
    [16,6,12,[[10060,60],[10041,2],[10031,2]]],
    [17,6,198,[[10006,8],[10031,5],[10480,100]]],
    [18,6,328,[[10006,10],[10031,10],[10493,5]]],
    [19,7,12,[[10060,60],[10041,2],[10031,2]]],
    [20,7,198,[[10006,8],[10031,5],[10480,100]]],
    [21,7,648,[[10011,50],[10480,500],[10031,20]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new newplayerchargeconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    newplayerchargeconfig .push(r);

}

export default newplayerchargeconfig
