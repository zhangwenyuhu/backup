const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","desc","unlockstage",]

export class bubbleconversationConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 描述
         **/
        @SafeProperty
        desc?:string

        /**
         * 解锁关卡
         **/
        @SafeProperty
        unlockstage?:number

}

let bubbleconversationConfig:bubbleconversationConfigRow []=[];

var rowData=
[
    [1,"你不会知道！所有召唤物会随着英雄的消失而消亡！",1],
    [2,"装备没有穿戴等级限制",1],
    [3,"合理安排站位可以让战斗变得更轻松！",1],
    [4,"战斗失败时，可以让其他英雄上阵试试看",1],
    [5,"重置英雄会完全返还培养资源",1],
    [6,"调整站位，才能完全发挥出英雄的战斗风格",1],
    [7,"英雄品阶会影响英雄等级上限",1],
    [8,"嗯~ 是脑子的味道！",1],
    [9,"我们要怎么进行，这令人愉悦的折磨！",1],
    [10,"也许！你需要的只是一场长眠…",1],
    [11,"我的胃…空空如也",1],
    [12,"这里已经被我们完全占领！挣扎是没用的！",1],
    [13,"别再靠近了，除非…你不怕死！",1],
    [14,"呼…呼…对！就是这样！你还有最后几秒钟喘气儿的机会！",1],
    [15,"嗯…我想…我闻到了，是肉的味道~",1],
    [16,"嗨，年轻人！我可以带你去见上帝！",1],
    [17,"有句古话，“人生自古…怎么着？”后面是被我吃掉不痛苦！",1],
    [18,"主动释放控制类必杀技，可以更好掌握时机，打断敌方施法！",1],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new bubbleconversationConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    bubbleconversationConfig .push(r);

}

export default bubbleconversationConfig
