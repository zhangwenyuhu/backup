const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","type","order","money","activitytype","title","buylimit","item","amount1","VipExp","twoTimes","price","productId","usd","HKD",]

export class storeConfigRow{

        /**
         * 参数ID
         **/
        @SafeProperty
        Id?:uid

        /**
         * 类型
         **/
        @SafeProperty
        type?:number

        /**
         * 排序
         **/
        @SafeProperty
        order?:number

        /**
         * 售价
         **/
        @SafeProperty
        money?:number

        /**
         * 绑定活动类型
         **/
        @SafeProperty
        activitytype?:number

        /**
         * 商品名称
         **/
        @SafeProperty
        title?:string

        /**
         * 限购次数
         **/
        @SafeProperty
        buylimit?:number

        /**
         * 商品id
道具表id

         **/
        @SafeProperty
        item?:number

        /**
         * 商品数量
         **/
        @SafeProperty
        amount1?:number

        /**
         * VIP 经验
         **/
        @SafeProperty
        VipExp?:number

        /**
         * 首次双倍
         **/
        @SafeProperty
        twoTimes?:number

        /**
         * 原价
         **/
        @SafeProperty
        price?:number

        /**
         * 后台商品名
         **/
        @SafeProperty
        productId?:string

        /**
         * 美金价格
         **/
        @SafeProperty
        usd?:number

        /**
         * 港币价格
         **/
        @SafeProperty
        HKD?:number

}

let storeConfig:storeConfigRow []=[];

var rowData=
[
    [101,1,6,6,0,"60钻石",0,10002,60,60,1,6,"com.hzmr.monsterwar.u6"],
    [1,1,5,30,0,"300钻石",0,10002,300,300,1,30,"com.hzmr.monsterwar.u30"],
    [3001,1,4,98,0,"980钻石",0,10002,980,980,1,98,"com.hzmr.monsterwar.u98"],
    [4,1,3,198,0,"1980钻石",0,10002,1980,1980,1,198,"com.hzmr.monsterwar.u198"],
    [5,1,2,328,0,"3280钻石",0,10002,3280,3280,1,328,"com.hzmr.monsterwar.u328"],
    [6,1,1,648,0,"6480钻石",0,10002,6480,6480,1,648,"com.hzmr.monsterwar.u648"],
    [7,2,1,30,0,"普通月卡",0,10002,300,300,0,30,"com.hzmr.monsterwar.m1"],
    [8,3,2,98,0,"超级月卡",0,10002,980,980,0,98,"com.hzmr.monsterwar.m2"],
    [9,4,1,128,0,"成长计划",0,10002,0,1280,0,128,"com.hzmr.monsterwar.grow"],
    [10,5,4,30,0,"新手福利礼包",0,10076,1,300,0,126,"com.hzmr.monsterwar.bag1"],
    [11,5,3,68,0,"新手精品礼包",0,10077,1,680,0,312,"com.hzmr.monsterwar.bag2"],
    [12,5,2,128,0,"新手豪华礼包",0,10078,1,1280,0,633,"com.hzmr.monsterwar.bag3"],
    [13,5,1,328,0,"新手奢华礼包",0,10079,1,3280,0,1750,"com.hzmr.monsterwar.bag4"],
    [14,5,6,648,0,"新手至尊礼包",0,10080,1,6480,0,3600,"com.hzmr.monsterwar.bag5"],
    [15,6,1,6,0,"惊喜礼包1",0,10081,1,60,0,6,"com.hzmr.monsterwar.bag6"],
    [16,6,2,30,0,"惊喜礼包2",0,10082,1,300,0,30,"com.hzmr.monsterwar.bag7"],
    [17,6,3,128,0,"惊喜礼包3",0,10083,1,1280,0,128,"com.hzmr.monsterwar.bag8"],
    [18,6,4,328,0,"惊喜礼包4",0,10084,1,3280,0,328,"com.hzmr.monsterwar.bag9"],
    [19,7,1,163,0,"活跃礼包特权",0,10002,0,1630,0,163,"com.hzmr.monsterwar.active"],
    [20,8,1,163,0,"智慧树礼包特权",0,10002,0,1630,0,163,"com.hzmr.monsterwar.wisdomtree"],
    [21,9,1,0,0,"每日免费礼包",1,10150,1,0,0,0,"com.hzmr.monsterwar.day1"],
    [22,9,2,6,0,"每日灵魂石礼包",1,10151,1,60,0,6,"com.hzmr.monsterwar.day2"],
    [23,9,3,30,0,"每日粉尘礼包",1,10152,1,300,0,30,"com.hzmr.monsterwar.day3"],
    [24,10,1,0,0,"每周免费礼包",1,10153,1,0,0,0,"com.hzmr.monsterwar.week1"],
    [26,10,3,30,0,"每周抽卡券礼包",3,10155,1,300,0,30,"com.hzmr.monsterwar.week3"],
    [27,11,1,0,0,"每月免费礼包",1,10156,1,0,0,0,"com.hzmr.monsterwar.month1"],
    [28,10,2,12,0,"每周灵魂石礼包",6,10157,1,120,0,12,"com.glee.zombiewar2.month2"],
    [29,11,3,30,0,"每月粉尘礼包",3,10158,1,300,0,30,"com.hzmr.monsterwar.month3"],
    [30,11,4,30,0,"每月粉尘礼包",3,10159,1,300,0,30,"com.hzmr.monsterwar.month4"],
    [31,11,5,68,0,"每月粉尘礼包",3,10160,1,680,0,68,"com.hzmr.monsterwar.month5"],
    [32,11,6,98,0,"每月粉尘礼包",3,10161,1,980,0,98,"com.hzmr.monsterwar.month6"],
    [33,12,1,30,8,"棋盘寻宝",1,10162,1,300,0,30,"com.hzmr.monsterwar.board1"],
    [34,12,2,68,8,"棋盘寻宝",1,10163,1,680,0,68,"com.hzmr.monsterwar.board2"],
    [35,12,1,6,7,"夺宝奇兵",1,10164,1,60,0,6,"com.hzmr.monsterwar.duobao1"],
    [36,12,2,30,7,"夺宝奇兵",1,10165,1,300,0,30,"com.hzmr.monsterwar.duobao2"],
    [37,9,4,30,0,"每日金币礼包",1,10166,1,300,0,30,"com.hzmr.monsterwar.day4"],
    [38,9,5,30,0,"每日铸币礼包",1,10167,1,300,0,30,"com.hzmr.monsterwar.day5"],
    [40,10,4,68,0,"每周抽卡券礼包",2,10169,1,680,0,68,"com.hzmr.monsterwar.week4"],
    [41,10,6,128,0,"每周抽卡券礼包",2,10170,1,1280,0,128,"com.hzmr.monsterwar.week5"],
    [42,10,8,198,0,"每周阵营抽礼包",2,10171,1,1980,0,198,"com.hzmr.monsterwar.week6"],
    [43,10,9,328,0,"每周阵营抽礼包",3,10172,1,3280,0,328,"com.hzmr.monsterwar.week7"],
    [44,10,10,648,0,"每周阵营抽礼包",3,10173,1,6480,0,648,"com.hzmr.monsterwar.week8"],
    [45,11,7,128,0,"每月灵魂石礼包",3,10174,1,1280,0,128,"com.hzmr.monsterwar.month7"],
    [48,11,10,328,0,"每月阵营抽礼包",4,10177,1,3280,0,328,"com.hzmr.monsterwar.month10"],
    [49,11,11,648,0,"每月阵营抽礼包",4,10178,1,6480,0,648,"com.hzmr.monsterwar.month11"],
    [50,6,5,648,0,"惊喜礼包5",0,10182,1,6480,0,328,"com.hzmr.monsterwar.bag10"],
    [51,6,6,6,0,"6块忍者龟",0,10183,1,60,0,6,"com.hzmr.monsterwar.surprise1"],
    [52,6,7,6,0,"6块30精英",0,10184,1,60,0,6,"com.hzmr.monsterwar.surprise2"],
    [53,6,8,6,0,"6块60精英60黑铁",0,10185,1,60,0,6,"com.hzmr.monsterwar.surprise3"],
    [54,6,9,30,0,"30块灵魂",0,10186,1,300,0,30,"com.hzmr.monsterwar.surprise4"],
    [55,6,10,30,0,"30块10抽",0,10187,1,300,0,30,"com.hzmr.monsterwar.surprise5"],
    [56,6,11,30,0,"30块60精英",0,10188,1,300,0,30,"com.hzmr.monsterwar.surprise6"],
    [57,6,12,30,0,"30块10抽",0,10189,1,300,0,30,"com.hzmr.monsterwar.surprise7"],
    [58,6,13,68,0,"68抽卡红装武器",0,10190,1,680,0,68,"com.hzmr.monsterwar.surprise8"],
    [59,6,14,68,0,"68抽卡红装武器",0,10191,1,680,0,68,"com.hzmr.monsterwar.surprise9"],
    [60,6,15,68,0,"68抽卡红装武器",0,10192,1,680,0,68,"com.hzmr.monsterwar.surprise10"],
    [61,6,16,68,0,"68抽卡红装帽子",0,10193,1,680,0,68,"com.hzmr.monsterwar.surprise11"],
    [62,6,17,68,0,"68抽卡红装帽子",0,10194,1,680,0,68,"com.hzmr.monsterwar.surprise12"],
    [63,6,18,68,0,"68抽卡红装帽子",0,10195,1,680,0,68,"com.hzmr.monsterwar.surprise13"],
    [64,6,19,68,0,"68灵魂石红装武器",0,10196,1,680,0,68,"com.hzmr.monsterwar.surprise14"],
    [65,6,20,68,0,"68灵魂石红装武器",0,10197,1,680,0,68,"com.hzmr.monsterwar.surprise15"],
    [66,6,21,68,0,"68灵魂石红装武器",0,10198,1,680,0,68,"com.hzmr.monsterwar.surprise16"],
    [67,6,22,68,0,"68灵魂石红装帽子",0,10199,1,680,0,68,"com.hzmr.monsterwar.surprise17"],
    [68,6,23,68,0,"68灵魂石红装帽子",0,10200,1,680,0,68,"com.hzmr.monsterwar.surprise18"],
    [69,6,24,68,0,"68灵魂石红装帽子",0,10201,1,680,0,68,"com.hzmr.monsterwar.surprise19"],
    [70,6,25,68,0,"68灵魂石粉尘红装武器",0,10202,1,680,0,68,"com.hzmr.monsterwar.surprise20"],
    [71,6,26,68,0,"68灵魂石粉尘红装武器",0,10203,1,680,0,68,"com.hzmr.monsterwar.surprise21"],
    [72,6,27,68,0,"68灵魂石粉尘红装武器",0,10204,1,680,0,68,"com.hzmr.monsterwar.surprise22"],
    [73,6,28,68,0,"68灵魂石粉尘红装帽子",0,10205,1,680,0,68,"com.hzmr.monsterwar.surprise23"],
    [74,6,29,68,0,"68灵魂石粉尘红装帽子",0,10206,1,680,0,68,"com.hzmr.monsterwar.surprise24"],
    [75,6,30,68,0,"68灵魂石粉尘红装帽子",0,10207,1,680,0,68,"com.hzmr.monsterwar.surprise25"],
    [76,6,31,128,0,"128大粉尘",0,10208,1,1280,0,128,"com.hzmr.monsterwar.surprise26"],
    [77,6,32,128,0,"128红装武器1经验",0,10209,1,1280,0,128,"com.hzmr.monsterwar.surprise27"],
    [78,6,33,128,0,"128红装武器2经验",0,10210,1,1280,0,128,"com.hzmr.monsterwar.surprise28"],
    [79,6,34,128,0,"128红装武器3经验",0,10211,1,1280,0,128,"com.hzmr.monsterwar.surprise29"],
    [80,6,35,128,0,"128红装帽子1经验",0,10212,1,1280,0,128,"com.hzmr.monsterwar.surprise30"],
    [81,6,36,128,0,"128红装帽子2经验",0,10213,1,1280,0,128,"com.hzmr.monsterwar.surprise31"],
    [82,6,37,128,0,"128红装帽子3经验",0,10214,1,1280,0,128,"com.hzmr.monsterwar.surprise32"],
    [83,6,38,128,0,"128红装武器1粉尘",0,10215,1,1280,0,128,"com.hzmr.monsterwar.surprise33"],
    [84,6,39,128,0,"128红装武器2粉尘",0,10216,1,1280,0,128,"com.hzmr.monsterwar.surprise34"],
    [85,6,40,128,0,"128红装武器3粉尘",0,10217,1,1280,0,128,"com.hzmr.monsterwar.surprise35"],
    [86,6,41,128,0,"128红装帽子1粉尘",0,10218,1,1280,0,128,"com.hzmr.monsterwar.surprise36"],
    [87,6,42,128,0,"128红装帽子2粉尘",0,10219,1,1280,0,128,"com.hzmr.monsterwar.surprise37"],
    [88,6,43,128,0,"128红装帽子3粉尘",0,10220,1,1280,0,128,"com.hzmr.monsterwar.surprise38"],
    [89,6,44,128,0,"128红装武器1铸币",0,10221,1,1280,0,128,"com.hzmr.monsterwar.surprise39"],
    [90,6,45,128,0,"128红装武器2铸币",0,10222,1,1280,0,128,"com.hzmr.monsterwar.surprise40"],
    [91,6,46,128,0,"128红装武器3铸币",0,10223,1,1280,0,128,"com.hzmr.monsterwar.surprise41"],
    [92,6,47,128,0,"128红装帽子1铸币",0,10224,1,1280,0,128,"com.hzmr.monsterwar.surprise42"],
    [93,6,48,128,0,"128红装帽子2铸币",0,10225,1,1280,0,128,"com.hzmr.monsterwar.surprise43"],
    [94,6,49,128,0,"128红装帽子3铸币",0,10226,1,1280,0,128,"com.hzmr.monsterwar.surprise44"],
    [95,6,50,128,0,"128抽卡",0,10227,1,1280,0,128,"com.hzmr.monsterwar.surprise45"],
    [96,6,51,328,0,"328大粉尘",0,10228,1,3280,0,328,"com.hzmr.monsterwar.surprise46"],
    [97,6,52,328,0,"328红装武器1经验",0,10229,1,3280,0,328,"com.hzmr.monsterwar.surprise47"],
    [98,6,53,328,0,"328红装武器2经验",0,10230,1,3280,0,328,"com.hzmr.monsterwar.surprise48"],
    [99,6,54,328,0,"328红装武器3经验",0,10231,1,3280,0,328,"com.hzmr.monsterwar.surprise49"],
    [100,6,55,328,0,"328红装帽子1经验",0,10232,1,3280,0,328,"com.hzmr.monsterwar.surprise50"],
    [1011,6,56,328,0,"328红装帽子2经验",0,10233,1,3280,0,328,"com.hzmr.monsterwar.surprise51"],
    [102,6,57,328,0,"328红装帽子3经验",0,10234,1,3280,0,328,"com.hzmr.monsterwar.surprise52"],
    [103,6,58,328,0,"328红装武器1粉尘",0,10235,1,3280,0,328,"com.hzmr.monsterwar.surprise53"],
    [104,6,59,328,0,"328红装武器2粉尘",0,10236,1,3280,0,328,"com.hzmr.monsterwar.surprise54"],
    [105,6,60,328,0,"328红装武器3粉尘",0,10237,1,3280,0,328,"com.hzmr.monsterwar.surprise55"],
    [106,6,61,328,0,"328红装帽子1粉尘",0,10238,1,3280,0,328,"com.hzmr.monsterwar.surprise56"],
    [107,6,62,328,0,"328红装帽子2粉尘",0,10239,1,3280,0,328,"com.hzmr.monsterwar.surprise57"],
    [108,6,63,328,0,"328红装帽子3粉尘",0,10240,1,3280,0,328,"com.hzmr.monsterwar.surprise58"],
    [109,6,64,328,0,"328红装武器1铸币",0,10241,1,3280,0,328,"com.hzmr.monsterwar.surprise59"],
    [110,6,65,328,0,"328红装武器2铸币",0,10242,1,3280,0,328,"com.hzmr.monsterwar.surprise60"],
    [111,6,66,328,0,"328红装武器3铸币",0,10243,1,3280,0,328,"com.hzmr.monsterwar.surprise61"],
    [112,6,67,328,0,"328红装帽子1铸币",0,10244,1,3280,0,328,"com.hzmr.monsterwar.surprise62"],
    [113,6,68,328,0,"328红装帽子2铸币",0,10245,1,3280,0,328,"com.hzmr.monsterwar.surprise63"],
    [114,6,69,328,0,"328红装帽子3铸币",0,10246,1,3280,0,328,"com.hzmr.monsterwar.surprise64"],
    [115,6,70,328,0,"328抽卡",0,10247,1,3280,0,328,"com.hzmr.monsterwar.surprise65"],
    [116,6,71,648,0,"648大粉尘",0,10248,1,6480,0,648,"com.hzmr.monsterwar.surprise66"],
    [117,6,72,648,0,"648红装武器1经验",0,10249,1,6480,0,648,"com.hzmr.monsterwar.surprise67"],
    [118,6,73,648,0,"648红装武器2经验",0,10250,1,6480,0,648,"com.hzmr.monsterwar.surprise68"],
    [119,6,74,648,0,"648红装武器3经验",0,10251,1,6480,0,648,"com.hzmr.monsterwar.surprise69"],
    [120,6,75,648,0,"648红装帽子1经验",0,10252,1,6480,0,648,"com.hzmr.monsterwar.surprise70"],
    [121,6,76,648,0,"648红装帽子2经验",0,10253,1,6480,0,648,"com.hzmr.monsterwar.surprise71"],
    [122,6,77,648,0,"648红装帽子3经验",0,10254,1,6480,0,648,"com.hzmr.monsterwar.surprise72"],
    [123,6,78,648,0,"648红装武器1粉尘",0,10255,1,6480,0,648,"com.hzmr.monsterwar.surprise73"],
    [124,6,79,648,0,"648红装武器2粉尘",0,10256,1,6480,0,648,"com.hzmr.monsterwar.surprise74"],
    [125,6,80,648,0,"648红装武器3粉尘",0,10257,1,6480,0,648,"com.hzmr.monsterwar.surprise75"],
    [126,6,81,648,0,"648红装帽子1粉尘",0,10258,1,6480,0,648,"com.hzmr.monsterwar.surprise76"],
    [127,6,82,648,0,"648红装帽子2粉尘",0,10259,1,6480,0,648,"com.hzmr.monsterwar.surprise77"],
    [128,6,83,648,0,"648红装帽子3粉尘",0,10260,1,6480,0,648,"com.hzmr.monsterwar.surprise78"],
    [129,6,84,648,0,"648红装武器1铸币",0,10261,1,6480,0,648,"com.hzmr.monsterwar.surprise79"],
    [130,6,85,648,0,"648红装武器2铸币",0,10262,1,6480,0,648,"com.hzmr.monsterwar.surprise80"],
    [131,6,86,648,0,"648红装武器3铸币",0,10263,1,6480,0,648,"com.hzmr.monsterwar.surprise81"],
    [132,6,87,648,0,"648红装帽子1铸币",0,10264,1,6480,0,648,"com.hzmr.monsterwar.surprise82"],
    [133,6,88,648,0,"648红装帽子2铸币",0,10265,1,6480,0,648,"com.hzmr.monsterwar.surprise83"],
    [134,6,89,648,0,"648红装帽子3铸币",0,10266,1,6480,0,648,"com.hzmr.monsterwar.surprise84"],
    [135,6,90,648,0,"648抽卡",0,10267,1,6480,0,648,"com.hzmr.monsterwar.surprise85"],
    [136,6,91,68,0,"68抽卡",0,10268,1,680,0,68,"com.hzmr.monsterwar.surprise86"],
    [137,6,92,68,0,"68抽卡金武器",0,10269,1,680,0,68,"com.hzmr.monsterwar.surprise87"],
    [138,6,93,68,0,"68抽卡金装武器",0,10270,1,680,0,68,"com.hzmr.monsterwar.surprise88"],
    [139,6,94,68,0,"68抽卡金装武器",0,10271,1,680,0,68,"com.hzmr.monsterwar.surprise89"],
    [140,6,95,68,0,"68抽卡金装帽子",0,10272,1,680,0,68,"com.hzmr.monsterwar.surprise90"],
    [141,6,96,68,0,"68抽卡金装帽子",0,10273,1,680,0,68,"com.hzmr.monsterwar.surprise91"],
    [142,6,97,68,0,"68抽卡金装帽子",0,10274,1,680,0,68,"com.hzmr.monsterwar.surprise92"],
    [143,6,98,68,0,"68灵魂石金装武器",0,10275,1,680,0,68,"com.hzmr.monsterwar.surprise93"],
    [144,6,99,68,0,"68灵魂石金装武器",0,10276,1,680,0,68,"com.hzmr.monsterwar.surprise94"],
    [145,6,100,68,0,"68灵魂石金装武器",0,10277,1,680,0,68,"com.hzmr.monsterwar.surprise95"],
    [146,6,101,68,0,"68灵魂石金装帽子",0,10278,1,680,0,68,"com.hzmr.monsterwar.surprise96"],
    [147,6,102,68,0,"68灵魂石金装帽子",0,10279,1,680,0,68,"com.hzmr.monsterwar.surprise97"],
    [148,6,103,68,0,"68灵魂石金装帽子",0,10280,1,680,0,68,"com.hzmr.monsterwar.surprise98"],
    [149,6,104,68,0,"68灵魂石粉尘金装武器",0,10281,1,680,0,68,"com.hzmr.monsterwar.surprise99"],
    [150,6,105,68,0,"68灵魂石粉尘金装武器",0,10282,1,680,0,68,"com.hzmr.monsterwar.surprise100"],
    [151,6,106,68,0,"68灵魂石粉尘金装武器",0,10283,1,680,0,68,"com.hzmr.monsterwar.surprise101"],
    [152,6,107,68,0,"68灵魂石粉尘金装帽子",0,10284,1,680,0,68,"com.hzmr.monsterwar.surprise102"],
    [153,6,108,68,0,"68灵魂石粉尘金装帽子",0,10285,1,680,0,68,"com.hzmr.monsterwar.surprise103"],
    [154,6,109,68,0,"68灵魂石粉尘金装帽子",0,10286,1,680,0,68,"com.hzmr.monsterwar.surprise104"],
    [155,6,110,68,0,"68抽卡金+装武器",0,10287,1,680,0,68,"com.hzmr.monsterwar.surprise105"],
    [156,6,111,68,0,"68抽卡金+装武器",0,10288,1,680,0,68,"com.hzmr.monsterwar.surprise106"],
    [157,6,112,68,0,"68抽卡金+装武器",0,10289,1,680,0,68,"com.hzmr.monsterwar.surprise107"],
    [158,6,113,68,0,"68抽卡金+装帽子",0,10290,1,680,0,68,"com.hzmr.monsterwar.surprise108"],
    [159,6,114,68,0,"68抽卡金+装帽子",0,10291,1,680,0,68,"com.hzmr.monsterwar.surprise109"],
    [160,6,115,68,0,"68抽卡金+装帽子",0,10292,1,680,0,68,"com.hzmr.monsterwar.surprise110"],
    [161,6,116,68,0,"68灵魂石金+装武器",0,10293,1,680,0,68,"com.hzmr.monsterwar.surprise111"],
    [162,6,117,68,0,"68灵魂石金+装武器",0,10294,1,680,0,68,"com.hzmr.monsterwar.surprise112"],
    [163,6,118,68,0,"68灵魂石金+装武器",0,10295,1,680,0,68,"com.hzmr.monsterwar.surprise113"],
    [164,6,119,68,0,"68灵魂石金+装帽子",0,10296,1,680,0,68,"com.hzmr.monsterwar.surprise114"],
    [165,6,120,68,0,"68灵魂石金+装帽子",0,10297,1,680,0,68,"com.hzmr.monsterwar.surprise115"],
    [166,6,121,68,0,"68灵魂石金+装帽子",0,10298,1,680,0,68,"com.hzmr.monsterwar.surprise116"],
    [167,6,122,68,0,"68灵魂石粉尘金+装武器",0,10299,1,680,0,68,"com.hzmr.monsterwar.surprise117"],
    [168,6,123,68,0,"68灵魂石粉尘金+装武器",0,10300,1,680,0,68,"com.hzmr.monsterwar.surprise118"],
    [169,6,124,68,0,"68灵魂石粉尘金+装武器",0,10301,1,680,0,68,"com.hzmr.monsterwar.surprise119"],
    [170,6,125,68,0,"68灵魂石粉尘金+装帽子",0,10302,1,680,0,68,"com.hzmr.monsterwar.surprise120"],
    [171,6,126,68,0,"68灵魂石粉尘金+装帽子",0,10303,1,680,0,68,"com.hzmr.monsterwar.surprise121"],
    [172,6,127,68,0,"68灵魂石粉尘金+装帽子",0,10304,1,680,0,68,"com.hzmr.monsterwar.surprise122"],
    [173,6,128,128,0,"128大粉尘",0,10305,1,1280,0,128,"com.hzmr.monsterwar.surprise123"],
    [174,6,129,128,0,"128金装武器1经验",0,10306,1,1280,0,128,"com.hzmr.monsterwar.surprise124"],
    [175,6,130,128,0,"128金装武器2经验",0,10307,1,1280,0,128,"com.hzmr.monsterwar.surprise125"],
    [176,6,131,128,0,"128金装武器3经验",0,10308,1,1280,0,128,"com.hzmr.monsterwar.surprise126"],
    [177,6,132,128,0,"128金装帽子1经验",0,10309,1,1280,0,128,"com.hzmr.monsterwar.surprise127"],
    [178,6,133,128,0,"128金装帽子2经验",0,10310,1,1280,0,128,"com.hzmr.monsterwar.surprise128"],
    [179,6,134,128,0,"128金装帽子3经验",0,10311,1,1280,0,128,"com.hzmr.monsterwar.surprise129"],
    [180,6,135,128,0,"128金装武器1粉尘",0,10312,1,1280,0,128,"com.hzmr.monsterwar.surprise130"],
    [181,6,136,128,0,"128金装武器2粉尘",0,10313,1,1280,0,128,"com.hzmr.monsterwar.surprise131"],
    [182,6,137,128,0,"128金装武器3粉尘",0,10314,1,1280,0,128,"com.hzmr.monsterwar.surprise132"],
    [183,6,138,128,0,"128金装帽子1粉尘",0,10315,1,1280,0,128,"com.hzmr.monsterwar.surprise133"],
    [184,6,139,128,0,"128金装帽子2粉尘",0,10316,1,1280,0,128,"com.hzmr.monsterwar.surprise134"],
    [185,6,140,128,0,"128金装帽子3粉尘",0,10317,1,1280,0,128,"com.hzmr.monsterwar.surprise135"],
    [186,6,141,128,0,"128金装武器1铸币",0,10318,1,1280,0,128,"com.hzmr.monsterwar.surprise136"],
    [187,6,142,128,0,"128金装武器2铸币",0,10319,1,1280,0,128,"com.hzmr.monsterwar.surprise137"],
    [188,6,143,128,0,"128金装武器3铸币",0,10320,1,1280,0,128,"com.hzmr.monsterwar.surprise138"],
    [189,6,144,128,0,"128金装帽子1铸币",0,10321,1,1280,0,128,"com.hzmr.monsterwar.surprise139"],
    [190,6,145,128,0,"128金装帽子2铸币",0,10322,1,1280,0,128,"com.hzmr.monsterwar.surprise140"],
    [191,6,146,128,0,"128金装帽子3铸币",0,10323,1,1280,0,128,"com.hzmr.monsterwar.surprise141"],
    [192,6,147,128,0,"128大粉尘",0,10324,1,1280,0,128,"com.hzmr.monsterwar.surprise142"],
    [193,6,148,128,0,"128金+装武器1经验",0,10325,1,1280,0,128,"com.hzmr.monsterwar.surprise143"],
    [194,6,149,128,0,"128金+装武器2经验",0,10326,1,1280,0,128,"com.hzmr.monsterwar.surprise144"],
    [195,6,150,128,0,"128金+装武器3经验",0,10327,1,1280,0,128,"com.hzmr.monsterwar.surprise145"],
    [196,6,151,128,0,"128金+装帽子1经验",0,10328,1,1280,0,128,"com.hzmr.monsterwar.surprise146"],
    [197,6,152,128,0,"128金+装帽子2经验",0,10329,1,1280,0,128,"com.hzmr.monsterwar.surprise147"],
    [198,6,153,128,0,"128金+装帽子3经验",0,10330,1,1280,0,128,"com.hzmr.monsterwar.surprise148"],
    [199,6,154,128,0,"128金+装武器1粉尘",0,10331,1,1280,0,128,"com.hzmr.monsterwar.surprise149"],
    [200,6,155,128,0,"128金+装武器2粉尘",0,10332,1,1280,0,128,"com.hzmr.monsterwar.surprise150"],
    [201,6,156,128,0,"128金+装武器3粉尘",0,10333,1,1280,0,128,"com.hzmr.monsterwar.surprise151"],
    [202,6,157,128,0,"128金+装帽子1粉尘",0,10334,1,1280,0,128,"com.hzmr.monsterwar.surprise152"],
    [203,6,158,128,0,"128金+装帽子2粉尘",0,10335,1,1280,0,128,"com.hzmr.monsterwar.surprise153"],
    [204,6,159,128,0,"128金+装帽子3粉尘",0,10336,1,1280,0,128,"com.hzmr.monsterwar.surprise154"],
    [205,6,160,128,0,"128金+装武器1铸币",0,10337,1,1280,0,128,"com.hzmr.monsterwar.surprise155"],
    [206,6,161,128,0,"128金+装武器2铸币",0,10338,1,1280,0,128,"com.hzmr.monsterwar.surprise156"],
    [207,6,162,128,0,"128金+装武器3铸币",0,10339,1,1280,0,128,"com.hzmr.monsterwar.surprise157"],
    [208,6,163,128,0,"128金+装帽子1铸币",0,10340,1,1280,0,128,"com.hzmr.monsterwar.surprise158"],
    [209,6,164,128,0,"128金+装帽子2铸币",0,10341,1,1280,0,128,"com.hzmr.monsterwar.surprise159"],
    [210,6,165,128,0,"128金+装帽子3铸币",0,10342,1,1280,0,128,"com.hzmr.monsterwar.surprise160"],
    [211,6,166,328,0,"328大粉尘",0,10343,1,3280,0,328,"com.hzmr.monsterwar.surprise161"],
    [212,6,167,328,0,"328金装武器1经验",0,10344,1,3280,0,328,"com.hzmr.monsterwar.surprise162"],
    [213,6,168,328,0,"328金装武器2经验",0,10345,1,3280,0,328,"com.hzmr.monsterwar.surprise163"],
    [214,6,169,328,0,"328金装武器3经验",0,10346,1,3280,0,328,"com.hzmr.monsterwar.surprise164"],
    [215,6,170,328,0,"328金装帽子1经验",0,10347,1,3280,0,328,"com.hzmr.monsterwar.surprise165"],
    [216,6,171,328,0,"328金装帽子2经验",0,10348,1,3280,0,328,"com.hzmr.monsterwar.surprise166"],
    [217,6,172,328,0,"328金装帽子3经验",0,10349,1,3280,0,328,"com.hzmr.monsterwar.surprise167"],
    [218,6,173,328,0,"328金装武器1粉尘",0,10350,1,3280,0,328,"com.hzmr.monsterwar.surprise168"],
    [219,6,174,328,0,"328金装武器2粉尘",0,10351,1,3280,0,328,"com.hzmr.monsterwar.surprise169"],
    [220,6,175,328,0,"328金装武器3粉尘",0,10352,1,3280,0,328,"com.hzmr.monsterwar.surprise170"],
    [221,6,176,328,0,"328金装帽子1粉尘",0,10353,1,3280,0,328,"com.hzmr.monsterwar.surprise171"],
    [222,6,177,328,0,"328金装帽子2粉尘",0,10354,1,3280,0,328,"com.hzmr.monsterwar.surprise172"],
    [223,6,178,328,0,"328金装帽子3粉尘",0,10355,1,3280,0,328,"com.hzmr.monsterwar.surprise173"],
    [224,6,179,328,0,"328金装武器1铸币",0,10356,1,3280,0,328,"com.hzmr.monsterwar.surprise174"],
    [225,6,180,328,0,"328金装武器2铸币",0,10357,1,3280,0,328,"com.hzmr.monsterwar.surprise175"],
    [226,6,181,328,0,"328金装武器3铸币",0,10358,1,3280,0,328,"com.hzmr.monsterwar.surprise176"],
    [227,6,182,328,0,"328金装帽子1铸币",0,10359,1,3280,0,328,"com.hzmr.monsterwar.surprise177"],
    [228,6,183,328,0,"328金装帽子2铸币",0,10360,1,3280,0,328,"com.hzmr.monsterwar.surprise178"],
    [229,6,184,328,0,"328金装帽子3铸币",0,10361,1,3280,0,328,"com.hzmr.monsterwar.surprise179"],
    [230,6,185,328,0,"328抽卡",0,10362,1,3280,0,328,"com.hzmr.monsterwar.surprise180"],
    [231,6,186,328,0,"328大粉尘",0,10363,1,3280,0,328,"com.hzmr.monsterwar.surprise181"],
    [232,6,187,328,0,"328金+装武器1经验",0,10364,1,3280,0,328,"com.hzmr.monsterwar.surprise182"],
    [233,6,188,328,0,"328金+装武器2经验",0,10365,1,3280,0,328,"com.hzmr.monsterwar.surprise183"],
    [234,6,189,328,0,"328金+装武器3经验",0,10366,1,3280,0,328,"com.hzmr.monsterwar.surprise184"],
    [235,6,190,328,0,"328金+装帽子1经验",0,10367,1,3280,0,328,"com.hzmr.monsterwar.surprise185"],
    [236,6,191,328,0,"328金+装帽子2经验",0,10368,1,3280,0,328,"com.hzmr.monsterwar.surprise186"],
    [237,6,192,328,0,"328金+装帽子3经验",0,10369,1,3280,0,328,"com.hzmr.monsterwar.surprise187"],
    [238,6,193,328,0,"328金+装武器1粉尘",0,10370,1,3280,0,328,"com.hzmr.monsterwar.surprise188"],
    [239,6,194,328,0,"328金+装武器2粉尘",0,10371,1,3280,0,328,"com.hzmr.monsterwar.surprise189"],
    [240,6,195,328,0,"328金+装武器3粉尘",0,10372,1,3280,0,328,"com.hzmr.monsterwar.surprise190"],
    [241,6,196,328,0,"328金+装帽子1粉尘",0,10373,1,3280,0,328,"com.hzmr.monsterwar.surprise191"],
    [242,6,197,328,0,"328金+装帽子2粉尘",0,10374,1,3280,0,328,"com.hzmr.monsterwar.surprise192"],
    [243,6,198,328,0,"328金+装帽子3粉尘",0,10375,1,3280,0,328,"com.hzmr.monsterwar.surprise193"],
    [244,6,199,328,0,"328金+装武器1铸币",0,10376,1,3280,0,328,"com.hzmr.monsterwar.surprise194"],
    [245,6,200,328,0,"328金+装武器2铸币",0,10377,1,3280,0,328,"com.hzmr.monsterwar.surprise195"],
    [246,6,201,328,0,"328金+装武器3铸币",0,10378,1,3280,0,328,"com.hzmr.monsterwar.surprise196"],
    [247,6,202,328,0,"328金+装帽子1铸币",0,10379,1,3280,0,328,"com.hzmr.monsterwar.surprise197"],
    [248,6,203,328,0,"328金+装帽子2铸币",0,10380,1,3280,0,328,"com.hzmr.monsterwar.surprise198"],
    [249,6,204,328,0,"328金+装帽子3铸币",0,10381,1,3280,0,328,"com.hzmr.monsterwar.surprise199"],
    [250,6,205,328,0,"328抽卡",0,10382,1,3280,0,328,"com.hzmr.monsterwar.surprise200"],
    [251,6,206,648,0,"648大粉尘",0,10383,1,6480,0,648,"com.hzmr.monsterwar.surprise201"],
    [252,6,207,648,0,"648金装武器1经验",0,10384,1,6480,0,648,"com.hzmr.monsterwar.surprise202"],
    [253,6,208,648,0,"648金装武器2经验",0,10385,1,6480,0,648,"com.hzmr.monsterwar.surprise203"],
    [254,6,209,648,0,"648金装武器3经验",0,10386,1,6480,0,648,"com.hzmr.monsterwar.surprise204"],
    [255,6,210,648,0,"648金装帽子1经验",0,10387,1,6480,0,648,"com.hzmr.monsterwar.surprise205"],
    [256,6,211,648,0,"648金装帽子2经验",0,10388,1,6480,0,648,"com.hzmr.monsterwar.surprise206"],
    [257,6,212,648,0,"648金装帽子3经验",0,10389,1,6480,0,648,"com.hzmr.monsterwar.surprise207"],
    [258,6,213,648,0,"648金装武器1粉尘",0,10390,1,6480,0,648,"com.hzmr.monsterwar.surprise208"],
    [259,6,214,648,0,"648金装武器2粉尘",0,10391,1,6480,0,648,"com.hzmr.monsterwar.surprise209"],
    [260,6,215,648,0,"648金装武器3粉尘",0,10392,1,6480,0,648,"com.hzmr.monsterwar.surprise210"],
    [261,6,216,648,0,"648金装帽子1粉尘",0,10393,1,6480,0,648,"com.hzmr.monsterwar.surprise211"],
    [262,6,217,648,0,"648金装帽子2粉尘",0,10394,1,6480,0,648,"com.hzmr.monsterwar.surprise212"],
    [263,6,218,648,0,"648金装帽子3粉尘",0,10395,1,6480,0,648,"com.hzmr.monsterwar.surprise213"],
    [264,6,219,648,0,"648金装武器1铸币",0,10396,1,6480,0,648,"com.hzmr.monsterwar.surprise214"],
    [265,6,220,648,0,"648金装武器2铸币",0,10397,1,6480,0,648,"com.hzmr.monsterwar.surprise215"],
    [266,6,221,648,0,"648金装武器3铸币",0,10398,1,6480,0,648,"com.hzmr.monsterwar.surprise216"],
    [267,6,222,648,0,"648金装帽子1铸币",0,10399,1,6480,0,648,"com.hzmr.monsterwar.surprise217"],
    [268,6,223,648,0,"648金装帽子2铸币",0,10400,1,6480,0,648,"com.hzmr.monsterwar.surprise218"],
    [269,6,224,648,0,"648金装帽子3铸币",0,10401,1,6480,0,648,"com.hzmr.monsterwar.surprise219"],
    [270,6,225,648,0,"648抽卡",0,10402,1,6480,0,648,"com.hzmr.monsterwar.surprise220"],
    [271,6,226,648,0,"648大粉尘",0,10403,1,6480,0,648,"com.hzmr.monsterwar.surprise221"],
    [272,6,227,648,0,"648金+装武器1经验",0,10404,1,6480,0,648,"com.hzmr.monsterwar.surprise222"],
    [273,6,228,648,0,"648金+装武器2经验",0,10405,1,6480,0,648,"com.hzmr.monsterwar.surprise223"],
    [274,6,229,648,0,"648金+装武器3经验",0,10406,1,6480,0,648,"com.hzmr.monsterwar.surprise224"],
    [275,6,230,648,0,"648金+装帽子1经验",0,10407,1,6480,0,648,"com.hzmr.monsterwar.surprise225"],
    [276,6,231,648,0,"648金+装帽子2经验",0,10408,1,6480,0,648,"com.hzmr.monsterwar.surprise226"],
    [277,6,232,648,0,"648金+装帽子3经验",0,10409,1,6480,0,648,"com.hzmr.monsterwar.surprise227"],
    [278,6,233,648,0,"648金+装武器1粉尘",0,10410,1,6480,0,648,"com.hzmr.monsterwar.surprise228"],
    [279,6,234,648,0,"648金+装武器2粉尘",0,10411,1,6480,0,648,"com.hzmr.monsterwar.surprise229"],
    [280,6,235,648,0,"648金+装武器3粉尘",0,10412,1,6480,0,648,"com.hzmr.monsterwar.surprise230"],
    [281,6,236,648,0,"648金+装帽子1粉尘",0,10413,1,6480,0,648,"com.hzmr.monsterwar.surprise231"],
    [282,6,237,648,0,"648金+装帽子2粉尘",0,10414,1,6480,0,648,"com.hzmr.monsterwar.surprise232"],
    [283,6,238,648,0,"648金+装帽子3粉尘",0,10415,1,6480,0,648,"com.hzmr.monsterwar.surprise233"],
    [284,6,239,648,0,"648金+装武器1铸币",0,10416,1,6480,0,648,"com.hzmr.monsterwar.surprise234"],
    [285,6,240,648,0,"648金+装武器2铸币",0,10417,1,6480,0,648,"com.hzmr.monsterwar.surprise235"],
    [286,6,241,648,0,"648金+装武器3铸币",0,10418,1,6480,0,648,"com.hzmr.monsterwar.surprise236"],
    [287,6,242,648,0,"648金+装帽子1铸币",0,10419,1,6480,0,648,"com.hzmr.monsterwar.surprise237"],
    [288,6,243,648,0,"648金+装帽子2铸币",0,10420,1,6480,0,648,"com.hzmr.monsterwar.surprise238"],
    [289,6,244,648,0,"648金+装帽子3铸币",0,10421,1,6480,0,648,"com.hzmr.monsterwar.surprise239"],
    [290,6,245,648,0,"648抽卡",0,10422,1,6480,0,648,"com.hzmr.monsterwar.surprise240"],
    [291,6,246,68,0,"68抽卡",0,10426,1,680,0,68,"com.hzmr.monsterwar.surprise241"],
    [292,6,247,128,0,"抽卡",0,10427,1,1280,0,128,"com.hzmr.monsterwar.surprise242"],
    [293,6,248,328,0,"328抽卡",0,10428,1,3280,0,328,"com.hzmr.monsterwar.surprise243"],
    [294,6,249,648,0,"648抽卡",0,10429,1,6480,0,648,"com.hzmr.monsterwar.surprise244"],
    [295,6,250,6,0,"6块4进度",0,10430,1,60,0,6,"com.hzmr.monsterwar.surprise245"],
    [296,12,3,128,8,"棋盘寻宝128",2,10431,1,1280,0,128,"com.hzmr.monsterwar.board3"],
    [297,12,4,328,8,"棋盘寻宝328",0,10432,1,3280,0,328,"com.hzmr.monsterwar.board4"],
    [298,12,5,648,8,"棋盘寻宝648",0,10433,1,6480,0,648,"com.hzmr.monsterwar.board5"],
    [299,12,3,128,7,"夺宝奇兵128",2,10434,1,1280,0,128,"com.hzmr.monsterwar.duobao3"],
    [300,12,4,328,7,"夺宝奇兵328",0,10435,1,3280,0,328,"com.hzmr.monsterwar.duobao4"],
    [301,12,5,648,7,"夺宝奇兵648",0,10436,1,6480,0,648,"com.hzmr.monsterwar.duobao5"],
    [302,13,1,30,0,"净化先锋小礼物",0,10437,1,300,0,30,"com.hzmr.monsterwar.jinghua1"],
    [303,5,5,6,0,"新手超值礼包",0,10459,1,60,0,25,"com.hzmr.monsterwar.bag10"],
    [304,6,251,128,0,"128抽卡",0,10460,1,1280,0,128,"com.hzmr.monsterwar.surprise246"],
    [305,6,252,128,0,"128抽卡",0,10461,1,1280,0,128,"com.hzmr.monsterwar.surprise247"],
    [306,12,1,6,12,"探趣寻宝6块",2,10466,1,60,0,6,"com.hzmr.monsterwar.xunbao1"],
    [307,12,2,30,12,"探趣寻宝30块",3,10467,1,300,0,30,"com.hzmr.monsterwar.xunbao2"],
    [308,12,3,128,12,"探趣寻宝128",0,10468,1,1280,0,128,"com.hzmr.monsterwar.xunbao3"],
    [309,12,4,328,12,"探趣寻宝328",0,10469,1,3280,0,328,"com.hzmr.monsterwar.xunbao4"],
    [310,12,5,648,12,"探趣寻宝648",0,10470,1,6480,0,648,"com.hzmr.monsterwar.xunbao5"],
    [311,14,1,24,0,"新手基金",1,10471,1,240,0,24,"com.hzmr.monsterwar.newplayer1"],
    [312,15,1,12,0,"周卡",0,10002,120,120,0,12,"com.hzmr.monsterwar.w1"],
    [316,10,11,648,0,"每周扭蛋券礼包",3,10494,1,6480,0,648,"com.hzmr.monsterwar.week11"],
    [317,11,13,648,0,"每月扭蛋券礼包",5,10495,1,6480,0,648,"com.hzmr.monsterwar.month13"],
    [318,12,1,68,23,"联盟抽卡开服礼包68",5,10500,1,680,0,68,"com.hzmr.kaifuactivity.gift1"],
    [319,12,2,198,23,"联盟抽卡开服礼包198",5,10501,1,1980,0,198,"com.hzmr.kaifuactivity.gift2"],
    [320,12,3,328,23,"联盟抽卡开服礼包328",5,10502,1,3280,0,328,"com.hzmr.kaifuactivity.gift3"],
    [321,12,4,648,23,"联盟抽卡开服礼包648",5,10503,1,6480,0,648,"com.hzmr.kaifuactivity.gift4"],
    [322,17,1,198,0,"终生卡",0,10002,1980,1980,0,198,"com.hzmr.monsterwar.entire1"],
    [323,18,1,68,24,"世界树馈赠月令",0,10002,0,680,0,68,"com.hzmr.monsterwar.worldtree1"],
    [324,12,1,30,14,"寻宝币礼包30",2,10531,1,300,0,30,"com.hzmr.xunbaoqingdian.gift1"],
    [325,12,2,68,14,"寻宝币礼包68",5,10532,1,680,0,68,"com.hzmr.xunbaoqingdian.gift2"],
    [326,12,3,198,14,"寻宝币礼包198",5,10533,1,1980,0,198,"com.hzmr.xunbaoqingdian.gift3"],
    [327,12,4,328,14,"寻宝币礼包328",5,10534,1,3280,0,328,"com.hzmr.xunbaoqingdian.gift4"],
    [328,12,5,648,14,"寻宝币礼包648",0,10535,1,6480,0,648,"com.hzmr.xunbaoqingdian.gift5"],
    [329,19,1,98,0,"莫莉卡",1,50002,1,980,0,98,"com.hzmr.shizhuangdian.cloth1"],
    [330,20,1,78,0,"主线战令",0,10002,0,780,0,78,"com.hzmr.zhanling.zhuxian1"],
    [331,20,2,78,0,"主线战令",0,10002,0,780,0,78,"com.hzmr.zhanling.zhuxian2"],
    [332,20,3,78,0,"主线战令",0,10002,0,780,0,78,"com.hzmr.zhanling.zhuxian3"],
    [333,20,4,78,0,"主线战令",0,10002,0,780,0,78,"com.hzmr.zhanling.zhuxian4"],
    [334,20,5,78,0,"主线战令",0,10002,0,780,0,78,"com.hzmr.zhanling.zhuxian5"],
    [335,20,1,78,0,"摩天楼战令",0,10002,0,780,0,78,"com.hzmr.zhanling.motianlou1"],
    [336,20,2,78,0,"摩天楼战令",0,10002,0,780,0,78,"com.hzmr.zhanling.motianlou2"],
    [337,20,3,78,0,"摩天楼战令",0,10002,0,780,0,78,"com.hzmr.zhanling.motianlou3"],
    [338,20,4,78,0,"摩天楼战令",0,10002,0,780,0,78,"com.hzmr.zhanling.motianlou4"],
    [339,20,5,78,0,"摩天楼战令",0,10002,0,780,0,78,"com.hzmr.zhanling.motianlou5"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new storeConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    storeConfig .push(r);

}

export default storeConfig
