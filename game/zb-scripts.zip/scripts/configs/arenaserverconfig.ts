const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","competition","server",]

export class arenaserverconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 赛区ID
         **/
        @SafeProperty
        competition?:number

        /**
         * 服务器
         **/
        @SafeProperty
        server?:number[]

}

let arenaserverconfig:arenaserverconfigRow []=[];

var rowData=
[
    [1,1,[1,5]],
    [2,2,[6,10]],
    [3,3,[11,15]],
    [4,4,[16,20]],
    [5,5,[21,25]],
    [6,6,[26,30]],
    [7,7,[31,35]],
    [8,8,[36,40]],
    [9,9,[41,45]],
    [10,10,[46,50]],
    [11,11,[51,55]],
    [12,12,[56,60]],
    [13,13,[61,65]],
    [14,14,[66,70]],
    [15,15,[71,75]],
    [16,16,[76,80]],
    [17,17,[81,85]],
    [18,18,[86,90]],
    [19,19,[91,95]],
    [20,20,[96,100]],
    [21,21,[101,105]],
    [22,22,[106,110]],
    [23,23,[111,115]],
    [24,24,[116,120]],
    [25,25,[121,125]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new arenaserverconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    arenaserverconfig .push(r);

}

export default arenaserverconfig
