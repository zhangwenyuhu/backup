const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","eventID","eventdes","effectdes",]

export class boardeventconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 事件ID
         **/
        @SafeProperty
        eventID?:number

        /**
         * 事件描述
         **/
        @SafeProperty
        eventdes?:string

        /**
         * 效果描述
         **/
        @SafeProperty
        effectdes?:string

}

let boardeventconfig:boardeventconfigRow []=[];

var rowData=
[
    [1,1001,"蘑菇屋","经过或者停留时可以获得星星，停留时\r\n可以升级1次蘑菇屋，最多升至3级，等级\r\n越高，每次获得的星星越多"],
    [2,2001,"心意小屋","停留时可以获得一个普通骰子"],
    [3,3001,"幸运小屋","停留时可以获得一个幸运骰子"],
    [4,4001,"正邪小屋","停留时将会进行一次判定，\r\n单数前进一格，双数后退一格"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new boardeventconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    boardeventconfig .push(r);

}

export default boardeventconfig
