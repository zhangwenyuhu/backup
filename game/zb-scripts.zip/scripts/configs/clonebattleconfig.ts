const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","stagenumber","rank","level","equip","reward",]

export class clonebattleconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 波数
         **/
        @SafeProperty
        stagenumber?:number

        /**
         * 品阶
         **/
        @SafeProperty
        rank?:number

        /**
         * 等级
         **/
        @SafeProperty
        level?:number

        /**
         * 装备
         **/
        @SafeProperty
        equip?:any

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:number

}

let clonebattleconfig:clonebattleconfigRow []=[];

var rowData=
[
    [1,1,3,30,[[30321,0],[30322,0],[30323,0],[30324,0]]],
    [2,2,4,40,[[30421,0],[30422,0],[30423,0],[30424,0]]],
    [3,3,5,60,[[30521,0],[30522,0],[30523,0],[30524,0]],2],
    [4,4,6,60,[[30521,0],[30522,0],[30523,0],[30524,0]]],
    [5,5,6,70,[[30521,0],[30522,0],[30523,0],[30524,0]]],
    [6,6,6,80,[[30621,0],[30622,0],[30623,0],[30624,0]],2],
    [7,7,7,100,[[30621,0],[30622,0],[30623,0],[30624,0]]],
    [8,8,8,100,[[30621,0],[30622,0],[30623,0],[30624,0]]],
    [9,9,10,120,[[30621,0],[30622,0],[30623,0],[30624,0]],2],
    [10,10,11,140,[[30721,0],[30722,0],[30723,0],[30724,0]]],
    [11,11,13,180,[[30821,0],[30822,0],[30823,0],[30824,0]]],
    [12,12,16,220,[[30821,0],[30822,0],[30823,0],[30824,0]],2],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new clonebattleconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    clonebattleconfig .push(r);

}

export default clonebattleconfig
