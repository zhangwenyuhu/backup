const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","costmoney","costlevel",]

export class costlevelconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 总消费间隔
         **/
        @SafeProperty
        costmoney?:any

        /**
         * 消费档位
         **/
        @SafeProperty
        costlevel?:number

}

let costlevelconfig:costlevelconfigRow []=[];

var rowData=
[
    [1,[0,5],1],
    [2,[6,30],2],
    [3,[31,128],3],
    [4,[129,328],4],
    [5,[329,648],5],
    [6,[649,99999999],6],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new costlevelconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    costlevelconfig .push(r);

}

export default costlevelconfig
