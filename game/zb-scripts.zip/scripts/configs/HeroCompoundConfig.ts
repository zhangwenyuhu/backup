const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","CompoundHero","HeroSpend",]

export class HeroCompoundConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 合成目标
         **/
        @SafeProperty
        CompoundHero?:number

        /**
         * 消耗材料1
作者:
默认主卡位是第一个
         **/
        @SafeProperty
        HeroSpend?:any[]

}

let HeroCompoundConfig:HeroCompoundConfigRow []=[];

var rowData=
[
    [1,20054,[[20033,1,4],[20034,1,4],[20035,1,4]]],
    [2,20057,[[20006,1,4],[20008,1,4],[20009,1,4]]],
    [3,20056,[[20016,1,4],[20017,1,4],[20018,1,4]]],
    [4,20064,[[20025,1,4],[20026,1,4],[20045,1,4]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new HeroCompoundConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    HeroCompoundConfig .push(r);

}

export default HeroCompoundConfig
