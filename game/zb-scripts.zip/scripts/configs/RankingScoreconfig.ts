const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","totalscore","CityID","tower","diamond","abandon",]

export class RankingScoreconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 英雄总积分
         **/
        @SafeProperty
        totalscore?:number

        /**
         * 章节
         **/
        @SafeProperty
        CityID?:number

        /**
         * 摩天楼
         **/
        @SafeProperty
        tower?:number

        /**
         * 钻石奖励
         **/
        @SafeProperty
        diamond?:number

        /**
         * 废弃
         **/
        @SafeProperty
        abandon?:bool

}

let RankingScoreconfig:RankingScoreconfigRow []=[];

var rowData=
[
    [1,5800,0,0,20],
    [2,9800,0,0,20],
    [3,13800,0,0,20],
    [4,17800,0,0,20],
    [5,21800,0,0,20],
    [6,25800,0,0,20],
    [7,29800,0,0,20],
    [8,33800,0,0,20],
    [9,37800,0,0,20],
    [10,41800,0,0,20],
    [11,45800,0,0,20],
    [12,0,1,0,20],
    [13,0,2,0,20],
    [14,0,3,0,20],
    [15,0,4,0,20],
    [16,0,5,0,20],
    [17,0,6,0,20],
    [18,0,7,0,20],
    [19,0,8,0,20],
    [20,0,9,0,20],
    [21,0,10,0,20],
    [22,0,11,0,20],
    [23,0,12,0,20],
    [24,0,13,0,20],
    [25,0,14,0,20],
    [26,0,15,0,20],
    [27,0,16,0,20],
    [32,0,0,100,20],
    [33,0,0,125,20],
    [34,0,0,150,20],
    [35,0,0,175,20],
    [36,0,0,200,20],
    [37,0,0,225,20],
    [38,0,0,250,20],
    [39,0,0,275,20],
    [40,0,0,300,20],
    [41,0,0,325,20],
    [42,0,0,350,20],
    [43,0,0,375,20],
    [44,0,0,400,20],
    [45,0,0,425,20],
    [46,0,0,450,20],
    [47,0,0,475,20],
    [48,0,0,500,20],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new RankingScoreconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    RankingScoreconfig .push(r);

}

export default RankingScoreconfig
