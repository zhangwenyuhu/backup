const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","type","name","require",]

export class medaltechinfoconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 战略分类
         **/
        @SafeProperty
        type?:number

        /**
         * 战略大类名
         **/
        @SafeProperty
        name?:string

        /**
         * 所需前一战略进度
         **/
        @SafeProperty
        require?:number

}

let medaltechinfoconfig:medaltechinfoconfigRow []=[];

var rowData=
[
    [1,1,"基础战略"],
    [2,2,"联盟战略",15],
    [3,3,"职责战略",20],
    [4,4,"大师战略",25],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new medaltechinfoconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    medaltechinfoconfig .push(r);

}

export default medaltechinfoconfig
