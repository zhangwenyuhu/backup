const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","playerlevel","weapen","hat","armor","shoes",]

export class soldierconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 等级
         **/
        @SafeProperty
        playerlevel?:any

        /**
         * 武器
         **/
        @SafeProperty
        weapen?:number

        /**
         * 帽子
         **/
        @SafeProperty
        hat?:number

        /**
         * 衣服
         **/
        @SafeProperty
        armor?:number

        /**
         * 鞋子
         **/
        @SafeProperty
        shoes?:number

}

let soldierconfig:soldierconfigRow []=[];

var rowData=
[
    [1,[[30,80]],3,3,3,3],
    [2,[[81,100]],4,4,3,3],
    [3,[[100,120]],5,5,4,4],
    [4,[[120,140]],6,6,4,4],
    [5,[[141,160]],7,7,5,5],
    [6,[[161,180]],8,8,5,5],
    [7,[[181,200]],8,8,6,6],
    [8,[[201,220]],8,8,8,8],
    [9,[[221,240]],9,9,8,8],
    [10,[[240,300]],9,9,9,9],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new soldierconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    soldierconfig .push(r);

}

export default soldierconfig
