const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","tasktypeID","value","vitality","unlock",]

export class DailytaskconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 任务类型ID
         **/
        @SafeProperty
        tasktypeID?:number

        /**
         * 条件参数
         **/
        @SafeProperty
        value?:string

        /**
         * 活跃度奖励
         **/
        @SafeProperty
        vitality?:number

        /**
         * 解锁等级
         **/
        @SafeProperty
        unlock?:string

}

let Dailytaskconfig:DailytaskconfigRow []=[];

var rowData=
[
    [1,1001,"1",10,"2-2"],
    [2,1003,"3",10,"2-2"],
    [3,1004,"1",10,"2-2"],
    [4,1007,"2",10,"2-2"],
    [5,1008,"3",10,"2-2"],
    [6,1009,"1",10,"2-2"],
    [7,1010,"3",10,"2-2"],
    [8,1011,"3",10,"2-2"],
    [9,1012,"1",10,"2-2"],
    [10,1013,"2",10,"2-2"],
    [11,2001,"3",15,"2-2"],
    [12,2003,"10",10,"2-2"],
    [13,2004,"30",10,"2-2"],
    [14,2006,"10",10,"2-2"],
    [15,2007,"1",10,"2-2"],
    [16,2008,"25",10,"2-2"],
    [17,2010,"3",10,"2-2"],
    [18,2011,"3",10,"2-2"],
    [19,2012,"25",15,"2-2"],
    [20,2013,"30",10,"2-2"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new DailytaskconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    Dailytaskconfig .push(r);

}

export default Dailytaskconfig
