const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","ScoreRank","Reward",]

export class battlescoreconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 战力排名
         **/
        @SafeProperty
        ScoreRank?:any

        /**
         * 奖励
         **/
        @SafeProperty
        Reward?:any

}

let battlescoreconfig:battlescoreconfigRow []=[];

var rowData=
[
    [1,[1,1],[[10135,180],[10103,120],[30911,1]]],
    [2,[2,2],[[10135,60],[10103,120],[30811,1]]],
    [3,[3,3],[[10135,60],[10103,60],[30811,1]]],
    [4,[4,10],[[10103,60],[10039,2],[30812,1]]],
    [5,[11,20],[[10103,60],[10037,3],[10008,500]]],
    [6,[21,50],[[10103,60],[10037,1]]],
    [7,[51,100],[[10060,60],[10047,1]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new battlescoreconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    battlescoreconfig .push(r);

}

export default battlescoreconfig
