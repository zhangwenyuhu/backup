const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","spacename","stageunlock","scheduleunlock","desc",]

export class spacetimeconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 时空名称
         **/
        @SafeProperty
        spacename?:string

        /**
         * 关卡解锁
         **/
        @SafeProperty
        stageunlock?:number

        /**
         * 前一章进度解锁
         **/
        @SafeProperty
        scheduleunlock?:number

        /**
         * 描述
         **/
        @SafeProperty
        desc?:string

}

let spacetimeconfig:spacetimeconfigRow []=[];

var rowData=
[
    [1,"海盗港湾",156,0.6,"近日，我市出现了多起盗窃案，据知情人士透露，在海盗港湾大量出现这些被盗物资。事件真相是什么，快和我们的英雄一探究竟吧！"],
    [2,"丛林沼泽",196,0.6,"氤氲的空气中透漏着果子腐烂的酸臭味，就算最优秀的猎手也会在这里迷失方向。"],
    [3,"秘境探险",236,0.6,"人们对秘境的了解，目前还只停留在道听途说的层面，据说只有通过秘境试炼真正的勇士，才能窥见他最深的秘密。"],
    [4,"冢墓幽地",276,0.6,"冢墓是僵尸的窝点，为防止入侵，他们设下重重陷阱。有人说，他们只是喜欢风经过后会“呜呜”作响的声音，也有人说，他们在守着什么宝贝。"],
    [5,"功夫世界",316,0.6,"暂未开放"],
    [6,"神秘埃及",316,0.6,"暂未开放"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new spacetimeconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    spacetimeconfig .push(r);

}

export default spacetimeconfig
