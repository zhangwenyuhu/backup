const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","tasktype","parameter","lasttask","nexttask","refresh","reward",]

export class boardtaskconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 任务类型
         **/
        @SafeProperty
        tasktype?:number

        /**
         * 任务参数
         **/
        @SafeProperty
        parameter?:number

        /**
         * 前置任务
         **/
        @SafeProperty
        lasttask?:number

        /**
         * 后置任务
         **/
        @SafeProperty
        nexttask?:number

        /**
         * 是否每日刷新
         **/
        @SafeProperty
        refresh?:number

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:any

}

let boardtaskconfig:boardtaskconfigRow []=[];

var rowData=
[
    [10001,6001,100,0,0,1,[[10148,2]]],
    [10002,1009,2,0,0,1,[[10148,2]]],
    [10003,6002,1,0,100031,0,[[10148,2]]],
    [100031,6002,2,10003,100032,0,[[10148,2]]],
    [100032,6002,3,100031,0,0,[[10149,1]]],
    [10004,6003,2,0,0,1,[[10148,1]]],
    [10005,6004,1,0,10006,1,[[10148,1]]],
    [10006,6004,2,10005,0,1,[[10148,2]]],
    [10007,6005,2,0,10008,1,[[10148,1]]],
    [10008,6005,5,10007,10009,1,[[10148,2]]],
    [10009,6005,10,10008,0,1,[[10149,1]]],
    [10010,6006,1,0,10011,0,[[10148,1]]],
    [10011,6006,2,10010,10012,0,[[10148,2]]],
    [10012,6006,3,10011,10013,0,[[10148,2]]],
    [10013,6006,5,10012,10014,0,[[10148,2]]],
    [10014,6006,8,10013,10015,0,[[10149,1]]],
    [10015,6006,10,10014,0,0,[[10149,1]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new boardtaskconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    boardtaskconfig .push(r);

}

export default boardtaskconfig
