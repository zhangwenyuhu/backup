const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","event","score","leveldes",]

export class spacetimeExploreConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 事件
         **/
        @SafeProperty
        event?:number

        /**
         * 分数
         **/
        @SafeProperty
        score?:number

        /**
         * 关卡描述
         **/
        @SafeProperty
        leveldes?:string

}

let spacetimeExploreConfig:spacetimeExploreConfigRow []=[];

var rowData=
[
    [1,1001,10,"一群普通的怪物，有时候打败他们是你继续前进的唯一选择"],
    [2,1002,20,"一群精英级别的怪物，稍有不慎，你可能会被他们狠揍一顿"],
    [3,1003,20,"这些是首领级别的怪物，你可千万别轻易尝试挑战他们"],
    [4,1004,15,""],
    [5,1005,15,""],
    [6,1006,15,""],
    [7,1007,10,""],
    [8,1008,20,""],
    [9,1009,10,""],
    [10,1010,30,""],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new spacetimeExploreConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    spacetimeExploreConfig .push(r);

}

export default spacetimeExploreConfig
