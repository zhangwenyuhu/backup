const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","videotime","describe",]

export class videoconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 次数
         **/
        @SafeProperty
        videotime?:number

        /**
         * 视频点描述
         **/
        @SafeProperty
        describe?:string

}

let videoconfig:videoconfigRow []=[];

var rowData=
[
    [1,5,"酒馆每日看视频抽取英雄次数上限"],
    [2,0,"看视频快速挂机每日次数上限"],
    [3,5,"智慧树中看视频复活英雄每日次数上限"],
    [4,1,"悬赏每日视频刷新次数上限"],
    [5,5,"悬赏每日看视频快速完成次数上限"],
    [6,1,"商店每日视频购买次数上限"],
    [7,5,"视频礼包"],
    [8,3,"看视频获得骰子"],
    [9,0,"奇妙时空复活"],
    [10,3,"视频礼包新的次数"],
    [11,1,"公会转盘次数"],
    [12,1,"公会雕像花瓣部位属性加成"],
    [13,1,"公会雕像枝干部位属性加成"],
    [14,1,"公会雕像花根部位属性加成"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new videoconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    videoconfig .push(r);

}

export default videoconfig
