const { SafeProperty } = slib;

import giftConfig,{giftConfigRow} from "./giftConfig"

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","days","giftId",]

export class sevenDaysSignConfigRow{

        /**
         * 参数ID
         **/
        @SafeProperty
        Id?:uid

        /**
         * 累计签到天数
         **/
        @SafeProperty
        days?:number

        /**
         * 礼包
         **/
        @SafeProperty
        giftId?:fk

        protected _fkgiftId?:giftConfigRow=undefined
        /**
         * 礼包
         **/
        get giftIdData(){
            if(this._fkgiftId===undefined){
                this._fkgiftId=giftConfig.find(a=>a.Id==this.giftId);
            }
            return this._fkgiftId;
        }

}

let sevenDaysSignConfig:sevenDaysSignConfigRow []=[];

var rowData=
[
    [1,1,11],
    [2,2,12],
    [3,3,13],
    [4,4,14],
    [5,5,15],
    [6,6,16],
    [7,7,17],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new sevenDaysSignConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    sevenDaysSignConfig .push(r);

}

export default sevenDaysSignConfig
