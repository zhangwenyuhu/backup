const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","type","ranking","reward",]

export class factionbattlerewardconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 奖励类型（1公会排名2个人排名）
         **/
        @SafeProperty
        type?:number

        /**
         * 排名名次
         **/
        @SafeProperty
        ranking?:number

        /**
         * 奖励内容
         **/
        @SafeProperty
        reward?:any

}

let factionbattlerewardconfig:factionbattlerewardconfigRow []=[];

var rowData=
[
    [1,1,1,[[10002,100],[10003,1000]]],
    [2,1,2,[[10002,100],[10003,1000]]],
    [3,1,3,[[10002,100],[10003,1000]]],
    [4,2,1,[[10002,100],[10003,1000]]],
    [5,2,2,[[10002,100],[10003,1000]]],
    [6,2,3,[[10002,100],[10003,1000]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new factionbattlerewardconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    factionbattlerewardconfig .push(r);

}

export default factionbattlerewardconfig
