const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","Bufflevel","harm","Buffeffect",]

export class huntbossbuffRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * buff层数范围
         **/
        @SafeProperty
        Bufflevel?:number[]

        /**
         * 每损失血量叠加1层
         **/
        @SafeProperty
        harm?:number

        /**
         * buff效果
         **/
        @SafeProperty
        Buffeffect?:number

}

let huntbossbuff:huntbossbuffRow []=[];

var rowData=
[
    [1,[1,2],5000,0.1],
    [2,[3,5],10000,0.1],
    [3,[6,20],50000,0.1],
    [4,[21,100],150000,0.1],
    [5,[101,500],300000,0.1],
    [6,[501,1000],400000,0.1],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new huntbossbuffRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    huntbossbuff .push(r);

}

export default huntbossbuff
