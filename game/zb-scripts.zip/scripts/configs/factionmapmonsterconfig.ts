const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","monster","level",]

export class factionmapmonsterconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 阵容
         **/
        @SafeProperty
        monster?:any

        /**
         * 等级
         **/
        @SafeProperty
        level?:any

}

let factionmapmonsterconfig:factionmapmonsterconfigRow []=[];

var rowData=
[
    [1001,[991001,992001,993001,994001,995001],[100,100,100,100,100]],
    [1002,[991001,992001,993001,994001,995001],[100,100,100,100,100]],
    [1003,[991001,992001,993001,994001,995001],[100,100,100,100,100]],
    [1004,[991001,992001,993001,994001,995001],[100,100,100,100,100]],
    [1005,[991001,992001,993001,994001,995001],[100,100,100,100,100]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new factionmapmonsterconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    factionmapmonsterconfig .push(r);

}

export default factionmapmonsterconfig
