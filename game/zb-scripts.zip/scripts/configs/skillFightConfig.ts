const { SafeClass, decryptTable ,SafeProperty} = slib;



type uid=number;
type key=string;
type fk=number;
 
var fields =["id","name","skillConfig","skillType","annotation","description","priority","startCd","intervalCd","distance","consumeEnergy",]

export class skillFightConfigRow{
	
    
        /**
         * 键
         **/
        
        id?:uid=null

        
        
    
        /**
         * 技能名称
         **/
        @SafeProperty
        name?:string=null

        
        
    
        /**
         * 技能树配置
         **/
        @SafeProperty
        skillConfig?:string=null

        
        
    
        /**
         * 技能类型(initiative/passive)
         **/
        @SafeProperty
        skillType?:string=null

        
        
    
        /**
         * 备注
         **/
        @SafeProperty
        annotation?:string=null

        
        
    
        /**
         * 技能描述
         **/
        @SafeProperty
        description?:string=null

        
        
    
        /**
         * 技能优先级
         **/
        @SafeProperty
        priority?:number=null

        
        
    
        /**
         * 进入游戏的初始CD ms
         **/
        @SafeProperty
        startCd?:number=null

        
        
    
        /**
         * 间隔CD ms
         **/
        @SafeProperty
        intervalCd?:number=null

        
        
    
        /**
         * 攻击距离
         **/
        @SafeProperty
        distance?:number=null

        
        
    
        /**
         * 消耗能量
         **/
        @SafeProperty
        consumeEnergy?:number=null

        
        
    
}

let skillFightConfig:skillFightConfigRow []=[]


/**
[
    [1000,"普攻","skill_tieshu_attack.tt.yml","initiative","铁树","铁树技能",4,3000,800,100,10],
    [1001,"金枪地刺","skill_tieshu_bskill.tt.yml","initiative","铁树","铁树技能",3,3000,4000,100,11],
    [1002,"百裂突刺","skill_tieshu_sskill1.tt.yml","initiative","铁树","铁树技能",2,3000,8000,100,12],
    [1003,"辅助吸血","skill_tieshu_sskill2.tt.yml","initiative","铁树","铁树技能",1,3000,12000,10000000,13],
    [1004,"普攻","skill_shaseng_attack.tt.yml","initiative","沙僧","沙僧技能",4,3000,800,100,14],
    
]
**/




export function skillFightConfigInit (

    
	key:string='AMhGbf0cnlMCWWviPskillFightConfigGOK+GK*--s8V2wUd',
	data:string='vj6ky4S5gvY63BxR/7vjMnsCUn+sAd+z6NpyDRxG0qXk+KlZbs6+INLgRrOxOmlQVqGAjF0qaHXxR1/E/XU8SrgyZaw0urHcTZjXykvOc/xUzyQA7y0mVmSAaBwtR8kArNVpEkWL4W3ST1ST3AU/MIO9DJT4tiy4cNmiBzb3XKsNB87B4CHrqBByGT7mSyyfwqrO181lrYAJ1eily0d4S730A+G7gZa9dPaRFB2Nd96madQ5+1gh4olOVAP51iw38houz8MvksrPXlG+ShBbyfnUSEmhIMwj+quj5SLay3QXeCMp'
    
){
    let newTable=decryptTable(
        ()=>{
            return new skillFightConfigRow ()
        },
        fields,
        'fmrarm'+key,
        data,true
    ) as skillFightConfigRow []
    for(let r of newTable){
        skillFightConfig .push(r);
        
    }
}

export default skillFightConfig
