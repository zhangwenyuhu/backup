const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","EqStarLv","EqStarNeed","EqStarMasterHP","EqStarMasterATK",]

export class equipstarmasterConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 升星大师等级
         **/
        @SafeProperty
        EqStarLv?:number

        /**
         * 全身装备星级要求
         **/
        @SafeProperty
        EqStarNeed?:number

        /**
         * 星级大师生命加成
         **/
        @SafeProperty
        EqStarMasterHP?:number

        /**
         * 星级大师攻击加成
         **/
        @SafeProperty
        EqStarMasterATK?:number

}

let equipstarmasterConfig:equipstarmasterConfigRow []=[];

var rowData=
[
    [1,1,5,2000,200],
    [2,2,10,5000,500],
    [3,3,15,10000,1000],
    [4,4,20,20000,2000],
    [5,5,25,30000,3000],
    [6,6,30,42000,4000],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new equipstarmasterConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    equipstarmasterConfig .push(r);

}

export default equipstarmasterConfig
