const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","artifactID","artifactLvNeed","artifactComPro",]

export class artifactcompoundConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 共鸣神器ID
         **/
        @SafeProperty
        artifactID?:number[]

        /**
         * 神器等级要求
         **/
        @SafeProperty
        artifactLvNeed?:number

        /**
         * 激活效果
         **/
        @SafeProperty
        artifactComPro?:any

}

let artifactcompoundConfig:artifactcompoundConfigRow []=[];

var rowData=
[
    [1,[40001,40002],1,[[15,0.02],[16,0.02]]],
    [2,[40001,40002],2,[[18,0.02],[19,0.02]]],
    [3,[40001,40002],3,[[2,0.02],[14,0.02]]],
    [4,[40003,40004],1,[[2,0.02],[4,0.02]]],
    [5,[40003,40004],2,[[18,0.02],[19,0.02]]],
    [6,[40003,40004],3,[[2,0.02],[14,0.02]]],
    [7,[40005,40006],1,[[2,0.02],[4,0.02]]],
    [8,[40005,40006],2,[[18,0.02],[19,0.02]]],
    [9,[40005,40006],3,[[2,0.02],[14,0.02]]],
    [10,[40007],1,[[2,0.02],[4,0.02]]],
    [11,[40007],2,[[18,0.02],[19,0.02]]],
    [12,[40007],3,[[2,0.02],[14,0.02]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new artifactcompoundConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    artifactcompoundConfig .push(r);

}

export default artifactcompoundConfig
