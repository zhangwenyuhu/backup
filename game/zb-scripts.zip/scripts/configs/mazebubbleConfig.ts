const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","desc","firsttime","weight","showtime","nterval",]

export class mazebubbleConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 描述
         **/
        @SafeProperty
        desc?:string

        /**
         * 首次触发
         **/
        @SafeProperty
        firsttime?:number

        /**
         * 权重
         **/
        @SafeProperty
        weight?:number

        /**
         * 展示时间
         **/
        @SafeProperty
        showtime?:number

        /**
         * 间隔时间
         **/
        @SafeProperty
        nterval?:number

}

let mazebubbleConfig:mazebubbleConfigRow []=[];

var rowData=
[
    [1,"每通一关，可以获得<color=#F4A460>属性加成果实</c>！",0,1,4,2],
    [2,"选择适合自己的果实，对战斗更有利！",0,1,4,2],
    [3,"每一关结束后，<color=#F4A460>怒气值</c>是可以<color=#F4A460>继承到下一关</c>的！",0,1,4,2],
    [4,"每一关结束后，英雄们的<color=#F4A460>血量</c>是要<color=#F4A460>继承到下一关</c>的！",0,1,4,2],
    [5,"及时调整站位和搭配，可别让你的英雄倒下了！",0,1,4,2],
    [6,"可别忘了！<color=#F4A460>路线选择</c>很重要，千万别错过自己想要的东西！",0,1,4,2],
    [7,"这是蕾姆给你的祝福哦！",0,1,4,2],
    [8,"欢迎来到智慧树！挑战三层BOSS可以获得丰厚奖励！",1,1,4,2],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new mazebubbleConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    mazebubbleConfig .push(r);

}

export default mazebubbleConfig
