const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","numberofplies","reward",]

export class xunbaocengrewardRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 生效层数
zhangchenxue:
数字相同的为同一个奖池
         **/
        @SafeProperty
        numberofplies?:number

        /**
         * 奖励
普通：goodsconfig

         **/
        @SafeProperty
        reward?:any

}

let xunbaocengreward:xunbaocengrewardRow []=[];

var rowData=
[
    [1,1,[[10001,10],[10002,10],[10003,10]]],
    [2,3,[[10001,10],[10002,10],[10003,10]]],
    [3,5,[[10001,10],[10002,10],[10003,10]]],
    [4,7,[[10001,10],[10002,10],[10003,10]]],
    [5,9,[[10001,10],[10002,10],[10003,10]]],
    [6,11,[[10001,10],[10002,10],[10003,10]]],
    [7,13,[[10001,10],[10002,10],[10003,10]]],
    [8,15,[[10001,10],[10002,10],[10003,10]]],
    [9,17,[[10001,10],[10002,10],[10003,10]]],
    [10,19,[[10001,10],[10002,10],[10003,10]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new xunbaocengrewardRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    xunbaocengreward .push(r);

}

export default xunbaocengreward
