const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","circle","stagenode","reward",]

export class pioneer2configRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 轮数
         **/
        @SafeProperty
        circle?:number

        /**
         * 关卡要求
         **/
        @SafeProperty
        stagenode?:number

        /**
         * 水晶能量点
         **/
        @SafeProperty
        reward?:number

}

let pioneer2config:pioneer2configRow []=[];

var rowData=
[
    [1,1,12,10],
    [2,1,20,10],
    [3,1,28,10],
    [4,1,36,10],
    [5,1,44,10],
    [6,1,52,20],
    [7,1,60,30],
    [8,2,68,10],
    [9,2,76,10],
    [10,2,84,10],
    [11,2,92,10],
    [12,2,100,10],
    [13,2,108,20],
    [14,2,116,30],
    [15,3,122,10],
    [16,3,130,10],
    [17,3,134,10],
    [18,3,138,10],
    [19,3,142,10],
    [20,3,148,20],
    [21,3,156,30],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new pioneer2configRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    pioneer2config .push(r);

}

export default pioneer2config
