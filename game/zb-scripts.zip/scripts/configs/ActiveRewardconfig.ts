const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","type","vitality","reward",]

export class ActiveRewardconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 类型（1日常2周常）
         **/
        @SafeProperty
        type?:number

        /**
         * 活跃值要求
         **/
        @SafeProperty
        vitality?:number

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:any

}

let ActiveRewardconfig:ActiveRewardconfigRow []=[];

var rowData=
[
    [1,1,20,[[10004,20],[10066,20],[10002,10]]],
    [2,1,40,[[10041,1],[10066,30],[10002,20]]],
    [3,1,60,[[10062,1],[10452,1],[10066,40]]],
    [4,1,80,[[10060,5],[10002,30],[10066,60]]],
    [5,1,100,[[10006,1],[10066,100],[10002,50],[10477,1]]],
    [6,2,20,[[10048,1],[10074,1],[10066,80]]],
    [7,2,40,[[10008,100],[10060,60],[10066,160]]],
    [8,2,60,[[10061,10],[10048,1],[10074,1],[10066,240]]],
    [9,2,80,[[10002,400],[10066,320]]],
    [10,2,100,[[10006,3],[10074,1],[10066,400]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new ActiveRewardconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    ActiveRewardconfig .push(r);

}

export default ActiveRewardconfig
