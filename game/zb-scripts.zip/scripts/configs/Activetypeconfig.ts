const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","taskdes","Activeid","skipID",]

export class ActivetypeconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 任务描述
         **/
        @SafeProperty
        taskdes?:string

        /**
         * 活动类型

1、抽卡活动
2、寻宝庆典
3、英雄养成
4、狂热竞技
5、智慧风暴
6、悬赏季
7、联盟集结
8、联盟抽卡
         **/
        @SafeProperty
        Activeid?:number

        /**
         * 跳转ID
         **/
        @SafeProperty
        skipID?:string

}

let Activetypeconfig:ActivetypeconfigRow []=[];

var rowData=
[
    [1,"获得%p点抽卡积分",1,"19"],
    [2,"进行日常寻宝%p次",2,"31"],
    [3,"进行精英寻宝%p次",2,"32"],
    [4,"将%p名英雄提升至%s级",3,"15"],
    [5,"将%p名英雄提升至%s品阶",3,"9"],
    [6,"参与竞技场%p次",4,"5"],
    [7,"竞技场获胜%p次",4,"5"],
    [8,"参与高级竞技场%p次",4,"36"],
    [9,"高级竞技场获胜%p次",4,"36"],
    [10,"购买勇士之证%p个",4,"5"],
    [11,"购买高级勇士之证%p个",4,"36"],
    [12,"参与智慧树考验%p次（智慧树刷新前仅计1次）",5,"7"],
    [13,"击败智慧树考验%s层BOSS%p次",5,"7"],
    [14,"刷新悬赏令%p次",6,"6"],
    [15,"完成%s星悬赏令任务%p次",6,"6"],
    [16,"获得%s联盟的SR英雄%p个",7,"19"],
    [17,"获得%s联盟的SSR英雄%p个",7,"19"],
    [18,"获得%s联盟的UR英雄%p个",7,"19"],
    [19,"获得%p点联盟抽卡积分",8,"38"],
    [20,"获得%p种不重复的%s联盟SR英雄",7,"19"],
    [21,"获得%p种不重复的%s联盟SSR英雄",7,"19"],
    [22,"获得%p种不重复的%s联盟UR英雄",7,"19"],
    [23,"获得%s联盟的%s品阶英雄%p个",7,"19"],
    [24,"将%p名英雄提升至%s星",3,"9"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new ActivetypeconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    Activetypeconfig .push(r);

}

export default Activetypeconfig
