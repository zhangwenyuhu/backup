const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","equipquality","progress","herolevel",]

export class mazeshopconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 装备/雇佣品阶
         **/
        @SafeProperty
        equipquality?:number

        /**
         * 解锁关卡
         **/
        @SafeProperty
        progress?:any

        /**
         * 英雄等级
         **/
        @SafeProperty
        herolevel?:any

}

let mazeshopconfig:mazeshopconfigRow []=[];

var rowData=
[
    [1,2,0,[1,1]],
    [2,3,0,[1,1]],
    [3,4,0,[1,1]],
    [4,5,0,[1,1]],
    [5,6,0,[1,1]],
    [6,7,0,[1,1]],
    [7,8,0,[1,1]],
    [8,9,0,[1,1]],
    [9,10,0,[1,1]],
    [10,11,0,[1,1]],
    [11,12,0,[1,1]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new mazeshopconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    mazeshopconfig .push(r);

}

export default mazeshopconfig
