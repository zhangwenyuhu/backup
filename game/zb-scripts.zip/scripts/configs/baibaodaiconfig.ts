const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","reward","weight","limit",]

export class baibaodaiconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 奖励内容
         **/
        @SafeProperty
        reward?:any

        /**
         * 权重
         **/
        @SafeProperty
        weight?:number

        /**
         * 前N次不可被抽到
         **/
        @SafeProperty
        limit?:number

}

let baibaodaiconfig:baibaodaiconfigRow []=[];

var rowData=
[
    [1,[10006,5],100,0],
    [2,[10061,60],50,6],
    [3,[10480,100],100,0],
    [4,[10006,10],100,10],
    [5,[10477,16],50,0],
    [6,[10061,60],100,8],
    [7,[10486,2],50,0],
    [8,[10007,3],100,0],
    [9,[10508,1],100,0],
    [10,[10509,1],50,12],
    [11,[10053,3],100,0],
    [12,[10478,3],50,13],
    [13,[10061,30],100,0],
    [14,[10096,10],100,0],
    [15,[10521,60],50,14],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new baibaodaiconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    baibaodaiconfig .push(r);

}

export default baibaodaiconfig
