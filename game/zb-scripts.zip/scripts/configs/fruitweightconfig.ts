const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","Monstertype","fruit","weight",]

export class fruitweightconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 怪物类型
admin:
1普通怪
2精英怪
3层boss
         **/
        @SafeProperty
        Monstertype?:number

        /**
         * 果实品质
admin:
1蓝色
2紫色
3金色
         **/
        @SafeProperty
        fruit?:number

        /**
         * 权重
         **/
        @SafeProperty
        weight?:number

}

let fruitweightconfig:fruitweightconfigRow []=[];

var rowData=
[
    [1,1,1,95],
    [2,1,2,5],
    [3,1,3,0],
    [4,2,1,13],
    [5,2,2,80],
    [6,2,3,7],
    [7,3,1,0],
    [8,3,2,0],
    [9,3,3,100],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new fruitweightconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    fruitweightconfig .push(r);

}

export default fruitweightconfig
