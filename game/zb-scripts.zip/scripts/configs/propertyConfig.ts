const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","ProName","VarName","ProType","ProCulType","ProShow",]

export class propertyConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 属性名称
         **/
        @SafeProperty
        ProName?:key

        /**
         * 变量名称
         **/
        @SafeProperty
        VarName?:string

        /**
         * 属性表现类型（0数值1百分比）
         **/
        @SafeProperty
        ProType?:number

        /**
         * 加成计算类型（0数值1百分比）
         **/
        @SafeProperty
        ProCulType?:number

        /**
         * 面板是否显示(1显示0不显示）
         **/
        @SafeProperty
        ProShow?:number

}

let propertyConfig:propertyConfigRow []=[];

var rowData=
[
    [1,"攻击","atk",0,0,1],
    [2,"攻击百分比","atk",1,1,1],
    [3,"生命","hp",0,0,1],
    [4,"生命百分比","hp",1,1,1],
    [5,"防御","def",0,0,1],
    [6,"防御百分比","def",1,1,1],
    [7,"暴击率","criPct",1,0,1],
    [8,"暴击伤害","criAtk",1,0,1],
    [9,"命中","hit",0,0,1],
    [10,"闪避","dodge",0,0,1],
    [11,"施法迅捷","skillSpeed",0,0,1],
    [12,"物理减伤","phyResist",1,0,1],
    [13,"魔法减伤","magicResist",1,0,1],
    [14,"吸血效果","liftLeech",0,0,1],
    [15,"神器主动技能增伤","incArtifactHarm",1,0,0],
    [16,"神器主动技能减伤","decArtifactHarm",1,0,0],
    [17,"神器主动技能暴击率","criPctArtifact",1,0,0],
    [18,"神器主动技能暴击伤害","criAtkArtifact",1,0,0],
    [19,"治疗能力增加","healCap",1,0,0],
    [20,"抗爆率","deCri",1,0,0],
    [21,"伤害增加","incHarm",1,0,0],
    [22,"每秒恢复生命","recoverSec",0,0,0],
    [23,"攻击回能","hitEnergy",0,0,0],
    [24,"受击回能","beHitEnergy",0,0,0],
    [25,"移动速度","moveSpeed",0,0,0],
    [26,"攻击速度","intervalCd",1,0,0],
    [27,"技能伤害","skillHarm",1,0,0],
    [28,"每秒回能","autoEnergy",0,0,0],
    [29,"克制伤害","restrain",1,0,0],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new propertyConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

export let propertyConfigMap:{

    /** {"Id":1,"ProName":"攻击","VarName":"atk","ProType":0,"ProCulType":0,"ProShow":1} */
    攻击?:propertyConfigRow

    /** {"Id":2,"ProName":"攻击百分比","VarName":"atk","ProType":1,"ProCulType":1,"ProShow":1} */
    攻击百分比?:propertyConfigRow

    /** {"Id":3,"ProName":"生命","VarName":"hp","ProType":0,"ProCulType":0,"ProShow":1} */
    生命?:propertyConfigRow

    /** {"Id":4,"ProName":"生命百分比","VarName":"hp","ProType":1,"ProCulType":1,"ProShow":1} */
    生命百分比?:propertyConfigRow

    /** {"Id":5,"ProName":"防御","VarName":"def","ProType":0,"ProCulType":0,"ProShow":1} */
    防御?:propertyConfigRow

    /** {"Id":6,"ProName":"防御百分比","VarName":"def","ProType":1,"ProCulType":1,"ProShow":1} */
    防御百分比?:propertyConfigRow

    /** {"Id":7,"ProName":"暴击率","VarName":"criPct","ProType":1,"ProCulType":0,"ProShow":1} */
    暴击率?:propertyConfigRow

    /** {"Id":8,"ProName":"暴击伤害","VarName":"criAtk","ProType":1,"ProCulType":0,"ProShow":1} */
    暴击伤害?:propertyConfigRow

    /** {"Id":9,"ProName":"命中","VarName":"hit","ProType":0,"ProCulType":0,"ProShow":1} */
    命中?:propertyConfigRow

    /** {"Id":10,"ProName":"闪避","VarName":"dodge","ProType":0,"ProCulType":0,"ProShow":1} */
    闪避?:propertyConfigRow

    /** {"Id":11,"ProName":"施法迅捷","VarName":"skillSpeed","ProType":0,"ProCulType":0,"ProShow":1} */
    施法迅捷?:propertyConfigRow

    /** {"Id":12,"ProName":"物理减伤","VarName":"phyResist","ProType":1,"ProCulType":0,"ProShow":1} */
    物理减伤?:propertyConfigRow

    /** {"Id":13,"ProName":"魔法减伤","VarName":"magicResist","ProType":1,"ProCulType":0,"ProShow":1} */
    魔法减伤?:propertyConfigRow

    /** {"Id":14,"ProName":"吸血效果","VarName":"liftLeech","ProType":0,"ProCulType":0,"ProShow":1} */
    吸血效果?:propertyConfigRow

    /** {"Id":15,"ProName":"神器主动技能增伤","VarName":"incArtifactHarm","ProType":1,"ProCulType":0,"ProShow":0} */
    神器主动技能增伤?:propertyConfigRow

    /** {"Id":16,"ProName":"神器主动技能减伤","VarName":"decArtifactHarm","ProType":1,"ProCulType":0,"ProShow":0} */
    神器主动技能减伤?:propertyConfigRow

    /** {"Id":17,"ProName":"神器主动技能暴击率","VarName":"criPctArtifact","ProType":1,"ProCulType":0,"ProShow":0} */
    神器主动技能暴击率?:propertyConfigRow

    /** {"Id":18,"ProName":"神器主动技能暴击伤害","VarName":"criAtkArtifact","ProType":1,"ProCulType":0,"ProShow":0} */
    神器主动技能暴击伤害?:propertyConfigRow

    /** {"Id":19,"ProName":"治疗能力增加","VarName":"healCap","ProType":1,"ProCulType":0,"ProShow":0} */
    治疗能力增加?:propertyConfigRow

    /** {"Id":20,"ProName":"抗爆率","VarName":"deCri","ProType":1,"ProCulType":0,"ProShow":0} */
    抗爆率?:propertyConfigRow

    /** {"Id":21,"ProName":"伤害增加","VarName":"incHarm","ProType":1,"ProCulType":0,"ProShow":0} */
    伤害增加?:propertyConfigRow

    /** {"Id":22,"ProName":"每秒恢复生命","VarName":"recoverSec","ProType":0,"ProCulType":0,"ProShow":0} */
    每秒恢复生命?:propertyConfigRow

    /** {"Id":23,"ProName":"攻击回能","VarName":"hitEnergy","ProType":0,"ProCulType":0,"ProShow":0} */
    攻击回能?:propertyConfigRow

    /** {"Id":24,"ProName":"受击回能","VarName":"beHitEnergy","ProType":0,"ProCulType":0,"ProShow":0} */
    受击回能?:propertyConfigRow

    /** {"Id":25,"ProName":"移动速度","VarName":"moveSpeed","ProType":0,"ProCulType":0,"ProShow":0} */
    移动速度?:propertyConfigRow

    /** {"Id":26,"ProName":"攻击速度","VarName":"intervalCd","ProType":1,"ProCulType":0,"ProShow":0} */
    攻击速度?:propertyConfigRow

    /** {"Id":27,"ProName":"技能伤害","VarName":"skillHarm","ProType":1,"ProCulType":0,"ProShow":0} */
    技能伤害?:propertyConfigRow

    /** {"Id":28,"ProName":"每秒回能","VarName":"autoEnergy","ProType":0,"ProCulType":0,"ProShow":0} */
    每秒回能?:propertyConfigRow

    /** {"Id":29,"ProName":"克制伤害","VarName":"restrain","ProType":1,"ProCulType":0,"ProShow":0} */
    克制伤害?:propertyConfigRow

}={}

for(let r of tableData){
    propertyConfig .push(r);

    propertyConfigMap [r. ProName ] =r;

}

export default propertyConfig
