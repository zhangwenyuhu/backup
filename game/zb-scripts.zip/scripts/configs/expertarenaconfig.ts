const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","rankname","rankscore","coinget","victoryscore",]

export class expertarenaconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 段位名称
         **/
        @SafeProperty
        rankname?:string

        /**
         * 段位积分
         **/
        @SafeProperty
        rankscore?:number

        /**
         * 角斗士硬币掉落速度（每小时）
         **/
        @SafeProperty
        coinget?:number

        /**
         * 胜利积分增加
         **/
        @SafeProperty
        victoryscore?:bool

}

let expertarenaconfig:expertarenaconfigRow []=[];

var rowData=
[
    [1,"新手1",10,10,true],
    [2,"新手2",20,20,true],
    [3,"新手3",30,30,true],
    [4,"新手4",40,40,true],
    [5,"新手5",50,50,true],
    [6,"净化新人1",60,60,true],
    [7,"净化新人2",70,70,true],
    [8,"净化新人3",80,80,true],
    [9,"净化新人4",90,90,true],
    [10,"净化新人5",100,100,true],
    [11,"净化先锋1",110,110,true],
    [12,"净化先锋2",120,120,true],
    [13,"净化先锋3",130,130,true],
    [14,"净化先锋4",140,140,true],
    [15,"净化先锋5",150,150,true],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new expertarenaconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    expertarenaconfig .push(r);

}

export default expertarenaconfig
