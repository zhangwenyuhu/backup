const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","theme","camp","monster","name","boxID",]

export class factiongamethemeconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 主题
         **/
        @SafeProperty
        theme?:string

        /**
         * 适用阵营
         **/
        @SafeProperty
        camp?:number

        /**
         * 怪物
         **/
        @SafeProperty
        monster?:any

        /**
         * 怪物名
         **/
        @SafeProperty
        name?:any

        /**
         * 宝箱ID（5特殊宝箱+剩下的填充公共箱）
         **/
        @SafeProperty
        boxID?:any

}

let factiongamethemeconfig:factiongamethemeconfigRow []=[];

var rowData=
[
    [1,"武装联盟",1,[20034,20035,20036,20037,20046],["奇异博士","范海辛","神器女侠","美国队长","林克"],[10001,10002,10003,10004,10005]],
    [2,"机械联盟",2,[20016,20017,20018,20052,20053],["机器猫","钢铁侠","毁灭博士","银河战士","海王"],[10001,10002,10003,10004,10005]],
    [3,"变种联盟",3,[20024,20025,20026,20045,20047],["格鲁特","沙僧","蜘蛛侠","金毛狮王","金刚狼"],[10001,10002,10003,10004,10005]],
    [4,"僵尸联盟",4,[20006,20007,20008,20009,20051],["恶灵骑士","德古拉","死侍","阿尔萨斯","奎托斯"],[10001,10002,10003,10004,10005]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new factiongamethemeconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    factiongamethemeconfig .push(r);

}

export default factiongamethemeconfig
