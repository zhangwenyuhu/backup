const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","level","name","battlenumber","playerlevel","prop1","prop2","cost","point","icon",]

export class medalconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 勋章等级
         **/
        @SafeProperty
        level?:number

        /**
         * 勋章名
         **/
        @SafeProperty
        name?:string

        /**
         * 所需战力
         **/
        @SafeProperty
        battlenumber?:number

        /**
         * 所需玩家等级
         **/
        @SafeProperty
        playerlevel?:number

        /**
         * 属性加成1
         **/
        @SafeProperty
        prop1?:any

        /**
         * 属性加成2
         **/
        @SafeProperty
        prop2?:any

        /**
         * 所需消耗
         **/
        @SafeProperty
        cost?:any

        /**
         * 战略点
         **/
        @SafeProperty
        point?:any

        /**
         * 勋章Icon
         **/
        @SafeProperty
        icon?:string

}

let medalconfig:medalconfigRow []=[];

var rowData=
[
    [1,1,"二等净兵",10000,10,[1,50],[3,20],null,[10567,5],"medal_ico0"],
    [2,2,"一等净兵",30000,15,[1,110],[3,30],[[10564,1]],[10567,5],"medal_ico0"],
    [3,3,"净兵长",50000,20,[1,120],[3,40],[[10564,1]],[10567,5],"medal_ico0"],
    [4,4,"协兵士",70000,25,[1,130],[3,50],[[10564,1]],[10567,5],"medal_ico1"],
    [5,5,"副净士",90000,30,[1,140],[3,60],[[10565,1]],[10567,5],"medal_ico1"],
    [6,6,"正净士",110000,35,[1,150],[3,70],[[10565,1]],[10567,5],"medal_ico1"],
    [7,7,"净士长",130000,40,[1,160],[3,80],[[10565,1]],[10567,5],"medal_ico1"],
    [8,8,"协净尉",150000,45,[1,170],[3,90],[[10566,1]],[10567,5],"medal_ico2"],
    [9,9,"副净尉",170000,50,[1,180],[3,100],[[10566,1]],[10567,5],"medal_ico2"],
    [10,10,"正净尉",170100,51,[1,190],[3,110],[[10566,1]],[10567,5],"medal_ico2"],
    [11,11,"净尉长",170200,52,[1,200],[3,120],[[10566,1]],[10567,5],"medal_ico2"],
    [12,12,"协净校",190200,53,[1,210],[3,130],[[10566,1]],[10567,5],"medal_ico3"],
    [13,13,"副净校",170300,54,[1,220],[3,140],[[10566,1]],[10567,5],"medal_ico3"],
    [14,14,"正净校",170400,55,[1,230],[3,150],[[10566,1]],[10567,5],"medal_ico3"],
    [15,15,"从净将",190400,56,[1,240],[3,160],[[10566,1]],[10567,5],"medal_ico4"],
    [16,16,"协净将",170500,57,[1,250],[3,170],[[10566,1]],[10567,5],"medal_ico4"],
    [17,17,"副净将",170600,58,[1,260],[3,180],[[10566,1]],[10567,5],"medal_ico4"],
    [18,18,"正净将",190600,59,[1,270],[3,190],[[10566,1]],[10567,5],"medal_ico4"],
    [19,19,"净化提督",170700,60,[1,280],[3,200],[[10566,1]],[10567,5],"medal_ico5"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new medalconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    medalconfig .push(r);

}

export default medalconfig
