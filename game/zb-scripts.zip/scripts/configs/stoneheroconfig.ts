const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","goodsID","qualitylevel","camp","pond","normal","epic","myth",]

export class stoneheroconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 道具ID
         **/
        @SafeProperty
        goodsID?:number

        /**
         * 品阶
         **/
        @SafeProperty
        qualitylevel?:number

        /**
         * 阵营
         **/
        @SafeProperty
        camp?:number[]

        /**
         * 卡池权重
         **/
        @SafeProperty
        pond?:number

        /**
         * 普通权重
         **/
        @SafeProperty
        normal?:number

        /**
         * 史诗权重
         **/
        @SafeProperty
        epic?:number

        /**
         * 神话权重
         **/
        @SafeProperty
        myth?:number

}

let stoneheroconfig:stoneheroconfigRow []=[];

var rowData=
[
    [1,10060,0,[1,2,3,4],100,0,100,0],
    [2,10061,4,[1,2,3,4],70,0,100,0],
    [3,10061,0,[1,2,3,4],30,0,0,100],
    [4,10075,0,[1,2,3,4],100,0,0,100],
    [5,10088,0,[1],100,0,100,0],
    [6,10089,0,[2],100,0,100,0],
    [7,10090,0,[3],100,0,100,0],
    [8,10091,0,[4],100,0,100,0],
    [9,10092,3,[1],0,0,100,0],
    [10,10092,0,[1],100,0,0,100],
    [11,10093,3,[2],0,0,100,0],
    [12,10093,0,[2],100,0,0,100],
    [13,10094,3,[3],0,0,100,0],
    [14,10094,0,[3],100,0,0,100],
    [15,10095,3,[4],0,0,100,0],
    [16,10095,0,[4],100,0,0,100],
    [17,10496,4,[1],70,0,100,0],
    [18,10496,0,[1],30,0,0,100],
    [19,10497,4,[2],70,0,100,0],
    [20,10497,0,[2],30,0,0,100],
    [21,10498,4,[3],70,0,100,0],
    [22,10498,0,[3],30,0,0,100],
    [23,10499,4,[4],70,0,100,0],
    [24,10499,0,[4],30,0,0,100],
    [25,10563,0,[1,2,3,4],100,0,100,0],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new stoneheroconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    stoneheroconfig .push(r);

}

export default stoneheroconfig
