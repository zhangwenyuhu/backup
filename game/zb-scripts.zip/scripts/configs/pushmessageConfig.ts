const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["id","type","parameter","des","sort","pushtype",]

export class pushmessageConfigRow{

        /**
         * id
         **/
        @SafeProperty
        id?:uid

        /**
         * 类型
1.离线时长
2.离线收益上限
3.悬赏大厅数量
4.智慧树关闭前，仍未开始通关
         **/
        @SafeProperty
        type?:number

        /**
         * 参数
对应类型离线推送的条件
         **/
        @SafeProperty
        parameter?:number

        /**
         * 描述
         **/
        @SafeProperty
        des?:string

        /**
         * 优先级
         **/
        @SafeProperty
        sort?:number

        /**
         * 推送类型
1.立即推送
2.定点推送（9、12、21）

         **/
        @SafeProperty
        pushtype?:number

}

let pushmessageConfig:pushmessageConfigRow []=[];

var rowData=
[
    [1,1,24,"亲爱的冒险家，您已经有1天没有回到我们的星球了。小伙伴们对您想念极了~",1,1],
    [2,1,48,"亲爱的冒险家，您已经有2天没有回到我们的星球了。小伙伴们对您想念极了~",1,1],
    [3,1,72,"亲爱的冒险家，您已经有3天没有回到我们的星球了。小伙伴们对您想念极了~",1,1],
    [4,1,96,"亲爱的冒险家，您已经有4天没有回到我们的星球了。小伙伴们对您想念极了~",1,1],
    [5,2,12,"亲爱的冒险家，您的离线收益快要把宝箱撑炸了！快点上线领取吧！",2,1],
    [6,3,3,"亲爱的冒险家，您有部分悬赏任务的奖励还未领取，再不来领，它就发霉啦！",3,2],
    [7,4,12,"你即将错过本次智慧树的试炼，以及丰厚的试炼奖励~赶快上线通关吧！",4,1],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new pushmessageConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    pushmessageConfig .push(r);

}

export default pushmessageConfig
