const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","circle","stagenode","reward",]

export class pioneerconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 轮数
         **/
        @SafeProperty
        circle?:number

        /**
         * 关卡要求
         **/
        @SafeProperty
        stagenode?:number

        /**
         * 抽奖券
         **/
        @SafeProperty
        reward?:number

}

let pioneerconfig:pioneerconfigRow []=[];

var rowData=
[
    [1,1,12,1],
    [2,1,20,1],
    [3,1,28,1],
    [4,1,36,1],
    [5,1,44,1],
    [6,1,52,2],
    [7,1,60,3],
    [8,2,68,1],
    [9,2,76,1],
    [10,2,84,1],
    [11,2,92,1],
    [12,2,100,1],
    [13,2,108,2],
    [14,2,116,3],
    [15,3,122,1],
    [16,3,130,1],
    [17,3,134,1],
    [18,3,138,1],
    [19,3,142,1],
    [20,3,148,2],
    [21,3,156,3],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new pioneerconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    pioneerconfig .push(r);

}

export default pioneerconfig
