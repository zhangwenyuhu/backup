const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","type","hurtnum","rewardbox",]

export class huntconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 类型（1哥布林2远古剑魂）
         **/
        @SafeProperty
        type?:number

        /**
         * 伤害要求
         **/
        @SafeProperty
        hurtnum?:number

        /**
         * 宝箱ID
         **/
        @SafeProperty
        rewardbox?:number

}

let huntconfig:huntconfigRow []=[];

var rowData=
[
    [1001,1,5000,10136],
    [1002,1,10000,10137],
    [1003,1,20000,10138],
    [1004,1,40000,10139],
    [1005,1,70000,10140],
    [1006,1,120000,10141],
    [1007,1,220000,10142],
    [1008,1,450000,10143],
    [1009,1,820000,10144],
    [1010,1,1550000,10145],
    [1011,1,3000000,10145],
    [1012,1,5500000,10145],
    [1013,1,10000000,10145],
    [1014,1,20000000,10145],
    [1015,1,45000000,10145],
    [1016,1,100000000,10145],
    [1017,1,300000000,10145],
    [1018,1,1000000000,10145],
    [2001,2,5000,10136],
    [2002,2,10000,10137],
    [2003,2,20000,10138],
    [2004,2,40000,10139],
    [2005,2,70000,10140],
    [2006,2,120000,10141],
    [2007,2,220000,10142],
    [2008,2,450000,10143],
    [2009,2,820000,10144],
    [2010,2,1550000,10145],
    [2011,2,3000000,10145],
    [2012,2,5500000,10145],
    [2013,2,10000000,10145],
    [2014,2,20000000,10145],
    [2015,2,45000000,10145],
    [2016,2,100000000,10145],
    [2017,2,300000000,10145],
    [2018,2,1000000000,10145],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new huntconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    huntconfig .push(r);

}

export default huntconfig
