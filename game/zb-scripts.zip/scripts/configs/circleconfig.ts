const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","circle","reward",]

export class circleconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 星星数
         **/
        @SafeProperty
        circle?:number

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:any

}

let circleconfig:circleconfigRow []=[];

var rowData=
[
    [1,15,[[10557,10]]],
    [2,30,[[10557,20]]],
    [3,45,[[10557,20]]],
    [4,60,[[10557,20]]],
    [5,80,[[10557,30]]],
    [6,100,[[10557,30]]],
    [7,120,[[10557,30]]],
    [8,150,[[10557,40]]],
    [9,180,[[10557,40]]],
    [10,210,[[10557,40]]],
    [11,300,[[10557,50]]],
    [12,400,[[10557,50]]],
    [13,500,[[10557,50]]],
    [14,600,[[10557,80]]],
    [15,700,[[10557,100]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new circleconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    circleconfig .push(r);

}

export default circleconfig
