const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","StarLevel","HeroType","HeroRank","HeroNumber","URHeroRank","URHeroNumber","goodsnumber","StarCoefficient","HeroLevel","SelfSkillLevel",]

export class HeroStarConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 星级
         **/
        @SafeProperty
        StarLevel?:number

        /**
         * 升星英雄类型(0:同ID/1:同阵营)
         **/
        @SafeProperty
        HeroType?:number

        /**
         * 升星材料品阶
         **/
        @SafeProperty
        HeroRank?:number

        /**
         * 升星材料数量
         **/
        @SafeProperty
        HeroNumber?:number

        /**
         * UR升星品阶
         **/
        @SafeProperty
        URHeroRank?:number

        /**
         * UR升星材料数量
         **/
        @SafeProperty
        URHeroNumber?:number

        /**
         * 道具消耗
         **/
        @SafeProperty
        goodsnumber?:any

        /**
         * 星级系数
         **/
        @SafeProperty
        StarCoefficient?:number

        /**
         * 英雄等级要求(废弃）
         **/
        @SafeProperty
        HeroLevel?:number

        /**
         * 专属技能等级
         **/
        @SafeProperty
        SelfSkillLevel?:number

}

let HeroStarConfig:HeroStarConfigRow []=[];

var rowData=
[
    [1,1,0,4,1,5,1,null,80,0,0],
    [2,2,0,4,1,5,1,null,130,0,1],
    [3,3,0,4,2,5,2,null,220,0,2],
    [4,4,0,4,3,5,3,null,300,0,3],
    [5,5,0,4,4,5,4,null,500,0,4],
    [6,6,0,4,2,5,2,[10559,2],800,0,5],
    [7,7,0,4,2,5,2,[10559,2],1100,0,6],
    [8,8,0,4,4,5,4,[10559,3],1400,0,7],
    [9,9,0,4,4,5,4,[10559,4],1700,0,8],
    [10,10,0,4,4,5,4,[10559,5],2000,0,9],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new HeroStarConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    HeroStarConfig .push(r);

}

export default HeroStarConfig
