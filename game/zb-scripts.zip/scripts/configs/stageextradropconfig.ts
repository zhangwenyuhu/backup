const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","stoptime","stoptimetype","rankreduce","dropprobability",]

export class stageextradropconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 卡关时间
         **/
        @SafeProperty
        stoptime?:number[]

        /**
         * 卡关时间类型
         **/
        @SafeProperty
        stoptimetype?:number

        /**
         * 装备掉落品阶—N
         **/
        @SafeProperty
        rankreduce?:number

        /**
         * 掉落概率
         **/
        @SafeProperty
        dropprobability?:number

}

let stageextradropconfig:stageextradropconfigRow []=[];

var rowData=
[
    [1,[36,60],1,3,0.8],
    [2,[36,60],1,2,0.2],
    [3,[60,96],2,2,0.9],
    [4,[60,96],2,1,0.1],
    [5,[96,9999999999],3,2,0.8],
    [6,[96,9999999999],3,1,0.2],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new stageextradropconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    stageextradropconfig .push(r);

}

export default stageextradropconfig
