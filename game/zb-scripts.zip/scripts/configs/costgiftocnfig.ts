const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","costlevel",]

export class costgiftocnfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 消费档位
         **/
        @SafeProperty
        costlevel?:any

}

let costgiftocnfig:costgiftocnfigRow []=[];

var rowData=
[
    [1,[1,2,2,2,5,6]],
    [2,[1,2,2,3,5,6]],
    [3,[1,2,3,3,5,6]],
    [4,[2,3,4,4,6,6]],
    [5,[2,3,4,4,6,6]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new costgiftocnfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    costgiftocnfig .push(r);

}

export default costgiftocnfig
