const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","dashilevel","equiplevel","atk","hp",]

export class equipstrengmasterconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 大师等级
         **/
        @SafeProperty
        dashilevel?:number

        /**
         * 全身装备等级
         **/
        @SafeProperty
        equiplevel?:number

        /**
         * 攻击加成
         **/
        @SafeProperty
        atk?:number

        /**
         * 生命加成
         **/
        @SafeProperty
        hp?:number

}

let equipstrengmasterconfig:equipstrengmasterconfigRow []=[];

var rowData=
[
    [1,1,10,96,1280],
    [2,2,20,192,2560],
    [3,3,30,288,3840],
    [4,4,40,384,5120],
    [5,5,50,480,6400],
    [6,6,60,576,7680],
    [7,7,70,672,8960],
    [8,8,80,768,10240],
    [9,9,90,864,11520],
    [10,10,100,960,12800],
    [11,11,110,1056,14080],
    [12,12,120,1152,15360],
    [13,13,130,1248,16640],
    [14,14,140,1344,17920],
    [15,15,150,1440,19200],
    [16,16,160,1536,20480],
    [17,17,170,1632,21760],
    [18,18,180,1728,23040],
    [19,19,190,1824,24320],
    [20,20,200,1920,25600],
    [21,21,210,2016,26880],
    [22,22,220,2112,28160],
    [23,23,230,2208,29440],
    [24,24,240,2304,30720],
    [25,25,250,2400,32000],
    [26,26,260,2496,33280],
    [27,27,270,2592,34560],
    [28,28,280,2688,35840],
    [29,29,290,2784,37120],
    [30,30,300,2880,38400],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new equipstrengmasterconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    equipstrengmasterconfig .push(r);

}

export default equipstrengmasterconfig
