import ActiveRewardconfig from "./ActiveRewardconfig";
import ActiveListconfig from "./ActiveListconfig";
import Activetypeconfig from "./Activetypeconfig";
import Activechargeconfig from "./Activechargeconfig";
import Arenaconfig from "./Arenaconfig";
import Arenahighestrankconfig from "./Arenahighestrankconfig";
import HeroCompoundConfig from "./HeroCompoundConfig";
import Dailytaskconfig from "./Dailytaskconfig";
import Arenascoreconfig from "./Arenascoreconfig";
import GuildLevelConfig from "./GuildLevelConfig";
import HeroStarConfig from "./HeroStarConfig";
import RankingScoreconfig from "./RankingScoreconfig";
import Template from "./Template";
import arenahighrankrewardconfig from "./arenahighrankrewardconfig";
import arenahighscorecountconfig from "./arenahighscorecountconfig";
import arenascorerewardconfig from "./arenascorerewardconfig";
import arenaseasonconfig from "./arenaseasonconfig";
import arenaserverconfig from "./arenaserverconfig";
import artifactcompoundConfig from "./artifactcompoundConfig";
import artifactConfig from "./artifactConfig";
import artifactforgeConfig from "./artifactforgeConfig";
import baibaodaiconfig from "./baibaodaiconfig";
import artifactunlockConfig from "./artifactunlockConfig";
import battlescoreconfig from "./battlescoreconfig";
import boardconfig from "./boardconfig";
import boardeventconfig from "./boardeventconfig";
import boxselfhelpconfig from "./boxselfhelpconfig";
import boardtaskconfig from "./boardtaskconfig";
import challengerewardConfig from "./challengerewardConfig";
import chatConfig from "./chatConfig";
import bubbleconversationConfig from "./bubbleconversationConfig";
import circleconfig from "./circleconfig";
import arenachallangetimeconfig from "./arenachallangetimeconfig";
import circlerankconfig from "./circlerankconfig";
import costgiftocnfig from "./costgiftocnfig";
import clonebattleconfig from "./clonebattleconfig";
import costlevelconfig from "./costlevelconfig";
import dialrewardConfig from "./dialrewardConfig";
import dungeoneventconfig from "./dungeoneventconfig";
import equipLevelConfig from "./equipLevelConfig";
import equippowerConfig from "./equippowerConfig";
import equipstarConfig from "./equipstarConfig";
import equipstarmasterConfig from "./equipstarmasterConfig";
import equipstrengmasterconfig from "./equipstrengmasterconfig";
import equipoutfitConfig from "./equipoutfitConfig";
import equipstrengthconfig from "./equipstrengthconfig";
import eventconfig from "./eventconfig";
import expertarenaconfig from "./expertarenaconfig";
import factionbattleconfig from "./factionbattleconfig";
import factionbattlerewardconfig from "./factionbattlerewardconfig";
import factionboxconfig from "./factionboxconfig";
import factionconfig from "./factionconfig";
import factiongamethemeconfig from "./factiongamethemeconfig";
import factiongameconfig from "./factiongameconfig";
import factionmapmonsterconfig from "./factionmapmonsterconfig";
import factiongamescoreconfig from "./factiongamescoreconfig";
import fruitweightconfig from "./fruitweightconfig";
import gachaGroupConfig from "./gachaGroupConfig";
import growUpConfig from "./growUpConfig";
import groupbuffConfig from "./groupbuffConfig";
import guildredpackConfig from "./guildredpackConfig";
import heroRankConfig from "./heroRankConfig";
import guidetaskconfig from "./guidetaskconfig";
import huntaddupconfig from "./huntaddupconfig";
import huntbossbuff from "./huntbossbuff";
import honorconfig from "./honorconfig";
import kaoshangConfig from "./kaoshangConfig";
import huntrewardconfig from "./huntrewardconfig";
import huntconfig from "./huntconfig";
import libraryconfig from "./libraryconfig";
import marqueeConfig from "./marqueeConfig";
import mazeboxrewardconfig from "./mazeboxrewardconfig";
import mazebubbleConfig from "./mazebubbleConfig";
import mazemonsterconfig from "./mazemonsterconfig";
import mazeshopconfig from "./mazeshopconfig";
import mazefruitconfig from "./mazefruitconfig";
import mazeshoplevelconfig from "./mazeshoplevelconfig";
import medalconfig from "./medalconfig";
import medaltechconfig from "./medaltechconfig";
import medaltechinfoconfig from "./medaltechinfoconfig";
import medalstagerewardconfig from "./medalstagerewardconfig";
import newplayerchargeconfig from "./newplayerchargeconfig";
import newplayertimespendconfig from "./newplayertimespendconfig";
import niudanconfig from "./niudanconfig";
import niudanheroconfig from "./niudanheroconfig";
import onlinegiftconfig from "./onlinegiftconfig";
import pioneer2config from "./pioneer2config";
import pioneerconfig from "./pioneerconfig";
import playerLevelConfig from "./playerLevelConfig";
import propertyConfig from "./propertyConfig";
import pushmessageConfig from "./pushmessageConfig";
import resourcegameconfig from "./resourcegameconfig";
import sevenDaysSignConfig from "./sevenDaysSignConfig";
import sevendayfundconfig from "./sevendayfundconfig";
import sevendayschargeConfig from "./sevendayschargeConfig";
import shopTypeConfig from "./shopTypeConfig";
import skipconfig from "./skipconfig";
import skinconfig from "./skinconfig";
import soldierconfig from "./soldierconfig";
import spacetimeBoxConfig from "./spacetimeBoxConfig";
import spacetimeExploreConfig from "./spacetimeExploreConfig";
import spacetimeMap01Config from "./spacetimeMap01Config";
import spacetimeMap02Config from "./spacetimeMap02Config";
import spacetimeMap03Config from "./spacetimeMap03Config";
import spacetimeMap04Config from "./spacetimeMap04Config";
import spacetimefruitconfig from "./spacetimefruitconfig";
import spacetimeconfig from "./spacetimeconfig";
import stageextradropconfig from "./stageextradropconfig";
import stagedropconfig from "./stagedropconfig";
import statueConfig from "./statueConfig";
import stagerewardconfig from "./stagerewardconfig";
import statuefreewalletconfig from "./statuefreewalletconfig";
import stoneheroconfig from "./stoneheroconfig";
import storyconfig from "./storyconfig";
import timeGiftConfig from "./timeGiftConfig";
import videoconfig from "./videoconfig";
import vipconfig from "./vipconfig";
import wheelprizepool from "./wheelprizepool";
import wisdomTreeBoxConfig from "./wisdomTreeBoxConfig";
import wisdomTreeConfig from "./wisdomTreeConfig";
import xsConfig from "./xsConfig";
import xsLvConfig from "./xsLvConfig";
import xunbaorewardconfig from "./xunbaorewardconfig";
import xunbaocengrewardconfig from "./xunbaocengrewardconfig";
import robotconfig from "./robotconfig";
import xunbaoluckyConfig from "./xunbaoluckyConfig";
import ArenaRankconfig from "./ArenaRankconfig";
import xunbaofinalrewardconfig from "./xunbaofinalrewardconfig";
import Tasktypeconfig from "./Tasktypeconfig";
import yuekaConfig from "./yuekaConfig";
import boxrewardconfig from "./boxrewardconfig";
import dungeonconfig from "./dungeonconfig";
import defaultConfig from "./defaultConfig";
import gachaConfig from "./gachaConfig";
import gamehelpConfig from "./gamehelpConfig";
import giftConfig from "./giftConfig";
import guideconfig from "./guideconfig";
import jibanconfig from "./jibanconfig";
import mazebusinessconfig from "./mazebusinessconfig";
import sevenDaysNewConfig from "./sevenDaysNewConfig";
import shopConfig from "./shopConfig";
import skillspecialconfig from "./skillspecialconfig";
import statueRankConfig from "./statueRankConfig";
import supplyconfig from "./supplyconfig";
import unlockConfig from "./unlockConfig";
import ServerErrorCodeConfig from "./ServerErrorCodeConfig";
import Taskconfig from "./Taskconfig";
import equipConfig from "./equipConfig";
import factionskybuildconfig from "./factionskybuildconfig";
import heroLevelConfig from "./heroLevelConfig";
import playernameconfig from "./playernameconfig";
import surprisegiftconfig from "./surprisegiftconfig";
import effectViewConfig from "./effectViewConfig";
import geniusConfig from "./geniusConfig";
import rewardConfig from "./rewardConfig";
import skybuildconfig from "./skybuildconfig";
import storeConfig from "./storeConfig";
import Monsterconfig from "./Monsterconfig";
import heroConfig from "./heroConfig";
import artifactlevelConfig from "./artifactlevelConfig";
import factiontechconfig from "./factiontechconfig";
import skillConfig from "./skillConfig";
import npcconfig from "./npcconfig";
import goodsConfig from "./goodsConfig";
import herointroduceconfig from "./herointroduceconfig";
import Stageconfig from "./Stageconfig";
import stringConfig from "./stringConfig";
import sevenDaysConfig from "./sevenDaysConfig";

let tableMap:{[key:string]:{table:any,pk:string}}={};
tableMap["ActiveRewardconfig"]={table:ActiveRewardconfig,pk:"ID"}
tableMap["ActiveListconfig"]={table:ActiveListconfig,pk:"ID"}
tableMap["Activetypeconfig"]={table:Activetypeconfig,pk:"ID"}
tableMap["Activechargeconfig"]={table:Activechargeconfig,pk:"ID"}
tableMap["Arenaconfig"]={table:Arenaconfig,pk:"ID"}
tableMap["Arenahighestrankconfig"]={table:Arenahighestrankconfig,pk:"ID"}
tableMap["HeroCompoundConfig"]={table:HeroCompoundConfig,pk:"ID"}
tableMap["Dailytaskconfig"]={table:Dailytaskconfig,pk:"ID"}
tableMap["Arenascoreconfig"]={table:Arenascoreconfig,pk:"ID"}
tableMap["GuildLevelConfig"]={table:GuildLevelConfig,pk:"Level"}
tableMap["HeroStarConfig"]={table:HeroStarConfig,pk:"ID"}
tableMap["RankingScoreconfig"]={table:RankingScoreconfig,pk:"ID"}
tableMap["Template"]={table:Template,pk:"Id"}
tableMap["arenahighrankrewardconfig"]={table:arenahighrankrewardconfig,pk:"ID"}
tableMap["arenahighscorecountconfig"]={table:arenahighscorecountconfig,pk:"ID"}
tableMap["arenascorerewardconfig"]={table:arenascorerewardconfig,pk:"ID"}
tableMap["arenaseasonconfig"]={table:arenaseasonconfig,pk:"ID"}
tableMap["arenaserverconfig"]={table:arenaserverconfig,pk:"ID"}
tableMap["artifactcompoundConfig"]={table:artifactcompoundConfig,pk:"Id"}
tableMap["artifactConfig"]={table:artifactConfig,pk:"Id"}
tableMap["artifactforgeConfig"]={table:artifactforgeConfig,pk:"ID"}
tableMap["baibaodaiconfig"]={table:baibaodaiconfig,pk:"ID"}
tableMap["artifactunlockConfig"]={table:artifactunlockConfig,pk:"ID"}
tableMap["battlescoreconfig"]={table:battlescoreconfig,pk:"ID"}
tableMap["boardconfig"]={table:boardconfig,pk:"parameterid"}
tableMap["boardeventconfig"]={table:boardeventconfig,pk:"ID"}
tableMap["boxselfhelpconfig"]={table:boxselfhelpconfig,pk:"ID"}
tableMap["boardtaskconfig"]={table:boardtaskconfig,pk:"ID"}
tableMap["challengerewardConfig"]={table:challengerewardConfig,pk:"ID"}
tableMap["chatConfig"]={table:chatConfig,pk:"ID"}
tableMap["bubbleconversationConfig"]={table:bubbleconversationConfig,pk:"ID"}
tableMap["circleconfig"]={table:circleconfig,pk:"ID"}
tableMap["arenachallangetimeconfig"]={table:arenachallangetimeconfig,pk:"ID"}
tableMap["circlerankconfig"]={table:circlerankconfig,pk:"ID"}
tableMap["costgiftocnfig"]={table:costgiftocnfig,pk:"ID"}
tableMap["clonebattleconfig"]={table:clonebattleconfig,pk:"ID"}
tableMap["costlevelconfig"]={table:costlevelconfig,pk:"ID"}
tableMap["dialrewardConfig"]={table:dialrewardConfig,pk:"ID"}
tableMap["dungeoneventconfig"]={table:dungeoneventconfig,pk:"ID"}
tableMap["equipLevelConfig"]={table:equipLevelConfig,pk:"Id"}
tableMap["equippowerConfig"]={table:equippowerConfig,pk:"Id"}
tableMap["equipstarConfig"]={table:equipstarConfig,pk:"Id"}
tableMap["equipstarmasterConfig"]={table:equipstarmasterConfig,pk:"Id"}
tableMap["equipstrengmasterconfig"]={table:equipstrengmasterconfig,pk:"ID"}
tableMap["equipoutfitConfig"]={table:equipoutfitConfig,pk:"Id"}
tableMap["equipstrengthconfig"]={table:equipstrengthconfig,pk:"ID"}
tableMap["eventconfig"]={table:eventconfig,pk:"ID"}
tableMap["expertarenaconfig"]={table:expertarenaconfig,pk:"ID"}
tableMap["factionbattleconfig"]={table:factionbattleconfig,pk:"ID"}
tableMap["factionbattlerewardconfig"]={table:factionbattlerewardconfig,pk:"ID"}
tableMap["factionboxconfig"]={table:factionboxconfig,pk:"ID"}
tableMap["factionconfig"]={table:factionconfig,pk:"ID"}
tableMap["factiongamethemeconfig"]={table:factiongamethemeconfig,pk:"ID"}
tableMap["factiongameconfig"]={table:factiongameconfig,pk:"ID"}
tableMap["factionmapmonsterconfig"]={table:factionmapmonsterconfig,pk:"ID"}
tableMap["factiongamescoreconfig"]={table:factiongamescoreconfig,pk:"ID"}
tableMap["fruitweightconfig"]={table:fruitweightconfig,pk:"ID"}
tableMap["gachaGroupConfig"]={table:gachaGroupConfig,pk:"Id"}
tableMap["growUpConfig"]={table:growUpConfig,pk:"Id"}
tableMap["groupbuffConfig"]={table:groupbuffConfig,pk:"Id"}
tableMap["guildredpackConfig"]={table:guildredpackConfig,pk:"ID"}
tableMap["heroRankConfig"]={table:heroRankConfig,pk:"Key"}
tableMap["guidetaskconfig"]={table:guidetaskconfig,pk:"ID"}
tableMap["huntaddupconfig"]={table:huntaddupconfig,pk:"ID"}
tableMap["huntbossbuff"]={table:huntbossbuff,pk:"ID"}
tableMap["honorconfig"]={table:honorconfig,pk:"ID"}
tableMap["kaoshangConfig"]={table:kaoshangConfig,pk:"Id"}
tableMap["huntrewardconfig"]={table:huntrewardconfig,pk:"ID"}
tableMap["huntconfig"]={table:huntconfig,pk:"ID"}
tableMap["libraryconfig"]={table:libraryconfig,pk:"ID"}
tableMap["marqueeConfig"]={table:marqueeConfig,pk:"Id"}
tableMap["mazeboxrewardconfig"]={table:mazeboxrewardconfig,pk:"Id"}
tableMap["mazebubbleConfig"]={table:mazebubbleConfig,pk:"ID"}
tableMap["mazemonsterconfig"]={table:mazemonsterconfig,pk:"ID"}
tableMap["mazeshopconfig"]={table:mazeshopconfig,pk:"ID"}
tableMap["mazefruitconfig"]={table:mazefruitconfig,pk:"ID"}
tableMap["mazeshoplevelconfig"]={table:mazeshoplevelconfig,pk:"ID"}
tableMap["medalconfig"]={table:medalconfig,pk:"ID"}
tableMap["medaltechconfig"]={table:medaltechconfig,pk:"ID"}
tableMap["medaltechinfoconfig"]={table:medaltechinfoconfig,pk:"ID"}
tableMap["medalstagerewardconfig"]={table:medalstagerewardconfig,pk:"ID"}
tableMap["newplayerchargeconfig"]={table:newplayerchargeconfig,pk:"ID"}
tableMap["newplayertimespendconfig"]={table:newplayertimespendconfig,pk:"ID"}
tableMap["niudanconfig"]={table:niudanconfig,pk:"ID"}
tableMap["niudanheroconfig"]={table:niudanheroconfig,pk:"ID"}
tableMap["onlinegiftconfig"]={table:onlinegiftconfig,pk:"ID"}
tableMap["pioneer2config"]={table:pioneer2config,pk:"ID"}
tableMap["pioneerconfig"]={table:pioneerconfig,pk:"ID"}
tableMap["playerLevelConfig"]={table:playerLevelConfig,pk:"Id"}
tableMap["propertyConfig"]={table:propertyConfig,pk:"Id"}
tableMap["pushmessageConfig"]={table:pushmessageConfig,pk:"id"}
tableMap["resourcegameconfig"]={table:resourcegameconfig,pk:"ID"}
tableMap["sevenDaysSignConfig"]={table:sevenDaysSignConfig,pk:"Id"}
tableMap["sevendayfundconfig"]={table:sevendayfundconfig,pk:"ID"}
tableMap["sevendayschargeConfig"]={table:sevendayschargeConfig,pk:"ID"}
tableMap["shopTypeConfig"]={table:shopTypeConfig,pk:"Id"}
tableMap["skipconfig"]={table:skipconfig,pk:"ID"}
tableMap["skinconfig"]={table:skinconfig,pk:"ID"}
tableMap["soldierconfig"]={table:soldierconfig,pk:"ID"}
tableMap["spacetimeBoxConfig"]={table:spacetimeBoxConfig,pk:"ID"}
tableMap["spacetimeExploreConfig"]={table:spacetimeExploreConfig,pk:"ID"}
tableMap["spacetimeMap01Config"]={table:spacetimeMap01Config,pk:"ID"}
tableMap["spacetimeMap02Config"]={table:spacetimeMap02Config,pk:"ID"}
tableMap["spacetimeMap03Config"]={table:spacetimeMap03Config,pk:"ID"}
tableMap["spacetimeMap04Config"]={table:spacetimeMap04Config,pk:"ID"}
tableMap["spacetimefruitconfig"]={table:spacetimefruitconfig,pk:"ID"}
tableMap["spacetimeconfig"]={table:spacetimeconfig,pk:"ID"}
tableMap["stageextradropconfig"]={table:stageextradropconfig,pk:"ID"}
tableMap["stagedropconfig"]={table:stagedropconfig,pk:"ID"}
tableMap["statueConfig"]={table:statueConfig,pk:"ID"}
tableMap["stagerewardconfig"]={table:stagerewardconfig,pk:"ID"}
tableMap["statuefreewalletconfig"]={table:statuefreewalletconfig,pk:"ID"}
tableMap["stoneheroconfig"]={table:stoneheroconfig,pk:"ID"}
tableMap["storyconfig"]={table:storyconfig,pk:"ID"}
tableMap["timeGiftConfig"]={table:timeGiftConfig,pk:"Id"}
tableMap["videoconfig"]={table:videoconfig,pk:"ID"}
tableMap["vipconfig"]={table:vipconfig,pk:"ID"}
tableMap["wheelprizepool"]={table:wheelprizepool,pk:"Id"}
tableMap["wisdomTreeBoxConfig"]={table:wisdomTreeBoxConfig,pk:"ID"}
tableMap["wisdomTreeConfig"]={table:wisdomTreeConfig,pk:"ID"}
tableMap["xsConfig"]={table:xsConfig,pk:"Id"}
tableMap["xsLvConfig"]={table:xsLvConfig,pk:"Id"}
tableMap["xunbaorewardconfig"]={table:xunbaorewardconfig,pk:"ID"}
tableMap["xunbaocengrewardconfig"]={table:xunbaocengrewardconfig,pk:"ID"}
tableMap["robotconfig"]={table:robotconfig,pk:"ID"}
tableMap["xunbaoluckyConfig"]={table:xunbaoluckyConfig,pk:"ID"}
tableMap["ArenaRankconfig"]={table:ArenaRankconfig,pk:"ID"}
tableMap["xunbaofinalrewardconfig"]={table:xunbaofinalrewardconfig,pk:"ID"}
tableMap["Tasktypeconfig"]={table:Tasktypeconfig,pk:"ID"}
tableMap["yuekaConfig"]={table:yuekaConfig,pk:"Id"}
tableMap["boxrewardconfig"]={table:boxrewardconfig,pk:"Id"}
tableMap["dungeonconfig"]={table:dungeonconfig,pk:"ID"}
tableMap["defaultConfig"]={table:defaultConfig,pk:"Id"}
tableMap["gachaConfig"]={table:gachaConfig,pk:"Id"}
tableMap["gamehelpConfig"]={table:gamehelpConfig,pk:"Id"}
tableMap["giftConfig"]={table:giftConfig,pk:"Id"}
tableMap["guideconfig"]={table:guideconfig,pk:"ID"}
tableMap["jibanconfig"]={table:jibanconfig,pk:"ID"}
tableMap["mazebusinessconfig"]={table:mazebusinessconfig,pk:"ID"}
tableMap["sevenDaysNewConfig"]={table:sevenDaysNewConfig,pk:"Id"}
tableMap["shopConfig"]={table:shopConfig,pk:"Id"}
tableMap["skillspecialconfig"]={table:skillspecialconfig,pk:"SkillID"}
tableMap["statueRankConfig"]={table:statueRankConfig,pk:"ID"}
tableMap["supplyconfig"]={table:supplyconfig,pk:"ID"}
tableMap["unlockConfig"]={table:unlockConfig,pk:"Id"}
tableMap["ServerErrorCodeConfig"]={table:ServerErrorCodeConfig,pk:"uid"}
tableMap["Taskconfig"]={table:Taskconfig,pk:"taskID"}
tableMap["equipConfig"]={table:equipConfig,pk:"Id"}
tableMap["factionskybuildconfig"]={table:factionskybuildconfig,pk:"ID"}
tableMap["heroLevelConfig"]={table:heroLevelConfig,pk:"Level"}
tableMap["playernameconfig"]={table:playernameconfig,pk:"ID"}
tableMap["surprisegiftconfig"]={table:surprisegiftconfig,pk:"ID"}
tableMap["effectViewConfig"]={table:effectViewConfig,pk:"Id"}
tableMap["geniusConfig"]={table:geniusConfig,pk:"ID"}
tableMap["rewardConfig"]={table:rewardConfig,pk:"Id"}
tableMap["skybuildconfig"]={table:skybuildconfig,pk:"ID"}
tableMap["storeConfig"]={table:storeConfig,pk:"Id"}
tableMap["Monsterconfig"]={table:Monsterconfig,pk:"MonsterID"}
tableMap["heroConfig"]={table:heroConfig,pk:"Id"}
tableMap["artifactlevelConfig"]={table:artifactlevelConfig,pk:"ID"}
tableMap["factiontechconfig"]={table:factiontechconfig,pk:"ID"}
tableMap["skillConfig"]={table:skillConfig,pk:"Id"}
tableMap["npcconfig"]={table:npcconfig,pk:"ID"}
tableMap["goodsConfig"]={table:goodsConfig,pk:"parameterid"}
tableMap["herointroduceconfig"]={table:herointroduceconfig,pk:"ID"}
tableMap["Stageconfig"]={table:Stageconfig,pk:"ID"}
tableMap["stringConfig"]={table:stringConfig,pk:"uid"}
tableMap["sevenDaysConfig"]={table:sevenDaysConfig,pk:"Id"}

export function applyLocal(local:{[key:string]:string|null}){
    for(let key in local){
        let [tableName,pk,filedName]=key.split("/");
        if(tableName==null||pk==null||filedName==null){
            continue;
        }
        let pkIndex=parseInt(pk);
        let t=tableMap[tableName];
        if(t==null){
            continue;
        }
        let row=t.table.find(a=>a[t.pk]==pkIndex);
        if(row==null){
            continue;
        }
        row[filedName]=local[key];
    }
}