const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","type","level","EventID","probability","upperlimit","floor",]

export class eventconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 类型
作者:
1.特殊事件
2.普通事件
3.固定事件
4.起始事件
         **/
        @SafeProperty
        type?:number

        /**
         * 生效层数
         **/
        @SafeProperty
        level?:number

        /**
         * 事件ID
         **/
        @SafeProperty
        EventID?:number

        /**
         * 概率
         **/
        @SafeProperty
        probability?:number

        /**
         * 每层数量上限
         **/
        @SafeProperty
        upperlimit?:number

        /**
         * 每层数量下限
         **/
        @SafeProperty
        floor?:number

}

let eventconfig:eventconfigRow []=[];

var rowData=
[
    [1,4,1,0,1,1,1],
    [2,1,1,1,0.1,1,0],
    [3,1,1,2,0.4,99,1],
    [4,1,1,3,0.25,2,1],
    [5,1,1,4,0.25,1,0],
    [6,2,1,5,0.7,99,1],
    [7,2,1,6,0.3,5,2],
    [8,4,1,7,1,1,1],
    [9,4,2,0,1,1,1],
    [10,1,2,1,0.1,1,0],
    [11,1,2,2,0.4,99,1],
    [12,1,2,3,0.25,2,1],
    [13,1,2,4,0.25,1,0],
    [14,2,2,5,0.7,99,1],
    [15,2,2,6,0.3,5,2],
    [16,4,2,7,1,1,1],
    [17,4,3,0,1,1,1],
    [18,1,3,1,0.4,1,0],
    [19,1,3,2,0.25,99,1],
    [20,1,3,3,0.25,2,1],
    [21,1,3,4,0.1,1,0],
    [22,2,3,5,0.7,99,1],
    [23,2,3,6,0.3,5,2],
    [24,4,3,7,1,1,1],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new eventconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    eventconfig .push(r);

}

export default eventconfig
