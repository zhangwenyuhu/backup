const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","layer","node","eventCount","roadChoose","eventType",]

export class wisdomTreeConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 层数
         **/
        @SafeProperty
        layer?:number

        /**
         * 节点
         **/
        @SafeProperty
        node?:number

        /**
         * 事件数
         **/
        @SafeProperty
        eventCount?:number

        /**
         * 路线选择
         **/
        @SafeProperty
        roadChoose?:number

        /**
         * 事件类型
作者:
1.特殊事件
2.普通事件
3.固定事件
4.起始事件
         **/
        @SafeProperty
        eventType?:number

}

let wisdomTreeConfig:wisdomTreeConfigRow []=[];

var rowData=
[
    [1,1,1,1,0,4],
    [2,1,2,1,0,2],
    [3,1,3,1,0,1],
    [4,1,4,2,1,2],
    [5,1,5,2,2,2],
    [6,1,6,2,2,1],
    [7,1,7,1,0,2],
    [8,1,8,2,1,2],
    [9,1,9,2,2,1],
    [10,1,10,2,2,2],
    [11,1,11,1,0,4],
    [12,2,1,1,0,4],
    [13,2,2,1,0,2],
    [14,2,3,1,0,1],
    [15,2,4,2,1,2],
    [16,2,5,2,2,1],
    [17,2,6,2,2,2],
    [18,2,7,1,0,1],
    [19,2,8,2,1,2],
    [20,2,9,2,2,2],
    [21,2,10,1,0,1],
    [22,2,11,1,0,4],
    [23,3,1,1,0,4],
    [24,3,2,1,0,2],
    [25,3,3,1,0,1],
    [26,3,4,2,1,2],
    [27,3,5,2,2,1],
    [28,3,6,2,2,2],
    [29,3,7,1,0,1],
    [30,3,8,2,1,2],
    [31,3,9,2,2,2],
    [32,3,10,1,0,1],
    [33,3,11,1,0,4],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new wisdomTreeConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    wisdomTreeConfig .push(r);

}

export default wisdomTreeConfig
