const { SafeClass, decryptTable ,SafeProperty} = slib;

import skillConfig,{skillConfigRow} from "./skillConfig"


type uid=number;
type key=string;
type fk=number;
 
var fields =["Id","SkillId","Lv","Distance","AttackPercent","AttackValue","startCd","intervalCd",]

export class skillLevelConfigRow{
	
    
        /**
         * ID
         **/
        
        Id?:uid=null

        
        
    
        /**
         * 技能ID
         **/
        
        SkillId?:fk=null

        
        protected _fkSkillId?:skillConfigRow=undefined
        /**
         * 技能ID
         **/
        get SkillIdData(){
            if(this._fkSkillId===undefined){
                this._fkSkillId=skillConfig.find(a=>a.Id==this.SkillId);
            }
            return this._fkSkillId;
        }
        
        
    
        /**
         * 技能等级
         **/
        @SafeProperty
        Lv?:number=null

        
        
    
        /**
         * 攻击距离
         **/
        @SafeProperty
        Distance?:number=null

        
        
    
        /**
         * 攻击百分比
         **/
        @SafeProperty
        AttackPercent?:number=null

        
        
    
        /**
         * 攻击固定数值
         **/
        @SafeProperty
        AttackValue?:number=null

        
        
    
        /**
         * 进入游戏的初始CD ms
         **/
        @SafeProperty
        startCd?:number=null

        
        
    
        /**
         * 间隔CD ms
         **/
        @SafeProperty
        intervalCd?:number=null

        
        
    
}

let skillLevelConfig:skillLevelConfigRow []=[]


/**
[
    [100001,1000,1,100,0.1,10,3000,800],
    [100101,1001,1,100,0.1,10,3000,4000],
    [100201,1002,1,100,0.2,20,3000,8000],
    [100301,1003,1,10000000,0.2,20,3000,12000],
    [100002,1000,2,101,0.1,10,3000,800],
    [100003,1000,3,102,0.1,10,3000,800],
    [100004,1000,4,103,0.1,10,3000,800],
    
]
**/




export function skillLevelConfigInit (

    
	key:string='AMhGbf0cnlMCWWviPskillLevelConfigGOK+GK*--s8V2wUd',
	data:string='csjGt6N9xhccho2GtRzxhosAz9qmPT6DzaxT3EBM0aWTL5mFwcWNUUeQuoiym3oeHiGynAgNpe6Y+ZT0kwTQAoCXQgsyS8KfpZCAc0BPis+B9IN+U+cp2ArBY7MKuFa7'
    
){
    let newTable=decryptTable(
        ()=>{
            return new skillLevelConfigRow ()
        },
        fields,
        'fmrarm'+key,
        data,true
    ) as skillLevelConfigRow []
    for(let r of newTable){
        skillLevelConfig .push(r);
        
    }
}

export default skillLevelConfig
