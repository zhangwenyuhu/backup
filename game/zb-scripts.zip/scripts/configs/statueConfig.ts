const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","statuerank","statuename","statuelevel","helptime","receivetime","helpreward","dialtime","dialreward","levelreward","limit","diamond","factioncoin","gettime",]

export class statueConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 雕像段位
         **/
        @SafeProperty
        statuerank?:number

        /**
         * 段位名称
         **/
        @SafeProperty
        statuename?:string

        /**
         * 部位升级等级
         **/
        @SafeProperty
        statuelevel?:number

        /**
         * 互助次数
         **/
        @SafeProperty
        helptime?:number

        /**
         * 互助接收次数
         **/
        @SafeProperty
        receivetime?:number

        /**
         * 互助奖励
         **/
        @SafeProperty
        helpreward?:any

        /**
         * 转盘次数
         **/
        @SafeProperty
        dialtime?:number

        /**
         * 转盘奖励库
         **/
        @SafeProperty
        dialreward?:number

        /**
         * 升级奖励
         **/
        @SafeProperty
        levelreward?:any

        /**
         * 每日铸造资源上限
         **/
        @SafeProperty
        limit?:number[]

        /**
         * 钻石红包
         **/
        @SafeProperty
        diamond?:number

        /**
         * 工会币红包
         **/
        @SafeProperty
        factioncoin?:number

        /**
         * 红包领取次数
         **/
        @SafeProperty
        gettime?:number

}

let statueConfig:statueConfigRow []=[];

var rowData=
[
    [1,1,"青铜",5,1,3,[[10068,300]],1,1,null,[80,80,80],600,6000,5],
    [2,2,"白银",10,1,3,[[10068,300]],1,1,[[10002,100]],[160,160,160],750,9000,5],
    [3,3,"黄金",15,1,3,[[10068,300]],2,2,[[10002,200]],[320,320,320],900,12000,6],
    [4,4,"铂金",20,2,3,[[10068,300]],2,2,[[10002,300]],[480,480,480],1050,15000,7],
    [5,5,"钻石",25,2,3,[[10068,300]],3,2,[[10002,500]],[640,640,640],1200,18000,8],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new statueConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    statueConfig .push(r);

}

export default statueConfig
