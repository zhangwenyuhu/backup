const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","Rank","RankName","RankHead","RankHigh","RankColor","Faction","SuperFaction","StarLimit","PowerLimit","ReFactionCost","EqComCost","EqComLimit",]

export class equipLevelConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 品阶
         **/
        @SafeProperty
        Rank?:number

        /**
         * 品阶别名
         **/
        @SafeProperty
        RankName?:string

        /**
         * 品阶框
         **/
        @SafeProperty
        RankHead?:string

        /**
         * 品阶角标
         **/
        @SafeProperty
        RankHigh?:string

        /**
         * 品阶颜色
         **/
        @SafeProperty
        RankColor?:string

        /**
         * 阵营专属几率
         **/
        @SafeProperty
        Faction?:number

        /**
         * 光暗阵营专属几率
         **/
        @SafeProperty
        SuperFaction?:number

        /**
         * 强化星级上限
         **/
        @SafeProperty
        StarLimit?:number

        /**
         * 充能等级上限
         **/
        @SafeProperty
        PowerLimit?:number

        /**
         * 装备重铸消耗钻石
         **/
        @SafeProperty
        ReFactionCost?:number

        /**
         * 合成该品质消耗金币
         **/
        @SafeProperty
        EqComCost?:number

        /**
         * 合成该品质需要摩天楼层数
         **/
        @SafeProperty
        EqComLimit?:number

}

let equipLevelConfig:equipLevelConfigRow []=[];

var rowData=
[
    [1,1,"白色","0","0","#ffffff",0,0,0,0,0,0,1],
    [2,2,"普通","1","0","#5de86c",0,0,0,0,0,1000,1],
    [3,3,"稀有","2","0","#00c6ff",0,0,20,8,0,2000,2],
    [4,4,"稀有+","2","1","#00c6ff",3000,0,20,8,100,3000,20],
    [5,5,"精英","3","0","#f85ef9",4000,0,25,8,200,4000,50],
    [6,6,"精英+","3","1","#f85ef9",3400,600,25,12,300,5000,70],
    [7,7,"史诗","4","0","#efce48",3400,600,30,12,400,6000,90],
    [8,8,"史诗+","4","1","#efce48",3400,600,30,13,500,7000,110],
    [9,9,"传说","5","0","#ff2525",3400,600,30,13,600,8000,130],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new equipLevelConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    equipLevelConfig .push(r);

}

export default equipLevelConfig
