const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","rank","reward",]

export class arenahighrankrewardconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 排名
         **/
        @SafeProperty
        rank?:any

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:any

}

let arenahighrankrewardconfig:arenahighrankrewardconfigRow []=[];

var rowData=
[
    [1,[1,1],[[10001,10000],[10002,100]]],
    [2,[2,2],[[10001,10000],[10002,100]]],
    [3,[3,3],[[10001,10000],[10002,100]]],
    [4,[4,10],[[10001,10000],[10002,100]]],
    [5,[11,20],[[10001,10000],[10002,100]]],
    [6,[21,50],[[10001,10000],[10002,100]]],
    [7,[51,100],[[10001,10000],[10002,100]]],
    [8,[101,200],[[10001,10000],[10002,100]]],
    [9,[201,500],[[10001,10000],[10002,100]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new arenahighrankrewardconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    arenahighrankrewardconfig .push(r);

}

export default arenahighrankrewardconfig
