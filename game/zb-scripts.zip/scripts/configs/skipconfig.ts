const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","skipID","skipname","icon",]

export class skipconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 跳转ID
         **/
        @SafeProperty
        skipID?:number

        /**
         * 跳转中文名
         **/
        @SafeProperty
        skipname?:string

        /**
         * 图标
         **/
        @SafeProperty
        icon?:string

}

let skipconfig:skipconfigRow []=[];

var rowData=
[
    [1,0,"快速挂机"],
    [2,1,"摩天楼"],
    [3,2,"好友"],
    [4,3,"抽卡机","skip_icon_chouka"],
    [5,4,"公会"],
    [6,5,"竞技场"],
    [7,6,"悬赏"],
    [8,7,"智慧树"],
    [9,8,"商店","skip_icon_shangdian"],
    [10,9,"花房"],
    [11,10,"改名"],
    [12,11,"充值"],
    [13,12,"主界面"],
    [14,13,"地牢"],
    [15,14,"共享花坛"],
    [16,15,"英雄列表"],
    [17,16,"VIP赠送","skip_icon_VIP"],
    [18,17,"首充","skip_icon_huodong"],
    [19,18,"新手基金","skip_icon_huodong"],
    [20,19,"抽卡机","skip_icon_chouka"],
    [21,20,"七日签到","skip_icon_huodong"],
    [22,21,"新手礼包","skip_icon_libao"],
    [23,22,"新手光环","skip_icon_huodong"],
    [24,23,"开服竞赛","skip_icon_huodong"],
    [25,24,"高阶竞技场商店","skip_icon_shangdian"],
    [26,25,"新手任务","skip_icon_huodong"],
    [27,26,"神器"],
    [28,27,"地牢"],
    [29,28,"奇妙时空"],
    [30,29,"资源副本"],
    [31,30,"寻宝商店","skip_icon_zhuanpan"],
    [32,31,"日常寻宝","skip_icon_huodong"],
    [33,32,"精英寻宝","skip_icon_huodong"],
    [34,33,"智慧树商店","skip_icon_shangdian"],
    [35,34,"心愿机","skip_icon_niudan"],
    [36,35,"英雄合成","skip_icon_huodong"],
    [37,36,"高阶竞技场"],
    [38,37,"限时铺子","skip_icon_huodong"],
    [39,38,"联盟抽卡"],
    [40,39,"月令","skip_icon_huodong"],
    [41,40,"补给站","skip_icon_huodong"],
    [42,41,"时装商店","skip_icon_shangdian"],
    [43,42,"公会副本","skip_icon_huodong"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new skipconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    skipconfig .push(r);

}

export default skipconfig
