const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["uid","type","errorcode","reason","msgcn","msgen","param",]

export class ServerErrorCodeConfigRow{

        /**
         * 参数ID
         **/
        @SafeProperty
        uid?:uid

        /**
         * 错误类型
         **/
        @SafeProperty
        type?:number

        /**
         * 错误码
         **/
        @SafeProperty
        errorcode?:string

        /**
         * 原因(仅表示出现该错误的原因)
         **/
        @SafeProperty
        reason?:string

        /**
         * 中文错误信息（可修改）
说明:
错误码：
【格式】系统_一级错误_二级错误_....._N级错误 
如 ROLE_NULL
错误信息：
【格式】说明性文字[错误参数(该项非必有)] 
如 Role Can Not Found[对应的RoleId]
如 Equip Can Not Found[对应的EquipId]
如 数量不足[对应的Id]
如 进度不足[5/10]
         **/
        @SafeProperty
        msgcn?:string

        /**
         * 英文错误信息（可修改）
         **/
        @SafeProperty
        msgen?:string

        /**
         * 错误参数
         **/
        @SafeProperty
        param?:string

}

let ServerErrorCodeConfig:ServerErrorCodeConfigRow []=[];

var rowData=
[
    [1,1,"ACTIVE_RECV_ALREADY","活跃任务奖励已领取","活跃任务奖励已领取","Active Reward Already Recv","活跃任务的configId"],
    [2,1,"ARENA_REVENGE_NOT_FOUND","记录不存在或已复仇","记录不存在或已复仇","Record Not Exists Or Have Revenged"],
    [3,1,"ARTIFACT_BELONG_ERROR_HERO","神器不属于英雄","神器不属于英雄","Artifact Belong Error","artifactId-heroId"],
    [4,1,"ARTIFACT_BELONG_ERROR_ROLE","神器不属于用户","神器不属于用户","Artifact Belong Error","artifactId-roleId"],
    [5,1,"ARTIFACT_NOT_FOUND","找不到神器","找不到神器","Artifact Not Found","artifactId"],
    [6,1,"BATTLE_DEFHERO_NULL","对战英雄数据为空","对战英雄数据为空","Battle Hero Data NULL","roleId"],
    [7,1,"BATTLE_DEFHERO_SAME","上阵中有相同英雄","上阵中有相同英雄","Same Hero In Battle"],
    [8,1,"BATTLE_HTTP_REQUEST","战斗服返回错误","战斗服返回错误","Battle Service Error","错误信息"],
    [9,1,"BATTLE_RECORD_OVERDUE","战斗录像已过期","战斗录像已过期","Battle Record is out of date","文件名称"],
    [10,1,"CONFIG_NULL","找不到配置","找不到配置","Config Not Found","配置类型-检索字段:值,检索字段:值,..."],
    [11,1,"ENUM_NULL","没有在枚举中找到项","没有在枚举中找到项","Enum Not Found","枚举类型-检索字段:值"],
    [12,1,"EQUIP_BELONG_ERROR_HERO","装备不属于英雄","装备不属于英雄","Equip Belong Error","equipId-heroId"],
    [13,1,"EQUIP_BELONG_ERROR_ROLE","装备不属于用户","装备不属于用户","Equip Belong Error","equipId-roleId"],
    [14,1,"EQUIP_CHANGE_CAREER_ERROR","无法替换穿着不同职业装备","无法替换穿着不同职业装备","Can Not Change Equips DiffCareer ","原equipId-新equipId"],
    [15,1,"EQUIP_CHANGE_PLACE_ERROR","无法替换穿着不同部位装备","无法替换穿着不同部位装备","Can Not Change Equips DiffPlace","原equipId-新equipId"],
    [16,1,"EQUIP_NOT_FOUND","找不到装备","找不到装备","Equip Not Found","equipId"],
    [17,1,"FETTER_ACTIVED","羁绊已经激活","该羁绊已开启，无需重复开启","Fetter Actived"],
    [18,1,"FLOWER_HERO_MAX","共享花坛空位已满","共享花坛空位已满","FlowerPlace Up To Limit"],
    [19,1,"FLOWER_HERO_TOP","前五名的英雄无法加入共享花坛","前五名的英雄无法加入共享花坛","Hero Cant Join FlowerPlace","heroIds"],
    [20,1,"FRIEND_APPLY_SELF","不能操作自己","不能对自己进行该操作","Can Not Operate Self"],
    [21,1,"FRIEND_BLCAKLIST","在黑名单中","你在对方的黑名单中","In BlackList","在别人黑名单里的roleId-黑名单所属者的roleId"],
    [22,1,"FRIEND_COUNT_MAX","好友数量达到上限","好友数量达到上限","Friend Reach The Upper Limit","roleId-当前数量/上限数量"],
    [23,1,"FRIEND_POINT_RECV_MAX","友情点领取达到上限","友情点领取达到上限","Recv Reaches The Upper Limit","领取上限"],
    [24,1,"FRIEND_POINT_RECV_NOT","没有该好友赠送的友情点可领取","没有该好友赠送的友情点可领取","Have Not Sent To You","好友roleId"],
    [25,1,"FRIEND_POINT_RECVED","已经领取过","已经领取过","Already Recv"],
    [26,1,"FRIEND_POINT_SEND_MAX","友情点赠送达到上限","友情点赠送达到上限","Send Reaches The Upper Limit","赠送上限"],
    [27,1,"FRIEND_POINT_SENT","已经赠送过","已经赠送过","Already Sent"],
    [28,1,"GACHA_TIMES_ENOUGH_NOT","次数不足","次数不足","Times Not Enough","目前次数/需要次数"],
    [29,1,"GIFT_SEVEN_DAY_ENOUGH_NOT","七天签到奖励领取时，签到天数不足","签到天数不足","Sign Day Not Enough","当前值/需要值"],
    [30,1,"GLOBAL_CHECK_ILLEGAL","含有敏感字符","内容非法","Para Illegal"],
    [31,1,"GOOD_CONSUM_ENOUGH_NOT","消耗品不足","消耗品不足","Consum Not Enough"],
    [32,1,"GOOD_COUNT_MUL_CHECK_60","数量必须是60的倍数","数量必须是60的倍数","Goods Need Multiple Of 60","当前个数"],
    [33,1,"GOOD_DIAMOND_ENOUGH_NOT","钻石不足","钻石不足","Diamond Not Enough","当前值/需要值"],
    [34,1,"GROWUP_CLOSE","成长计划没有激活","成长计划没有激活","Growup Plan Not Active","roleId"],
    [35,1,"GROWUP_PROGRESS_NOT","任务进度未完成","任务进度未完成","Insufficient Progress","当前进度/需要进度"],
    [36,1,"GROWUP_RECV_ALREADY","成长奖励已经领取过，不能重复领取","无法重复领取","Recv Already","growUpConfigId"],
    [37,1,"GUILD_ACTIVE_ENOUGH_NOT","公会活跃值不足","公会活跃值不足","Active Score Not Enough","当前值/需要值"],
    [38,1,"GUILD_ALREADY_IN","已经在一个公会中","已经在一个公会中","Already In A Guild","当前公会ID"],
    [39,1,"GUILD_APPLY_ALREADY","已经申请过该公会","已经申请过该公会","Submit Already"],
    [40,1,"GUILD_CONFIG_OOR","超过配置范围","超过配置范围","Out Of Range","范围（可能是数组）"],
    [41,1,"GUILD_EXIT_SUBMIT_CD","退出公会后需要经过一段CD才能再申请加入公会","退出公会一小时内无法加入公会","Cant Join Guild Util Cd"],
    [42,1,"GUILD_JOB_APPOINT_SELF","无法任命自己","无法任命自己","Can Not Appoint Self"],
    [43,1,"GUILD_JOB_KICK_SELF","无法踢出自己","无法踢出自己","Can Not Kick Self"],
    [44,1,"GUILD_JOB_MAX","职位没有空余","职位没有空余","Job Reach The Upper Limit","职位ID"],
    [45,1,"GUILD_JOIN_CANT","无法加入公会","无法加入公会","Guild Can Not Join","公会ID"],
    [46,1,"GUILD_MEMBER_MAX","公会成员达到上限","公会成员达到上限","Member Reach The Upper Limit","当前数量/上限数量"],
    [47,1,"GUILD_NAME_ILLEGAL","公会名非法","公会名非法","Guild Name Illegal"],
    [48,1,"GUILD_NAME_SAME","公会名已存在","公会名已存在","Guild Name Exist"],
    [49,1,"GUILD_NO_ROLE","当前未加入公会","当前未加入公会","Have No Guild"],
    [50,1,"GUILD_NOT_FOUND","公会不存在","公会不存在","No Guild","公会ID"],
    [51,1,"GUILD_NOTICE_LENGTH","公告不能超过长度","公告不能超过长度","Notice Cant Exceed","长度上限"],
    [52,1,"GUILD_PRESIDENT_HANDOVER","请先转交会长职务","请先转交会长职务","Hand Over President First"],
    [53,1,"GUILD_RIGHT_NOT","权限不足","权限不足","Insufficient Authority"],
    [54,1,"GUILD_ROLE_NOT_IN","玩家不在公会中","玩家不在公会中","Not in Guild","玩家ID-公会ID"],
    [55,1,"HANGUP_QUICK_MAX","快速挂机次数耗尽","快速挂机次数耗尽","Reach The Upper Limit","当前数量/上限数量"],
    [56,1,"HELP_HERO_ERROR","外援英雄错误","外援英雄错误","HelpHero Error"],
    [57,1,"HELP_HERO_UPDATE","无法更新佣兵状态","无法更新佣兵状态","Can Not Update HelpHero Status"],
    [58,1,"HERO_BELONG_ERROR","英雄不属于用户","英雄不属于用户","Hero Belong Error","heroId-roleId"],
    [59,1,"HERO_CAPACITY_ENOUGH_NOT","英雄空位不足","英雄空位不足","Hero Capacity Not Enough"],
    [60,1,"HERO_LOCKED","英雄已被锁定","英雄已被锁定","Hero Locked","英雄IDs"],
    [61,1,"HERO_LV_ALREADY_REACH","英雄已经达到该等级","英雄已经达到该等级","Already Reach Level","当前等级/要达到的等级"],
    [62,1,"HERO_NOT_FOUND","找不到英雄","找不到英雄","Hero Not Found","heroIds"],
    [63,1,"HERO_RANK_MAX","已达到品阶上限","已达到品阶上限","Rank Up To Limit"],
    [64,1,"HERO_RANK_TYPE_MATCH_NOT","升阶消耗英雄类型不匹配","升阶消耗英雄类型不匹配","Hero Not Match","被升阶英雄configId-当前品阶-需要消耗的数量"],
    [65,1,"HTTP_PARA_ERROR","参数错误","参数错误","Para Error","错误原因或错误的参数内容"],
    [66,1,"HUTTER_CREATE_CANT","管理员开启狩猎时，由于当前存在进行中的狩猎，没法再创建了","已存在狩猎","Hunt Opened"],
    [67,1,"HUTTER_HITCOUNT_MAX","攻击次数用尽","没有攻击次数","Times Reach The Upper Limit","当前数量/上限数量"],
    [68,1,"HUTTER_NOT_CREATE","远古狩猎活动没有开启","活动尚未开启，请联系公会管理员开启","Hunt Not Start","公会狩猎type"],
    [69,1,"HUTTER_OVER","狩猎已经结束","狩猎已经结束","The Hunt Is Over"],
    [70,1,"KAOSHANG_PROGRESS_NOT","任务进度未完成","任务进度未完成","Insufficient Progress","当前进度/需要进度"],
    [71,1,"MERC_APPLY_ONWER_TIMEOUT","该玩家不是好友或公会成员或超过七天未上线，不能借用","不能借用该玩家的英雄","Can Not Apply","roleId"],
    [72,1,"MERC_APPLY_SELF","不能操作自己","不能操作自己","Can Not Operate Self"],
    [73,1,"MERC_LOANED_OUT","英雄已经被借出","英雄已经被借出","Hero Has Been Loaned Out","英雄ID"],
    [74,1,"MERC_SUC_MAX","没有空余的佣兵位","没有空余的佣兵位","Merc Reach The Upper Limit","当前数量/上限数量"],
    [75,1,"MONTHCARD_CLOSE","月卡没有激活","月卡没有激活","Card Not Active","roleId-cardType"],
    [76,1,"MONTHCARD_RECV_ALREADY","月卡奖励已经领取过，不能重复领取","无法重复领取","Recv Already","roleId-storeConfigId"],
    [77,1,"PROCESS_STAGE_ERROR","已经过关或过关条件不足","已经过关或过关条件不足","Already Passed Or Can Not Jump","关卡ID"],
    [78,1,"ROLE_LV_REWARD_ALREADY","玩家没有升级奖励可以领取","没有可以领取的奖励","No Reward","已领等级/当前等级"],
    [79,1,"ROLE_NICK_ILLEGAL","昵称非法","昵称非法","Nick illegal"],
    [80,1,"ROLE_NICK_REPEAT","昵称重名","该昵称已被占用","Nickname Already In Use"],
    [81,1,"ROLE_NOT_FOUND","找不到玩家","找不到玩家","No Player","roleId"],
    [82,1,"ROLE_SIGN_ILLEGAL","签名非法","签名非法","Signature Illegal"],
    [83,1,"SHOP_ITEM_NOT_FOUND","找不到商品","找不到商品","Item Not Found","roleId-商店类型-商品位号"],
    [84,1,"SHOP_REMAIN_ENOUGH_NOT","可购买次数不足","可购买次数不足","Item Remain Not Enough"],
    [85,1,"STORE_BUY_MAX","购买的商品已经达到购买上限","达到上限无法购买","Buy Count Reach The Upper Limit","roleId-storeConfigId"],
    [86,1,"STORE_BUY_TIMEOUT","购买的商品不在购买时间段","不在购买时间","Buy Time Not","roleId-storeConfigId"],
    [87,1,"STORE_FSTREWARD_NOT","首充奖励未激活，不能领取","完成首充才能领取","First Charge Not Finished"],
    [88,1,"STORE_FSTREWARD_RECVED","首充奖励已经领取过，不能重复领取","无法重复领取","Recv Already"],
    [89,1,"STORE_TRADE_NOT","支付订单不存在","订单不存在","Order Not Exist","订单号"],
    [90,1,"TASK_PROGRESS_NOT","任务进度未完成","任务进度未完成","Insufficient Progress","当前进度/需要进度"],
    [91,1,"TASK_RECV_ALREADY","任务奖励已领取","任务奖励已领取","Task Reward Already Recv","taskId"],
    [92,1,"TASK_RECV_FIALED","领取失败","领取失败","Recv Failed","taskId"],
    [93,1,"VIP_ENOUGH_NOT","领取VIP奖励时，领取的VIP奖励等级高于实际等级，无法领取","VIP等级不足","Vip Lv Not Enough","当前等级/需要等级"],
    [94,1,"VIP_RECV_ALREADY","VIP奖励已经领取过，不能重复领取","无法重复领取","Recv Already","roleId-vip等级"],
    [95,1,"WISDOM_REWARD_LAYER_RECVED","本层奖励已经领取过，不能重复领取","无法重复领取","Recv Already","roleId-层ID"],
    [96,1,"WISDOM_REWARD_NODE_RECVED","本关奖励已经领取过，不能重复领取","无法重复领取","Recv Already","roleId-节点id"],
    [97,1,"WISDOM_SHOP_ITEM_NOT_FOUND","找不到商品","找不到商品","Item Not Found","roleId-商店ID-商品位号"],
    [98,1,"WISDOM_SHOP_ITEM_SELL_CANT","由于商店已经被购买过其它商品，无法购买","无法购买","Can Not Buy","roleId-商店ID-商品位号"],
    [99,1,"WISDOM_SHOP_ITEM_SELLOUT","商品售罄","商品售罄","Item Sell Out","roleId-商店ID-商品位号"],
    [100,1,"XS_TASK_ALREADY_OPEN","悬赏任务已开启","悬赏任务已开启","Task Already Turned On","悬赏ID"],
    [101,1,"XS_TASK_HERO_CAMP","未达到阵营要求","未达到阵营要求","Not Up To Camp Require"],
    [102,1,"XS_TASK_HERO_COUNT","英雄数量不合法","英雄数量非法","Number Of Hero Illegal","需要多少个英雄"],
    [103,1,"XS_TASK_HERO_RANK_COUNT","指定品阶的英雄数量不足","指定品阶的英雄数量不足","Number Of Rank Hero Illegal","需要的品阶-当前个数/需要的个数"],
    [104,1,"XS_TASK_HERO_USING","英雄已被占用","英雄已被占用","Hero Occupied"],
    [105,1,"XS_TASK_NOT_EXIST","悬赏任务不存在","悬赏任务不存在","Task Not Exist","悬赏ID"],
    [106,1,"XS_TASK_NOT_OPEN","悬赏任务未开启","悬赏任务未开启","Task Not Turned On"],
    [107,1,"XS_TASK_REFRESH_NOT","没有可以刷新的任务","没有可以刷新的任务","No Task Refresh"],
    [108,1,"XS_TASK_TIME_NOT_ARRI","悬赏任务尚未完成","悬赏任务尚未完成","Time Not Arrived","悬赏ID"],
    [109,1,"VIDEO_COUNT_ENOUGH_NOT","视频次数不足","视频次数不足","Insufficient Video Count","次数上限"],
    [110,1,"VIDEO_SHOP_CANT","商品不支持广告获取","不支持广告获取","Video Buy Cant"],
    [111,1,"GUILD_SUBMIT_MAX","公会申请数量达到上限","公会申请数量达到上限","Guild Submit Count Upper Limit"],
    [112,1,"ARENA_NORMAL_TIME_CLOSE","竞技场休赛","赛季将在%s:%s:%s后开始","Will Start After %s:%s:%s"],
    [113,1,"HUTTER_CREATE_MAX","管理员开启狩猎时，由于当前次数已经用尽，没法再创建了","开启次数达到上限","Times Reach The Upper Limit"],
    [114,1,"EQUIP_NO_CHANGE","新老装备没有发生变化，穿装失败","装备无变化","Equip No Change"],
    [115,1,"ACTIVITY_NOT_FOUND","领取活动奖励时，由于活动无法找到，领取失败","活动不存在或已结束","Activity Not Found","actId"],
    [116,1,"ACTIVITY_RECV_ALREADY","活动奖励已领取","任务奖励已领取","Activity Reward Already Recv","actId:领取标识1-领取标识2-....."],
    [117,1,"ACTIVITY_PROGRESS_NOT","活动进度未完成","活动进度未完成","Insufficient Progress","当前进度/需要进度"],
    [118,1,"ACTIVITY_REWARD_CONFIG_NOT","活动奖励配置不存在","活动奖励配置不存在","Activity Reward Config Not Found"],
    [119,1,"ACTIVITY_STEP_NOT","由于僵尸/玩家已经达到的步数比请求的步数高，接口参数错误","不能后退","Can Not Back","请求步数/当前步数"],
    [120,1,"EXCODE_FAIL","兑换失败","兑换失败","Code Fail","兑换码"],
    [121,1,"EXCODE_INVALID","兑换码无效","兑换码无效","Code Invalid","兑换码"],
    [122,1,"EXCODE_USED","兑换码已使用","兑换码已使用","Code Used","兑换码"],
    [123,1,"EXCODE_REWARD_ALREADY","奖励已领取","奖励已领取","Code Reward Already Recv","兑换码"],
    [124,1,"ACTIVITY_END","活动已结束","活动已结束","Activity Is Over","活动ID"],
    [125,1,"ACTIVITY_CHESS_TEN_ENOUGH_NOT","骰子不足十个，不能进行十连","骰子不足","Dice Not Enough","现有个数"],
    [126,1,"GUILD_BOSS_NOT_LAZY","会长并没有离线超过七天，不能弹劾","当前不满足弹劾要求","Insufficient Conditions For Impeachment","会长上次离线时间/七天前的时间戳"],
    [127,1,"GUILD_STATUE_LV_MAX","公会雕像的部位已经达到当前等级上限，无法升级","达到上限，无法升级","Statue Lv Reach The Upper Limit","上限等级"],
    [128,1,"GUILD_HELP_SEND_ENOUGH_NOT","在进行公会互助时，自己的赠送次数不足","赠送次数不足","Send Times Not Enough","当前次数/上限次数"],
    [129,1,"GUILD_TABLE_ENOUGH_NOT","公会转盘剩余次数不足","次数不足","Times Not Enough","当前次数/上限次数"],
    [130,1,"REDPACK_TIMEOUT","红包已经过期无法领取","红包已过期","Redpack Timeout"],
    [131,1,"REDPACK_FINISH","红包已经抢完","红包已经抢完","Redpack Finish"],
    [132,1,"REDPACK_RECV_ALREADY","已经领取过红包","已领取","Redpack Already Recv","红包ID"],
    [133,1,"REDPACK_AVG_ERROR","红包金额不能小于红包人数","红包金额不能小于红包人数","Redpack Amt Must Bigger Than Count"],
    [134,1,"REDPACK_CREATE_ERROR","红包金额/人数都不能为0","金额(个数)不能为0","Amt(Count) Can Not Be Zero"],
    [135,1,"REDPACK_NOT_FOUND","红包不存在","红包不存在","Redpack Not Found","红包ID"],
    [136,1,"DUNGEON_MAX","地牢已经没有下一层了","您已打到顶层","Dungeon Max"],
    [137,1,"TASK_RECV_TEN_ENOUGH_NOT","先锋奖励十个才能领取，当前可领数量不足十个","不足十个，无法领取","Goods Not Enough","当前票数/要求票数"],
    [138,1,"ACTIVITY_PIONEER_ENOUGH_NOT","可领取次数未达到最小领取配置次数","次数不足","Times Not Enough","目前次数/需要次数"],
    [139,1,"GUILD_STATUE_DAY_MAX","达到每日强化上限","今日铸造已满，请明日再来铸造！","Statue Exp Reach The Day Upper Limit","提交的强化经验/剩余可强化经验"],
    [140,1,"GOOD_COUNT_MAX","物品达到最高拥有上限","达到最高上限，无法领取","Count Reach The Upper Limit","当前数量/上限数量"],
    [141,1,"REDPACK_ENOUGH_NOT","红包领取次数不足","次数不足","Times Not Enough","当前次数/上限次数"],
    [142,1,"REDPACK_SEND_ENOUGH_NOT","红包发放要求未达到次数不足","次数不足","Times Not Enough"],
    [143,1,"REDPACK_SEND_ALREADY","红包成就红包无法重复发放","该红包已发放","Reward Already Send"],
    [144,1,"TALENT_POINT_ENOUGH_NOT","天赋点不足","天赋点不足","Talent Point Not Enough","当前次数/要求次数"],
    [145,1,"TALENT_OPENED","天赋已经开启，无需重复开启","天赋已开启","Talent Already Opened","天赋ID"],
    [146,1,"TALENT_CONDITION_ENOUGH_NOT","前置条件不足","前置条件不足","Talent Preconditon Not Enough"],
    [147,1,"GUILD_JOIN_CD","加入公会的24小时内，无法使用转盘和攻击公会BOSS","%s后可使用","After %s Open"],
    [148,1,"TALENT_ACTIVE_FIRST","没有激活天赋树就点亮天赋","请先激活天赋树","Active Tree First"],
    [149,1,"TELENT_RESET_NONEED","没有重置天赋数的必要","无需重置","No Need Reset"],
    [150,1,"ARENA_ADV_COIN_NO","没有可以领取的角斗士币","没有硬币可以领取","No Coin Recv"],
    [151,1,"ACTIVITY_PIONEER_CHARGE_ALREADY","能量点已充入","能量点已充入","Point Already Charge"],
    [152,1,"SERVER_BATTLE_WAIT","战斗服尚未返回，战斗记录不存在","请稍后再试","Plz Try Again Later"],
    [153,1,"ACTIVITY_TREAINST_FREWARD_CHANGE_NOT","无法更换终极奖励","无法更换终极奖励","Can Not Change Final Reward","活动ID"],
    [154,1,"ACTIVITY_TREAINST_FREWARD_NOT","终极奖励尚未设置","终极奖励尚未设置","No Final Reward","活动ID"],
    [155,1,"GIFT_REWARD_NO","没有奖励可以领取","没有可以领取的奖励","No Reward"],
    [156,1,"ACTIVITY_TREAINST_FREWARD_FIRST","需要先领取终极奖励","请先领取终极奖励","Final Reward Recv Not","活动ID"],
    [157,1,"SEVENFUND_CLOSE","新手基金没有激活","基金没有激活","Growup Plan Not Active","roleId"],
    [158,1,"SERVER_VERSION_UPDATE","服务器不支持此版本的请求，需要使用更新的客户端","客户端版本需要更新","You Should Update Your Client"],
    [159,1,"ARTIFACT_LVUP_LV_NOT","神器升级可能需要玩家达到某个等级才能升级","等级不足","Lv Enough Not","当前等级/需要等级"],
    [160,1,"RMISSION_SWEEP_ENOUGH_NOT","没有剩余次数","没有剩余次数","Times Not Enough"],
    [161,1,"RMISSION_SWEEP_CANT","没有通关副本无法扫荡","没有通关副本无法扫荡","Can Not Sweep"],
    [162,1,"GASHAPON_POOL_NOT","英雄池中不存在该英雄","英雄池中不存在该英雄","Hero Not Found"],
    [163,1,"ARTIFACT_UNLOCK_FIRST","需要先解锁神器才能进行下一步操作","请先解锁神器","Artifact Must Unlock"],
    [164,1,"HERO_STAR_MAX","已达到星级上限","已达到星级上限","Star Up To Limit"],
    [165,1,"HERO_STAR_ENOUGH_NOT","升阶时，英雄所需星级不足","英雄星级不足","Star Not Enough"],
    [166,1,"HERO_LV_ENOUGH_NOT","升星时，英雄所需等级不足","英雄等级不足","Lv Not Enough","当前等级/需要等级"],
    [167,1,"HERO_QUALITY_NOT","置换时，品质不符","英雄品质不正确","Quality Not Match","当前品质/需要品质"],
    [168,1,"HERO_RANK_NOT","置换时，品阶不符","英雄品阶不正确","Rank Not Match","当前品阶/需要品阶"],
    [169,1,"HERO_ENOUGH_NOT","活动兑换、合成等消耗英雄的场景中，英雄条件不匹配","英雄条件不匹配","Hero Not Match"],
    [170,1,"EQUIP_ENOUGH_NOT","活动兑换、合成等消耗装备的场景中，装备条件不匹配","装备条件不匹配","Equip Not Match"],
    [171,1,"CLONEBAT_COUNT_ENOUGH_NOT","没有剩余次数","没有剩余次数","Times Not Enough"],
    [172,1,"TREABOX_COUNT_ENOUGH_NOT","没有剩余次数","没有剩余次数","Times Not Enough"],
    [173,1,"SUPPLY_TILI_ENOUGH_NOT","搜寻补给站时，体力不足","体力不足","Energy Not Enough","当前体力/需要体力"],
    [174,1,"SUPPLY_COUNT_ENOUGH_NOT","没有剩余次数","没有剩余次数","Times Not Enough"],
    [175,1,"FETTER_MATCH_NOT","羁绊激活条件不匹配","激活条件不匹配","Fetter Not Match"],
    [176,1,"SKIN_MATCH_NOT","英雄和皮肤不匹配","英雄和皮肤不匹配","Skin Not Match"],
    [177,1,"FLOWER_HERO_EQUIP_NOT","共享花坛的英雄无法佩戴装备","共享花坛英雄无法穿着装备","Hero In FlowerPlace Cant Equip"],
    [178,1,"FLOWER_HERO_LVUP_NOT","共享花坛的英雄无法升级","共享花坛英雄无法升级","Hero In FlowerPlace Cant Lv Up"],
    [179,1,"FLOWER_HERO_RANKUP_NOT","共享花坛的英雄无法升阶","共享花坛英雄无法升阶","Hero In FlowerPlace Cant Rank Up"],
    [180,1,"EQUIP_INHERIT_NOT","目标装备全面优于源装备，无需继承","无需继承","Inherit Need Not","源装备ID/目标装备ID"],
    [181,1,"EQUIP_RESET_NOT","重置装备时，参数中没有符合条件的装备","没有装备可以重置","Have No Equip Reset"],
    [182,1,"EQUIP_COMP_NOT","合成装备时，参数中没有符合条件的装备","没有装备可以合成","Have No Equip Compound"],
    [183,1,"ARTIFACT_FORGECHANGE_PRE_NOT","装备铸造转化时，没有提前预览导致转化数据为空","没有可以接受的结果","Forge Change Result Not"],
    [184,1,"TOWER_SEARCH_BUY_MAX","购买摩天楼搜寻次数时，购买次数已经达到上限","达到上限，无法购买","Buy Count Limit","当前次数/上限次数"],
    [185,1,"TOWER_SEARCH_COUNT_ENOUGH_NOT","搜寻摩天楼时，没有剩余次数","没有剩余次数","Times Not Enough"],
    [186,1,"ARENA_FRESH_COUNT_ENOUGH_NOT","刷新竞技场匹配结果时，没有剩余次数","没有剩余次数","Times Not Enough"],
    [187,1,"GUILD_TECH_TYPE_LV_MAX","该项公会科技己经达到上限","已达到等级上限","Lv Up To Limit"],
    [188,1,"HUNTER_BUY_MAX","公会狩猎的可购买次数已用完","达到上限，无法购买","Buy Count Limit","当前次数/上限次数"],
    [189,1,"GUILD_JOURNEY_TIME_CLOSE","公会副本休赛期","公示中，新一轮副本将在%s:%s:%s后开始","Will Start After %s:%s:%s"],
    [190,1,"GUILD_HEGE_IN_SIGN","不在报名时间内","不在报名时间内","Not In Sign Time"],
    [191,1,"GUILD_HEGE_IN_BATTLE","公会争霸时，所进攻的节点正在战斗中","资源点战斗中，请稍后再试","Node In Battle"],
    [192,1,"GUILD_HEGE_NODE_MAX","公会争霸时，拥有资源点数量已经达到上限","拥有资源点达到上限","Node Up To Limit"],
    [193,1,"GUILD_HEGE_TILI_ENOUGH_NOT","公会争霸时，体力不足","体力不足","Energy Not Enough","当前体力/需要体力"],
    [194,1,"GUILD_HEGE_BATTLE_SEQ_ERROR","公会争霸时，节点战斗序列号不同，需要刷新节点数据","资源点数据需要更新","Node Data Need Update","提交的序列号/当前需要的序列号"],
    [195,1,"GUILD_HEGE_BATTLE_SELF","公会争霸时，不能攻打自己的资源点","不能攻击自己的资源点","Can Not Attack Self"],
    [196,1,"GUILD_HEGE_COLLECT_SELF","公会争霸时，不能获取不是自己的资源点的资源","只能收获自己的资源点","Can Not Collect Node Not Self"],
    [197,1,"GUILD_JOURNEY_RECV_LATE","领取公会副本讨伐宝箱时，该位置已经被领走","被人抢先一步，换一个宝箱吧","Been Recved By Someone Else"],
    [198,1,"MEDAL_LV_MAX","勋章等级升级时，已经达到顶级无法升级","已达到最高等级","Medal Lv Reaches The Upper Limit"],
    [199,1,"MEDAL_TOPPOWER_ENOUGH_NOT","勋章等级升级时，历史最高战力记录未达到要求","战力不足","Power Not Enough"],
    [200,1,"MEDAL_LV_ENOUGH_NOT","勋章等级升级时，玩家等级不足","等级不足","Lv Enough Not"],
    [201,1,"STRATEGIC_LV_MAX","战略树节点升级，已经达到顶级无法升级","已达到最高等级","Strategic Lv Reaches The Upper Limit"],
    [202,1,"STRATEGIC_CONDITION_ENOUGH_NOT","前置条件不足","前置条件不足","Strategic Preconditon Not Enough"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new ServerErrorCodeConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    ServerErrorCodeConfig .push(r);

}

export default ServerErrorCodeConfig
