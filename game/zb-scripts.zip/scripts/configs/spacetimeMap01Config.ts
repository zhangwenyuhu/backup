const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","eventtype","eventnumber","battle","level",]

export class spacetimeMap01ConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 事件类型
         **/
        @SafeProperty
        eventtype?:number

        /**
         * 事件数量
         **/
        @SafeProperty
        eventnumber?:number

        /**
         * 配置
         **/
        @SafeProperty
        battle?:any

        /**
         * 等级
         **/
        @SafeProperty
        level?:any

}

let spacetimeMap01Config:spacetimeMap01ConfigRow []=[];

var rowData=
[
    [1001,1001,0,[872004,872004,871004,873004,871004],[80,80,80,80,80]],
    [1002,1002,0,[881004,881004,8834004,888004,882004],[80,80,80,80,80]],
    [1003,1002,0,[883004,883004,886004,8818004,883004],[90,90,90,101,90]],
    [1004,1001,0,[8832004,884004,873004,885004,873004],[85,85,85,85,85]],
    [1005,1002,0,[8819004,8819004,8820004,8820004,873004],[90,90,90,90,90]],
    [1006,1001,0,[8820004,8820004,8818004,873004,886004],[90,90,95,95,95]],
    [1007,1001,0,[872004,872004,8820004,885004,8820004],[95,95,95,95,95]],
    [1008,1003,0,[872004,872004,885004,8831004,8820004],[95,95,95,95,95]],
    [1009,1006,0,[20035,20033,20017,20031]],
    [1010,1006,0,[20013,20014,20025,20016]],
    [1011,1007,1,[[10001,150000]]],
    [1012,1008,1,[[10002,500]]],
    [1013,1010,1,[[10477,16]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new spacetimeMap01ConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    spacetimeMap01Config .push(r);

}

export default spacetimeMap01Config
