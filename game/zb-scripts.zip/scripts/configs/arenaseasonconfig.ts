const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","ranked","diamond","daydaimond",]

export class arenaseasonconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 排名范围
         **/
        @SafeProperty
        ranked?:number[]

        /**
         * 赛季奖励
         **/
        @SafeProperty
        diamond?:any

        /**
         * 每日奖励
         **/
        @SafeProperty
        daydaimond?:any

}

let arenaseasonconfig:arenaseasonconfigRow []=[];

var rowData=
[
    [1,[1,1],[[10002,800],[10441,30000]],[[10002,300],[10441,1500]]],
    [2,[2,3],[[10002,600],[10441,20000]],[[10002,200],[10441,1000]]],
    [3,[4,10],[[10002,400],[10441,15000]],[[10002,150],[10441,700]]],
    [4,[11,20],[[10002,300],[10441,10000]],[[10002,120],[10441,500]]],
    [5,[21,50],[[10002,240],[10441,8000]],[[10002,100],[10441,400]]],
    [6,[51,100],[[10002,200],[10441,7000]],[[10002,80],[10441,350]]],
    [7,[101,200],[[10002,160],[10441,6000]],[[10002,60],[10441,300]]],
    [8,[201,500],[[10002,120],[10441,5000]],[[10002,40],[10441,250]]],
    [9,[501,1000],[[10002,80],[10441,3000]],[[10002,30],[10441,150]]],
    [10,[1001,99999],[[10002,50],[10441,2000]],[[10002,10],[10441,100]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new arenaseasonconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    arenaseasonconfig .push(r);

}

export default arenaseasonconfig
