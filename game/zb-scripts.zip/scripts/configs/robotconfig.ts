const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","name","icon","level",]

export class robotconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 昵称
         **/
        @SafeProperty
        name?:string

        /**
         * 头像
         **/
        @SafeProperty
        icon?:string

        /**
         * 等级范围
         **/
        @SafeProperty
        level?:number[]

}

let robotconfig:robotconfigRow []=[];

var rowData=
[
    [1,"乱世枭雄","20001",[15,25]],
    [2,"心态王者","20002",[17,28]],
    [3,"一世蒼涼","20003",[26,32]],
    [4,"窃忠魂","20004",[19,34]],
    [5,"记忆时光","20005",[25,35]],
    [6,"不败菇凉","20006",[36,46]],
    [7,"樱小珞","20007",[40,50]],
    [8,"风苍溪","20008",[45,55]],
    [9,"酷影枫","20009",[50,60]],
    [10,"冷千翼","20010",[55,65]],
    [11,"战临枪","20011",[60,70]],
    [12,"长空","20012",[70,80]],
    [13,"七月殇","20013",[75,85]],
    [14,"冷酷的云","20014",[85,95]],
    [15,"饮长风","20015",[90,110]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new robotconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    robotconfig .push(r);

}

export default robotconfig
