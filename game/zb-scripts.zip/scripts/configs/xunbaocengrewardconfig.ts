const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","numberofplies","reward",]

export class xunbaocengrewardconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 生效层数
zhangchenxue:
数字相同的为同一个奖池
         **/
        @SafeProperty
        numberofplies?:number

        /**
         * 奖励
普通：goodsconfig

         **/
        @SafeProperty
        reward?:any

}

let xunbaocengrewardconfig:xunbaocengrewardconfigRow []=[];

var rowData=
[
    [1,1,[[10002,50]]],
    [2,3,[[10002,100]]],
    [3,5,[[10002,300],[10033,2]]],
    [4,7,[[10002,300],[10060,60]]],
    [5,9,[[10002,300],[10060,120]]],
    [6,11,[[10002,300],[10060,180]]],
    [7,13,[[10002,300],[10006,2]]],
    [8,15,[[10002,300],[10006,5]]],
    [9,17,[[10002,300],[10061,60]]],
    [10,19,[[10002,300],[10006,10]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new xunbaocengrewardconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    xunbaocengrewardconfig .push(r);

}

export default xunbaocengrewardconfig
