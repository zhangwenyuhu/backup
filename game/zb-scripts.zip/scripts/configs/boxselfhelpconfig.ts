const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","boxID","reward",]

export class boxselfhelpconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 自选宝箱ID
         **/
        @SafeProperty
        boxID?:number

        /**
         * 可选奖励
         **/
        @SafeProperty
        reward?:any

}

let boxselfhelpconfig:boxselfhelpconfigRow []=[];

var rowData=
[
    [1,10493,[10011,1]],
    [2,10493,[10012,1]],
    [3,10493,[10013,1]],
    [4,10493,[10016,1]],
    [5,10493,[10017,1]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new boxselfhelpconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    boxselfhelpconfig .push(r);

}

export default boxselfhelpconfig
