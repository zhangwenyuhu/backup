const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Level","ActivityPoint","MemberLimit","activelimit",]

export class GuildLevelConfigRow{

        /**
         * 等级
         **/
        @SafeProperty
        Level?:uid

        /**
         * 升至下级需要活跃值
         **/
        @SafeProperty
        ActivityPoint?:number

        /**
         * 公会人数上限
         **/
        @SafeProperty
        MemberLimit?:number

        /**
         * 活跃值上限
         **/
        @SafeProperty
        activelimit?:number

}

let GuildLevelConfig:GuildLevelConfigRow []=[];

var rowData=
[
    [1,10000,30,27000],
    [2,30000,35,31500],
    [3,50000,40,36000],
    [4,70000,45,40500],
    [5,90000,50,45000],
    [6,110000,55,49500],
    [7,130000,60,54000],
    [8,150000,65,58500],
    [9,170000,70,63000],
    [10,190000,75,67500],
    [11,210000,80,72000],
    [12,230000,85,76500],
    [13,250000,90,81000],
    [14,270000,95,85500],
    [15,290000,100,90000],
    [16,310000,105,94500],
    [17,330000,110,99000],
    [18,350000,115,103500],
    [19,370000,120,108000],
    [20,390000,125,112500],
    [21,410000,130,117000],
    [22,430000,135,121500],
    [23,450000,140,126000],
    [24,470000,145,130500],
    [25,490000,150,135000],
    [26,510000,155,139500],
    [27,530000,160,144000],
    [28,550000,165,148500],
    [29,570000,170,153000],
    [30,590000,175,157500],
    [31,610000,180,162000],
    [32,630000,185,166500],
    [33,650000,190,171000],
    [34,670000,195,175500],
    [35,690000,200,180000],
    [36,710000,205,184500],
    [37,730000,210,189000],
    [38,750000,215,193500],
    [39,770000,220,198000],
    [40,790000,225,202500],
    [41,810000,230,207000],
    [42,830000,235,211500],
    [43,850000,240,216000],
    [44,0,245,220500],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new GuildLevelConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    GuildLevelConfig .push(r);

}

export default GuildLevelConfig
