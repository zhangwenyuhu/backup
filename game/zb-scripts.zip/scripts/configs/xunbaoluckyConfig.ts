const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","rewardlimit","description","singlecount","cd","save","weight","number",]

export class xunbaoluckyConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 幸运效果名称
         **/
        @SafeProperty
        rewardlimit?:string

        /**
         * 描述
         **/
        @SafeProperty
        description?:string

        /**
         * 单轮内触发次数
         **/
        @SafeProperty
        singlecount?:number

        /**
         * 间隔时间
zhangchenxue:
按回合算
         **/
        @SafeProperty
        cd?:number

        /**
         * 是否继承
         **/
        @SafeProperty
        save?:number

        /**
         * 权重
zhangchenxue:
万分之一
         **/
        @SafeProperty
        weight?:number

        /**
         * 数量
         **/
        @SafeProperty
        number?:number

}

let xunbaoluckyConfig:xunbaoluckyConfigRow []=[];

var rowData=
[
    [1,"双倍来袭","获得该效果后，本层终极大奖将“双倍获得”！",1,1,0,10],
    [2,"天降福利","获得奇异花！",999,0,1,100,18],
    [3,"偷天换日","获得该效果后，有一次可更换终极奖励的机会",1,0,1,300],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new xunbaoluckyConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    xunbaoluckyConfig .push(r);

}

export default xunbaoluckyConfig
