const { SafeProperty } = slib;

import skillConfig,{skillConfigRow} from "./skillConfig"
import skillConfig,{skillConfigRow} from "./skillConfig"
import goodsConfig,{goodsConfigRow} from "./goodsConfig"

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","order","Name","Skill","SkillLv","SkillInitiative","SkillLvInitiative","icon","AtkRatio","DefRatio","HpRatio","CritRate","HitRate","DodgeRate","SkillSpeed","M_DeHarmRate","P_DeHarmRate","Golds","Goods","Counts","Spine","SpaceTime",]

export class artifactConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 排序
         **/
        @SafeProperty
        order?:number

        /**
         * 神器名
         **/
        @SafeProperty
        Name?:string

        /**
         * 关联技能
         **/
        @SafeProperty
        Skill?:fk

        protected _fkSkill?:skillConfigRow=undefined
        /**
         * 关联技能
         **/
        get SkillData(){
            if(this._fkSkill===undefined){
                this._fkSkill=skillConfig.find(a=>a.Id==this.Skill);
            }
            return this._fkSkill;
        }

        /**
         * 技能等级
         **/
        @SafeProperty
        SkillLv?:number[]

        /**
         * 关联技能
         **/
        @SafeProperty
        SkillInitiative?:fk

        protected _fkSkillInitiative?:skillConfigRow=undefined
        /**
         * 关联技能
         **/
        get SkillInitiativeData(){
            if(this._fkSkillInitiative===undefined){
                this._fkSkillInitiative=skillConfig.find(a=>a.Id==this.SkillInitiative);
            }
            return this._fkSkillInitiative;
        }

        /**
         * 技能等级
         **/
        @SafeProperty
        SkillLvInitiative?:number[]

        /**
         * 图标
         **/
        @SafeProperty
        icon?:number[]

        /**
         * 攻击百分比
         **/
        @SafeProperty
        AtkRatio?:number[]

        /**
         * 防御百分比
         **/
        @SafeProperty
        DefRatio?:number[]

        /**
         * 生命百分比
         **/
        @SafeProperty
        HpRatio?:number[]

        /**
         * 暴击
         **/
        @SafeProperty
        CritRate?:number[]

        /**
         * 命中
         **/
        @SafeProperty
        HitRate?:number[]

        /**
         * 闪避
         **/
        @SafeProperty
        DodgeRate?:number[]

        /**
         * 施法迅捷
         **/
        @SafeProperty
        SkillSpeed?:number[]

        /**
         * 魔法减伤率
         **/
        @SafeProperty
        M_DeHarmRate?:number[]

        /**
         * 物理减伤率
         **/
        @SafeProperty
        P_DeHarmRate?:number[]

        /**
         * 强化消耗金币
         **/
        @SafeProperty
        Golds?:number[]

        /**
         * 强化消耗道具
         **/
        @SafeProperty
        Goods?:fk

        protected _fkGoods?:goodsConfigRow=undefined
        /**
         * 强化消耗道具
         **/
        get GoodsData(){
            if(this._fkGoods===undefined){
                this._fkGoods=goodsConfig.find(a=>a.parameterid==this.Goods);
            }
            return this._fkGoods;
        }

        /**
         * 强化消耗数量
         **/
        @SafeProperty
        Counts?:number[]

        /**
         * 对应spine
         **/
        @SafeProperty
        Spine?:string

        /**
         * 获取路径
         **/
        @SafeProperty
        SpaceTime?:number

}

let artifactConfig:artifactConfigRow []=[];

var rowData=
[
    [40001,2,"风暴战斧",998001,[1,1,2,2,2,3],995002,[1,2,3,4,5,5],[1,1,2,2,3,3],[],[],[],[0.05,0.07,0.07,0.09,0.11,0.11],[],[],[],[],[0.05,0.07,0.07,0.09,0.11,0.11],[600000,1500000,3000000,6000000,10000000],10011,[20,50,100,150,200],"shengqi_futou",3],
    [40002,5,"法老面具",998002,[1,1,2,2,2,3],995005,[1,2,3,4,5,5],[1,1,2,2,3,3],[],[0.08,0.1,0.1,0.12,0.14,0.14],[],[],[],[],[],[],[],[600000,1500000,3000000,6000000,10000000],10012,[20,50,100,150,200],"shengqi_falao",5],
    [40003,4,"杰克的罗盘",998003,[1,1,2,2,2,3],995004,[1,2,3,4,5,5],[1,1,2,2,3,3],[],[],[0.08,0.1,0.1,0.12,0.14,0.14],[],[],[10,12,12,14,16,16],[],[],[],[600000,1500000,3000000,6000000,10000000],10013,[20,50,100,150,200],"shengqi_luopan",1],
    [40004,6,"魔戒",998004,[1,1,2,2,2,3],995006,[1,2,3,4,5,5],[1,1,2,2,3,3],[],[],[],[],[],[],[8,10,10,12,14,14],[0.05,0.07,0.07,0.09,0.11,0.11],[],[600000,1500000,3000000,6000000,10000000],10014,[20,50,100,150,200],"shengqi_mojie",4],
    [40005,7,"石中剑",998005,[1,1,2,2,2,3],995007,[1,2,3,4,5,5],[1,1,2,2,3,3],[0.05,0.07,0.07,0.09,0.11,0.11],[],[],[],[15,18,18,21,24,24],[],[],[],[],[600000,1500000,3000000,6000000,10000000],10015,[20,50,100,150,200],"shengqi_sword",6],
    [40006,3,"死海文书",998006,[1,1,2,2,2,3],995003,[1,2,3,4,5,5],[1,1,2,2,3,3],[],[0.05,0.07,0.07,0.09,0.11,0.11],[0.08,0.1,0.1,0.12,0.14,0.14],[],[],[],[],[],[],[600000,1500000,3000000,6000000,10000000],10016,[20,50,100,150,200],"shengqi_map",7],
    [40007,1,"灭霸手套",998007,[1,1,2,2,2,3],995001,[1,2,3,4,5,5],[1,1,2,2,3,3],[],[],[],[0.03,0.04,0.04,0.05,0.06,0.06],[15,18,18,21,24,24],[],[],[],[],[600000,1500000,3000000,6000000,10000000],10017,[20,50,100,150,200],"6022_3",8],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new artifactConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    artifactConfig .push(r);

}

export default artifactConfig
