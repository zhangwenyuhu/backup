const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","days","reward",]

export class newplayertimespendconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 充值天数
         **/
        @SafeProperty
        days?:number

        /**
         * 奖励
         **/
        @SafeProperty
        reward?:any

}

let newplayertimespendconfig:newplayertimespendconfigRow []=[];

var rowData=
[
    [1,3,[[20046,1,4]]],
    [2,5,[[10007,10]]],
    [3,7,[[40001,1]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new newplayertimespendconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    newplayertimespendconfig .push(r);

}

export default newplayertimespendconfig
