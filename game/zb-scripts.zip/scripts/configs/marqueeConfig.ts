const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","range","type","condition","content","cxtime","jgtime",]

export class marqueeConfigRow{

        /**
         * Id
         **/
        @SafeProperty
        Id?:uid

        /**
         * 范围
Trace:
1本服
2全服
3自己
         **/
        @SafeProperty
        range?:number

        /**
         * 类型
Trace:
1.抽卡
2.荣誉榜
3.转盘
4.VIP
5.荣誉榜我的排行榜
         **/
        @SafeProperty
        type?:number

        /**
         * 条件
1.数量：1-5

         **/
        @SafeProperty
        condition?:number[]

        /**
         * 内容
         **/
        @SafeProperty
        content?:string

        /**
         * 持续时间
         **/
        @SafeProperty
        cxtime?:number

        /**
         * 间隔时间
         **/
        @SafeProperty
        jgtime?:number

}

let marqueeConfig:marqueeConfigRow []=[];

var rowData=
[
    [1,2,1,[2],"<b><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#FFFFFF>抽到了</c><color=#D600FF>%hero%</c></b>",5,2],
    [2,2,1,[3,4],"<b><color=#FFEC16>运气爆棚！</c><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#FFFFFF>竟然抽到了</c><color=#D600FF>%hero%</c></b>",5,2],
    [3,2,1,[5,10],"<b><color=#FFEC16>叹为观止！</c><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#FFFFFF>竟然抽到了</c><color=#D600FF>%hero%</c></b>",8,2],
    [4,1,2,[],"<b><color=#FFEC16>全体注意！</c><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#FFFFFF>成为通关</c><color=#D600FF>第%chapter%章节所有关卡</c><color=#FFFFFF>第一人！</c><b>",8,2],
    [5,1,2,[],"<b><color=#FFEC16>全体注意！</c><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#FFFFFF>成功突破</c><color=#D600FF>摩天楼第%stage%层</c><color=#FFFFFF>成为摩天楼一哥！</c><b>",8,2],
    [6,1,2,[],"<b><color=#FFEC16>全体注意！</c><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#D600FF>武装军团积分达到%integral%</c><color=#FFFFFF>快来膜拜武装大佬！</c><b>",8,2],
    [7,1,2,[],"<b><color=#FFEC16>全体注意！</c><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#D600FF>机械军团积分达到%integral%</c><color=#FFFFFF>快来膜拜机械大佬！</c><b>",8,2],
    [8,1,2,[],"<b><color=#FFEC16>全体注意！</c><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#D600FF>变种军团积分达到%integral%</c><color=#FFFFFF>快来膜拜变种大佬！</c><b>",8,2],
    [9,1,2,[],"<b><color=#FFEC16>全体注意！</c><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#D600FF>僵尸军团积分达到%integral%</c><color=#FFFFFF>快来膜拜僵尸大佬！</c><b>",8,2],
    [10,2,3,[],"<b><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#FFFFFF>在寻宝中抽到了</c><color=#D600FF>%goods%</c><b>",5,2],
    [11,2,4,[4,15],"<b><color=#FFEC16>恭喜！</c><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#FFFFFF>成为了尊贵的</c><color=#FFEC16>Vip%viplv%!</c><b>",5,2],
    [12,3,5,[],"<b><color=#FFFFFF>你当前在%rankingtype%中的排名已提升到</c><color=#16ECFF>%position%！</c><color=#FFFFFF>再接再厉！</c><b>",5,2],
    [13,2,3,[],"<b><color=#FFFFFF>%fromser%的</c><color=#47DE58>%fromnick%</c><color=#FFFFFF>在寻宝限时活动中抽到了</c><color=#D600FF>%goods%</c><b>",5,2],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new marqueeConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    marqueeConfig .push(r);

}

export default marqueeConfig
