const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","viplevel","vipexp","idlegold","idleexp","arenafreetime","herotakelimit","skipbattle","mazegold","factionboss","gotobattle","wipeout","wheelVipAdd","wheelTenLock","wheelAdvLock","resourcetimebuy","egglock","artifactUnlock","vipreward","ShowIcon",]

export class vipconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * VIP等级
         **/
        @SafeProperty
        viplevel?:number

        /**
         * 升级所需经验
         **/
        @SafeProperty
        vipexp?:number

        /**
         * 挂机额外金币产出
         **/
        @SafeProperty
        idlegold?:number

        /**
         * 挂机额外英雄经验产出
         **/
        @SafeProperty
        idleexp?:number

        /**
         * 竞技场每日免费次数增加
         **/
        @SafeProperty
        arenafreetime?:number

        /**
         * 英雄携带数量上限增加
         **/
        @SafeProperty
        herotakelimit?:number

        /**
         * 解锁竞技场跳过战斗
         **/
        @SafeProperty
        skipbattle?:number

        /**
         * 智慧树产出金币增加
         **/
        @SafeProperty
        mazegold?:number

        /**
         * 公会Boss挑战增加
         **/
        @SafeProperty
        factionboss?:number

        /**
         * 解锁悬赏栏一键上阵
         **/
        @SafeProperty
        gotobattle?:number

        /**
         * 解锁团队狩猎扫荡功能
         **/
        @SafeProperty
        wipeout?:number

        /**
         * 转盘VIP十连抽加成
         **/
        @SafeProperty
        wheelVipAdd?:number

        /**
         * 普通转盘10连抽解锁
         **/
        @SafeProperty
        wheelTenLock?:number

        /**
         * 高级转盘解锁
         **/
        @SafeProperty
        wheelAdvLock?:number

        /**
         * 资源副本额外购买次数
         **/
        @SafeProperty
        resourcetimebuy?:number

        /**
         * 扭蛋解锁
         **/
        @SafeProperty
        egglock?:number

        /**
         * 解锁的神器
         **/
        @SafeProperty
        artifactUnlock?:number

        /**
         * 到达奖励
         **/
        @SafeProperty
        vipreward?:any

        /**
         * 展示图片
         **/
        @SafeProperty
        ShowIcon?:string

}

let vipconfig:vipconfigRow []=[];

var rowData=
[
    [1,1,60,0.05,0.05,1,0,0,0,0,0,0,0,0,0,0,0,0,[[10060,60]],"vip_linghunshi"],
    [2,2,300,0.1,0.1,1,10,0,0,0,0,0,0,0,0,0,0,0,[[10061,5],[10060,60]],"vip_reward"],
    [3,3,1000,0.2,0.2,2,15,0,0,0,0,0,0,1,1,1,0,0,[[20046,1,4],[10061,10]],"vip_linke"],
    [4,4,2000,0.25,0.25,2,20,0,0,0,1,0,0,1,1,1,0,0,[[30511,1],[10060,120],[10061,15]],"vip_weapon1"],
    [5,5,4000,0.3,0.3,3,25,1,0.2,0,1,0,0,1,1,1,0,40002,[[10060,120],[10061,15]],"vip_falao"],
    [6,6,7000,0.5,0.5,3,30,1,0.3,1,1,1,0,1,1,2,0,0,[[20009,1,4],[30621,1],[10061,15]],"vip_aersasi"],
    [7,7,10000,0.56,0.56,4,35,1,0.4,1,1,1,0,1,1,2,0,0,[[20009,1,4],[30622,1],[10061,60]],"vip_aersasi1"],
    [8,8,14000,0.6,0.6,4,40,1,0.5,1,1,1,12,1,1,2,0,40004,[[10061,60],[30623,1]],"vip_mojie"],
    [9,9,20000,0.9,0.9,5,45,1,0.5,1,1,1,12,1,1,2,0,0,[[20009,2,4],[30623,1],[30624,1]],"vip_aersasi2"],
    [10,10,30000,1,1,5,50,1,0.6,1,1,1,12,1,1,2,1,0,[[20038,1,4],[10061,60],[30711,1]],"vip_mieba"],
    [11,11,50000,1.11,1.11,6,55,1,0.7,1,1,1,12,1,1,3,1,0,[[20038,1,4],[10075,1],[30712,1]],"vip_mieba1"],
    [12,12,80000,1.5,1.5,6,60,1,0.7,1,1,1,12,1,1,3,1,0,[[10014,200],[10061,120],[30822,1]],"vip_mojiesuipian"],
    [13,13,150000,1.6,1.6,7,65,1,0.8,1,1,1,12,1,1,3,1,0,[[20038,1,4],[10061,180],[10075,2]],"vip_mieba2"],
    [14,14,300000,1.7,1.7,7,70,1,0.8,1,1,1,12,1,1,4,1,0,[[20038,1,4],[10061,300],[10075,3]],"vip_mieba2"],
    [15,15,500000,2,2,7,120,1,1,1,1,1,12,1,1,4,1,0,[[20038,2,4],[10061,480],[10075,5]],"vip_mieba3"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new vipconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    vipconfig .push(r);

}

export default vipconfig
