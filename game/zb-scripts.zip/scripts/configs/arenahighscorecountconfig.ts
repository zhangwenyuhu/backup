const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","rankgap","winscoreadd","failscorelose",]

export class arenahighscorecountconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 段位差绝对值
         **/
        @SafeProperty
        rankgap?:number

        /**
         * 高阶胜利积分增加
         **/
        @SafeProperty
        winscoreadd?:number

        /**
         * 高阶失败积分减少
         **/
        @SafeProperty
        failscorelose?:number

}

let arenahighscorecountconfig:arenahighscorecountconfigRow []=[];

var rowData=
[
    [1,1,20,10],
    [2,2,22,11],
    [3,3,24,12],
    [4,4,26,13],
    [5,5,28,14],
    [6,6,30,15],
    [7,7,32,16],
    [8,8,34,17],
    [9,9,36,18],
    [10,10,38,19],
    [11,11,40,20],
    [12,12,42,21],
    [13,13,44,22],
    [14,14,46,23],
    [15,15,48,24],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new arenahighscorecountconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    arenahighscorecountconfig .push(r);

}

export default arenahighscorecountconfig
