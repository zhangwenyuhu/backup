const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","layer","RewardID",]

export class wisdomTreeBoxConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 层数
         **/
        @SafeProperty
        layer?:number

        /**
         * 奖励ID
         **/
        @SafeProperty
        RewardID?:number[]

}

let wisdomTreeBoxConfig:wisdomTreeBoxConfigRow []=[];

var rowData=
[
    [1,1,[80001,80002,80003]],
    [2,2,[80004,80005,80006]],
    [3,3,[80007,80008,80009]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new wisdomTreeBoxConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    wisdomTreeBoxConfig .push(r);

}

export default wisdomTreeBoxConfig
