const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","stage","difficulty","level","rank","equiprank","killscore","killcoin","bosslevel","bossrank","bossequiprank","bosskillscore","bosskillcoin",]

export class factiongameconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 挑战阶段（当前阶段挑战完到下阶段）
         **/
        @SafeProperty
        stage?:number

        /**
         * 关卡难度（1简单2普通3困难）
         **/
        @SafeProperty
        difficulty?:number

        /**
         * 怪物等级
         **/
        @SafeProperty
        level?:number

        /**
         * 怪物品阶
         **/
        @SafeProperty
        rank?:number

        /**
         * 装备品阶
         **/
        @SafeProperty
        equiprank?:number

        /**
         * 单个击杀积分
         **/
        @SafeProperty
        killscore?:number

        /**
         * 单个击杀工会币奖励
         **/
        @SafeProperty
        killcoin?:number

        /**
         * boss怪物等级
         **/
        @SafeProperty
        bosslevel?:number

        /**
         * boss怪物品阶
         **/
        @SafeProperty
        bossrank?:number

        /**
         * boss装备品阶
         **/
        @SafeProperty
        bossequiprank?:number

        /**
         * boss单个击杀积分
         **/
        @SafeProperty
        bosskillscore?:number

        /**
         * boss单个击杀工会币奖励
         **/
        @SafeProperty
        bosskillcoin?:number

}

let factiongameconfig:factiongameconfigRow []=[];

var rowData=
[
    [1,1,1,10,1,1,10,20,10,1,1,10,20],
    [2,1,2,15,1,1,15,40,15,1,1,15,40],
    [3,1,3,20,1,1,20,60,20,1,1,20,60],
    [4,2,1,15,2,1,15,40,15,2,1,15,40],
    [5,2,2,20,2,1,20,60,20,2,1,20,60],
    [6,2,3,25,2,1,25,80,25,2,1,25,80],
    [7,3,1,20,3,2,20,60,20,3,2,20,60],
    [8,3,2,25,3,2,25,80,25,3,2,25,80],
    [9,3,3,30,3,2,30,100,30,3,2,30,100],
    [10,4,1,25,4,2,25,80,25,4,2,25,80],
    [11,4,2,30,4,2,30,100,30,4,2,30,100],
    [12,4,3,35,4,2,35,120,35,4,2,35,120],
    [13,5,1,30,5,3,30,100,30,5,3,30,100],
    [14,5,2,35,5,3,35,120,35,5,3,35,120],
    [15,5,3,40,5,3,40,140,40,5,3,40,140],
    [16,6,1,35,6,3,35,120,35,6,3,35,120],
    [17,6,2,40,6,3,40,140,40,6,3,40,140],
    [18,6,3,45,6,3,45,160,45,6,3,45,160],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new factiongameconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    factiongameconfig .push(r);

}

export default factiongameconfig
