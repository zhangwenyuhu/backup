const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","day","reward",]

export class sevendayfundconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 天数
         **/
        @SafeProperty
        day?:number

        /**
         * 奖励内容
         **/
        @SafeProperty
        reward?:any

}

let sevendayfundconfig:sevendayfundconfigRow []=[];

var rowData=
[
    [1,1,[[10002,50],[10480,3]]],
    [2,2,[[10002,50],[10480,3]]],
    [3,3,[[10002,50],[10051,2]]],
    [4,4,[[10002,50],[10480,3]]],
    [5,5,[[10002,50],[10480,3]]],
    [6,6,[[10002,50],[10051,2]]],
    [7,7,[[20033,1,4]]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new sevendayfundconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    sevendayfundconfig .push(r);

}

export default sevendayfundconfig
