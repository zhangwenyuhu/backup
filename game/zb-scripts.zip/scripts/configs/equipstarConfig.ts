const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","EqSLv","EqStar","EqStarExp","EqStarData","EqStarPro",]

export class equipstarConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Id?:uid

        /**
         * 升星等级（默认0级）
         **/
        @SafeProperty
        EqSLv?:number

        /**
         * 装备星级
         **/
        @SafeProperty
        EqStar?:number

        /**
         * 升星经验（升到该等级所需经验）
         **/
        @SafeProperty
        EqStarExp?:number

        /**
         * 升星系数
         **/
        @SafeProperty
        EqStarData?:number

        /**
         * 升星额外加成(属性类型|数值）
         **/
        @SafeProperty
        EqStarPro?:number[]

}

let equipstarConfig:equipstarConfigRow []=[];

var rowData=
[
    [1,1,0,3360,0.04,[]],
    [2,2,0,3360,0.08,[]],
    [3,3,0,3360,0.12,[]],
    [4,4,0,3360,0.16,[]],
    [5,5,1,6720,0.2,[7,0.05]],
    [6,6,1,6720,0.24,[]],
    [7,7,1,6720,0.28,[]],
    [8,8,1,6720,0.32,[]],
    [9,9,1,6720,0.36,[]],
    [10,10,2,10752,0.4,[7,0.05]],
    [11,11,2,10752,0.44],
    [12,12,2,10752,0.48,[]],
    [13,13,2,10752,0.52],
    [14,14,2,10752,0.56],
    [15,15,3,20160,0.6,[20,0.05]],
    [16,16,3,20160,0.64],
    [17,17,3,20160,0.68,[]],
    [18,18,3,20160,0.72],
    [19,19,3,20160,0.76],
    [20,20,4,33600,0.8,[20,0.05]],
    [21,21,4,33600,0.84],
    [22,22,4,33600,0.88],
    [23,23,4,33600,0.92],
    [24,24,4,33600,0.96],
    [25,25,5,53760,1,[7,0.05]],
    [26,26,5,53760,1.05],
    [27,27,5,53760,1.1,[]],
    [28,28,5,53760,1.15],
    [29,29,5,53760,1.2],
    [30,30,6,33600,1.3,[7,0.05]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new equipstarConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    equipstarConfig .push(r);

}

export default equipstarConfig
