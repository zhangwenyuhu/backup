const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","condition","icon","desc",]

export class chatConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 触发条件
1.单抽抽到了神话英雄
2.十连抽抽到神话英雄
3.友情点抽到神话英雄
4.英雄升阶到金色-6阶
5.英雄升阶到红色-8阶
6.英雄升阶到神话-10阶

         **/
        @SafeProperty
        condition?:number

        /**
         * 图标
         **/
        @SafeProperty
        icon?:string

        /**
         * 描述
         **/
        @SafeProperty
        desc?:string

}

let chatConfig:chatConfigRow []=[];

var rowData=
[
    [1,1,"chat_text2","{player} 单抽抽到了SSR英雄 {hero}！"],
    [2,2,"chat_text3","{player} 十连抽抽到了SSR英雄 {hero}！"],
    [3,2,"chat_text4","{player} 十连抽一次性居然抽到了SSR英雄 {hero}！"],
    [4,3,"chat_text5","{player} 使用友情点抽到了SSR英雄 {hero}！"],
    [5,4,"chat_text7","{player} 将 {hero} 升到了 {quality}"],
    [6,5,"chat_text8","{player} 将 {hero} 升到了 {quality}"],
    [7,6,"chat_text9","{player} 居然将 {hero}升到了 {quality}"],
    [8,7,"chat_text4","{player} 在寻宝限时活动中抽到了UR英雄 {hero}！"],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new chatConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    chatConfig .push(r);

}

export default chatConfig
