const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","hurtnum",]

export class challengerewardConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 伤害要求
         **/
        @SafeProperty
        hurtnum?:number

}

let challengerewardConfig:challengerewardConfigRow []=[];

var rowData=
[
    [1,5000],
    [2,10000],
    [3,20000],
    [4,30000],
    [5,40000],
    [6,50000],
    [7,60000],
    [8,70000],
    [9,80000],
    [10,90000],
    [11,100000],
    [12,200000],
    [13,300000],
    [14,400000],
    [15,500000],
    [16,600000],
    [17,700000],
    [18,800000],
    [19,900000],
    [20,1000000],
    [21,1200000],
    [22,1400000],
    [23,1600000],
    [24,1800000],
    [25,2000000],
    [26,2200000],
    [27,2400000],
    [28,2600000],
    [29,2800000],
    [30,3000000],
    [31,3400000],
    [32,3800000],
    [33,4200000],
    [34,4600000],
    [35,5000000],
    [36,5400000],
    [37,5800000],
    [38,6200000],
    [39,6600000],
    [40,7000000],
    [41,7400000],
    [42,7800000],
    [43,8200000],
    [44,8600000],
    [45,9000000],
    [46,10000000],
    [47,11000000],
    [48,12000000],
    [49,13000000],
    [50,14000000],
    [51,15000000],
    [52,16000000],
    [53,17000000],
    [54,18000000],
    [55,19000000],
    [56,20000000],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new challengerewardConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    challengerewardConfig .push(r);

}

export default challengerewardConfig
