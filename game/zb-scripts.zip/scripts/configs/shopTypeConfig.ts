const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Id","refreshType","refreshCost",]

export class shopTypeConfigRow{

        /**
         * ID
         **/
        @SafeProperty
        Id?:uid

        /**
         * 刷新机制
Trace:
1 = 每天UTC0点刷新
2 = 以玩家创建账号时间为准,每30天刷新
         **/
        @SafeProperty
        refreshType?:number

        /**
         * 手动刷新价格(钻石)
         **/
        @SafeProperty
        refreshCost?:number[]

}

let shopTypeConfig:shopTypeConfigRow []=[];

var rowData=
[
    [1,1,[300,400,400,400,600,600,600,600,800,800]],
    [2,1,[100,100,100,200,200,200,400,600,800,1000]],
    [3,2,[1000]],
    [4,2,[1000]],
    [5,1,[100,100,100,200,200,200,400,600,800,1000]],
    [6,1,[1000]],
    [7,1,[100]],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new shopTypeConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    shopTypeConfig .push(r);

}

export default shopTypeConfig
