const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["Key","RankName","RankHead","RankHigh","RankColor","Type","Rank","SpecialType","SpecialRank","URSpecialType","URSpecialRank","Level","star","starlimit","starrequire","Score","coefficient","fixedvalue",]

export class heroRankConfigRow{

        /**
         * 键
         **/
        @SafeProperty
        Key?:uid

        /**
         * 品阶别名
         **/
        @SafeProperty
        RankName?:string

        /**
         * 品阶框
         **/
        @SafeProperty
        RankHead?:string

        /**
         * 品阶角标
         **/
        @SafeProperty
        RankHigh?:string

        /**
         * 品阶颜色
         **/
        @SafeProperty
        RankColor?:string

        /**
         * 4族进阶消耗英雄类型(0:同ID/1:同阵营/2：任意阵营)
         **/
        @SafeProperty
        Type?:number[]

        /**
         * 4族进阶材料品阶
         **/
        @SafeProperty
        Rank?:number[]

        /**
         * 光暗进阶消耗英雄类型(0:同ID/1:同阵营)
         **/
        @SafeProperty
        SpecialType?:number[]

        /**
         * 光暗进阶材料品阶
         **/
        @SafeProperty
        SpecialRank?:number[]

        /**
         * 特殊四族进阶消耗英雄类型(0:同ID/1:同阵营)
         **/
        @SafeProperty
        URSpecialType?:number[]

        /**
         * 特殊四族进阶材料品阶
         **/
        @SafeProperty
        URSpecialRank?:number[]

        /**
         * 等级最高上限
         **/
        @SafeProperty
        Level?:number

        /**
         * 星级要求
         **/
        @SafeProperty
        star?:number

        /**
         * 星级下限
         **/
        @SafeProperty
        starlimit?:number

        /**
         * 是否可升星
         **/
        @SafeProperty
        starrequire?:bool

        /**
         * 积分
         **/
        @SafeProperty
        Score?:number

        /**
         * 品阶系数
         **/
        @SafeProperty
        coefficient?:number

        /**
         * 品阶固定值
         **/
        @SafeProperty
        fixedvalue?:number

}

let heroRankConfig:heroRankConfigRow []=[];

var rowData=
[
    [1,"普通","1","0","#5de86c",[],[],[],[],[],[],30,0,0,false,0,1,0],
    [2,"稀有","2","0","#00c6ff",[1,1],[2,2],[],[],[],[],40,0,0,true,5,1,0],
    [3,"稀有+","2","1","#00c6ff",[1,1,2],[3,3,3],[],[],[],[],50,0,0,true,15,1.15,10.15],
    [4,"精英","3","0","#f85ef9",[2,2],[4,4],[2,2],[4,4],[],[],60,0,0,true,50,1.25,18.9],
    [5,"精英+1","3","1","#f85ef9",[1,2,2],[4,4,4],[2,2,2],[4,4,4],[1,2,2],[4,4,4],80,0,0,true,150,1.38,24],
    [6,"精英+2","3","2","#f85ef9",[1,1,2],[4,4,4],[2,2,2],[4,4,4],[1,1,2],[4,4,4],100,0,0,true,500,1.524,24],
    [7,"史诗","4","0","#ffc800",[1,2,2],[4,4,4],[2,2,2],[4,4,4],[1,2,2],[4,4,4],120,0,0,true,650,1.63,24],
    [8,"史诗+1","4","1","#ffc800",[1,2,2],[4,4,4],[2,2,2],[4,4,4],[1,2,2],[4,4,4],140,1,0,true,1300,1.748,24],
    [9,"史诗+2","4","2","#ffc800",[1,2,2],[4,4,4],[2,2,2],[4,4,4],[1,2,2],[4,4,4],160,1,1,true,2000,1.89,24],
    [10,"史诗+3","4","3","#ffc800",[1,2,2],[5,4,4],[2,2,2],[5,4,4],[1,2,2],[5,4,4],170,1,1,true,2500,2.011,24],
    [11,"传说","5","0","#ff2525",[1,2,2],[5,5,5],[2,2,2],[5,5,5],[1,2,2],[5,5,5],180,2,1,true,2800,2.08,24],
    [12,"传说+1","5","1","#ff2525",[1,2,2],[5,5,5],[2,2,2],[5,5,5],[1,2,2],[5,5,5],190,2,2,true,3100,2.131,24],
    [13,"传说+2","5","2","#ff2525",[1,2,2],[6,5,5],[2,2,2],[6,5,5],[1,2,2],[6,5,5],200,3,2,true,3400,2.21,24],
    [14,"传说+3","5","3","#ff2525",[1,2,2],[6,6,6],[2,2,2],[6,6,6],[1,2,2],[6,6,6],210,3,3,true,3700,2.3,24],
    [15,"神话","6","0","#fff8de",[1,2,2],[6,6,6],[2,2,2],[6,6,6],[1,2,2],[6,6,6],220,4,3,true,4000,2.46,24],
    [16,"神话+1","6","1","#fff8de",[1,2,2],[6,6,6],[2,2,2],[6,6,6],[1,2,2],[6,6,6],230,4,4,true,4000,2.667,24],
    [17,"神话+2","6","2","#fff8de",[1,2,2],[7,6,6],[2,2,2],[7,6,6],[1,2,2],[7,6,6],240,4,4,true,4000,2.812,24],
    [18,"神话+3","6","3","#fff8de",[1,2,2],[7,7,7],[2,2,2],[7,7,7],[1,2,2],[7,7,7],240,5,4,true,4000,3.025,24],
    [19,"永恒","7","0","#ff7c81",[1,1,2],[7,7,7],[2,2,2],[7,7,7],[1,1,2],[7,7,7],240,5,5,true,4000,3.239,24],
    [20,"永恒+1","7","3","#ff7c81",[],[],[],[],[],[],240,0,5,true,4000,3.36,24],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new heroRankConfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    heroRankConfig .push(r);

}

export default heroRankConfig
