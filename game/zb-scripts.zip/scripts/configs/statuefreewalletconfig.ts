const { SafeProperty } = slib;

type uid=number;
type key=string;
type fk=number;
type bool=boolean;

var fields =["ID","bullettype","tasktype","value","lasttask","nexttask","unlock","repetition","diamond","peoplenumber",]

export class statuefreewalletconfigRow{

        /**
         * ID
         **/
        @SafeProperty
        ID?:uid

        /**
         * 红包类型
1.普通
2.特殊，充值红包标识
         **/
        @SafeProperty
        bullettype?:number

        /**
         * 任务类型
tasktype id
         **/
        @SafeProperty
        tasktype?:number

        /**
         * 条件参数
         **/
        @SafeProperty
        value?:number

        /**
         * 前置任务
         **/
        @SafeProperty
        lasttask?:number

        /**
         * 后置任务
         **/
        @SafeProperty
        nexttask?:number

        /**
         * 解锁关卡
         **/
        @SafeProperty
        unlock?:number

        /**
         * 可重复
         **/
        @SafeProperty
        repetition?:bool

        /**
         * 钻石数
         **/
        @SafeProperty
        diamond?:number

        /**
         * 领取人数
         **/
        @SafeProperty
        peoplenumber?:number

}

let statuefreewalletconfig:statuefreewalletconfigRow []=[];

var rowData=
[
    [1001,1,3001,50,0,1002,1,false,100,10],
    [1002,1,3001,200,1001,1003,1,false,150,10],
    [1003,1,3001,456,1002,1004,1,false,200,10],
    [1004,1,3001,800,1003,0,1,false,300,15],
    [2001,1,3003,50,0,2002,1,false,100,10],
    [2002,1,3003,120,2001,2003,1,false,150,10],
    [2003,1,3003,250,2002,0,1,false,300,15],
    [3001,1,7011,100,0,3002,40,false,100,10],
    [3002,1,7011,200,3001,3003,40,false,150,10],
    [3003,1,7011,500,3002,3004,40,false,150,10],
    [3004,1,7011,1000,3003,0,40,false,300,15],
    [9001,1,7009,1,0,0,0,true,100,10],
    [10001,1,7010,1,0,0,0,true,150,10],
    [11001,2,7001,1,0,0,0,true,100,10],
    [12001,2,7002,1,0,0,0,true,150,10],
    [13001,2,7003,1,0,0,0,true,200,10],

]

let tableData: any[] = []
for (let record of rowData) {
    let obj = new statuefreewalletconfigRow () as any
    for(let i = 0;i<fields.length;i++) {
        let key = fields[i]
        obj[key] = record[i]
    }
    tableData.push(obj)
}

for(let r of tableData){
    statuefreewalletconfig .push(r);

}

export default statuefreewalletconfig
