import loadUtils from "../utils/LoadUtils";
import CommonLoader from "../view/common/CommonLoader";

/**
 * 节点池管理
 */
class PoolManager {
    protected _pools: { [key: string]: cc.NodePool } = {};

    put(key: string, node: cc.Node) {
        let pool = this._pools[key];
        if (!pool) {
            pool = new cc.NodePool();
            this._pools[key] = pool;
        }
        pool.put(node);
    }

    get(key: string): cc.Node {
        let pool = this._pools[key];
        if (pool) {
            return pool.get();
        }
        return null;
    }

    getNodePool(key: string): cc.NodePool {
        return this._pools[key];
    }

    /**
     * 创建英雄图标节点池
     * @param count 数量
     */
    async createHeroItemPool(count: number) {
        let prefab = await loadUtils.loadRes("prefabs/common/hero/hero_item", cc.Prefab) as cc.Prefab;
        let loader = prefab.data.getChildByName("hero").getComponent(CommonLoader);
        loader.loaderNode;
        prefab.compileCreateFunction();
        for (let i = 0; i < count; i++) {
            let node = cc.instantiate(prefab);
            node['_destroyImmediate'] = () => {
                this.put(prefab.name, node);
            }
            this.put(prefab.name, node);
        }
    }

    /**
     * 创建物品图标节点池
     * @param count 数量
     */
    async createBagItemPool(count: number) {
        let prefab = await loadUtils.loadRes("prefabs/common/bag/bag_item", cc.Prefab) as cc.Prefab;
        let loader = prefab.data.getChildByName("equip_card").getComponent(CommonLoader);
        loader.loaderNode;
        loader = prefab.data.getChildByName("soul_stone_card").getComponent(CommonLoader);
        loader.loaderNode;
        prefab.compileCreateFunction();
        for (let i = 0; i < count; i++) {
            let node = cc.instantiate(prefab);
            node['_destroyImmediate'] = () => {
                this.put(prefab.name, node);
            }
            this.put(prefab.name, node);
        }
    }
}

let poolManager = new PoolManager();
export default poolManager;