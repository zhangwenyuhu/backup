import { ResInfo } from './../view/panel/help/ResGotoPanel';
import { stringConfigMap } from './../configs/stringConfig';
import {
    ArtifactBO,
    EquipBO,
    GoodVO,
    HangUpSpeedBO,
    HeroBagVO,
    HeroBookVO,
    HeroVO,
    RedPointItem,
    ResourceVO
} from './../proxy/GameProxy';
import EManager, { EName } from "./EventManager";
import TouchPanel from "../view/panel/TouchPanel";
import GameProxy, { BagVO, RoleVO } from "../proxy/GameProxy";
import IndicatorPanel from '../view/panel/IndicatorPanel';
import playerLogic from '../logics/PlayerLogic';
import heroLogic from '../logics/HeroLogic';
import commonUtils from '../utils/CommonUtils';
import cm from './ConfigManager';
import { DistrictDO } from '../proxy/IPirateProxy';
import bagLogic from "../logics/BagLogic";
import ToastError from "../error/ToastError";
import missionLogic from '../logics/MissionLogic';
import IGameManager from './IGameManager';
import friendLogic from '../logics/FriendLogic';
import { BattleType, SystemId, Storage } from '../utils/DefineUtils';
import xsLogic from '../logics/XuanshangLogic';
import loadUtils from '../utils/LoadUtils';
import assignmentLogic from '../logics/AssignmentLogic';
import towerLogic from '../logics/TowerLogic';
import FightHangUp from '../view/fight/FightHangUp';
import friendMerLogic from '../logics/FriendMerLogic';
import Card, { CardType } from '../data/card/Card';
import CommonLoader from '../view/common/CommonLoader';
import GoodCard from '../view/component/Good/GoodCard';
import Good, { GoodType, GoodId } from '../data/card/Good';
import EquipCard from '../view/component/Equip/EquipCard';
import Equip from '../data/card/Equip';
import HeroCard from '../view/component/Hero/HeroCard';
import Hero from '../data/card/Hero';
import Property from '../data/Property';
import FightPath from '../view/component/FightPath';
import statuSocket from '../socket/StatuSocket';
import pm from './PromptManager';
import RewardFly from "../view/component/RewardFly";
import redPointLogic from '../logics/RedPointLogic';
import libraryLogic from '../logics/LibraryLogic';
import honorLogic from '../logics/HonorLogic';
import benefitLogic from '../logics/BenefitLogic';
import rechargeLogic from '../logics/RechargeLogic';
import giftLogic from '../logics/GiftLogic';
import activityLogic, { ActivityType } from "../logics/ActivityLogic";
import wisdomTreeLogic from "../logics/WisdomTreeLogic";
import guideLogic from '../logics/GuideLogic';
import GuidePanel from '../view/panel/GuidePanel';
import am from './AudioManager';
import promptLogic from "../logics/PromptLogic";
import videoAdLogic from '../logics/VideoAdLogic';
import stringUtils from "../utils/StringUtils";
import storageUtils from '../utils/StorageUtils';
import vipconfig from '../configs/vipconfig';
import guideTaskLogic from '../logics/GuideTaskLogic';
import chessLogic from '../logics/ChessLogic';
import chatSocket from "../socket/ChatSocket";
import wonderSpaceLogic from '../logics/WonderSpaceLogic';
import Artifact from "../data/card/Artifact";
import pushManager from "./PushManager";
import { PushType } from "../data/push/PushModal";
import lotteryLogic from '../logics/LotteryLogic';
import unionLogic from '../logics/UnionLogic';
import { MarketTab } from '../view/panel/market/MarketPanel';
import { MarketDateTab } from '../view/component/Market/DateMarketModule';
import redPackLogic from '../logics/RedPackLogic';
import UnlockWrapper from '../view/widget/unlock/UnlockWrapper';
import { unlockConfigMap } from '../configs/unlockConfig';
import localLogic, { localIndex } from '../logics/LocalLogic';
import exploreLogic from '../logics/ExploreLogic';
import BaseCell from '../view/component/BaseCell';
import onlineTimeWidget from "../view/component/OnlineTimeWidget";
import dungeonLogic from '../logics/DungeonLogic';
import zpLogic from '../logics/ZhuanPanLogic';
import BasePanel from '../view/panel/BasePanel';
import mqLogic from '../logics/MarqueeLogic';
import commitLogic from '../logics/CommitLogic';
import rMissionLogic from "../logics/RMissionLogic";
import { PromptType } from '../data/prompt/PromptModal';
import Info from '../Info';
import arenaLogic from '../logics/ArenaLogic';
import { ResType } from '../view/panel/help/ResGotoPanel';
import cMissionLogic from "../logics/CMissionLogic";
import actTabLogic from '../logics/ActTabLogic';
import ActivityTopTab from '../view/component/Activity/ActivityTopTab';
import arenaSeniorLogic from '../logics/ArenaSeniorLogic';
import PlayerEquip from '../data/card/PlayerEquip';
import techLogic from '../logics/TechLogic';
import udgLogic from '../logics/UnionDungeonLogic';
import unionWarLogic from '../logics/UnionWarLogic';
import medalLogic from '../logics/MedalLogic';

slib.i18n.resRootPath = "lang"
// if (Info.language == "zh") {
//     slib.i18n.applyTable(zh.data);
//     slib.i18n.language = zh.lang
// }
// else if (info.language == "en") {
//     slib.i18n.applyTable(en.data);
//     slib.i18n.language = en.lang
// }

const gToastText = {
    '普通': "<b><color=#5de86c>普通</color></b>",
    '稀有+': "<b><color=#00c6ff>稀有+</color></b>",
    '稀有': "<b><color=#00c6ff>稀有</color></b>",
    '精英+2': "<b><color=#f85ef9>精英+2</color></b>",
    '精英+1': "<b><color=#f85ef9>精英+1</color></b>",
    '精英': "<b><color=#f85ef9>精英</color></b>",
    '史诗+3': "<b><color=#efce48>史诗+3</color></b>",
    '史诗+2': "<b><color=#efce48>史诗+2</color></b>",
    '史诗+1': "<b><color=#efce48>史诗+1</color></b>",
    '史诗': "<b><color=#efce48>史诗</color></b>",
    '传说+3': "<b><color=#ff2525>传说+3</color></b>",
    '传说+2': "<b><color=#ff2525>传说+2</color></b>",
    '传说+1': "<b><color=#ff2525>传说+1</color></b>",
    '传说': "<b><color=#ff2525>传说</color></b>",
    '神话+3': "<b><color=#fad1f5>神话+3</color></b>",
    '神话+2': "<b><color=#fad1f5>神话+2</color></b>",
    '神话+1': "<b><color=#fad1f5>神话+1</color></b>",
    '神话': "<b><color=#fad1f5>神话</color></b>",
    '永恒+1': "<b><color=#fad1f5>永恒+1</color></b>",
    '永恒': "<b><color=#fad1f5>永恒</color></b>",
    //'将开': "<b><color=#f85ef9>将开</color></b>",
}

/**
 * 游戏代理
 */
class GameManager implements IGameManager {
    protected _guideLayer: cc.Node = null;
    protected _dialogLayer: cc.Node = null;
    protected _topDialogLayer: cc.Node = null;
    protected _toastLayer: cc.Node = null;
    protected _touchLayer: cc.Node = null;
    protected _actTopBgLayer: cc.Node = null;
    protected _actTopLayer: cc.Node = null;
    protected _actTopNode: cc.Node = null;
    protected _indicatorLayer: cc.Node = null;
    protected _battleIndicatorLayer: cc.Node = null;
    protected _fightNode: cc.Node = null;
    protected _walkZombieNodes: { [key: string]: cc.Node } = {};
    protected _safeArea: { left: number, right: number, top: number, bottom: number } = { left: 0, right: 0, top: 0, bottom: 0 };
    protected _deltaTimestamp: number = 0;
    protected _myServer: DistrictDO = null;
    protected _firstJuniorReport: boolean = true;
    protected _firstSeniorReport: boolean = true;

    public districtMap: { [key: number]: DistrictDO } = {};
    public districtId: number = 0;
    public snode: string = "";
    public curServerInfo: DistrictDO = null;
    public isBattled: boolean = false;
    public isFighting: boolean = false;
    public battleType: BattleType = BattleType.PVE;

    public autoSplit: boolean = false;
    public speedUp: boolean = false;
    public autoSkill: boolean = false;
    public redPush: boolean = false;
    public isNewUnlock: boolean = false;

    public tipNode: cc.Node[] = [];      // 气泡节点
    public reCountdown: boolean = false; // 重新开始10s倒计时
    public needCheckPopFirstPay: boolean = false;// 检查弹出首充礼包
    public popFirstPay: boolean = false;
    public popVipPanel: boolean = false;  // 弹出vip页面
    public sevenTaskNewRed: boolean = false;

    public fightVersion: number = 0;
    public isIndicatorEnabled: boolean = true;
    public usePerformance: boolean = false;
    public heroTab: number = 1;
    public lastMergeHeroIndex: number = 0;

    public appReview: boolean = false;
    public loginTimeTs: number = 0;

    async init() {
        gcc.core.init();

        if (cc.sys.platform == cc.sys.ANDROID) {
            let size = cc.view.getFrameSize();
            this.usePerformance = size.width < 1080;
        }
        else if (cc.sys.platform == cc.sys.WIN32) {
            this.usePerformance = true;
        }

        let size = cc.director.getWinSize();
        let nowScene = cc.director.getScene();

        this._dialogLayer = new cc.Node("dialog");
        this._dialogLayer.setContentSize(size);
        this._dialogLayer.position = cc.v2(size.width / 2, size.height / 2);
        nowScene.addChild(this._dialogLayer, 300);
        cc.game.addPersistRootNode(this._dialogLayer);

        this._topDialogLayer = new cc.Node("singleDialog");
        this._topDialogLayer.setContentSize(size);
        this._topDialogLayer.position = cc.v2(size.width / 2, size.height / 2);
        nowScene.addChild(this._topDialogLayer, 450);
        cc.game.addPersistRootNode(this._topDialogLayer);

        this._toastLayer = new cc.Node("toast");
        this._toastLayer.setContentSize(size);
        this._toastLayer.position = cc.v2(size.width / 2, size.height / 2);
        nowScene.addChild(this._toastLayer, 400);
        cc.game.addPersistRootNode(this._toastLayer);

        this._actTopLayer = new cc.Node("actTop");
        this._actTopLayer.setContentSize(size);
        this._actTopLayer.position = cc.v2(size.width / 2, size.height / 2);
        nowScene.addChild(this._actTopLayer, 449);
        cc.game.addPersistRootNode(this._actTopLayer);

        this._actTopBgLayer = new cc.Node("actTopBg");
        this._actTopBgLayer.setContentSize(size);
        this._actTopBgLayer.position = cc.v2(size.width / 2, size.height / 2);
        nowScene.addChild(this._actTopBgLayer, 50);
        cc.game.addPersistRootNode(this._actTopBgLayer);
        let widget = this._actTopLayer.addComponent(cc.Widget);
        widget.isAlignBottom = true;
        widget.isAlignTop = true;

        var bg = new cc.Node("modalBg");
        bg.setContentSize(size.width, size.height)
        bg.color = cc.Color.BLACK;
        bg.opacity = 235;
        bg.addComponent(cc.BlockInputEvents);
        this._actTopBgLayer.addChild(bg, -1);
        var sprite = bg.addComponent(cc.Sprite);
        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        loadUtils.loadSpriteFrame(`textures/ui/common/common_mask`, sprite);
        this._actTopBgLayer.active = false;
        widget = this._actTopBgLayer.addComponent(cc.Widget);
        widget.isAlignBottom = true;
        widget.isAlignTop = true;

        this._touchLayer = new cc.Node("touch");
        this._touchLayer.setContentSize(size);
        this._touchLayer.position = cc.v2(size.width / 2, size.height / 2);
        this._touchLayer.addComponent(TouchPanel);
        nowScene.addChild(this._touchLayer, 500);
        cc.game.addPersistRootNode(this._touchLayer);

        let prefab = cc.loader.getRes("prefabs/common/indicator", cc.Prefab);
        this._indicatorLayer = cc.instantiate(prefab);
        this._indicatorLayer.name = "indicator";
        this._indicatorLayer.setContentSize(size);
        this._indicatorLayer.position = cc.v2(size.width / 2, size.height / 2);
        this._indicatorLayer.addComponent(IndicatorPanel);
        nowScene.addChild(this._indicatorLayer, 300);
        cc.game.addPersistRootNode(this._indicatorLayer);
        this._indicatorLayer.active = false;

        prefab = cc.loader.getRes("prefabs/common/guide");
        this._guideLayer = cc.instantiate(prefab);
        this._guideLayer.name = "guide";
        this._guideLayer.setContentSize(size);
        this._guideLayer.position = cc.v2(size.width / 2, size.height / 2);
        nowScene.addChild(this._guideLayer, 250);
        cc.game.addPersistRootNode(this._guideLayer);
        this._guideLayer.active = false;

        cm.init();
        am.init();
        pushManager.init();
        storageUtils.init();
        gssdk.setNetErrorCallback((error, retry) => {
            EManager.emit(EName.onNetworkError, retry);
        });
        gssdk.setSSLHandShakeErrorCallBack((id, url) => {
            EManager.emit(EName.onNetworkError);
        });

        gdk.onShow(this._onShow.bind(this));
        gdk.onHide(this._onHide.bind(this));

        gcc.core.showModalCallback = () => {
            this.showIndicator(0.5);
        }
        gcc.core.closeModalCallback = () => {
            this.hideIndicator();
        }
        gssdk.gameClient.showModalCallback = () => {
            this.showIndicator(0.5);
        }
        gssdk.gameClient.closeModalCallback = () => {
            this.hideIndicator();
        }
        gssdk.storage.loadFromLocalStorage();

        await this._requestPlayerData();
        chatSocket.connectGroup();
        this._statuSocketConnect();

        let texture = await loadUtils.loadRes("textures/bg/panel_bg", cc.Texture2D) as cc.Texture2D
        gcc.core.bgTexture = texture;

        await this._updateSafeArea();
    }

    /**
     * 获取屏幕安全区域
     */
    get safeArea(): { left: number, right: number, top: number, bottom: number } {
        return this._safeArea;
    }

    /**
     * 获取对话框层
     */
    get dialogLayer(): cc.Node {
        return this._dialogLayer;
    }

    protected _statuSocketConnect() {
        statuSocket.connect(Info.gameServerUrl, gssdk.gameClient.getGameToken(), () => {
            console.log("statuSocket connect end")
        });
    }

    public async redPointsReq() {
        let proto = await this.request<RedPointItem[]>(GameProxy.apiRolecheckRP);
        redPointLogic.onServerMessage("", proto);
        promptLogic.doReceivePrompt("", proto);
    }

    /**
     * 更新屏幕安全区域
     */
    protected async _updateSafeArea() {
        return new Promise((resolve, reject) => {
            gdk.getSafeArea((data: { left: number, right: number, top: number, bottom: number }) => {
                let scaleX = cc.view.getScaleX();
                let scaleY = cc.view.getScaleY();
                this._safeArea.left = Math.floor(data.left / scaleX);
                this._safeArea.right = Math.floor(data.right / scaleX);
                this._safeArea.top = Math.floor(data.top / scaleY);
                this._safeArea.bottom = Math.floor(data.bottom / scaleY);
                console.log(`view scaleX:${scaleX}  svaleY:${scaleY}`);
                console.log(`screen top:${data.top} safeArea top:${this._safeArea.top}`);
                resolve();
            });
        })
    }

    /**
     * 请求玩家信息
     */
    protected async _requestPlayerData() {
        let playerProto = await this.request<RoleVO>(GameProxy.apiRolegetRole);
        playerLogic.init(playerProto, this);

        if (!guideLogic.noGuide) {
            let guideProto = await this.request<{ [key: string]: object }>(GameProxy.apiutilgetCloudObject, [guideLogic.cloudKey]);
            guideLogic.init(guideProto[guideLogic.cloudKey], this);
        }

        let bagProto = await this.request<BagVO>(GameProxy.apibaggetMyBags);
        bagLogic.init(bagProto, this);

        let herosProto = await this.request<HeroBagVO>(GameProxy.apiherogetHeros);
        heroLogic.init(herosProto, this);
        await heroLogic.doGetSkin();

        let heroBooks = await this.request<HeroBookVO[]>(GameProxy.apiherogetHeroBook);
        heroLogic.updateHeroIllustrations(heroBooks);

        let missionProto = await this.request<ResourceVO>(GameProxy.apiprocessgetProcess, SystemId.PVE.toString());
        missionLogic.init(missionProto, this);

        let hangupProto = await this.request<HangUpSpeedBO>(GameProxy.apihangUpgetHangUpSpeed)
        playerLogic.updateHangup(hangupProto);

        localLogic.init(this);
        friendLogic.init(this);
        friendMerLogic.init(this);
        xsLogic.init(this);
        towerLogic.init(this);
        assignmentLogic.init(this);
        redPointLogic.init(this);
        promptLogic.init(this);
        libraryLogic.init(this);
        honorLogic.init(this);
        rechargeLogic.init(this);
        giftLogic.init(this);
        activityLogic.init(this);
        wisdomTreeLogic.init(this);
        videoAdLogic.init(this);
        guideTaskLogic.init(this);
        chessLogic.init(this);
        wonderSpaceLogic.init(this);
        lotteryLogic.init(null, this);
        redPackLogic.init(this);
        rMissionLogic.init(this);
        arenaLogic.init(this);
        await videoAdLogic.allVideoAdTimesReq();
        await assignmentLogic.tasksReq(0);
        await rechargeLogic.storeBuyInfoReq();
        await rechargeLogic.vipRewardStatuReq();
        await activityLogic.activityReq(ActivityType.All);
        await dungeonLogic.init(this);
        await activityLogic.doGetCloudData();
        await activityLogic.doGetCycleActRank(0, 10);
        await arenaSeniorLogic.init(this);
        await towerLogic.towerProcessReq();
        await rMissionLogic.doGetRMissionInfo(1);
        benefitLogic.init(this);
        exploreLogic.init(this);
        zpLogic.init(this);
        mqLogic.init(this);
        cMissionLogic.init(this);
        actTabLogic.init(this);
        techLogic.init(this);
        udgLogic.init(this);
        unionWarLogic.init(this);
        medalLogic.init(this);
        //supplyLogic.init(this);
        //await supplyLogic.doGetSupplyInfo();

        if (playerLogic && playerLogic.getPlayer().getExp() >= 0) {
            console.info("请求红点信息!");
            gm.redPointsReq();
        }

        pm.init();

        commitLogic.levelUp();
        commitLogic.vipLevelUp();
        this.loginTimeTs = this._getZeroTime();
    }

    protected async _onShow(res: any) {
        EManager.emit(EName.onShow, res);
        let nowZeroTime = this._getZeroTime();
        if (this.loginTimeTs > 0 && (nowZeroTime - this.loginTimeTs) >= 3600000) {
            if (playerLogic && playerLogic.getPlayer().getExp() >= 0) {
                console.info("第二天请求红点信息!");
                gm.redPointsReq();
            }
            this.loginTimeTs = this._getZeroTime();
        }
    }

    protected _onHide() {
        console.log("app hide");
        pushManager.updateLocalPushs([PushType.OFFLINE_TIME, PushType.OFFLINE_BENEFIT]);
        onlineTimeWidget.saveOnlineTime();
        EManager.emit(EName.onHide);
    }

    protected _getZeroTime() {
        let time = new Date(this.getCurrentTimestamp());
        time.setHours(0);
        time.setMinutes(0);
        time.setSeconds(0);
        time.setMilliseconds(0);
        return time.getTime();
    }

    /**
     * @override
     * @param curEquip 当前装备
     * @param replaceEquip 替换装备
     * @param confirm 确认回调
     * @param cancel 取消回调
     */
    inheritDialog(curEquip: Equip, replaceEquip: Equip, confirm: Function, cancel: Function) {
        gcc.core.showLayer("prefabs/panel/equip/EquipInheritPanel", {
            data: {
                curEquip: curEquip,
                replaceEquip: replaceEquip,
                confirm: confirm,
                cancel: cancel
            }
        });
    }

    /**
     * @override
     * @param equip 装备
     * @param confirm 确认回调
     * @param cancel 取消回调
     */
    splitDialog(equip: Equip, confirm: Function, cancel: Function) {
        gcc.core.showLayer("prefabs/panel/equip/EquipSplitPanel", {
            data: {
                equip: equip,
                confirm: confirm,
                cancel: cancel
            }
        });
    }

    /**
     * @override
     * @param prevFaction 上次种族
     * @param nowFaction 当前种族
     * @param equip 装备
     * @param confirm 确认回调
     * @param cancel 取消回调
     * @param effect
     */
    recastDialog(prevFaction: number, nowFaction: number, equip: PlayerEquip, confirm: Function, cancel: Function, effect: Function) {
        gcc.core.showLayer("prefabs/panel/equip/EquipRecastPanel", {
            data: {
                prevFaction: prevFaction,
                nowFaction: nowFaction,
                equip: equip,
                confirm: confirm,
                cancel: cancel,
                effect: effect
            }
        });
    }

    /**
     * @override
     * @param data 
     */
    async dialog(data: {
        title?: string,
        content: string,
        okText?: string,
        confirm?: Function,
        cancel?: Function,
        noCancel?: boolean,
        id?: string,
        top?: boolean
    }) {
        let dialogLayer = data.top ? this._topDialogLayer : this._dialogLayer;

        let parent: cc.Node = null;
        if (typeof data.id == "string") {
            let child = dialogLayer.getChildByName(data.id);
            if (child) { return }
            parent = new cc.Node(data.id);
        }
        else {
            parent = new cc.Node("dialog");
        }
        parent.setContentSize(cc.winSize);
        parent.position = cc.v2();
        parent.parent = dialogLayer;

        try {
            let prefab = cc.loader.getRes("prefabs/common/dialog", cc.Prefab);
            if (!prefab) { prefab = await loadUtils.loadRes("prefabs/common/dialog", cc.Prefab) as cc.Prefab }

            let node = cc.instantiate(prefab) as cc.Node;
            node.position = cc.v2();
            node.setContentSize(cc.director.getWinSize());
            node.parent = parent;

            if (data.title) {
                let labelTitle = cc.find("dialog/title", node).getComponent(cc.Label);
                labelTitle.string = data.title;
            }

            let labelContent = cc.find("dialog/content", node).getComponent(cc.RichText);
            if (data.content.search('<b>') == -1) {
                data.content = "<b>" + data.content + "</b>";
            }
            let func = labelContent['_updateRichTextPosition'];
            labelContent['_updateRichTextPosition'] = () => {
                func.call(labelContent);
                for (let segment of labelContent['_labelSegments']) {
                    if (segment.name == "RICHTEXT_Image_CHILD") {
                        // let lineCount = (labelContent as any)._lineCount;
                        segment.y = -20;
                        break;
                    }
                }
            };
            labelContent.string = data.content;
            // (labelContent as any)._updateRenderData(true);
            if (labelContent.node.height > 63) {
                labelContent.horizontalAlign = cc.macro.TextAlignment.LEFT;
            }
            else {
                labelContent.horizontalAlign = cc.macro.TextAlignment.CENTER;
            }
            for (let child of labelContent.node.children) {
                if (child.getComponent(cc.Sprite)) {
                    child.scale = 0.8;
                    break;
                }
            }

            let btnConfirm = cc.find("dialog/btn_confirm", node);
            btnConfirm.on("click", () => {
                if (data.confirm) data.confirm();
                parent.destroy();
            });

            if (data.okText) {
                btnConfirm.getChildByName("label").getComponent(cc.Label).string = data.okText;
            }

            let btnCancel = cc.find("dialog/btn_cancel", node);
            btnCancel.on("click", () => {
                if (data.cancel) data.cancel();
                parent.destroy();
            })

            if (data.noCancel) {
                btnCancel.active = false;
                btnConfirm.x = 0;
            }
            else {
                node.once(cc.Node.EventType.TOUCH_END, () => {
                    if (data.cancel) data.cancel();
                    parent.destroy();
                });
            }
        } catch (error) {
            console.error(error);
        }
    }

    /**
     * 显示Toast
     * @param content 内容
     * @param parent 父节点
     */
    async toast(content: string, parent?: cc.Node) {
        content = content ? content : "";
        if (content.length == 0) return;

        try {
            let prefab = cc.loader.getRes("prefabs/common/toast", cc.Prefab);
            if (!prefab) {
                prefab = await loadUtils.loadRes("prefabs/common/toast", cc.Prefab) as cc.Prefab;
            }

            let node = cc.instantiate(prefab) as cc.Node;
            node.position = cc.v2();
            node.parent = parent ? parent : this._toastLayer;

            let labelNode = node.getChildByName("label");
            let label = labelNode.getComponent(cc.RichText);
            label.string = this._getColorToast(content);
            //(label as any)._updateRenderData(true);

            if (label.node.height > 50) {
                label.horizontalAlign = cc.macro.TextAlignment.LEFT;
            }
            if (label.node.width > 600) {
                label.maxWidth = 600;
            }

            node.width = Math.max(labelNode.width + 80, node.width);
            node.height = label.node.height + 36;

            let animation = node.getComponent(cc.Animation);
            animation["_init"] = cc.Animation.prototype['_initEx'];
            animation.on("finished", () => { node.destroy(); }, node);
        } catch (error) {
            console.error(error);
        }
    }

    /**
     * 顶部区域 设置活动列表是否显示
     * @param enable 
     */
    public enableActTop(enable: boolean) {
        if (this._actTopNode) {
            if (this._actTopNode.active != enable) {
                this._actTopNode.active = enable;
            }
        }
    }

    /**
     * 顶部区域 活动列表
     * @param valid 
     */
    public async validActTop(valid: boolean) {
        this._actTopBgLayer.active = valid;
        if (this._actTopBgLayer.active) {
            let bg = this._actTopBgLayer.getChildByName('modalBg');
            let sprite = bg.getComponent(cc.Sprite);
            if (sprite && !sprite.spriteFrame) {
                loadUtils.loadSpriteFrame(`textures/ui/common/common_mask`, sprite);
            }
        }

        if (this._actTopNode) {
            this._actTopNode.active = valid;
            this._actTopLayer.active = valid;
            if (this._actTopNode.active) {
                this._actTopLayer.getComponent(cc.Widget).updateAlignment();
                this._actTopNode.setContentSize(cc.winSize);

                let comp = this._actTopNode.getComponent(ActivityTopTab);
                comp.refresh();
            }
            return;
        }
        try {
            let prefab = cc.loader.getRes("prefabs/common/actTop", cc.Prefab);
            if (!prefab) {
                prefab = await loadUtils.loadRes("prefabs/common/actTop", cc.Prefab) as cc.Prefab;
            }

            let node = cc.instantiate(prefab) as cc.Node;
            node.setContentSize(cc.winSize);
            node.parent = this._actTopLayer;
            node.position = cc.v2();
            node.name = 'actTop';
            node.getComponent(ActivityTopTab).refresh();
            this._actTopNode = node;
        } catch (error) {
            console.error(error);
        }
    }

    protected _getColorToast(text: string): string {
        let result: string = '';
        let keys: string[] = Object.keys(gToastText);
        for (let i = 0; i < keys.length; i++) {
            if (text.indexOf(keys[i]) >= 0) {
                result = text.replace(keys[i], gToastText[keys[i]]);
                break;
            }
        }
        if (!result || result.length <= 0) { result = text; }
        return result;
    }

    /**
     * 钻石是否足够消耗
     * @param cost 消耗值
     */
    enoughDimond(cost: number): boolean {
        let enough: boolean = true;
        let diamond = bagLogic.getGood(Good.GoodId.Diamond);
        enough = diamond.getAmount() >= cost;
        return enough;
    }

    /**
     * 钻石不足提醒
     */
    diamondLessToast() {
        let payed: boolean = rechargeLogic.isPayed();
        if (payed) {
            gm.dialog({
                content: "钻石数量不足,是否前往购买?",
                okText: "去购买",
                confirm: () => {
                    gm.gotoBuy();
                },
                noCancel: false,
            })
        } else {
            gcc.core.showLayer("prefabs/panel/help/PayTipPanel");
        }
    }

    /**
     * 前往充值
     */
    gotoBuy() {
        if (UnlockWrapper.isUnlock(unlockConfigMap.新手礼包) && benefitLogic.isNewPlayerValid()) {
            gcc.core.showLayer("prefabs/panel/newplayer/NewPlayerGiftListPanel");
        } else {
            if (rechargeLogic.isMonthCardBuy()) {
                gcc.core.showLayer("prefabs/panel/market/MarketPanel", { data: { tabIndex: MarketTab.Normal, tabChildIndex: MarketDateTab.Diamond } });
            } else {
                if (BasePanel.getPanel('MarketPanel')) {
                    EManager.emit(EName.onFreshPanel, { panel: "MarketPanel", tabIndex: MarketTab.MonthCard, childIndex: 1 });
                }
                gcc.core.showLayer("prefabs/panel/market/MarketPanel", { data: { tabIndex: MarketTab.MonthCard } });
            }
        }
    }

    /**
     * 当天第一次登录弹出首充礼包
     * @param check 
     */
    checkPopFirstPay(check: boolean = false) {
        if (gm.appReview) return false;

        if (gm.needCheckPopFirstPay) {
            let firstLogined: boolean = localLogic.getData(localIndex.popFirstPay);
            if (!firstLogined && rechargeLogic.getPayMoney() <= 0) {
                if (check) {
                    return true;
                }
                gcc.core.showLayer("prefabs/panel/benefit/FirstPayPanel");
                localLogic.setData(localIndex.popFirstPay, true);
                gm.needCheckPopFirstPay = false;
            }
        }
        return false;
    }

    /**
     * 本周第一次登陆
     * @param check 
     */
    async checkArenaReport(check: boolean = false) {
        if (!this._firstJuniorReport) {
            return;
        }
        let isUnlockJuniorArena = UnlockWrapper.isUnlock(unlockConfigMap.竞技场);
        let isUnlockSeniorArena = UnlockWrapper.isUnlock(unlockConfigMap.高阶竞技场);
        if (!isUnlockJuniorArena && !isUnlockSeniorArena) {
            return;
        }
        if (!isUnlockJuniorArena) {
            // 未解锁不弹战报
            this._firstJuniorReport = false;
            this._firstSeniorReport = false;
        }
        if (!isUnlockSeniorArena) {
            // 未解锁不弹战报
            this._firstSeniorReport = false;
        }
        if (!gm.needCheckPopFirstPay && !gm.checkPopFirstPay(true) && (isUnlockJuniorArena || isUnlockSeniorArena)) {
            this._firstJuniorReport = false;
            this._firstSeniorReport = false;
            let now = new Date(gm.getCurrentTimestamp());
            now.setUTCHours(0);
            now.setUTCMinutes(0);
            now.setUTCSeconds(0);
            now.setUTCMilliseconds(0);
            let nowDay = now.getDay();
            if (nowDay > 1) {
                let nowTs = now.getTime() - (nowDay - 1) * 3600 * 24 * 1000;
                now = new Date(nowTs);
            }
            let showReport: boolean = false;
            let arenaReportTs: number = storageUtils.getNumber(isUnlockSeniorArena ? Storage.ArenaSeniorReportTs : Storage.ArenaReportTs);
            if (arenaReportTs == 0) {
                if (now.getDay() > 0) {
                    showReport = true;
                }
            } else {
                let time = new Date(arenaReportTs);
                let day = time.getDay();
                let date = time.getDate();
                if ((day == now.getDay() && date != now.getDate()) || day != now.getDay()) {
                    showReport = true;
                }
            }
            if (showReport) {
                if (check) {
                    return true;
                }
                await activityLogic.doGetRankLast(-1);
                if (activityLogic.lastRankValid) {
                    gcc.core.showLayer("prefabs/panel/activity/ActivityReportPanel", { modalTouch: true, data: isUnlockJuniorArena && isUnlockSeniorArena });
                    storageUtils.setNumber(isUnlockSeniorArena ? Storage.ArenaSeniorReportTs.Key : Storage.ArenaReportTs.Key, now.getTime(), true);
                }
            }
        }
        return false;
    }

    /**
     * 奖励中是否存在某个物品
     * @param goodId 物品ID
     * @param num 数量
     * @param res 奖励模型
     */
    hasGood(goodId: number, num: number, res: ResourceVO): boolean {
        let cards = playerLogic.getCards(res);
        for (let i = 0; i < cards.length; i++) {
            let good = cards[i] as Good
            if (good && good.getIndex() == goodId && good.getAmount() == num) {
                return true;
            }
        }
        return false;
    }

    /**
     * 获取奖励列表中的一个物品id
     * @param res 奖励模型
     * @param ignores
     */
    getGoodId(res: ResourceVO, ignores?: number[]): number[] {
        let goodId: number[] = [];
        let cards = playerLogic.getCards(res);
        for (let i = 0; i < cards.length; i++) {
            if (ignores) {
                let index = ignores.findIndex((a) => { return a == cards[i].getIndex(); })
                if (index < 0) {
                    let good = cards[i] as Good
                    goodId.push(good.getIndex());
                    goodId.push(good.getAmount());
                    break;
                }
            } else {
                let good = cards[0] as Good
                goodId.push(good.getIndex());
                goodId.push(good.getAmount());
                break;
            }
        }
        return goodId;
    }

    /**
     * 获取奖励中钻石的数量
     * @param res 奖励模型
     */
    getDiamondFromReward(res: ResourceVO): number {
        let num: number = 0;
        let cards = playerLogic.getCards(res);
        for (let i = 0; i < cards.length; i++) {
            if (cards[i].getType() == CardType.Good) {
                let data = cards[i] as Good;
                if (data.getIndex() == GoodId.Diamond) {
                    num += data.getAmount();
                }
            }
        }
        return num;
    }

    /**
     * 获取奖励中粉尘的数量
     * @param res 奖励模型
     */
    getDustFromReward(res: ResourceVO): number {
        let num: number = 0;
        let cards = playerLogic.getCards(res);
        for (let i = 0; i < cards.length; i++) {
            if (cards[i].getType() == CardType.Good) {
                let data = cards[i] as Good;
                if (data.getIndex() == GoodId.Dust) {
                    num += data.getAmount();
                } else if (data.getGoodType() == GoodType.DustHourGlass ||
                    data.getGoodType() == GoodType.EpicDustHourGlass) {
                    let item = this.glassToDust([data.getIndex(), data.getAmount()]);
                    if (item && item.length == 2) {
                        num += item[1];
                    }
                }
            }
        }
        return num;
    }

    /**
     * @override
     * @param res 奖励模型
     * @param showPanel 是否显示奖励面板
     * @param ignoreIds
     * @param ex 
     */
    getReward(res: ResourceVO, showPanel: boolean = true, ignoreIds: number[] = [], ex?: Card[]): Card[] {
        if (!res) { return; }
        let cards = playerLogic.addCards(res);
        let vipLevel: number = playerLogic.getPlayer().getVipLevel();
        for (let card of cards) {
            if (card.getIndex() == Good.GoodId.VipExp) {
                let oldVip = playerLogic.getPlayer().getVipLevel();
                let config = vipconfig[oldVip - 1];
                let oldCapacity = 0;
                if (config) oldCapacity = config.herotakelimit;
                playerLogic.getPlayer().setVipExp(playerLogic.getPlayer().getVipExp() + (card as Good).getAmount());
                let newVip = playerLogic.getPlayer().getVipLevel();
                config = vipconfig[newVip - 1];
                let newCapacity = 0;
                if (config) newCapacity = config.herotakelimit;
                let delta = newCapacity - oldCapacity;
                if (delta > 0) {
                    playerLogic.getPlayer().setHeroCapacity(playerLogic.getPlayer().getHeroCapacity() + delta);
                }
            }
        }
        if (playerLogic.getPlayer().getVipLevel() > vipLevel) {
            let addVipLevel = playerLogic.getPlayer().getVipLevel() - vipLevel;
            gm.popVipPanel = true;
            this.checkAutoRect(vipLevel, playerLogic.getPlayer().getVipLevel());
            heroLogic.artifactUnlockInfo && heroLogic.artifactUnlockInfo.addTaskProgress(8005, addVipLevel);
            EManager.emit(EName.onVipLevelUp);
            EManager.emit(EName.onRedDirty, PromptType.VIPBtn);
            EManager.emit(EName.onMissionPass);
            commitLogic.vipLevelUp(playerLogic.getPlayer().getVipLevel());
        }

        if (cards.length > 0 && ignoreIds && ignoreIds.length > 0) {
            cards = cards.filter((v, i, arr) => {
                let index = ignoreIds.find((a) => { return a == v.getIndex(); });
                return !(index >= 0);
            })
        }
        if (cards.length > 0 && showPanel) {
            if (ex && ex.length > 0) { cards.pushList(ex); }
            gcc.core.showLayer("prefabs/panel/reward/RewardPanel", { data: { cards: cards }, modalTouch: true });
        }

        return cards;
    }

    /**
     * 显示VIP界面
     */
    showVipPanel() {
        if (gm.popVipPanel) { gcc.core.showLayer("prefabs/panel/market/VIPPanel"); }
        gm.popVipPanel = false;
    }

    /**
     * 创建奖励图标
     * @param cards 奖励列表 
     * @param templates 模版
     * @param parent 父节点
     * @param fixNum 数量值修正
     * @param showDesc 点击是否显示详情
     * @param scale 缩放比
     */
    createRewards(cards: Card[], templates: { goodItem: cc.Node, equipItem: cc.Node, heroItem: cc.Node }, parent: cc.Node, fixNum: number = 2, showDesc: boolean = false, scale?: number) {
        for (let card of cards) {
            let icon: cc.Node = null;
            if (card.getType() == Card.Type.Good) {
                if (templates.goodItem) {
                    icon = cc.instantiate(templates.goodItem);
                    let loader = icon.getComponent(CommonLoader);
                    (card as Good).setFixNum(fixNum);
                    loader.loaderNode.getComponent(GoodCard).refresh(card as Good);
                    if (showDesc) { loader.loaderNode.getComponent(GoodCard).registerOnGoodInfo(); }
                }
            }
            else if (card.getType() == Card.Type.Equip
                || card.getType() == Card.Type.Artifact) {
                if (templates.equipItem) {
                    icon = cc.instantiate(templates.equipItem);
                    let loader = icon.getComponent(CommonLoader);
                    loader.loaderNode.getComponent(EquipCard).refresh({ equip: card as Equip });
                    if (showDesc) { loader.loaderNode.getComponent(EquipCard).registerOnEquipInfo(); }
                }
            }
            else if (card.getType() == Card.Type.Hero) {
                if (templates.heroItem) {
                    icon = cc.instantiate(templates.heroItem);
                    let loader = icon.getComponent(CommonLoader);
                    loader.loaderNode.getComponent(HeroCard).refresh(card as Hero);
                    if (showDesc) { loader.loaderNode.getComponent(HeroCard).registerOnHeroInfo(); }
                }
            }
            if (icon) icon.parent = parent;
            if (icon && scale) { icon.scale = scale; }
        }
    }

    /**
     * 创建奖励图标
     * @param item 奖励数据
     * @param node 模版
     * @param parent 父节点
     * @param scale 缩放比
     * @param hideBg 
     * @param noTouch 
     * @param mask 
     * @param param 
     */
    showGoodItem(item: number[],
        node: { goodItem?: cc.Node, equipItem?: cc.Node, heroItem?: cc.Node },
        parent: cc.Node,
        scale?: number,
        hideBg?: boolean,
        noTouch?: boolean, mask?: boolean,
        param?: { quality?: number }
    ): BaseCell {
        let id = item[0];
        let num = item[1] ? item[1] : 0;
        let type = Math.floor(id / 10000);
        let icon: cc.Node = null;
        let cell: BaseCell = null;
        if (type == Card.Type.Good) {
            if (node.goodItem) {
                let vo = new GoodVO();
                vo.amt = num;
                vo.propId = id;
                let good = new Good(vo);
                if (!good.getConfig()) return;

                icon = cc.instantiate(node.goodItem);
                let loader = icon.getComponent(CommonLoader)
                let card = loader.loaderNode.getComponent(GoodCard);
                card.refresh(good);
                card.showBg(hideBg ? false : true);
                if (!noTouch) card.registerOnGoodInfo();
                if (good.getGoodType() == GoodType.HeroPiece) {
                    let heroId: number = good.getConfig().canCompose;
                    let cfg = cm.getHeroConfig(heroId);
                    if (cfg && cfg.Quality >= 3) {
                        card.showQualityIcon();
                    }
                }

                cell = card;
            } else {
                console.error(`物品ui节点为空!`)
            }
        } else if (type == Card.Type.Hero) {
            if (node.heroItem) {
                let heroVo = new HeroVO();
                heroVo.heroCofId = id;
                heroVo.lv = 1;
                heroVo.rank = item.length > 2 ? item[2] : 0;
                heroVo.equips = [];
                let hero = new Hero(heroVo);
                if (!hero.config) return;
                hero.calcProperties();

                icon = cc.instantiate(node.heroItem);
                let loader = icon.getComponent(CommonLoader);
                let card = loader.loaderNode.getComponent(HeroCard);
                card.refresh(hero);
                if (!noTouch) card.registerOnHeroInfo();
                if (hero.getQuality() >= 3) {
                    card.showQualityIcon();
                }
                cell = card;
            } else {
                console.error(`英雄ui节点为空!`)
            }
        } else if (type == Card.Type.Equip) {
            if (node.equipItem) {
                let equipBo = new EquipBO();
                equipBo.equipCofId = id;
                let camp = item.length > 2 ? item[2] : 0;
                camp = camp ? camp : 0;
                equipBo.campBonus = camp;
                let equip = new Equip(equipBo);
                if (!equip.config) return;

                icon = cc.instantiate(node.equipItem);
                let loader = icon.getComponent(CommonLoader);
                let card = loader.loaderNode.getComponent(EquipCard);
                card.refresh({ equip: equip });
                if (!noTouch) card.registerOnEquipInfo();
                cell = card;
            } else {
                console.error(`装备ui节点为空!`);
            }
        } else if (type == Card.Type.Artifact) {
            if (node.equipItem) {
                let artifactBo = new ArtifactBO();
                artifactBo.artifactCofId = id;
                artifactBo.rank = 0;
                artifactBo.forgeLv = 0;
                let artifact = new Artifact(artifactBo);
                if (!artifact.config) return;

                icon = cc.instantiate(node.equipItem);
                let loader = icon.getComponent(CommonLoader);
                let card = loader.loaderNode.getComponent(EquipCard);
                card.refresh({ equip: artifact });
                if (!noTouch) card.registerOnEquipInfo();
                cell = card;
            }
        }
        if (icon) {
            icon.parent = parent;
            if (scale) { icon.scale = scale; }
            if (mask) {
                icon.getComponent(CommonLoader).loaderNode.getComponent(BaseCell).showMask(true);
            }
        }

        return cell;
    }

    /**
     * 创建英雄Spine动画
     * @param hero 英雄
     * @param skeleton 动画组件
     * @param animation 动画名
     * @param isLock 对资源释放加锁（加锁后需解锁才能释放）
     */
    async createHeroSpine(hero: Hero, skeleton: sp.Skeleton, animation?: string, isLock?: boolean) {
        let heroUrl = commonUtils.getHeroSpineUrl(hero.getSpineFile());

        skeleton.node.active = false;
        let skeletonData = await loadUtils.loadRes(heroUrl, sp.SkeletonData) as sp.SkeletonData;
        if (isLock) { skeletonData.lock(); }
        if (skeleton && cc.isValid(skeleton) && skeleton.node && cc.isValid(skeleton.node)) {
            skeleton.skeletonData = skeletonData;
            skeleton.node.active = true;
            (skeleton as any)._updateSkeletonData();
            if (hero.getSpineSkin().length > 0) {
                skeleton.setSkin(hero.getSpineSkin());
            }
            skeleton.animation = animation ? animation : "idle";
            skeleton.loop = true;
        }
    }

    /**
     * 创建普通Spine动画
     * @param url 资源地址
     * @param skeleton 动画组件
     * @param animation 动画名
     * @param loop 是否循环播放
     * @param isLock 对资源释放加锁（加锁后需解锁才能释放）
     */
    async createCommonSpine(url: string, skeleton: sp.Skeleton, animation?: string, loop?: boolean, isLock?: boolean) {
        skeleton.node.active = false;
        let skeletonData = await loadUtils.loadRes(url, sp.SkeletonData) as sp.SkeletonData;
        if (isLock) { skeletonData.lock(); }
        if (skeleton && cc.isValid(skeleton) && skeleton.node && cc.isValid(skeleton.node)) {
            skeleton.skeletonData = skeletonData;
            skeleton.node.active = true;
            (skeleton as any)._updateSkeletonData();
            skeleton.animation = animation ? animation : "idle";
            skeleton.loop = loop;
        }
    }

    /**
     * 英雄属性增减Toast
     * @param property 属性 
     */
    async propertyToast(property: Property | { [key: string]: number }) {
        let contents = [];
        let colors: cc.Color[] = [];
        if (property instanceof Property) {
            let values = property.getValues();
            let titles = property.getTitles();
            for (let i = 0; i < titles.length; i++) {
                let char = "";
                if (values[i] > 0) {
                    char = "+";
                    colors.push(cc.Color.GREEN);
                }
                else {
                    colors.push(cc.Color.RED);
                }
                contents.push(`${titles[i]} ${char}${Property.getShowValue(titles[i], values[i])}`);
            }
        }
        else {
            for (let key in property) {
                let char = "";
                if (property[key] > 0) {
                    char = "+";
                    colors.push(cc.Color.GREEN);
                }
                else {
                    colors.push(cc.Color.RED);
                }
                contents.push(`${key} ${char}${property[key]}`);
            }
        }

        if (contents.length > 0) {
            try {
                let prefab = cc.loader.getRes("prefabs/common/property_change", cc.Prefab);
                if (!prefab) { prefab = await loadUtils.loadRes("prefabs/common/property_change", cc.Prefab) as cc.Prefab }
                let node = cc.instantiate(prefab) as cc.Node;
                node.position = cc.v2();
                node.parent = this._toastLayer;

                let template = node.getChildByName("label");
                template.parent = null;

                for (let i = 0; i < contents.length; i++) {
                    let labelNode = cc.instantiate(template);
                    labelNode.color = colors[i];
                    labelNode.parent = node;

                    let label = labelNode.getComponent(cc.Label);
                    label.string = contents[i];
                }

                let animation = node.getComponent(cc.Animation);
                animation["_init"] = cc.Animation.prototype['_initEx'];
                animation.on("finished", () => { node.destroy(); }, node);
            } catch (error) {
                console.error(error);
            }
        }
    }

    /**
     * 显示开始战斗动画
     */
    async showBattleIndicator() {
        this.isIndicatorEnabled = false;
        return new Promise((resolve, reject) => {
            let size = cc.winSize;
            let nowScene = cc.director.getScene();

            let prefab = cc.loader.getRes("prefabs/fight/fight_start", cc.Prefab);
            this._battleIndicatorLayer = cc.instantiate(prefab);
            this._battleIndicatorLayer.name = "battle indicator";
            this._battleIndicatorLayer.setContentSize(size);
            this._battleIndicatorLayer.position = cc.v2(size.width / 2, size.height / 2);
            nowScene.addChild(this._battleIndicatorLayer, 300);

            let animation = this._battleIndicatorLayer.getChildByName("start").getComponent(cc.Animation);
            animation.play("fight_start");
            animation.on("finished", resolve);
        });
    }

    /**
     * 隐藏开始战斗动画
     */
    hideBattleIndicator() {
        this.isIndicatorEnabled = true;
        if (cc.isValid(this._battleIndicatorLayer)) {
            let layer = this._battleIndicatorLayer;
            let animation = this._battleIndicatorLayer.getChildByName("start").getComponent(cc.Animation);
            animation.play("fight_start2");
            animation.on("finished", () => { layer.destroy(); });

            this._battleIndicatorLayer = null;
        }
    }

    /**
     * 显示加载动画
     * @param delay 延迟时间 
     */
    showIndicator(delay?: number) {
        if (!this || !this._indicatorLayer) { return; }
        if (!this.isIndicatorEnabled) { return; }

        let panel = this._indicatorLayer.getComponent(IndicatorPanel);
        panel.show(delay);
    }

    /**
     * 隐藏加载动画
     */
    hideIndicator() {
        if (!this || !this._indicatorLayer) { return; }
        if (!this.isIndicatorEnabled) { return; }

        let panel = this._indicatorLayer.getComponent(IndicatorPanel);
        panel.hide();
    }

    /**
     * 创建地图建筑上行走的僵尸
     * @param parent 父节点
     */
    createWalkZombie(parent: cc.Node) {
        if (!parent) return;
        if (!cc.isValid(parent)) return;

        try {
            let walkNode = this._walkZombieNodes[parent.name];
            if (walkNode) {
                walkNode.parent = parent;
            }
            else {
                let path = parent.getChildByName("path");
                if (path) {
                    let walkNode = new cc.Node('walkNode');
                    walkNode.parent = parent;

                    let comp = walkNode.addComponent(FightPath);
                    comp.init(path, true);
                    this._walkZombieNodes[parent.name] = walkNode;
                }
            }
        } catch (error) {
            console.error(error);
        }
    }

    /**
     * 销毁行走的僵尸
     * @param parent 父节点
     */
    destroyWalkZombie(parent: cc.Node) {
        if (!parent) return;
        if (!cc.isValid(parent)) return;

        let walkNode = this._walkZombieNodes[parent.name];
        if (walkNode) {
            walkNode.destroy();
            delete this._walkZombieNodes[parent.name];
        }
    }

    /**
     * 创建挂机战斗节点
     * @param parent 父节点
     */
    async createHangUpBattle(parent: cc.Node) {
        if (!parent) return;
        if (!cc.isValid(parent)) return;

        if (this._fightNode) {
            this._fightNode.parent = parent;
        }
        else {
            let ret = await playerLogic.isTroopEmpty(BattleType.PVE);
            if (!ret) {
                if (!cc.isValid(parent)) return;

                let mission = missionLogic.getCurrentMission();
                if (mission) {
                    let fightNode = new cc.Node('fightNode')
                    let comp = fightNode.addComponent(FightHangUp);
                    comp.init(mission, parent.width, parent.height);
                    this._fightNode = fightNode;
                    this._fightNode.parent = parent;
                }
            }
        }
    }

    /**
     * 销毁挂机战斗
     */
    destroyHangUpBattle() {
        if (this._fightNode) {
            this._fightNode.destroy();
            this._fightNode = null;
        }
    }

    /**
     * 显示离线对话框
     * @param msg 消息类型
     */
    onOfflineMessage(msg: any) {
        let tip: string = "服务器维护中,暂时无法登陆";
        if (msg == "1" || msg == 1) {
            tip = "该账号已在另外一台设备登陆!"
        }
        gm.dialog({
            content: tip,
            confirm: () => {
                cc.game.end();
            },
            cancel: () => {
                cc.game.end();
            },
            noCancel: true,
        })
    }

    /**
     * 显示领取挂机奖励的飞金币动画
     * @param cards 奖励
     * @param bagNode 背包按钮
     * @param expNode 经验图标
     * @param goldNode 金币图标
     */
    async rewardFly(cards: Card[], bagNode: cc.Node, expNode: cc.Node, goldNode: cc.Node) {
        try {
            let prefab = cc.loader.getRes("prefabs/common/reward_fly", cc.Prefab);
            if (!prefab) {
                prefab = await loadUtils.loadRes("prefabs/common/reward_fly", cc.Prefab) as cc.Prefab;
            }

            let node = cc.instantiate(prefab) as cc.Node;
            node.position = cc.p(-70, -240);
            node.parent = this._toastLayer;
            node.getComponent(RewardFly).showReward(cards, bagNode, expNode, goldNode);
        } catch (error) {
            console.error(error);
        }
    }

    /**
     * 显示飞金币动画
     */
    async rewardGoldFly() {
        try {
            let prefab = cc.loader.getRes("prefabs/common/reward_gold_fly", cc.Prefab);
            if (!prefab) { prefab = await loadUtils.loadRes("prefabs/common/reward_gold_fly", cc.Prefab) as cc.Prefab }

            let node = cc.instantiate(prefab) as cc.Node;
            node.position = cc.v2();
            node.parent = this._toastLayer;
            let skeleton = node.getComponent(sp.Skeleton);
            skeleton.setCompleteListener(() => { node.destroy(); });
        } catch (error) {
            console.error(error);
        }
    }

    /**
     * @override
     */
    getCurrentTimestamp(): number {
        return new Date().getTime() + this._deltaTimestamp;
    }

    /**
     * 获取区服名称
     * @param id 区服ID
     */
    getServerName(id: number): string {
        let serverName = this.districtMap[id] ? this.districtMap[id].name : "";
        return serverName;
    }

    /**
     * 是否可以忽略视频
     */
    needIgnoreVideo(): boolean {
        let timestamp = storageUtils.getNumber(Storage.FreeVideoTimestamp);
        return timestamp > gm.getCurrentTimestamp() || rechargeLogic.isSuperMonthCardBuyed();
    }

    /**
     * 粉尘道具id和数量 转换为粉尘id和数量
     * @param good 
     */
    glassToDust(good: number[]): number[] {
        if (good.length < 2) { return []; }
        let reward: number[] = good;
        let cfg = cm.getGoodConfig(good[0]);
        if (cfg && (cfg.type == GoodType.DustHourGlass || cfg.type == GoodType.EpicDustHourGlass)) {
            let num = cfg.effect * benefitLogic.getDropDustPerHour() * reward[1];
            reward[0] = GoodId.Dust;
            reward[1] = num;
        }
        return reward;
    }

    /**
     * 本地数据的每日刷新检查
     */
    checkDayFresh() {
        let localTs = this.getLoginTsLocal() * 1000;
        let fresh: boolean = false;
        console.log("开始检查每日刷新:")
        if (localTs == 0) {
            // 刷新
            fresh = true;
        } else {
            let nowTs = this.getCurrentTimestamp();
            let now = new Date(nowTs);
            let local = new Date(localTs);
            console.log(`now month:${now.getUTCMonth()} day:${now.getUTCDate()}`);
            console.log(`local month:${local.getUTCMonth()} day:${local.getUTCDate()}`);
            if (now.getUTCMonth() > local.getUTCMonth() || now.getUTCDate() > local.getUTCDate()) {
                fresh = true;
            }
        }
        if (fresh) {
            // 每日刷新
            if (unionLogic) { unionLogic.resetPartRead(); }
            if (localLogic) { localLogic.resetLocalData(); }
            console.log("每日刷新数据");
            this.setLoginTsLoacl();
        }
    }

    /**
     * 保存登陆时间
     */
    setLoginTsLoacl() {
        let ts = this.getCurrentTimestamp() / 1000;
        storageUtils.setNumber('user_utc_ts', ts);
    }

    /**
     * 获取登陆时间
     */
    getLoginTsLocal(): number {
        return storageUtils.getNumber({ Key: 'user_utc_ts', Default: 0 });
    }

    /**
     * 获取当前区服模型
     */
    getMyServer(): DistrictDO {
        return this._myServer;
    }

    /**
     * 获取引导面板
     */
    getGuidePanel(): GuidePanel {
        return this._guideLayer.getComponent(GuidePanel);
    }

    /**
     * 提交事件信息
     * @param eventGroup 
     * @param events 
     * @param value 
     */
    commitEvent(eventGroup: string, events: string[], value: number) {
        // exp commitEvent("关卡",["闯关模式","第1关","胜利"],"记录数据");
        // exp commitEvent("普通转盘",["22","2","刷新"]，1)；
        gssdk.logCommitTool.commitEvent(eventGroup, events, value);
        console.warn(`提交事件: ${eventGroup} - ${events.join(';')} - ${value}`);
    }

    /**
     * @override
     * @param api 接口名称 
     * @param param 参数
     * @param proxy HTTP代理
     * @param noBlock 不转菊花
     */
    async request<T>(api: Function, param?: any, proxy?: any, noBlock?: boolean): Promise<T> {
        return new Promise<T>((resolve, reject) => {
            let callback = (data: {
                succeed: boolean,
                code: 0 | number,
                message: "success" | string,
                ts: number,
                map_min_v: {
                    min: string;
                    max: string;
                },
                errorcode: string,
                data: T
            }) => {
                if (!noBlock) { gm.hideIndicator(); }

                if (data.succeed) {
                    this._deltaTimestamp = data.ts - new Date().getTime();
                    resolve(data.data);
                }
                else {
                    if (data.code == -9999) {
                        commonUtils.sleep(1).then(() => {
                            if (proxy)
                                api.call(proxy, param, callback, false, errorCallback);
                            else
                                api.call(GameProxy, param, callback, false, errorCallback);
                        });
                    }
                    else {
                        if (data.errorcode == "SERVER_VERSION_UPDATE") {
                            gm.dialog({
                                content: stringConfigMap.key_update_package.Value,
                                confirm: () => { cc.game.end(); },
                                noCancel: true,
                                id: "single dialog",
                                top: true
                            });
                            return;
                        }

                        let msg = cm.getErrorMsg(data.errorcode);
                        if (msg) {
                            if (msg.msgcn.search("%s") != -1) {
                                data.message = stringUtils.formatStr2(msg.msgcn, JSON.parse(data.message));
                            } else {
                                data.message = msg.msgcn;
                            }
                        }
                        reject(new ToastError(data.message));
                    }
                }
            };

            let newProxy = proxy;
            if (!newProxy) {
                newProxy = GameProxy;
            }

            let retryCount = 0;
            let errorCallback = async (error: any, retry: () => void) => {
                if (retryCount > 3) {
                    retryCount = 0;
                    gdk.showAlert({
                        title: stringConfigMap.key_alert_title.Value,
                        content: stringConfigMap.key_network_error.Value
                    }).then(function (res) {
                        retry();
                    });
                }
                else {
                    await commonUtils.sleep(1);
                    retry();
                    retryCount++;
                }
            };

            if (!noBlock) { gm.showIndicator(0.5); }
            api.call(newProxy, param, callback, false, errorCallback);
        })
    }

    /**
     * 校正红点
     * @param node 
     */
    checkRedNode(node: cc.Node) {
        if (node && cc.isValid(node)) {
            let redFrame = node.getComponent(cc.Sprite);
            if (redFrame) { redFrame.sizeMode = cc.Sprite.SizeMode.TRIMMED; }

            let min: number = 33;
            if (node.width < min && node.height < min) {
                node.setContentSize(min, min);
            }
            node.scale = 1;
        }
    }

    protected _vipInfo: number[][] = [
        [1, 4],
        [3, 5],
        [7, 6],
        [9, 7],
        [13, 8],
    ]

    protected _vipTag: number[][] = [
        [1, 3, 1],
        [4, 6, 2],
        [7, 10, 3],
        [11, 14, 4],
        [15, 100, 5],
    ]

    /**
     * VIP头像框解锁等级
     * @param rectIndex 
     */
    rectUnlockVipLevel(rectIndex: number): number {
        let data = this._vipInfo.find((a) => { return a[1] == rectIndex; })
        if (!data) { return 0; }
        return data[0];
    }

    getVipIconUrl(level: number): string {
        let data = this._vipInfo.find((a) => { return a[0] == level; })
        if (data) { return commonUtils.getCommonUrl(`common_player_rect${data[1]}`); }
        return "";
    }

    public getVipTagUrl(level: number) {
        let data = this._vipTag.find((a) => { return a[0] <= level && a[1] >= level; });
        if (!data) { return ''; };
        return commonUtils.getCommon2Url(`vip_tag_${data[2]}`);
    }

    public addVipTag(node: cc.Node, vipLevel: number, pos: cc.Vec2, scale: number = 0.8) {
        let vipNode: cc.Node = node.getChildByName("vip");
        if (vipLevel <= 0) { return; }
        if (vipNode) {
            let vipBg = vipNode.addComponent(cc.Sprite);
            if (vipBg) {
                let url: string = this.getVipTagUrl(vipLevel);
                loadUtils.loadSpriteFrame(url, vipBg);
            }
            return;
        }
        vipNode = new cc.Node("vip");
        vipNode.position = pos || cc.v2(0, -33);
        vipNode.anchorX = 0.5;
        vipNode.anchorY = 0.5;
        vipNode.scale = scale;
        vipNode.parent = node;

        let vipBg = vipNode.addComponent(cc.Sprite);
        if (vipBg) {
            let url: string = this.getVipTagUrl(vipLevel);
            loadUtils.loadSpriteFrame(url, vipBg);
        }
    }

    /**
     * 节点上增加VIP等级
     * @param node 
     * @param vipLevel 
     * @param pos 
     * @param scale 
     */
    addVipIcon(node: cc.Node, vipLevel: number, pos: cc.Vec2, scale: number = 0.8) {
        let vipNode: cc.Node = node.getChildByName("vip");
        if (vipNode || vipLevel <= 0) {
            if (vipNode && vipNode.getChildByName("vipIcon")) {
                let vip = vipNode.getChildByName("vipIcon").getComponent(cc.Sprite);
                if (vip) { loadUtils.loadSpriteFrame(commonUtils.getCommonUrl(`vip_${vipLevel}`), vip); }
            }
            return;
        }
        vipNode = new cc.Node("vip");
        vipNode.position = pos || cc.v2(0, -33);
        vipNode.anchorX = 0.5;
        vipNode.anchorY = 0.5;
        vipNode.scale = scale;
        vipNode.parent = node;

        let vipBg = vipNode.addComponent(cc.Sprite);
        if (vipBg) {
            loadUtils.loadSpriteFrame(commonUtils.getCommonUrl(`vip_bg`), vipBg);

            let vipIcon = new cc.Node("vipIcon");
            vipIcon.position = cc.v2(0, 0);
            vipIcon.parent = vipNode;
            let icon = vipIcon.addComponent(cc.Sprite);
            loadUtils.loadSpriteFrame(commonUtils.getCommonUrl(`vip_${vipLevel}`), icon);
        }
    }

    /**
     * vip升级后设置默认VIP头像框
     * @param vipFrom 
     * @param vipNow 
     */
    async checkAutoRect(vipFrom: number, vipNow: number) {
        if (vipFrom >= vipNow) { return; }

        let avatarRect: number = 0;
        for (let i = vipFrom; i < vipNow; i++) {
            let vip = i + 1;
            let data = this._vipInfo.find((a) => { return a[0] == vip; })
            if (data) {
                avatarRect = data[1];
            }
        }
        if (avatarRect > 0) {
            let avatar = playerLogic.getPlayer().getAvatar();
            console.warn(`vip升级 设置默认头像框  avatar:${avatar} rect:${avatarRect}`);
            await playerLogic.doChangeAvatar(avatar, `${avatarRect}`);
        }
    }

    /**
     * 资源不足跳转
     * @param type 
     */
    public lackResGotoPanel(type: ResType) {
        if (this.appReview) {
            let lackRes = ResInfo.find((a) => { return a.type == type; });
            if (lackRes) {
                gm.toast(lackRes.title);
            }
        }
        else {
            gcc.core.showLayer("prefabs/panel/help/ResGotoPanel", { data: type });
        }
    }
}

let gm = new GameManager();
export default gm;