import Info from "../Info";

/**
 * 观看关卡代理
 */
class AdManager {
    protected _fullScreenAD: any = null;
    protected _leaveResultTimes: number = 0;
    protected _fullscreenTimes: number = 0;
    protected _videoAD: any = null;
    protected _videoLoaded: boolean = false;
    protected _success = null;
    protected _fail = null;
    protected _leavePostTimes: number = 0;

    protected _feedAd: GDK.IFeedAd = null
    protected _setLoading: boolean = false;

    get videoLoaded(): boolean {
        return (this.isTest() || this._videoLoaded) && !this._setLoading;
    }

    setVideoLoadingStatu(value: boolean) {
        this._setLoading = value;
    }

    init() {
        try {
            this._fullScreenAD = gssdk.createFullscreenVideoAd({});
            this._videoAD = gssdk.createVideoAd({});
            if (this._videoAD) {
                this._videoAD.onLoad(this._onLoadCallback.bind(this));
                this._videoAD.onError(this._onErrorCallback.bind(this));
                this._videoAD.load();
            }
        }
        catch (err) {
            console.log(err)
        }
    }

    validVideoAdObj() {
        if (!this._videoAD) {
            this._videoAD = gssdk.createVideoAd({});
            if (this._videoAD) {
                this._videoAD.onLoad(this._onLoadCallback.bind(this));
                this._videoAD.onError(this._onErrorCallback.bind(this));
                this._videoAD.load();
            }
        }
    }

    // showFullscreenVideoAd() {
    //     let version = this.getFullScreenVersion()
    //     if (version == "V2") {
    //         this.showFullscreenVideoAdV2()
    //     }
    //     else {
    //         this.showFullscreenVideoAdV1()
    //     }
    // }

    // getFullScreenVersion() {
    //     let versionCode: number = 1;
    //     let showFlag = false
    //     console.log("createtime", gssdk.loginData.createTime)
    //     if (cc.sys.os == cc.sys.OS_ANDROID && gssdk.checkFeature(FunctionToggle.FullScreenAds)) {
    //         versionCode = 4;
    //         showFlag = gdk.systemInfo.versionCode >= versionCode
    //     }
    //     else if (cc.sys.os == cc.sys.OS_IOS && gssdk.checkFeature(FunctionToggle.FullScreenAdsIOS)) {
    //         versionCode = 14;
    //         //let createTime = 1574737341710
    //         let createTime = 1575129600000
    //         showFlag = (gdk.systemInfo.versionCode >= versionCode && gssdk.loginData.createTime >= createTime)
    //     }


    //     let version = "V1"
    //     if (showFlag) {
    //         version = "V2"
    //     }

    //     return version
    // }

    // showFullscreenVideoAdV2() {
    //     this._leaveResultTimes++;
    //     let fullscreenAdRate = GManager.getFullScreenLevel()

    //     if (GPlayer.saved.currentMission == 15 && !GPlayer.saved.hasShowFullScreen[15]) {
    //         GPlayer.saved.hasShowFullScreen[15] = true
    //         this._leaveResultTimes = 0
    //     }

    //     if (GPlayer.saved.currentMission == 30 && !GPlayer.saved.hasShowFullScreen[30]) {
    //         GPlayer.saved.hasShowFullScreen[30] = true
    //         this._leaveResultTimes = 0
    //     }


    //     if (fullscreenAdRate == 0 || (this._leaveResultTimes % fullscreenAdRate != 0)) {
    //         return;
    //     }

    //     //this._fullscreenTimes++;
    //     //if (this._fullscreenTimes % ConfigManager.videoAdRate != 0) 
    //     //{
    //     if (this._fullScreenAD) {
    //         //await this._fullScreenAD.load();
    //         await this._fullScreenAD.play({ eventName: "关卡结算" });
    //         this._fullScreenAD.load();
    //     }
    //     //}
    //     // else {
    //     //     if (this._videoAD) {
    //     //         await this.preloadVideoAd();
    //     //         await this.showVideoAd("全屏视频改激励视频", null);
    //     //     }
    //     // }
    // }

    // async showFullScreenAd(name) {
    //     if (this._fullScreenAD) {
    //         //await this._fullScreenAD.load();
    //         await this._fullScreenAD.play({ eventName: name });
    //         this._fullScreenAD.load();
    //     }
    // }


    // async showFullscreenVideoAdV1() {
    //     this._leaveResultTimes++;
    //     if (this._leaveResultTimes % ConfigManager.fullscreenAdRate != 0) {
    //         return;
    //     }
    //     this._fullscreenTimes++;
    //     if (this._fullscreenTimes % ConfigManager.videoAdRate != 0) {
    //         if (this._fullScreenAD) {
    //             //await this._fullScreenAD.load();
    //             await this._fullScreenAD.play({ eventName: "关卡结算" });
    //             this._fullScreenAD.load();
    //         }
    //     }
    //     else {
    //         if (this._videoAD) {
    //             await this.preloadVideoAd();
    //             await this.showVideoAd("全屏视频改激励视频", null);
    //         }
    //     }
    // }

    // async showFullscreenVideoAdPost() {
    //     this._leavePostTimes++;
    //     if (this._leavePostTimes % ConfigManager.rewardStageFull != 0) {
    //         return;
    //     }
    //     if (this._fullScreenAD) {
    //         //await this._fullScreenAD.load();
    //         await this._fullScreenAD.play({ eventName: "悬赏全屏视频" });
    //         this._fullScreenAD.load();
    //     }
    // }



    protected _onLoadCallback() {
        console.log("广告加载回调");
        if (this._videoAD && this._videoAD.isAdValid) {
            console.log("成功");
            this._videoLoaded = true;
            this._success && this._success();
        } else {
            console.log("失败");
            this._videoLoaded = false;
            this._fail && this._fail();
        }
    }

    protected _onErrorCallback(res) {
        console.log("广告加载失败");
        this._videoLoaded = false;
        this._fail && this._fail();
    }

    async preloadVideoAd(success = null, fail = null) {
        this._success = success;
        this._fail = fail;
        if (this.isTest()) { return; }
        this.validVideoAdObj();
        if (!this._videoAD) {
            console.error("gssdk 创建视频管理对象失败");
            return;
        }
        await this._videoAD.load();
    }

    private isTest(): boolean {
        return (Info.mode == "develop" && CC_PREVIEW)
    }

    async showVideoAd(eventName: string, success, fail = null) {
        if (this.isTest()) {
            if (success) { success(); }
            return;
        }
        if (this._videoAD) {
            try {
                let result = await this._videoAD.play({ eventName: eventName });
                if (result.isEnded) {
                    success && success();

                    // cc.game.emit(Define.Event.TaskAction, AchivementType.kVideo, 1)
                    // GManager.addSkinRecord(SkinRecordType.Video)

                    // if (this.getFullScreenVersion() == "V2") {
                    //     GManager.addFullScreenRecord()
                    // }

                } else {
                    fail && fail();
                }
            } catch (e) {
                fail && fail();
            }
        } else {
            fail && fail();
        }
    }

    // async preloadFeedAd() {
    //     if (gdk.supportFeedAd) {
    //         this.destoryFeedAd()

    //         this._feedAd = gdk.createFeedAd({
    //             style: {
    //                 y: 0,
    //                 x: 0
    //             },
    //             isDebugMode: false//info.mode=="develop"
    //         })


    //         // 加载广告
    //         try {
    //             await this._feedAd.load()
    //         }
    //         catch (err) {
    //             console.log("feedAds load error:", err)
    //             this.destoryFeedAd()
    //         }
    //     }
    // }

    // get feedAd() {
    //     return this._feedAd
    // }

    // async showFeedAd() {
    //     if (this._feedAd) {
    //         await this._feedAd.show()
    //     }
    // }

    // async hideFeedAd() {
    //     if (this._feedAd) {
    //         await this._feedAd.hide()
    //     }
    // }

    // async destoryFeedAd() {
    //     if (this._feedAd) {
    //         this._feedAd.destroy()
    //         this._feedAd = null
    //     }
    // }
}

let ad = new AdManager();
export default ad;