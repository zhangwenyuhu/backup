import { ResourceVO } from "../proxy/GameProxy";
import PlayerEquip from "../data/card/PlayerEquip";
import Equip from "../data/card/Equip";

/**
 * 游戏代理接口
 */
export default interface IGameManager {
    /**
     * 获取当前时间戳
     */
    getCurrentTimestamp(): number;

    /**
     * HTTP请求
     * @param api 接口名称 
     * @param param 参数
     * @param proxy HTTP代理
     * @param noBlock 不转菊花
     */
    request<T>(api: Function, param?: any, proxy?: any, noBlock?: boolean): Promise<T>;

    /**
     * 加入奖励，并显示奖励界面
     * @param res 奖励模型
     * @param showPanel 显示奖励面板
     */
    getReward(res: ResourceVO, showPanel: boolean): void;

    /**
     * 显示对话框
     * @param data 
     */
    dialog(data: {
        title?: string,
        content: string,
        okText?: string,
        confirm?: Function,
        cancel?: Function,
        noCancel?: boolean,
        id?: string,
        top?: boolean
    }): void;

    /**
     * 装备继承二次确认框
     * @param curEquip 当前装备
     * @param replaceEquip 替换装备
     * @param confirm 确认回调
     * @param cancel 取消回调
     */
    inheritDialog(curEquip: Equip, replaceEquip: Equip, confirm: Function, cancel: Function): void;

    /**
     * 装备分解二次确认框
     * @param equip 装备
     * @param confirm 确认回调
     * @param cancel 取消回调
     */
    splitDialog(equip: Equip, confirm: Function, cancel: Function): void;

    /**
     * 装备重铸放弃确认框
     * @param prevFaction 上次种族
     * @param nowFaction 当前种族
     * @param equip 装备
     * @param confirm 确认回调
     * @param cancel 取消回调
     * @param effect
     */
    recastDialog(prevFaction: number, nowFaction: number, equip: PlayerEquip, confirm: Function, cancel: Function, effect: Function): void;
}