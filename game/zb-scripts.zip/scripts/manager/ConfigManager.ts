import propertyConfig, { propertyConfigRow } from './../configs/propertyConfig';
import { jibanconfigRow } from './../configs/jibanconfig';
import ArenaRankconfig, { ArenaRankconfigRow } from './../configs/ArenaRankconfig';
import arenascorerewardconfig, { arenascorerewardconfigRow } from './../configs/arenascorerewardconfig';
import arenachallangetimeconfig, { arenachallangetimeconfigRow } from './../configs/arenachallangetimeconfig';
import stoneheroconfig, { stoneheroconfigRow } from './../configs/stoneheroconfig';
import skipconfig, { skipconfigRow } from './../configs/skipconfig';
import artifactunlockConfig, { artifactunlockConfigRow } from './../configs/artifactunlockConfig';
import artifactlevelConfig, { artifactlevelConfigRow } from './../configs/artifactlevelConfig';
import { storyconfigRow } from './../configs/storyconfig';
import geniusConfig, { geniusConfigRow } from './../configs/geniusConfig';
import { mazefruitconfigRow } from './../configs/mazefruitconfig';
import dungeonconfig, { dungeonconfigRow } from './../configs/dungeonconfig';
import spacetimeconfig, { spacetimeconfigRow } from './../configs/spacetimeconfig';
import ServerErrorCodeConfig, { ServerErrorCodeConfigRow } from './../configs/ServerErrorCodeConfig';
import artifactConfig, { artifactConfigRow } from './../configs/artifactConfig';
import skillConfig, { skillConfigRow } from './../configs/skillConfig';
import goodsConfig, { goodsConfigRow } from './../configs/goodsConfig';
import equipConfig, { equipConfigRow } from './../configs/equipConfig';
import heroConfig, { heroConfigRow } from './../configs/heroConfig';
import Stageconfig, { StageconfigRow } from '../configs/Stageconfig';
import Monsterconfig, { MonsterconfigRow } from '../configs/Monsterconfig';
import xsConfig, { xsConfigRow } from '../configs/xsConfig';
import xsLvConfig, { xsLvConfigRow } from '../configs/xsLvConfig';
import Dailytaskconfig, { DailytaskconfigRow } from '../configs/Dailytaskconfig';
import Taskconfig, { TaskconfigRow } from '../configs/Taskconfig';
import Tasktypeconfig, { TasktypeconfigRow } from '../configs/Tasktypeconfig';
import { defaultConfigMap } from '../configs/defaultConfig';
import ActiveRewardconfig, { ActiveRewardconfigRow } from '../configs/ActiveRewardconfig';
import heroLevelConfig from '../configs/heroLevelConfig';
import skybuildconfig, { skybuildconfigRow } from '../configs/skybuildconfig';
import effectViewConfig, { effectViewConfigRow } from "../configs/effectViewConfig";
import growUpConfig, { growUpConfigRow } from '../configs/growUpConfig';
import storeConfig, { storeConfigRow } from '../configs/storeConfig';
import giftConfig, { giftConfigRow } from '../configs/giftConfig';
import kaoshangConfig, { kaoshangConfigRow } from '../configs/kaoshangConfig';
import timeGiftConfig, { timeGiftConfigRow } from '../configs/timeGiftConfig';
import videoconfig, { videoconfigRow } from '../configs/videoconfig';
import guidetaskconfig, { guidetaskconfigRow } from '../configs/guidetaskconfig';
import circleconfig, { circleconfigRow } from '../configs/circleconfig';
import circlerankconfig, { circlerankconfigRow } from '../configs/circlerankconfig';
import boardconfig, { boardconfigRow } from '../configs/boardconfig';
import boardtaskconfig, { boardtaskconfigRow } from '../configs/boardtaskconfig';
import mazefruitconfig from '../configs/mazefruitconfig';
import surprisegiftconfig, { surprisegiftconfigRow } from '../configs/surprisegiftconfig';
import statuefreewalletconfig, { statuefreewalletconfigRow } from '../configs/statuefreewalletconfig';
import xunbaorewardconfig, { xunbaorewardconfigRow } from '../configs/xunbaorewardconfig';
import wheelprizepool, { wheelprizepoolRow } from '../configs/wheelprizepool';
import storyconfig from '../configs/storyconfig';
import niudanheroconfig, { niudanheroconfigRow } from '../configs/niudanheroconfig';
import sevenDaysNewConfig, { sevenDaysNewConfigRow } from '../configs/sevenDaysNewConfig';
import HeroCompoundConfig, { HeroCompoundConfigRow } from "../configs/HeroCompoundConfig";
import skillspecialconfig, { skillspecialconfigRow } from '../configs/skillspecialconfig';
import heroRankConfig, { heroRankConfigRow } from "../configs/heroRankConfig";
import ActiveListconfig from "../configs/ActiveListconfig";
import skinconfig, { skinconfigRow } from "../configs/skinconfig";
import jibanconfig from '../configs/jibanconfig';
import equipstarConfig, { equipstarConfigRow } from '../configs/equipstarConfig';
import factiontechconfig, { factiontechconfigRow } from '../configs/factiontechconfig';
import factiongameconfig, { factiongameconfigRow } from '../configs/factiongameconfig';
import factiongamescoreconfig, { factiongamescoreconfigRow } from '../configs/factiongamescoreconfig';
import factiongamethemeconfig, { factiongamethemeconfigRow } from '../configs/factiongamethemeconfig';
import factionboxconfig, { factionboxconfigRow } from '../configs/factionboxconfig';
import medalconfig, { medalconfigRow } from '../configs/medalconfig';
import medaltechinfoconfig, { medaltechinfoconfigRow } from '../configs/medaltechinfoconfig';
import medaltechconfig, { medaltechconfigRow } from '../configs/medaltechconfig';

/**
 * 表格配置代理
 */
class ConfigManager {
    protected _heroMap: { [key: number]: heroConfigRow } = {};
    protected _equipMap: { [key: number]: equipConfigRow } = {};
    protected _goodsMap: { [key: number]: goodsConfigRow } = {};
    protected _skillMap: { [key: number]: skillConfigRow } = {};
    protected _artifactMap: { [key: number]: artifactConfigRow } = {};
    protected _stageMap: { [key: number]: StageconfigRow } = {};
    protected _monsterMap: { [key: number]: MonsterconfigRow } = {};
    protected _xsMap: { [key: number]: xsConfigRow } = {};
    protected _xsLvMap: { [key: number]: xsLvConfigRow } = {};
    protected _dailyTaskMap: { [key: number]: DailytaskconfigRow } = {};
    protected _mainTaskMap: { [key: number]: TaskconfigRow } = {};
    protected _taskMap: { [key: number]: TasktypeconfigRow } = {};
    protected _taskActiveRewardMap: { [key: number]: ActiveRewardconfigRow } = {};
    protected _commonSkillLevels: { [key: number]: number[] } = {};
    protected _epicsSkillLevels: { [key: number]: number[] } = {};
    protected _mythSkillLevels: { [key: number]: number[] } = {};
    protected _towerMap: { [key: number]: skybuildconfigRow } = {};
    protected _errorCodes: { [key: string]: ServerErrorCodeConfigRow } = {};
    protected _buffEffectViewMap: { [key: number]: effectViewConfigRow } = {};
    protected _effectViewMap: { [key: number]: effectViewConfigRow } = {};
    protected _growupMap: { [key: number]: growUpConfigRow } = {};
    protected _storeMap: { [key: number]: storeConfigRow } = {};
    protected _giftMap: { [key: number]: giftConfigRow } = {};
    protected _kaoshangMap: { [key: number]: kaoshangConfigRow } = {};
    protected _activeGiftMap: { [key: number]: kaoshangConfigRow } = {};
    protected _wisdomGiftMap: { [key: number]: kaoshangConfigRow } = {};
    protected _timeGiftMap: { [key: number]: timeGiftConfigRow } = {};
    protected _videoCfgMap: { [key: number]: videoconfigRow } = {};
    protected _guideCfgMap: { [key: number]: guidetaskconfigRow } = {};
    protected _circleCfgMap: { [key: number]: circleconfigRow } = {};
    protected _circleRankCfgMap: { [key: number]: circlerankconfigRow } = {};
    protected _boardCfgMap: { [key: number]: boardconfigRow } = {};
    protected _boardTaskCfgMap: { [key: number]: boardtaskconfigRow } = {};
    protected _spaceTimeCfgMap: { [key: number]: spacetimeconfigRow } = {};
    protected _dungeonCfgMap: { [key: number]: dungeonconfigRow } = {};
    protected _dungeonIdCfgMap: { [key: number]: dungeonconfigRow } = {};
    protected _fruitCfgMap: { [key: number]: mazefruitconfigRow } = {};
    protected _surpriseGiftCfgMap: { [key: number]: surprisegiftconfigRow } = {};
    protected _redTaskCfgMap: { [key: number]: statuefreewalletconfigRow } = {};
    protected _xunbaoCfgMap: { [key: number]: xunbaorewardconfigRow } = {};
    protected _geniusCfgMap: { [key: number]: geniusConfigRow } = {};
    protected _zhuanpanCfgMap: { [key: number]: wheelprizepoolRow } = {};
    protected _storyCfgMap: { [key: number]: { [key: number]: storyconfigRow[] } } = {};
    protected _artifactLevelCfgMap: { [key: number]: artifactlevelConfigRow[] } = {};
    protected _artifactUnlockCfgMap: { [key: number]: artifactunlockConfigRow[] } = {};
    protected _taskTypeCfgMap: { [key: number]: TasktypeconfigRow } = {};
    protected _niudanHeroCfgMap: { [key: number]: niudanheroconfigRow } = {};
    protected _skipCfgMap: { [key: number]: skipconfigRow } = {};
    protected _sevenTaskNewCfgMap: { [Key: number]: sevenDaysNewConfigRow } = {};
    protected _heroCompoundCfgMap: { [Key: number]: HeroCompoundConfigRow } = {};
    protected _heroSkillConfigMap: { [key: number]: skillspecialconfigRow } = {};
    protected _heroRankLevelMap: { [key: number]: heroRankConfigRow } = {};
    protected _stoneHeroMap: { [key: number]: stoneheroconfigRow } = {};
    protected _arenaChallengeRewardMap: { [key: number]: arenachallangetimeconfigRow } = {};
    protected _arenaScoreRewardMap: { [key: number]: arenascorerewardconfigRow } = {};
    protected _heroPieceMap: { [key: number]: goodsConfigRow } = {};
    protected _arenaRankMap: { [key: number]: ArenaRankconfigRow } = {};
    protected _arenaRankIdMap: { [key: number]: ArenaRankconfigRow } = {};
    protected _heroSkinMap: { [key: number]: skinconfigRow } = {};
    protected _jibanMap: { [key: number]: jibanconfigRow } = {};
    protected _propertyMap: { [key: number]: propertyConfigRow } = {};
    protected _equipStarMap: { [key: number]: equipstarConfigRow } = {};
    protected _techMap: { [key: number]: factiontechconfigRow } = {};
    protected _7dayNewMap: { [key: number]: sevenDaysNewConfigRow } = {};
    protected _udgMap: { [key: number]: factiongameconfigRow } = {};
    protected _udgScoreMap: { [key: number]: factiongamescoreconfigRow } = {};
    protected _udgThemeMap: { [key: number]: factiongamethemeconfigRow } = {};
    protected _udgBoxMap: { [key: number]: factionboxconfigRow } = {};
    protected _medalMap: { [key: number]: medalconfigRow } = {};
    protected _medalTechMap: { [key: number]: medaltechconfigRow } = {};
    protected _medalTechInfoMap: { [key: number]: medaltechinfoconfigRow } = {};
    protected _battlePowerHero: number[] = [];
    protected _battlePowerEquip: number[] = [];
    protected _activeList: number[] = [];

    protected _isInited: boolean = false;

    init() {
        if (this._isInited) return;
        this._isInited = true;

        for (let item of heroConfig) {
            this._heroMap[item.Id] = item;
        }
        for (let item of equipConfig) {
            this._equipMap[item.Id] = item;
        }
        for (let item of goodsConfig) {
            this._goodsMap[item.parameterid] = item;
            if (typeof item.canCompose == "number") {
                this._heroPieceMap[item.canCompose] = item;
            }
        }
        for (let item of skillConfig) {
            this._skillMap[item.Id] = item;
        }
        for (let item of artifactConfig) {
            this._artifactMap[item.Id] = item;
        }
        for (let item of Stageconfig) {
            this._stageMap[item.ID] = item;
        }
        for (let item of Monsterconfig) {
            this._monsterMap[item.MonsterID] = item;
        }
        for (let item of xsConfig) {
            this._xsMap[item.Id] = item;
        }
        for (let item of xsLvConfig) {
            this._xsLvMap[item.Id] = item;
        }
        for (let item of Dailytaskconfig) {
            this._dailyTaskMap[item.ID] = item;
        }
        for (let item of Taskconfig) {
            this._mainTaskMap[item.taskID] = item;
        }
        for (let item of Tasktypeconfig) {
            this._taskMap[item.ID] = item;
        }
        for (let item of ActiveRewardconfig) {
            this._taskActiveRewardMap[item.ID] = item;
        }
        for (let item of skybuildconfig) {
            this._towerMap[item.ID] = item;
        }
        for (let item of ServerErrorCodeConfig) {
            this._errorCodes[item.errorcode] = item;
        }
        for (let item of effectViewConfig) {
            let key = `${item.BuffName}_${item.HeroId}`
            this._buffEffectViewMap[key] = item;
            this._effectViewMap[item.Id] = item;
        }
        for (let item of growUpConfig) {
            this._growupMap[item.Id] = item;
        }
        for (let item of storeConfig) {
            this._storeMap[item.Id] = item;
        }
        for (let item of giftConfig) {
            this._giftMap[item.Id] = item;
        }

        let activeGiftId = 1;
        let wisdomGiftId = 1;
        for (let item of kaoshangConfig) {
            this._kaoshangMap[item.Id] = item;
            if (item.type == 1) {
                this._activeGiftMap[activeGiftId] = item;
                activeGiftId++;
            }
            else {
                this._wisdomGiftMap[wisdomGiftId] = item;
                wisdomGiftId++;
            }
        }
        for (let item of timeGiftConfig) {
            this._timeGiftMap[item.Id] = item;
        }
        for (let item of videoconfig) {
            this._videoCfgMap[item.ID] = item;
        }
        for (let item of guidetaskconfig) {
            this._guideCfgMap[item.ID] = item;
        }
        for (let item of circleconfig) {
            this._circleCfgMap[item.ID] = item;
        }
        for (let item of circlerankconfig) {
            this._circleRankCfgMap[item.ID] = item;
        }
        for (let item of boardconfig) {
            this._boardCfgMap[item.Key] = item;
        }
        for (let item of boardtaskconfig) {
            this._boardTaskCfgMap[item.ID] = item;
        }
        for (let item of spacetimeconfig) {
            this._spaceTimeCfgMap[item.ID] = item;
        }
        for (let item of dungeonconfig) {
            this._dungeonCfgMap[item.levelID] = item;
            this._dungeonIdCfgMap[item.ID] = item;
        }
        for (let item of mazefruitconfig) {
            this._fruitCfgMap[item.ID] = item;
        }
        for (let item of surprisegiftconfig) {
            this._surpriseGiftCfgMap[item.ID] = item;
        }
        for (let item of statuefreewalletconfig) {
            this._redTaskCfgMap[item.ID] = item;
        }
        for (let item of xunbaorewardconfig) {
            this._xunbaoCfgMap[item.ID] = item;
        }
        for (let item of geniusConfig) {
            this._geniusCfgMap[item.ID] = item;
        }
        for (let item of wheelprizepool) {
            this._zhuanpanCfgMap[item.Id] = item;
        }
        for (let item of storyconfig) {
            let cfgMap = this._storyCfgMap[item.stage];
            if (!cfgMap) {
                cfgMap = {}
                this._storyCfgMap[item.stage] = cfgMap;
            }
            let cfgs = cfgMap[item.where];
            if (!cfgs) {
                cfgs = [];
                cfgMap[item.where] = cfgs;
            }
            cfgs.push(item as any);
        }
        for (let item of artifactlevelConfig) {
            let configs = this._artifactLevelCfgMap[item.Level];
            if (!configs) {
                configs = [];
                this._artifactLevelCfgMap[item.Level] = configs;
            }
            configs.push(item);
        }
        for (let item of artifactunlockConfig) {
            let configs = this._artifactUnlockCfgMap[item.order];
            if (!configs) {
                configs = [];
                this._artifactUnlockCfgMap[item.order] = configs;
            }
            configs.push(item);
        }
        for (let item of Tasktypeconfig) {
            this._taskTypeCfgMap[item.tasktypeID] = item;
        }
        for (let item of niudanheroconfig) {
            this._niudanHeroCfgMap[item.ID] = item;
        }
        for (let item of skipconfig) {
            this._skipCfgMap[item.skipID] = item;
        }
        for (let item of sevenDaysNewConfig) {
            this._sevenTaskNewCfgMap[item.Id] = item;
        }
        for (let item of HeroCompoundConfig) {
            this._heroCompoundCfgMap[item.CompoundHero] = item;
        }
        for (let item of skillspecialconfig) {
            this._heroSkillConfigMap[item.SkillID] = item;
        }
        for (let item of heroRankConfig) {
            if (Object.keys(this._heroRankLevelMap).indexOf(item.Level.toString()) == -1) {
                this._heroRankLevelMap[item.Level] = item;
            }
        }
        for (let item of stoneheroconfig) {
            this._stoneHeroMap[item.goodsID] = item;
        }
        for (let item of arenachallangetimeconfig) {
            this._arenaChallengeRewardMap[item.ID] = item;
        }
        for (let item of arenascorerewardconfig) {
            this._arenaScoreRewardMap[item.ID] = item;
        }
        for (let item of ArenaRankconfig) {
            this._arenaRankMap[item.ID] = item;
            this._arenaRankIdMap[item.rankID] = item;
        }
        for (let item of skinconfig) {
            this._heroSkinMap[item.ID] = item;
        }
        for (let item of jibanconfig) {
            this._jibanMap[item.ID] = item;
        }
        for (let item of propertyConfig) {
            this._propertyMap[item.Id] = item;
        }
        for (let item of equipstarConfig) {
            this._equipStarMap[item.EqSLv] = item;
        }
        for (let item of factiontechconfig) {
            this._techMap[item.ID] = item;
        }
        for (let item of sevenDaysNewConfig) {
            this._7dayNewMap[item.Id] = item;
        }
        for (let item of factiongameconfig) {
            this._udgMap[item.ID] = item;
        }
        for (let item of factiongamescoreconfig) {
            this._udgScoreMap[item.ID] = item;
        }
        for (let item of factiongamethemeconfig) {
            this._udgThemeMap[item.ID] = item;
        }
        for (let item of factionboxconfig) {
            this._udgBoxMap[item.ID] = item;
        }
        for (let item of medalconfig) {
            this._medalMap[item.ID] = item;
        }
        for (let item of medaltechconfig) {
            this._medalTechMap[item.ID] = item;
        }
        for (let item of medaltechinfoconfig) {
            this._medalTechInfoMap[item.ID] = item;
        }

        for (let config of heroLevelConfig) {
            if (typeof config.commonskill == 'number' && config.commonskill > 0) {
                if (!this._commonSkillLevels[config.commonskill]) {
                    this._commonSkillLevels[config.commonskill] = [];
                }
                this._commonSkillLevels[config.commonskill].push(config.Level);
            }
            if (typeof config.epicskill == 'number' && config.epicskill > 0) {
                if (!this._epicsSkillLevels[config.epicskill]) {
                    this._epicsSkillLevels[config.epicskill] = [];
                }
                this._epicsSkillLevels[config.epicskill].push(config.Level);
            }
            if (typeof config.mythskill == 'number' && config.mythskill > 0) {
                if (!this._mythSkillLevels[config.mythskill]) {
                    this._mythSkillLevels[config.mythskill] = [];
                }
                this._mythSkillLevels[config.mythskill].push(config.Level);
            }
        }
        for (let config of ActiveListconfig) {
            if (this._activeList.indexOf(config.Activeid) == -1) {
                this._activeList.push(config.Activeid);
            }
        }

        this._battlePowerHero = this._splitValue(defaultConfigMap.battlenumberhero.value);
        this._battlePowerEquip = this._splitValue(defaultConfigMap.battlenumberequip.value);
    }

    getCommonSkillLevels(): { [key: number]: number[] } {
        return this._commonSkillLevels;
    }

    getEpicsSkillLevels(): { [key: number]: number[] } {
        return this._epicsSkillLevels;
    }

    getMythSkillLevels(): { [key: number]: number[] } {
        return this._mythSkillLevels;
    }

    getHeroConfig(configId: number) {
        return this._heroMap[configId];
    }

    getEquipConfig(configId: number) {
        return this._equipMap[configId];
    }

    getGoodConfig(configId: number) {
        return this._goodsMap[configId];
    }

    getSkillConfig(configId: number) {
        return this._skillMap[configId];
    }

    getArtifactConfig(configId: number) {
        return this._artifactMap[configId];
    }

    getStageConfig(configId: number) {
        return this._stageMap[configId];
    }

    getMonsterConfig(configId: number) {
        return this._monsterMap[configId];
    }

    getXsConfig(configId: number) {
        return this._xsMap[configId];
    }

    getXsLvConfig(configId: number) {
        return this._xsLvMap[configId];
    }

    getDailyTaskConfig(configId: number) {
        return this._dailyTaskMap[configId];
    }

    getMainTaskConfig(configId: number) {
        return this._mainTaskMap[configId];
    }

    getTaskConfig(configId: number) {
        return this._taskMap[configId];
    }

    getTaskConfigByType(type: number) {
        let cfg: TasktypeconfigRow;
        Object.keys(this._taskMap).forEach((v, i, a) => {
            let id: number = parseInt(v);
            if (this._taskMap[id].tasktypeID == type) {
                cfg = this._taskMap[id];
            }
        });
        return cfg;
    }

    getActiveRewardConfig(id: number) {
        return this._taskActiveRewardMap[id];
    }

    getTowerConfig(id: number) {
        return this._towerMap[id];
    }

    getGrowupConfig(id: number) {
        return this._growupMap[id];
    }

    getStoreConfig(id: number) {
        return this._storeMap[id];
    }

    getGiftConfig(id: number) {
        return this._giftMap[id];
    }

    getKaoshangConfig(id: number) {
        return this._kaoshangMap[id];
    }

    getActiveGiftConfig(id: number) {
        return this._activeGiftMap[id];
    }

    getWisdomGiftConfig(id: number) {
        return this._wisdomGiftMap[id];
    }

    getTimeGiftConfig(id: number) {
        return this._timeGiftMap[id];
    }

    getVideoConfig(id: number) {
        return this._videoCfgMap[id];
    }

    getGuideTaskConfig(id: number) {
        return this._guideCfgMap[id];
    }

    getCircleConfig(id: number) {
        return this._circleCfgMap[id];
    }

    getCircleRankConfig(id: number) {
        return this._circleRankCfgMap[id];
    }

    getChessConfig(id: number) {
        return this._boardCfgMap[id];
    }

    getDiceTaskConfig(id: number) {
        return this._boardTaskCfgMap[id];
    }

    getSurpriseGiftConfig(id: number) {
        return this._surpriseGiftCfgMap[id];
    }

    getRedTaskConfig(id: number) {
        return this._redTaskCfgMap[id];
    }

    getErrorMsg(errorCode: string): ServerErrorCodeConfigRow {
        return this._errorCodes[errorCode];
    }

    getBuffEffectView(buffName: string, heroId: string): effectViewConfigRow {
        return this._buffEffectViewMap[`${buffName}_${heroId}`] || this._buffEffectViewMap[`${buffName}_`]
    }

    getEffectView(id: number): effectViewConfigRow {
        return this._effectViewMap[id];
    }

    getSpacetimeConfig(id: number) {
        return this._spaceTimeCfgMap[id];
    }

    getDungeonConfig(id: number) {
        return this._dungeonCfgMap[id];
    }

    getDungeonIdConfig(id: number) {
        return this._dungeonIdCfgMap[id];
    }

    getFruitConfig(id: number) {
        return this._fruitCfgMap[id];
    }
    getXunbaoConfig(id: number) {
        return this._xunbaoCfgMap[id];
    }

    getGeniusConfig(id: number) {
        return this._geniusCfgMap[id];
    }

    getZhuanPanConfig(id: number) {
        return this._zhuanpanCfgMap[id];
    }

    getStoryConfig(stageId: number, where: number) {
        let cfgMap = this._storyCfgMap[stageId];
        if (cfgMap) {
            let configs = cfgMap[where];
            if (configs) {
                return configs;
            }
        }
        return [];
    }

    getArtifactLevelConfigs(level: number) {
        return this._artifactLevelCfgMap[level] || [];
    }

    getArtifactUnlockConfigs(order: number) {
        return this._artifactUnlockCfgMap[order] || [];
    }

    getTaskTypeConfig(taskTypeId: number) {
        return this._taskTypeCfgMap[taskTypeId];
    }

    getNiudanHeroConfig(id: number) {
        return this._niudanHeroCfgMap[id];
    }

    getSkipConfig(skipId: number) {
        return this._skipCfgMap[skipId];
    }

    getSevenTaskNewConfig(id: number) {
        return this._sevenTaskNewCfgMap[id];
    }

    getHeroCompoundConfig(heroId: number) {
        return this._heroCompoundCfgMap[heroId];
    }

    getHeroSkillConfig(id: number) {
        return this._heroSkillConfigMap[id];
    }

    getHeroRankLevelConfig(level: number) {
        return this._heroRankLevelMap[level];
    }

    getStoneHeroConfig(goodID: number) {
        return this._stoneHeroMap[goodID];
    }

    getArenaChallengeRewardConfig(taskId: number) {
        return this._arenaChallengeRewardMap[taskId];
    }

    getArenaScoreRewardConfig(taskId: number) {
        return this._arenaScoreRewardMap[taskId];
    }

    getHeroPiece(heroId: number) {
        return this._heroPieceMap[heroId];
    }

    getArenaRankConfig(id: number) {
        return this._arenaRankMap[id];
    }

    getArenaRankIdConfig(rankId: number) {
        return this._arenaRankIdMap[rankId];
    }

    getHeroSkinConfig(id: number) {
        return this._heroSkinMap[id];
    }

    getJibanConfig(id: number) {
        return this._jibanMap[id];
    }

    getPropertyConfig(id: number) {
        return this._propertyMap[id];
    }
    getEquipStarConfig(lv: number) {
        return this._equipStarMap[lv];
    }
    getTechConfig(techId: number) {
        return this._techMap[techId];
    }

    get7DayNewConfig(id: number) {
        return this._7dayNewMap[id];
    }

    getUdgConfig(id: number) {
        return this._udgMap[id];
    }

    getUdgThemeConfig(id: number) {
        return this._udgThemeMap[id];
    }

    getUdgScoreConfig(id: number) {
        return this._udgScoreMap[id];
    }

    getUdgBoxConfig(id: number) {
        return this._udgBoxMap[id];
    }

    getMedalConfig(id: number) {
        return this._medalMap[id];
    }

    getMedalTechConfig(id: number) {
        return this._medalTechMap[id];
    }

    getMedalTechInfoConfig(id: number) {
        return this._medalTechInfoMap[id];
    }

    protected _splitValue(value: string, separator?: string) {
        let values = [];
        let datas = value.split(separator ? separator : ";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get gacha100Reward() {
        let values = JSON.parse(defaultConfigMap.gacha100Reward.value)
        return values;
    }

    get heroRankLimit() {
        let values = [];
        let datas = defaultConfigMap.heroRankLimit.value.split(";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get changejoinlevel() {
        let values = [];
        let datas = defaultConfigMap.changejoinlevel.value.split(";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get heroboxbuyspend() {
        let values = [];
        let datas = defaultConfigMap.heroboxbuyspend.value.split(";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get goldshow() {
        let values = [];
        let datas = defaultConfigMap.goldshow.value.split(";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get goldshoweffect() {
        let values = [];
        let datas = defaultConfigMap.goldshoweffect.value.split(";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get defaultAvatars() {
        let values = [];
        let datas = defaultConfigMap.heroinitialicon.value.split(";");
        for (let data of datas) {
            values.push(data);
        }
        return values;
    }

    get defaultJoinLevels() {
        let values = [];
        let datas = defaultConfigMap.changejoinlevel.value.split(";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get defaultWorldBossCosts() {
        let values = [];
        let datas = defaultConfigMap.worldbossspend.value.split(";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get defaultFlowerUnlockDiamond(): number[] {
        let values = [];
        let datas = defaultConfigMap.flowerunlockbuy.value.split(";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get defaultHuntBoss(): number[] {
        let values = [];
        let datas = defaultConfigMap.huntboss.value.split(";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get dungeonRefreshCost(): number[] {
        let values = [];
        let datas = defaultConfigMap.dungeonhero.value.split(";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get heroConversationTime(): number[] {
        let values = [];
        let datas = defaultConfigMap.heroconversationtime.value.split(";");
        for (let data of datas) {
            values.push(Number(data));
        }
        return values;
    }

    get srHeroStarLimit(): number {
        return Number(defaultConfigMap.Srherostarlimit.value);
    }

    get battlePowerHero(): number[] {
        return this._battlePowerHero;
    }

    get battlePowerEquip(): number[] {
        return this._battlePowerEquip;
    }

    get cloneResetCost(): number[] {
        return this._splitValue(defaultConfigMap.cloneresetcost.value);
    }

    get tilibuyprice(): number[] {
        return this._splitValue(defaultConfigMap.tilibuyprice.value);
    }

    get supplyresetprice(): number[] {
        return this._splitValue(defaultConfigMap.supplyresetprice.value);
    }

    get activeList(): number[] {
        return this._activeList;
    }

    get searchtimebuy(): number[] {
        return this._splitValue(defaultConfigMap.searchtimebuy.value);
    }

    get bajiaociBuyPrice(): number[] {
        return this._splitValue(defaultConfigMap.bajiaocibuyprice.value);
    }

    get dujianmuBuyPrice(): number[] {
        return this._splitValue(defaultConfigMap.dujianmubuyprice.value);
    }

    get unionTiliBuyPrice(): number[] {
        return this._splitValue(defaultConfigMap.factionenergybuyprice.value);
    }

    get wisdomTreeStonereward(): number[] {
        return this._splitValue(defaultConfigMap.wisdomTreeStonereward.value);
    }
}

let cm = new ConfigManager();
export default cm;