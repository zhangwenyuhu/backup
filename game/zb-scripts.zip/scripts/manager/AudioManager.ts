import { Storage } from './../utils/DefineUtils';
import storageUtils from "../utils/StorageUtils";
import loadUtils from '../utils/LoadUtils';

type AudioInfo = {
    audioId: number,
    timestamp: number
}

/**
 * 音乐音效代理
 */
class AudioManager {
    protected _musicId: number = NaN;
    protected _effects: { [key: string]: AudioInfo } = {};
    protected _musicVolume: number = 1.0;
    protected _effectVolume: number = 1.0;

    init() {
        this._musicVolume = storageUtils.getNumber(Storage.Music, false);
        this._effectVolume = storageUtils.getNumber(Storage.Sound, false);
        cc.audioEngine.setMusicVolume(this._musicVolume);
        cc.audioEngine.setEffectsVolume(this._effectVolume);

        gcc.MusicHelper.playEffect = (clip: cc.AudioClip, loop: boolean) => {
            am.playEffect(clip, loop);
            return 0;
        }
    }

    uncacheAll() {
        cc.audioEngine.uncacheAll();
        this._effects = {};
    }

    get musicVolume(): number {
        return this._musicVolume;
    }

    set musicVolume(volume: number) {
        if (this._musicVolume != volume) {
            this._musicVolume = volume;
            storageUtils.setNumber(Storage.Music.Key, this._musicVolume, false, false);
        }
        cc.audioEngine.setMusicVolume(this._musicVolume);
    }

    get effectVolume(): number {
        return this._effectVolume;
    }

    set effectVolume(volume: number) {
        if (this._effectVolume != volume) {
            this._effectVolume = volume;
            storageUtils.setNumber(Storage.Sound.Key, this._effectVolume, false, false);
        }
        cc.audioEngine.setEffectsVolume(this._effectVolume);
    }

    async playEffect(name: cc.AudioClip | string, loop: boolean = false) {
        let clip: cc.AudioClip = null;
        if (typeof name == "string") {
            let url = `sounds/${name}`;
            clip = cc.loader.getRes(url, cc.AudioClip);
            if (!clip) { clip = await loadUtils.loadRes(url, cc.AudioClip) as cc.AudioClip; }
        }
        else if (name instanceof cc.AudioClip) {
            clip = name;
        }

        let info = this._effects[clip.name];
        let timestamp = new Date().getTime();
        if (info && timestamp - info.timestamp <= 200) {
            return;
        }
        let audioId = cc.audioEngine.playEffect(clip, loop);
        this._effects[clip.name] = { audioId: audioId, timestamp: timestamp };
    }

    stopEffect(name: string) {
        let effect = this._effects[name];
        if (effect) {
            cc.audioEngine.stopEffect(effect.audioId);
            delete this._effects[name];
        }
    }

    async preloadEffect(name: string) {
        let url = `sounds/${name}`;
        let clip = cc.loader.getRes(url, cc.AudioClip) as cc.AudioClip;
        if (!clip) { clip = await loadUtils.loadRes(url, cc.AudioClip) as cc.AudioClip; }
        if (CC_JSB) { (cc.audioEngine as any)._preload(clip.nativeUrl); }
    }

    async playMusic(name: cc.AudioClip | string) {
        let clip: cc.AudioClip = null;
        if (typeof name == "string") {
            clip = await loadUtils.loadRes(`sounds/${name}`, cc.AudioClip) as cc.AudioClip;
        }
        else if (name instanceof cc.AudioClip) {
            clip = name;
        }

        this.stopMusic();
        this._musicId = cc.audioEngine.playMusic(clip, true);
    }

    stopMusic() {
        if (!isNaN(this._musicId)) {
            cc.audioEngine.stopMusic();
            this._musicId = NaN;
        }
    }
}

let am = new AudioManager();
window['am'] = am;
export default am;