import { PromptSupplyBtn } from './../data/prompt/supply/PromptSupplyBtn';
import { PromptFieldBtn } from './../data/prompt/PromptFieldBtn';
import { PromptHomeBtn } from './../data/prompt/PromptHomeBtn';
import { PromptHangupBtn } from './../data/prompt/hangup/PromptHangupBtn';
import { PromptModal, PromptType } from "../data/prompt/PromptModal";
import { PromptHeroBtn } from "../data/prompt/hero/PromptHeroBtn";
import { PromptLeftMenuBtn } from '../data/prompt/leftmenu/PromptLeftMenuBtn';
import { PromptGiftBtn } from '../data/prompt/leftmenu/PromptGiftBtn';

/**
 * 红点管理
 */
class PromptManager {
    protected _prompts: { [key: number]: PromptModal } = {};

    init() {
        this._prompts[PromptType.HeroBtn] = new PromptHeroBtn(null);
        this._prompts[PromptType.HangupBtn] = new PromptHangupBtn(null);
        this._prompts[PromptType.HomeBtn] = new PromptHomeBtn(null);
        this._prompts[PromptType.LeftMenuBtn] = new PromptLeftMenuBtn(null);
        this._prompts[PromptType.FieldBtn] = new PromptFieldBtn(null);
        this._prompts[PromptType.GiftBtn] = new PromptGiftBtn(null);
        this._prompts[PromptType.SupplyBtn] = new PromptSupplyBtn(null);
    }

    /**
     * 获取红点模型
     * @param type 红点类型
     * @param datas 附加数据
     */
    getPrompt(type: PromptType, datas: any[]): PromptModal {
        let totalStr = type.toString();
        let typeStr = totalStr.substring(0, 4);
        let endStr = totalStr.substring(4);
        let prompt: PromptModal = this._findPrompt(typeStr, datas);
        if (prompt && endStr.length > 0) {
            prompt = this._findPromptWithEndStr(endStr, prompt, typeStr, datas);
        }
        return prompt;
    }

    protected _findPromptWithEndStr(endStr: string, p: PromptModal, preType: string, datas: any[]): PromptModal {
        let prompt: PromptModal = p;
        preType = preType ? preType : "";
        for (let i = 0; i < endStr.length; i++) {
            let num = endStr.substr(0, i + 1);
            let isMatch: boolean = false;
            for (let child of prompt.children) {
                if (child.type.toString() == preType + num.toString()) {
                    if (child.isMatch(datas)) {
                        prompt = child;
                        isMatch = true;
                        break;
                    }
                }
            }
            if (!isMatch) return null;
        }
        return prompt;
    }

    protected _findPrompt(typeStr: string, datas: any[], p?: PromptModal, preType?: string): PromptModal {
        let prompt: PromptModal = p;
        preType = preType ? preType : "";
        for (let i = 0; i < typeStr.length; i++) {
            let num = Number(typeStr.substr(0, i + 1));
            if (num % 10 != 0) {
                num *= Math.pow(10, typeStr.length - i - 1);
                if (prompt) {
                    let isMatch: boolean = false;
                    for (let child of prompt.children) {
                        if (child.type.toString() == preType + num.toString()) {
                            if (child.isMatch(datas)) {
                                prompt = child;
                                isMatch = true;
                                break;
                            }
                        }
                    }
                    if (!isMatch) return null;
                }
                else {
                    prompt = this._prompts[num];
                }
            }
            else {
                break;
            }
        }
        return prompt;
    }
}

let pm = new PromptManager();
export default pm;