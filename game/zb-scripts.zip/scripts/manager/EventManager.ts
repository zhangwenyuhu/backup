export let EName = {
    onPushView: "on push view",
    onPopView: "on pop view",
    onReplaceView: "on replace view",
    onNetworkError: "on network error",
    onGotoView: "on goto view",
    onGotoModule: "on goto module",

    onShow: "on show",
    onHide: "on hide",
    onClosePanel: "on close panel",
    onClosePanels: "on close panels",
    onTouch: "on touch",

    onDataDirty: "on data dirty",
    onUpdateEquip: "on update equip",
    onArtifactEquiped: "on artifact equiped",
    onUpdateBag: "on update bag",
    onChooseTopic: "on choose topic",
    onDeleteTopic: "on delete topic",
    onRefreshTopic: "on refresh topic",
    onPrivateMsg: "on private msg",
    onOpenPrivate: "on open private",
    onUpdateRank: "on update rank",
    onRewardFly: "on reward fly",
    onUpdateHunt: "on update hunt",
    onHuntChest: "on hunt chest",
    onChestGet: "on chest get",
    onGoldDrop: "on gold drop",
    onUpdatePurity: "on update purity",
    onBattleChallenge: "on battle challenge",
    onReChallenge: "on rechallenge",
    onUpdateSurpriseShop: "on update surprise shop",
    onChatHistory: "on chat history",
    onReportFail: "on report fail",
    onReportClose: "on report close",

    onUpdatePioneer: "on update pioneer",
    onPioneerGetWater: "on pioneer get water",
    onPioneerAdvGet: "on pioneer adv get",

    onUpdateDailyLight: "on update daily light",
    onUpdateDailyTab: "on update daily tab",

    onActivityNewProgress: "on activity new progress",
    onUpdateMaterial: "on update material",
    onUpdateRecycle: "on update recycle",

    onWisdomComplete: "on wisdom complete",
    onWisdomFruitChoose: "on wisdom fruit choose",
    onWisdomLayerReward: "on wisdom layer reward",
    onWisdomNextLayer: "on wisdom next layer",
    onWisdomModifyStage: "on wisdom modify stage",
    onWisdomAddFruit: "on wisdom add fruit",
    onWisdomSetFruitValue: "on wisdom set fruit value",
    onWisdomReset: "on wisdom reset",
    onWisdomSaveHero: "on wisdom save hero",
    onWisdomShopBuy: "on wisdom shop buy",
    onWisdomFruitGet: "on wisdom fruit get",
    onWisdomPlayerJump: "on wisdom player jump",
    onWisdomReviveHero: "on wisdom revive hero",
    onWisdomModifyCloud: "on wisdom modify cloud",

    onWonderFocusPlayer: "on wonder focus player",

    onArenaRefresh: "on arena refresh",
    onArenaDefenseChange: "on arena defense edit",
    onArenaDefenseReplace: "on arena defense replace",
    onArenaDefenseRefresh: "on arena defense refresh",
    onArenaUpdateRank: "on arena update rank",

    onUpdateTaskActivity: "on update task activity",
    onUpdateOnline: "on update online",
    onUpdateOnlineGuide: "on update online guide",
    onUpdateCloneList: "on update clone list",

    onHeroWearSkin: "on hero wear skin",
    onArtifactForge: "on artifact forge",
    onArtifactReforge: "on artifact reforge",

    onUpdateHeroSchool: "on update hero school",
    onUpdateArtifact: "on update artifact",
    onArtifactLevelUp: "on artifact level up",
    onChangeToArtifact: "on change to artifact",
    onExchangeChooseCard: "on exchange choose card",
    onExchangeRefreshBtn: "on exchange refresh btn",
    onExchangeHeroSucc: "on exchange hero succ",
    onBBXLottery: "on bbx lottery",

    onUpdateFightHero: "on update fight hero",
    onUpdateTroopHero: "on update troop hero",
    onUpdateTroopCard: "on update troop card",
    onUpdateTroops: "on update troops",
    onFightStationSelected: "on fight station selected",
    onFightStationMoved: "on fight station moved",
    onFightStationChanged: "on fight station changed",
    onFightStationClick: "on fight station click",
    onUseHeroSkill: "on use hero skill",
    onClickHeroSkill: "on click hero skill",
    onHeroDead: "on hero dead",
    onHeroRevive: "on hero revive",
    onHeroReset: "on hero reset",
    onHeroKill: "on hero kill",
    onSelfTroopDead: "on self troop dead",
    onEnemyTroopDead: "on enemy troop dead",
    onNextChapter: "on next chapter",
    onNextCountry: "on next country",
    onNextBuilding: "on next building",
    onEnterUnion: "on enter union",
    onHangupDirty: "on hangup dirty",
    onRefreshHeroList: "on refresh hero list",
    onEnterHeroCloseUp: "on enter hero close up",
    onLeaveHeroCloseUp: "on leave hero close up",
    onHighlight: "on highlight",
    onShakeScreen: "on shake screen",
    onHeroCallback: "on hero callback",

    onBeforeAddHeroes: "on before add heroes",
    onAddHeroes: "on add heroes",
    onAddHero: "on add hero",
    onRemoveHero: "on remove hero",
    onBeforeEvoluteHeroes: "on before evolute heroes",
    onEvoluteHeroes: "on evolute heroes",
    onStarHeroes: "on star heroes",
    onMergeHeroes: "on merge heroes",
    onStartMerge: "on start merge",
    PromptRefresh: "prompt refresh",

    onGameTimeout: "on game timeout",
    onTryGamePause: "on try game pause",
    onGamePause: "on game pause",
    onGameResume: "on game resume",
    onGameResult: "on game result",
    onGameRestart: "on game restart",
    onGameSkillAuto: "on game skill auto",
    onGameSpeedX2: "on game speed x2",
    onGameOver: "on game over",
    onGameSkip: "on game skip",
    onFreshPanel: "on fresh panel",
    onFreshRed: "on fresh red",
    onRedDirty: "on red dirty",
    onLevelUp: "on level up",
    onApplyOrder: "on apply order",
    onStartGuideStep: "on start guide step",
    onFinishGuideStep: "on finish guide step",
    onUpdateGuideStep: "on update guide step",
    onGuideFinished: "on guide finished",
    onStartingGuideStep: "on starting guide step",
    onFinishingGuideStep: "on finishing guide step",
    onActivityBtnFresh: "on activity btn fresh",
    onMissionPass: "on mission pass",
    onUseVideoLottery: "on use video lottery",
    onSortedHeroes: "on sorted heroes",
    onSelectLotteryType: "on select lottery type",
    onFreshGuideTask: "on fresh guide task",
    onUpdateActivityDatas: "on update activitydatas",
    onWorldBossChallengeFinish: "on world boss challenge finish",
    onHideTips: "on hide tips",
    onShowUnlockGuide: "on show unlock guide",
    onHideUnlockGuide: "on hide unlock guide",
    onGeniusInfoDirty: "on genius info dirty",
    onGeniusPointsDirty: "on genius points dirty",
    onVipLevelUp: "on vip level up",
    onCostDiamond: "on cost diamond",
    onRecharge: "on recharge",
    onWipeTower: "on wipe tower",
    onUpdateZhuanPan: "on update zhuanpan",
    onComingNewDay: "on coming new day",
    onMedalLevelUp: "on medal level up",

    onClearGuideObstruct: "on clear guide obstruct",

    onEnablePanel: "on enable panel",
    onDisablePanel: "on disable panel",
    onReloadView: "on reload view",

    onGameExit: "退出游戏",
    onShowPanel: "显示面板",
    onHidePanel: "隐藏面板",
}

export class EListener {
    /**
     * 事件名称
     */
    name: string

    /**
     * 事件回调，返回false表示事件中断
     */
    func: (data: any, connection: EConnection) => void

    /**
     * 只监听一次
     */
    once: boolean

    /**
     * 优先级
     */
    prority: number

    /**
     * 是否有效
     */
    enable: boolean
}

/**
 * 各监听者之间的传递者
 */
export class EConnection {
    listener: EListener;
    stop: boolean = false;
}

/**
 * 事件分发器   
 */
export default class EManager {
    protected static _allEvtListeners: { [key: string]: EListener[] } = {}

    /**
     * 添加事件监听者
     * @param key 事件名称
     * @param func 事件回调     
     */
    public static addEvent(key: string, func: (data: any, connection: EConnection) => void, once?: boolean, prority?: number): EListener {
        let listener = new EListener()
        listener.name = key
        listener.func = func
        listener.once = once
        listener.prority = prority ? prority : 0;
        listener.enable = true;

        if (this._allEvtListeners[key] == null) {
            this._allEvtListeners[key] = []
        }
        let listeners = this._allEvtListeners[key];
        listeners.push(listener);
        listeners.sort((a: EListener, b: EListener) => {
            return a.prority - b.prority
        });

        return listener
    }

    /**
     * 批量添加事件监听者
     * @param keys 事件名称
     * @param func 事件回调     
     */
    public static addEventArray(keys: string[], func: (data: any, connection: EConnection) => void, once?: boolean, prority?: number): EListener[] {
        let listeners = [];
        for (let key of keys) {
            let listener = this.addEvent(key, func, once, prority)
            listeners.push(listener);
        }

        return listeners;
    }

    /**
     * 删除事件监听者
     * @param listener 事件监听者
     */
    public static removeEvent(listener: EListener) {
        let listeners = this._allEvtListeners[listener.name]
        if (listeners instanceof Array) {
            let index = listeners.indexOf(listener)
            if (index >= 0) {
                listener.enable = false;
                listeners.splice(index, 1)
                if (listeners.length == 0) {
                    delete this._allEvtListeners[listener.name]
                }
            }
        }
    }

    /**
     * 
     * @param key 事件名称
     * @param data 附带的数据
     */
    public static emit(key: string, data?: any) {
        let listeners = this._allEvtListeners[key]
        if (listeners instanceof Array) {
            let connection = new EConnection();
            let tempListeners = listeners.slice(0)
            for (let listener of tempListeners) {
                if (listener.enable) {
                    connection.listener = listener;
                    listener.func(data, connection)
                    if (listener.once) {
                        this.removeEvent(listener)
                    }
                    if (connection.stop) {
                        break;
                    }
                }
            }
        }
    }
}