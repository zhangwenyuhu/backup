import PushModal, { PushType } from "../data/push/PushModal";
import PushOfflineTime from "../data/push/PushOfflineTime";
import PushOfflineBenefit from "../data/push/PushOfflineBenefit";
import PushTaskUnRecv from "../data/push/PushTaskUnRecv";
import PushWisdomTreeEnd from "../data/push/PushWisdomTreeEnd";

/**
 * 推送管理
 */
class PushManager {

    protected _pushs: { [key: number]: PushModal } = {};
    public pushEnabled: boolean = true;
    public pushDebug: boolean = false;

    async init() {
        this._pushs[PushType.OFFLINE_TIME] = new PushOfflineTime();
        this._pushs[PushType.OFFLINE_BENEFIT] = new PushOfflineBenefit();
        this._pushs[PushType.TASK_UNRECV] = new PushTaskUnRecv();
        this._pushs[PushType.WISDOMTREE_END] = new PushWisdomTreeEnd();
        this.pushDebug = localStorage.getItem("pushDebug") && localStorage.getItem("pushDebug") == "1";
        if (!CC_PREVIEW) {
            let { enabled } = await gdk.isLocalNoticeEnabled();
            this.pushEnabled = enabled;
        }
    }

    getPushModel(pushType: PushType) {
        return this._pushs[pushType];
    }

    updateLocalPushs(pushTypes: PushType[] = [PushType.OFFLINE_TIME, PushType.OFFLINE_BENEFIT, PushType.TASK_UNRECV, PushType.WISDOMTREE_END]) {
        if (CC_PREVIEW) {
            return;
        }
        for (let pushType of pushTypes) {
            if (this._pushs[pushType]) {
                this._pushs[pushType].updateLocalPush();
            }
        }
    }

    async clearLocalPush() {
        if (!CC_PREVIEW && this.pushEnabled) {
            gdk.removeAllLocalNotices();
        }
    }

}

let pushManager = new PushManager();
export default pushManager;