import GameProxy, { HelpHeroVO, ResourceVO, XsConfigBO, XsReq, XsVO } from './../proxy/GameProxy';
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from '../manager/GameManager';
import Task from '../data/xuanshang/task';
import HeroXs from '../data/xuanshang/HeroXs';
import HeroHelp from '../data/xuanshang/HeroHelp';
import Hero from '../data/card/Hero';
import heroLogic from './HeroLogic';
import cm from '../manager/ConfigManager';
import redPointLogic, { RedPointType } from './RedPointLogic';
import activityLogic, { ActivityType } from "./ActivityLogic";
import { Storage, TaskActivityType } from "../utils/DefineUtils";
import { unlockConfigMap } from '../configs/unlockConfig';
import UnlockWrapper from '../view/widget/unlock/UnlockWrapper';
import vipconfig from '../configs/vipconfig';
import commitLogic, { DiamondSource } from './CommitLogic';
import storageUtils from '../utils/StorageUtils';

/* 悬赏 */
export class XuanshangLogic extends BaseLogic {

    protected _dispatchedHeroIds: string[] = [];
    public selectingHelpHeroIds: string = "";
    protected _tasks: { [key: string]: Task } = {};     // 悬赏任务数据
    protected _myHeros: { [key: string]: HeroXs } = {};    // 我的可派遣英雄数据
    protected _helpHeros: HeroHelp[] = [];                // 外援我的英雄数据
    protected _myHelpHeroIds: HelpHeroVO[] = [];              // 我的外援英雄id数据
    protected _conditions: number[] = [];
    protected _resetTimeStamp: number = 0;
    protected _xsLv: number = 0;
    protected _oneKeyVipLevel: number = 0;

    init(gm: IGameManager) {
        super.init(null, gm);

        this.bindRedFunc();
        this.initOneKeyVipLevel();
    }

    protected initOneKeyVipLevel() {
        for (let cfg of vipconfig) {
            if (cfg.gotobattle) {
                this._oneKeyVipLevel = cfg.viplevel;
                break;
            }
        }
    }
    getOneKeyVipLevel(): number { return this._oneKeyVipLevel; }
    resetAll() {
        this.selectingHelpHeroIds = "";
        this._tasks = {};
        this._myHeros = {};
        this._helpHeros = [];
        this._conditions = [];
        this._resetTimeStamp = 0;
        this._xsLv = 0;
    }
    clearHeros() {
        this._myHeros = {};
        this._helpHeros = [];
    }

    // 请求悬赏任务信息
    async xsTaskReq() {
        let xsProto = await gm.request<XsVO>(GameProxy.apixsgetXsDetail);
        this.xsTasksInit(xsProto);
        return xsProto.lvUp;
    }

    async xsQuickComplete(id: string) {
        let proto = await gm.request<XsVO>(GameProxy.apixsquickXs, id);
        this.xsTasksInit(proto);
        return proto.lvUp;
    }

    // 刷新悬赏任务列表
    async xsTaskRefreshReq(bVideo: boolean = false) {
        let xsTasks = await gm.request<XsConfigBO[]>(GameProxy.apixsrefreshXs, bVideo);
        this.xsTasksRefresh(xsTasks);
        activityLogic.doIncTaskActProgress(ActivityType.RewardSeason, TaskActivityType.RefreshXuanShang, null, 1);
    }

    // 请求英雄列表
    async dispatchHerosReq() {
        let heros: string[] = await gm.request<string[]>(GameProxy.apixsgetMyHeros);
        this.myHerosRefresh(heros);
    }

    // 请求外援我的英雄列表
    async helpMeHeroReq() {
        let helpHeros = await gm.request<HelpHeroVO[]>(GameProxy.apiprocessgetHelpMeHeros);
        this._helpHeros = [];
        helpHeros.forEach((v, i, a) => {
            let tmp: HeroHelp = new HeroHelp(v);
            this._helpHeros.push(tmp);
        });
    }

    // 派遣任务
    async dispatchTaskReq(param: XsReq) {
        let proto = await gm.request<XsConfigBO>(GameProxy.apixsstartXs, param);

        if (this._tasks[proto.xsId]) {
            this._tasks[proto.xsId].changeServerData(proto);
            commitLogic.xuanshangGo(this._tasks[proto.xsId].taskCfg.Id);
        }
    }

    // 批量派遣任务
    async autoDispatchTaskReq(param: XsReq[]) {
        if (param.length == 0) { return; }
        let proto = await gm.request<XsVO>(GameProxy.apixsstartXsMul, param);
        this.xsTasksInit(proto);
        commitLogic.xuanshangGo(-1);
    }

    // 领取任务奖励
    async getTaskRewardReq(param: string) {
        let reward = await gm.request<ResourceVO>(GameProxy.apixsgetReward, param);

        this.taskComplete(param);
        let star = this._tasks[param].star;
        delete this._tasks[param];
        // reward
        gm.getReward(reward);
        commitLogic.commitReward(reward, DiamondSource.xuanshang);
        activityLogic.doIncTaskActProgress(ActivityType.RewardSeason, TaskActivityType.CompleteXSTask, star.toString(), 1, true);
    }

    // 批量领取任务奖励
    async autoGetTaskRewardReq(param: string[]) {
        if (param.length == 0) { return; }
        let reward = await gm.request<ResourceVO>(GameProxy.apixsgetRewardMul, param);
        gm.getReward(reward);

        for (let i = 0; i < param.length; i++) {
            this.taskComplete(param[i]);
            delete this._tasks[param[i]];
        }
        commitLogic.commitReward(reward, DiamondSource.xuanshang);
    }

    // 我的外援英雄
    async myHelpHeroReq() {
        let ids: HelpHeroVO[] = await gm.request<HelpHeroVO[]>(GameProxy.apiprocessgetHelpHeros);
        this._myHelpHeroIds = [];
        this._myHelpHeroIds.pushList(ids);
    }

    // 设置外援英雄
    async setMyHelpHeroReq(param: string[]) {
        if (param.length > 6) {
            param = [];
        }
        let ids: string = await gm.request<string>(GameProxy.apiprocesssetHelpHeros, param);

        let sameIds: string[] = param.filter((v, i, a) => {
            let same: boolean = this._myHelpHeroIds.some((value, index, arr) => {
                return value.heroId == v;
            })
            return same;
        })
        this._myHelpHeroIds = this._myHelpHeroIds.filter((v, i, a) => {
            let id: string = v.heroId;
            let same: boolean = param.some((value, index, arr) => {
                return value == id;
            })
            return same;
        });

        let addHelpHeros = param.filter((v, i, a) => {
            let same: boolean = sameIds.some((value, index, arr) => {
                return value == v;
            })
            return !same;
        })

        addHelpHeros.forEach((v, i, a) => {
            let helpHero = new HelpHeroVO;
            helpHero.heroId = v;
            this._myHelpHeroIds.push(helpHero);
        });
    }

    // 悬赏任务完成 是否达到悬赏栏的升级要求 
    private taskComplete(id: string) {
        return;
        if (this._tasks[id]) {
            let xsCfg = cm.getXsLvConfig(this._xsLv);
            let task = this._tasks[id];
            if (task.isPeronalTask) {
                if (task.taskCfg.Rank >= xsCfg.Condition[0]) {
                    this._conditions[0] += 1;
                }
            } else {/*
                if (task.taskCfg.Rank >= xsCfg.Condition2[0]) {
                    this._conditions[1] += 1;
                }*/
            }
        }
    }

    public updateMyHeros() {
        this._myHeros = {};
        let myAllHeros = heroLogic.getHeroes();
        myAllHeros.forEach((v, i, a) => {
            let tmp = new HeroXs(v.getId());
            this._myHeros[tmp.id] = tmp;
        });
    }

    private myHerosRefresh(heros: string[]) {
        this._dispatchedHeroIds = heros;
        this._myHeros = {};
        let myAllHeros = heroLogic.getHeroes();
        myAllHeros.forEach((v, i, a) => {
            let tmp = new HeroXs(v.getId());
            this._myHeros[tmp.id] = tmp;
        });
    }

    private xsTasksRefresh(xsTasks: XsConfigBO[]) {

        Object.keys(this._tasks).forEach((v, i, a) => {
            if (this._tasks[v].isPeronalTask) {
                if (!this._tasks[v].isOpen) {
                    delete this._tasks[v];
                }

            }
        });
        xsTasks.forEach((v, i, a) => {
            let tmp = new Task(v);
            this._tasks[tmp.id] = tmp;
        });
    }

    private xsTasksInit(xsProto: XsVO) {
        this._tasks = {};
        this._conditions = [];

        xsProto.xsConfigBOS.forEach((v, i, a) => {
            let tmp = new Task(v);
            this._tasks[tmp.id] = tmp;
        });
        this._conditions.push(xsProto.condition);
        //this._conditions.push(xsProto.condition2);

        this._resetTimeStamp = xsProto.nextTime;
        this._xsLv = xsProto.xsLv;
    }

    // 判断一个英雄是否已派遣
    public isDispatched(id: string): boolean {
        let canDispatch: boolean = this._dispatchedHeroIds.every((v, i, a) => {
            return v != id;
        })
        return !canDispatch;
    }
    getTasks(): Task[] {
        let tasks: Task[] = [];
        Object.keys(this._tasks).forEach((v, i, a) => {
            tasks.push(this._tasks[v]);
        });

        let result: Task[] = [];
        for (let i = 1; i <= 3; i++) {
            let task_type = tasks.filter((v, index, a) => { return v.taskCfg.type == i; })
            for (let j = 0; j < 3; j++) {
                if (task_type.length > j) {
                    result.push(task_type[j]);
                }
            }
        }
        return result;
    }

    getTaskById(id: string): Task {
        return this._tasks[id];
    }
    getPersonalTask(): Task[] {
        return this.getTasks();
        let tasks: Task[] = [];
        Object.keys(this._tasks).forEach((v, i, a) => {
            if (this._tasks[v].isPeronalTask) {
                tasks.push(this._tasks[v]);
            }
        });
        return tasks;
    }
    getTeamTask(): Task[] {
        let tasks: Task[] = [];
        Object.keys(this._tasks).forEach((v, i, a) => {
            if (!this._tasks[v].isPeronalTask) {
                tasks.push(this._tasks[v]);
            }
        });
        return tasks;
    }
    getXslevel(): number {
        return this._xsLv;
    }
    getXsCondition(): number[] {
        return this._conditions;
    }
    getXsfreshTimestamp(): number {
        return this._resetTimeStamp;
    }
    getAllHelpHeros(onlyRank: boolean = true, sort: boolean = true): HeroXs[] {
        let arr: HeroXs[] = [];
        Object.keys(this._myHeros).forEach((v, i, a) => {
            arr.push(this._myHeros[v]);
        });
        if (sort) {
            arr.sort((a, b) => {
                if (a.isDispatched() == b.isDispatched()) {
                    if (a.lv != b.lv && !onlyRank) {
                        return b.lv - a.lv;
                    } else {
                        if (a.rank != b.rank) {
                            return b.rank - a.rank;
                        } else {
                            return b.getPower() - a.getPower();
                        }
                    }
                } else {
                    return b.isDispatched() ? -1 : 1;
                }
            });
        }

        return arr;
    }
    getMyHeroById(id: string): HeroXs {
        return this._myHeros[id];
    }
    isExitSameIndexInSelectHeros(id: string, index: number) {
        let bExit = Object.keys(this._myHeros).some((v, i, a) => {
            let tmp = this._myHeros[v]
            return tmp.id != id && tmp.select && tmp.cfg.Id == index;
        })
        return bExit;
    }
    getSelectingHero(index: number): HeroXs {
        let hero;
        Object.keys(this._myHeros).forEach((v, i, a) => {
            if (this._myHeros[v].cfg.Id == index && this._myHeros[v].select) {
                hero = this._myHeros[v];
            }
        })
        return hero;
    }
    getAllHeroCount(): number {
        return Object.keys(this._myHeros).length;
    }
    getHeroByTag(index: number): HeroXs[] {
        let arr: HeroXs[] = [];
        Object.keys(this._myHeros).forEach((v, i, a) => {
            if (index == this._myHeros[v].cfg.Faction) {
                arr.push(this._myHeros[v]);
            }
        });
        arr.sort((a, b) => {
            if (a.isDispatched() == b.isDispatched()) {
                if (a.lv != b.lv) {
                    return b.lv - a.lv;
                } else {
                    if (a.rank != b.rank) {
                        return b.rank - a.rank;
                    } else {
                        return b.getPower() - a.getPower();
                    }
                }
            } else {
                return b.isDispatched() ? -1 : 1;
            }
        });
        return arr;
    }
    getHelpMeHeros(): HeroHelp[] {
        return this._helpHeros;
    }
    validHelpMeHeroSelect(id: string, select: boolean) {
        this._helpHeros.forEach((v, i, a) => {
            if (v.id == id) {
                v.select = select;
            }
        });
    }
    getHelpMeHeroById(id: string): HeroHelp {
        for (let i = 0; i < this._helpHeros.length; i++) {
            if (this._helpHeros[i].id == id) {
                return this._helpHeros[i];
            }
        }
        return null;
    }
    getHelpMeHeroByTag(index: number): HeroHelp[] {
        let arr: HeroHelp[] = [];
        this._helpHeros.forEach((v, i, a) => {
            if (index == v.cfg.Faction) {
                arr.push(v);
            }
        });
        return arr;
    }
    getMyHelpHeroIds(): HelpHeroVO[] {
        return this._myHelpHeroIds;
    }

    // 获取未设置外援的英雄列表
    getUserHeros(): Hero[] {
        let tmp: Hero[] = [];
        tmp = heroLogic.getHeroes({
            filter: (hero: Hero) => {
                let fiter: boolean = this._myHelpHeroIds.some((v, i, a) => {
                    return v.heroId === hero.getId();
                });
                return !fiter;
            }
        });
        return tmp;
    }
    getUserHerosCount(): number {
        return heroLogic.getHeroesCount();
    }
    selectingToHelp(id: string): boolean {
        return this.selectingHelpHeroIds == id ? true : false;
    }

    /*  --红点判断函数--   */
    bindRedFunc() {
        redPointLogic.addFunc(RedPointType.Town_XuanShang, null);
        redPointLogic.addFunc(RedPointType.Town_XuanShang_Person, this.xuanshangRed.bind(this));
    }

    isXsUnlock(): boolean {
        let tmp = true;
        let cfg = unlockConfigMap.悬赏大厅;
        tmp = UnlockWrapper.isUnlock(cfg);
        return tmp;
    }

    xuanshangRed(type?: number): boolean {
        let bRed: boolean = false;
        let tasks = this.getPersonalTask();
        if (type) {
            tasks = tasks.filter((v, i, a) => { return v.taskCfg.type == type; })
        }
        for (let i = 0; i < tasks.length; i++) {
            if (tasks[i].isOver && tasks[i].isOpen) {
                // 已开启可领取完成奖励
                bRed = true;
                break;
            }

            if (!tasks[i].isOpen) {
                // 未开启但满足开启条件
                if (tasks[i].canDispatch()) {
                    bRed = true;
                    break;
                }
            }
        }
        let read: boolean = false;
        if (type) {
            read = this.typeRead(type);
        } else {
            read = this.typeRead(2) && this.typeRead(3) && this.typeRead(1);
        }
        return bRed && !read;
    }

    protected typeRead(type: number) {
        if (type == 1) {
            return storageUtils.getBoolean(Storage.XsSenlinRead);
        } else if (type == 2) {
            return storageUtils.getBoolean(Storage.XsFeixuRead);
        } else if (type == 3) {
            return storageUtils.getBoolean(Storage.XsKuangdongRead);
        }
        return false;
    }
    /*  --红点判断函数--   */
}

let xsLogic = new XuanshangLogic();
export default xsLogic;