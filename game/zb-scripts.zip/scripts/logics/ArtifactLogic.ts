import { stringConfigMap } from './../configs/stringConfig';
import BaseLogic from "./BaseLogic";
import IGameManager from "../manager/IGameManager";
import artifactcompoundConfig, { artifactcompoundConfigRow } from "../configs/artifactcompoundConfig";
import bagLogic from "./BagLogic";
import GameProxy, { ArtifactForgeReq, StrengArtifactVO } from "../proxy/GameProxy";
import Artifact from "../data/card/Artifact";
import heroLogic, { ArtifactUnlockInfo } from "./HeroLogic";
import artifactConfig from "../configs/artifactConfig";
import commonUtils from "../utils/CommonUtils";
import Good from "../data/card/Good";
import stringUtils from "../utils/StringUtils";
import ToastError from '../error/ToastError';

class ArtifactLogic extends BaseLogic {

    init(artifactUnlockInfo: ArtifactUnlockInfo, gm: IGameManager) {
        super.init(null, gm);
        for (let artifactCfg of artifactConfig) {
            let compound = this.getArtifactCompound(artifactCfg.Id);
            let artifact = bagLogic.getIndexArtifact(artifactCfg.Id);
            if (compound.compoundLv > 0 && artifact) {
                artifact.updateCompoundAddition(compound);
            }
        }
    }

    getArtifactCompound(artifactId: number) {
        let propertyIds = this.getArtifactCompoundIds(artifactId);
        let compoundLv = 0;
        for (let id of propertyIds) {
            let cfg = artifactcompoundConfig[id - 1];
            if (this._canCompound(cfg)) {
                compoundLv++;
            }
        }
        return { propertyIds: propertyIds, compoundLv: compoundLv };
    }

    getArtifactCompoundIds(artifactId: number) {
        let propertyIds = [];
        for (let cfg of artifactcompoundConfig) {
            if (cfg.artifactID.indexOf(artifactId) != -1) {
                propertyIds.push(cfg.Id);
            }
        }
        return propertyIds;
    }

    /**能否产生共鸣*/
    protected _canCompound(config: artifactcompoundConfigRow) {
        if (config.artifactID.length == 1) {
            let artifact = bagLogic.getArtifacts().find(a => a.getIndex() == config.artifactID[0]);
            if (artifact && artifact.getStar() >= config.artifactLvNeed) {
                return true;
            }
        } else if (config.artifactID.length == 2) {
            let artifact1 = bagLogic.getArtifacts().find(a => a.getIndex() == config.artifactID[0]);
            let artifact2 = bagLogic.getArtifacts().find(a => a.getIndex() == config.artifactID[1]);
            if (artifact1 && artifact2 && artifact1.getStar() >= config.artifactLvNeed && artifact2.getStar() >= config.artifactLvNeed) {
                return true;
            }
        }
        return false;
    }

    /**
     * 能否锻造神器
     * @param artifact 
     * @param lock 
     */
    canForgeArtifact(artifact: Artifact): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        if (!artifact.isForgeable()) {
            return {
                result: false,
                message: "神器锻造等级已达上限"
            }
        }

        let costs = artifact.getForgeCost();
        let consumes: Function[] = [];
        for (let cost of costs) {
            let good = commonUtils.item2Card(cost) as Good;
            if (bagLogic.getGood(good.getIndex()).getAmount() < good.getAmount()) {
                return {
                    result: false,
                    message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
                }
            }
            else {
                consumes.push(() => {
                    bagLogic.changeGoodAmount(good.getIndex(), -good.getAmount());
                });
            }
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**锻造神器*/
    async doForgeArtifact(artifact: Artifact, lock: boolean) {
        let ret = this.canForgeArtifact(artifact);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let req = new ArtifactForgeReq();
        req.artifactId = artifact.getId();
        req.lock = lock;
        let proto = await this._gm.request<StrengArtifactVO>(GameProxy.apiartifactforgeArtifact, req);
        if (proto) {
            for (let consume of ret.consumes) {
                consume();
            }
            artifact.update(proto.artifactInfo);
            if (proto.heroAddInfos) {
                let hero = heroLogic.getHero(proto.heroAddInfos.heroId);
                hero.updateAddition([proto.heroAddInfos]);
            }
        }
    }

    /**锻造转化预览*/
    async doForgeChangePre(artifact: Artifact) {
        let req = new ArtifactForgeReq();
        req.artifactId = artifact.getId();
        let proto = await this._gm.request(GameProxy.apiartifactforgeChangePre, req);
        let cost = artifact.getForgeChangeCost();
        for (let item of cost) {
            if (item) {
                bagLogic.getGood(item[0]).changeAmount(-item[1]);
            }
        }
        return proto;
    }

    /**接受锻造转化*/
    async doForgeChange(artifact: Artifact) {
        let req = new ArtifactForgeReq();
        req.artifactId = artifact.getId();
        let proto = await this._gm.request<StrengArtifactVO>(GameProxy.apiartifactforgeChange, req);
        if (proto) {
            artifact.update(proto.artifactInfo);
            if (proto.heroAddInfos) {
                let hero = heroLogic.getHero(proto.heroAddInfos.heroId);
                hero.updateAddition([proto.heroAddInfos]);
            }
        }
    }

}

let artifactLogic = new ArtifactLogic();
export default artifactLogic;