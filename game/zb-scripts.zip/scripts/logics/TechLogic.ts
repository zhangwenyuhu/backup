import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from "../manager/GameManager";
import TechPropertyData from "../data/tech/TechPropertyData";
import { DutyType } from "../utils/DefineUtils";
import factiontechconfig from "../configs/factiontechconfig";
import GameProxy, { GTechBO, HeroModulBO, ResourceVO } from "../proxy/GameProxy";
import cm from "../manager/ConfigManager";
import heroLogic from "./HeroLogic";
import { defaultConfigMap } from "../configs/defaultConfig";

/* 公会科技研究 */
export class TechLogic extends BaseLogic {

    protected _techInfo: { [key: number]: TechPropertyData[] } = {};
    protected _resetTime: { [key: number]: number } = {};
    protected _techPropertyMaxLv: { [key: number]: number } = {};
    init(gm: IGameManager) {
        super.init(null, gm);

        this._initTech();
    }

    protected _initTech() {
        this._techInfo = {};
        for (let i = 0; i < factiontechconfig.length; i++) {
            let cof = factiontechconfig[i];
            if (!cof.lasttech) {
                if (!this._techInfo[cof.techtype]) { this._techInfo[cof.techtype] = []; }
                let tech = new TechPropertyData(cof.ID);
                this._techInfo[cof.techtype].push(tech);
            }

            if (!this._techPropertyMaxLv[cof.techUid] || this._techPropertyMaxLv[cof.techUid] < cof.level) {
                this._techPropertyMaxLv[cof.techUid] = cof.level;
            }
        }
    }
    protected _resetTech(type: number) {
        this._techInfo[type] = [];
        for (let i = 0; i < factiontechconfig.length; i++) {
            let cof = factiontechconfig[i];
            if (cof.techtype == type && !cof.lasttech) {
                if (!this._techInfo[cof.techtype]) { this._techInfo[cof.techtype] = []; }
                let tech = new TechPropertyData(cof.ID);
                this._techInfo[cof.techtype].push(tech);
            }
        }
    }

    public getTechInfo(type: DutyType): TechPropertyData[] {
        return this._techInfo[type];
    }
    public getTechPropertyMaxLevel(techUid: number) {
        return this._techPropertyMaxLv[techUid];
    }
    public getTechProperty(techId: number): TechPropertyData {
        let cof = cm.getTechConfig(techId);
        let info = this._techInfo[cof.techtype];
        let data = info.find((a) => { return a.getCof().ID == techId; })
        return data;
    }

    // 获取公会科技信息
    public async techPropertyReq() {
        this._initTech();
        let proto = await gm.request<GTechBO>(GameProxy.apiguildgetGTechInfo);
        if (proto) {
            this._updatePropertyData(proto.activeIds);
            this._updateResetTimes(proto.resetMap);
        }
    }

    protected _updateResetTimes(data: object) {
        let keys = Object.keys(data);
        for (let i = 0; i < keys.length; i++) {
            let type = parseInt(keys[i]);
            this._resetTime[type] = data[keys[i]];
        }
    }

    public canFreeReset(type: DutyType) {
        if (!this._resetTime[type] || this._resetTime[type] < 1) { return true; }
        return false;
    }
    protected _addResetTime(type: DutyType) {
        if (!this._resetTime[type]) {
            this._resetTime[type] = 1;
        } else {
            this._resetTime[type] += 1;
        }
    }

    // 升级公会科技
    public async techPropertyLvupReq(techUid: number) {
        let proto = await gm.request<HeroModulBO[]>(GameProxy.apiguildlvUpGTech, techUid);
        heroLogic.updateTechAddition(proto);
    }

    // 重置某个类型的公会科技
    public async techPropertyResetReq(techType: number) {
        let proto = await gm.request<ResourceVO>(GameProxy.apiguildresetGTech, techType);
        gm.getReward(proto);
        this._addResetTime(techType);
        this._resetTech(techType);
        heroLogic.clearTechAddition(techType);
    }

    // 重置消耗钻石
    public getResetTechCostDiamond(): number {
        return defaultConfigMap.factiontechreset.value;
    }

    // 某个类型的科技是否可以重置
    public dutyPropertyCanReset(duty: number) {
        let canReset: boolean = false;
        if (this._techInfo[duty]) {
            canReset = this._techInfo[duty].some((v, i, a) => { return v.getUnlock(); })
        }
        return canReset;
    }

    protected _updatePropertyData(techIds: number[]) {
        for (let i = 0; i < techIds.length; i++) {
            let cof = cm.getTechConfig(techIds[i]);

            let info = this._techInfo[cof.techtype];
            let index = info.findIndex((a) => { return a.getCof().techUid == cof.techUid })
            if (index >= 0) { info[index].updateTechId(cof.ID); }
        }
    }
}

let techLogic = new TechLogic();
export default techLogic;