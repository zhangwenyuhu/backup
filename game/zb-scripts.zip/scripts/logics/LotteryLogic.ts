import { stringConfigMap } from './../configs/stringConfig';
import GameProxy, { GachaReq, GachaVO, GoodUseReq, GoodVO, HeroVO, ResourceVO, GashaponVO, GashaponReq, HeroChangeEnterReq } from './../proxy/GameProxy';
import BaseLogic from "./BaseLogic";
import { WatchProperty } from '../decorator/PropertyDecorator';
import ToastError from '../error/ToastError';
import bagLogic from './BagLogic';
import Good, { GoodId } from '../data/card/Good';
import stringUtils from '../utils/StringUtils';
import Hero from '../data/card/Hero';
import heroLogic from './HeroLogic';
import IGameManager from '../manager/IGameManager';
import playerLogic from './PlayerLogic';
import Card from '../data/card/Card';
import PlayerHero from '../data/card/PlayerHero';
import activityLogic, { ActivityType } from "./ActivityLogic";
import { SevenDayTaskType, Storage, TaskActivityType, WeekType } from "../utils/DefineUtils";
import chatSocket from "../socket/ChatSocket";
import { SystemType } from "../socket/ChatUserData";
import storageUtils from "../utils/StorageUtils";
import EManager, { EName } from "../manager/EventManager";
import gm from '../manager/GameManager';
import { defaultConfigMap } from '../configs/defaultConfig';
import commitLogic, { DiamondSource, DiamondCost, HeroSubSource, HeroSource } from './CommitLogic';
import assignmentLogic from './AssignmentLogic';
import niudanconfig from '../configs/niudanconfig';

export enum LotteryType {
    Unknow = -1,
    Friendship = 1,
    Diamond,
    Faction,

    Num = 3
}

/**抽卡系统 */
export class LotteryLogic extends BaseLogic {
    static Event = {
        onLotteryTimesDirty: "on lottery times dirty",
        onLotteryFactionDirty: "on lottery faction dirty"
    }

    @WatchProperty(LotteryLogic.Event.onLotteryTimesDirty)
    protected _lotteryTimes: number = -1;

    protected _wishHeroIds: number[] = [];
    protected _tenTimes: number = 0;

    // 扭蛋
    protected _rewardPool: number[] = [];      // 扭蛋奖励池
    protected _finalReward: number = 0;        // 指定英雄
    protected _finalRefreshTs: number = 0;     // 指定英雄刷新时间
    protected _rewardRefreshTs: number = 0;    // 扭蛋奖励池刷新时间
    public hasFreeNiudan: boolean = false;
    public inVideoLotteryCdWhenLeavePanel: boolean = false;

    init(proto: GachaVO, gm: IGameManager) {
        super.init(proto, gm);
        if (proto) {
            this._update(proto);
        }
    }

    protected _update(proto: GachaVO) {
        this._lotteryTimes = proto.total;
        this._wishHeroIds = proto.wishHeroIds;
        this._tenTimes = proto.tenTimes;
    }

    getWishCount(): number {
        return 5;
    }

    getWishIds(): number[] {
        return this._wishHeroIds;
    }

    getLotteryTimes(): number {
        return this._lotteryTimes;
    }

    getBonusTimes(): number {
        return 100;
    }

    getLotteryDiamond(times: number): number {
        let value: number = defaultConfigMap.gachaprice.value;
        if (times == 10) { value = defaultConfigMap.gachatenprice.value };
        return value;
    }

    getLotteryTicket(times: number): number {
        return times;
    }

    getLotteryFriendship(times: number): number {
        return 10 * times;
    }

    getLotteryFactionTicket(times: number): number {
        return times;
    }

    getTenTimes(): number {
        return this._tenTimes;
    }

    getLotteryConsume(lotteryType: LotteryType, times: number): Good[] {
        let goods: Good[] = [];
        if (lotteryType == LotteryType.Diamond) {
            let amtDiamond = this.getLotteryDiamond(times);
            let amtTicket = this.getLotteryTicket(times);

            let vo = new GoodVO();
            vo.propId = Good.GoodId.NormalLotteryTicket;
            vo.amt = amtTicket;
            goods.push(new Good(vo));

            vo = new GoodVO();
            vo.propId = Good.GoodId.Diamond;
            vo.amt = amtDiamond;
            goods.push(new Good(vo));
        }
        else if (lotteryType == LotteryType.Friendship) {
            let vo = new GoodVO();
            vo.propId = Good.GoodId.Friendship;
            vo.amt = this.getLotteryFriendship(times);
            goods.push(new Good(vo));
        }
        else if (lotteryType == LotteryType.Faction) {
            let vo = new GoodVO();
            vo.propId = Good.GoodId.FactionLotteryTicket;
            vo.amt = this.getLotteryFactionTicket(times);
            goods.push(new Good(vo));
        }

        return goods;
    }

    canLottery(lotteryType: LotteryType, times: number): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        let count = heroLogic.getHeroesCount();
        if (count >= playerLogic.getPlayer().getHeroCapacity()) {
            return {
                result: false,
                message: stringConfigMap.key_max_hero_grid.Value
            }
        }

        let consumes = [];
        let goods = this.getLotteryConsume(lotteryType, times);
        if (lotteryType == LotteryType.Diamond) {
            for (let good of goods) {
                if (bagLogic.getGood(good.getIndex()).getAmount() >= good.getAmount()) {
                    consumes.push(() => {
                        bagLogic.changeGoodAmount(good.getIndex(), -good.getAmount());
                        if (good.getIndex() == GoodId.Diamond) {
                            commitLogic.costDiamond(good.getAmount(), DiamondCost.chouKa);
                        }
                    })
                    return {
                        result: true,
                        consumes: consumes
                    }
                }
            }
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: goods[0].getName() })
                    + stringConfigMap.key_or.Value + goods[1].getName()
            }
        }
        else {
            for (let good of goods) {
                if (bagLogic.getGood(good.getIndex()).getAmount() < good.getAmount()) {
                    return {
                        result: false,
                        message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
                    }
                }
                else {
                    consumes.push(() => {
                        bagLogic.changeGoodAmount(good.getIndex(), -good.getAmount());
                    })
                }
            }
            return {
                result: true,
                consumes: consumes
            }
        }
    }

    // 提交抽卡请求
    async doLottery(lotteryType: LotteryType, times: number, bVideo: boolean = false, fact: number = 0): Promise<{ heroes: Hero[], newHeroes: Set<number>, reward: ResourceVO }> {
        let ret = this.canLottery(lotteryType, times);
        if (!ret.result && !bVideo) {
            throw new ToastError(ret.message);
        }

        let type: number = lotteryType
        if (lotteryType == LotteryType.Faction) {
            type = fact;
        }

        let req = new GachaReq();
        req.gachaType = type;
        req.gachaTimes = times;
        req.useVideo = bVideo;
        let proto = await this._gm.request<GachaVO>(GameProxy.apiGachadoGacha, req);

        let subSource: string = HeroSubSource.diamond;
        if (lotteryType == LotteryType.Diamond) {
            subSource = bagLogic.getGood(GoodId.NormalLotteryTicket).getAmount() >= times ? HeroSubSource.allFact : subSource;
        }
        subSource = lotteryType == LotteryType.Faction ? HeroSubSource.fact : subSource;
        subSource = lotteryType == LotteryType.Friendship ? HeroSubSource.friend : subSource;
        subSource = bVideo ? HeroSubSource.video : subSource;

        if (ret && ret.consumes && !bVideo) {
            for (let consume of ret.consumes) {
                consume();
            }
        }

        let heroes: Hero[] = [];
        let epicHeroes: number = 0;
        let mythHeroes: HeroVO[] = [];
        let newHeroes: Set<number> = new Set<number>();
        if (proto.heroVOS) {
            for (let heroVO of proto.heroVOS) {
                let hero = new PlayerHero(heroVO, false);
                heroes.push(hero);
                if (!heroLogic.getRewardIllustration(hero.getIndex())) {
                    newHeroes.add(hero.getIndex());
                }
                if (hero.getQuality() != Hero.Quality.Normal) {
                    epicHeroes++;
                }
                if (hero.getQuality() == Hero.Quality.Myth) {
                    mythHeroes.push(heroVO);
                }
            }
            heroLogic.addHeroes(heroes);
        }

        commitLogic.lotteryHeros(heroes, HeroSource.chouKa, subSource);
        this._lotteryTimes = proto.total;
        this._tenTimes = proto.tenTimes;

        if (mythHeroes.length > 0) {
            if (lotteryType != LotteryType.Friendship) {
                //单抽
                if (times == 1) {
                    chatSocket.sendMultiSystemMsg(SystemType.YQBP, mythHeroes);
                } else if (times == 10) {
                    if (mythHeroes.length == 1) {
                        chatSocket.sendMultiSystemMsg(SystemType.HYLX, mythHeroes);
                    } else if (mythHeroes.length == 2) {
                        chatSocket.sendMultiSystemMsg(SystemType.OHFT, mythHeroes);
                    } else {
                        chatSocket.sendMultiSystemMsg(SystemType.TXZZ, mythHeroes);
                    }
                }
            } else {
                if (times == 1) {
                    chatSocket.sendMultiSystemMsg(SystemType.DDZDZ, mythHeroes);
                } else if (times == 10) {
                    chatSocket.sendMultiSystemMsg(SystemType.RQMM, mythHeroes);
                }
            }
        }
        if (times == 10 && !storageUtils.getBoolean(Storage.TenLottery)) {
            storageUtils.setBoolean(Storage.TenLottery.Key, true, true);
            EManager.emit(EName.onActivityBtnFresh, "activity");
        }

        if (lotteryType == LotteryType.Faction) {
            assignmentLogic.weekTaskProCommit(WeekType.faction_summon_hero, times);
            activityLogic.doIncTaskActProgress(ActivityType.UnionLottery, TaskActivityType.GetUnionLottery, null, times);
        }

        if (lotteryType == LotteryType.Diamond) {
            activityLogic.doIncTaskActProgress(ActivityType.Lottery, TaskActivityType.GetLottery, null, times);
        }

        return { heroes: heroes, newHeroes: newHeroes, reward: proto.resourceVO };
    }

    canLotteryFactionCard(): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        let count = heroLogic.getHeroesCount();
        if (count >= playerLogic.getPlayer().getHeroCapacity()) {
            return {
                result: false,
                message: stringConfigMap.key_max_hero_grid.Value
            }
        }

        let consumes = [];
        let good = bagLogic.getGood(Good.GoodId.FactionSelector);
        if (good.getAmount() > 0) {
            consumes.push(() => {
                bagLogic.changeGoodAmount(good.getIndex(), -1);
            });
        }
        else {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    async doLotteryFactionCard(faction: number): Promise<{ heroes: Hero[], newHeroes: Set<number> }> {
        let ret = this.canLotteryFactionCard();
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let req = new GoodUseReq();
        req.goodsId = Good.GoodId.FactionSelector;
        req.paras = { faction: faction };
        req.useCount = 1;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apibaguseGoods, req);

        for (let consume of ret.consumes) {
            consume();
        }

        let newHeroes = new Set<number>();
        let cards = playerLogic.getCards(proto);
        for (let card of cards) {
            if (card.getType() == Card.Type.Hero) {
                if (!heroLogic.getRewardIllustration(card.getIndex())) {
                    newHeroes.add(card.getIndex());
                }
                heroLogic.addHeroes([card as PlayerHero]);
                return { heroes: [card as Hero], newHeroes: newHeroes };
            }
        }
        throw new ToastError("无法获取英雄");
    }

    async doWish(wishIds: number[]) {
        this._wishHeroIds.sort((a: number, b: number) => { return a - b });
        wishIds.sort((a: number, b: number) => { return a - b });
        if (this._wishHeroIds.toString() == wishIds.toString()) {
            return;
        }
        await this._gm.request<GachaVO>(GameProxy.apiGachasetWishHeros, wishIds);
        this._wishHeroIds = wishIds;
    }

    async doReward(): Promise<Card[]> {
        if (this._lotteryTimes < this.getBonusTimes()) {
            throw new ToastError(stringConfigMap.key_lottery_times_no_enough.Value);
        }
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiGachagetGacha100Reward);
        this._lotteryTimes -= this.getBonusTimes();
        let cards = playerLogic.addCards(proto);
        return cards;
    }


    // --- 扭蛋 begin--- //
    ndOnceDiamondCost(): number { return defaultConfigMap.niudanprice.value; }
    ndTenDiamondCost(): number { return defaultConfigMap.niudantenprice.value; }
    // 扭蛋指定奖励
    getNdFinalId(): number { return this._finalReward; }
    getNdFinalPercent(): number {
        let total: number = 10000;
        let other: number = niudanconfig.reduce((pre, v, i, a) => { return pre + v.probability }, 0);
        let ndPercent = (total - other) / 100;
        return ndPercent;
    }
    // 扭蛋奖励池
    getNdRewardPool() { return this._rewardPool; }
    getNdFinalRefreshTs() { return (this._finalRefreshTs - gm.getCurrentTimestamp()) / 1000; }
    getNdRewardRefreshTs() { return (this._rewardRefreshTs - gm.getCurrentTimestamp()) / 1000; }

    protected updateNiudan(proto: GashaponVO) {
        if (!proto) { return; }
        this._rewardPool = proto.confIds;
        this._finalReward = proto.finalId;
        this._finalRefreshTs = proto.finalRefreshTs;
        this._rewardRefreshTs = proto.refreshTs;
        this.hasFreeNiudan = proto.firstDan;
    }
    // 获取扭蛋信息
    async niudanInfoReq() {
        let proto = await this._gm.request<GashaponVO>(GameProxy.apigashaponponInfo);
        this.updateNiudan(proto);
    }
    // 扭蛋
    async niudanGoReq(times: number, useTicket: boolean) {
        let param = new GashaponReq;
        param.gachaTimes = times;
        param.useTicket = useTicket;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apigashapongopon, param);
        return proto;
        //gm.getReward(proto);
        //commitLogic.recvDiamond(gm.getDiamondFromReward(proto), DiamondSource.niudan);
    }
    // 更换扭蛋最终大奖
    async niudanChangeFinal(cfgId: number) {
        let proto = await this._gm.request<GashaponVO>(GameProxy.apigashaponchangeFinal, cfgId);
        this.updateNiudan(proto);
    }
    // 
    nowUtcDay() {
        let data = new Date(gm.getCurrentTimestamp());
        return data.getUTCDate();
    }
    // --- 扭蛋 end  --- //

    // 置换 begin

    public getReplaceCost() {
        return defaultConfigMap.pyyonceprice.value;
    }
    public getHaveCulture(): number {
        return bagLogic.getGood(GoodId.Culture).getAmount();
    }

    // 英雄置换结果
    public async heroReplaceReq(confId: number) {
        if (confId <= 0) { return; }
        let proto = await this._gm.request<number>(GameProxy.apiherochangeHeroRandom, confId);
        return proto;
    }
    // 确认置换结果
    public async commitReplaceReq(heroId: string, confId: number) {
        let param = new HeroChangeEnterReq;
        param.heroId = heroId;
        param.changeHeroConf = confId;

        let proto = await this._gm.request<ResourceVO>(GameProxy.apiherochangeHero, param);
        return proto;
    }
    // 取消置换结果
    public async cancelReplaceReq(confId: number) {
        if (!confId || confId <= 0) { return; }
        await this._gm.request<boolean>(GameProxy.apiherocancelHeroChange, confId);
    }

    // 置换 end
}

let lotteryLogic = new LotteryLogic();
export default lotteryLogic;