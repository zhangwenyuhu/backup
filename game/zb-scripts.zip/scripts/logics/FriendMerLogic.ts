
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from '../manager/GameManager';
import GameProxy, { HeroVO, MercApplyReq, MercApplyVO, MercOptApplyReq, MercUseIncReq, MercOutVO, RoleVO, MercInfoVO, EquipBO } from "../proxy/GameProxy";
import HeroMerc from "../data/card/HeroMerc";
import User from "../data/user/User";
import friendLogic from "./FriendLogic";
import { BattleType, SystemId } from "../utils/DefineUtils";
import { stringConfigMap } from "../configs/stringConfig";
import heroLogic from "./HeroLogic";
import soldierconfig from "../configs/soldierconfig";
import equipLevelConfig from "../configs/equipLevelConfig";
import equipConfig from "../configs/equipConfig";
import { EquipPlace } from "../data/card/Equip";
import cm from "../manager/ConfigManager";
import UnlockWrapper from "../view/widget/unlock/UnlockWrapper";
import { unlockConfigMap } from "../configs/unlockConfig";

/* 好友佣兵 */
export class FriendMerLogic extends BaseLogic {


    private _mercHeros: { [key: string]: HeroMerc } = {};          // 所有佣兵列表
    private _borrowedHeros: { [key: string]: HeroMerc } = {};      // 已经借到的英雄
    private _mercApplys: { heroId: string, user: User }[] = [];     // 向我申请的列表
    private _myMercHeros: { heroId: string, user: User }[] = [];    // 我借出去的英雄
    private _userInfo: { [key: string]: User } = {};               // 缓存的玩家信息 
    public resetTimestamp: number = 0;
    public _applyingNum: number = 0;
    public currentPreparFightType: BattleType = 0;
    private _mercHeroLevel: number = 0;

    init(gm: IGameManager) {
        super.init(null, gm);
    }

    reset() {
        this._mercHeros = {}
        this._mercApplys = [];
        this._myMercHeros = [];
        this._borrowedHeros = {};
    }

    public getFightTypeStr(type: BattleType) {
        if (type == BattleType.PVP) {
            return stringConfigMap.key_common_tip4.Value;
        } else if (type == BattleType.Tower) {
            return stringConfigMap.key_common_tip5.Value;
        }
        return "";
    }
    // 可以在当前战斗中使用该雇佣英雄
    canUseInFight(id: string): boolean {
        let hero = this._borrowedHeros[id]
        if (hero) {
            let canUse: boolean = Object.keys(this._borrowedHeros).every((v, i, a) => {
                return this._borrowedHeros[v].getMercFightCount(this.currentPreparFightType) < 1;
            })
            return canUse;
        }
        return false;
    }

    // 战斗类型是否支持使用雇佣的英雄
    needMercHero(type: BattleType): boolean {
        return type == BattleType.PVE || type == BattleType.Tower;
    }

    // 是否需要重新请求雇佣英雄数据
    needReqMercHero(): boolean {
        let len = Object.keys(this._mercHeros).length
        return len <= 0 && UnlockWrapper.isUnlock(unlockConfigMap.好友);
    }

    // 提交雇佣英雄的使用次数
    public mercHeroFightCommit(id: string, type: BattleType) {
        let mercHero = this._borrowedHeros[id];
        if (mercHero) {
            let fightSystem = 0;
            if (type == BattleType.Tower) {
                fightSystem = SystemId.Tower;
            } else if (type == BattleType.PVE) {
                fightSystem = SystemId.PVE;
            }

            this.addMercHeroTimesReq({ heroId: id, systemId: "" + fightSystem });
        }
    }

    public getMercHeroLevel(): number {
        if (this._mercHeroLevel > 0) { return this._mercHeroLevel; }

        let heros = heroLogic.getHeroes();
        let maxLevel: number = 0;
        heros.forEach((v, i, a) => {
            maxLevel = maxLevel > v.getLevel() ? maxLevel : v.getLevel();
        })
        this._mercHeroLevel = maxLevel - 4;
        this._mercHeroLevel = this._mercHeroLevel > 0 ? this._mercHeroLevel : 1;
        return this._mercHeroLevel;
    }

    public resetMercHeroLevel() {
        this._mercHeroLevel = 0;
    }

    // 获取已申请到的英雄列表
    public getBorrowedHeros(filter?: (hero: HeroMerc) => boolean): HeroMerc[] {
        let tmp: HeroMerc[] = [];
        Object.keys(this._borrowedHeros).forEach((v, i, a) => {
            tmp.push(this._borrowedHeros[v]);
        });
        if (filter) { tmp = tmp.where(filter); }
        return tmp;
    }

    // 获取可申请的不同类型的英雄列表
    public getShowMercHeros(faction: number): HeroMerc[] {
        let tmpHeros: { [key: string]: HeroMerc } = {};
        Object.keys(this._mercHeros).forEach((v, i, a) => {
            let heroCfgId: string = `${this._mercHeros[v].real_data.heroCofId}`;
            if (tmpHeros[heroCfgId]) {
                if (tmpHeros[heroCfgId].getLevel() < this._mercHeros[v].getLevel()) {
                    tmpHeros[heroCfgId] = this._mercHeros[v];
                }
            } else {
                tmpHeros[heroCfgId] = this._mercHeros[v];
            }
        });

        let heros: HeroMerc[] = [];
        Object.keys(tmpHeros).forEach((v, i, a) => {
            if (faction == 0) {
                heros.push(tmpHeros[v]);
            } else {
                if (tmpHeros[v].getFaction() == faction) {
                    heros.push(tmpHeros[v]);
                }
            }

        });
        return heros;
    }
    // 获取同一种佣兵英雄列表
    public getMercHerosByCfgId(heroId: number) {
        let heros: HeroMerc[] = [];
        Object.keys(this._mercHeros).forEach((v, i, a) => {
            if (heroId == this._mercHeros[v].real_data.heroCofId) {
                heros.push(this._mercHeros[v]);
            }
        });
        return heros;
    }

    // 通过id获取玩家信息
    public getUserDataByRoleId(roleId: string): User {
        // 是否在好友数据中
        let tmpUser: User = friendLogic.getFriendInfo(roleId);
        if (tmpUser) { return tmpUser; }
        // 是否在工会数据中

        // 是否在缓存中
        if (this._userInfo[roleId]) { return this._userInfo[roleId]; }
        return null;
    }

    public getApplyList(): any[] {
        return this._mercApplys;
    }

    public getMyBorrowToOtherHeroList() {
        return this._myMercHeros;
    }

    // 通过roleid请求一个玩家的信息
    async userDataReq(id: string) {
        let proto = await gm.request<RoleVO>(GameProxy.apiRolegetRole, id);

        let tmp = new User(proto);
        this._userInfo[tmp.getRoleId()] = tmp;
    }

    creatEquipBo(caree: number, equipId: number, heroId: string, place: number, exp: number): EquipBO {
        let equip = new EquipBO;
        equip.campBonus = 0;
        equip.career = caree;
        equip.equipCofId = equipId;
        equip.equipId = `${gm.getCurrentTimestamp()}+${equipId}`;
        equip.heroId = heroId;
        equip.place = place;
        equip.totalStarExp = exp;
        return equip;
    }

    // 校正雇佣英雄的装备
    checkMercHeroData(data: HeroVO) {
        if (data) {
            let cfg = this.getMercHeroEquipCfg();
            let heroCfg = cm.getHeroConfig(data.heroCofId);
            // 武器
            let id = this.getMercHeroEquipId(heroCfg.Career, EquipPlace.Weapon, cfg.weapen);
            let exp = this.getMercHeroStarExp(cfg.weapen);
            data.equips = [];
            data.equips.push(this.creatEquipBo(heroCfg.Career, id, data.heroId, cfg.weapen, exp));
            // 胸甲
            id = this.getMercHeroEquipId(heroCfg.Career, EquipPlace.Armor, cfg.armor);
            exp = this.getMercHeroStarExp(cfg.armor);
            data.equips.push(this.creatEquipBo(heroCfg.Career, id, data.heroId, cfg.armor, exp));
            // 帽子
            id = this.getMercHeroEquipId(heroCfg.Career, EquipPlace.Helmet, cfg.hat);
            exp = this.getMercHeroStarExp(cfg.hat);
            data.equips.push(this.creatEquipBo(heroCfg.Career, id, data.heroId, cfg.hat, exp));
            // 鞋子
            id = this.getMercHeroEquipId(heroCfg.Career, EquipPlace.Shoes, cfg.shoes);
            exp = this.getMercHeroStarExp(cfg.shoes);
            data.equips.push(this.creatEquipBo(heroCfg.Career, id, data.heroId, cfg.shoes, exp));
        }
    }

    // 请求所有佣兵列表
    async mercHerosReq() {
        let proto = await gm.request<MercInfoVO>(GameProxy.apimercgetMercList);
        this._mercHeros = {};
        this._borrowedHeros = {};

        for (let i = 0; i < proto.heroes.length; i++) {
            let v = proto.heroes[i];
            let realLv: number = v.lv;
            this.checkMercHeroData(v);
            let tmp = new HeroMerc(v);
            let newLv: number = this.getMercHeroLevel();
            if (newLv == realLv) {
                let tmpLv = newLv <= 1 ? newLv + 1 : newLv - 1;
                tmp.setLevel(tmpLv);
            }
            tmp.setLevel(newLv);
            if (tmp.isBorrowedToMe()) {
                this._borrowedHeros[tmp.id] = tmp;
            }
            this._mercHeros[tmp.id] = tmp;
        }
        this.resetTimestamp = proto.resetTs;
        this.MercApplyTag();
        this.freshApplyingNum();
    }

    // 提交佣兵申请
    async heroApplyCommitReq(param: MercApplyReq) {

        try {
            let proto = await gm.request<HeroVO>(GameProxy.apimercapplyForMerc, param);

            let tmp = new HeroMerc(proto);
            this._mercHeros[tmp.id].setHeroExtra(tmp.getHeroExtra());

            Object.keys(this._mercHeros).forEach((v, i, a) => {
                let index: number = this._mercHeros[v].getIndex();
                if (index == tmp.getIndex()) {
                    this._mercHeros[v].setTagApplyStatu(true);
                }
            });
            this.freshApplyingNum();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    // 取消佣兵申请
    async cancelMercHeroApplyReq(param: MercApplyReq) {
        let proto = await gm.request<HeroVO>(GameProxy.apimerccancelForMerc, param);

        let tmp = new HeroMerc(proto);
        this._mercHeros[tmp.id].setHeroExtra(tmp.getHeroExtra());

        let arr = this.getMercHerosByCfgId(tmp.getIndex());
        let bExistApplying = arr.some((v, i, a) => {
            return v.isApplying();
        });
        if (!bExistApplying) {
            Object.keys(this._mercHeros).forEach((v, i, a) => {
                let index: number = this._mercHeros[v].getIndex();
                if (index == tmp.getIndex()) {
                    this._mercHeros[v].setTagApplyStatu(false);
                }
            })
        }
        this.freshApplyingNum();
    }

    // 获取向我提交的佣兵申请列表
    async applyToMeMercHeroReq() {
        let proto = await gm.request<MercApplyVO[]>(GameProxy.apimercgetMercApplyToMe);
        this._mercApplys = [];
        proto.forEach((v, i, a) => {
            let len = v.roleIds.length;
            for (let j = 0; j < len; j++) {
                let tmp = new User(v.roleIds[j]);
                this._mercApplys.push({ heroId: v.heroId, user: tmp });
            }
        })
    }

    // 增加使用次数
    async addMercHeroTimesReq(param: MercUseIncReq) {
        let proto = await gm.request<HeroVO>(GameProxy.apimercincMercUse, param);
        if (proto) {
            let tmp = new HeroMerc(proto);
            this._borrowedHeros[tmp.id] = tmp;
        }
    }

    // 处理佣兵申请
    async optionMercApplyReq(param: MercOptApplyReq) {
        try {
            let proto = await gm.request<MercApplyVO[]>(GameProxy.apimercoptMercApply, param);

            this._mercApplys = [];
            proto.forEach((v, i, a) => {
                let len = v.roleIds.length;
                for (let j = 0; j < len; j++) {
                    let tmp = new User(v.roleIds[j]);
                    this._mercApplys.push({ heroId: v.heroId, user: tmp });
                }
            })
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
                await this.applyToMeMercHeroReq();
            }
            else {
                throw e;
            }
        }
    }

    // 一键处理佣兵申请
    async autoOptionMercApplyReq(param: boolean) {
        let proto = await gm.request<MercApplyVO[]>(GameProxy.apimercoptAllMercApply, param);
        this._mercApplys = [];
        proto.forEach((v, i, a) => {
            let len = v.roleIds.length;
            for (let j = 0; j < len; j++) {
                let tmp = new User(v.roleIds[j]);
                this._mercApplys.push({ heroId: v.heroId, user: tmp });
            }
        })
    }

    // 归还佣兵英雄
    async backMercHeroReq(heroId: string) {
        let proto = await gm.request<boolean>(GameProxy.apimercretrunBackMerc, heroId)
        if (proto) {
            Object.keys(this._borrowedHeros).forEach((v, i, a) => {
                if (heroId == v) {
                    delete this._borrowedHeros[v];
                }
            })
        }
    }

    // 请求已经借出的英雄列表
    async myMercHerosReq() {
        let proto = await gm.request<MercOutVO[]>(GameProxy.apimercmyMercOut);
        this._myMercHeros = [];
        proto.forEach((v, i, a) => {
            let tmp = new User(v.user);
            this._myMercHeros.push({ heroId: v.heroId, user: tmp });
        });
    }

    private MercApplyTag() {
        let ids: number[] = [];
        Object.keys(this._mercHeros).forEach((v, i, a) => {
            if (this._mercHeros[v].isApplying()) {
                ids.push(this._mercHeros[v].getIndex());
            }
        })

        for (let j = 0; j < ids.length; j++) {
            Object.keys(this._mercHeros).forEach((v, i, a) => {
                if (this._mercHeros[v].getIndex() == ids[j]) {
                    this._mercHeros[v].setTagApplyStatu(true);
                }
            })
        }
    }

    private freshApplyingNum() {
        let num: number = 0;
        Object.keys(this._mercHeros).forEach((v, i, a) => {
            if (this._mercHeros[v].isApplying()) {
                num += 1;
            }
        })
        this._applyingNum = num;
    }

    private getMercHeroEquipCfg() {
        for (let i = 0; i < soldierconfig.length; i++) {
            let cfg = soldierconfig[i];
            if (cfg.playerlevel && cfg.playerlevel[0]) {
                let maxLv = this.getMercHeroLevel() + 4
                if (maxLv >= cfg.playerlevel[0][0] && maxLv <= cfg.playerlevel[0][1]) {
                    return cfg;
                }
            }
        }
        return soldierconfig[0];
    }

    private getMercHeroStarExp(rank: number): number {
        let exp: number = 0;
        if (rank) {
            let cfg = equipLevelConfig[rank - 1];
            if (cfg) {
                exp = 0;
            }
        }
        return exp;
    }

    private getMercHeroEquipId(career: number, place: number, rank: number): number {
        let id: number = 0;
        for (let i = 0; i < equipConfig.length; i++) {
            let cfg = equipConfig[i];
            if (cfg.Career == career && cfg.Place == place && cfg.Rank == rank) {
                return cfg.Id;
            }
        }
        return id;
    }
}

let friendMerLogic = new FriendMerLogic();
export default friendMerLogic;