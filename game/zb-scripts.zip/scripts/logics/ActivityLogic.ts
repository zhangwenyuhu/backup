import { stringConfigMap } from './../configs/stringConfig';
import {
    ActivitySevenRewardReq,
    GoodVO,
    EquipBO,
    StorePromotionReq,
    ActBossHitReq,
    PioneerRecvBO,
    ActivityProgressChangeReq,
    ActivityExchangeBuyReq,
    CloudObjectReq,
    HeroVO,
    RankListReq,
    RankVO,
    ActSevenChargeBO
} from './../proxy/GameProxy';
import { EName } from './../manager/EventManager';
import BaseLogic from "./BaseLogic";
import IGameManager from "../manager/IGameManager";
import GameProxy, {
    ResourceVO,
    SevenDaySignInfoVO,
    TaskInfoVO,
    ActivityBO,
    ActivityRoleBO,
    ActivityCumRewardReq, ActTreaRaiderBuy, MainTaskInfoVO, ActivityProgressBO, TreaBoxBO, RankListVO, LikeSOReq,
} from "../proxy/GameProxy";
import ToastError from "../error/ToastError";
import gm from "../manager/GameManager";
import sevenDaysConfig, { sevenDaysConfigRow } from "../configs/sevenDaysConfig";
import { BattleType, EventGroup, Storage, TaskActivityType } from "../utils/DefineUtils";
import Tasktypeconfig from "../configs/Tasktypeconfig";
import playerLogic from "./PlayerLogic";
import promptLogic, { PromptType } from "./PromptLogic";
import missionLogic from "./MissionLogic";
import EManager from "../manager/EventManager";
import ActivityAccumData from '../data/activity/ActivityAccumData';
import Card from '../data/card/Card';
import Good, { GoodId } from '../data/card/Good';
import Equip from '../data/card/Equip';
import RoleActivityDatas from "../data/activity/roleactivitydatas/RoleActivityDatas";
import TreasureActConfig from "../data/activity/actconfig/TreasureActConfig";
import TreasureRoleActivityDatas from "../data/activity/roleactivitydatas/TreasureRoleActivityDatas";
import bagLogic from './BagLogic';
import stringUtils from '../utils/StringUtils';
import ChessActivityDatas from '../data/activity/roleactivitydatas/ChessActivityDatas';
import WorldBossActConfig from '../data/activity/actconfig/WorldBossActConfig';
import WorldBossActivityDatas from '../data/activity/roleactivitydatas/WorldBossActivityDatas';
import SurpriseShopActConfig from "../data/activity/actconfig/SurpriseShopActConfig";
import { defaultConfigMap } from "../configs/defaultConfig";
import IBattleData from '../data/IBattleData';
import Hero from '../data/card/Hero';
import Npc from '../data/card/Npc';
import cm from '../manager/ConfigManager';
import UnlockWrapper from '../view/widget/unlock/UnlockWrapper';
import { unlockConfigMap, unlockConfigRow } from '../configs/unlockConfig';
import pioneer2config from "../configs/pioneer2config";
import SignNewActivityDatas from '../data/activity/roleactivitydatas/SignNewActivityDatas';
import XiaoFeiDaRenActivityDatas from '../data/activity/roleactivitydatas/XiaoFeiDaRenActivityDatas';
import SignNewActConfig from '../data/activity/actconfig/SignNewActConfig';
import XiaoFeiDaRenActConfig from '../data/activity/actconfig/XiaoFeiDaRenActConfig';
import ExploreActivityDatas from '../data/activity/roleactivitydatas/ExploreActivityDatas';
import ExploreActConfig from '../data/activity/actconfig/ExploreActConfig';

/**活动类型 */
export enum ActivityType {
    All = -1,
    None = 0,

    /**七日特惠 */
    Day7,
    /**超值促销 */
    Promotion,

    /**累充 */
    LeiChong,
    /**累消 */
    LeiXiao,

    /**世界Boss */
    WorldBoss,
    /**夺宝奇兵 */
    Treasure,
    /**奇兵商店 */
    SurpriseShop,
    /**棋盘活动 */
    CheckerBoard,
    /**演武试炼 */
    YanWuShiLian,
    /**消费达人 */
    XiaoFeiDaRen = 10,
    /**签到有礼 */
    SignNew = 11,
    /**探趣寻宝 */
    Explore = 12,

    /**抽卡活动*/
    Lottery = 13,
    /**寻宝庆典*/
    HappyTreasure = 14,
    /**英雄养成*/
    HeroCultivate = 15,
    /**狂热竞技*/
    CrazyArena = 16,
    /**智慧风暴*/
    WisdomStorm = 17,
    /**悬赏季*/
    RewardSeason = 18,
    /**联盟集结*/
    UnionRally = 19,
    /**英雄降临*/
    HeroCome = 20,
    /**熔炉馈赠*/
    FurnaceGift = 21,
    /**神秘宝库*/
    MysteryTreasure = 22,
    /**联盟抽卡*/
    UnionLottery = 23,
    /**活动月令*/
    MonthOrder = 24,

    /**7日签到 */
    Day7Sign = 1100,
    /**7日目标 */
    NewPlayerTask = 1101,
    /**14日目标 */
    NewPlayer2Task = 1102,
    /**每日光环*/
    DailyLight = 1103,

    //减2000为对应活动的榜单活动
    /**寻宝每日光环*/
    ExchangeDailyLight = 2014,
    /**夺宝每日光环*/
    TreasureDailyLight = 2006,
    /**棋盘每日光环*/
    BoardDailyLight = 2008,
    /**联盟每日光环*/
    UnionDailyLight = 2019,

    NewServer = 1000
}

/**
 * 活动模型
 */
export class ActivityModal {
    id: string;
    type: number;
    openAt: number;
    closeAt: number;
    count: number;
    actConfig: ActConfig = null;
    roleActivityDatas: RoleActivityDatas = null;
    sevenInfo: SevenInfoModal = null;
    datas: { [key: string]: ActivityAccumData } = {};

    protected _rewards: Card[] = [];

    constructor(params: {
        id: string,
        type: number,
        realOpenAt: number,
        realCloseAt: number
    }) {
        this.id = params.id;
        this.type = params.type;
        this.openAt = params.realOpenAt;
        this.closeAt = params.realCloseAt;
    }

    getSevenInfo(): SevenInfoModal {
        return this.sevenInfo;
    }

    get configs(): any[] {
        return this.actConfig.configs;
    }

    /**
     * 活动是否生效
     */
    get isValid(): boolean {
        if (this.type == ActivityType.LeiChong) {
            if (!UnlockWrapper.isUnlock(unlockConfigMap.充值竞赛)) {
                return false;
            }
        }
        else if (this.type == ActivityType.LeiXiao) {
            if (!UnlockWrapper.isUnlock(unlockConfigMap.消费竞赛)) {
                return false;
            }
        }
        else if (this.type == ActivityType.WorldBoss) {
            if (!UnlockWrapper.isUnlock(unlockConfigMap.世界BOSS)) {
                return false;
            }
        }
        else if (this.type == ActivityType.CheckerBoard) {
            if (!UnlockWrapper.isUnlock(unlockConfigMap.棋盘活动)) {
                return false;
            }
        }
        else if (this.type == ActivityType.Treasure) {
            if (!UnlockWrapper.isUnlock(unlockConfigMap.夺宝奇兵)) {
                return false;
            }
        }
        else if (this.type == ActivityType.SurpriseShop) {
            if (!UnlockWrapper.isUnlock(unlockConfigMap.夺宝奇兵)) {
                return false;
            }
        }

        if (this.type == ActivityType.CheckerBoard) { return this.remainTime > 0; }
        return (this.configs.length > 0 || (this.actConfig && this.actConfig.isActConfigValid)) && this.remainTime > 0;
    }

    /**
     * 活动剩余时间
     */
    get remainTime(): number {
        return this.closeAt - gm.getCurrentTimestamp();
    }

    getData(tag: string): ActivityAccumData {
        return this.roleActivityDatas.taskDatas[tag];
    }

    getDataByIndex(index: number): ActivityAccumData {
        return this.roleActivityDatas.activityDatas[index];
    }

    /**
     * 活动奖励
     */
    getRewards(): Card[] {
        if (this._rewards.length == 0) {
            let rewards = this.actConfig && this.actConfig.data.rewards;
            if (rewards) {
                for (let reward of rewards) {
                    if (reward.objId == "goods") {
                        let goodVo = new GoodVO();
                        goodVo.propId = reward.propId;
                        goodVo.amt = Number(reward.amt);
                        let good = new Good(goodVo);
                        this._rewards.push(good);
                    } else if (reward.objId == "equip") {
                        let equipBo = new EquipBO();
                        equipBo.equipCofId = reward.propId;
                        equipBo.campBonus = reward.campBonus | 0;
                        let equip = new Equip(equipBo);
                        this._rewards.push(equip);
                    } else if (reward.objId == "hero") {
                        let heroVo = new HeroVO();
                        heroVo.heroCofId = reward.propId;
                        heroVo.star = reward.star;
                        heroVo.rank = reward.rank;
                        heroVo.lv = reward.lv;
                        let hero = new Hero(heroVo);
                        this._rewards.push(hero);
                    }
                }
            }
        }
        return this._rewards;
    }
}

/**
 * 世界Boss活动模型
 */
export class ActivityWorldBossModal extends ActivityModal implements IBattleData {
    get diamondCost(): number {
        let config = this.actConfig as WorldBossActConfig;
        let data = this.roleActivityDatas as WorldBossActivityDatas;
        let index = data.challengeCount - config.freeCount;
        let cost = cm.defaultWorldBossCosts[index];
        return cost;
    }

    /**
     * 是否挑战
     */
    canChallenge(): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        let consumes: Function[] = [];
        let config = this.actConfig as WorldBossActConfig;
        let data = this.roleActivityDatas as WorldBossActivityDatas;
        if (this.remainTime <= 0) {
            return {
                result: false,
                message: stringConfigMap.key_activity_finished.Value
            }
        }
        if (data.rebornTimestamp >= 0) {
            return {
                result: false,
                message: stringConfigMap.key_boss_no_reborn.Value
            };
        }
        if (data.challengeCount == config.limitCount) {
            return {
                result: false,
                message: stringConfigMap.key_challenge_limit.Value
            }
        }
        if (data.challengeCount >= config.freeCount) {
            let cost = this.diamondCost;
            let good = bagLogic.getGood(Good.GoodId.Diamond);
            if (good.getAmount() < cost) {
                return {
                    result: false,
                    message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
                }
            }
            else {
                consumes.push(() => {
                    bagLogic.changeGoodAmount(Good.GoodId.Diamond, -cost);
                    commitLogic.costDiamond(cost, DiamondCost.worldBoss);
                });
            }
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**
     * 挑战
     */
    doChallenge() {
        let ret = this.canChallenge();
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        for (let consume of ret.consumes) {
            consume();
        }
        let data = this.roleActivityDatas as WorldBossActivityDatas;
        data.addChallengeCount();
        EManager.emit(EName.onWorldBossChallengeFinish);
    }

    /**
     * @override
     */
    getMonsters(): Hero[] {
        let config = this.actConfig as WorldBossActConfig;
        return [null, null, null, config.boss, null];
    }

    /**
     * @override
     */
    getRewards(): Good[] {
        return []
    }

    /**
     * @override
     */
    getTime(): number {
        return 90;
    }

    /**
     * @override
     */
    getBattleType(): BattleType {
        return BattleType.WorldBoss;
    }

    /**
     * @override
     */
    getNpcs(): { [key: number]: Npc } {
        return {};
    }

    /**
     * @override
     */
    getUntroopHeroIds(): Set<string> {
        return null;
    }

    /**
     * @override
     */
    getUntroopReason(): string {
        return "";
    }

    /**
     * @override
     */
    getTroopExpire(): number {
        return -1;
    }
}

export class ActivitySevenNew {
    protected _task: MainTaskInfoVO[] = [];

    constructor(task: MainTaskInfoVO[]) {
        this._task = task;
    }

    get taskInfo() {
        return this._task;
    }

    doRecvReward(id: number) {
        this._task.find(a => a.taskId == id).recv = true;
        if (!this.hasUnRecvTaskReward) {
            promptLogic.setPromptRead([15]);
        }
    }

    get taskFinishCnt() {
        let cnt = 0;
        for (let task of this._task) {
            let sevenDaysNewCfg = sevenDaysNewConfig.find(a => a.Id == task.taskId);
            if (sevenDaysNewCfg && sevenDaysNewCfg.days > 0 && sevenDaysNewCfg.days <= activityLogic.whichDay()) {
                let taskTypeCfg = Tasktypeconfig.find(a => a.tasktypeID == sevenDaysNewCfg.type);
                if (taskTypeCfg.paracount == 2) {
                    let progressBase = taskTypeCfg.progressbase == 1 ? sevenDaysNewCfg.parameter1 : sevenDaysNewCfg.parameter2;
                    if (task.progress >= progressBase) {
                        cnt++;
                    }
                } else {
                    if (task.progress >= sevenDaysNewCfg.parameter1) {
                        cnt++;
                    }
                }
            }
        }
        return cnt;
    }

    get hasUnRecvTaskReward(): boolean {
        let whichDay = activityLogic.whichDay();
        for (let i = 1; i <= 5; i++) {
            if (i <= whichDay) {
                if (this.hasUnRecvTaskRewardByDay(i)) {
                    return true;
                }
            }
        }
        for (let task of this._task) {
            let sevenCfg = sevenDaysNewConfig.find(a => a.Id == task.taskId);
            if (sevenCfg && sevenCfg.days == -1) {
                if (this.taskFinishCnt >= sevenCfg.parameter1 && !task.recv) {
                    return true;
                }
            }
        }
        return false;
    }

    hasUnRecvTaskRewardByDay(day: number, tab: number = -1) {
        if (day <= activityLogic.whichDay()) {
            let taskData = this.getTaskByDay(day);
            if (tab != -1) {
                taskData = taskData.where(a => a.type2 == tab);
            }
            for (let task of taskData) {
                let taskConfig = Tasktypeconfig.find(a => a.tasktypeID == task.type);
                if (taskConfig) {
                    let taskInfo = this._task.find(a => a.taskId == task.Id);
                    //存在未领取任务
                    let progressBase = taskConfig.progressbase == 1 ? task.parameter1 : task.parameter2;
                    if (taskInfo && !taskInfo.recv) {
                        if (taskConfig.tasktypeID == 9018) {
                            if (taskInfo.progress > 0 && taskInfo.progress <= task.parameter1) {
                                return true;
                            }
                        } else if (taskConfig.tasktypeID == 9020) {
                            return true;
                        } else {
                            if (taskConfig.paracount == 1 && taskInfo.progress >= task.parameter1) {
                                return true;
                            } else if (taskConfig.paracount == 2 && taskInfo.progress >= progressBase) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    getTaskByDay(day: number): sevenDaysNewConfigRow[] {
        let taskTypes = this._getTaskTypeByDay(day);
        let taskData = [];
        for (let taskType of taskTypes) {
            let config = this._getFirstUnReceiveTask(day, taskType);
            if (config) {
                taskData.push(config);
            }
        }
        return taskData;
    }

    // 充值任务本地更新到最新
    public taskRecharge(num: number) {
        console.log('新手充值任务 更新数据')
        let nowDay: number = activityLogic.whichDay();
        let todayCfg = this.getTaskByDay(nowDay);
        for (let i = 0; i < this._task.length; i++) {
            for (let j = 0; j < todayCfg.length; j++) {
                if (this._task[i].taskId == todayCfg[j].Id) {
                    if (todayCfg[j].type == 9016) {
                        // 当日充值
                        let needPro: number = todayCfg[j].parameter1;
                        this._task[i].progress += num;
                        if (this._task[i].progress > needPro) {
                            this._task[i].progress = needPro;
                        }
                    }
                }
            }

            // 累计充值
            let cfg = cm.getSevenTaskNewConfig(this._task[i].taskId);
            if (cfg && cfg.type == 9017) {
                this._task[i].progress += num;
                if (this._task[i].progress > cfg.parameter1) {
                    this._task[i].progress = cfg.parameter1;
                }
            }
        }
    }

    protected _getTaskTypeByDay(day: number) {
        let list: number[] = [];
        for (let config of sevenDaysNewConfig) {
            if (config.days == day) {
                if (list.indexOf(config.type) == -1) {
                    list.push(config.type);
                }
            }
        }
        return list;
    }

    protected _getFirstUnReceiveTask(day: number, taskType: number): sevenDaysNewConfigRow {
        for (let config of sevenDaysNewConfig) {
            if (config.days == day && config.type == taskType) {
                let taskInfo = this._task.find(a => a.taskId == config.Id);
                if (!taskInfo || !taskInfo.recv || (this._taskTypeAllFinish(config.Id) && this._isTaskLast(day, config.Id))) {
                    return config;
                }
            }
        }
        return null;
    }

    protected _taskTypeAllFinish(taskId: number): boolean {
        let taskType = sevenDaysNewConfig.find(a => a.Id == taskId);
        for (let config of sevenDaysNewConfig) {
            if (config.type == taskType) {
                let taskInfo = this._task.find(a => a.taskId == config.Id);
                if (!taskInfo || taskInfo.progress < 1 || !taskInfo.recv) {
                    return false;
                }
            }
        }
        return true;
    }

    protected _isTaskLast(day: number, taskId: number): boolean {
        let taskTypeConfig = sevenDaysNewConfig.find(a => a.Id == taskId);
        for (let config of sevenDaysNewConfig) {
            if (config.days == day && config.type == taskTypeConfig.type && config.Id > taskId) {
                return false;
            }
        }
        return true;
    }

}

export class TaskActivityCloudData {
    protected _differentFactionSR: number[] = [];
    protected _differentFactionSSR: number[] = [];
    protected _differentFactionUR: number[] = [];

    constructor(data: any) {
        if (data) {
            this._differentFactionSR = data.differentFactionSR;
            this._differentFactionSSR = data.differentFactionSSR;
            this._differentFactionUR = data.differentFactionUR;
        }
    }

    getCloudData() {
        let data = {};
        data["differentFactionSR"] = this._differentFactionSR;
        data["differentFactionSSR"] = this._differentFactionSSR;
        data["differentFactionUR"] = this._differentFactionUR;
        return data;
    }

    checkSR(heroConfId: number) {
        return this._differentFactionSR.indexOf(heroConfId) != -1;
    }

    addSR(heroConfId: number) {
        if (!this.checkSR(heroConfId)) {
            this._differentFactionSR.push(heroConfId);
        }
    }

    checkSSR(heroConfId: number) {
        return this._differentFactionSSR.indexOf(heroConfId) != -1;
    }

    addSSR(heroConfId: number) {
        if (!this.checkSSR(heroConfId)) {
            this._differentFactionSSR.push(heroConfId);
        }
    }

    checkUR(heroConfId: number) {
        return this._differentFactionUR.indexOf(heroConfId) != -1;
    }

    addUR(heroConfId: number) {
        if (!this.checkUR(heroConfId)) {
            this._differentFactionUR.push(heroConfId);
        }
    }

    async doPutCloudData(expireTimeTs: number) {
        if (expireTimeTs <= 0) {
            return;
        }
        let req = new CloudObjectReq();
        req.expire = expireTimeTs;
        req.key = activityLogic.taskActivityKey;
        req.objData = { data: this.getCloudData() };
        await gm.request(GameProxy.apiutilsetCloudObject, [req], GameProxy, true);
    }

}

export class TaskWisdomActivityData {
    protected _wisdomTreeTs: number = 0;

    constructor(data: any) {
        if (data) {
            this._wisdomTreeTs = data.wisdomTreeTs;
        }
    }

    getCloudData() {
        let data = {};
        data["wisdomTreeTs"] = this._wisdomTreeTs;
        return data;
    }

    /**能上传*/
    checkWisdomTreeTs(ts: number) {
        return this._wisdomTreeTs == 0 || ts != this._wisdomTreeTs;
    }

    setWisdomTreeTs(ts: number) {
        this._wisdomTreeTs = ts;
    }

    async doPutCloudData(expireTimeTs: number) {
        if (expireTimeTs <= 0) {
            return;
        }
        let req = new CloudObjectReq();
        req.expire = expireTimeTs;
        req.key = activityLogic.taskWisdomActivityKey;
        req.objData = { data: this.getCloudData() };
        await gm.request(GameProxy.apiutilsetCloudObject, [req], GameProxy, true);
    }
}

export class TreasureBox {
    protected _treaBoxBo: TreaBoxBO = null;

    constructor(data: TreaBoxBO) {
        this._treaBoxBo = data;
    }

    get lotteryIds(): number[] {
        let ids: number[] = [];
        for (let conf of baibaodaiconfig) {
            if (!this.isLottery(conf.ID) && conf.ID != baibaodaiconfig[baibaodaiconfig.length - 1].ID) {
                ids.push(conf.ID);
            }
        }
        return ids;
    }

    /**已抽取 */
    isLottery(id: number): boolean {
        return this._treaBoxBo.confIds.indexOf(id) != -1;
    }

    doLottery(id: number) {
        this._treaBoxBo.confIds.push(id);
        this._treaBoxBo.count--;
        if (this._treaBoxBo.count <= 0) {
            promptLogic.setPromptRead([PromptType.TREABOX_READY]);
        }
    }

    get lastCount(): number {
        return this._treaBoxBo.count;
    }

    get dayPay(): number {
        return this._treaBoxBo.dayPay;
    }

    get refreshTs(): number {
        return this._treaBoxBo.finalRefreshTs;
    }
}

/**
 * 活动逻辑
 */
class ActivityLogic extends BaseLogic {
    protected _sevenDaySignInfo: SevenDaySignInfoVO[] = [];
    protected _taskInfo: TaskInfoVO[] = [];
    protected _pioneer2Info: PioneerRecvBO = null;
    protected _sevenNew: ActivitySevenNew = null;
    protected _treaBoxInfo: TreasureBox = null;

    protected _activityDatas: { [key: number]: ActivityModal } = {};

    init(gm: IGameManager) {
        super.init(null, gm);
    }

    /**检测七日任务是否过期 */
    checkNewPlayerExpire() {
        let finish = playerLogic.getPlayer().getCreateTs() + 7 * 24 * 3600 * 1000;
        return gm.getCurrentTimestamp() > finish;
    }

    getNewPlayerTaskTs(): number {
        let finish = playerLogic.getPlayer().getCreateTs() + 7 * 24 * 3600 * 1000;
        let ts: number = finish - gm.getCurrentTimestamp();
        ts = ts > 0 ? ts : 0;
        return ts;
    }

    /**检测14日任务是否过期 */
    checkNewPlayer2Expire() {
        let finish = playerLogic.getPlayer().getCreateTs() + 14 * 24 * 3600 * 1000;
        let start = playerLogic.getPlayer().getCreateTs() + 7 * 24 * 3600 * 1000;
        let timestamp = gm.getCurrentTimestamp();
        return timestamp > finish || timestamp < start;
    }

    getNewPlayer2TaskTs(): number {
        let finish = playerLogic.getPlayer().getCreateTs() + 14 * 24 * 3600 * 1000;
        let ts: number = finish - gm.getCurrentTimestamp();
        ts = ts > 0 ? ts : 0;
        return ts;
    }

    get hasActivityValid(): boolean {
        return this.isNewServerValid
            || this.isActivityValid(ActivityType.LeiChong)
            || this.isActivityValid(ActivityType.LeiXiao)
            || this.isActivityValid(ActivityType.Day7)
            || this.isActivityValid(ActivityType.Treasure)
            || this.isActivityValid(ActivityType.SurpriseShop)
            || this.isActivityValid(ActivityType.WorldBoss)
            || this.isActivityValid(ActivityType.CheckerBoard)
            || this.isActivityValid(ActivityType.SignNew)
            || this.isActivityValid(ActivityType.XiaoFeiDaRen)
            || this.isActivityValid(ActivityType.Explore)
            || this.isActivityValid(ActivityType.Day7Sign)
            || this.isActivityValid(ActivityType.NewPlayerTask)
            || this.isActivityValid(ActivityType.NewPlayer2Task)
            || this.isActivityValid(ActivityType.DailyLight)
            || this.isActivityValid(ActivityType.Lottery)
            || this.isActivityValid(ActivityType.HappyTreasure)
            || this.isActivityValid(ActivityType.HeroCultivate)
            || this.isActivityValid(ActivityType.CrazyArena)
            || this.isActivityValid(ActivityType.WisdomStorm)
            || this.isActivityValid(ActivityType.RewardSeason)
            || this.isActivityValid(ActivityType.UnionRally)
            || this.isActivityValid(ActivityType.UnionLottery)
            || this.isActivityValid(ActivityType.HeroCome)
            || this.isActivityValid(ActivityType.FurnaceGift)
            || this.isActivityValid(ActivityType.MysteryTreasure)
            || this.isActivityValid(ActivityType.MonthOrder)
    }

    get sevenNew(): ActivitySevenNew {
        return this._sevenNew;
    }

    get sevenDaySignInfo(): SevenDaySignInfoVO[] {
        return this._sevenDaySignInfo;
    }

    get pioneer2Info(): PioneerRecvBO {
        return this._pioneer2Info;
    }

    get pioneer2Finish() {
        if (!this._pioneer2Info) {
            return true;
        }
        if (this._pioneer2Info.reaminCount >= this._pioneer2Info.recvLimit) {
            promptLogic.setLocalPromptStatus(PromptType.ACTIVITY_PURITY, this.hasUnRecvPioneer2());
            return false;
        }
        if (this.hasUnRecvPioneer2()) {
            return false;
        }
        let currentConf = pioneer2config[pioneer2config.length - 1];
        return this._pioneer2Info.stageId >= currentConf.stagenode;
    }

    get pioneer2CanShow() {
        if (!this._pioneer2Info) {
            return false;
        }
        // let canRecv = this._pioneer2Info.reaminCount >= this._pioneer2Info.recvLimit;
        // let showAdv = this.pioneer2ShowAdv();
        // let hasUnRecv = this.hasUnRecvPurityReward;
        let hasMieba = bagLogic.getArtifacts().find(a => a.getIndex() == 40007) != null;
        return !this.pioneer2Finish && hasMieba;
    }

    pioneer2ShowAdv() {
        let canRecv = this._pioneer2Info.reaminCount >= this._pioneer2Info.recvLimit;
        return !this._allStageFinish() && this._previousCircleAllFinish() &&
            this._isPioneerInRange() && !activityLogic.pioneer2Finish && !canRecv;
    }

    protected _previousCircleAllFinish() {
        let _currentConf = this._getCurrentPioneerCfg();
        if (_currentConf.circle > 1) {
            let cfg = pioneer2config.where(a => a.circle == _currentConf.circle - 1);
            for (let _cfg of cfg) {
                if (!this._pioneer2Info.enterDetail[_cfg.ID]) {
                    return false;
                }
            }
        }
        return true;
    }

    protected _getCurrentPioneerCfg() {
        let _currentConf = pioneer2config[pioneer2config.length - 1];
        for (let info of pioneer2config) {
            if (!activityLogic.pioneer2Info.enterDetail[info.ID]) {
                _currentConf = info;
                break;
            }
        }
        return _currentConf;
    }

    protected _isPioneerInRange() {
        let stageId = missionLogic.getCurrentMission().getStageId() - 1;
        let lastCfg = pioneer2config.where(a => a.ID % 7 == 0);
        let _currentConf = this._getCurrentPioneerCfg();
        let previousCfg = null;
        if (_currentConf.circle > 1) {
            previousCfg = lastCfg[_currentConf.circle - 2];
        }
        let cfg2 = pioneer2config.where(a => a.circle == _currentConf.circle);
        let previousStageNode = previousCfg ? previousCfg.stagenode : 0;
        let isInRange = stageId >= previousStageNode && stageId < cfg2[cfg2.length - 1].stagenode || stageId >= lastCfg[lastCfg.length - 1].stagenode;
        return isInRange;
    }

    protected _allStageFinish() {
        let stageId = missionLogic.getCurrentMission().getStageId() - 1;
        let stageFinish = stageId >= pioneer2config[pioneer2config.length - 1].stagenode;
        return stageFinish;
    }

    get sevenDaySignFinished(): boolean {
        if (this._sevenDaySignInfo.length < 7) {
            return false;
        }
        for (let sign of this._sevenDaySignInfo) {
            if (!sign.recv) {
                return false;
            }
        }
        return true;
    }

    get isNewServerValid(): boolean {
        if (!UnlockWrapper.isUnlock(unlockConfigMap.开服竞赛)) {
            return false;
        }
        //return true;
        return gm.getCurrentTimestamp() <= gm.curServerInfo.openAt + 7 * 24 * 3600 * 1000;
    }

    get newServerRemainTime(): number {
        //return 7 * 24 * 3600 * 1000;
        return gm.curServerInfo.openAt + 7 * 24 * 3600 * 1000 - gm.getCurrentTimestamp();
    }

    get hasUnRecvSignReward(): boolean {
        for (let sign of this._sevenDaySignInfo) {
            if (!sign.recv) {
                return true;
            }
        }
        return false;
    }

    hasUnRecvTaskRewardByDay(day: number) {
        if (day <= this.whichDay()) {
            let taskData = this.getTaskByDay(day);
            for (let task of taskData) {
                let taskConfig = Tasktypeconfig.find(a => a.tasktypeID == task.type);
                if (taskConfig) {
                    let taskInfo = activityLogic.taskInfo.find(a => a.taskId == task.Id);
                    //存在未领取任务
                    if (taskInfo && taskInfo.progress >= task.counts && !taskInfo.recv) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    get taskInfo(): TaskInfoVO[] {
        return this._taskInfo;
    }

    get taskFinishCnt() {
        let cnt = 0;
        for (let task of this._taskInfo) {
            let sevenDaysCfg = sevenDaysConfig.find(a => a.Id == task.taskId);
            if (sevenDaysCfg && sevenDaysCfg.days > 0 && sevenDaysCfg.days <= this.whichDay()) {
                if (task.progress >= sevenDaysCfg.counts) {
                    cnt++;
                }
            }
        }
        return cnt;
    }

    getTaskProgress(taskId: number): number {
        let task = this._taskInfo.find(a => a.taskId == taskId);
        return task ? task.progress : 0;
    }

    whichDay(): number {
        let start = playerLogic.getPlayer().getCreateTs();
        let startTime = new Date(start);
        startTime.setUTCHours(0);
        startTime.setUTCMinutes(0);
        startTime.setUTCSeconds(0);
        startTime.setUTCMilliseconds(0);
        let utcTs = startTime.getTime();
        let serverTime = new Date(gm.getCurrentTimestamp());
        let nowTs = serverTime.getTime();
        let diffTime = nowTs - utcTs;
        //console.log(`createTs:${start} createUtc0Ts:${utcTs} nowTs:${nowTs}`);
        if (diffTime < 0) {
            return 1;
        }
        let diffHour = diffTime / 1000 / 3600;
        return Math.min(5, Math.floor(diffHour / 24) + 1);
    }

    getTaskByDay(day: number): sevenDaysConfigRow[] {
        let taskTypes = this._getTaskTypeByDay(day);
        let taskData = [];
        for (let taskType of taskTypes) {
            let config = this._getFirstUnReceiveTask(day, taskType);
            if (config) {
                taskData.push(config);
            }
        }
        return taskData;
    }

    protected _getTaskTypeByDay(day: number) {
        let list: number[] = [];
        for (let config of sevenDaysConfig) {
            if (config.days == day) {
                if (list.indexOf(config.type) == -1) {
                    list.push(config.type);
                }
            }
        }
        return list;
    }

    protected _getFirstUnReceiveTask(day: number, taskType: number): sevenDaysConfigRow {
        for (let config of sevenDaysConfig) {
            if (config.days == day && config.type == taskType) {
                let taskInfo = activityLogic.taskInfo.find(a => a.taskId == config.Id);
                if (!taskInfo || !taskInfo.recv || (this._taskTypeAllFinish(config.Id) && this._isTaskLast(config.Id))) {
                    return config;
                }
            }
        }
        return null;
    }

    protected _taskTypeAllFinish(taskId: number): boolean {
        let taskType = sevenDaysConfig.find(a => a.Id == taskId);
        for (let config of sevenDaysConfig) {
            if (config.type == taskType) {
                let taskInfo = activityLogic.taskInfo.find(a => a.taskId == config.Id);
                if (!taskInfo || taskInfo.progress < 1 || !taskInfo.recv) {
                    return false;
                }
            }
        }
        return true;
    }

    protected _isTaskLast(taskId: number): boolean {
        let taskTypeConfig = sevenDaysConfig.find(a => a.Id == taskId);
        for (let config of sevenDaysConfig) {
            if (config.type == taskTypeConfig.type && config.Id > taskId) {
                return false;
            }
        }
        return true;
    }

    // 七日签到
    async doGetSevenDaySignInfo() {
        this._sevenDaySignInfo = await this._gm.request<SevenDaySignInfoVO[]>(GameProxy.apigiftgetSevenDayInfo, "");
        promptLogic.setLocalPromptStatus(PromptType.ACTIVITY_SIGN, this.hasUnRecvSignReward);
    }

    async doRecvSevenDaySignReward(day: number) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apigiftrecvSevenDay, day);
        if (proto) {
            gm.getReward(proto, true);
            commitLogic.commitReward(proto, DiamondSource.sevenSign);
        }
        for (let signInfo of this._sevenDaySignInfo) {
            if (signInfo.day == day) {
                signInfo.recv = true;
            }
        }
        promptLogic.setLocalPromptStatus(PromptType.ACTIVITY_SIGN, this.hasUnRecvSignReward);
    }

    // 新手任务新版-获取任务信息
    async doGetSevenNewTaskInfo() {
        let proto = await this._gm.request<MainTaskInfoVO[]>(GameProxy.apitaskgetSevenNewTaskInfo, 0);
        this._sevenNew = new ActivitySevenNew(proto);
    }

    // 新手任务新版-领取奖励
    async doGetSevenNewTaskReward(id: number) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apitaskgetSevenNewTaskReward, id);
        if (proto) {
            gm.getReward(proto);
            this._sevenNew.doRecvReward(id);
            EManager.emit(EName.PromptRefresh);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.NewPlayerTask);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.NewPlayer2Task);
            commitLogic.commitReward(proto, DiamondSource.sevenTaskNew);
            commitLogic.recvNpTaskReward(id);
        }
    }

    hasUnRecvPioneer2() {
        if (this._pioneer2Info.reaminCount >= this._pioneer2Info.recvLimit) {
            return true;
        }
        let stage = Math.max(missionLogic.getCurrentMission().getStageId() - 1, this._pioneer2Info.stageId);
        for (let info of pioneer2config) {
            if (info.stagenode <= stage) {
                if (!this._pioneer2Info.enterDetail[info.ID]) {
                    return true;
                }
            }
        }
        return false;
    }

    getLastRecvCircle(): number {
        let circle = 1;
        for (let i = 1; i <= 3; i++) {
            let pioneerCfgs = pioneer2config.where(a => a.circle == i);
            let flag = false;
            for (let cfg of pioneerCfgs) {
                if (!this._pioneer2Info.enterDetail[cfg.ID]) {
                    flag = true;
                    break;
                }
            }
            if (flag) {
                break;
            }
            circle++;
        }
        return circle;
    }

    getFirstPioneerUnPassed(): number {
        let stageId = Math.max(missionLogic.getCurrentMission().getStageId() - 1, this._pioneer2Info.stageId);
        for (let info of pioneer2config) {
            if (stageId < info.stagenode) {
                return info.ID;
            }
        }
        return pioneer2config[pioneer2config.length - 1].ID;
    }

    passPioneerMission(stageId: number) {
        let pioneerCfg = pioneer2config.find(a => a.stagenode == stageId);
        if (pioneerCfg) {
            this._pioneer2Info.reaminCount += pioneerCfg.reward;
            if (missionLogic.getCurrentMission().getStageId() > this._pioneer2Info.stageId) {
                this._pioneer2Info.stageId = missionLogic.getCurrentMission().getStageId() - 1;
            }
            EManager.emit(EName.onActivityBtnFresh, "activity");
        }
        promptLogic.setLocalPromptStatus(PromptType.ACTIVITY_PURITY, this.hasUnRecvPioneer2());
    }

    async doGetPioneer2Info() {
        this._pioneer2Info = await this._gm.request<PioneerRecvBO>(GameProxy.apiActivitypioneerInfoV2, null);
        promptLogic.setLocalPromptStatus(PromptType.ACTIVITY_PURITY, this.hasUnRecvPioneer2());
    }

    async doRecvPioneer2(showReward: boolean = true) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiActivityrecvPioneerV2, 0);
        if (proto.extra && proto.extra.length > 0) {
            this._pioneer2Info = proto.extra[0] as PioneerRecvBO;
            promptLogic.setLocalPromptStatus(PromptType.ACTIVITY_PURITY, this.hasUnRecvPioneer2());
        }
        if (showReward) {
            gm.getReward(proto);
            commitLogic.commitReward(proto, DiamondSource.pioneer2);
        }
        return proto;
    }

    async doPioneer2Enter(stageId: number) {
        this._pioneer2Info = await this._gm.request<PioneerRecvBO>(GameProxy.apiActivitypioneerEnterV2, stageId);
        promptLogic.setLocalPromptStatus(PromptType.ACTIVITY_PURITY, this.hasUnRecvPioneer2());
        EManager.emit(EName.onUpdatePioneer);
    }

    async doAtkTreaRaider() {
        let activity = this.getActivityConfigs(ActivityType.Treasure);
        let actConfig = activity.actConfig as TreasureActConfig;
        let roleActivityDatas = activity.roleActivityDatas as TreasureRoleActivityDatas;
        let req = new ActBossHitReq();
        req.actId = activity.id;
        req.result = null; //战报
        req.totalHurt = actConfig.treasureTotalHurt;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiActivityatkTreaRaider, req);
        if (proto) {
            //没有免费次数了
            if (roleActivityDatas.count >= actConfig.freeCount) {
                bagLogic.getGood(actConfig.ticketId).changeAmount(-1);
            }
            roleActivityDatas.count++;
            gm.getReward(proto, true);
            commitLogic.commitReward(proto, DiamondSource.trearaider);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.SurpriseShop);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.Treasure);
        }
    }

    async doBuyRaiderStore(data: ActivityAccumData) {
        let activity = this.getActivityConfigs(ActivityType.SurpriseShop);
        let index = activity.roleActivityDatas.activityDatas.indexOf(data);
        let actConfig = activity.actConfig as SurpriseShopActConfig;
        let req = new ActivityCumRewardReq();
        req.actId = activity.id;
        req.recTag = data.tag;
        req.type = ActivityType.SurpriseShop;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiActivitybuyRaiderStore, req);
        if (proto) {
            data.changeCurValue(1);
            bagLogic.getGood(actConfig.shopData[index].ticketId).changeAmount(-actConfig.shopData[index].ticketCount);
            gm.getReward(proto, true);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.SurpriseShop);
            commitLogic.commitReward(proto, DiamondSource.trearaiderBuy);
        }
    }

    async doBuyTreaRaider(cnt: number) {
        let diamond = bagLogic.getGood(GoodId.Diamond).getAmount();
        if (diamond < cnt * defaultConfigMap.challengeticket.value) {
            gm.toast(stringConfigMap.key_auto_553.Value);
            return;
        }
        let activity = this.getActivityConfigs(ActivityType.Treasure);
        let req = new ActTreaRaiderBuy();
        req.actId = activity.id;
        req.buyCount = cnt;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiActivitybuyTreaRaider, req);
        if (proto) {
            (activity.roleActivityDatas as TreasureRoleActivityDatas).ticketBuyCount += cnt;
            bagLogic.getGood(GoodId.Diamond).changeAmount(-cnt * defaultConfigMap.challengeticket.value);
            gm.getReward(proto, true);
            commitLogic.costDiamond(cnt * defaultConfigMap.challengeticket.value, DiamondCost.treaRaindeTicket);
        }
    }

    getActivityRemainTime(type: ActivityType): number {
        if (type == ActivityType.NewServer) {
            return this.newServerRemainTime;
        }
        let activityData = this._activityDatas[type];
        if (activityData) {
            return activityData.remainTime;
        }
        return 0;
    }

    getActivityId(type: ActivityType): string {
        let activityData = this._activityDatas[type];
        if (activityData) {
            return activityData.id;
        }
        return "";
    }

    protected _updateActivityData(config: ActivityBO, data: object, sevenInfo: ActSevenChargeBO) {
        let modal: ActivityModal = null;
        if (config.type == ActivityType.WorldBoss) {
            modal = new ActivityWorldBossModal({
                id: config.id,
                type: config.type,
                realOpenAt: config.realOpenAt,
                realCloseAt: config.realCloseAt
            });
        }
        else {
            modal = new ActivityModal({
                id: config.id,
                type: config.type,
                realOpenAt: config.realOpenAt,
                realCloseAt: config.realCloseAt
            });
        }

        if (modal.type == ActivityType.Treasure) {
            modal.actConfig = new TreasureActConfig(config.actConfig);
        } else if (modal.type == ActivityType.SurpriseShop) {
            modal.actConfig = new SurpriseShopActConfig(config.actConfig);
        } else if (modal.type == ActivityType.WorldBoss) {
            modal.actConfig = new WorldBossActConfig(config.actConfig);
        } else if (modal.type == ActivityType.SignNew) {
            modal.actConfig = new SignNewActConfig(config.actConfig);
        } else if (modal.type == ActivityType.XiaoFeiDaRen) {
            modal.actConfig = new XiaoFeiDaRenActConfig(config.actConfig);
        } else if (modal.type == ActivityType.Explore) {
            modal.actConfig = new ExploreActConfig(config.actConfig);
        } else if (modal.type == ActivityType.MonthOrder) {
            modal.actConfig = new MonthOrderActConfig(config.actConfig);
        } else if (modal.type == ActivityType.Lottery ||
            modal.type == ActivityType.HappyTreasure ||
            modal.type == ActivityType.HeroCultivate ||
            modal.type == ActivityType.CrazyArena ||
            modal.type == ActivityType.WisdomStorm ||
            modal.type == ActivityType.RewardSeason ||
            modal.type == ActivityType.UnionRally ||
            modal.type == ActivityType.UnionLottery) {
            modal.actConfig = new TaskActConfig(config.actConfig);
        } else if (modal.type == ActivityType.HeroCome ||
            modal.type == ActivityType.FurnaceGift ||
            modal.type == ActivityType.MysteryTreasure) {
            modal.actConfig = new ExchangeActConfig(config.actConfig);
        } else {
            modal.actConfig = new ActConfig(config.actConfig);
        }

        if (data) {
            if (modal.type == ActivityType.Treasure) {
                modal.roleActivityDatas = new TreasureRoleActivityDatas(data, modal.type);
            } else if (modal.type == ActivityType.CheckerBoard) {
                modal.roleActivityDatas = new ChessActivityDatas(data, modal.type);
            } else if (modal.type == ActivityType.WorldBoss) {
                modal.roleActivityDatas = new WorldBossActivityDatas(data, modal.type);
            } else if (modal.type == ActivityType.SignNew) {
                modal.roleActivityDatas = new SignNewActivityDatas(data, modal.type);
            } else if (modal.type == ActivityType.XiaoFeiDaRen) {
                modal.roleActivityDatas = new XiaoFeiDaRenActivityDatas(data, modal.type);
            } else if (modal.type == ActivityType.Explore) {
                modal.roleActivityDatas = new ExploreActivityDatas(data, modal.type);
            } else if (modal.type == ActivityType.MonthOrder) {
                modal.roleActivityDatas = new MonthOrderActivityDatas(data, modal.type);
            } else {
                modal.roleActivityDatas = new RoleActivityDatas(data, modal.type);
            }
        }

        if (sevenInfo) {
            modal.sevenInfo = new SevenInfoModal(sevenInfo, modal.type);
        }

        this._activityDatas[modal.type] = modal;
        EManager.emit(EName.onUpdateActivityDatas, modal.type);
    }

    async activityReq(type: ActivityType) {
        let proto = await this._gm.request<ActivityRoleBO[]>(GameProxy.apiActivitygetRoleActivities, type);
        if (proto && proto.length > 0) {
            for (let data of proto) {
                this._updateActivityData(data.activityBO, data.roleActivityDatas, data.sevenInfo);
            }
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.DailyLight);
        }
        if (this._taskActivityCloudData == null) {
            this.doGetCloudData();
        }
    }

    async doClaimBonus(data: ActivityAccumData, actId: string, type: ActivityType) {
        let proto: ResourceVO = null;
        if (type == ActivityType.Day7) {
            let req = new ActivitySevenRewardReq();
            req.actId = actId;
            req.needProgress = data.totalValue;
            req.recTag = data.realTag;
            proto = await this._gm.request<ResourceVO>(GameProxy.apiActivityrecvSevenDayCum, req);
        }
        else {
            let req = new ActivityCumRewardReq();
            req.actId = actId;
            req.recTag = data.tag;
            req.type = type;
            if (type == ActivityType.WorldBoss) {
                proto = await this._gm.request<ResourceVO>(GameProxy.apiActivityrecvWordBoss, req);
            }
            else {
                proto = await this._gm.request<ResourceVO>(GameProxy.apiActivityrecvCumChargeConsum, req);
            }
        }
        this._gm.getReward(proto, true);

        let source: string = DiamondSource.actDefault;
        source = type == ActivityType.WorldBoss ? DiamondSource.actWorldBoss : source;
        source = type == ActivityType.Day7 ? DiamondSource.actSevenDayCum : source;
        commitLogic.commitReward(proto, source);
    }

    async doBuyPromotion(actId: string, tag: string, config: any) {
        let cost = Math.floor(config.price * config.discount);
        let good = bagLogic.getGood(Good.GoodId.Diamond);
        if (good.getAmount() < cost) {
            throw new ToastError(stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() }));
        }

        let req = new StorePromotionReq();
        req.actId = actId;
        req.buyTag = tag;
        let protos = await this._gm.request<ResourceVO>(GameProxy.apiActivitybugFromPromotion, req);
        bagLogic.changeGoodAmount(Good.GoodId.Diamond, -cost);
        this._gm.getReward(protos, true);
        gm.commitEvent(EventGroup.Promotion, [tag], cost);
        commitLogic.costDiamond(cost, DiamondCost.promotionBuy);
    }

    async doCommitWorldBossHurt(totalHurt: number, result: object) {
        let modal = this.getActivityConfigs(ActivityType.WorldBoss) as ActivityWorldBossModal;
        let req = new ActBossHitReq();
        req.actId = modal.id;
        req.result = result;
        req.totalHurt = totalHurt;
        await this._gm.request(GameProxy.apiActivityatkWorldBoss, req);
        modal.doChallenge();
    }

    getActivityData(type: ActivityType, tag: string): ActivityAccumData {
        let activityData = this._activityDatas[type];
        if (activityData) {
            return activityData.getData(tag);
        }
        return null;
    }

    getActivityDataByIndex(type: ActivityType, index: number): ActivityAccumData {
        let activityData = this._activityDatas[type];
        if (activityData) {
            return activityData.getDataByIndex(index);
        }
        return null;
    }

    getActivityConfigs(type: ActivityType): ActivityModal {
        return this._activityDatas[type];
    }

    isActivityValid(type: ActivityType): boolean {
        let realType = type;
        if (type == ActivityType.NewServer) {
            return this.isNewServerValid;
        } else if (type == ActivityType.Day7Sign) {
            return !activityLogic.sevenDaySignFinished && UnlockWrapper.isUnlock(unlockConfigMap.七日签到);
        } else if (type == ActivityType.NewPlayerTask) {
            return !activityLogic.checkNewPlayerExpire() && UnlockWrapper.isUnlock(unlockConfigMap.新手任务);
        } else if (type == ActivityType.NewPlayer2Task) {
            return !activityLogic.checkNewPlayer2Expire() && UnlockWrapper.isUnlock(unlockConfigMap.新手任务);
        } else if (type == ActivityType.DailyLight) {
            return giftLogic.dailyLightModal && giftLogic.dailyLightModal.isDailyLightValid && UnlockWrapper.isUnlock(unlockConfigMap.新手光环);
        } else if (type == ActivityType.ExchangeDailyLight ||
            type == ActivityType.TreasureDailyLight ||
            type == ActivityType.BoardDailyLight ||
            type == ActivityType.UnionDailyLight) {
            realType = type - 2000;
        }
        if (!this.isActivityUnlock(realType)) { return false; }

        let activityData = this._activityDatas[realType];
        if (activityData) {
            if (type == ActivityType.ExchangeDailyLight ||
                type == ActivityType.TreasureDailyLight ||
                type == ActivityType.BoardDailyLight ||
                type == ActivityType.UnionDailyLight) {
                return activityData.isValid && activityData.sevenInfo != null;
            } else {
                return activityData.isValid;
            }
        }

        return false;
    }

    isActivityUnlock(type: ActivityType): boolean {
        let unlock = true;
        if (type == ActivityType.Explore) {
            unlock = UnlockWrapper.isUnlock(unlockConfigMap.探趣寻宝);
        }
        return unlock;
    }

    isTaskActivityValid(type: ActivityType): boolean {
        let activityData = this.getActivityConfigs(type);
        if (!activityData) {
            return false;
        }
        let actConfig = activityData.actConfig as TaskActConfig;
        return activityData.remainTime > 0 && actConfig.isActConfigValid;
    }

    hasTaskActivityUnRecv(type: ActivityType): boolean {
        let data = this.getActivityConfigs(type);
        let actConfig = null;
        if (type == ActivityType.HeroCome || type == ActivityType.FurnaceGift || type == ActivityType.MysteryTreasure) {
            actConfig = data.actConfig as ExchangeActConfig;
        } else {
            actConfig = data.actConfig as TaskActConfig;
        }
        if (actConfig) {
            if (type == ActivityType.HeroCome || type == ActivityType.FurnaceGift || type == ActivityType.MysteryTreasure) {
                let exchangeData = actConfig.exchangeData;
                for (let data of exchangeData) {
                    if (data.canExchange() && data.isAllMaterialEnough()) {
                        return true;
                    }
                }
            } else {
                let taskCfg = actConfig.getTaskCfg();
                for (let cfg of taskCfg) {
                    let activityData = this.getActivityDataByIndex(type, actConfig.getTagIndex(cfg));
                    if (activityData.claimable) {
                        return true;
                    }
                }
            }
        }
        let activityData = this.getActivityData(type, "-1");
        if (activityData && activityData.claimable) {
            return true;
        }
        return false;
    }

    /**
     * 设置任务活动进度 累加
     * @param activityType 活动类型
     * @param taskType 任务类型
     * @param param 带参数任务，该值传递最新的数据
     * @param progress 累加的进度
     */
    async doIncTaskActProgress(activityType: ActivityType, taskType: TaskActivityType, param: string, progress: number, equal: boolean = false, callback: Function = null) {
        if (!this.isTaskActivityValid(activityType)) {
            return;
        }
        let data: ActivityModal = activityLogic.getActivityConfigs(activityType);
        let actConfig = data.actConfig as TaskActConfig;
        let taskCfg: TaskCfg[] = actConfig.getTaskCfg();
        let req = new ActivityProgressChangeReq();
        req.actId = data.id;
        let map = {};
        for (let cfg of taskCfg) {
            if (taskType == cfg.getTaskType()) {
                let actData = this.getActivityDataByIndex(activityType, actConfig.getTagIndex(cfg))
                let tag = actData.tag;

                let bMonthOrder: boolean = false;
                if (param && param != "" && cfg.getParas() && cfg.getParas() != "") {
                    if (equal) {
                        // 多参数
                        if (param.search(';') != -1 || param.search('；') != -1) {
                            if (cfg.isEqual(param)) {
                                map[tag] = progress;
                                bMonthOrder = true;
                            }
                        } else {
                            if (Number(cfg.getParas()) == Number(param)) {
                                map[tag] = progress;
                                bMonthOrder = true;
                            }
                        }
                    } else {
                        if (Number(cfg.getParas()) < Number(param)) {
                            map[tag] = progress;
                            bMonthOrder = true;
                        }
                    }
                } else {
                    map[tag] = progress;
                    bMonthOrder = true;
                }
                let actMonth = [ActivityType.HeroCultivate, ActivityType.WisdomStorm, ActivityType.RewardSeason]
                let index = actMonth.findIndex((a) => { return a == activityType; })
                if (bMonthOrder && index >= 0) {
                    if (cfg.getProgressNeed() > actData.curValue && cfg.getProgressNeed() <= actData.curValue + progress) {
                        if (activityLogic.isActivityValid(ActivityType.MonthOrder)) {
                            console.log('月令活动完成,积分+10');
                            this.moData().AddNowValueTen();
                            EManager.emit(EName.onUpdateActivityDatas, ActivityType.MonthOrder);
                        }
                    }
                }
            }
        }
        if (Object.keys(map).length > 0) {
            callback && callback();
            req.changeMap = map;
            let proto = await this._gm.request<ActivityProgressBO[]>(GameProxy.apiActivityincTaskActProgress, req);
            if (proto) {
                for (let res of proto) {
                    let activityData = activityLogic.getActivityData(activityType, res.tag);
                    activityData.curValue = res.progress;
                }
                EManager.emit(EName.onUpdateActivityDatas, activityType);
            }
        }
    }

    /**
     * 设置任务活动进度 覆盖
     * @param activityType 活动类型
     * @param taskType 任务类型
     * @param param 带参数任务，该值传递最新的数据
     * @param equal 是否参数相等
     */
    async doSetTaskActProgress(activityType: ActivityType, taskType: TaskActivityType, param: string, equal: boolean = false, callback: Function = null) {
        if (!this.isTaskActivityValid(activityType)) {
            return;
        }
        let data: ActivityModal = activityLogic.getActivityConfigs(activityType);
        let actConfig = data.actConfig as TaskActConfig;
        let taskCfg: TaskCfg[] = actConfig.getTaskCfg();
        let req = new ActivityProgressChangeReq();
        req.actId = data.id;
        let map = {};
        for (let cfg of taskCfg) {
            if (taskType == cfg.getTaskType()) {
                let tag = this.getActivityDataByIndex(activityType, actConfig.getTagIndex(cfg)).tag;
                if (param && param != "" && cfg.getParas() && cfg.getParas() != "") {
                    if (equal) {
                        // 多参数
                        if (param.search(';') != -1 || param.search('；') != -1) {
                            if (cfg.isEqual(param)) {
                                map[tag] = 1;
                            }
                        } else {
                            if (Number(cfg.getParas()) == Number(param)) {
                                map[tag] = 1;
                            }
                        }
                    } else {
                        if (Number(cfg.getParas()) < Number(param)) {
                            map[tag] = Number(param);
                        }
                    }
                } else {
                    map[tag] = Number(param);
                }
            }
        }
        if (Object.keys(map).length > 0) {
            callback && callback();
            req.changeMap = map;
            let proto = await this._gm.request<ActivityProgressBO[]>(GameProxy.apiActivitysetTaskActProgress, req);
            if (proto) {
                for (let res of proto) {
                    let activityData = activityLogic.getActivityData(activityType, res.tag);
                    activityData.curValue = res.progress;
                }
                EManager.emit(EName.onUpdateActivityDatas, activityType);
            }
        }
    }

    /**领取任务活动奖励 */
    async doRecvTaskActReward(activityType: ActivityType, tag: string) {
        let data: ActivityModal = activityLogic.getActivityConfigs(activityType);
        let req = new ActivityCumRewardReq();
        req.actId = data.id;
        req.recTag = tag;
        req.type = activityType;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiActivityrecvTaskActReward, req);
        if (proto) {
            gm.getReward(proto);
            this.getActivityData(activityType, tag).markClaimed();
            EManager.emit(EName.onUpdateTaskActivity);
            EManager.emit(EName.onUpdateActivityDatas, activityType);
        }
    }

    /**兑换活动兑换 */
    async doBuyExchangeItem(activityType: ActivityType, heroes: Hero[], equips: Equip[], goods: Good[], tag: string) {
        let data: ActivityModal = activityLogic.getActivityConfigs(activityType);
        let req = new ActivityExchangeBuyReq();
        req.actId = data.id;
        let heroIds = [];
        for (let hero of heroes) {
            heroIds.push(hero.getId());
        }
        req.heroIds = heroIds;
        let equipIds = [];
        for (let equip of equips) {
            equipIds.push(equip.getId());
        }
        req.equipIds = equipIds;
        req.recTag = tag;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiActivitybuyExchangeItem, req);
        if (proto) {
            let cards = playerLogic.addCards(proto);

            for (let good of goods) {
                bagLogic.getGood(good.getIndex()).changeAmount(-good.getAmount());
            }
            let activityConfig = this.getActivityConfigs(activityType);
            let actConfig = activityConfig.actConfig as ExchangeActConfig;
            let roleDatas = activityConfig.roleActivityDatas;
            let index = roleDatas.getIndexByTag(tag);
            if (index >= 0) {
                actConfig.exchangeData[index].doExchange();
            }
            for (let h of heroes) {
                heroLogic.doRevert(h as PlayerHero, heroLogic.getResetCards);
            }
            heroLogic.removeHeroes(heroIds);
            bagLogic.removeEquips(equipIds);
            EManager.emit(EName.onUpdateActivityDatas, activityType);
            return cards;
        }
    }

    protected _taskActivityKey: string = "TaskActivityKey";
    protected _taskActivityCloudData: TaskActivityCloudData = null;

    protected _taskWisdomActivityKey: string = "TaskWisdomActivityKey";
    protected _taskWisdomActivityCloudData: TaskWisdomActivityData = null;

    get taskActivityKey(): string {
        return this._taskActivityKey;
    }

    get taskActivityCloudData(): TaskActivityCloudData {
        return this._taskActivityCloudData;
    }

    get taskWisdomActivityKey(): string {
        return this._taskWisdomActivityKey;
    }

    get taskWisdomCloudData(): TaskWisdomActivityData {
        return this._taskWisdomActivityCloudData;
    }

    async doGetCloudData() {
        let proto = await this._gm.request<{ [key: string]: object }>(GameProxy.apiutilgetCloudObject, [this._taskActivityKey, this._taskWisdomActivityKey]);
        if (proto[this._taskActivityKey] && proto[this._taskActivityKey]["data"]) {
            this._taskActivityCloudData = new TaskActivityCloudData(proto[this._taskActivityKey]["data"]);
        } else {
            this._taskActivityCloudData = new TaskActivityCloudData(null);
        }
        if (proto[this._taskWisdomActivityKey] && proto[this._taskWisdomActivityKey]["data"]) {
            this._taskWisdomActivityCloudData = new TaskWisdomActivityData(proto[this._taskWisdomActivityKey]["data"]);
        } else {
            this._taskWisdomActivityCloudData = new TaskWisdomActivityData(null);
        }
    }

    get treaBoxInfo(): TreasureBox {
        return this._treaBoxInfo;
    }

    async doGetTreaBoxInfo() {
        let proto = await this._gm.request<TreaBoxBO>(GameProxy.apitreaboxtreaboxInfo, null);
        if (proto) {
            this._treaBoxInfo = new TreasureBox(proto);
            if (this._treaBoxInfo.lastCount <= 0) {
                promptLogic.setPromptRead([PromptType.TREABOX_READY]);
            } else {
                promptLogic.setPrompt(PromptType.TREABOX_READY, true);
            }
        }
    }

    async doGoTreaBox() {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apitreaboxgotrea, null);
        return proto;
    }

    protected _cycleRank: RankListVO = null;

    get cycleLastRank(): RankVO[] {
        return this._cycleRank.preTop;
    }

    get cycleRankType() {
        return this._cycleRank.myRank.conins;
    }

    get cycleRankRemainTime(): number {
        return this._cycleRank.myRank.limitTime - gm.getCurrentTimestamp();
    }

    /**获取周期活动排行信息 */
    async doGetCycleActRank(start: number, end: number) {
        let req = new RankListReq();
        req.customKey = "";
        req.end = end;
        req.rankType = 9;
        req.start = start;
        this._cycleRank = await this._gm.request<RankListVO>(GameProxy.apirankgetCycleActRank, req);
        return this._cycleRank;
    }

    get isCycleRankValid() {
        if (this._cycleRank && this._cycleRank.myRank) {
            let type = this._cycleRank.myRank.conins + 2000;
            if (type == ActivityType.ExchangeDailyLight ||
                type == ActivityType.UnionDailyLight) {
                if (!UnlockWrapper.isUnlock(unlockConfigMap.活动)) {
                    return false;
                }
            } else if (type == ActivityType.TreasureDailyLight) {
                if (!UnlockWrapper.isUnlock(unlockConfigMap.夺宝奇兵)) {
                    return false;
                }
            } else if (type == ActivityType.BoardDailyLight) {
                if (!UnlockWrapper.isUnlock(unlockConfigMap.棋盘活动)) {
                    return false;
                }
            }
            return this._cycleRank.myRank.limitTime > gm.getCurrentTimestamp();
        }
        return false;
    }

    protected _rankLastList: RankVO[] = [];

    get rankLastList(): RankVO[] {
        return this._rankLastList;
    }

    get lastRankValid() {
        let arenaJuniorRank = this.getRankLastListByType(7);
        let arenaSeniorRank = this.getRankLastListByType(8);
        if (arenaJuniorRank.length > 0 && UnlockWrapper.isUnlock(unlockConfigMap.竞技场) || arenaSeniorRank.length > 0 && UnlockWrapper.isUnlock(unlockConfigMap.高阶竞技场)) {
            return true;
        }
        return false;
    }

    getRankLastListByType(type: number) {
        let rank = [];
        let list = this._rankLastList.where(a => a.rankType == type).sort((a: RankVO, b: RankVO) => { return a.no - b.no });
        for (let i = 0, len = Math.min(3, list.length); i < len; i++) {
            rank.push(list[i]);
        }
        return rank;
    }

    /**上期竞技场排行榜 */
    async doGetRankLast(type: number) {
        this._rankLastList = await this._gm.request<RankVO[]>(GameProxy.apiarenarankLast, type);
    }

    async doGetActSevenReward(activeType: ActivityType, id: number) {
        let activeData = activityLogic.getActivityConfigs(activeType);
        let req = new ActivitySevenRewardReq();
        req.actId = activeData.id;
        req.needProgress = 1;
        req.recTag = id.toString();
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiActivitygetActSevenReward, req);
        if (proto) {
            gm.getReward(proto);
            activeData.sevenInfo.doReceive(id);
            EManager.emit(EName.onUpdateActivityDatas, activeType + 2000);
        }
    }

    // 签到有礼 begin
    async signNewRewardReq(day: number, id: string, needProg: number, tag: string) {
        let req = new ActivitySevenRewardReq();
        req.actId = id;
        req.needProgress = needProg;
        req.recTag = tag;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiActivityrecvSignGift, req);
        gm.getReward(proto);
        commitLogic.commitReward(proto, DiamondSource.actSign);
    }
    hasSignNewReward(): boolean {
        if (!activityLogic.getActivityConfigs(ActivityType.SignNew)) { return false; }
        let data = activityLogic.getActivityConfigs(ActivityType.SignNew).roleActivityDatas as SignNewActivityDatas;
        return data.hasReward();
    }
    // 签到有礼 end

    // 消费达人 begin
    async xiaofeiDarenRewardReq(id: string, tag: string) {
        let req = new ActivityCumRewardReq();
        req.actId = id;
        req.recTag = tag;
        req.type = ActivityType.XiaoFeiDaRen;

        let proto = await this._gm.request<ResourceVO>(GameProxy.apiActivityrecvCumChargeConsum, req);
        gm.getReward(proto);
        commitLogic.commitReward(proto, DiamondSource.actXiaofeiDaren);
    }

    hasXiaoFeiReward(): boolean {
        if (!activityLogic.getActivityConfigs(ActivityType.XiaoFeiDaRen)) { return false; }
        let data = activityLogic.getActivityConfigs(ActivityType.XiaoFeiDaRen).roleActivityDatas as XiaoFeiDaRenActivityDatas;
        return data.hasReward();
    }

    costDiamond(num: number) {
        if (!activityLogic.getActivityConfigs(ActivityType.XiaoFeiDaRen)) { return false; }
        let data = activityLogic.getActivityConfigs(ActivityType.XiaoFeiDaRen).roleActivityDatas as XiaoFeiDaRenActivityDatas;
        data.costDiamond(num);
        EManager.emit(EName.onUpdateActivityDatas, ActivityType.XiaoFeiDaRen);
    }
    // 消费达人 end

    async supportPlayer(roleId: string, type: number = 0) {
        let req = new LikeSOReq();
        req.targetRoleId = roleId;
        req.type = type;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiRolelikeRole, req);
        gm.getReward(proto);
        return proto.extra;
    }

    public heroSchoolvalid(): boolean {
        //let createTs: number = playerLogic.getPlayer().getCreateTs();
        let unlockTs: number = storageUtils.getNumber(Storage.UnlockHeroSchoolTs);
        return unlockTs <= 0 || (gm.getCurrentTimestamp() - unlockTs < 3 * 24 * 3600 * 1000);
    }

    public async recvMonthOrderReward(tag: string, actId: string) {
        let param = new ActivityCumRewardReq;
        param.recTag = tag;
        param.actId = actId;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiActivityrecvMonthKsReward, param);
        gm.getReward(proto);
    }
    public monthOrderRed(): boolean {
        let red: boolean = false;
        let data = activityLogic.getActivityConfigs(ActivityType.MonthOrder).roleActivityDatas;
        if (data) { red = (data as MonthOrderActivityDatas).hasCanRecved(); }
        return red;
    }

    public moModal() {
        return activityLogic.getActivityConfigs(ActivityType.MonthOrder);
    }
    public moData(): MonthOrderActivityDatas {
        return this.moModal().roleActivityDatas as MonthOrderActivityDatas;
    }
    public moCfg(): MonthOrderActConfig {
        return this.moModal().actConfig as MonthOrderActConfig;
    }
}

let activityLogic = new ActivityLogic();
export default activityLogic;

import giftLogic from "./GiftLogic";
import sevenDaysNewConfig, { sevenDaysNewConfigRow } from "../configs/sevenDaysNewConfig";
import commitLogic, { DiamondSource, DiamondCost } from './CommitLogic'; import storageUtils from '../utils/StorageUtils';
import TaskActConfig, { TaskCfg } from "../data/activity/actconfig/TaskActConfig";
import ExchangeActConfig from "../data/activity/actconfig/ExchangeActConfig";
import heroLogic from "./HeroLogic";
import Task from "../data/xuanshang/task";
import MonthOrderActConfig from '../data/activity/actconfig/MonthOrderActConfig';
import MonthOrderActivityDatas from '../data/activity/roleactivitydatas/MonthOrderActivityDatas';
import baibaodaiconfig from "../configs/baibaodaiconfig";
import { SevenInfoModal } from "../data/activity/SevenInfoModal";
import PlayerHero from '../data/card/PlayerHero';
import ActConfig from '../data/activity/actconfig/ActConfig';

