import { CloudObjectReq } from './../proxy/GameProxy';
import { EName } from './../manager/EventManager';
import { guideconfigRow } from './../configs/guideconfig';
import IGameManager from "../manager/IGameManager";
import BaseLogic from "./BaseLogic";
import guideconfig from "../configs/guideconfig";
import EManager from '../manager/EventManager';
import GameProxy from '../proxy/GameProxy';
import storageUtils from '../utils/StorageUtils';
import { Storage } from '../utils/DefineUtils';

/**引导系统 */
class GuideLogic extends BaseLogic {
    readonly cloudKey: string = "guideId";
    guideIndex: number = 0;
    noGuide: boolean = false;
    isPause: boolean = false;

    readonly leishenStageId = 8;
    readonly artifactStageId = 6;
    readonly banzangStageId = 56;

    protected _currentStep: guideconfigRow = null;
    protected _recordIndex: number = 0;
    protected _recordId: number = 1001;

    init(data: any, gm: IGameManager) {
        super.init(data, gm);

        let id = storageUtils.getNumber(Storage.GuideId);
        if (data && typeof data.data == "number") {
            id = Math.max(id, data.data);
        }

        this._recordId = id;
        this.guideIndex = -1;
        for (let i = 0; i < guideconfig.length; i++) {
            if (guideconfig[i].ID == id) {
                this._recordIndex = i;
                this.guideIndex = i;
                this._currentStep = guideconfig[i];
                break;
            }
        }

        if (id == 30100) { // 兼容老版本的引导
            this.guideId = 4001;
            this._record(4001);
        }
    }

    set guideId(id: number) {
        this.guideIndex = -1;
        this._currentStep = null;
        for (let i = 0; i < guideconfig.length; i++) {
            let config = guideconfig[i];
            if (config.ID == id) {
                this.guideIndex = i;
                this._currentStep = guideconfig[i];
                break;
            }
        }
    }

    get guideId(): number {
        if (this._currentStep) {
            return this._currentStep.ID;
        }
        return this.recordId;
    }

    get currentStep(): guideconfigRow {
        if (this.noGuide) return null;
        if (!this._currentStep) {
            this._currentStep = guideconfig[this.guideIndex];
        }
        return this._currentStep;
    }

    get recordId(): number {
        return this._recordId;
    }

    rollback() {
        if (this.noGuide) return;

        this.guideIndex = this._recordIndex;
        this._currentStep = guideconfig[this.guideIndex];
    }

    nextStep() {
        let step = this.currentStep;
        EManager.emit(EName.onFinishGuideStep, step);
        if (step != this.currentStep) {
            return;
        }
        if (step.record > 0) {
            this._record(step.record);
        }
        if (step.finish > 0) {
            this._currentStep = null;
            this.guideIndex = -1;
            EManager.emit(EName.onGuideFinished);
            return;
        }

        if (step == this.currentStep) {
            this.guideIndex++;
            this._currentStep = guideconfig[this.guideIndex];
            EManager.emit(EName.onUpdateGuideStep, this._currentStep);

            if (this._currentStep) {
                gssdk.logCommitTool.commitCommon({
                    eventId: 1,
                    index: this._currentStep.ID
                });
            }
        }
    }

    protected async _record(guideId: number) {
        this._recordIndex = this.guideIndex;
        this._recordId = guideId;
        storageUtils.setNumber(Storage.GuideId.Key, guideId);

        let req = new CloudObjectReq();
        req.expire = 0;
        req.key = this.cloudKey;
        req.objData = { data: guideId };
        this._gm.request(GameProxy.apiutilsetCloudObject, [req], GameProxy, true);
    }
}

let guideLogic = new GuideLogic();
export default guideLogic;