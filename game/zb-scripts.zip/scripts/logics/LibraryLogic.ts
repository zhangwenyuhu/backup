import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from '../manager/GameManager';
import cm from '../manager/ConfigManager';
import libraryconfig, { libraryconfigRow } from '../configs/libraryconfig';
import FetterData from '../data/record/FetterData';
import Hero from '../data/card/Hero';
import HeroIllustration from '../data/card/HeroIllustration';
import heroLogic from './HeroLogic';
import playerLogic from './PlayerLogic';
import GameProxy, { HeroModulBO, FetterAddBO } from "../proxy/GameProxy";

enum fetter_rank {
    normal = 1,
    middle = 5,
    high = 8,
    max = 20,
}

/* 图书馆 */
export class LibraryLogic extends BaseLogic {

    protected _fetters: { [key: number]: FetterData } = {};
    protected _usefullHero: { [key: string]: Hero } = {};
    protected _cacheCfgHero: { [key: string]: HeroIllustration } = {};
    protected _useHeroTimes: { [key: string]: number } = {};                   // 对其他玩家的英雄的雇佣次数 

    protected _activeFetterIds: { [key: number]: boolean } = {}; // 已激活的羁绊
    protected _libraryAddition: HeroModulBO = null;
    init(gm: IGameManager) {
        super.init(null, gm);
        this.initFetters();
    }

    resetAll() {

    }

    public getLibraryAddition() { return this._libraryAddition; }
    protected initFetters() {
        let fetterCount: number = this.getFetterCount();
        for (let i = 0; i < fetterCount; i++) {
            let fetterType = i + 1;
            let tmp = new FetterData(fetterType);
            this._fetters[fetterType] = tmp;
        }
    }
    // 更新羁绊信息
    public updateFetterInfo(info: FetterAddBO) {
        if (!info) { return; }
        if (Object.keys(this._fetters).length <= 0) { this.initFetters(); }

        this._libraryAddition = info.heroModulBO;
        let ids = info.effectConfs;
        if (ids && ids.length > 0) {
            this._activeFetterIds = {};
            for (let i = 0; i < ids.length; i++) { this._activeFetterIds[ids[i]] = true; }
        }
    }
    // 某个羁绊信息是否已激活
    public isFetterActive(fetterId: number) { return this._activeFetterIds[fetterId]; }
    // 获取英雄历史最高星级
    public getHeroTopStar(heroCofId: number) {
        let data = heroLogic.getRewardIllustration(heroCofId);
        let star: number = data ? data.topStar : 0;
        star = star > 0 ? star : 0;
        return star;
    }

    // 羁绊激活信息
    public async fettersReq() {
        let proto = await gm.request<FetterAddBO>(GameProxy.apilibragetFetterInfo);
        this.updateFetterInfo(proto);
    }
    // 激活某个羁绊信息中的一项
    public async activeFetterReq(fetterId: number) {
        let proto = await gm.request<FetterAddBO>(GameProxy.apilibraactiveFetter, fetterId);
        this.updateFetterInfo(proto);

        playerLogic.getPlayer().updateCommonAdd([this._libraryAddition]);
        playerLogic.getPlayer().setPowerDirty();
        heroLogic.updateHeroCommonAdd();
    }

    public getUsefullFetterHeros(cfgId: number): Hero[] {
        return [];
    }

    public getOwerUsefullHeroName(heroId: string): string {
        return '';
    }

    public getFetterData(type: number): FetterData {
        return this._fetters[type];
    }

    // 获取羁绊数量
    public getFetterCount(): number {
        let len = libraryconfig.length;
        return libraryconfig[len - 1].fettertype;
    }

    public getFetterCfgs(type: number): libraryconfigRow[] {
        let fetters = libraryconfig.filter((v, i, a) => {
            return v.fettertype == type;
        })
        return fetters;
    }

    public getFetterAddStr(cfg: libraryconfigRow): string[] {
        let buffs: string[] = [];
        let str: string = "";
        if (cfg.Hp) {
            str = `生命+${cfg.Hp}`;
            buffs.push(str)
        }
        if (cfg.Atk) {
            str = `攻击+${cfg.Atk}`;
            buffs.push(str)
        }
        if (cfg.Def) {
            str = `防御+${cfg.Def}`;
            buffs.push(str)
        }
        if (cfg.CritRate) {
            str = `暴击+${cfg.CritRate}`;
            buffs.push(str)
        }
        if (cfg.HarmAbsorbLv) {
            str = `吸血+${cfg.HarmAbsorbLv}`;
            buffs.push(str)
        }
        if (cfg.DodgeRate) {
            str = `闪避+${cfg.DodgeRate}`;
            buffs.push(str)
        }
        if (cfg.HitRate) {
            str = `命中+${cfg.HitRate}`;
            buffs.push(str)
        }
        if (cfg.Hpper) {
            str = `生命+${cfg.Hpper}%`;
            buffs.push(str)
        }
        if (cfg.Atkper) {
            str = `攻击+${cfg.Atkper}%`;
            buffs.push(str)
        }
        if (cfg.Defper) {
            str = `防御+${cfg.Defper}%`;
            buffs.push(str)
        }
        return buffs;
    }

    public fetterRedPoint(): boolean {
        let red: boolean = false;
        if (this._fetters) {
            let keys = Object.keys(this._fetters);
            if (keys) {
                for (let i = 0; i < keys.length; i++) {
                    let type = parseInt(keys[i]);
                    if (this.fetterRed(type)) {
                        red = true;
                        break;
                    }
                }
            }
        }
        return red;
    }

    public fetterRed(type: number): boolean {
        let red: boolean = false;
        let data = this._fetters[type];
        red = data ? data.hasCanFetter() : red;
        return red;
    }

    private betterRank(rank: number): number {
        let betterRank = fetter_rank.max;
        if (rank < fetter_rank.normal) {
            betterRank = fetter_rank.normal;
        } else if (rank < fetter_rank.middle) {
            betterRank = fetter_rank.middle;
        } else if (rank < fetter_rank.high) {
            betterRank = fetter_rank.high;
        }
        return betterRank;
    }
}

let libraryLogic = new LibraryLogic();
export default libraryLogic;