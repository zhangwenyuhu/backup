import BaseLogic from "./BaseLogic";
import EManager, { EName, EListener } from "../manager/EventManager";
import IGameManager from '../manager/IGameManager';
import gm from "../manager/GameManager";
import GameProxy from "../proxy/GameProxy";
import UnlockWrapper from "../view/widget/unlock/UnlockWrapper";
import { unlockConfigMap } from "../configs/unlockConfig";

export enum RedPointType {
    NONE = 1,

    HomeRight = 2,
    Town = 3,
    Pay = 4,

    Friend = 10,
    Friend_TabFriend = 11,
    Friend_TabMer = 12,
    Friend_Manager = 13,
    Friend_TabMer_Manage = 14,

    Assign = 20,
    Assign_Daily = 21,
    Assign_Week = 22,
    Assign_Main = 23,

    Mail = 31,
    Bag = 32,
    Bag_Stone = 33,
    Bag_All = 34,
    Bag_Good = 35,

    Town_XuanShang = 40,
    Town_XuanShang_Person = 41,
    Town_XuanShang_Team = 42,
    Town_Arena = 43,

    Pay_Vip = 50,

    Union = 60,
    Union_Hall = 61,
    Union_Hunt_Arrow = 62,
}

export let redpoints = {
    2: "HomeRight",
    3: "Town",
    4: "Pay",

    10: "HomeRight_Friend",
    11: "HomeRight_Friend_TabFriend",
    12: "HomeRight_Friend_TabMer",
    13: "HomeRight_Friend_Manager",
    14: "HomeRight_Friend_TabMer_Manage",

    20: "Assign",
    21: "Assign_Daily",
    22: "Assign_Week",
    23: "Assign_Main",

    31: "HomeRight_Mail",
    32: "HomeRight_Bag",
    33: "HomeRight_Bag_Stone",
    34: "HomeRight_Bag_All",
    35: "HomeRight_Bag_Good",

    40: "Town_XuanShang",
    41: "Town_XuanShang_Person",
    42: "Town_XuanShang_Team",
    43: "Town_Arena",

    50: "Pay_Vip",

    60: "Union",
    61: "Union_Hall",
    62: "Union_Hunt_Arrow",
}

let serverRed = {
    mail: "mail",
    arenaRecord: "arenaRecord",
    xs: "xs",
    friendApply: "friend_apply",
    // friendSend:"friend_point_send",
    friendRecv: "friend_point_recv",
    taskMain: "task_main",
    mercApply: "merc_new_apply",
    mercApplyAgree: "merc_new_apply_agree",
    guild: "guild_new_apply",
    guildNormalHunter: "guild_hunter_normal_ready",
    guildAdvanceHunter: "guild_hunter_advance_ready",
}

// 节点信息
class RedItem {
    name: string;        // 名称
    node?: cc.Node;      // ui
    func?: Function;     // 判断逻辑
    child?: any[];       // 子节点
    ignore?: boolean;    // 忽略显示
    serverRed?: boolean; // 服务器判断
}

/*
    1.添加红点后,默认自动刷新
    2.如果不需要自动刷新 则设置为事件驱动刷新
 */

const autoFreshSec = 2;

class RedPointLogic extends BaseLogic {

    protected _redItems: { [key: string]: RedItem } = {};  // 红点名对应 节点信息集合
    protected _redPool: RedItem[] = [];                // 节点集合
    protected _failueItem: RedItem[] = [];             // 加入失败的节点 刷新时重新加入
    protected _msgPool: { pointType: string, status: boolean }[] = [];  // 服务器推送的红点消息集合
    protected _commitPool: string[] = [];              // 推送到服务器的红点名称
    protected _second: number = 0;
    protected _eventList: { [key: string]: boolean } = {}; // 事件刷新的红点列表
    protected _eventListeners: EListener[] = [];

    init(gm: IGameManager) {
        super.init(null, gm);

        let listener = EManager.addEvent(EName.onFreshRed, (data: RedPointType) => {
            this.freshRedType(data);
        });
        this._eventListeners.push(listener);
    }

    // 设置为通过事件刷新
    public setEventFresh(type: RedPointType) {
        this._eventList[redpoints[type]] = true;
    }

    // 设置某个节点不显示
    public setRedPointIgnore(type: RedPointType, ignore: boolean) {
        let item = this.getItem(redpoints[type]);
        if (item) {
            item.ignore = ignore;
        }
    }

    public addRed(type: RedPointType, node: cc.Node) {
        if (type == RedPointType.NONE) { return; }
        if (redpoints[type]) {
            let item = this.getItem(redpoints[type])
            if (item) {
                item.node = node;
                this.freshRedItemServerRed(redpoints[type]);
                return;
            }
            this.registerRed({ name: redpoints[type], node: node });
            this.freshRedByName(redpoints[type]);
        } else {
            console.error("红点加入失败!!");
        }
    }
    public addFunc(type: RedPointType, func: Function) {
        if (redpoints[type]) {
            this.registerFunc({ name: redpoints[type], func: func });
            this.freshRedItemServerRed(redpoints[type]);
            //this.freshRedByName(redpoints[type]);
        }
    }

    // 刷新红点
    public freshAll(eventFresh: boolean = true) {
        this.reRegiste();
        for (let i = 0; i < this._redPool.length; i++) {
            let fresh = !this._eventList[this._redPool[i].name] || eventFresh;
            if (fresh) {
                //console.warn("开始刷新红点: " + this._redPool[i].name);
                this.freshRed(this._redPool[i]);
            }
        }

        this.printRedScreenShot();
    }

    // 刷新红点
    public freshRedType(type: RedPointType) {
        this.freshRedByName(redpoints[type]);
    }

    private freshRedByName(name: string) {
        let rootName: string = name;
        if (name.indexOf(`_`) > 0) {
            rootName = name.slice(0, name.indexOf(`_`));
        }
        this.freshRed(this.getItem(rootName));
    }

    public closeRedPoint(type: RedPointType) {
        console.log('关闭服务器红点: ' + redpoints[type]);
        this._commitPool.push(redpoints[type]);
        let item = this.getItem(redpoints[type]);
        if (item) { item.serverRed = false; }
    }

    // 添加节点信息
    private registerRed(data: { name: string, node: cc.Node, func?: Function }) {
        let item = this.getItem(data.name);
        if (item) {
            item.node = data.node ? data.node : item.node;
            if (data.func) {
                item.func = data.func;
            }
            return;
        }

        if (data.name.indexOf(`_`) > 0) {
            let end = data.name.lastIndexOf(`_`);
            let parentName = data.name.slice(0, end);
            let parentItem = this.getItem(parentName);
            if (parentItem) {
                let red = new RedItem;
                red.name = data.name;
                red.node = data.node;
                red.func = data.func;

                parentItem.child = parentItem.child ? parentItem.child : [];
                parentItem.child.push(red);
                this._redItems[red.name] = red;
                console.warn(`加入child红点: ${data.name}`);
            } else {
                //console.warn("父节点未找到");
                let red = new RedItem;
                red.name = data.name;
                red.node = data.node;
                red.func = data.func;
                this._failueItem.push(red);
            }
        } else {
            let red = new RedItem;
            red.name = data.name;
            red.node = data.node;
            red.func = data.func;
            this._redPool.push(red);
            this._redItems[red.name] = red;
            console.warn(`加入root红点: ${data.name}`);
        }
    }

    //添加册节点红点函数
    private registerFunc(data: { name: string, func: Function }) {
        let item = this.getItem(data.name);
        if (item) {
            item.func = data.func;
            item.serverRed = false;
        } else {
            //console.warn(`${data.name} 节点注册红点函数时 未找到该节点`);
            this.registerRed({ name: data.name, node: null, func: data.func });
        }
    }

    private getItem(name: string): RedItem {
        return this._redItems[name];
        if (name.indexOf(`_`) > 0) {
            for (let i = 0; i < this._redPool.length; i++) {
                let item = this.getItemInChild(this._redPool[i], name);
                if (item) { return item; }
            }
        } else {
            for (let i = 0; i < this._redPool.length; i++) {
                if (this._redPool[i].name === name) {
                    return this._redPool[i];
                }
            }
        }
        return null;
    }

    private getItemInChild(item: RedItem, itemName: string): RedItem {
        if (item && item.child) {
            for (let i = 0; i < item.child.length; i++) {
                if (itemName === item.child[i].name) {
                    return item.child[i];
                } else {
                    let result = this.getItemInChild(item.child[i], itemName);
                    if (result) { return result; }
                }
            }
            return null;
        }
        return null;
    }

    private freshRed(item: RedItem): boolean {
        let redUnlock: boolean = true;
        if (!item) {
            return false;
        }
        let result: boolean = false;
        if (!item.child) {
            result = item.func ? item.func() : false;
        } else {
            let len = item.child.length;
            for (let i = 0; i < len; i++) {
                let res = this.freshRed(item.child[i]);
                result = res ? res : result;
            }
        }
        result = item.serverRed ? true : result;
        result = item.ignore ? false : result;
        result = redUnlock ? result : false;
        if (item.node && cc.isValid(item.node)) {
            let preStatu = item.node.active;
            item.node.active = result;
            if (preStatu && !result) {
                this._commitPool.push(item.name);
            }
        }

        return result;
    }

    private reRegiste() {
        if (this._failueItem.length == 0) { return; }
        let num = this._failueItem.length;
        for (let i = 0; i < num; i++) {
            let item = this._failueItem.shift();
            this.registerRed({ name: item.name, node: item.node, func: item.func });
        }
    }

    public update() {

        this._second += 1;

        // 处理服务器推送过来的红点信息
        if (Object.keys(this._redItems).length >= 5) {
            let len = this._msgPool.length;
            for (let i = 0; i < len; i++) {
                let msg = this._msgPool.shift();
                if (!this.onRedPoint(msg.pointType, msg.status)) {
                    this._msgPool.push(msg);
                }
            }
            if (len > 0) {
                this.freshAll(false);
            }
        }

        // 提交红点关闭信息
        if (this._commitPool.length != 0) {
            this.commitRedPointNegative(this._commitPool);
            this._commitPool = [];
        }

        if (this._second >= autoFreshSec) {
            this.freshAll(false);
            this._second = 0;
        }
    }

    public onServerMessage(msg: string, data?: any) {
        console.log("RedPoint Message:");
        console.log(msg);
        /*
        {
            "code":1,   // 1 服务端首次红点检测  2 红点变更 200001 微服务红点推送
            "msg":[
                {"pointType":"xs","status":false},
                {"pointType":"friend_apply","status":false},
                {"pointType":"guild_hunter_noraml_ready","status":false},
                {"pointType":"guild_hunter_advance_ready","status":false},
                {"pointType":"mail","status":false}
            ]
        }
        */
        if (msg) {
            let content = JSON.parse(msg);
            let reds: { pointType: string, status: boolean }[] = content.msg;
            reds.forEach((v, i, a) => {
                if (v.status) {
                    this._msgPool.push(v);
                }
            });
        }
        if (data) {
            this._msgPool = data;
        }

        for (let i = 0; i < this._msgPool.length; i++) {
            if (this._msgPool[i].pointType == serverRed.xs) {
                let unlock = UnlockWrapper.isUnlock(unlockConfigMap.悬赏大厅);
                if (!unlock) {
                    this._msgPool[i].status = false;
                }
            } else if (this._msgPool[i].pointType == serverRed.taskMain) {
                EManager.emit(EName.onFreshPanel, 'AssignmentPanel');
            }
        }

        this.freshAll();
    }

    private commitRedPointNegative(name: string[]) {
        let serverReds: string[] = [];
        let len = name.length;
        for (let j = 0; j < len; j++) {
            let type = Object.keys(redpoints).find((v, i, a) => { return redpoints[v] === name[j]; });
            let red = this.typeToServerRed(type);
            serverReds.pushList(red);
        }

        if (serverReds.length > 0) {
            this.redNegativeCommit(serverReds);
        }
    }

    private typeToServerRed(typeStr: string): string[] {
        let sRed: string[] = [];
        let type: number = parseInt(typeStr);
        switch (type) {
            case RedPointType.Mail:
                sRed.push(serverRed.mail);
                break;
            case RedPointType.Friend_Manager:
                sRed.push(serverRed.friendApply);
                break;
            case RedPointType.Friend_TabFriend:
                sRed.push(serverRed.friendRecv);
                // sRed.push(serverRed.friendSend);
                break;
            case RedPointType.Friend_TabMer_Manage:
                sRed.push(serverRed.mercApply);
                break;
            case RedPointType.Friend_TabMer:
                sRed.push(serverRed.mercApplyAgree);
                break;
            case RedPointType.Assign_Main:
                sRed.push(serverRed.taskMain);
                break;
            case RedPointType.Town:
                sRed.push(serverRed.xs);
                break;
            case RedPointType.Town_Arena:
                sRed.push(serverRed.arenaRecord);
                break;
            default:
                break;
        }
        return sRed;
    }

    async redNegativeCommit(name: string[]) {
        if (name.length == 0) { return; }
        let proto = await gm.request<Object>(GameProxy.apiRolecloseRP, name);
    }

    private onRedPoint(type: string, statu: boolean) {
        let result: boolean = true;
        switch (type) {
            case serverRed.mail:
                result = this.setRedItemServerRed(redpoints[RedPointType.Mail], statu);
                break;
            case serverRed.arenaRecord:
                result = this.setRedItemServerRed(redpoints[RedPointType.Town_Arena], statu);
                break;
            case serverRed.friendApply:
                result = this.setRedItemServerRed(redpoints[RedPointType.Friend_Manager], statu);
                break;
            case serverRed.friendRecv:
                result = this.setRedItemServerRed(redpoints[RedPointType.Friend_TabFriend], statu);
                break;
            // case serverRed.friendSend:
            //     result = this.setRedItemServerRed(redpoints[RedPointType.Friend_TabFriend], statu);
            //     break;
            case serverRed.guild:
                break;
            case serverRed.guildAdvanceHunter:
                result = this.setRedItemServerRed(redpoints[RedPointType.Union_Hall], statu);
                break;
            case serverRed.guildNormalHunter:
                result = this.setRedItemServerRed(redpoints[RedPointType.Union_Hall], statu);
                break;
            case serverRed.mercApply:
                result = this.setRedItemServerRed(redpoints[RedPointType.Friend_TabMer_Manage], statu);
                break;
            case serverRed.mercApplyAgree:
                result = this.setRedItemServerRed(redpoints[RedPointType.Friend_TabMer], statu);
                break;
            case serverRed.taskMain:
                result = this.setRedItemServerRed(redpoints[RedPointType.Assign_Main], statu);
                break;
            case serverRed.xs:
                result = this.setRedItemServerRed(redpoints[RedPointType.Town_XuanShang], statu);
                break;
            default:
                break;
        }
        return result;
    }

    private getParentName(name: string) {
        let parentName: string = name;
        let nameArr: string[] = [];
        if (name.indexOf(`_`) > 0) {
            let tmpArr = name.split(`_`);
            tmpArr.pop();
            let len = tmpArr.length;
            let str = ""
            for (let i = 0; i < len; i++) {
                if (i == 0) {
                    str = `${tmpArr[i]}`;
                } else {
                    str += `_${tmpArr[i]}`;
                }
            }
            parentName = str;
        }
        return parentName;
    }

    private freshRedItemServerRed(name: string) {
        //let parentName = this.getParentName(name);
        let item = this._redItems[name];
        if (item) {
            if (item.node && item.func) {
                this.setRedItemServerRed(name, false);
            }
        }
    }

    private setRedItemServerRed(name: string, statu: boolean) {
        let reds = this.getListItem(name);
        reds.forEach((v, i, a) => {
            if (this._redItems[v]) {
                this._redItems[v].serverRed = statu;
                console.log("serverRed to false: " + v);
            }
        })
        return reds.length > 0;
    }

    private getListItem(name: string): string[] {
        let nameArr: string[] = [];
        if (name.indexOf(`_`) > 0) {
            let tmpArr = name.split(`_`);
            let len = tmpArr.length;
            let str = ""
            for (let i = 0; i < len; i++) {
                str = i == 0 ? tmpArr[i] : `${str}_${tmpArr[i]}`;
                nameArr.push(str);
            }
        } else {
            nameArr.push(name);
        }
        return nameArr;
    }

    private printRedScreenShot() {
        return;
        console.log(` ---- RedPoint begin ----`);
        Object.keys(this._redItems).forEach((v, i, a) => {
            let item = this._redItems[v];
            if (item.node) {
                console.log(`${v} : ${item.node.active}`);
            }
        });
        console.log(` ---- RedPoint end   ----`);
    }
}

let redPointLogic = new RedPointLogic();
export default redPointLogic;