
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import GameProxy, { GJourneyBO, ResourceVO, GJourneyHitReq, RankListReq, RankListVO, RankVO, CloudObjectReq, GJourneyCompleteRecvReq } from "../proxy/GameProxy";
import UdgMonsterData from "../data/union/UdgMonsterData";
import factiongamescoreconfig, { factiongamescoreconfigRow } from "../configs/factiongamescoreconfig";
import gm from "../manager/GameManager";
import { factiongamethemeconfigRow } from "../configs/factiongamethemeconfig";
import cm from "../manager/ConfigManager";
import unionLogic from "./UnionLogic";
import { defaultConfigMap } from "../configs/defaultConfig";
import RankData from "../data/record/RankData";
import playerLogic from "./PlayerLogic";
import timeUtils from "../utils/TimeUtils";
import heroConfig from "../configs/heroConfig";
import factiongameconfig from "../configs/factiongameconfig";
import { GoodId } from "../data/card/Good";
import SeedUtils from "../utils/SeedUtils";
import EManager, { EName } from "../manager/EventManager";

const DungeonSortSec: number = 2 * 3600 * 1000;
const DaySec: number = 24 * 3600 * 1000;
const UdgCircleDay: number = 7;

/* 公会副本 */
export class UnionDungeonLogic extends BaseLogic {

    protected _initUdgNpc: boolean = false;
    protected _dungeonDay: number = 0; // 当前第几天
    protected _endTs: number = 0;
    protected _dungeonLv: number = 0;
    protected _todayUnionScore: number = 0;
    protected _totalUnionScore: number = 0;
    protected _theme: number = 0;
    protected _npcInfo: { [key: number]: UdgMonsterData } = {};
    protected _levels: string[] = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];

    // 重置使用参数
    protected _preTs: number = 0;
    protected _needReset: boolean = false;
    protected _inResetNpc: boolean = false;
    protected _reReqTimes: number = 3;

    // 敌对信息
    protected _enemyId: number = 0;             //  敌对公会id
    protected _enemyTotalScore: number = 0;     //  敌对公会总积分

    // 公会副本个人信息
    protected _todayFightTimes: number = 0;     // 今日已攻击次数
    protected _refreshTimesTs: number = 0;      // 挑战次数刷新时间
    protected _dungeonScoreInfo: { [key: number]: number } = {};        // 个人贡献分 day:score
    protected _passRewardRecvInfo: { [key: number]: boolean } = {};      //成就奖励领取信息 level:recv

    public udgScoreCof: factiongamescoreconfigRow = null;
    public udgThemeCof: factiongamethemeconfigRow = null;

    // rank
    protected _udgRank: { [key: number]: RankData } = {};      // 贡献榜
    protected _udgFightRank: { [key: number]: RankData } = {}; // 竞争榜
    protected _udgMyRank: RankData = null;
    protected _udgFightMyRank: RankData = null;

    // 副本怪物数据
    protected _udgNpc: { [key: number]: string } = {};
    protected _udgClear: { [key: string]: number[] } = {};

    // 上周副本数据
    protected _lastUdgWin: boolean = false;
    protected _lastEnemyId: number = 0;
    protected _lastEndTs: number = 0;
    protected _lastTop3: RankData[] = [];
    protected _lastMyUnionScore: number = 0;
    protected _lastEnemyScore: number = 0;

    // 讨伐礼包领取信息
    protected _udgBox: { [key: number]: { index: number, roleId: string, boxId: number }[] } = {};
    protected _maxBoxCount: number = 30;

    // 
    protected _seed: SeedUtils = null;
    protected _boxPos: number[][] = [];

    // 本期是否弹出周报
    protected _udgReport: { [key: string]: boolean } = {};
    init(gm: IGameManager) {
        super.init(null, gm);

        this._npcInfo = {};
        for (let i = 1; i <= 5; i++) {
            let tmp = new UdgMonsterData(i);
            this._npcInfo[i] = tmp;
        }
    }

    public clearUdgData() {
        this._initUdgNpc = false;
    }

    // 是否可以进入公会副本
    public async canAccessUdg() {
        return { result: true, msg: '' };
        if (this._endTs <= 0) {
            await udgLogic.unionDungeonReq();
        }
        if (this._endTs <= 0) { return { result: false, msg: '公会副本未开启' }; }

        let mem = unionLogic.getUnion().getMember(playerLogic.getPlayer().getRoleId());
        let ts: number = mem.getJoinTs();
        if (this._endTs - ts > UdgCircleDay * DaySec) { return { result: true, msg: '' }; }
        let leftSec: number = this._endTs - ts;
        let day: number = Math.ceil(leftSec / DaySec);
        return { result: false, msg: `${day}天后可参与公会副本玩法` }
    }

    updatePer() {
        this._checkResetUdgNpc();
    }

    // 跨天重置公会副本怪物数据
    protected _checkResetUdgNpc() {
        if (playerLogic.getPlayer().getUnionId() <= 0) { return; }
        let nowTs: number = gm.getCurrentTimestamp();
        if (this._preTs <= 0) { this._preTs = nowTs; return; }
        let now = new Date(nowTs);
        let pre = new Date(this._preTs);
        let needReset: boolean = now.getUTCDate() != pre.getUTCDate();
        if (needReset) { this._needReset = true; }
        if (this._reReqTimes <= 0) { this._needReset = false; }
        if (needReset || (!this._inResetNpc && this._needReset)) {
            console.log(`公会副本怪物数据需要重置:`);
            this._initUdgNpc = false;
            this._inResetNpc = true;
            this.unionDungeonReq();
            setTimeout(() => {
                this._inResetNpc = false;
            }, 5000);
            this._preTs = nowTs;
            this._reReqTimes -= 1;
        }
    }

    // 是否可以领取副本挑战奖励
    public canRecvUdgPassReward(level: number) {
        //if (!this._dungeonScoreInfo) { return false; }
        //let keys = Object.keys(this._dungeonScoreInfo);
        //let join = keys.some((v, i, a) => { return this._dungeonScoreInfo[parseInt(v)] > 0; })
        if (level == this._dungeonLv) {
            let arr = [1, 2, 3, 4, 5];
            let pass = arr.every((v, i, a) => { return this._npcInfo[v].getNpcProg() >= 100; })
            return pass;
        }
        return this._dungeonLv > level;
    }
    public getUdgBoxMaxCount() { return this._maxBoxCount; }
    public getUdgLv() { return this._dungeonLv; }
    public getUdgLvTitle(lv: number) { return this._levels[lv - 1] || this._levels[0]; }
    // 上次本公会积分
    public lastMyUnionScore() { return this._lastMyUnionScore; }
    // 上次敌对公会积分
    public lastEnemyScore() { return this._lastEnemyScore; }
    // 上周战报结果
    public lastUdgFightWin() { return this._lastUdgWin; }
    // 上周截止时间
    public lastEndTs() {
        if (this._lastEndTs > 0) { return this._endTs - 7 * 24 * 3600 * 1000; }
        return this._lastEndTs;
    }
    // 上周战斗公会id
    public getLastEnemyId() { return this._lastEnemyId; }
    // 本周战斗公会ID
    public getEnemyId() { return this._enemyId; }
    // 本次副本节点信息
    public getDungeonMonster(index: number) { return this._npcInfo[index]; }
    public isAllComplete() {
        let all: boolean = true;
        for (let i = 1; i <= 5; i++) {
            if (this._npcInfo[i]) {
                if (this._npcInfo[i].getNpcProg() < 100) { all = false; }
            }
        }
        return all;
    }
    // 是否结算中
    public isDungeonSort() {
        let nowTs: number = gm.getCurrentTimestamp();
        return this._endTs - nowTs < DungeonSortSec;
    }
    // 今日副本挑战剩余时间
    public getLeftSec() { return this._endTs - gm.getCurrentTimestamp(); }
    // 今日挑战次数
    public getTodayFightTimes() { return this._todayFightTimes; }
    // 公会副本积分
    public getUdgTotalScore(bEnemy?: boolean) { return bEnemy ? this._enemyTotalScore : this._totalUnionScore; }
    // 公会副本是否解锁
    public isUdgUnlock() {
        let data = unionLogic.getUnion();
        let limit = defaultConfigMap.GuildDungeonLimit.value;
        return data.getLevel() >= limit;
    }
    // 公会副本挑战次数上限
    public getUdgFightMaxTimes() { return defaultConfigMap.GuildDungeonAttackNum.value; }
    // 副本通关奖励是否领取
    public isUdgPassRewardRecv(lv: number) { return this._passRewardRecvInfo[lv] ? true : false; }

    public getRankLen(all: boolean) {
        if (all) { return Object.keys(this._udgFightRank).length; }
        return Object.keys(this._udgRank).length;
    }
    public getRankData(all: boolean, rank: number) {
        if (all) { return this._udgFightRank[rank]; }
        return this._udgRank[rank];
    }
    public getLastTop3() { return this._lastTop3; }

    public getMyRank(all: boolean) { return all ? this._udgFightMyRank : this._udgMyRank; }

    // 请求公会副本信息
    public async unionDungeonReq() {
        let proto = await this._gm.request<GJourneyBO>(GameProxy.apiguild_journeyfindGJourney);
        this._initDungeonData(proto);

        if (!this._initUdgNpc) {
            await this.udgNpcReq();
            if (!this._udgNpcCloudValid()) {
                await this._initUdgMonsterId();
            }
            this._updateUdgMonster(this._udgNpc);
            this._initUdgNpc = true;
            this._lastTop3 = [];
            EManager.emit(EName.onFreshPanel, 'UnionDungeonMainPanel');
        }

        if (!this._udgNpcCloudValid()) { console.error('公会副本怪物数据未生成'); }
    }
    // 请求公会副本简单信息
    public async unionDungeonSimpleReq() {
        let proto = await this._gm.request<GJourneyBO>(GameProxy.apiguild_journeyfindSimpleGJourney);
        this._updateUnionDungeonSimpleData(proto);
    }
    // 领取公会副本通关奖励
    public async recvPassRewardReq(lv: number) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiguild_journeyrecvOncePassReward, lv);
        this._recvPassReward(lv);
        return proto;
    }
    // 提交公会副本成绩
    public async commitDungeonBattleResult(index: number, diff: number, boss: number, normal: number) {
        let param = new GJourneyHitReq;
        param.bossIndex = index;
        param.difficulty = diff;
        param.killBoss = boss;
        param.killNormal = normal;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiguild_journeysubmitJourney, param);

        // 更新挑战次数和对应怪物节点积分
        this._todayFightTimes += 1;
        let score = this.getKillScore(diff, boss, normal);
        this._npcInfo[index].score += score;
        this._totalUnionScore += score;

        return proto;
    }
    // 公会副本排行榜 
    public async udgRankReq(all: boolean, start: number, end: number) {
        let type: number = all ? 17 : 16;
        let param = new RankListReq;
        param.customKey = this._getRankCustomKey(all);
        param.rankType = type;
        param.start = start;
        param.end = end;

        let proto = await this._gm.request<RankListVO>(GameProxy.apirankmyGameRank, param);
        if (proto) {
            if (all) {
                this._udgFightMyRank = new RankData(proto.myRank);
            } else {
                this._udgMyRank = new RankData(proto.myRank);
            }
            this._updateRankData(all, proto.rankDetail);
        }
    }

    // 上周前3
    public async lastUdgTop3Req() {
        if (this._lastTop3.length > 0) { return; }
        let myUnionId = playerLogic.getPlayer().getUnionId();
        let param = new RankListReq;
        //param.customKey = `${myUnionId}_${this._lastEndTs}`;
        param.customKey = this._getRankCustomKeyEx(true, myUnionId, this._lastEnemyId);
        param.rankType = 17;
        param.start = 0;
        param.end = 2;

        let proto = await this._gm.request<RankListVO>(GameProxy.apirankmyGameRank, param);
        if (proto && proto.rankDetail) {
            this._lastTop3 = [];
            for (let i = 0; i < proto.rankDetail.length; i++) {
                let tmp = new RankData(proto.rankDetail[i]);
                this._lastTop3.push(tmp);
            }
        }
    }

    // 初始化公会副本信息
    protected _initDungeonData(data: GJourneyBO) {
        if (!data) { return; }
        if (data.day != this._dungeonDay) { this._needReset = false; }
        this._dungeonDay = data.day;
        this._dungeonLv = data.journeyLv;
        this.udgScoreCof = factiongamescoreconfig[this._dungeonLv - 1];
        this._endTs = data.endTs;
        this._todayUnionScore = data.score;
        this._totalUnionScore = data.totalScore;
        this._theme = data.theme;
        this.udgThemeCof = cm.getUdgThemeConfig(this._theme);
        this._updateBossData(data.dayBossScoreMap);

        this._enemyId = data.rivalGuildId;
        this._enemyTotalScore = data.rivalTotalScore;

        this._todayFightTimes = data.roleInfo.count;
        this._refreshTimesTs = data.roleInfo.countFreshTs;
        this._dungeonScoreInfo = data.roleInfo.dayScoreMap as any;
        this._passRewardRecvInfo = data.roleInfo.onceRecvInfo as any;

        this._lastUdgWin = data.preWin;
        this._lastEnemyId = data.preRivalGuildId;
        this._lastEndTs = data.preCulEndTs;
        this._lastMyUnionScore = data.preTotalScore;
        this._lastEnemyScore = data.preRivalTotalScore;

        this._udgBox = data.completeBossRecvIds as any;
        this._maxBoxCount = data.memberCount + 5;

        this._updateUdgBoxPos(data.seed);
    }

    protected _updateUnionDungeonSimpleData(data: GJourneyBO) {
        if (!data) { return; }
        if (data.day != this._dungeonDay) { this._needReset = false; }
        this._dungeonDay = data.day;
        this._dungeonLv = data.journeyLv;
        this.udgScoreCof = factiongamescoreconfig[this._dungeonLv - 1];
        this._endTs = data.endTs;
        this._todayUnionScore = data.score;
        this._totalUnionScore = data.totalScore;
        this._theme = data.theme;
        this.udgThemeCof = cm.getUdgThemeConfig(this._theme);
        this._updateBossData(data.dayBossScoreMap);

        this._enemyId = data.rivalGuildId;
        this._enemyTotalScore = data.rivalTotalScore;
    }

    protected _updateBossData(data: object) {
        if (!data) { return; }
        let keys = Object.keys(data);
        if (!keys || keys.length <= 0) { return; }
        for (let i = 0; i < keys.length; i++) {
            let id: number = parseInt(keys[i]);
            if (this._npcInfo[id]) {
                this._npcInfo[id].score = data[keys[i]];
            }
        }
    }

    protected _recvPassReward(level: number) {
        this._passRewardRecvInfo[level] = true;
    }

    protected _updateRankData(all: boolean, rank: RankVO[]) {
        for (let i = 0; i < rank.length; i++) {
            if (all) {
                if (!this._udgFightRank) { this._udgFightRank = {}; }
                let num = rank[i].no;
                if (this._udgFightRank[num]) {
                    this._udgFightRank[num].updateRankData(rank[i]);
                } else {
                    this._udgFightRank[num] = new RankData(rank[i]);
                }
            } else {
                if (!this._udgRank) { this._udgRank = {}; }
                let num = rank[i].no;
                if (this._udgRank[num]) {
                    this._udgRank[num].updateRankData(rank[i]);
                } else {
                    this._udgRank[num] = new RankData(rank[i]);
                }
            }
        }
    }

    protected _getRankCustomKey(all: boolean) {
        let myUnionId = playerLogic.getPlayer().getUnionId();
        if (!all) { return `${myUnionId}_${this._endTs}`; }
        let key: string = `${this._enemyId}_${myUnionId}`;
        if (myUnionId > this._enemyId) { key = `${myUnionId}_${this._enemyId}` }
        key += `_${this._endTs}`;
        return key;
    }

    protected _getRankCustomKeyEx(all: boolean, myUnionId: number, enemyId: number) {
        if (!all) { return `${myUnionId}_${this.lastEndTs}`; }
        let key: string = `${enemyId}_${myUnionId}`;
        if (myUnionId > enemyId) { key = `${myUnionId}_${enemyId}` }
        key += `_${this._lastEndTs}`;
        return key;
    }

    // 保存副本怪物信息
    protected async saveUdgNpc(data: { key: number, ids: string }[]) {
        let param = new CloudObjectReq;
        // 副本怪物每日更换,有效期1天
        param.expire = 24 * 3600 * 1000;
        param.key = this._getUdgCloudKey();
        console.log(`公会副本保存怪物信息key: ` + param.key);

        let obj: { [key: number]: string } = {};
        for (let i = 0; i < data.length; i++) { obj[data[i].key] = data[i].ids; }
        param.objData = obj;

        let proto = await this._gm.request<{ [key: string]: any }>(GameProxy.apiutilsetCloudObject, [param]);
        if (proto) { this._updateUdgNpcCloud(proto); }
    }
    // 获取副本怪物信息
    protected async udgNpcReq() {
        let key: string = this._getUdgCloudKey();
        console.log(`获取公会副本怪物信息key: ` + key);
        let proto = await this._gm.request<{ [key: string]: any }>(GameProxy.apiutilgetCloudObject, [key]);
        if (proto) { this._updateUdgNpcCloud(proto); }
    }

    protected _updateUdgNpcCloud(data: { [key: string]: any }) {
        console.log('更新本地怪物数据:');
        this._udgNpc = data[this._getUdgCloudKey()];
        this._printUdgNpc();
    }
    protected _printUdgNpc() {
        if (!this._udgNpc) { console.log(`udg monster data is null `); return; }
        let keys = Object.keys(this._udgNpc);
        let desc: string = ``;
        for (let i = 0; i < keys.length; i++) {
            desc += `${keys[i]}:${this._udgNpc[keys[i]]} _ `;
        }
        console.log(`udg monster: ` + desc);
    }

    // 副本怪物数据云存储Key
    protected _getUdgCloudKey() {
        let roleId: string = playerLogic.getPlayer().getRoleId();
        let endTsStr: string = timeUtils.formatTimeToStr2(this._endTs);
        let key: string = `udg_${this.myUnionId()}_${roleId}_${endTsStr}_${this._dungeonDay}_${this._theme}`;
        return key;
    }

    protected myUnionId() { return playerLogic.getPlayer().getUnionId(); }

    // 保存副本扫荡信息
    protected async _saveUdgClear() {
        let param = new CloudObjectReq;
        // 副本怪物每日更换,有效期1天
        param.expire = 24 * 3600 * 1000;
        param.key = this._getUdgClearCloudKey();
        param.objData = this._udgClear;

        let proto = await this._gm.request<{ [key: string]: any }>(GameProxy.apiutilsetCloudObject, [param]);
        if (proto) { this._updateUdgClearCloud(proto); }
    }
    // 获取副本扫荡信息
    protected async _udgClearResultReq() {
        let key: string = this._getUdgClearCloudKey();
        let proto = await this._gm.request<{ [key: string]: any }>(GameProxy.apiutilgetCloudObject, [key]);
        if (proto) { this._updateUdgClearCloud(proto); }
    }

    protected _updateUdgClearCloud(data: { [key: string]: any }) {
        this._udgClear = data[this._getUdgClearCloudKey()];
    }

    // 副本挑战最高纪录云存储key
    protected _getUdgClearCloudKey() {
        let roleId: string = playerLogic.getPlayer().getRoleId();
        let endTsStr: string = timeUtils.formatTimeToStr2(this._endTs);
        let key: string = `udg_clear_${this.myUnionId()}_${roleId}_${endTsStr}_${this._dungeonDay}_${this._theme}`;
        return key;
    }

    // 生成每日的公会副本怪物数据
    protected async _initUdgMonsterId() {
        this._udgNpc = {};
        if (!this.udgThemeCof) { console.error('副本主题配置信息未找到'); }

        console.log('开始随生成机公会副本怪物信息');
        // 配置的副本NPC
        let npc: number[] = this.udgThemeCof.monster.map((v, i, a) => { return v; });
        npc = this._shuffArr(npc, this.myUnionId());

        // 随机副本怪物
        let data: { key: number, ids: string }[] = [];
        for (let i = 0; i < npc.length; i++) {
            let randomNpcIds = this._rand4Npc(this.udgThemeCof.camp, npc[i]);
            randomNpcIds.push(npc[i]);

            let key: number = i + 1;
            let ids: string = randomNpcIds.join(';');
            data.push({ key: key, ids: ids });
        }
        await this.saveUdgNpc(data);
    }

    protected _rand4Npc(camp: number, ignoreId: number) {
        let cof = heroConfig.filter((v, i, a) => { return camp == v.Faction && v.Id != ignoreId && v.Type == 0; })
        let ids = cof.map((v, i, a) => { return v.Id; })
        ids = this._shuffArr(ids, ignoreId + this.myUnionId());
        let ret = ids.slice(0, 4);
        return ret;
    }

    // arr数组元素随机打乱
    protected _shuffArr(arr: number[], seed: number = 0) {
        let tempRand = new SeedUtils(seed);
        for (let i = arr.length; i > 0; i--) {
            let index = 0;
            if (seed > 0) {
                index = Math.floor(tempRand.random() * i);
            } else {
                index = Math.floor(Math.random() * i);
            }
            let tmp = arr[i - 1];
            arr[i - 1] = arr[index];
            arr[index] = tmp;
        }
        return arr;
    }

    // 保存的副本数据是否有效
    protected _udgNpcCloudValid() {
        if (!this._udgNpc) { return false; }
        for (let i = 0; i < 5; i++) {
            let data = this._udgNpc[i + 1];
            if (!data || data.length <= 0) { return false; }
        }
        return true;
    }

    public getUdgCof(diff: number) {
        let cof = factiongameconfig.find((a) => { return a.stage == this._dungeonLv && a.difficulty == diff; })
        return cof;
    }

    // 创建怪物详细数据
    protected _updateUdgMonster(data: { [key: number]: string }) {
        for (let i = 1; i <= 5; i++) {
            this._npcInfo[i].updateMonster(data[i]);
        }
    }

    // 获取公会副本扫荡结果
    public getUdgClearData(index: number, diff: number): number[] {
        let key: string = `${index}${diff}`;
        return this._udgClear ? this._udgClear[key] : [];
    }
    // 请求公会副本扫荡战斗结果
    public async udgClearResultReq(index: number, diff: number) {
        let data = this.getUdgClearData(index, diff);
        if (!data || data.length < 2) {
            await this._udgClearResultReq();
        }
    }
    // 提交公会副本战斗结果
    public async commitUdgClearResult(index: number, diff: number, boss: number, normal: number) {
        if (!this._canCommitResult(index, diff, boss, normal)) { return; }

        console.log(`公会副本挑战结果提交云存储: `);
        let key: string = `${index}${diff}`;
        if (!this._udgClear) { this._udgClear = {}; }
        this._udgClear[key] = [boss, normal];
        await udgLogic._saveUdgClear();
    }

    protected _canCommitResult(index: number, diff: number, boss: number, normal: number): boolean {
        let key: string = `${index}${diff}`;
        if (!this._udgClear || !this._udgClear[key]) { return true; }
        let data = this._udgClear[key];
        if (data.length < 2) { return true; }

        let score = udgLogic.getKillScore(diff, boss, normal);
        let cur = udgLogic.getKillScore(diff, boss, normal);
        return cur > score;
    }

    // 获取公会副本击杀可得到的积分
    public getKillScore(diff: number, boss: number, normal: number) {
        let cof = udgLogic.getUdgCof(diff);
        return cof ? (cof.killscore * normal + cof.bosskillscore * boss) : 0;
    }
    // 获取公会副本击杀可得到的公会币
    public getKillCoin(diff: number, boss: number, normal: number) {
        let cof = udgLogic.getUdgCof(diff);
        return cof ? (cof.killcoin * normal + cof.bosskillcoin * boss) : 0;
    }
    // 获取公会副本击杀奖励
    public getUdgFightReward(diff: number, boss: number, normal: number): number[][] {
        let num = this.getKillCoin(diff, boss, normal);
        return [[GoodId.UnionCoin, num]];
    }

    // 讨伐宝箱信息
    public getUdgBox(index: number, pos: number) {
        if (this._udgBox[index]) {
            let data = this._udgBox[index].find((a) => { return a.index == pos; })
            return data;
        }
        return null;
    }
    // 领取讨伐礼包奖励
    public async recvUdgBoxReq(index: number, pos: number) {
        let param = new GJourneyCompleteRecvReq;
        param.bossIndex = index;
        param.rewardIndex = pos;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiguild_journeyrecvCompleteReward, param);
        gm.getReward(proto);

        let boxId: number = proto.extra[0] as any;
        let roleId: string = playerLogic.getPlayer().getRoleId();
        this._updateUdgBox(index, pos, boxId, roleId);

        let data = this.getDungeonMonster(index);
        //if (data) { data.giftRecvied = true; }
    }

    // 对应怪物的宝箱是否领取
    public isRecvBox(index: number) {
        if (!this._udgBox) { return true; }
        if (!this._udgBox[index]) { return true; }

        let roleId = playerLogic.getPlayer().getRoleId();
        let data = this._udgBox[index].find((a) => { return a.roleId == roleId; })
        return data ? true : false;
    }

    protected _updateUdgBox(index: number, pos: number, boxId: number, roleId: string) {
        if (!this._udgBox) { this._udgBox = {}; }
        if (!this._udgBox[index]) { this._udgBox[index] = []; }

        let data = this._udgBox[index].find((a) => { return a.index == pos; })
        if (!data) {
            this._udgBox[index].push({ index: pos, roleId: roleId, boxId: boxId });
        }
    }

    protected _updateUdgBoxPos(seed: number) {
        // 随机5个怪物对应的宝箱列表的位置
        seed = seed >= 0 ? seed : 0;
        seed = seed <= 0 ? this._dungeonDay : seed;
        this._seed = new SeedUtils(seed);
        this._boxPos = [];

        for (let i = 0; i < 5; i++) {
            let boxPos: number[] = [];
            for (let i = 0; i < this._maxBoxCount; i++) { boxPos.push(i + 1); }
            for (let j = this._maxBoxCount; j > 0; j--) {
                let index = Math.floor(this._seed.random() * j);
                let tmp = boxPos[j - 1];
                boxPos[j - 1] = boxPos[index];
                boxPos[index] = tmp;
            }
            this._boxPos.push(boxPos);
        }

        let res: number = 0;
    }

    // 获取对应怪物宝箱列表中的第index个宝箱的位置
    public getUdgBoxPos(bossIndex: number, index: number) {
        return this._boxPos[bossIndex - 1][index];
    }

    protected _getReportCloudKey() {
        let roleId: string = playerLogic.getPlayer().getRoleId();
        return `${roleId}_udg_report`;
    }
    // 保存本期是否弹出过战报
    public async updateUdgReportStateReq(report: boolean) {
        if (this._lastEndTs <= 0) { return; }
        let param = new CloudObjectReq;
        param.expire = 0;
        param.key = this._getReportCloudKey();

        let obj: { [key: string]: boolean } = {};
        let key = timeUtils.formatTimeToStr2(this._lastEndTs);
        obj[key] = report;
        param.objData = obj;
        let proto = await this._gm.request<{ [key: string]: any }>(GameProxy.apiutilsetCloudObject, [param]);
        if (!this._udgReport) { this._udgReport = {}; }
        if (proto) { this._udgReport = proto[this._getReportCloudKey()]; }
    }
    // 获取本期是否弹出过战报
    public async getUdgReportStateReq() {
        let key: string = this._getReportCloudKey();
        let proto = await this._gm.request<{ [key: string]: any }>(GameProxy.apiutilgetCloudObject, [key]);
        if (proto) { this._udgReport = proto[key] || {}; }
    }
    // 本期是否弹出过战报
    public isReported() {
        if (this._lastEndTs <= 0) { return true; }
        let key: string = timeUtils.formatTimeToStr2(this._lastEndTs);
        return this._udgReport ? this._udgReport[key] : false;
    }
    // 是否有怪物宝箱可以开启
    public hasBoxCanOpen(): boolean {
        let has: boolean = false;
        let arr = [1, 2, 3, 4, 5];
        has = arr.some((v, i, a) => {
            let data = this._npcInfo[i];
            return data && !data.giftRecvied && data.getNpcProg() >= 100;
        })
        return has;
    }
}

let udgLogic = new UnionDungeonLogic();
export default udgLogic;