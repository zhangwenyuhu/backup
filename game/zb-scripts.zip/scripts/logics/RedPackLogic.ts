import {
    ResourceVO,
    RedPackVO,
    RedPackTaskInfoVO
} from './../proxy/GameProxy';
import BaseLogic from "./BaseLogic";
import GameProxy from "../proxy/GameProxy";
import IGameManager from '../manager/IGameManager';
import RedPack from '../data/union/RedPack';
import EManager, { EName } from '../manager/EventManager';
import cm from '../manager/ConfigManager';
import RedTask, { RedTaskType } from '../data/assignment/RedTask';
import unionLogic from './UnionLogic';
import redPointLogic, { RedPointType } from './RedPointLogic';
import playerLogic from './PlayerLogic';
import storageUtils from '../utils/StorageUtils';
import { Storage } from '../utils/DefineUtils';

/**公会红包系统 */
class RedPackLogic extends BaseLogic {

    protected _redPacks: { [key: string]: RedPack } = {};   // 红包
    protected _redTasks: RedTask[] = [];                    // 红包任务
    protected _runningTask: RedTask[] = [];
    protected _packBtnPos: number[] = [];
    public needReload: boolean = false;

    init(gm: IGameManager) {
        super.init(null, gm);
        this.initPackPos();
    }

    getPackPos(): cc.Vec2 {
        if (this._packBtnPos.length < 2) { return null; }
        return cc.v2(this._packBtnPos[0], this._packBtnPos[1]);
    }
    setPackPos(x: number, y: number, save: boolean = true) {
        if (this._packBtnPos.length == 0) {
            this._packBtnPos.push(x);
            this._packBtnPos.push(y);
        } else if (this._packBtnPos.length == 1) {
            this._packBtnPos[0] = x;
            this._packBtnPos.push(y);
        } else {
            this._packBtnPos[0] = x;
            this._packBtnPos[1] = y;
        }
        if (save) { this.setPackPosLoacl(); }
    }
    // 从本地初始化红包位置
    protected initPackPos() {
        let data = this.getPackPosLocal()
        if (data) {
            let pos = data.split(`;`);
            if (pos.length == 2) {
                this.setPackPos(parseInt(pos[0]), parseInt(pos[1]), false);
                console.warn("从本地读取红包位置");
            }
        }
    }
    // 保存红包位置到本地
    protected setPackPosLoacl() {
        let pos = this.getPackPos();
        let data: string = `${pos.x};${pos.y}`;
        storageUtils.setString(Storage.RedPackPos.Key, data);
    }
    // 获取本地存储的红包位置信息
    protected getPackPosLocal(): string {
        return storageUtils.getString(Storage.RedPackPos);
    }

    // 获取红包列表
    async redPacksReq() {
        let proto = await this._gm.request<RedPackVO[]>(GameProxy.apiredpackgetGuildPacks);
        this._redPacks = {}
        if (proto) {
            for (let i = 0; i < proto.length; i++) {
                let id = proto[i].packId;
                let tmp = new RedPack(proto[i]);
                this._redPacks[id] = tmp;
            }
        }
    }
    // 获取红包信息
    async redPackInfoReq(ids: string[]) {
        let proto = await this._gm.request<RedPackVO[]>(GameProxy.apiredpackgetPacks, ids);
        if (proto) {
            for (let i = 0; i < proto.length; i++) {
                let id = proto[i].packId;
                if (this._redPacks[id]) {
                    this._redPacks[id].updateRedPack(proto[i]);
                } else {
                    let tmp = new RedPack(proto[i]);
                    this._redPacks[id] = tmp;
                }
            }
        }
    }
    // 获取红包任务信息
    async redTasksReq(id: number = 0) {
        let proto = await this._gm.request<RedPackTaskInfoVO[]>(GameProxy.apiredpackgetRTaskInfo, id);
        if (proto) {
            this._redTasks = [];
            for (let i = 0; i < proto.length; i++) {
                let cfg = cm.getRedTaskConfig(proto[i].taskId);
                if (!cfg) {
                    console.error(`红包任务表中未找到: ${proto[i].taskId}`);
                    continue;
                }
                if (cfg.repetition) {
                    if (proto[i].progress == 0) {
                        let tmpTask = new RedTask(proto[i].taskId, proto[i].typeId, false, 0);
                        this._redTasks.push(tmpTask);
                    } else {
                        let tmpTask = new RedTask(proto[i].taskId, proto[i].typeId, false, proto[i].progress);
                        this._redTasks.push(tmpTask);
                    }
                } else {
                    let tmp = new RedTask(proto[i].taskId, proto[i].typeId, proto[i].recv, proto[i].progress);
                    this._redTasks.push(tmp);
                }
            }
            this.freshRunningTask();
        }
    }
    // 领取红包
    async redPackRecvReq(id: string) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiredpackrecvPack, id);
        if (proto.extra) {
            this._redPacks[id].updateRedPack(proto.extra[0] as RedPackVO);
        }
        return proto;
    }
    // 发放任务红包
    async redPackSendReq(id: number) {
        let proto = await this._gm.request<RedPackVO>(GameProxy.apiredpacksendGuildPack, id);
        if (proto) {
            this._redPacks[proto.packId] = new RedPack(proto);
        }

        this.setTaskRecv(id);
        this.freshRunningTask();
    }
    // 红包推送
    async onRedPackMsg(pack: RedPackVO) {
        if (pack) {
            //await this.redPackInfoReq([packId]);
            let id = pack.packId;
            if (this._redPacks[id]) {
                this._redPacks[id].updateRedPack(pack);
            } else {
                this._redPacks[id] = new RedPack(pack);
            }
            EManager.emit(EName.onFreshPanel, "UnionHallNewPanel");
            EManager.emit(EName.onFreshPanel, "RedPackPanel");
        }
    }
    // 公会红包
    public getUnionPacks(): RedPack[] {
        let packs: RedPack[] = [];
        Object.keys(this._redPacks).forEach((v, i, a) => {
            if (this._redPacks[v].isSystemRed()) {
                packs.push(this._redPacks[v]);
            }
        })
        return packs;
    }
    // 任务红包
    public getRedPacks(): RedPack[] {
        let packs: RedPack[] = [];
        Object.keys(this._redPacks).forEach((v, i, a) => {
            if (!this._redPacks[v].isSystemRed() && this._redPacks[v].leftSecond() > 0
                && this._redPacks[v].getLeftNum() > 0) {
                packs.push(this._redPacks[v]);
            }
        })
        return packs;
    }
    public getRedPack(id: string): RedPack {
        return this._redPacks[id];
    }
    public getCanRecvUnionPackNum(): number {
        let packs = this.getUnionPacks();
        let num: number = packs.reduce((pre, now, i, a) => {
            let tmp: number = now.canRecv() ? 1 : 0;
            return pre + tmp;
        }, 0);
        return num;
    }
    public getCompleteTaskNum(): number {
        let num = this._runningTask.reduce((pre, now, i, a) => {
            let tmpNum: number = now.isComplete() ? 1 : 0;
            return pre + tmpNum;
        }, 0)
        return num;
    }
    public getCanRecvTaskPackNum(): number {
        let packs = this.getRedPacks();
        let num: number = packs.reduce((pre, now, i, a) => {
            let tmp: number = now.canRecv() ? 1 : 0;
            return pre + tmp;
        }, 0);
        return num;
    }

    public getRecvPackMaxTimes(): number {
        if (unionLogic.getUnion()) {
            return unionLogic.getUnion().statue.getMaxRecvPackTimes();
        }
        return 5;
    }
    // 红包任务
    public getRedTasks(): RedTask[] {
        return this._runningTask;
    }
    public getRedTask(taskId: number): RedTask {
        return this._redTasks.find((v, i, a) => { return v.getTaskId() == taskId; });
    }
    public setTaskRecv(taskId: number) {
        for (let i = 0; i < this._redTasks.length; i++) {
            let task = this._redTasks[i];
            if (task.getTaskId() == taskId) {
                if (!task.isRecv() && task.isComplete()) {
                    if (task.canRepeat()) {
                        task.setProg(task.getProg() - 1);
                        this.checkRepeatTask(taskId);
                    } else {
                        task.setRecv(true);
                    }
                    break;
                }
            }
        }
    }
    // 检查可重复的红包任务是否都已领取
    checkRepeatTask(taskId: number) {
        let hasValidTask = this._redTasks.some((v, i, a) => {
            let has = v.getTaskId() == taskId && ((v.isComplete() && !v.isRecv()) || !v.isComplete());
            return has;
        })
        if (!hasValidTask) {
            for (let i = 0; i < this._redTasks.length; i++) {
                if (this._redTasks[i].getTaskId() == taskId) {
                    this._redTasks[i].update(taskId, this._redTasks[i].getTypeId(), false, 0);
                    console.warn(`重设红包任务:${taskId}`);
                    break;
                }
            }
        }
    }
    // 筛选出待显示的红包任务
    freshRunningTask() {
        this._runningTask = [];
        this._runningTask = this._redTasks.filter((v, i, a) => { return v.isRunning(); });
        this._runningTask.sort((a, b) => {
            if (b.getRedPackType() == a.getRedPackType()) {
                return b.getSortTag() - a.getSortTag();
            } else {
                return b.getRedPackType() - a.getRedPackType();
            }
        })
    }

    public packSendRP(): boolean {
        return this.getCompleteTaskNum() > 0;
    }
    public memberPackRecvRP(): boolean {
        return this.getCanRecvTaskPackNum() > 0 && this.getRecvPackMaxTimes() > playerLogic.getPlayer().getRecvPackTimes();
    }
    public unionPackRecvRP(): boolean {
        return this.getCanRecvUnionPackNum() > 0;
    }
}

let redPackLogic = new RedPackLogic();
export default redPackLogic;