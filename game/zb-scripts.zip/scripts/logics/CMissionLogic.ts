import BaseLogic from "./BaseLogic";
import GameProxy, {CloneBatSubmitReq, CloneBatVO, ResourceVO} from "../proxy/GameProxy";
import gm from "../manager/GameManager";
import EManager, {EName} from "../manager/EventManager";
import bagLogic from "./BagLogic";
import {GoodId} from "../data/card/Good";
import {defaultConfigMap} from "../configs/defaultConfig";
import promptLogic, {PromptType} from "./PromptLogic";

export class CloneInfo {
    protected _cloneBatVo: CloneBatVO = null;

    constructor(proto: CloneBatVO) {
        this._cloneBatVo = proto;
    }

    canShowRedPoint() {
        let lastCount = defaultConfigMap.clonefreetime.value - this.getDayCount();
        return lastCount > 0;
    }

    getConfIds(): number[] {
        return this._cloneBatVo.confIds;
    }

    getLastCount(): number {
        return defaultConfigMap.clonefreetime.value - this.getDayCount();
    }

    getChallengeCnt(heroConfId: number): number {
        if (this._cloneBatVo.dayCountMap && this._cloneBatVo.dayCountMap[heroConfId]) {
            return this._cloneBatVo.dayCountMap[heroConfId];
        }
        return 0;
    }

    getDayCount(): number {
        if (this._cloneBatVo.dayCount) {
            return this._cloneBatVo.dayCount;
        }
        return 0;
    }

    getRefreshCount(): number {
        if (this._cloneBatVo.freshCount) {
            return this._cloneBatVo.freshCount;
        }
        return 0;
    }

    getLastTime(): number {
        return this._cloneBatVo.refreshTs;
    }

    getRemainTime(): number {
        return this._cloneBatVo.refreshTs - gm.getCurrentTimestamp();
    }

    getMaxWave(heroConfId: number): number {
        if (this._cloneBatVo.heroMaxProgress && this._cloneBatVo.heroMaxProgress[heroConfId]) {
            return this._cloneBatVo.heroMaxProgress[heroConfId];
        }
        return 0;
    }

    doComplete(heroConfId: number) {
        if (this._cloneBatVo.dayCountMap) {
            if (this._cloneBatVo.dayCountMap[heroConfId]) {
                this._cloneBatVo.dayCountMap[heroConfId] += 1;
            } else {
                this._cloneBatVo.dayCountMap[heroConfId] = 1;
            }
        }
        this._cloneBatVo.dayCount++;
    }
}

class CMissionLogic extends BaseLogic {

    protected _cloneInfo: CloneInfo = null;
    protected _currentMonsterId: number = 0;
    protected _battleStartTs: number = 0;

    init(gm) {
        super.init(null, gm);
    }

    cloneInfo(): CloneInfo {
        return this._cloneInfo;
    }

    set currentMonsterId(id: number) {
        this._currentMonsterId = id;
    }

    get currentMonsterId(): number {
        return this._currentMonsterId;
    }

    set battleStartTs(ts: number) {
        this._battleStartTs = ts;
    }

    get battleStartTs(): number {
        return this._battleStartTs;
    }

    /**获取克隆大作战信息 */
    async doGetCloneInfo() {
        let proto = await this._gm.request<CloneBatVO>(GameProxy.apiclonebatcloneInfo, null);
        this._cloneInfo = new CloneInfo(proto);
        if (!this._cloneInfo.canShowRedPoint()) {
            promptLogic.setPromptRead([PromptType.CLONE_FREE]);
        } else {
            promptLogic.setPrompt(PromptType.CLONE_FREE, true);
        }
    }

    /**提交克隆大作战结果 */
    async doPassClone(double: boolean, heroConfId: number, waveNo: number, cost: number = 0) {
        let req = new CloneBatSubmitReq();
        req.double = double;
        req.heroConfId = heroConfId;
        req.waveNo = waveNo;
        req.startTs = this.battleStartTs.toString();
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiclonebatpassClone, req);
        if (proto) {
            gm.getReward(proto);
            let date = new Date(this.battleStartTs);
            let startDay = date.getDay();
            date = new Date(gm.getCurrentTimestamp());
            let nowDay = date.getDay();
            if (startDay == nowDay) {
                this._cloneInfo.doComplete(heroConfId);
                if (this._cloneInfo.getLastCount() <= 0) {
                    bagLogic.getGood(GoodId.CloneTicket).changeAmount(-1);
                }
            }
            if (double && cost > 0) {
                bagLogic.getGood(GoodId.Diamond).changeAmount(-cost);
            }
            EManager.emit(EName.onUpdateCloneList);
            if (!this._cloneInfo.canShowRedPoint()) {
                promptLogic.setPromptRead([PromptType.CLONE_FREE]);
            }
        }
    }

    /**刷新克隆大作战英雄池 */
    async doFreshClone(cost: number) {
        let proto = await this._gm.request<CloneBatVO>(GameProxy.apiclonebatfreshClone, null);
        this._cloneInfo = new CloneInfo(proto);
        bagLogic.getGood(GoodId.Diamond).changeAmount(-cost);
    }

}

let cMissionLogic = new CMissionLogic();
export default cMissionLogic;
