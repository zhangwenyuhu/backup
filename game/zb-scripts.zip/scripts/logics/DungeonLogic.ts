import equipConfig, { equipConfigRow } from '../configs/equipConfig';
import mazefruitconfig from '../configs/mazefruitconfig';
import Card from '../data/card/Card';
import { EquipPlace } from '../data/card/Equip';
import Good from '../data/card/Good';
import Hero from "../data/card/Hero";
import Monster from '../data/card/Monster';
import Npc from '../data/card/Npc';
import IBattleData from '../data/IBattleData';
import Property from '../data/Property';
import ToastError from "../error/ToastError";
import cm from '../manager/ConfigManager';
import EManager from '../manager/EventManager';
import gm from '../manager/GameManager';
import IGameManager from "../manager/IGameManager";
import commonUtils from '../utils/CommonUtils';
import { BattleType, SystemId } from '../utils/DefineUtils';
import mathUtils from '../utils/MathUtils';
import stringUtils from '../utils/StringUtils';
import { defaultConfigMap } from './../configs/defaultConfig';
import dungeonconfig, { dungeonconfigRow } from './../configs/dungeonconfig';
import { mazefruitconfigRow } from './../configs/mazefruitconfig';
import { stringConfigMap } from './../configs/stringConfig';
import GameProxy, { DungeonInfoBO, DungeonRewardReq, EquipBO, GoodVO, HeroVO, KeyValueReq, ProcessReq, ResourceVO, WonderExtraReq } from './../proxy/GameProxy';
import bagLogic from './BagLogic';
import BaseLogic from "./BaseLogic";
import commitLogic, { DiamondCost, DiamondSource } from './CommitLogic';
import heroLogic from './HeroLogic';
import playerLogic from './PlayerLogic';

export enum DungeonRewardId {
    Gold = 2,
    Diamond,
    Chest
}

export enum DungeonEventId {
    /**
     * 无
     */
    None,

    /**
     * 金币1
     */
    Gold1 = 2001,

    /**
     * 金币2
     */
    Gold2,

    /**
     * 金币3
     */
    Gold3,

    /**
     * 钻石1
     */
    Diamond1 = 3001,

    /**
     * 钻石2
     */
    Diamond2 = 3002,

    /**
     * 钻石3
     */
    Diamond3 = 3003,

    /**
     * 宝箱
     */
    Chest = 4001,

    /**
     * 果实
     */
    Fruit = 5001,

    /**
     * 助力
     */
    Assist,

    /**
     * 传送门
     */
    Door,

    /**
     * 怪物
     */
    Monster,

    /**
     * 英雄
     */
    Hero,

    /**
     * 装饰物
     */
    Decoration
}

export abstract class DungeonEvent {
    protected _id: DungeonEventId = DungeonEventId.None;
    protected _index: number = 0;
    protected _valid: boolean = false;

    static Event = {
        onDirty: "dungeon event on dirty",
        onNextMission: "dungeon on next mission",
        onFinishMission: "dungeon on finish mission",
        onHeroMove: "dungeon on hero move",
        onHeroSwitch: "dungeon on hero switch",
        onShowAssist: "on show assist",
        onShowMonster: "on show monster",
        onSelectAssistHeroes: "on select assist heroes",
        onSelectFruits: "on select fruits",
        onWipeDungeon: "on wipe dungeon"
    }

    static create(data: any): DungeonEvent {
        let id = data.id;
        let rewardId = Math.floor(id / 1000);
        if (rewardId == DungeonRewardId.Diamond
            || rewardId == DungeonRewardId.Gold
            || rewardId == DungeonRewardId.Chest) {
            return new DungeonRewardEvent(data);
        }
        else if (id == DungeonEventId.Fruit) {
            return new DungeonFruitEvent(data);
        }
        else if (id == DungeonEventId.Assist) {
            return new DungeonAssistEvent(data);
        }
        else if (id == DungeonEventId.Door) {
            return new DungeonDoorEvent(data);
        }
        else if (id == DungeonEventId.Monster) {
            return new DungeonMonsterEvent(data);
        }
        else if (id == DungeonEventId.Hero) {
            return new DungeonHeroEvent(data);
        }
        else if (id == DungeonEventId.Decoration) {
            return new DungeonDecorationEvent(data);
        }
        return null;
    }

    constructor(data: { id: DungeonEventId, index: number, valid: boolean }) {
        this._id = data.id;
        this._index = data.index;
        this._valid = data.valid;
    }

    pack(): { id: DungeonEventId, index: number, valid: boolean } {
        return {
            id: this._id,
            index: this._index,
            valid: this._valid
        }
    }

    get id(): DungeonEventId {
        return this._id;
    }

    get index(): number {
        return this._index;
    }

    set index(value: number) {
        this._index = value;
    }

    get valid(): boolean {
        return this._valid;
    }

    set valid(value: boolean) {
        if (this._valid == value) return;
        this._valid = value;
        EManager.emit(DungeonEvent.Event.onDirty, this);
    }

    get frameNameOrAnimationName(): string {
        return `event${this.id}`;
    }

    get canTrigger(): boolean {
        return this.valid;
    }

    abstract get name(): string
    abstract async trigger(): Promise<any>;
}

export class DungeonRewardEvent extends DungeonEvent {
    async trigger(): Promise<Card[]> {
        let cards = await dungeonLogic.doClaimReward(this);
        this._valid = false;
        EManager.emit(DungeonEvent.Event.onDirty, this);
        await dungeonLogic.doSyncEvents(this.index);
        return cards;
    }

    get name(): string {
        return `reward ${this.id}`;
    }
}

export class DungeonFruitEvent extends DungeonEvent {
    protected _fruitIds: number[] = [];
    protected _canRefresh: boolean[] = [];

    constructor(data: {
        id: DungeonEventId,
        index: number,
        valid: boolean,
        fruitIds: number[],
        canRefresh: boolean[]
    }) {
        super(data);
        if (data.fruitIds) {
            this._fruitIds = data.fruitIds;
        }
        else {
            this._fruitIds = [];
        }
        this._canRefresh = data.canRefresh || [];
    }

    async trigger(fruitIds?: number[]) {
        await dungeonLogic.doReplaceFruits(this, fruitIds);
        this._valid = false;
        EManager.emit(DungeonEvent.Event.onDirty, this);
        await dungeonLogic.doSyncEvents(this.index);
    }

    async refresh(index: number): Promise<number> {
        let fruitId = this._randomFruit();
        this._fruitIds[index] = fruitId;
        this._canRefresh[index] = false;
        await dungeonLogic.doSyncEvents();

        return fruitId;
    }

    get name(): string {
        return 'fruit';
    }

    get fruitIds(): number[] {
        return this._fruitIds;
    }

    canRefresh(index: number): boolean {
        return this._canRefresh[index];
    }

    pack(): {
        id: DungeonEventId,
        index: number,
        valid: boolean,
        fruitIds: number[],
        canRefresh: boolean[]
    } {
        let data = super.pack() as {
            id: DungeonEventId,
            index: number,
            valid: boolean,
            fruitIds: number[],
            canRefresh: boolean[]
        };
        data.fruitIds = this._fruitIds;
        data.canRefresh = this._canRefresh;
        return data;
    }

    createFruits() {
        this._canRefresh = [];
        for (let i = 0; i < dungeonLogic.maxFruitCount; i++) {
            try {
                let fruitId = this._randomFruit();
                this._fruitIds.push(fruitId);
                this._canRefresh.push(true);
            } catch (error) {
                console.error(error);
            }
        }
    }

    protected _randomFruit(): number {
        let weight: number[] = dungeonLogic.battleData.config.fruitweight;
        let fruitIds = this._fruitIds.slice(0);
        fruitIds.pushList(dungeonLogic.fruitIds);
        let idSet = new Set<number>(fruitIds);
        let rarity = mathUtils.randomByWeight(weight) + 1;
        let rows = mazefruitconfig.filter((row: mazefruitconfigRow) => {
            return row.rarity == rarity
                && row.dungeon
                && !idSet.has(row.ID)
        });
        if (rows.length == 0) {
            throw new ToastError('no random fruit');
        }
        return rows[Math.floor(Math.random() * rows.length)].ID;
    }
}

export class DungeonAssistEvent extends DungeonEvent {
    protected _heroes: DungeonHeroData[] = [];

    constructor(data: {
        id: DungeonEventId,
        index: number,
        valid: boolean,
        heroes: DungeonHeroData[]
    }) {
        super(data);
        if (data.heroes) {
            this._heroes = data.heroes;
        }
        else {
            this._heroes = [];
        }
    }

    async trigger() {
        await dungeonLogic.doSaveAssistHero();
        this._valid = false;
        EManager.emit(DungeonEvent.Event.onDirty, this);
        await dungeonLogic.doSyncEvents(this.index);
    }

    get name(): string {
        return 'assist';
    }

    pack(): {
        id: DungeonEventId,
        index: number,
        valid: boolean,
        heroes: DungeonHeroData[]
    } {
        let data = super.pack() as {
            id: DungeonEventId,
            index: number,
            valid: boolean,
            heroes: DungeonHeroData[]
        };
        data.heroes = this._heroes;
        return data;
    }

    createHeroes() {
        this._heroes = [];

        let heroSet = new Set<number>();
        for (let hero of dungeonLogic.assistHeroes) {
            heroSet.add(hero.getIndex());
        }
        heroSet.add(dungeonLogic.battleHero.getIndex());

        let totalHeroes = heroLogic.getIllustrations().filter((a: Hero) => { return a.getQuality() > Hero.Quality.Normal; });
        let selectHeros = totalHeroes.filter((a: Hero) => { return !heroSet.has(a.getIndex()) });

        for (let i = 0; i < dungeonLogic.assistHeroCount; i++) {
            let hero: Hero = null;
            if (selectHeros.length == 0) {
                hero = totalHeroes[Math.floor(Math.random() * totalHeroes.length)];
            }
            else {
                hero = selectHeros.splice(Math.floor(Math.random() * selectHeros.length), 1)[0];
            }

            let data: DungeonHeroData = {
                id: stringUtils.generateUUID(),
                index: hero.getIndex(),
                equips: []
            }
            let assistHero = new DungeonAssistHero(data);
            let rows = equipConfig.filter((a: equipConfigRow) => { return a.Rank == assistHero.getRank() - 1; })
            if (rows.length > 0) {
                for (let i = EquipPlace.Weapon; i <= EquipPlace.Num; i++) {
                    let filters = rows.filter((a: equipConfigRow) => { return a.Place == i });
                    if (filters.length > 0) {
                        data.equips.push(filters[Math.floor(Math.random() * filters.length)].Id);
                    }
                }
            }
            this._heroes.push(data);
        }
    }

    get heroes(): DungeonAssistHero[] {
        let heroes: DungeonAssistHero[] = [];
        for (let item of this._heroes) {
            heroes.push(new DungeonAssistHero(item));
        }
        return heroes;
    }
}

export class DungeonDoorEvent extends DungeonEvent {
    async trigger() {
        this._valid = false;
        EManager.emit(DungeonEvent.Event.onDirty, this);
        await dungeonLogic.doPassMission();
    }

    show() {
        this._valid = true;
        EManager.emit(DungeonEvent.Event.onDirty, this);
    }

    get name(): string {
        return 'door';
    }
}

export class DungeonMonsterEvent extends DungeonEvent {
    async trigger() {
        this._valid = false;
        EManager.emit(DungeonEvent.Event.onDirty, this);
    }

    get name(): string {
        return 'monster';
    }

    get monster(): Monster {
        return dungeonLogic.battleData.getLeader();
    }

    get frameNameOrAnimationName(): string {
        return 'idle';
    }
}

export class DungeonHeroEvent extends DungeonEvent {
    async trigger() {
        this._valid = false;
        EManager.emit(DungeonEvent.Event.onDirty, this);
    }

    get hero(): Hero {
        return dungeonLogic.battleHero;
    }

    get name(): string {
        return 'hero';
    }

    get frameNameOrAnimationName(): string {
        return this.valid ? 'idle' : 'die';
    }
}

export class DungeonDecorationEvent extends DungeonEvent {
    protected _decorationId: number = 0;

    constructor(data: {
        id: DungeonEventId,
        index: number,
        valid: boolean,
        decorationId: number
    }) {
        super(data);
        this._decorationId = data.decorationId;
    }

    get decorationId(): number {
        return this._decorationId;
    }

    get name(): string {
        return 'decoration';
    }

    get frameNameOrAnimationName(): string {
        return `decoration${this.decorationId}`;
    }

    get canTrigger(): boolean {
        return false;
    }

    pack(): {
        id: DungeonEventId,
        index: number,
        valid: boolean,
        decorationId: number
    } {
        let data = super.pack() as {
            id: DungeonEventId,
            index: number,
            valid: boolean,
            decorationId: number
        };
        data.decorationId = this._decorationId;
        return data;
    }

    async trigger() {

    }
}

export class DungeonBattleData implements IBattleData {
    protected _config: dungeonconfigRow = null;
    protected _monsters: Monster[] = [];
    protected _leader: Monster = null;
    protected _rewards: Good[] = [];
    protected _eventIds: DungeonEventId[] = [];
    protected _allPassed: boolean = false;

    constructor(id: number, allPassed: boolean = false) {
        this._config = cm.getDungeonConfig(id);
        this._allPassed = allPassed;

        let monsters = [];
        for (let id of this._config.Monster) {
            if (id > 0) {
                let monster = new Monster(id, this._config.MonsterLevel);
                monsters.push(monster);
                if (this._leader) {
                    if (this._leader.getPower() < monster.getPower()) {
                        this._leader = monster;
                    }
                }
                else {
                    this._leader = monster;
                }
            }
            else {
                monsters.push(null);
            }
        }
        this._monsters = monsters;

        let rewards = [];
        for (let reward of this._config.Reward) {
            let vo = new GoodVO();
            vo.propId = reward[0];
            vo.amt = reward[1];
            rewards.push(new Good(vo));
        }
        this._rewards = rewards;

        if (this.hasAssist) {
            this._eventIds.push(DungeonEventId.Assist);
        }
        if (this.hasFruit) {
            this._eventIds.push(DungeonEventId.Fruit);
        }
        if (this._config.Things) {
            for (let event of this._config.Things) {
                if (Math.random() <= event[1]) {
                    this._eventIds.push(event[0]);
                }
            }
        }
    }

    get allPassed(): boolean {
        return this._allPassed;
    }

    set allPassed(value: boolean) {
        this._allPassed = value;
    }

    get config(): dungeonconfigRow {
        return this._config;
    }

    get id(): number {
        return this._config.ID;
    }

    get levelId(): number {
        return this._config.levelID;
    }

    get hasAssist(): boolean {
        return this._config.HelpHero == 1;
    }

    get hasFruit(): boolean {
        return this._config.Fruit == 1;
    }

    get needSave(): boolean {
        return this._config.SavePoint == 1;
    }

    get eventIds(): DungeonEventId[] {
        return this._eventIds;
    }

    get geniusPoints(): number[] {
        return [this._config.talentPoint1, this._config.talentPoint2, this._config.talentPoint3];
    }

    getLeader(): Monster {
        return this._leader;
    }

    getMonsters(): Monster[] {
        return this._monsters;
    }

    getMonstersPower(): number {
        let power: number = 0;
        power = this._monsters.reduce((pre, v, i, a) => { return pre + v.getPower(); }, 0);
        return power;
    }

    getRewards(): Good[] {
        return this._rewards;
    }

    getTime(): number {
        return 90
    }

    getBattleType(): BattleType {
        return BattleType.Dungeon;
    }

    getNpcs(): { [key: number]: Npc } {
        return {};
    }

    getUntroopHeroIds(): Set<string> {
        return null;
    }

    getUntroopReason(): string {
        return "";
    }

    getTroopExpire(): number {
        return -1;
    }
}

type DungeonHeroData = {
    id: string,
    index: number,
    equips: number[]
}

export class DungeonAssistHero extends Hero {
    protected _data: DungeonHeroData = null;

    static createHeroVo(data: DungeonHeroData): HeroVO {
        let heroVO = new HeroVO();
        heroVO.heroId = data.id;
        heroVO.heroCofId = data.index;
        heroVO.rank = Math.max(dungeonLogic.assistHeroRank - 1, 4);
        heroVO.lv = Math.max(1, dungeonLogic.assistHeroLevel - 5);
        heroVO.equips = [];
        for (let id of data.equips) {
            let bo = new EquipBO();
            bo.equipId = stringUtils.generateUUID();
            bo.equipCofId = id;
            bo.heroId = heroVO.heroId;
            bo.totalStarExp = 0;
            bo.chargingLv = 0;
            bo.strengLv = 1;
            heroVO.equips.push(bo);
        }
        return heroVO;
    }

    constructor(data: DungeonHeroData) {
        super(DungeonAssistHero.createHeroVo(data));
        this._data = data;
        this.calcProperties();
    }

    get data(): DungeonHeroData {
        return this._data;
    }

    calcProperties() {
        super.calcProperties();

        for (let place in this._equips) {
            let equip = this._equips[place];
            for (let config of Property.Config) {
                this[`_${config.VarName}AddValue`] += equip.getValue(config);
            }
        }
    }
}

class DungeonLogic extends BaseLogic {
    protected _battleHeroes: Hero[] = [];
    protected _remainCount: number = 0;
    protected _events: DungeonEvent[] = [];
    protected _fruitIds: number[] = [];
    protected _assistHeroes: DungeonAssistHero[] = [];
    protected _troop: { [key: number]: string } = {};
    protected _battleData: DungeonBattleData = null;
    protected _assistHeroLevel: number = 0;
    protected _assistHeroRank: number = 0;
    protected _refreshCount: number = 0;
    protected _rewardClaimed: boolean = false;
    protected _resetTimestamp: number = 0;
    protected _heroProcesses: { [key: number]: number } = {};
    protected _lastHeroSelectIndexes: number[] = [];
    protected _heroSelectNo: number = 0;
    protected _maxMapIndex: number = 0;

    readonly globalDungeonId: number = -1;
    readonly columnCount: number = 5;
    readonly rowCount: number = 5;
    readonly totalTime: number = 3;
    readonly decorationCount: number = 7;
    readonly assistHeroCount: number = 4;
    readonly maxAssistSelectCount: number = 2;
    readonly maxFruitCount: number = 3;
    readonly maxHeroCount: number = 2;
    readonly keys = {
        remainCount: 'remainCount',
        events: 'events',
        fruitIds: 'fruitIds',
        assistHeroes: 'assistHeroes',
        troop: 'troop',
        selectHeroConfIds: 'selectHeroConfIds',
        selectHeroNo: 'selectHeroNo',
        assistHero: 'assistHero',
    }

    readonly saveKeys = {
        maxMapIndex: "maxMapIndex"
    }

    async init(gm: IGameManager) {
        super.init(null, gm);

        this._heroProcesses = {};

        let process = await this._gm.request<ResourceVO>(GameProxy.apiprocessgetProcess, SystemId.Dungeon.toString());
        if (process.process) {
            for (let proc of process.process) {
                this._heroProcesses[proc.houseId] = proc.stageId;
            }
        }
    }

    async request() {
        await this.init(this._gm);

        this._battleHeroes = [];
        this._resetTimestamp = 0;

        let proto = await this._gm.request<DungeonInfoBO>(GameProxy.apidungeongetDungeonInfo, this.globalDungeonId);

        let extraSave = proto.extraSave as any;
        let selectHeroConfIds = extraSave[this.keys.selectHeroConfIds];
        if (selectHeroConfIds) { this._lastHeroSelectIndexes = selectHeroConfIds; }
        let maxMapIndex = extraSave[this.saveKeys.maxMapIndex];
        if (maxMapIndex) { this._maxMapIndex = maxMapIndex; }

        let extra = proto.extra as any;
        selectHeroConfIds = extra[this.keys.selectHeroConfIds];
        if (selectHeroConfIds) {
            for (let i = 0; i < selectHeroConfIds.length; i++) {
                let confId = selectHeroConfIds[i];
                let heroes = heroLogic.getHeroesByIndex(confId);
                if (heroes.length > 0) {
                    heroes.sort(this.sortHeroes.bind(this));
                    this._battleHeroes.push(heroes[0]);
                }
            }

            if (this._battleHeroes.length == 0) {
                throw new ToastError(stringConfigMap.key_dungeon_hero_leave.Value);
            }

            this._heroSelectNo = 0;
            let heroNo = extra[this.keys.selectHeroNo];
            if (typeof heroNo == "number" && this._battleHeroes[heroNo]) {
                this._heroSelectNo = heroNo;
            }

            await this._requestDungeonInfo(this.battleHero);
        }
    }

    getHeroProcess(heroConfId: number): number {
        return this._heroProcesses[heroConfId];
    }

    sortHeroes(a: Hero, b: Hero) {
        let aRank = a.getRank();
        let bRank = b.getRank();
        if (aRank != bRank) return bRank - aRank;

        let aLevel = a.getLevel();
        let bLevel = b.getLevel();
        if (aLevel != bLevel) return bLevel - aLevel;

        let aPower = a.getPower();
        let bPower = b.getPower();
        if (aPower != bPower) return bPower - aPower;

        if (a.getId() < b.getId()) { return -1; }
        else { return 1; }
    }

    protected async _requestDungeonInfo(hero: Hero) {
        let proto = await this._gm.request<DungeonInfoBO>(GameProxy.apidungeongetDungeonInfo, hero.getIndex());
        this._refreshCount = proto.helpFresh;
        this._rewardClaimed = proto.passRecv;
        this._resetTimestamp = proto.resetTs;

        let extra = proto.extra as any;
        let assistHero = extra[this.keys.assistHero];
        if (typeof assistHero == 'object' && assistHero) {
            this._assistHeroLevel = assistHero.level;
            this._assistHeroRank = assistHero.rank;
        }
        else {
            let heroes = heroLogic.getHeroes();
            if (heroes.length > 0) {
                heroes.sort((a: Hero, b: Hero) => { return b.getLevel(true) - a.getLevel(true) });
                this._assistHeroLevel = heroes[0].getLevel(true);
                heroes.sort((a: Hero, b: Hero) => { return b.getRank() - a.getRank() });
                this._assistHeroRank = heroes[0].getRank();
            }
            else {
                this._assistHeroLevel = 1;
                this._assistHeroRank = 1;
            }
            await this._doSave([
                {
                    key: this.keys.assistHero,
                    value: { level: this._assistHeroLevel, rank: this._assistHeroRank }
                }
            ]);
        }

        this._remainCount = undefined;
        this._events = [];
        this._fruitIds = [];
        this._assistHeroes = [];

        extra = proto.extra as any;

        let remainCount = extra[this.keys.remainCount];
        if (typeof remainCount == 'number') { this._remainCount = remainCount; }
        else { this._remainCount = this.totalTime; }

        let fruitIds = extra[this.keys.fruitIds];
        if (fruitIds && fruitIds instanceof Array) {
            this._fruitIds = fruitIds;
        }

        let heroDatas = extra[this.keys.assistHeroes] as DungeonHeroData[];
        if (heroDatas && heroDatas instanceof Array) {
            for (let data of heroDatas) {
                this._assistHeroes.push(new DungeonAssistHero(data));
            }
        }

        let troop = extra[this.keys.troop] as string[];
        if (troop && typeof troop == 'object') {
            this._troop = troop;
        }
        else {
            this._troop = {};
        }

        if (proto.levelID > this.getLimitLevel() + 1000 || proto.levelID < 0) {
            this._battleData = new DungeonBattleData(this.getLimitLevel() + 1000, true);
            this._createMap();
            return;
        }
        else {
            this._battleData = new DungeonBattleData(proto.levelID);
        }

        let events = extra[this.keys.events];
        if (events && events instanceof Array) {
            for (let event of events) {
                let e = DungeonEvent.create(event);
                if (this._battleData.allPassed) {
                    if (e.id == DungeonEventId.Hero || e.id == DungeonEventId.Decoration) {
                        this._events.push(e);
                    }
                }
                else {
                    this._events.push(e);
                }
            }
        }
        else {
            this._createMap();
            await this.doSyncEvents();
            await this._doSaveGlobalForever([{ key: this.saveKeys.maxMapIndex, value: this._maxMapIndex }]);
        }
        this._events.sort((a: DungeonEvent, b: DungeonEvent) => {
            return a.index - b.index;
        });
    }

    get resetTimestamp(): number {
        return this._resetTimestamp;
    }

    getLimitLevel(hero?: Hero): number {
        let h = hero || this.battleHero;
        if (h.getQuality() == Hero.Quality.Epic) {
            return defaultConfigMap.dilaoputonglimit.value;
        }
        else {
            return dungeonconfig[dungeonconfig.length - 1].ID;
        }
    }

    addAssistHeroes(heroes: DungeonAssistHero[]) {
        this._assistHeroes.pushList(heroes);
    }

    async doSwitchBattleHero() {
        this._heroSelectNo = (this._heroSelectNo + 1) % this._battleHeroes.length;
        await this._doSaveGlobal([{ key: this.keys.selectHeroNo, value: this._heroSelectNo }]);
        await this._requestDungeonInfo(this.battleHero);
    }

    async doSelectBattleHero(heroes: Hero[], index: number) {
        if (heroes.length == 0) {
            throw new ToastError(stringConfigMap.key_at_least_select_battle_hero.Value);
        }

        let selectHeroConfIds = [];
        for (let hero of heroes) {
            selectHeroConfIds.push(hero.getIndex());
        }
        this._battleHeroes = heroes;
        this._heroSelectNo = index;

        await this._doSaveGlobal([
            {
                key: this.keys.selectHeroConfIds,
                value: selectHeroConfIds
            },
            {
                key: this.keys.selectHeroNo,
                value: index
            }
        ]);
        await this._doSaveGlobalForever([{
            key: this.keys.selectHeroConfIds,
            value: selectHeroConfIds
        }]);
        await this._requestDungeonInfo(this.battleHero);
    }

    async doSyncEvents(targetIndex?: number) {
        if (typeof targetIndex == 'number') {
            for (let event of this._events) {
                if (event instanceof DungeonHeroEvent) {
                    event.index = targetIndex;
                    EManager.emit(DungeonEvent.Event.onHeroMove);
                    break;
                }
            }
        }

        let events = this._packEvents();
        await this._doSave([{ key: this.keys.events, value: events }]);
    }

    async doClaimReward(event: DungeonRewardEvent): Promise<Card[]> {
        let req = new DungeonRewardReq();
        req.eventId = event.id;
        req.levelId = this._battleData.levelId;
        let vo = await this._gm.request<ResourceVO>(GameProxy.apidungeongetDungeonEventReward, req);
        commitLogic.commitReward(vo, DiamondSource.dungeonEvent);
        if (vo) {
            return playerLogic.addCards(vo);
        }
        else {
            return [];
        }
    }

    async doReplaceFruits(event: DungeonFruitEvent, fruitIds?: number[]) {
        let newFruitIds = [];
        if (fruitIds && fruitIds.length > 0) {
            newFruitIds = fruitIds;
        }
        else {
            newFruitIds = event.fruitIds;
        }

        let needSave = true;
        if (newFruitIds.length == this._fruitIds.length) {
            needSave = false;
            for (let i = 0; i < newFruitIds.length; i++) {
                if (newFruitIds[i] != this._fruitIds) {
                    needSave = true;
                    break;
                }
            }
        }
        if (needSave) {
            this._fruitIds = newFruitIds;
            await this._doSave([{ key: this.keys.fruitIds, value: this._fruitIds }]);
        }
    }

    async doSaveAssistHero() {
        let datas: DungeonHeroData[] = [];
        for (let hero of this._assistHeroes) {
            datas.push(hero.data);
        }
        await this._doSave([{ key: this.keys.assistHeroes, value: datas }]);
    }

    async doUpdateTroop(selectHeroes: { [key: number]: Hero }) {
        let heroes = Object.values(selectHeroes);
        heroes = heroes.filter(h => h != null);
        if (heroes.length == 0) {
            throw new ToastError(stringConfigMap.key_please_select_fight_hero.Value);
        }

        let isDirty: boolean = false;
        for (let key in selectHeroes) {
            let hero = selectHeroes[key];
            if (hero.getId() != this._troop[key]) {
                isDirty = true;
                break;
            }
        }
        if (isDirty) {
            this._troop = {};
            for (let key in selectHeroes) {
                this._troop[key] = selectHeroes[key].getId();
            }
            await this._doSave([{ key: this.keys.troop, value: this._troop }]);
        }
    }

    async doClaimMissionRewards(): Promise<Card[]> {
        if (dungeonLogic.resetTimestamp > 0) {
            if (this._gm.getCurrentTimestamp() >= dungeonLogic.resetTimestamp) {
                throw new ToastError(stringConfigMap.key_dungeon_finished.Value);
            }
        }

        let monsterEvent: DungeonMonsterEvent = null;
        for (let event of this._events) {
            if (event instanceof DungeonMonsterEvent) {
                event.trigger();
                monsterEvent = event;
            }
            else if (event instanceof DungeonDoorEvent) {
                event.show();
            }
        }
        await this.doSyncEvents(monsterEvent.index);

        if (!this._rewardClaimed) {
            let req = new DungeonRewardReq();
            req.eventId = this.battleHero.getIndex();
            req.levelId = this._battleData.levelId;
            let proto = await this._gm.request<ResourceVO>(GameProxy.apidungeondungeonPassRecv, req);
            let cards = [];
            if (proto) { cards = playerLogic.addCards(proto); }
            this._rewardClaimed = true;
            commitLogic.commitReward(proto, DiamondSource.dungeonFight);
            return cards;
        }
        return [];
    }

    async doPassMission() {
        let needSave = this._battleData.needSave;
        // if (this._battleData.needSave) {
        //     if (this._remainCount < this.totalTime) {
        //         this._remainCount = this.totalTime;
        //         await this._doSave([{ key: this.keys.remainCount, value: this._remainCount }]);
        //     }
        // }

        let req = new ProcessReq();
        req.stageId = this._battleData.levelId;
        req.systemId = SystemId.Dungeon;
        req.paras = [this.battleHero.getIndex().toString()];
        await this._gm.request(GameProxy.apiprocesspassProcess, req);

        let level = this.getLimitLevel();
        if (this._battleData.config.ID == level) {
            this._battleData.allPassed = true;

            for (let event of this._events) {
                if (event.id != DungeonEventId.Hero && event.id != DungeonEventId.Decoration) {
                    event.valid = false;
                }
            }

            if (this.battleHero.getQuality() == Hero.Quality.Epic) {
                throw new ToastError(stringUtils.getString(stringConfigMap.key_dungeon_finish_mission_ex.Value, { count: defaultConfigMap.dilaoputonglimit.value }));
            }
            else {
                throw new ToastError(stringConfigMap.key_dungeon_finish_mission.Value);
            }
        }

        if (this._battleData.levelId == 1050) {
            if (heroLogic.artifactUnlockInfo) {
                heroLogic.artifactUnlockInfo.addTaskProgress(8004);
            }
        }

        let config = cm.getDungeonIdConfig(this._battleData.config.ID + 1);
        if (config) {
            this._heroProcesses[this.battleHero.getIndex()] = this._battleData.levelId;
            this._battleData = new DungeonBattleData(config.levelID);
            this._rewardClaimed = false;
            this._createMap();
            await this.doSyncEvents();
            await this._doSaveGlobalForever([{ key: this.saveKeys.maxMapIndex, value: this._maxMapIndex }]);
            EManager.emit(DungeonEvent.Event.onNextMission, needSave);
        }
    }

    async doFailMission() {
        let reqs: KeyValueReq[] = [];

        this._remainCount--;
        let req = new KeyValueReq();
        req.key = this.keys.remainCount;
        req.objData = this._remainCount as any;
        reqs.push(req);

        for (let event of this._events) {
            if (event instanceof DungeonHeroEvent) {
                if (this._remainCount == 0) {
                    event.trigger();
                    req = new KeyValueReq();
                    req.key = this.keys.events;
                    req.objData = this._packEvents();
                    reqs.push(req);
                }
                else {
                    EManager.emit(DungeonEvent.Event.onDirty, event);
                }
                break;
            }
        }

        let extraReq = new WonderExtraReq();
        extraReq.pairs = reqs;
        extraReq.stageId = this.battleHero.getIndex();
        await this._gm.request<boolean>(GameProxy.apidungeonputDungeonExtra, extraReq);
    }

    async doRefreshAssistHero() {
        for (let event of this._events) {
            if (event instanceof DungeonAssistEvent) {
                let costs = cm.dungeonRefreshCost;
                let cost = costs[Math.min(dungeonLogic.refreshCount, costs.length - 1)];
                let good = bagLogic.getGood(Good.GoodId.Diamond);
                if (good.getAmount() < cost) {
                    gm.toast(stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() }));
                    return;
                }

                event.createHeroes();
                await this.doSyncEvents();
                this._refreshCount = await this._gm.request<number>(GameProxy.apidungeondungeonHelpFresh, this.battleHero.getIndex());
                bagLogic.changeGoodAmount(Good.GoodId.Diamond, -cost);
                commitLogic.costDiamond(cost, DiamondCost.dungeonRefreshHero);
                break;
            }
        }
    }

    protected async _doSaveGlobal(kvs: { key: string, value: any }[]) {
        if (dungeonLogic.resetTimestamp > 0) {
            if (this._gm.getCurrentTimestamp() >= dungeonLogic.resetTimestamp) {
                throw new ToastError(stringConfigMap.key_dungeon_finished.Value);
            }
        }

        let req = new WonderExtraReq();
        req.pairs = [];
        req.stageId = this.globalDungeonId;
        for (let kv of kvs) {
            let keyValue = new KeyValueReq();
            keyValue.key = kv.key;
            keyValue.objData = kv.value;
            req.pairs.push(keyValue);
        }
        await this._gm.request<boolean>(GameProxy.apidungeonputDungeonExtra, req);
    }

    protected async _doSave(kvs: { key: string, value: any }[]) {
        if (dungeonLogic.resetTimestamp > 0) {
            if (this._gm.getCurrentTimestamp() >= dungeonLogic.resetTimestamp) {
                throw new ToastError(stringConfigMap.key_dungeon_finished.Value);
            }
        }

        let req = new WonderExtraReq();
        req.pairs = [];
        req.stageId = this.battleHero.getIndex();
        for (let kv of kvs) {
            let keyValue = new KeyValueReq();
            keyValue.key = kv.key;
            keyValue.objData = kv.value;
            req.pairs.push(keyValue);
        }
        await this._gm.request<boolean>(GameProxy.apidungeonputDungeonExtra, req);
    }

    protected async _doSaveGlobalForever(kvs: { key: string, value: any }[]) {
        if (dungeonLogic.resetTimestamp > 0) {
            if (this._gm.getCurrentTimestamp() >= dungeonLogic.resetTimestamp) {
                throw new ToastError(stringConfigMap.key_dungeon_finished.Value);
            }
        }

        let req = new WonderExtraReq();
        req.pairs = [];
        req.stageId = this.globalDungeonId;
        for (let kv of kvs) {
            let keyValue = new KeyValueReq();
            keyValue.key = kv.key;
            keyValue.objData = kv.value;
            req.pairs.push(keyValue);
        }
        await this._gm.request<boolean>(GameProxy.apidungeonputDungeonExtraSave, req);
    }

    protected async _doSaveForever(kvs: { key: string, value: any }[]) {
        if (dungeonLogic.resetTimestamp > 0) {
            if (this._gm.getCurrentTimestamp() >= dungeonLogic.resetTimestamp) {
                throw new ToastError(stringConfigMap.key_dungeon_finished.Value);
            }
        }

        let req = new WonderExtraReq();
        req.pairs = [];
        req.stageId = this.battleHero.getIndex();
        for (let kv of kvs) {
            let keyValue = new KeyValueReq();
            keyValue.key = kv.key;
            keyValue.objData = kv.value;
            req.pairs.push(keyValue);
        }
        await this._gm.request<boolean>(GameProxy.apidungeonputDungeonExtraSave, req);
    }

    get nextSaveConfig(): dungeonconfigRow {
        let index = dungeonconfig.indexOf(this._battleData.config);
        for (let i = index; i < dungeonconfig.length; i++) {
            if (dungeonconfig[i].SavePoint != 0) {
                return dungeonconfig[i];
            }
        }
        return null;
    }

    get battleData(): DungeonBattleData {
        return this._battleData;
    }

    get remainCount(): number {
        return this._remainCount;
    }

    get events(): DungeonEvent[] {
        return this._events;
    }

    get fruitIds(): number[] {
        return this._fruitIds;
    }

    get assistHeroes(): DungeonAssistHero[] {
        return this._assistHeroes;
    }

    get assistHeroLevel(): number {
        return this._assistHeroLevel;
    }

    get assistHeroRank(): number {
        return this._assistHeroRank;
    }

    get troopCount(): number {
        return 3;
    }

    get troop(): { [key: number]: string } {
        return this._troop;
    }

    get refreshCount(): number {
        return this._refreshCount;
    }

    get rewardClaimed(): boolean {
        return this._rewardClaimed;
    }

    get battleHero(): Hero {
        return this._battleHeroes[this._heroSelectNo];
    }

    get battleHeroes(): Hero[] {
        return this._battleHeroes;
    }

    get heroSelectNo(): number {
        return this._heroSelectNo;
    }

    get lastHeroSelectIndexes(): number[] {
        return this._lastHeroSelectIndexes;
    }

    protected _packEvents(): object {
        let protos = [];
        for (let event of this._events) {
            protos.push(event.pack());
        }
        return protos;
    }

    protected _createMap() {
        this._events = [];

        let count = this.columnCount * this.rowCount;
        let allSet = new Set<number>();
        for (let i = 0; i < count; i++) {
            allSet.add(i);
        }

        this._createHero(allSet);
        if (!this._battleData.allPassed) {
            this._createDoor(allSet);
            this._createMonster(allSet);
            this._createEvents(allSet);
        }
        this._createDecorations(allSet);
    }

    protected _createHero(allSet: Set<number>) {
        let index = this.columnCount * this.rowCount - 1;
        allSet.delete(index);
        this._events.push(new DungeonHeroEvent({
            id: DungeonEventId.Hero,
            index: index,
            valid: true
        }));
    }

    protected _createDoor(allSet: Set<number>) {
        let count = this.columnCount * this.rowCount;
        let index = Math.floor(count / 2);
        allSet.delete(index);
        this._events.push(new DungeonDoorEvent({
            id: DungeonEventId.Door,
            index: index,
            valid: false
        }));
    }

    protected _createDecorations(allSet: Set<number>) {
        let decorationCollection: number[] = [];
        for (let i = 0; i < this.columnCount; i++) {
            if (i == 0 || i == this.columnCount - 1) {
                for (let j = 0; j < this.rowCount; j++) {
                    if (i == this.columnCount - 1 && j == this.rowCount - 1) {
                        continue;
                    }
                    decorationCollection.push(j * this.columnCount + i);
                }
            }
            else {
                decorationCollection.push(i);
                decorationCollection.push((this.rowCount - 1) * this.columnCount + i);
            }
        }
        let count = mathUtils.random(3, 5);
        let selects = mathUtils.randomPickup(decorationCollection, count);
        for (let value of selects) {
            if (allSet.size == 0) {
                break;
            }
            if (!allSet.has(value)) {
                continue;
            }
            allSet.delete(value);
            this._events.push(new DungeonDecorationEvent({
                id: DungeonEventId.Decoration,
                index: value,
                valid: true,
                decorationId: Math.floor(Math.random() * this.decorationCount)
            }));
        }
    }

    protected _createEvents(allSet: Set<number>) {
        // let tempSet = new Set<number>(allSet);
        let eventIds = this._battleData.eventIds.slice(0);
        if (this._maxMapIndex < this._battleData.id) {
            if (this._battleData.config.OneTimeThings) {
                for (let event of this._battleData.config.OneTimeThings) {
                    if (Math.random() <= event[1]) {
                        eventIds.push(event[0]);
                    }
                }
            }
            this._maxMapIndex = this._battleData.id;
        }

        while (eventIds.length > 0 && allSet.size > 0) {
            let index = Math.floor(Math.random() * eventIds.length);
            let eventId = eventIds[index];
            eventIds.splice(index, 1);

            let arr = Array.from(allSet);
            let arrIndex = Math.floor(Math.random() * arr.length);
            let arrValue = arr[arrIndex];
            let event = DungeonEvent.create({ id: eventId, index: arrValue, valid: true });
            this._events.push(event);
            if (event instanceof DungeonFruitEvent) {
                event.createFruits();
            }
            else if (event instanceof DungeonAssistEvent) {
                event.createHeroes();
            }
            allSet.delete(arrValue);
            // tempSet.delete(arrValue);
            // let col = arrValue % this.columnCount;
            // let row = Math.floor(arrValue / this.columnCount);
            // for (let i = col - 1; i <= col + 1; i++) {
            //     for (let j = row - 1; j <= row + 1; j++) {
            //         arrValue = j * this.columnCount + i;
            //         tempSet.delete(arrValue);
            //     }
            // }
        }
    }

    protected _createMonster(allSet: Set<number>) {
        let arr = Array.from(allSet);
        let arrIndex = Math.floor(Math.random() * arr.length);
        let arrValue = arr[arrIndex];
        allSet.delete(arrValue);
        this._events.push(new DungeonMonsterEvent({
            id: DungeonEventId.Monster,
            index: arrValue,
            valid: true
        }));
    }

    getSkeletonUrl(heroConfId: number): string {
        let url = "";
        let process = dungeonLogic.getHeroProcess(heroConfId);
        if (process) {
            let config = cm.getDungeonConfig(process + 1);
            if (config) {
                url = commonUtils.getUISpineUrl(`dilao/${config.map}`);
            }
            else {
                config = dungeonconfig[0];
                url = commonUtils.getUISpineUrl(`dilao/${config.map}`);
            }
        }
        else {
            let config = dungeonconfig[0];
            url = commonUtils.getUISpineUrl(`dilao/${config.map}`);
        }
        return url;
    }
}

let dungeonLogic = new DungeonLogic();
export default dungeonLogic;