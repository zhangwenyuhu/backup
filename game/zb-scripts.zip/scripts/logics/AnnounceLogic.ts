import { AnnouncementDO } from './../proxy/IPirateProxy';
import AnnounceData from '../data/announce/AnnounceData';

/**
 * 公告逻辑
 */
class AnnounceLogic {
    protected _announces: AnnounceData[] = [];

    init(protos: AnnouncementDO[], districtId: number) {
        this._announces = [];
        if (protos) {
            for (let proto of protos) {
                let data = new AnnounceData(proto, districtId);
                if (data.isValid) {
                    this._announces.push(data);
                }
            }
            this._announces.sort((a: AnnounceData, b: AnnounceData) => { return b.index - a.index });
        }
    }

    get announces(): AnnounceData[] {
        return this._announces;
    }
}

let announceLogic = new AnnounceLogic();
export default announceLogic;