import GameProxy, { RankVO, RankReq, RankRewardInfoBO, ResourceVO, RankListReq, RankListVO } from './../proxy/GameProxy';
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from '../manager/GameManager';
import cm from '../manager/ConfigManager';
import { HonorRankType } from '../utils/DefineUtils';
import RankData from '../data/record/RankData';
import RankingScoreconfig, { RankingScoreconfigRow } from '../configs/RankingScoreconfig';
import Stageconfig from '../configs/Stageconfig';
import User from '../data/user/User';
import EManager, { EName } from '../manager/EventManager';
import { PromptType } from '../data/prompt/PromptModal';
import commitLogic, { DiamondSource } from './CommitLogic';

/* 荣耀榜 */
export class HonorLogic extends BaseLogic {

    protected _rankTop1: { [key: number]: RankData } = {};    // 荣耀榜top1榜 
    protected _ranks: { [key: number]: RankData[] } = {};     // 荣耀榜排名信息
    protected _myRanks: { [key: number]: RankData } = {};      // 我的排名信息
    protected _rankRewards: { [key: number]: { gotRewards: number[], openRewards: number[] } } = {};
    protected _top5: { [key: number]: { [key: number]: RankData[] } } = {};
    protected _firstReach: { [key: number]: { [key: number]: RankData } } = {};

    private _scoreCfgs: RankingScoreconfigRow[] = [];
    private _chapterCfgs: RankingScoreconfigRow[] = [];
    private _towerCfgs: RankingScoreconfigRow[] = [];

    init(gm: IGameManager) {
        super.init(null, gm);

        this._ranks = {};
        this._myRanks = {};
        this._rankRewards = {};
        this._top5 = {};

        this._scoreCfgs = [];
        this._chapterCfgs = [];
        this._towerCfgs = [];
        this.initCfg();
    }

    initCfg() {
        this._scoreCfgs = RankingScoreconfig.filter((v, i, a) => {
            return v.totalscore && v.totalscore > 0;
        })
        this._chapterCfgs = RankingScoreconfig.filter((v, i, a) => {
            return v.CityID && v.CityID > 0;
        })
        this._towerCfgs = RankingScoreconfig.filter((v, i, a) => {
            return v.tower && v.tower > 0;
        })
    }

    resetAll() {
        this._ranks = {};
        this._myRanks = {};
        this._rankRewards = {};
        this._top5 = {};

        this._scoreCfgs = [];
        this._chapterCfgs = [];
        this._towerCfgs = [];
        this.initCfg();
    }

    async allRankReq() {
        this.resetAll();
        await this.rankReq(HonorRankType.race_wuzhuang);
        await this.rankReq(HonorRankType.race_jixie);
        await this.rankReq(HonorRankType.race_bianzhong);
        await this.rankReq(HonorRankType.race_chaoneng);
        await this.rankReq(HonorRankType.mission);
        await this.rankReq(HonorRankType.tower);

        await this.myRankReq();

        await this.rankRewardsReq(HonorRankType.race_wuzhuang);
        await this.rankRewardsReq(HonorRankType.race_jixie);
        await this.rankRewardsReq(HonorRankType.race_bianzhong);
        await this.rankRewardsReq(HonorRankType.race_chaoneng);
        await this.rankRewardsReq(HonorRankType.mission);
        await this.rankRewardsReq(HonorRankType.tower);
    }

    getRandomTop1(): RankData {
        // 固定关卡
        return this._rankTop1[HonorRankType.power];
    }

    // 获取所有榜单第一名的信息
    async allRankTop1Req() {
        let proto = await gm.request<RankVO[]>(GameProxy.apirankrankAllTop);
        this._rankTop1 = {};
        proto.forEach((v, i, a) => {
            let tmp = new RankData(v);
            this._rankTop1[tmp.getType()] = tmp;
        })
    }

    // 荣耀榜各层级首位达到的信息
    async rankRewardFirstReachReq(type: HonorRankType) {
        let param = new RankReq();
        param.rankType = type;

        let proto = await gm.request<RankVO[]>(GameProxy.apirankrankTop, param);
        if (!this._firstReach) {
            this._firstReach = {};
        }
        this._firstReach[type] = {};
        proto.forEach((v, i, a) => {
            let tmp = new RankData(v);
            this._firstReach[type][tmp.getRank()] = tmp;
        })
    }

    // 领取荣耀榜奖励
    async getRankRewardReq(type: HonorRankType, id: number) {
        let param = new RankReq();
        param.rankType = type;
        param.rewardId = id;

        let proto = await gm.request<ResourceVO>(GameProxy.apirankgetRankReward, param);
        gm.getReward(proto);

        if (this._rankRewards && this._rankRewards[type]) {
            let data = this._rankRewards[type];
            data.gotRewards.push(id);
        }
        commitLogic.commitReward(proto, DiamondSource.honorRank);
    }

    // 荣耀榜奖励最先达成的5人信息
    async rankRewardTop5Req(type: HonorRankType, id: number) {
        let param = new RankReq();
        param.rankType = type;
        param.rewardId = id;

        let proto = await gm.request<RankVO[]>(GameProxy.apirankrankTop5, param);
        if (!this._top5[type]) {
            this._top5[type] = {};
        }

        this._top5[type][id] = [];
        proto.forEach((v, i, a) => {
            let tmp = new RankData(v);
            tmp.setType(type);
            this._top5[type][id].push(tmp);
        })
    }

    // 荣耀榜对应的积分奖励领取信息
    async rankRewardsReq(type: HonorRankType) {
        let param = new RankReq();
        param.rankType = type;
        let proto = await gm.request<RankRewardInfoBO>(GameProxy.apirankrankRewardInfo, param);

        this._rankRewards[type] = proto;
        EManager.emit(EName.onRedDirty, this.getPromptType(type));
    }

    // 我的各项排行数据
    async myRankReq() {
        let proto = await gm.request<RankVO[]>(GameProxy.apirankmyRank);
        this._myRanks = {};
        proto.forEach((v, i, a) => {
            let tmp = new RankData(v);
            this._myRanks[tmp.getType()] = tmp;
        })
    }

    // 荣耀榜排名请求
    async rankReq(type: HonorRankType) {
        if (type == HonorRankType.power) {
            await this.powerRankReq();
            return;
        }

        let param = new RankReq();
        param.rankType = type;

        let proto = await gm.request<RankVO[]>(GameProxy.apirankrank, param);
        this._ranks[type] = [];
        proto.forEach((v, i, a) => {
            let tmp = new RankData(v);
            tmp.setType(type);
            this._ranks[type].push(tmp);
        });
    }

    // 战力榜数据请求
    protected async powerRankReq() {
        let req = new RankListReq();
        req.rankType = 9;
        req.start = 0;
        req.end = 50;
        let proto = await gm.request<RankListVO>(GameProxy.apirankmyGameRank, req);

        let myRankInfo = new RankData(proto.myRank);
        this._myRanks[HonorRankType.power] = myRankInfo;

        this._ranks[HonorRankType.power] = [];
        for (let vo of proto.rankDetail) {
            let tmp = new RankData(vo);
            tmp.setType(HonorRankType.power);
            this._ranks[HonorRankType.power].push(tmp);
        }
    }

    public getFirstReachPlayer(type: HonorRankType, id: number): User {
        let user;
        if (this._firstReach && this._firstReach[type]) {
            if (this._firstReach[type][id]) {
                user = this._firstReach[type][id].getRole();
            }
        }
        return user;
    }

    public getTop5(type: HonorRankType, id: number): RankData[] {
        if (this._top5[type] && this._top5[type][id]) {
            return this._top5[type][id];
        }
        return [];
    }

    public getHonorCfgs(type: HonorRankType) {
        if (type == HonorRankType.mission) {
            return this._chapterCfgs;
        } else if (type == HonorRankType.tower) {
            return this._towerCfgs;
        } else {
            return this._scoreCfgs;
        }
    }

    public isOpen(type: HonorRankType, uid: number) {
        if (this._rankRewards && this._rankRewards[type]) {
            let data = this._rankRewards[type];
            if (data.openRewards) {
                let bOpen = data.openRewards.some((v, i, a) => {
                    return v == uid;
                });
                return bOpen;
            }
        }
        return false;
    }

    public isGotReward(type: HonorRankType, uid: number) {
        if (this._rankRewards && this._rankRewards[type]) {
            let data = this._rankRewards[type];
            if (data.gotRewards) {
                let bGot = data.gotRewards.some((v, i, a) => {
                    return v == uid;
                });
                return bGot;
            }
        }
        return false;
    }

    public getMyRank(type: HonorRankType): RankData {
        return this._myRanks[type];
    }

    public getTop1(type: HonorRankType): RankData {
        if (this._ranks[type] && this._ranks[type].length > 0) {
            return this._ranks[type][0];
        }
        if (this._rankTop1 && this._rankTop1[type]) {
            return this._rankTop1[type];
        }
        return null;
    }

    public getRankData(type: HonorRankType, index: number) {
        if (this._ranks[type].length > index) {
            return this._ranks[type][index];
        }
        return null;
    }

    public getRankCount(type: HonorRankType): number {
        return this._ranks[type].length;
    }

    public getChapter(mission: number): string {
        let cfg = cm.getStageConfig(mission)
        return cfg ? `${cfg.HouseID}-${cfg.level}` : `1-0`;
    }

    public getHonorRankTitleUrl(type: HonorRankType): string {
        let pre = `textures/ui/panel/honor/`;
        return pre + `honor_title_${type}`;
    }

    public hasHonorRankReward(type: HonorRankType): boolean {
        let tmp: boolean = false;
        if (this._rankRewards && this._rankRewards[type]) {
            let data = this._rankRewards[type];
            if (data.openRewards) {
                let gotLen = data.gotRewards ? data.gotRewards.length : 0;
                tmp = data.openRewards.length > gotLen;
            }
        }
        return tmp;
    }

    public getHonorRankTitle(type: HonorRankType): string {
        let str: string = "";
        switch (type) {
            case HonorRankType.race_wuzhuang:
                str = "武装军团积分榜";
                break;
            case HonorRankType.race_jixie:
                str = "机械军团积分榜";
                break;
            case HonorRankType.race_bianzhong:
                str = "变种军团积分榜";
                break;
            case HonorRankType.race_chaoneng:
                str = "僵尸军团积分榜";
                break;
            case HonorRankType.mission:
                str = "战役进度榜";
                break;
            case HonorRankType.tower:
                str = "超级摩天楼榜";
                break;
            default:
                break;
        }
        return str;
    }

    public getLastBuildCfg(cityId: number) {
        let stageId: number = 0;
        let houseId: number = 0;
        for (let i = 0; i < Stageconfig.length; i++) {
            let cfg = Stageconfig[i];
            if (cfg.CityID == cityId) {
                if (cfg.HouseID > houseId) {
                    houseId = cfg.HouseID;
                    stageId = cfg.ID;
                }
            }
        }
        return cm.getStageConfig(stageId);
    }

    public getHonorRewardDesc(type: HonorRankType, cfg: RankingScoreconfigRow): string {
        let param: number = 0;
        if (type == HonorRankType.mission) {
            param = cfg.CityID;
            let stageCfg = this.getLastBuildCfg(param);
            if (!stageCfg) { return ''; }
            return `本服任意一名玩家通关第${stageCfg.HouseID}个建筑: ${stageCfg.HouseName}`;
        } else if (type == HonorRankType.tower) {
            param = cfg.tower;
            return `本服任意一名玩家摩天楼达到${param}`;
        } else if (type == HonorRankType.race_wuzhuang) {
            param = cfg.totalscore;
            return `本服任意一名玩家武装军团积分达到${param}`;
        } else if (type == HonorRankType.race_jixie) {
            param = cfg.totalscore;
            return `本服任意一名玩家机械军团积分达到${param}`;
        } else if (type == HonorRankType.race_bianzhong) {
            param = cfg.totalscore;
            return `本服任意一名玩家变种军团积分达到${param}`;
        } else if (type == HonorRankType.race_chaoneng) {
            param = cfg.totalscore;
            return `本服任意一名玩家超能军团积分达到${param}`;
        }
        return "";
    }

    public getHonorType(type: HonorRankType): string {
        if (type == HonorRankType.mission) {
            return "关卡进度";
        } else if (type == HonorRankType.tower) {
            return "摩天楼层数";
        } else if (type == HonorRankType.power) {
            return "战力";
        } else {
            return "荣誉积分";
        }
    }

    public getHonorFaction(type: HonorRankType): number {
        let faction: number = 0;
        switch (type) {
            case HonorRankType.race_wuzhuang:
                faction = 1;
                break;
            case HonorRankType.race_jixie:
                faction = 2;
                break;
            case HonorRankType.race_bianzhong:
                faction = 3;
                break;
            case HonorRankType.race_chaoneng:
                faction = 4;
                break;
            default:
                break;
        }
        return faction;
    }

    public getPromptType(type: HonorRankType) {
        if (type == HonorRankType.mission) {
            return PromptType.HonorMissionBtn;
        } else if (type == HonorRankType.tower) {
            return PromptType.HonorTowerBtn;
        } else if (type == HonorRankType.race_wuzhuang) {
            return PromptType.HonorWuzhuangBtn;
        } else if (type == HonorRankType.race_jixie) {
            return PromptType.HonorJixieBtn;
        } else if (type == HonorRankType.race_bianzhong) {
            return PromptType.HonorBianzhongBtn;
        } else if (type == HonorRankType.race_chaoneng) {
            return PromptType.HonorJiangshiBtn;
        }
        return null;
    }
}

let honorLogic = new HonorLogic();
export default honorLogic;