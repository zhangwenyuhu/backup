import spacetimeconfig, { spacetimeconfigRow } from './../configs/spacetimeconfig';
import BaseLogic from "./BaseLogic";
import IGameManager from "../manager/IGameManager";
import {
    WonderCloudData,
    WonderSpaceCurrent,
    WonderSpaceData,
    WonderSpaceType,
    WonderStance
} from "../data/wonderspace/WonderSpaceBaseData";
import GameProxy, {
    HeroVO,
    KeyValueReq,
    ResourceVO,
    WonderExtraReq,
    WonderInfoBO,
    WonderRewardReq,
    WonderScoreReq
} from "../proxy/GameProxy";
import WonderCurrent from "../data/wonderspace/WonderCurrent";
import WonderSpaceMap from "../view/component/WonderSpace/WonderSpaceMap";
import WisdomTreeHero, { WisdomTreeHeroData } from "../data/wisdomtree/WisdomTreeHero";
import WisdomTreeBag, { WisdomTreeBagData } from "../data/wisdomtree/WisdomTreeBag";
import WonderSpace from "../data/wonderspace/WonderSpace";

import UnlockWrapper from '../view/widget/unlock/UnlockWrapper';
import missionLogic from './MissionLogic';
import stringUtils from "../utils/StringUtils";
import Hero from "../data/card/Hero";
import gm from "../manager/GameManager";
import spacetimeExploreConfig from "../configs/spacetimeExploreConfig";
import WonderExtraSave from "../data/wonderspace/WonderExtraSave";
import spacetimeMap01Config from "../configs/spacetimeMap01Config";
import spacetimeMap02Config from "../configs/spacetimeMap02Config";
import heroLogic from "./HeroLogic";
import WonderSpaceBase from "../view/component/WonderSpace/WonderSpaceBase";
import spacetimeMap04Config from "../configs/spacetimeMap04Config";
import spacetimeMap03Config from "../configs/spacetimeMap03Config";
import commitLogic, { DiamondSource } from './CommitLogic';

export class WonderSpaceChapter {
    protected _config: spacetimeconfigRow = null;
    protected _info: WonderInfoBO = null;
    protected _prevChapter: WonderSpaceChapter = null;
    protected _extraSave: WonderExtraSave = null;

    constructor(config: spacetimeconfigRow, prevChapter: WonderSpaceChapter) {
        this._config = config;
        this._prevChapter = prevChapter;
    }

    get config(): spacetimeconfigRow {
        return this._config;
    }

    get extraSave(): WonderExtraSave {
        return this._extraSave;
    }

    set extraSave(value: WonderExtraSave) {
        this._extraSave = value;
    }

    get id(): number {
        return this._config.ID;
    }

    get name(): string {
        return this._config.spacename;
    }

    get isUnlock(): boolean {
        if (UnlockWrapper.compareMission(missionLogic.getCurrentMission(), this._config.stageunlock) <= 0) {
            return false;
        }
        if (this._prevChapter && (this._prevChapter.progress / this._prevChapter.totalProgress) < this._config.scheduleunlock) {
            return false;
        }
        return true;
    }

    get progress(): number {
        if (this._info) {
            return this._info.score;
        }
        return 0;
    }

    set progress(value: number) {
        if (this._info) {
            this._info.score = value;
        }
    }

    get totalProgress(): number {
        if (this._extraSave) {
            return this._extraSave.totalScore;
        }
        return 1;
    }

    set totalProgress(value: number) {
        if (this._extraSave) {
            this._extraSave.totalScore = value;
        }
    }

    set info(value: WonderInfoBO) {
        this._info = value;
        if (this._info && typeof this._info.extraSave == "object") {
            this._extraSave = new WonderExtraSave(this._info.extraSave["ExtraData"]);
        }
    }

    get info(): WonderInfoBO {
        return this._info;
    }

    get prevChapter(): WonderSpaceChapter {
        return this._prevChapter;
    }

    get isOpened(): boolean {
        if (typeof this._info.extra == "object" && Object.keys(this._info.extra).length > 0) {
            return true;
        }
        return false;
    }

    checkRewardRecv(rewardId: string): boolean {
        return this.info.rewardRecvedIds.indexOf(rewardId) != -1;
    }

    existClearFog(id: number) {
        return this.extraSave.clearFogList.indexOf(id) != -1;
    }

    addClearFogList(ids: number[]) {
        for (let id of ids) {
            if (!this.existClearFog(id)) {
                this.extraSave.clearFogList.push(id);
            }
        }
    }

    resetStage() {
        this._info.extra = {};
    }

    checkRewardRecvCnt(rewardId: number): number {
        let cnt: number = 0;
        for (let reward of this.info.rewardRecvedIds) {
            let id = Number(reward.split('-')[1]);
            if (rewardId == id) {
                cnt++;
            }
        }
        return cnt;
    }

    get reward1Progress(): number {
        return (this.reward1Total - this.lastReward1.length) / this.reward1Total;
    }

    get reward1ProgressLabel(): string {
        return (this.reward1Total - this.lastReward1.length) + "/" + this.reward1Total;
    }

    get reward1Total(): number {
        let cnt: number = 0;
        let config = wonderSpaceLogic.getWonderSpaceMapConfig(this.id);
        for (let _config of config) {
            if (_config.eventtype == 1007 || _config.eventtype == 1008) {
                cnt += _config.eventnumber;
            }
        }
        return cnt;
    }

    get lastReward1(): any[] {
        let config = wonderSpaceLogic.getWonderSpaceMapConfig(this.id);
        let allReward1 = [];
        for (let _config of config) {
            if (_config.eventtype == 1007 || _config.eventtype == 1008) {
                let lastCnt: number = _config.eventnumber - this.checkRewardRecvCnt(_config.ID);
                for (let i = 0; i < lastCnt; i++) {
                    for (let item of _config.battle) {
                        allReward1.push(item);
                    }
                }
            }
        }
        return allReward1;
    }

    get reward2Progress(): number {
        return (this.reward2Total - this.lastReward2.length) / this.reward2Total;
    }

    get reward2ProgressLabel(): string {
        return (this.reward2Total - this.lastReward2.length) + "/" + this.reward2Total;
    }

    get reward2Total(): number {
        let cnt: number = 0;
        let config = wonderSpaceLogic.getWonderSpaceMapConfig(this.id);
        for (let _config of config) {
            if (_config.eventtype == 1010) {
                cnt += _config.eventnumber;
            }
        }
        return cnt;
    }

    get lastReward2(): any[] {
        let config = wonderSpaceLogic.getWonderSpaceMapConfig(this.id);
        let allReward2 = [];
        for (let _config of config) {
            if (_config.eventtype == 1010) {
                let lastCnt: number = _config.eventnumber - this.checkRewardRecvCnt(_config.ID);
                for (let i = 0; i < lastCnt; i++) {
                    for (let item of _config.battle) {
                        allReward2.push(item);
                    }
                }
            }
        }
        return allReward2;
    }

}

class WonderSpaceLogic extends BaseLogic {

    //原始数据
    protected _wonderInfo: WonderInfoBO = null;
    protected _wonderMap: Map<string, object> = new Map<string, object>();
    protected _wonderChapters: WonderSpaceChapter[] = [];
    protected _wonderOpenedChapter: WonderSpaceChapter = null;

    //数据对象
    protected _wonderCurrent: WonderCurrent = null;
    protected _wonderSpace: WonderSpace = null;
    protected _wonderHero: WisdomTreeHero = null;
    protected _wonderBag: WisdomTreeBag = null;
    protected _wonderStance: WonderStance = null;

    protected _row: number = 0;
    protected _column: number = 0;
    protected _startNodeId: number = 0;
    protected _wonderNodeList: cc.Node[] = [];
    protected _wonderPlayerNode: cc.Node = null;
    protected _wonderSpaceGuard: WonderSpaceBase = null;

    protected _wonderInterval: number = -1;
    protected _wonderSpaceDirty: string[] = [];
    protected _wonderSpaceExtraDirty: boolean = false;

    init(gm: IGameManager) {
        super.init(null, gm);
    }

    get row(): number {
        return this._row;
    }

    set row(value: number) {
        this._row = value;
    }

    get column(): number {
        return this._column;
    }

    set column(value: number) {
        this._column = value;
    }

    get startNodeId(): number {
        return this._startNodeId;
    }

    set startNodeId(value: number) {
        this._startNodeId = value;
    }

    get wonderNodeList(): cc.Node[] {
        return this._wonderNodeList;
    }

    set wonderNodeList(list: cc.Node[]) {
        this._wonderNodeList = list;
    }

    get wonderPlayerNode(): cc.Node {
        return this._wonderPlayerNode;
    }

    get wonderCurrentBase(): WonderSpaceBase {
        return this._wonderNodeList[this.wonderSpaceCurrent.wonderSpaceNodePos].getComponent(WonderSpaceBase);
    }

    set wonderPlayerNode(node: cc.Node) {
        this._wonderPlayerNode = node;
    }

    get wonderSpaceGuard(): WonderSpaceBase {
        return this._wonderSpaceGuard;
    }

    set wonderSpaceGuard(value: WonderSpaceBase) {
        this._wonderSpaceGuard = value;
    }

    get wonderSpaceCurrent(): WonderSpaceCurrent {
        return this._wonderCurrent.wonderSpaceCurrent;
    }

    get wonderChapters(): WonderSpaceChapter[] {
        return this._wonderChapters;
    }

    get wonderOpenedChapter(): WonderSpaceChapter {
        return this._wonderOpenedChapter;
    }

    get wonderSpace(): WonderSpace {
        return this._wonderSpace;
    }

    get wonderBag(): WisdomTreeBag {
        return this._wonderBag;
    }

    get wonderHero(): WisdomTreeHero {
        return this._wonderHero;
    }

    get wonderSpaceData(): WonderSpaceData[] {
        return this._wonderSpace.wonderSpaceData;
    }

    get wonderSpaceHero(): WisdomTreeHeroData[] {
        return this._wonderHero.wisdomTreeHeroData;
    }

    get wonderSpaceBag(): WisdomTreeBagData[] {
        return this._wonderBag.wisdomTreeBagData;
    }

    get wonderStance(): WonderStance {
        return this._wonderStance;
    }

    set wonderStance(value: WonderStance) {
        this._wonderStance = value;
    }

    get wonderPubHero(): WisdomTreeHeroData[] {
        let hero: WisdomTreeHeroData[] = [];
        for (let wisdomHero of this._wonderHero.wisdomTreeHeroData) {
            if (wisdomHero.isEmploy) {
                hero.push(wisdomHero);
            }
        }
        return hero;
    }

    getWonderSpaceMapConfig(id: number): any {
        switch (id) {
            case 1:
                return spacetimeMap01Config;
            case 2:
                return spacetimeMap02Config;
            case 3:
                return spacetimeMap03Config;
            case 4:
                return spacetimeMap04Config;
            default:
                console.error(`Map${id}配置未添加`);
                return spacetimeMap01Config;
        }
    }

    setWonderSpaceDirty(wonderSpace: string[]) {
        for (let wonder of wonderSpace) {
            if (!this._wonderSpaceDirty.find(a => a == wonder)) {
                this._wonderSpaceDirty.push(wonder);
            }
        }
    }

    setWonderSpaceExtraDirty() {
        this._wonderSpaceExtraDirty = true;
    }

    asyncData() {
        if (this._wonderSpaceDirty.length > 0) {
            this.putWonderExtra(this._wonderSpaceDirty, undefined, true);
            this._wonderSpaceDirty = [];
        }
        if (this._wonderSpaceExtraDirty) {
            this.putWonderExtraSave(true);
            this._wonderSpaceExtraDirty = false;
        }
    }

    startAsync() {
        this.stopAsync();
        this._wonderInterval = setInterval(this.asyncData.bind(this), 100) as any;
    }

    stopAsync() {
        if (this._wonderInterval != -1) {
            clearInterval(this._wonderInterval);
            this._wonderInterval = -1;
        }
    }

    /**获取关卡数据 */
    async getWonderInfo(id: number, wonderSpaceMap?: WonderSpaceMap) {
        this._wonderInfo = await this._gm.request<WonderInfoBO>(GameProxy.apiwondergetWonderInfo, id);
        for (let chapter of this.wonderChapters) {
            if (chapter.id == id) {
                chapter.info.extra = { Current: null };
                chapter.info.extraSave = this._wonderInfo.extraSave;
                this._wonderOpenedChapter = chapter;
                break;
            }
        }
        this._wonderCurrent = new WonderCurrent(this._wonderInfo.extra[WonderCloudData.Current], wonderSpaceMap);
        this._wonderSpace = new WonderSpace(this._wonderInfo.extra[WonderCloudData.WonderData]);
        this._wonderHero = new WisdomTreeHero(this._wonderInfo.extra[WonderCloudData.Hero] || []);
        this._wonderBag = new WisdomTreeBag(this._wonderInfo.extra[WonderCloudData.Bag] || []);
        this._wonderStance = this._wonderInfo.extra[WonderCloudData.Stance];
        this.startAsync();
        if (Object.keys(this._wonderInfo.extra).length == 0) {
            this.putWonderExtra([WonderCloudData.Current, WonderCloudData.WonderData, WonderCloudData.Bag, WonderCloudData.Stance], id);
        }
    }

    /**获取关卡总览 */
    async getWonderList() {
        this._wonderChapters = [];
        let protos = await this._gm.request<WonderInfoBO[]>(GameProxy.apiwondergetWonderList);
        let prevChapter: WonderSpaceChapter = null;
        for (let i = 0; i < spacetimeconfig.length; i++) {
            let config = spacetimeconfig[i];
            let chapter = new WonderSpaceChapter(config, prevChapter);
            if (protos[i]) {
                chapter.info = protos[i];
            }
            this._wonderChapters.push(chapter);
            prevChapter = chapter;
            if (protos[i]) { chapter.info = protos[i] }

            if (chapter.isOpened) {
                this._wonderOpenedChapter = chapter;
            }
        }
    }

    /**设置奇妙时空云端数据 */
    async putWonderExtra(extra: string[] =
        [
            WonderCloudData.Current,
            WonderCloudData.WonderData,
            WonderCloudData.Bag,
            WonderCloudData.Stance
        ], stageId?: number, noBlock?: boolean) {
        let putExtra = [];
        for (let _extra of extra) {
            let keyValueReq = new KeyValueReq();
            keyValueReq.key = _extra;
            if (_extra == WonderCloudData.Current) {
                keyValueReq.objData = this.wonderSpaceCurrent;
            } else if (_extra == WonderCloudData.WonderData) {
                keyValueReq.objData = this.wonderSpaceData;
            } else if (_extra == WonderCloudData.Hero) {
                keyValueReq.objData = this.wonderSpaceHero;
            } else if (_extra == WonderCloudData.Bag) {
                keyValueReq.objData = this.wonderSpaceBag;
            } else if (_extra == WonderCloudData.Stance) {
                keyValueReq.objData = this.wonderStance;
            }
            putExtra.push(keyValueReq);
        }
        let wonderExtraReq = new WonderExtraReq();
        wonderExtraReq.pairs = putExtra;
        wonderExtraReq.stageId = stageId ? stageId : this.wonderOpenedChapter.id;
        await this._gm.request(GameProxy.apiwonderputWonderExtra, wonderExtraReq, GameProxy, noBlock);
    }

    /**设置奇妙时空云端持久化数据 */
    async putWonderExtraSave(noBlock?: boolean) {
        let putExtra = [];
        let keyValueReq = new KeyValueReq();
        keyValueReq.key = "ExtraData";
        keyValueReq.objData = this.wonderOpenedChapter.extraSave.wonderExtraSave;
        putExtra.push(keyValueReq);
        let wonderExtraReq = new WonderExtraReq();
        wonderExtraReq.pairs = putExtra;
        wonderExtraReq.stageId = this.wonderOpenedChapter.id;
        let proto = await this._gm.request(GameProxy.apiwonderputWonderExtraSave, wonderExtraReq, GameProxy, noBlock);
        this.wonderOpenedChapter.info.extraSave = this.wonderOpenedChapter.extraSave.wonderExtraSave;
    }

    /**重置迷雾 */
    async resetWonderExtraFog() {
        if (!this.wonderOpenedChapter) {
            return;
        }
        let putExtra = [];
        let keyValueReq = new KeyValueReq();
        keyValueReq.key = "ExtraData";
        this.wonderOpenedChapter.extraSave.wonderExtraSave.clearFogList = [];
        keyValueReq.objData = this.wonderOpenedChapter.extraSave.wonderExtraSave;
        putExtra.push(keyValueReq);
        let wonderExtraReq = new WonderExtraReq();
        wonderExtraReq.pairs = putExtra;
        wonderExtraReq.stageId = this.wonderOpenedChapter.id;
        let proto = await this._gm.request(GameProxy.apiwonderputWonderExtraSave, wonderExtraReq);
        this.wonderOpenedChapter.info.extraSave = proto as object;
    }

    /**清除 */
    async clearWonderExtraFog() {
        if (!this.wonderOpenedChapter || this._wonderNodeList.length == 0) {
            return;
        }
        let putExtra = [];
        let keyValueReq = new KeyValueReq();
        keyValueReq.key = "ExtraData";
        let clearFogList = [];
        for (let node of this._wonderNodeList) {
            if (node && node.getComponent(WonderSpaceBase)) {
                clearFogList.push(node.getComponent(WonderSpaceBase).cellId);
            }
        }
        this.wonderOpenedChapter.extraSave.wonderExtraSave.clearFogList = clearFogList;
        keyValueReq.objData = this.wonderOpenedChapter.extraSave.wonderExtraSave;
        putExtra.push(keyValueReq);
        let wonderExtraReq = new WonderExtraReq();
        wonderExtraReq.pairs = putExtra;
        wonderExtraReq.stageId = this.wonderOpenedChapter.id;
        let proto = await this._gm.request(GameProxy.apiwonderputWonderExtraSave, wonderExtraReq);
        this.wonderOpenedChapter.info.extraSave = proto as object;
    }

    /**领取关卡 */
    async recvStageReward(rewardId: string) {
        let wonderRewardReq = new WonderRewardReq();
        wonderRewardReq.rewardId = rewardId;
        wonderRewardReq.stageId = this.wonderOpenedChapter.id;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiwonderrecvStageReward, wonderRewardReq);
        this.wonderOpenedChapter.info.rewardRecvedIds.push(rewardId);
        gm.getReward(proto, true);
        commitLogic.commitReward(proto, DiamondSource.wonderSpaceBox);
    }

    /**重置关卡 */
    async resetWonder(stageId: number) {
        this._wonderInfo = await this._gm.request<WonderInfoBO>(GameProxy.apiwonderresetWonder, stageId);
        for (let chapter of this._wonderChapters) {
            if (chapter.id == stageId) {
                chapter.resetStage();
                break;
            }
        }
        this._wonderOpenedChapter = null;
        this.stopAsync();
    }

    /**设置关卡积分进度 */
    async setWonderScore() {
        let wonderScoreReq = new WonderScoreReq();
        let score: number = 0;
        for (let wonderSpaceData of this.wonderSpaceData) {
            if (wonderSpaceData) {
                let eventId = this.getEventIdByType(wonderSpaceData.wonderSpaceType);
                if (eventId > 0 && wonderSpaceData.wonderComplete) {
                    let config = spacetimeExploreConfig.find(a => a.event == eventId);
                    score += config.score;
                }
            }
        }
        if (score > this.wonderOpenedChapter.progress) {
            wonderScoreReq.score = score;
            wonderScoreReq.stageId = this.wonderOpenedChapter.id;
            let proto = await this._gm.request<number>(GameProxy.apiwondersetWonderScore, wonderScoreReq);
            this.wonderOpenedChapter.progress = proto;
        }
        this.wonderOpenedChapter.totalProgress = this.getTotalScore();
        this.setWonderSpaceExtraDirty();
    }

    async resetWonderScore(id) {
        let wonderScoreReq = new WonderScoreReq();
        wonderScoreReq.score = 0;
        wonderScoreReq.stageId = id;
        await this._gm.request<number>(GameProxy.apiwondersetWonderScore, wonderScoreReq);
    }

    /**雇佣一个英雄 */
    doEmployHero(heroVO: HeroVO) {
        let wisdomTreeHeroData = new WisdomTreeHeroData();
        wisdomTreeHeroData.heroVO = heroVO;
        wisdomTreeHeroData.hero = stringUtils.generateUUID();
        wisdomTreeHeroData.hp = new Hero(heroVO).getHp();
        wisdomTreeHeroData.hpMax = wisdomTreeHeroData.hp;
        wisdomTreeHeroData.power = 0;
        wisdomTreeHeroData.isEmploy = true;
        this.wonderSpaceHero.push(wisdomTreeHeroData);
        this.setWonderSpaceDirty([WonderCloudData.Hero]);
    }

    /**温泉恢复血量 */
    doSpringHero() {
        this.wonderHero.doSpringHero(this.wonderBag.getSpringValue());
        this.setWonderSpaceDirty([WonderCloudData.Hero]);
    }

    /**随机复活一个英雄 */
    doReviveHero() {
        let deadHeros = this.wonderSpaceHero.where(a => a.hp <= 0);
        if (deadHeros.length > 0) {
            let rd = Math.floor(Math.random() * deadHeros.length);
            let hero = deadHeros[rd];
            hero.hp = hero.hpMax;
        } else {
            let percent: number = 1;
            let minHero: WisdomTreeHeroData = null;
            for (let hero of this.wonderSpaceHero) {
                let per = hero.hp / hero.hpMax;
                if (per < percent) {
                    per = percent;
                    minHero = hero;
                }
            }
            if (minHero) {
                minHero.hp = minHero.hpMax;
                minHero.power = minHero.powerMax;
            }
        }
        this.setWonderSpaceDirty([WonderCloudData.Hero]);
    }

    /**复活选择的英雄 */
    doReviveSelectHero(hero: Hero) {
        let wisdomHero = this.wonderSpaceHero.find(a => (a.heroVO && a.heroVO.heroId == hero.getId()) || a.hero == hero.getId());
        if (wisdomHero && wisdomHero.hp <= 0) {
            wisdomHero.hp = wisdomHero.hpMax;
            this.setWonderSpaceDirty([WonderCloudData.Hero]);
        }
    }

    /**特定类型英雄扣血 */
    doSubHeroHp(carceer: number, percent: number) {
        let heroes: Hero[] = heroLogic.getHeroes({ sort: true });
        for (let hero of wonderSpaceLogic.wonderPubHero) {
            heroes.unshift(new Hero(hero.heroVO));
        }
        for (let hero of heroes) {
            if (hero.getCareer() == carceer) {
                let treeHero = wonderSpaceLogic.wonderSpaceHero.find(a => a.hero == hero.getId() || a.heroVO && a.heroVO.heroId == hero.getId());
                if (treeHero) {
                    treeHero.hp -= treeHero.hpMax * (percent / 100);
                    treeHero.hp = Math.max(0, treeHero.hp);
                } else {
                    let wisdomTreeHeroData = new WisdomTreeHeroData();
                    wisdomTreeHeroData.hero = hero.getId();
                    wisdomTreeHeroData.hp = hero.getHp() * (1 - percent / 100);
                    wisdomTreeHeroData.hpMax = hero.getHp();
                    wisdomTreeHeroData.power = hero.getPowerMax();
                    wonderSpaceLogic.wonderHero.wisdomTreeHeroData.push(wisdomTreeHeroData);
                    wonderSpaceLogic.wonderHero.addWisdomTreeHero([wisdomTreeHeroData]);
                }
            }
        }
        this.setWonderSpaceDirty([WonderCloudData.Hero]);
    }

    /**所有敌方扣血 */
    doSubMonsterHp(percent: number) {
        for (let wonderSpaceData of this.wonderSpaceData) {
            if (wonderSpaceData.wonderSpaceType == WonderSpaceType.普通守卫 ||
                wonderSpaceData.wonderSpaceType == WonderSpaceType.精英守卫 ||
                wonderSpaceData.wonderSpaceType == WonderSpaceType.BOSS守卫) {
                if (wonderSpaceData.wonderData && wonderSpaceData.wonderData.guardData) {
                    for (let guardData of wonderSpaceData.wonderData.guardData) {
                        guardData.hp -= guardData.hpMax * (percent / 100);
                        guardData.hp = Math.max(0, guardData.hp);
                    }
                }
            }
        }
        this.setWonderSpaceDirty([WonderCloudData.Hero]);
    }

    /**增加果实 */
    doFruitAdd(fruitId: number) {
        this.wonderBag.addFruit(fruitId);
        this.setWonderSpaceDirty([WonderCloudData.Current, WonderCloudData.WonderData, WonderCloudData.Bag]);
    }

    /**减少果实 */
    doFruitSub(fruitId: number) {
        this.wonderBag.subFruit(fruitId);
        this.setWonderSpaceDirty([WonderCloudData.Bag]);
    }

    getTotalScore() {
        let score: number = 0;
        for (let wonderSpaceData of this.wonderSpaceData) {
            if (wonderSpaceData) {
                let eventId = this.getEventIdByType(wonderSpaceData.wonderSpaceType);
                if (eventId > 0) {
                    let config = spacetimeExploreConfig.find(a => a.event == eventId);
                    score += config.score;
                }
            }
        }
        return score;
    }

    getEventIdByType(wonderSpaceType: WonderSpaceType) {
        let eventId = 0;
        if (wonderSpaceType == WonderSpaceType.普通守卫) {
            eventId = 1001;
        } else if (wonderSpaceType == WonderSpaceType.精英守卫) {
            eventId = 1002;
        } else if (wonderSpaceType == WonderSpaceType.BOSS守卫) {
            eventId = 1003;
        } else if (wonderSpaceType == WonderSpaceType.祭坛) {
            eventId = 1004;
        } else if (wonderSpaceType == WonderSpaceType.泉水) {
            eventId = 1005;
        } else if (wonderSpaceType == WonderSpaceType.酒馆) {
            eventId = 1006;
        } else if (wonderSpaceType == WonderSpaceType.金币宝箱) {
            eventId = 1007;
        } else if (wonderSpaceType == WonderSpaceType.钻石宝箱) {
            eventId = 1008;
        } else if (wonderSpaceType == WonderSpaceType.传送门) {
            eventId = 1009;
        } else if (wonderSpaceType == WonderSpaceType.终极宝箱) {
            eventId = 1010;
        }
        return eventId;
    }

}

let wonderSpaceLogic = new WonderSpaceLogic();
export default wonderSpaceLogic;