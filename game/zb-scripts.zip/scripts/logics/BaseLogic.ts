import IGameManager from "../manager/IGameManager";

export default class BaseLogic {
    protected _gm: IGameManager = null;

    init(proto: any, gm: IGameManager): void {
        this._gm = gm;
    }
}