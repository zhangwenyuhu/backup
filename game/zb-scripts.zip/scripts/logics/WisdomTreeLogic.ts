import BaseLogic from "./BaseLogic";
import IGameManager from "../manager/IGameManager";
import GameProxy, {
    CloudObjectReq,
    GoodVO,
    HeroVO,
    KeyValueReq,
    ResourceVO,
    RewardBO,
    WisdomBuyReq,
    WisdomGuardRewardReq,
    WisdomMapBO,
    WisdomNodeUpdateReq,
    WisdomShopItem
} from "../proxy/GameProxy";
import WisdomTreeBase, {
    WisdomCloudData,
    WisdomStance,
    WisdomTreeCurrent,
    WisdomTreeData,
} from "../data/wisdomtree/WisdomTreeBase";
import WisdomTreeHero, {WisdomTreeHeroData} from "../data/wisdomtree/WisdomTreeHero";
import WisdomTreeBag, {WisdomTreeBagData} from "../data/wisdomtree/WisdomTreeBag";
import wisdomTreeConfig from "../configs/wisdomTreeConfig";
import Hero from "../data/card/Hero";
import stringUtils from "../utils/StringUtils";
import bagLogic from "./BagLogic";
import ToastError from "../error/ToastError";
import gm from "../manager/GameManager";
import WisdomTree from "../data/wisdomtree/data/WisdomTree";
import WisdomCurrent from "../data/wisdomtree/data/WisdomCurrent";
import heroLogic from "./HeroLogic";
import EManager from "../manager/EventManager";
import {stringConfigMap} from "../configs/stringConfig";
import commitLogic, {DiamondSource} from "./CommitLogic";
import activityLogic, {ActivityType} from "./ActivityLogic";
import {TaskActivityType} from "../utils/DefineUtils";

class WisdomTreeLogic extends BaseLogic {

    //原始数据
    protected _wisdomMap: Map<string, object> = new Map<string, object>();
    protected _wisdomMapBO: WisdomMapBO[] = [];

    //数据对象
    protected _wisdomCurrent: WisdomCurrent = null;
    protected _wisdomTree: WisdomTree = null;
    protected _wisdomHero: WisdomTreeHero = null;
    protected _wisdomBag: WisdomTreeBag = null;
    protected _wisdomStance: WisdomStance = null;

    protected _wisdomInterval: number = -1;
    protected _wisdomTreeDirty: string[] = [];
    protected _wisdomTreeNodeDirty: number[] = [];
    protected _wisdomtreeGetFruit: boolean = true;
    protected _wisdomKey: string = "wisdomKey";
    protected _wisdomCloudData = null;
    protected _top5Power: number = 0;

    init(gm: IGameManager) {
        super.init(null, gm);
    }

    get top5Power(): number {
        return this._top5Power;
    }

    get wisdomTreeCurrent(): WisdomTreeCurrent {
        return this._wisdomCurrent && this._wisdomCurrent.wisdomTreeCurrent;
    }

    get wisdomTreeCurrentPos(): number {
        return (this.wisdomTreeCurrent.wisdomCurrentLayer - 1) * 11 + this.wisdomTreeCurrent.wisdomCurrentNode;
    }

    getWisdomTreeReward(layer: number): RewardBO[] {
        let wisdomMap = this._wisdomMapBO[layer - 1];
        if (wisdomMap) {
            return wisdomMap.rewards;
        }
        return [];
    }

    get wisdomTreeCurrentTreeData(): WisdomTreeData {
        let wisdomTreeData = this.wisdomTreeData[this.wisdomTreeCurrentPos - 1];
        let index = this.wisdomTreeCurrent.wisdomCurrentDirection > 0 ? this.wisdomTreeCurrent.wisdomCurrentDirection - 1 : 0;
        let treeData = wisdomTreeData[index];
        return treeData;
    }

    get wisdomTreeData(): WisdomTreeData[][] {
        return this._wisdomTree.wisdomTreeData;
    }

    get wisdomTreeHero(): WisdomTreeHeroData[] {
        return this._wisdomHero.wisdomTreeHeroData;
    }

    get wisdomTreeBag(): WisdomTreeBagData[] {
        return this._wisdomBag.wisdomTreeBagData;
    }

    get wisdomTree(): WisdomTree {
        return this._wisdomTree;
    }

    get wisdomBag(): WisdomTreeBag {
        return this._wisdomBag;
    }

    get wisdomHero(): WisdomTreeHero {
        return this._wisdomHero;
    }

    get wisdomPubHero(): WisdomTreeHeroData[] {
        let hero: WisdomTreeHeroData[] = [];
        for (let wisdomHero of this._wisdomHero.wisdomTreeHeroData) {
            if (wisdomHero.isEmploy) {
                hero.push(wisdomHero);
            }
        }
        return hero;
    }

    get wisdomStance(): WisdomStance {
        return this._wisdomStance;
    }

    set wisdomStance(value: WisdomStance) {
        this._wisdomStance = value;
    }

    get wisdomTreeGetFruit(): boolean {
        return this._wisdomtreeGetFruit;
    }

    set wisdomTreeGetFruit(value: boolean) {
        this._wisdomtreeGetFruit = value;
    }

    get wisdomCloudData() {
        return this._wisdomCloudData;
    }

    get wisdomNewUser() {
        return !this._wisdomCloudData || this._wisdomCloudData["passCnt"] == 0;
    }

    get wisdomFirstTime(): boolean {
        if (!this._wisdomCloudData || this._wisdomCloudData["firstTime"] != 1) {
            return true;
        }
        return false;
    }

    set wisdomCloudData(value) {
        this._wisdomCloudData = value;
    }

    setWisdomTreeDirty(wisdomTree: string[]) {
        for (let wisdom of wisdomTree) {
            if (!this._wisdomTreeDirty.find(a => a == wisdom)) {
                this._wisdomTreeDirty.push(wisdom);
            }
        }
    }

    setWisdomTreeNodeDirty(nodeIndexs: number[]) {
        for (let nodeIndex of nodeIndexs) {
            if (this._wisdomTreeNodeDirty.indexOf(nodeIndex) == -1) {
                this._wisdomTreeNodeDirty.push(nodeIndex);
            }
        }
    }

    asyncData() {
        if (this._wisdomTreeDirty.length > 0) {
            this.doPutWisdomExtra(this._wisdomTreeDirty, true);
            this._wisdomTreeDirty = [];
        }
        if (this._wisdomTreeNodeDirty.length > 0) {
            this.doUpdateWisdomNodeArr(this._wisdomTreeNodeDirty, true);
            this._wisdomTreeNodeDirty = [];
        }
    }

    startAsync() {
        this.stopAsync();
        this._wisdomInterval = setInterval(this.asyncData.bind(this), 100) as any;
    }

    stopAsync() {
        if (this._wisdomInterval != -1) {
            clearInterval(this._wisdomInterval);
            this._wisdomInterval = -1;
        }
    }

    /**获取智慧树云端数据 */
    async doGetWisdomExtra() {
        this._wisdomMap = await this._gm.request<Map<string, object>>(GameProxy.apiWisdomTreegetWisdomExtra, null);
        this._wisdomCurrent = new WisdomCurrent(null, this._wisdomMap[WisdomCloudData.Current]);
        this._wisdomTree = new WisdomTree(null, this._wisdomMap[WisdomCloudData.TreeData]);
        this._wisdomHero = new WisdomTreeHero(this._wisdomMap[WisdomCloudData.Hero]);
        this._wisdomBag = new WisdomTreeBag(this._wisdomMap[WisdomCloudData.Bag]);
        this._wisdomStance = this._wisdomMap[WisdomCloudData.Stance];
        this._top5Power = this._wisdomMap["top5Power"];
        this.startAsync();
    }

    /**获取(生成)智慧树地图数据 */
    async doGetWisdomMaps() {
        let proto = await this._gm.request<WisdomMapBO[]>(GameProxy.apiWisdomTreegetWisdomMaps, null);
        this._wisdomMapBO = proto;
        await this.doGetCloudData();
        await this.doGetWisdomExtra();
        if (this.wisdomTreeCurrent && proto[0].resetTs == this.wisdomTreeCurrent.wisdomEndTime) {
            console.log("获取云端数据");
        } else {
            this._wisdomCurrent = new WisdomCurrent(proto);
            this._wisdomTree = new WisdomTree(proto);
            this._wisdomHero = new WisdomTreeHero([]);
            this._wisdomBag = new WisdomTreeBag([]);
            this._wisdomStance = null;
            await this.doPutWisdomExtra();
        }
    }

    /**重置智慧树地图 */
    async doResetWisdomMaps() {
        let proto = await this._gm.request<WisdomMapBO[]>(GameProxy.apiWisdomTreegetWisdomMaps, null);
        this._wisdomMapBO = proto;
        this._wisdomCurrent = new WisdomCurrent(proto);
        this._wisdomTree = new WisdomTree(proto);
        this._wisdomHero = new WisdomTreeHero([]);
        this._wisdomBag = new WisdomTreeBag([]);
        this._wisdomStance = null;
        await this.doPutWisdomExtra();
    }

    /**修改关卡 */
    doModifyStage(stage: string) {
        let str = stage.split('-');
        if (str.length != 2) {
            return;
        }
        let layer = parseInt(str[0]);
        let node = parseInt(str[1]);
        if (layer >= 1 && layer <= 3) {
            this.wisdomTreeCurrent.wisdomCurrentLayer = layer;
        }
        if (node >= 1 && node <= 11) {
            this.wisdomTreeCurrent.wisdomCurrentNode = node;
        }
        this.setWisdomTreeDirty([WisdomCloudData.Current]);
    }

    /**修改过关次数 */
    doModifyCloudData(passCnt: number) {
        let data = {};
        data["resetTs"] = this.wisdomTreeCurrent.wisdomEndTime;     //重置时间戳
        data["node"] = this.wisdomTreeCurrent.wisdomCurrentNode;    //当前节点
        data["layer"] = this.wisdomTreeCurrent.wisdomCurrentLayer;  //当前层
        data["passCnt"] = passCnt;
        let req = new CloudObjectReq();
        req.expire = 0;
        req.key = this._wisdomKey;
        req.objData = { data: data };
        this._gm.request(GameProxy.apiutilsetCloudObject, [req], GameProxy, true);
    }

    /**路线选择 */
    doRoadChoose(wisdomPos: number, choose: number = 1 | 2) {
        let needSync: boolean = false;
        let treeIndexs: number[] = [];
        for (let i = wisdomPos - 1; i < wisdomTreeConfig.length; i++) {
            let wisdomConfig = wisdomTreeConfig[i];
            if (wisdomConfig.roadChoose == 0) {
                break;
            }
            let treeData = this.wisdomTree.wisdomTreeData[i];
            let treeDataBase = this.wisdomTree.wisdomTreeBase[i];
            if (treeData.length == 2) {
                if (choose == 1) {
                    treeData[1].wisdomNodeChoose = false;
                    treeDataBase[1].wisdomNodeChoose = false;
                    EManager.emit(WisdomTreeBase.Event.onNodeChoose, { target: treeDataBase[1] });
                } else if (choose == 2) {
                    treeData[0].wisdomNodeChoose = false;
                    treeDataBase[0].wisdomNodeChoose = false;
                    EManager.emit(WisdomTreeBase.Event.onNodeChoose, { target: treeDataBase[0] });
                }
                treeIndexs.push(i);
                needSync = true;
            }
        }
        if (!this.wisdomTreeCurrent.wisdomChoose) {
            this.wisdomTreeCurrent.wisdomChoose = true;
            needSync = true;
        }
        if (needSync) {
            this.setWisdomTreeDirty([WisdomCloudData.Current]);
            this.setWisdomTreeNodeDirty(treeIndexs);
        }
    }

    checkCanRoadChoose(wisdomPos: number) {
        for (let i = wisdomPos - 1; i < wisdomTreeConfig.length; i++) {
            let wisdomConfig = wisdomTreeConfig[i];
            if (wisdomConfig.roadChoose == 0) {
                return false;
            }
            let treeData = this.wisdomTree.wisdomTreeData[i];
            if (treeData.length == 2) {
                if (treeData[0].wisdomNodeChoose && treeData[1].wisdomNodeChoose) {
                    return true;
                }
            }
        }
        return false;
    }

    /**增加果实 */
    doFruitAdd(fruitId: number) {
        this._wisdomBag.addFruit(fruitId);
        this.setWisdomTreeDirty([WisdomCloudData.Current, WisdomCloudData.Bag]);
    }

    /**减少果实 */
    doFruitSub(fruitId: number) {
        this._wisdomBag.subFruit(fruitId);
        this.setWisdomTreeDirty([WisdomCloudData.Bag]);
    }

    /**雇佣一个英雄 */
    doEmployHero(heroVO: HeroVO) {
        let wisdomTreeHeroData = new WisdomTreeHeroData();
        wisdomTreeHeroData.heroVO = heroVO;
        wisdomTreeHeroData.hero = stringUtils.generateUUID();
        wisdomTreeHeroData.hp = new Hero(heroVO).getHp();
        wisdomTreeHeroData.hpMax = wisdomTreeHeroData.hp;
        wisdomTreeHeroData.power = 0;
        wisdomTreeHeroData.isEmploy = true;
        this.wisdomTreeHero.push(wisdomTreeHeroData);
        this.setWisdomTreeDirty([WisdomCloudData.Hero]);
    }

    /**战斗结束保存英雄的血量及能力 */
    doSaveHeroHpAndPower(heroList: rpgfight.Hero[]) {
        for (let hero of heroList) {
            // this._wisdomTree.wisdomTreeData
        }
    }

    /**温泉恢复血量 */
    doSpringHero() {
        this.wisdomHero.doSpringHero(this.wisdomBag.getSpringValue());
        this.setWisdomTreeDirty([WisdomCloudData.Hero]);
    }

    /**随机复活一个英雄 */
    doReviveHero() {
        let deadHeros = this.wisdomTreeHero.where(a => a.hp <= 0);
        if (deadHeros.length > 0) {
            let rd = Math.floor(Math.random() * deadHeros.length);
            let hero = deadHeros[rd];
            hero.hp = hero.hpMax;
        } else {
            let percent: number = 1;
            let minHero: WisdomTreeHeroData = null;
            for (let hero of this.wisdomTreeHero) {
                let per = hero.hp / hero.hpMax;
                if (per < percent) {
                    per = percent;
                    minHero = hero;
                }
            }
            if (minHero) {
                minHero.hp = minHero.hpMax;
                minHero.power = minHero.powerMax;
            }
        }
        this.setWisdomTreeDirty([WisdomCloudData.Hero]);
    }

    /**设置智慧树云端数据 */
    async doPutWisdomExtra(extra: string[]
        = [
            WisdomCloudData.Current,
            WisdomCloudData.TreeData,
            WisdomCloudData.Hero,
            WisdomCloudData.Bag
        ], noBlock?: boolean) {
        let putExtra = [];
        for (let _extra of extra) {
            let keyValueReq = new KeyValueReq();
            keyValueReq.key = _extra;
            if (_extra == WisdomCloudData.Current) {
                keyValueReq.objData = this.wisdomTreeCurrent;
            } else if (_extra == WisdomCloudData.TreeData) {
                keyValueReq.objData = this.wisdomTreeData;
            } else if (_extra == WisdomCloudData.Hero) {
                keyValueReq.objData = this.wisdomTreeHero;
            } else if (_extra == WisdomCloudData.Bag) {
                keyValueReq.objData = this.wisdomTreeBag;
            } else if (_extra == WisdomCloudData.Stance) {
                keyValueReq.objData = this.wisdomStance;
            }
            putExtra.push(keyValueReq);
        }
        this.doPutCloudData(this.wisdomTreeCurrent.wisdomCurrentLayer == 3 && this.wisdomTreeCurrent.wisdomCurrentNode == 11);
        await this._gm.request(GameProxy.apiWisdomTreeputWisdomExtra, putExtra, GameProxy, noBlock);
    }

    /**更新智慧树节点数据 */
    async doUpdateWisdomNodeArr(nodeIndex: number[], noBlock?: boolean) {
        //index从0开始
        let wisdomNodeReqs = [];
        for (let index of nodeIndex) {
            let wisdomNodeUpdateReq = new WisdomNodeUpdateReq();
            wisdomNodeUpdateReq.nodeIndex = index;
            wisdomNodeUpdateReq.newData = this.wisdomTreeData[index];
            wisdomNodeReqs.push(wisdomNodeUpdateReq);
            console.log("更新:" + index);
        }
        await this._gm.request(GameProxy.apiWisdomTreeupdateWisdomNodeArr, wisdomNodeReqs, GameProxy, noBlock);
    }

    /**智慧树商店购买 */
    async doBuy(shopItem: WisdomShopItem) {
        let good = bagLogic.getGood(shopItem.costType);
        let price = Math.floor(shopItem.amt * shopItem.discount);
        if (good.getAmount() < price) {
            throw new ToastError(stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() }));
        }
        let wisdomBuyReq = new WisdomBuyReq();
        wisdomBuyReq.shopId = shopItem.shopId;
        wisdomBuyReq.order = shopItem.order;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiWisdomTreebuy, wisdomBuyReq);
        gm.getReward(proto, true);
        good.setAmount(good.getAmount() - price);
    }

    /**刷新智慧树商店数据 */
    async doRefreshShops() {
        await this._gm.request<WisdomMapBO[]>(GameProxy.apiWisdomTreerefreshShops, 0);
    }

    /**领取智慧树守卫奖励 */
    async doGetGuardReward(wisdomTreeBase: WisdomTreeBase) {
        let wisdomRewardReq = new WisdomGuardRewardReq();
        wisdomRewardReq.eventId = wisdomTreeBase.wisdomTreeData.wisdomEventType;
        wisdomRewardReq.guardPower = wisdomTreeBase.getTotalPower();
        wisdomRewardReq.layerNo = wisdomTreeBase.wisdomTreeData.wisdomLayer;
        wisdomRewardReq.nodeNo = wisdomTreeBase.wisdomTreeData.wisdomNode;
        wisdomRewardReq.passRewardCount = wisdomTreeLogic.wisdomTreeCurrent.wisdomStageGold;
        wisdomRewardReq.top5Rank = wisdomTreeBase.getTotalRank();
        if (wisdomRewardReq.nodeNo == 11) {
            activityLogic.doIncTaskActProgress(ActivityType.WisdomStorm, TaskActivityType.DefeatWisdom, wisdomRewardReq.layerNo.toString(), 1, true);
        }
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiWisdomTreegetGuardReward, wisdomRewardReq);
        if (proto) {
            gm.getReward(proto, false);
            commitLogic.commitReward(proto, DiamondSource.wisdomTreeGuard);
        }
    }

    /**领取智慧树层宝箱 */
    async doGetLayerReward() {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiWisdomTreegetLayerReward, this.wisdomTreeCurrent.wisdomCurrentLayer);
        gm.getReward(proto, true);
        this.wisdomTreeCurrent.wisdomLayerReward = true;
        this.setWisdomTreeDirty([WisdomCloudData.Current]);
        if (this.wisdomTreeCurrent.wisdomCurrentLayer == 3) {
            heroLogic.artifactUnlockInfo && heroLogic.artifactUnlockInfo.addTaskProgress(3002);
        }
        commitLogic.commitReward(proto, DiamondSource.wisdomTreeCicle);
    }

    /**进入下一层 */
    async doEnterNextLayer() {
        if (this.wisdomTreeCurrent.wisdomCurrentLayer < 3) {
            this.wisdomTreeCurrent.wisdomCurrentLayer++;
            this.wisdomTreeCurrent.wisdomCurrentNode = 1;
            this.wisdomTreeCurrent.wisdomLayerReward = false;
            this.wisdomTreeCurrent.wisdomCurrentDirection = 0;
            this.setWisdomTreeDirty([WisdomCloudData.Current]);
        }
    }

    /**使用复活道具 */
    async doRebornGoodUse() {
        let proto = await this._gm.request<GoodVO>(GameProxy.apiWisdomTreerebornGoodUse, null);
        bagLogic.getGood(proto.propId).setAmount(proto.amt);
        let heroes = heroLogic.getHeroes({ sort: true });
        for (let hero of heroes) {
            let existHero = this.wisdomTreeHero.find(a => a.hero == hero.getId());
            if (existHero) {
                existHero.hp = existHero.hpMax;
                existHero.power = existHero.powerMax;
            } else {
                let wisdomHeroData = new WisdomTreeHeroData();
                wisdomHeroData.hero = hero.getId();
                wisdomHeroData.hp = hero.getHp();
                wisdomHeroData.hpMax = hero.getHp();
                wisdomHeroData.power = wisdomHeroData.powerMax;
                this.wisdomTreeHero.push(wisdomHeroData);
            }
        }
        for (let hero of this.wisdomTreeHero) {
            hero.hp = hero.hpMax;
            hero.power = hero.powerMax;
        }
        this.setWisdomTreeDirty([WisdomCloudData.Hero]);
    }

    /**复活选择的英雄 */
    doReviveSelectHero(hero: Hero) {
        let wisdomHero = this.wisdomTreeHero.find(a => (a.heroVO && a.heroVO.heroId == hero.getId()) || a.hero == hero.getId());
        if (wisdomHero && wisdomHero.hp <= 0) {
            wisdomHero.hp = wisdomHero.hpMax;
            this.setWisdomTreeDirty([WisdomCloudData.Hero]);
        }
    }

    async doGetCloudData() {
        let proto = await this._gm.request<{ [key: string]: object }>(GameProxy.apiutilgetCloudObject, [this._wisdomKey]);
        this._wisdomCloudData = proto[this._wisdomKey] && proto[this._wisdomKey]["data"];
        return this._wisdomCloudData;
    }

    doPutCloudData(pass: boolean, firstTime: boolean = false) {
        let data = {};
        data["resetTs"] = this.wisdomTreeCurrent.wisdomEndTime;     //重置时间戳
        data["node"] = this.wisdomTreeCurrent.wisdomCurrentNode;    //当前节点
        data["layer"] = this.wisdomTreeCurrent.wisdomCurrentLayer;  //当前层
        if (pass) {
            data["passCnt"] = this._wisdomCloudData && this._wisdomCloudData["passCnt"] ? this._wisdomCloudData["passCnt"] + 1 : 1;
        } else {
            data["passCnt"] = this._wisdomCloudData && this._wisdomCloudData["passCnt"] ? this._wisdomCloudData["passCnt"] : 0;
        }
        if (firstTime) {
            data["firstTime"] = 1;
        }
        let req = new CloudObjectReq();
        req.expire = 0;
        req.key = this._wisdomKey;
        req.objData = { data: data };
        this._wisdomCloudData = data;
        this._gm.request(GameProxy.apiutilsetCloudObject, [req], GameProxy, true);
    }

}

let wisdomTreeLogic = new WisdomTreeLogic();
export default wisdomTreeLogic;