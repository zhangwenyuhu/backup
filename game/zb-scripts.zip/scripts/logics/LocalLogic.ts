import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import EManager, { EName } from "../manager/EventManager";
import { PromptType } from "../data/prompt/PromptModal";
import storageUtils from "../utils/StorageUtils";
import { Storage } from "../utils/DefineUtils";

export enum localIndex {
    popFirstPay = 0,        // 是否今天弹出过首充礼包
    exploreRead = 1,        // 是否进入过探趣寻宝
    sevenFundRead = 2,      // 是否进入过新手基金
    surpriseGiftRead = 3,   // 是否进入过惊喜礼包
    grownupRead = 4,        // 是否进入过成长礼包
}

let localSave: string[] = [
    "popFirstPay",
    "exploreRed",
    "sevenFund",
    "surpriseGiftRead",
    "grownupRead",
]

export class LocalLogic extends BaseLogic {

    protected _localPre: string = "localLogic";
    protected _locals: { [key: string]: boolean } = {};     //  本地存储bool类型数据
    init(gm: IGameManager) {
        super.init(null, gm);

        this.readFromLocal();
    }
    // 每日重置数据
    resetLocalData() {
        Object.keys(this._locals).forEach((v, i, a) => {
            this._locals[v] = false;
            this.saveToLocal(v, false);
        })

        storageUtils.setBoolean(Storage.XsSenlinRead.Key, false);
        storageUtils.setBoolean(Storage.XsFeixuRead.Key, false);
        storageUtils.setBoolean(Storage.XsKuangdongRead.Key, false);
        storageUtils.setBoolean(Storage.VideoIgnoreTip.Key, false);
        storageUtils.setBoolean(Storage.ZhuanPanRead.Key, false);

        EManager.emit(EName.onRedDirty, PromptType.SevenFundBtn);
        EManager.emit(EName.onRedDirty, PromptType.ExploreReward);
    }

    getData(type: localIndex) {
        return this._locals[localSave[type]] || false;
    }
    setData(type: localIndex, value: boolean) {
        this.saveToLocal(localSave[type], value);
        this._locals[localSave[type]] = value;
    }

    // 从本地读取数据
    protected readFromLocal() {
        for (let i = 0; i < localSave.length; i++) {
            let key: string = this._localPre + localSave[i];
            this._locals[localSave[i]] = storageUtils.getBoolean({ Key: key, Default: false });
        }
    }
    // 保存到本地
    protected saveToLocal(key: string, value: any) {
        let saveKey: string = this._localPre + key;
        storageUtils.setBoolean(saveKey, value);
    }

}

let localLogic = new LocalLogic();
export default localLogic;