import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from "../manager/GameManager";
import GameProxy, { TurnInfoVO, TurnResVO, TurnTableReq } from "../proxy/GameProxy";
import { TaskActivityType, ZhuanPanType } from "../utils/DefineUtils";
import { defaultConfigMap } from "../configs/defaultConfig";
import playerLogic from "./PlayerLogic";
import rechargeLogic, { RightType } from "./RechargeLogic";
import EManager, { EName } from "../manager/EventManager";
import { PromptType } from "../data/prompt/PromptModal";
import activityLogic, { ActivityType } from "./ActivityLogic";
import cm from "../manager/ConfigManager";
import Hero from "../data/card/Hero";
import chatSocket from "../socket/ChatSocket";
import {SystemType} from "../socket/ChatUserData";

/* 转盘 */
export class ZhuanPanLogic extends BaseLogic {

    protected _normalRewards: { [key: string]: { id: number, level: number, reward: number[] } } = {};
    protected _betterRewards: { [key: string]: { id: number, level: number, reward: number[] } } = {};

    protected _normalMustTimes: number = 0;
    protected _normalFreshTs: number = 0;
    protected _normalFreshCount: number = 0;
    protected _normalLeftFree: number = 0;

    protected _betterMustTimes: number = 0;
    protected _betterFreshTs: number = 0;
    protected _betterFreshCount: number = 0;

    protected _actHeroEndTs: number = 0;
    public heroTipValid: boolean = true;

    init(gm: IGameManager) {
        super.init(null, gm);

    }

    // 精英寻宝限时英雄Id
    public getZpHeroId(): number {
        let cfgId: number = 0;
        let keys = Object.keys(this._betterRewards);
        for (let i = 0; i < keys.length; i++) {
            let value = keys[i];
            let data = this._betterRewards[value];
            if (data.id == 0) {
                cfgId = data.reward[0];
                break;
            }
        }
        return cfgId;
    }
    public getZpHeroLeftSec(): number {
        if (this._actHeroEndTs <= 0) { return 0; }
        let nowTs = gm.getCurrentTimestamp();
        let sec: number = (this._actHeroEndTs - nowTs) / 1000;
        return sec > 0 ? sec : 0;
    }
    public getZpHeroIconUrl(cfgId: number) {
        return `textures/hero/zp_hero_${cfgId}`;
    }
    public getZpHeroNameUrl(cfgId: number) {
        return `textures/hero/zp_hero_${cfgId}_text`;
    }

    // 十连转 实际的转动次数
    getTenTurnTimes(type: ZhuanPanType): number {
        let num: number = 10;
        if (type == ZhuanPanType.Better) { return num; }

        let vipLevel: number = playerLogic.getPlayer().getVipLevel();
        let vipEx = rechargeLogic.getVipBuffValue(RightType.WheelTenVip, vipLevel);
        num = vipEx ? vipEx : num;
        return num;
    }
    // 十连转 实际的消耗
    getTenCost(type: ZhuanPanType): number {
        let num: number = 10;
        let data = defaultConfigMap.wheelTenCost.value as string;
        let arr = data.split(';');
        if (arr.length >= type) {
            return parseInt(arr[type - 1]);
        }
        return num;
    }
    // 精英寻宝是否解锁
    isUnlockBetterZhuanPan(): boolean {
        let vip = playerLogic.getPlayer().getVipLevel();
        let unlockVip = rechargeLogic.getUnlockVipLevel(RightType.WheelAdv);
        return vip >= unlockVip
    }
    // 日常寻宝十连是否解锁
    isTenUnlcok(): boolean {
        let vip = playerLogic.getPlayer().getVipLevel();
        let unlockVip = rechargeLogic.getUnlockVipLevel(RightType.WheelTen);
        return vip >= unlockVip;
    }
    // 日常寻宝十二连是否解锁
    isTenAddUnlcok(): boolean {
        let vip = playerLogic.getPlayer().getVipLevel();
        let unlockVip = rechargeLogic.getUnlockVipLevel(RightType.WheelTenVip);
        return vip >= unlockVip;
    }
    freshCost(type: ZhuanPanType): number {
        let cost: number = 100;
        let cfg = type == ZhuanPanType.Normal ? defaultConfigMap.wheelRenovate : defaultConfigMap.wheelAdvRenovate;
        if (typeof cfg.value == 'string') {
            let arr = cfg.value.split(`;`);
            let num = this.freshCount(type);
            cost = num >= arr.length ? parseInt(arr[arr.length - 1]) : parseInt(arr[num]);
        } else if (typeof cfg.value == 'number') {
            cost = cfg.value;
        }
        return cost;
    }
    freshTs(type: ZhuanPanType): number {
        return type == ZhuanPanType.Normal ? this._normalFreshTs : this._betterFreshTs;
    }
    maxMustTimes(type: ZhuanPanType): number {
        let data = defaultConfigMap.wheelCounts.value as string;
        let arr = data.split(';');
        if (arr.length >= type) {
            return parseInt(arr[type - 1]);
        }
        return 10;
    }
    mustTimes(type: ZhuanPanType): number {
        return type == ZhuanPanType.Normal ? this._normalMustTimes : this._betterMustTimes;
    }
    freshCount(type: ZhuanPanType): number {
        return type == ZhuanPanType.Normal ? this._normalFreshCount : this._betterFreshCount;
    }
    leftFreeCount(): number {
        return this._normalLeftFree;
    }
    zhuanpanRewards(type: ZhuanPanType): { index: number, reward: number[], level: number, id: number }[] {
        let rewards: { index: number, reward: number[], level: number, id: number }[] = [];
        let data = type == ZhuanPanType.Normal ? this._normalRewards : this._betterRewards;
        let keys = Object.keys(data);
        for (let i = 0; i < keys.length; i++) {
            let tmp = {
                index: parseInt(keys[i]),
                reward: data[keys[i]].reward,
                level: data[keys[i]].level,
                id: data[keys[i]].id
            };
            rewards.push(tmp);
        }
        return rewards;
    }

    // 请求转盘信息
    async zhuanPanReq() {
        let proto = await gm.request<TurnInfoVO>(GameProxy.apiturntableturnInfo);
        this.updateZhuanPan(proto);
        EManager.emit(EName.onRedDirty, PromptType.ZhuanPanBtn);
        EManager.emit(EName.onUpdateZhuanPan);
    }

    // 转盘转动
    async zhuanPanTurnReq(type: ZhuanPanType, count: number, bVideo?: boolean) {
        let param = new TurnTableReq;
        param.turnType = bVideo ? ZhuanPanType.Normal : type;
        param.turnTimes = bVideo ? 1 : count;
        param.useVideo = bVideo;
        let proto = await gm.request<TurnResVO>(GameProxy.apiturntablegoturn, param);
        if (!proto) { return; }

        this.updateZhuanPanEx(type, proto);
        if (type == ZhuanPanType.Normal && this._normalLeftFree > 0) {
            this._normalLeftFree -= count;
            this._normalLeftFree = this._normalLeftFree > 0 ? this._normalLeftFree : 0;
        }
        let key = proto.resourceVO.extra[0] as any;
        let index: number = 1;
        if (key instanceof Array) {
            index = key[key.length - 1];
        } else {
            index = key;
        }
        key = key ? key : 1;

        if (type == ZhuanPanType.Normal) {
            activityLogic.doIncTaskActProgress(ActivityType.HappyTreasure, TaskActivityType.ZhuanPanNormal, null, param.turnTimes);
        } else if (type == ZhuanPanType.Better) {
            activityLogic.doIncTaskActProgress(ActivityType.HappyTreasure, TaskActivityType.ZhuanPanBetter, null, param.turnTimes);
        }

        if (proto.resourceVO.heros && proto.resourceVO.heros[0]) {
            let heroCfg = cm.getHeroConfig(proto.resourceVO.heros[0].heroCofId);
            if (heroCfg && heroCfg.Quality == Hero.Quality.Eternal) {
                chatSocket.sendMultiSystemMsg(SystemType.XBUR, [proto.resourceVO.heros[0]]);
            }
        }

        return { index: index, reward: proto.resourceVO, arr: key };
    }

    // 刷新转盘
    async zhuanpanFreshReq(type: ZhuanPanType) {
        let param = new TurnTableReq;
        param.turnType = type;
        param.turnTimes = 0;
        param.useVideo = false;
        let proto = await gm.request<TurnResVO>(GameProxy.apiturntablefreshturn, param);
        this.updateZhuanPanEx(type, proto);
    }

    protected updateZhuanPan(data: TurnInfoVO) {
        this._normalMustTimes = data.normalMustCount;
        this._normalFreshTs = data.normalFreshTs;
        this._normalLeftFree = data.normalFreeCount;
        this._normalFreshCount = data.normalFreshCount;
        this._betterMustTimes = data.advMustCount;
        this._betterFreshTs = data.advFreshTs;
        this._betterFreshCount = data.advFreshCount;
        this._actHeroEndTs = data.actEndTs;

        this._normalRewards = {};
        this.freshReward(ZhuanPanType.Normal, data.normalContent);

        this._betterRewards = {};
        this.freshReward(ZhuanPanType.Better, data.advContent);
    }

    protected updateZhuanPanEx(type: ZhuanPanType, data: TurnResVO) {
        if (!data) { return; }
        if (type == ZhuanPanType.Normal) {
            this._normalMustTimes = data.mustCount;
            this._normalFreshCount = data.freshCount;
            this._normalFreshTs = data.freshTs;
        } else {
            this._betterMustTimes = data.mustCount;
            this._betterFreshCount = data.freshCount;
            this._betterFreshTs = data.freshTs;
        }
        this.freshReward(type, data.content);
    }

    protected freshReward(type: ZhuanPanType, data: object) {
        if (!data) { return; }

        let keys: string[] = Object.keys(data);
        for (let i = 0; i < keys.length; i++) {
            if (type == ZhuanPanType.Normal) {
                this._normalRewards[keys[i]] = {
                    id: data[keys[i]].id,
                    level: data[keys[i]].level,
                    reward: data[keys[i]].item[0]
                };
            } else {
                this._betterRewards[keys[i]] = {
                    id: data[keys[i]].id,
                    level: data[keys[i]].level,
                    reward: data[keys[i]].item[0]
                };
            }
        }
    }
}

let zpLogic = new ZhuanPanLogic();
export default zpLogic;