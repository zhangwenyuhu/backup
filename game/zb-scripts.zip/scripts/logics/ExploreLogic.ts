
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import activityLogic, { ActivityType } from "./ActivityLogic";
import ExploreActivityDatas from "../data/activity/roleactivitydatas/ExploreActivityDatas";
import ExploreActConfig from "../data/activity/actconfig/ExploreActConfig";
import xunbaorewardconfig, { xunbaorewardconfigRow } from "../configs/xunbaorewardconfig";
import missionLogic from "./MissionLogic";
import GameProxy, { ActTreaChangeRewardReq, RankListReq, RankListVO, ActTreaOpenReq, ResourceVO, ActivityCumRewardReq, ActivityTreaInstBO } from "../proxy/GameProxy";
import gm from "../manager/GameManager";
import bagLogic from "./BagLogic";
import { GoodId } from "../data/card/Good";
import xunbaofinalrewardconfig, { xunbaofinalrewardconfigRow } from "../configs/xunbaofinalrewardconfig";
import localLogic, { localIndex } from "./LocalLogic";
import commitLogic, { DiamondSource } from "./CommitLogic";

export enum KEY_TYPE {
    Double = 1,
    KeyReward = 2,
    ChangeFinal = 3,
}

/* 探趣寻宝 */
export class ExploreLogic extends BaseLogic {

    protected _finalCfgs: xunbaofinalrewardconfigRow[] = [];
    protected _normalCfgs: xunbaorewardconfigRow[] = [];
    init(gm: IGameManager) {
        super.init(null, gm);
    }

    resetAll() {

    }
    // 探索一格
    async exploreBlockReq(index: number) {
        if (index < 0) { return; }

        let param = new ActTreaOpenReq;
        param.actId = this.getExploreModal().id;
        param.index = index;
        let proto = await gm.request<ResourceVO>(GameProxy.apiActivitytreaOpenBlock, param);
        return proto;
    }

    // 进入下一层
    async exploreNextLayerReq() {
        let actId: string = this.getExploreModal().id;
        let proto = await gm.request<ActivityTreaInstBO>(GameProxy.apiActivitytreaNewLayer, actId);
    }

    // 更换终极奖励
    async changeFinalReq(id: number, buff: boolean) {
        if (id <= 0) { return; }
        let param = new ActTreaChangeRewardReq;
        param.actId = this.getExploreModal().id;
        param.confId = id;
        param.useBuff = buff;

        let proto = await gm.request<number>(GameProxy.apiActivitytreaChangeFReward, param);
        if (proto) {
            this.getExploreData().setFinalId(proto);
        }
    }

    // 层数排行榜获取
    async exploreLevelRankReq(num: number) {
        let param = new RankListReq;
        param.customKey = this.getExploreModal().id;
        param.start = 0;
        param.end = num - 1;;
        let proto = await gm.request<RankListVO>(GameProxy.apirankmyGameRank, param);
        return proto;
    }

    // 领取层数奖励
    async recvExploreLevelRewardReq(tag: string) {
        let param = new ActivityCumRewardReq;
        param.actId = this.getExploreModal().id;
        param.recTag = tag;
        let proto = await gm.request<ResourceVO>(GameProxy.apiActivitytreaRecvLayerReward, param);
        gm.getReward(proto);
        commitLogic.commitReward(proto, DiamondSource.actExploreFloor);
    }

    getExploreModal() {
        return activityLogic.getActivityConfigs(ActivityType.Explore);
    }
    getExploreData(): ExploreActivityDatas {
        return this.getExploreModal().roleActivityDatas as ExploreActivityDatas;
    }
    getExplreCfg(): ExploreActConfig {
        return this.getExploreModal().actConfig as ExploreActConfig;
    }
    // 探趣寻宝层数
    getExploreLevel(): number {
        return this.getExploreData().getLevel() || 1;
    }
    // 寻宝钥匙数量
    getKeyAmt(): number {
        return bagLogic.getGood(GoodId.ExploreKey).getAmount();
    }
    // 探趣寻宝红点
    exploreRed(): boolean {
        let read: boolean = localLogic.getData(localIndex.exploreRead);
        return bagLogic.getGood(GoodId.ExploreKey).getAmount() > 0 || !read;
    }
    exploreHasReward(): boolean {
        let red: boolean = false;
        let reward = this.getExploreData().getLayerReward();
        red = reward.some((v, i, a) => {
            return v.progress >= v.needProgress && !v.recv;
        })
        return red;
    }
    // 活跃额外奖励
    getActiveExReward(type: number, score: number): number[] {
        let ex: number[] = [];
        if (activityLogic.isActivityValid(ActivityType.Explore) &&
            activityLogic.getActivityRemainTime(ActivityType.Explore) > 0) {
            let data = this.getExplreCfg().getActiveReward();
            if (data) {
                let reward = data.find((a) => { return a.count == score && a.type == type; });
                if (reward) {
                    ex.push(reward.rewardId);
                    ex.push(reward.rewardCount);
                }
            }
        }
        return ex;
    }
    // 获取设置的终极奖励id -1为未设置
    getFinalId(): number {
        return this.getExploreData().getFinalId();
    }
    getFinalRewardCfg(id: number) {
        return this.getFinalCfg().find((a) => { return a.ID == id; })
    }
    // 获取设置的终极奖励所在格子 -1为未探索
    getFinalIndex(): number {
        return this.getExploreData().getFinalIndex();
    }
    // 当前层奖励领取次数
    getRecvCount(id: number): number {
        return this.getExploreData().getCurrentRecvCount(id);
    }
    // 终极奖励的领取次数
    getFinalRecvCount(id: number): number {
        return this.getExploreData().getFinalRecvCount(id);
    }
    // 寻宝格子是否已探索
    isBlockExplored(index: number): boolean {
        return this.getExploreData().isBlockRecv(index);
    }
    // 寻宝buff是否有效
    isBuffValid(type: KEY_TYPE): boolean {
        return this.getExploreData().buffValid(type);
    }
    public getFinalCfg(forceInit: boolean = false) {
        if (this._finalCfgs.length <= 0 || forceInit) { this.initExploreCfg(); }
        return this._finalCfgs;
    }
    public getNormalCfg(forceInit: boolean = false) {
        if (this._normalCfgs.length <= 0 || forceInit) { this.initExploreCfg(); }
        return this._normalCfgs;
    }
    protected initExploreCfg() {
        this._finalCfgs = [];
        this._normalCfgs = [];
        let nowStage = missionLogic.getCurrentMission().getStageId();
        let level = this.getExploreLevel();
        this._finalCfgs = xunbaofinalrewardconfig.filter((v, i, a) => {
            return v.unlockstage < nowStage && v.unlockfloor <= level;
        })
        this._normalCfgs = xunbaorewardconfig.filter((v, i, a) => {
            let inLevel: boolean = v.numberofplies[0] <= level && level <= v.numberofplies[1];
            return inLevel;
        })
    }
}

let exploreLogic = new ExploreLogic();
export default exploreLogic;