import { defaultConfigMap } from './../configs/defaultConfig';
import { BuyCountBO } from './../proxy/GameProxy';

import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from '../manager/GameManager';
import GameProxy, { RankVO, RankReq, ResourceVO, RoleVO, TowerBattleReq, TowerBattleDataReq, HeroVO, ProcessRecordVO, TowerBattleFindReq } from "../proxy/GameProxy";
import User from "../data/user/User";
import skybuildconfig from "../configs/skybuildconfig";
import Tower from "../data/tower/Tower";
import { SystemId, BattleType } from "../utils/DefineUtils";
import playerLogic from "./PlayerLogic";
import Card from "../data/card/Card";
import Hero from "../data/card/Hero";
import HttpProxy from "../proxy/HttpProxy";
import { stringConfigMap } from "../configs/stringConfig";
import cm from "../manager/ConfigManager";
import factionskybuildconfig from "../configs/factionskybuildconfig";
import UnlockWrapper from "../view/widget/unlock/UnlockWrapper";
import { unlockConfigMap } from "../configs/unlockConfig";
import heroLogic from "./HeroLogic";
import bagLogic from './BagLogic';
import Good, { GoodId } from '../data/card/Good';
import stringUtils from '../utils/StringUtils';
import ToastError from '../error/ToastError';

export enum RaceType {
    Default = 0,
    Wuzhuang = 1,
    Jixie = 2,
    Bianzhong = 3,
    Jiangshi = 4,
}

/* 摩天大楼 */
export class TowerLogic extends BaseLogic {
    protected _towerRecords: {
        [key: string]: {
            id?: number,
            selfTroops?: Hero[],
            enemyIndex?: string[],
            enemyTroops?: Hero[],
            result?: any,
            skills?: { [key: number]: string },
            role?: string,
            win?: boolean,
            seed?: number,
            type?: number,
        }
    } = {};
    protected _lastTowerFailRecord: {
        id?: number,
        selfTroops?: Hero[],
        enemyIndex?: string[],
        enemyTroops?: Hero[],
        result?: any,
        skills?: { [key: number]: string },
        role?: string,
        win?: boolean,
        seed?: number,
        type?: number,
    } = null;

    private _currentTowerId: number = 0;
    private _myTowerRank: RankVO = null;

    private _towers: { [key: number]: Tower } = {};         // 所有关卡信息
    private _towerRanks: RankVO[] = [];                     // 关卡排行榜 
    private _maxLevel: number = 0;
    private _unPassPre: number = 3;
    private _roleRelations: { [key: string]: number } = {};

    // 种族塔
    private _raceTowerLevel: { [key: number]: number } = {};        // 种族当前关卡层数
    private _raceTowerMyRank: { [key: number]: RankVO } = {};        // 我的种族排行信息
    private _raceTowerRank: { [key: number]: RankVO[] } = {};        // 种族排行信息
    private _raceTowers: { [key: number]: Tower[] } = {};        // 种族塔关卡信息
    private _raceMaxLevel: { [key: number]: number } = {};

    // 战力前五英雄
    protected _myTopHero: Hero[] = [];
    protected _raceTopHero: { [key: number]: Hero[] } = {};

    init(gm: IGameManager) {
        super.init(null, gm);

        let maxLevel: number = skybuildconfig.length;
        this._maxLevel = maxLevel;
        for (let i = 0; i < maxLevel; i++) {
            let tmp = new Tower(i + 1);
            this._towers[tmp.id] = tmp;
        }

        this.initRaceTowerData();
    }

    public initMyTopHero() {
        let heros = heroLogic.getHeroes();
        heros.sort((a, b) => { return b.getPower() - a.getPower(); })
        this._myTopHero = heros.length <= 5 ? heros.slice(0, heros.length) : heros.slice(0, 5);

        for (let i = RaceType.Wuzhuang; i <= RaceType.Jiangshi; i++) {
            let tmp = heros.filter((v, index, a) => {
                let fact = v.getFaction() as number;
                let filtFact = i as number;
                return fact == filtFact;
            })
            this._raceTopHero[i] = tmp.length <= 5 ? tmp.slice(0, tmp.length) : tmp.slice(0, 5);
        }
    }

    public getMyTopHero(raceType?: number): Hero {
        if (!this._myTopHero || this._myTopHero.length <= 0) {
            this.initMyTopHero();
        }

        if (raceType) {
            let heroArr = this._raceTopHero[raceType];
            return (heroArr && heroArr.length > 0) ? heroArr[0] : null;
        } else {
            return this._myTopHero[0];
        }
    }

    // 获取自己前五的英雄的战力
    public getTop5HeroPower(raceType?: number): number {
        if (!this._myTopHero || this._myTopHero.length <= 0) {
            this.initMyTopHero();
        }

        let getHerosPower = (heros: Hero[]): number => {
            if (!heros || heros.length <= 0) { return 0; }
            let num: number = heros.reduce((pre, now, i, a) => {
                return pre + now.getPower();
            }, 0);
            return num;
        }

        if (raceType) {
            let heroArr = this._raceTopHero[raceType];
            return getHerosPower(heroArr);
        } else {
            return getHerosPower(this._myTopHero);
        }
    }

    // 获取下一个可获得通关奖励的楼层信息
    public getNextPassRewardTower(raceType?: number): Tower {
        let nowLevel: number = this.getCurrentTower(raceType);
        if (raceType) {
            for (let i = 0; i < this._raceTowers[raceType].length; i++) {
                let tmp = this._raceTowers[raceType][i];
                if (nowLevel <= tmp.getLevel() && tmp.getPassReward()) {
                    return tmp;
                }
            }
        } else {
            let keys = Object.keys(this._towers);
            for (let i = 0; i < keys.length; i++) {
                let id: number = parseInt(keys[i]);
                let tmp = this._towers[id];
                if (nowLevel <= tmp.getLevel() && tmp.getPassReward()) {
                    return tmp;
                }
            }
        }
        return null;
    }

    // 获取摩天楼阵容战力
    public async getFightTroopPower(type: RaceType) {
        let power: number = 0;
        let troop = await playerLogic.getTroop(BattleType.Tower, type);
        if (troop && troop.length > 0) {
            for (let i = 0; i < troop.length; i++) {
                if (troop[i]) { power += troop[i].getPower(); }
            }
        }
        return power;
    }

    resetAll() {

    }

    // 上传摩天楼挑战胜利数据
    async towerFightCommit(data: {
        battleData: Tower,
        troops: { selfTroop: Hero[], enemyTroop: Hero[] }
    }, skills: any, result: any[], seed: number = 0, commit: boolean = true) {

        if (!commit) {
            this._lastTowerFailRecord = {};
            this._lastTowerFailRecord.id = data.battleData.id;
            this._lastTowerFailRecord.role = playerLogic.getPlayer().getRoleId();
            this._lastTowerFailRecord.result = result;
            this._lastTowerFailRecord.skills = skills;
            this._lastTowerFailRecord.selfTroops = data.troops.selfTroop;
            this._lastTowerFailRecord.enemyTroops = data.troops.enemyTroop;
            this._lastTowerFailRecord.enemyIndex = data.troops.enemyTroop.map((v, i, a) => {
                return v.getId();
            })
            this._lastTowerFailRecord.win = false;
            this._lastTowerFailRecord.seed = seed;
            return;
        }

        let param = new TowerBattleReq();
        param.floor = data.battleData.id;
        param.battleData = {};

        param.battleData["seed"] = seed;
        param.battleData["skills"] = skills;
        param.battleData["result"] = result;

        param.battleData["troops"] = {}
        let troops = param.battleData["troops"];
        troops["selfTroop"] = [];
        troops["selfTroopIndex"] = [];
        troops["enemyTroop"] = [];
        troops["enemyTroops"] = [];
        data.troops.selfTroop.forEach((v, i, a) => {
            if (v) {
                let tmp = v.getHeroVO();
                tmp.lv = v.getLevel();
                troops["selfTroop"].push(tmp);
                troops["selfTroopIndex"].push(i);
            }
        });
        this._towers[data.battleData.id].getMonsters().forEach((v, i, a) => {
            if (v) {
                troops["enemyTroop"].push(v.getId());
                let tmp = v.getHeroVO();
                troops["enemyTroops"].push(tmp);
            }
        });

        heroLogic.artifactUnlockInfo && heroLogic.artifactUnlockInfo.addTaskProgress(3003);

        await gm.request<string>(GameProxy.apitowertowerBattle, param);
    }

    // 请求摩天楼挑战记录
    async towerFightRecordReq(roleId: string, towerId: number, type: RaceType = 0) {
        if (type > 0) {
            await this.raceTowerFightRecordReq(roleId, towerId, type);
            return;
        }
        if (this._towerRecords[`${roleId}-${towerId}`]) {
            return;
        }
        if (roleId == playerLogic.getPlayer().getRoleId() && towerId == this.getCurrentTower()) {
            return;
        }

        let param = new TowerBattleDataReq();
        param.floor = towerId;
        param.roleId = roleId;
        param.type = 0;

        let recordUrl = await gm.request<string>(GameProxy.apitowertowerBattleData, param);
        if (recordUrl) {
            let proto = await HttpProxy.httpGet<string>(recordUrl);
            let data = JSON.parse(proto);
            if (data && data.battleData && data.floor) {
                let towerRecord: any = {};
                towerRecord.id = data.floor;
                towerRecord.role = roleId;
                if (data.battleData.troops && data.battleData.troops.selfTroop) {
                    let troops: HeroVO[] = data.battleData.troops.selfTroop;
                    towerRecord.selfTroops = new Array(5);
                    troops.forEach((v, i, a) => {
                        let hero = new Hero(v);
                        let heroPos = data.battleData.troops.selfTroopIndex
                        if (heroPos && heroPos[i] >= 0) {
                            towerRecord.selfTroops[heroPos[i]] = hero;
                        }
                    });
                    if (data.battleData.troops.enemyTroop) {
                        towerRecord.enemyIndex = data.battleData.troops.enemyTroop;
                    }
                    if (data.battleData.troops.enemyTroops) {
                        let troops: HeroVO[] = data.battleData.troops.enemyTroops;
                        towerRecord.enemyTroops = [];
                        troops.forEach((v, i, a) => {
                            let hero = new Hero(v);
                            towerRecord.enemyTroops.push(hero);
                        });
                    }
                    if (data.battleData.skills) {
                        towerRecord.skills = data.battleData.skills;
                    }
                    if (data.battleData.result) {
                        towerRecord.result = data.battleData.result;
                    }
                    towerRecord.win = true;
                    towerRecord.seed = data.battleData.seed || 0;
                }

                this._towerRecords[`${roleId}-${towerId}`] = towerRecord;
            }
        } else {
            gm.toast(stringConfigMap.key_common_tip8.Value);
        }
    }

    getTowerRecord(roleId: string, towerId: number, type: RaceType = 0) {
        if (type > 0) {
            if (roleId == playerLogic.getPlayer().getRoleId() && towerId == this.getCurrentTower(type)) {
                return this._lastTowerFailRecord;
            }
            return this._towerRecords[`${roleId}-${towerId}-${type}`];
        }
        if (roleId == playerLogic.getPlayer().getRoleId() && towerId == this.getCurrentTower()) {
            return this._lastTowerFailRecord;
        }
        return this._towerRecords[`${roleId}-${towerId}`];
    }

    // 摩天楼进度查询
    async towerProcessReq(type: SystemId = 0) {
        let str: string = type > 0 ? type.toString() : null;
        let proto = await gm.request<ResourceVO>(GameProxy.apiprocessgetProcess, str);
        if (proto) {
            if (type == SystemId.Tower) {
                this._currentTowerId = proto.proces.stageId + 1;
                this._currentTowerId = this._currentTowerId < 1 ? 1 : this._currentTowerId;

                this._myTowerRank = proto.roleRank;
            } else {
                if (type > 0) {
                    let race = type - 2;
                    this._raceTowerLevel[race] = proto.proces.stageId + 1;
                    this._raceTowerMyRank[race] = proto.roleRank;
                } else {
                    if (proto.process) {
                        for (let i = 0; i < SystemId.Jiangshi; i++) {
                            let sysId: number = i + 1;
                            let data = proto.process.find((a) => { return a.systemId == sysId; });
                            if (data) {
                                if (data.systemId == SystemId.Tower) {
                                    this._currentTowerId = data.stageId + 1;
                                    this._currentTowerId = this._currentTowerId < 1 ? 1 : this._currentTowerId;
                                } else if (data.systemId >= SystemId.Wuzhang && data.systemId <= SystemId.Jiangshi) {
                                    let raceType = data.systemId - 2;
                                    this._raceTowerLevel[raceType] = data.stageId + 1;
                                }
                            } else {
                                if (sysId == SystemId.Tower) {
                                    this._currentTowerId = 1;
                                } else if (sysId >= SystemId.Wuzhang && sysId <= SystemId.Jiangshi) {
                                    let raceType = sysId - 2;
                                    this._raceTowerLevel[raceType] = 1;
                                }
                            }
                        }
                    }
                    if (proto.roleRanks) {
                        // 玩家种族塔排行信息
                        for (let i = 0; i < SystemId.Jiangshi; i++) {
                            let sysId: number = i + 1;
                            if (sysId == SystemId.Tower) {
                                let data = proto.roleRanks.find((a) => { return a.rankType == 6; });
                                this._myTowerRank = data ? data : this._myTowerRank;
                            } else if (sysId >= SystemId.Wuzhang && sysId <= SystemId.Jiangshi) {
                                let data = proto.roleRanks.find((a) => { return a.rankType == sysId + 8; });
                                if (data) {
                                    let raceType = sysId - 2;
                                    this._raceTowerMyRank[raceType] = data;
                                }
                            }
                        }
                    }
                }
            }
        }

        for (let i = RaceType.Wuzhuang; i <= RaceType.Jiangshi; i++) {
            if (!this._raceTowerLevel[i]) {
                this._raceTowerLevel[i] = 1;
            }
        }
        if (this._currentTowerId <= 0) { this._currentTowerId = 1; }
    }
    // 摩天楼挑战胜利
    async towerPassCommit(tower: Tower): Promise<Card[]> {
        if (tower.id < this._currentTowerId) { return []; }
        let proto = await gm.request<ResourceVO>(GameProxy.apiprocesspassProcess, { stageId: tower.id, systemId: SystemId.Tower });
        this._currentTowerId += 1;
        let cards = playerLogic.addCards(proto);

        if (proto) {
            if (proto.roleRank) {
                this._myTowerRank = proto.roleRank;
            }
        }
        heroLogic.artifactUnlockInfo && heroLogic.artifactUnlockInfo.addTaskProgress(3003);
        return cards;
    }
    // 摩天楼关卡好友
    async towerFriendsReq(id: number, type: RaceType = 0) {
        //if (this._towers[id].friends.length > 0) { return; }
        let param = new TowerBattleFindReq();
        param.floor = id;
        param.type = type > 0 ? type + 2 : 0;
        let proto = await gm.request<RoleVO[]>(GameProxy.apitowernowFriendsv2, param);

        if (type > 0) {
            let raceType = type;
            let index: number = this._raceTowers[raceType].findIndex((v, i, a) => { return v.cfg.FactionFloor == id; })
            if (index >= 0 && index < this._raceTowers[raceType].length) {
                this._raceTowers[raceType][index].friends = [];
                proto.forEach((v, i, a) => {
                    let tmp = new User(v);
                    this._raceTowers[raceType][index].friends.push(tmp);
                });
                this._raceTowers[raceType][index].freshTag = 1;
            }
        } else {
            this._towers[id].friends = [];
            proto.forEach((v, i, a) => {
                let tmp = new User(v);
                this._towers[id].friends.push(tmp);
            });
            this._towers[id].freshTag = 1;
        }
    }
    // 摩天楼关卡信息
    async towerDetailReq(id: number, type: RaceType = 0) {
        let param = new TowerBattleFindReq();
        param.floor = id;
        param.type = type > 0 ? type + 2 : 0;

        let proto = await gm.request<ProcessRecordVO[]>(GameProxy.apitowernowRecordsv2, param);
        if (type > 0) {
            // 种族塔
            let raceType = type;
            let index: number = this._raceTowers[raceType].findIndex((v, i, a) => { return v.cfg.FactionFloor == id; })
            if (index >= 0 && index < this._raceTowers[raceType].length) {
                this._raceTowers[raceType][index].pass = [];
                proto.forEach((v, i, a) => {
                    let tmp = new User(v.roleVO);
                    this._raceTowers[raceType][index].pass.push(tmp);
                    this._roleRelations[tmp.getRoleId()] = v.relationType;
                });
            }
        } else {
            // 摩天楼
            this._towers[id].pass = [];
            proto.forEach((v, i, a) => {
                let tmp = new User(v.roleVO);
                this._towers[id].pass.push(tmp);
                this._roleRelations[tmp.getRoleId()] = v.relationType;
            });
        }
    }

    async rankReq(type: RaceType = 0) {
        let param: RankReq = new RankReq;
        param.rankType = type > 0 ? type + 8 : 6;
        param.rewardId = 0;
        let proto = await gm.request<RankVO[]>(GameProxy.apirankrank, param);
        if (type > 0) {
            this._raceTowerRank[type] = proto;
        } else {
            this._towerRanks = proto;
        }
    }

    public getTowerRanks(type: RaceType = 0): RankVO[] {
        return type > 0 ? this._raceTowerRank[type] : this._towerRanks;
    }
    public getMyRank(type: RaceType = 0): number {
        return type > 0 ? this._raceTowerMyRank[type].no : this._myTowerRank.no;
    }

    public getMaxTower(): number {
        let maxLevel = this._currentTowerId + this._unPassPre < this._maxLevel ? this._currentTowerId + this._unPassPre : this._maxLevel;
        return maxLevel;
    }
    public getCurrentTower(type: RaceType = 0): number {
        return type > 0 ? this.getRaceTowerNowLevel(type) : this._currentTowerId;
    }
    public getMaxLevel(type: RaceType = 0): number {
        return type > 0 ? this._raceMaxLevel[type] : this._maxLevel;
    }
    public getTowerInfo(index: number, type: RaceType = 0) {
        return type == 0 ? this._towers[index] : this.getRaceTower(type, index);
    }

    public setTowerOpenAction(id: number, valid: boolean) {
        this._towers[id].openAction = valid;
    }

    public getTowerPass(id: number, type: RaceType = 0): User[] {
        if (type > 0) {
            return this.getRaceTower(type, id).pass;
        } else {
            return this._towers[id].pass;
        }
    }
    public getTowerFriends(id: number, type: RaceType = 0): User[] {
        return type > 0 ? this.getRaceTower(type, id).friends : this._towers[id].friends;
    }
    public getAllTowers(): Tower[] {
        let arr: Tower[] = [];
        Object.keys(this._towers).forEach((v, i, a) => {
            let id: number = parseInt(v);
            let towerLevel = this._currentTowerId + this._unPassPre;
            towerLevel = towerLevel > 5 ? towerLevel : 5;
            if (id <= towerLevel && id + 3 >= this._currentTowerId) {
                arr.push(this._towers[v]);
            }
        });
        return arr;
    }
    public getUserRelation(id: string): string {
        let relation = this._roleRelations[id];
        let str = "";
        if (relation == 1) {
            str = stringConfigMap.key_common_tip9.Value;
        } else if (relation == 2) {
            str = stringConfigMap.key_common_tip10.Value;
        }
        return str;
    }
    public getTowerPassRewards(level: number, type: RaceType = 0): number[][] {
        let rewards: number[][] = [];
        if (type > 0) {
            rewards = this.getRaceTower(type, level).cfg.Reward;
        } else {
            let cfg = cm.getTowerConfig(level);
            rewards = this.makeTowerReward(GoodId.Gold, cfg.gold, rewards);
            rewards = this.makeTowerReward(GoodId.BlackCoin, cfg.blackcoin, rewards);
            rewards = this.makeTowerReward(GoodId.Dust, cfg.dust, rewards);
            rewards = this.makeTowerReward(GoodId.SoulStone1, cfg.raresoul, rewards);
            rewards = this.makeTowerReward(GoodId.SoulStone2, cfg.elitesoul, rewards);
        }
        return rewards;
    }
    private makeTowerReward(id: number, data: number, rewards: number[][]): number[][] {
        if (data <= 0) { return rewards; }
        rewards.push([id, data])
        return rewards;
    }

    //  -- 种族塔 -- begin
    // 种族塔挑战记录上传
    async raceTowerFightCommit(data: {
        battleData: Tower,
        troops: { selfTroop: Hero[], enemyTroop: Hero[] }
    }, skills: any, result: any[], seed: number = 0, commit: boolean = true) {

        if (!commit) {
            this._lastTowerFailRecord = {};
            this._lastTowerFailRecord.id = data.battleData.id;
            this._lastTowerFailRecord.role = playerLogic.getPlayer().getRoleId();
            this._lastTowerFailRecord.result = result;
            this._lastTowerFailRecord.skills = skills;
            this._lastTowerFailRecord.selfTroops = data.troops.selfTroop;
            this._lastTowerFailRecord.enemyTroops = data.troops.enemyTroop;
            this._lastTowerFailRecord.enemyIndex = data.troops.enemyTroop.map((v, i, a) => {
                return v.getId();
            })
            this._lastTowerFailRecord.win = false;
            this._lastTowerFailRecord.seed = seed;
            return;
        }

        let param = new TowerBattleReq();
        param.floor = data.battleData.id;
        param.battleData = {};
        param.type = data.battleData.getRaceType() + 2;

        param.battleData["seed"] = seed;
        param.battleData["skills"] = skills;
        param.battleData["result"] = result;

        param.battleData["troops"] = {}
        let troops = param.battleData["troops"];
        troops["selfTroop"] = [];
        troops["selfTroopIndex"] = [];
        troops["enemyTroop"] = [];
        troops["enemyTroops"] = [];
        data.troops.selfTroop.forEach((v, i, a) => {
            if (v) {
                let tmp = v.getHeroVO();
                tmp.lv = v.getLevel();
                troops["selfTroop"].push(tmp);
                troops["selfTroopIndex"].push(i);
            }
        });
        let raceTower = this.getRaceTower(data.battleData.getRaceType(), data.battleData.id);
        raceTower.getMonsters().forEach((v, i, a) => {
            if (v) {
                troops["enemyTroop"].push(v.getId());
                let tmp = v.getHeroVO();
                troops["enemyTroops"].push(tmp);
            }
        });
        this._doAddArtifactProgress();
        await gm.request<string>(GameProxy.apitowertowerBattle, param);
    }

    protected _doAddArtifactProgress() {
        let cnt: number = 0;
        for (let i = RaceType.Wuzhuang; i <= RaceType.Jiangshi; i++) {
            if (this._raceTowerLevel[i] >= 30) {
                cnt++;
            }
        }
        if (cnt > 0) {
            heroLogic.artifactUnlockInfo && heroLogic.artifactUnlockInfo.addTaskProgress(8006, cnt);
        }
    }

    // 请求玩家种族塔挑战记录
    async raceTowerFightRecordReq(roleId: string, towerId: number, type: RaceType) {
        if (this._towerRecords[`${roleId}-${towerId}-${type}`]) {
            return;
        }
        if (roleId == playerLogic.getPlayer().getRoleId() && towerId == this.getCurrentTower(type)) {
            return;
        }

        let param = new TowerBattleDataReq();
        param.floor = towerId;
        param.roleId = roleId;
        param.type = type + 2;

        let recordUrl = await gm.request<string>(GameProxy.apitowertowerBattleData, param);
        console.log("种族塔战斗记录地址:" + recordUrl);
        if (recordUrl) {
            let proto = await HttpProxy.httpGet<string>(recordUrl);
            let data = JSON.parse(proto);
            if (data && data.battleData && data.floor) {
                let towerRecord: any = {};
                towerRecord.id = data.floor;
                towerRecord.role = roleId;
                if (data.battleData.troops && data.battleData.troops.selfTroop) {
                    let troops: HeroVO[] = data.battleData.troops.selfTroop;
                    towerRecord.selfTroops = new Array(5);
                    troops.forEach((v, i, a) => {
                        let hero = new Hero(v);
                        let heroPos = data.battleData.troops.selfTroopIndex
                        if (heroPos && heroPos[i] >= 0) {
                            towerRecord.selfTroops[heroPos[i]] = hero;
                        }
                    });
                    if (data.battleData.troops.enemyTroop) {
                        towerRecord.enemyIndex = data.battleData.troops.enemyTroop;
                    }
                    if (data.battleData.troops.enemyTroops) {
                        let troops: HeroVO[] = data.battleData.troops.enemyTroops;
                        towerRecord.enemyTroops = [];
                        troops.forEach((v, i, a) => {
                            let hero = new Hero(v);
                            towerRecord.enemyTroops.push(hero);
                        });
                    }
                    if (data.battleData.skills) {
                        towerRecord.skills = data.battleData.skills;
                    }
                    if (data.battleData.result) {
                        towerRecord.result = data.battleData.result;
                    }
                    towerRecord.win = true;
                    towerRecord.seed = data.battleData.seed || 0;
                }

                this._towerRecords[`${roleId}-${towerId}-${type}`] = towerRecord;
            }
        } else {
            gm.toast(stringConfigMap.key_common_tip8.Value);
        }
    }
    // 种族塔挑战胜利
    async raceTowerPassCommit(tower: Tower): Promise<Card[]> {
        if (tower.id < this._raceTowerLevel[tower.getRaceType()]) { return []; }
        let race: RaceType = tower.getRaceType();
        let sysId: SystemId = race + 2;
        let proto = await gm.request<ResourceVO>(GameProxy.apiprocesspassProcess, { stageId: tower.id, systemId: sysId });

        this._raceTowerLevel[race] += 1;
        let cards = playerLogic.addCards(proto);

        if (proto) {
            if (proto.roleRank) {
                this._raceTowerMyRank[race] = proto.roleRank;
            }
        }
        this._doAddArtifactProgress();
        return cards;
    }
    // 初始化种族塔信息
    private initRaceTowerData() {
        let cfgs = factionskybuildconfig;
        for (let i = RaceType.Wuzhuang; i <= RaceType.Jiangshi; i++) {
            this._raceTowers[i] = [];
            this._raceMaxLevel[i] = 0;
            let raceCfgs = cfgs.filter((v, index, a) => { return v.Faction == i; })
            for (let j = 0; j < raceCfgs.length; j++) {
                let tmp = new Tower(raceCfgs[j].ID, 1);
                this._raceTowers[i].push(tmp);
                this._raceMaxLevel[i] += 1;
            }
        }
    }
    // 获取用于显示的种族塔信息
    public getRaceTowers(type: RaceType) {
        let showRaceTowers: Tower[] = [];
        let showLevel: number = this.getRaceTowerNowLevel(type) + this._unPassPre;
        showLevel = showLevel > 5 ? showLevel : 5;
        for (let i = 0; i < this._raceTowers[type].length; i++) {
            if (this._raceTowers[type][i].cfg.FactionFloor <= showLevel &&
                this.getRaceTowerNowLevel(type) <= this._raceTowers[type][i].cfg.FactionFloor + 3) {
                showRaceTowers.push(this._raceTowers[type][i]);
            }
        }
        return showRaceTowers;
    }
    // 获取对应等级的种族塔
    public getRaceTower(type: RaceType, level: number) {
        return this._raceTowers[type].find((a) => { return a.cfg.FactionFloor == level; });
    }
    // 种族塔是否解锁
    public isRaceUnlock(): boolean {
        let unlock: boolean = true;
        unlock = UnlockWrapper.isUnlock(unlockConfigMap.种族高塔);
        return unlock;
    }
    // 获取种族塔当前等级
    public getRaceTowerNowLevel(type: RaceType) {
        return this._raceTowerLevel[type] || 0;
    }
    public getRaceCfg(id: number) {
        return factionskybuildconfig.find((a) => { return a.ID == id; });
    }
    public getRaceFightRecord(roleId: string, level: number, type: RaceType) {
        return null;
    }
    public getRaceTitle(type: RaceType) {
        let title: string = "超级摩天楼";
        if (type == RaceType.Wuzhuang) {
            title = "武装之阶";
        } else if (type == RaceType.Jixie) {
            title = "机械之窟";
        } else if (type == RaceType.Bianzhong) {
            title = "变种之柱";
        } else if (type == RaceType.Jiangshi) {
            title = "僵尸之墓";
        }
        return title;
    }
    public getRaceConfigType(type: RaceType) {
        let tip: string = "tower";
        if (type == RaceType.Wuzhuang) {
            tip = "wuzhuang";
        } else if (type == RaceType.Jixie) {
            tip = "jixie";
        } else if (type == RaceType.Bianzhong) {
            tip = "bianzhong";
        } else if (type == RaceType.Jiangshi) {
            tip = "jiangshi";
        }
        return tip;
    }
    //  -- 种族塔 -- end

    protected _searchInfos: {
        [key: number]: {
            buyCount: number,
            nowCount: number,
            timestamp: number
        }
    } = {};

    /**
     * 请求摩天楼搜寻信息
     */
    async doGetSearchInfo(tower: Tower) {
        this._searchInfos = {};
        let protos = await this._gm.request<BuyCountBO[]>(GameProxy.apitowergetSearchInfo, [tower.getRaceType() + 2]);
        for (let proto of protos) {
            this._searchInfos[proto.type - 2] = {
                buyCount: proto.buyCount,
                nowCount: proto.nowCount,
                timestamp: proto.freshTs
            }
        }
    }

    /**
     * 能否搜寻
     */
    canSearchRewards(tower: Tower): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        let remainCount = this.getSearchRemainCount(tower);
        if (remainCount == 0) {
            return {
                result: false,
                message: '今日搜寻次数已用完，请明日再来'
            }
        }

        let consumes: Function[] = [];
        if (!this.isSearchFree(tower)) {
            let cost = this.getSearchCost(tower);
            let good = bagLogic.getGood(Good.GoodId.Diamond);
            if (good.getAmount() < cost) {
                return {
                    result: false,
                    message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
                }
            }
            else {
                consumes.push(() => {
                    bagLogic.changeGoodAmount(Good.GoodId.Diamond, -cost);
                });
            }
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**
     * 请求搜寻
     */
    async doSearchRewards(tower: Tower) {
        let ret = this.canSearchRewards(tower);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let raceType = tower.getRaceType();
        if (ret.consumes.length > 0) {
            await this._gm.request(GameProxy.apitowerbuySearchCount, raceType + 2);
            this._searchInfos[raceType].buyCount++;
            for (let consume of ret.consumes) {
                consume();
            }
        }

        let proto = await this._gm.request<ResourceVO>(GameProxy.apitowergoSearch, raceType + 2);
        if (proto) {
            this._gm.getReward(proto, true);
            this._searchInfos[raceType].nowCount++;
        }
    }

    /**
     * 获取搜寻剩余次数
     * @param tower 
     */
    getSearchRemainCount(tower: Tower): number {
        let remainCount: number = 0;
        let info = this._searchInfos[tower.getRaceType()];
        if (tower.getRaceType() == 0) {
            remainCount = defaultConfigMap.searchfreetime.value + defaultConfigMap.searchtimebuylimit.value - info.nowCount;
        }
        else {
            remainCount = defaultConfigMap.factionsearchfreetime.value - info.nowCount;
        }
        return remainCount;
    }

    /**
     * 获取搜寻的花费
     * @param tower 
     */
    getSearchCost(tower: Tower): number {
        if (tower.getRaceType() == 0) {
            let info = this._searchInfos[tower.getRaceType()];
            let costs = cm.searchtimebuy;
            return costs[Math.min(info.buyCount, costs.length - 1)];
        }
        return 0;
    }

    /**
     * 获取搜寻下次刷新的时间戳
     * @param tower 
     */
    getSearchRefreshTimestamp(tower: Tower): number {
        return this._searchInfos[tower.getRaceType()].timestamp;
    }

    /**
     * 本次搜寻是否免费
     * @param tower 
     */
    isSearchFree(tower: Tower): boolean {
        let info = this._searchInfos[tower.getRaceType()];
        if (tower.getRaceType() == 0) {
            return info.nowCount < defaultConfigMap.searchfreetime.value;
        }
        else {
            return info.nowCount < defaultConfigMap.factionsearchfreetime.value;
        }
    }
}

let towerLogic = new TowerLogic();
export default towerLogic;