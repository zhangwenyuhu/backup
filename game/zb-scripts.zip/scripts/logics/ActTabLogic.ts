import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import EManager, { EListener, EName } from "../manager/EventManager";
import BasePanel from "../view/panel/BasePanel";
import activityLogic, { ActivityType } from "./ActivityLogic";
import giftLogic from "./GiftLogic";
import gm from "../manager/GameManager";
import ActivityTaskPanel from "../view/panel/activity/ActivityTaskPanel";
import ActivityExchangePanel from "../view/panel/activity/ActivityExchangePanel";
import ActivityChargePanel from "../view/panel/activity/ActivityChargePanel";
import ActivityAccumPanel from "../view/panel/activity/ActivityAccumPanel";
import UnlockWrapper from "../view/widget/unlock/UnlockWrapper";
import { unlockConfigMap } from "../configs/unlockConfig";

export enum TabType {
    NewPlayerAct = 1,
    BetterAct = 2,
}

export type TabActivity = {
    type: ActivityType,
    name: string,
    img: string,
    bg: string,
    prefab: string,
    isValid: Function,
    remainTime: Function
}

export let ActList: TabActivity[] = [
    {
        type: ActivityType.Day7,
        name: '七日特惠',
        img: "act_top_tehui",
        bg: "activity_bg_day7",
        prefab: "ActivityDay7Panel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.Day7) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.Day7) }
    },
    {
        type: ActivityType.NewPlayerTask,
        name: '七日目标',
        img: "act_top_default",
        bg: "",
        prefab: "ActivityNew2Panel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.NewPlayerTask); },
        remainTime: () => { return activityLogic.getNewPlayerTaskTs(); }
    },
    {
        type: ActivityType.NewPlayer2Task,
        name: '七日目标',
        img: 'act_top_default',
        bg: "",
        prefab: "ActivityNew2Panel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.NewPlayer2Task); },
        remainTime: () => { return activityLogic.getNewPlayer2TaskTs(); }
    },
    {
        type: ActivityType.SignNew,
        name: '签到有礼',
        img: "act_top_default",
        bg: "",
        prefab: "ActivitySignNewPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.SignNew) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.SignNew) }
    },
    {
        type: ActivityType.LeiChong,
        name: '累计充值',
        img: "act_top_leichong",
        bg: "activity_bg_3",
        prefab: "ActivityAccumPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.LeiChong) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.LeiChong) }
    },
    {
        type: ActivityType.LeiXiao,
        name: '累计消费',
        img: "act_top_leixiao",
        bg: "activity_bg_4",
        prefab: "ActivityAccumPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.LeiXiao) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.LeiXiao) }
    },
    {
        type: ActivityType.DailyLight,
        name: '新手光环',
        img: "act_top_dailylight",
        bg: "activity_dailylight_bg",
        prefab: "ActivityDailyLightPanel",
        isValid: () => { return giftLogic.dailyLightModal && giftLogic.dailyLightModal.isDailyLightValid },
        remainTime: () => { return giftLogic.dailyLightModal ? giftLogic.dailyLightModal.remainTime : 0 }
    },
    {
        type: ActivityType.XiaoFeiDaRen,
        name: '消费达人',
        img: "act_top_xiaofeidaren",
        bg: "activity_bg_xiaofeidaren",
        prefab: "ActivityXiaoFeiPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.XiaoFeiDaRen) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.XiaoFeiDaRen) }
    },
    {
        type: ActivityType.Lottery,
        name: '抽卡活动',
        img: "act_top_chouka",
        bg: "activity_bg_task1",
        prefab: "ActivityTaskPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.Lottery); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.Lottery); }
    },
    {
        type: ActivityType.HappyTreasure,
        name: '寻宝庆典',
        img: "act_top_xunbao",
        bg: "activity_bg_task2",
        prefab: "ActivityTaskPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.HappyTreasure); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.HappyTreasure); }
    },
    {
        type: ActivityType.HeroCultivate,
        name: '英雄养成',
        img: "act_top_heroyangcheng",
        bg: "activity_bg_task3",
        prefab: "ActivityTaskPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.HeroCultivate); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.HeroCultivate); }
    },
    {
        type: ActivityType.CrazyArena,
        name: '狂热竞技',
        img: "act_top_crazyarena",
        bg: "activity_bg_task4",
        prefab: "ActivityTaskPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.CrazyArena); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.CrazyArena); }
    },
    {
        type: ActivityType.WisdomStorm,
        name: '智慧风暴',
        img: "act_top_zhihui",
        bg: "activity_bg_task5",
        prefab: "ActivityTaskPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.WisdomStorm); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.WisdomStorm); }
    },
    {
        type: ActivityType.UnionRally,
        name: '联盟集结',
        img: "act_top_herojijie",
        bg: "activity_bg_task7",
        prefab: "ActivityTaskPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.UnionRally); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.UnionRally); }
    },
    {
        type: ActivityType.UnionLottery,
        name: '联盟抽卡',
        img: "act_top_lianmengchou",
        bg: "activity_bg_task8",
        prefab: "ActivityTaskPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.UnionLottery); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.UnionLottery); }
    },
    {
        type: ActivityType.RewardSeason,
        name: '悬赏季',
        img: "act_top_xuanshang",
        bg: "activity_bg_task6",
        prefab: "ActivityTaskPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.RewardSeason); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.RewardSeason); }
    },
    {
        type: ActivityType.HeroCome,
        name: '英雄降临',
        img: "act_top_herojiangling",
        bg: "activity_bg_exchange1",
        prefab: "ActivityExchangePanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.HeroCome); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.HeroCome); }
    },
    {
        type: ActivityType.FurnaceGift,
        name: '熔炉馈赠',
        img: "act_top_furnacegift",
        bg: "activity_bg_exchange2",
        prefab: "ActivityExchangePanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.FurnaceGift); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.FurnaceGift); }
    },
    {
        type: ActivityType.MysteryTreasure,
        name: '神秘宝库',
        img: "act_top_mystery",
        bg: "activity_bg_exchange3",
        prefab: "ActivityExchangePanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.MysteryTreasure); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.MysteryTreasure); }
    },
    {
        type: ActivityType.MonthOrder,
        name: '月令活动',
        img: "act_top_yueling",
        bg: "act_monthorder_bg",
        prefab: "ActivityMonthOrderPanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.MonthOrder); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.MonthOrder); }
    },
    {
        type: ActivityType.ExchangeDailyLight,
        name: '寻宝光环',
        img: "act_top_charge",
        bg: "activity_act_light",
        prefab: "ActivityChargePanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.ExchangeDailyLight); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.HappyTreasure); }
    },
    {
        type: ActivityType.TreasureDailyLight,
        name: '夺宝光环',
        img: "act_top_charge",
        bg: "activity_act_light",
        prefab: "ActivityChargePanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.TreasureDailyLight); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.Treasure); }
    },
    {
        type: ActivityType.BoardDailyLight,
        name: '棋盘光环',
        img: "act_top_charge",
        bg: "activity_act_light",
        prefab: "ActivityChargePanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.BoardDailyLight); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.CheckerBoard); }
    },
    {
        type: ActivityType.UnionDailyLight,
        name: '联盟光环',
        img: "act_top_charge",
        bg: "activity_act_light",
        prefab: "ActivityChargePanel",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.UnionDailyLight); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.UnionRally); }
    },
];

/* 顶部活动管理 */
export class ActTabLogic extends BaseLogic {

    protected _type: number = 1;
    protected _eventListeners: EListener[] = [];
    protected _cloingAct: TabActivity = null;
    protected _nowTab: TabActivity = null;
    protected _bCheck: boolean = false;

    init(gm: IGameManager) {
        super.init(null, gm);

        this.registerEvent();
    }

    update(dt) {
        this.checkTopEnable();
    }

    protected registerEvent() {
        let listener = EManager.addEvent(EName.onHidePanel, (data: BasePanel) => {
            if (data) {
                let name: string = data['__classname__'];
                console.log('act listen: hide ' + name);
                console.log(`act hide panel data: ${data.data}`);
                if (this._nowTab && name == this._nowTab.prefab) {
                    if (data.data) {
                        if (this._nowTab.type == data.data) {
                            this.doHidePanel(data);
                            console.log('act close actTop');
                        }
                    } else {
                        this.doHidePanel(data);
                        console.log('act close actTop');
                    }
                }
            }
        })
        this._eventListeners.push(listener);
    }
    protected removeEvent() {
        for (let listener of this._eventListeners) {
            EManager.removeEvent(listener);
        }
        this._eventListeners = [];
    }
    // 处理显示精彩活动时弹出其他窗口的情况
    protected checkTopEnable() {
        if (!this._bCheck) { return; }
        let data = BasePanel.getNowPanelData();
        let enable: boolean = false;
        if (data && this._nowTab) {
            let name: string = data.prefab ? data.prefab.name : '';
            enable = this._nowTab.prefab == name;
        } else {
            enable = false;
        }
        gm.enableActTop(enable);
    }

    public getTopTabType() { return this._type; }

    // 用于跳转打开活动
    public showActivity(type: ActivityType) {
        let tab = ActList.find((a) => { return a.type == type; })
        if (tab) {

        } else {
            console.error('')
        }
    }
    // 显示精彩活动
    public async showTab(type: TabType) {
        await giftLogic.doGetDailyLightDetail();
        await activityLogic.activityReq(ActivityType.All);

        let tabs = this.getValidActTab(type);
        if (tabs.length <= 0) { EManager.emit(EName.onActivityBtnFresh); return; }

        this._type = type;
        this.registerEvent();
        gm.validActTop(true);

        if (tabs && tabs.length > 0) { this.doShowPanel(tabs[0], () => { this._bCheck = true; }); }
    }
    // 关闭活动顶部区域,移除监听
    public hideTab() {
        this._bCheck = false;
        this.removeEvent();
        gm.validActTop(false);
    }
    // 关闭正在显示的精彩活动
    public closeNowActPanel() {
        if (this._nowTab) {
            this.closeActPanel(this._nowTab);
        }
    }
    // 某类活动是否存在有效的
    public isTabValid(type: TabType): boolean {
        if (type == TabType.NewPlayerAct) {
            return this.getValidActTab(TabType.NewPlayerAct).length > 0 && UnlockWrapper.isUnlock(unlockConfigMap.七日签到);
        } else if (type == TabType.BetterAct) {
            return this.getValidActTab(TabType.BetterAct).length > 0 && UnlockWrapper.isUnlock(unlockConfigMap.活动);
        }
        return false;
    }
    // 获取有效活动数据
    public getValidActTab(type: TabType): TabActivity[] {
        let tabs: TabActivity[] = [];
        let tab = actTabLogic.getActivityNewTab(type);
        for (let i = 0; i < ActList.length; i++) {
            let act = ActList[i];
            let index = tab.findIndex((a) => { return a == act.type; })
            if (index >= 0) {
                if (act.isValid() && act.remainTime() > 0) { tabs.push(act); }
            }
        }
        return tabs;
    }
    public getActivityNewTab(type: TabType): ActivityType[] {
        let tab: ActivityType[] = [];
        if (type == 1) {
            tab = [
                ActivityType.Day7Sign,
                ActivityType.NewPlayerTask,
                ActivityType.NewPlayer2Task,
                ActivityType.SignNew,
            ]
        } else {
            tab = [
                ActivityType.DailyLight,
                ActivityType.Day7,
                ActivityType.LeiChong,
                ActivityType.LeiXiao,
                ActivityType.XiaoFeiDaRen,
                ActivityType.Lottery,
                ActivityType.HappyTreasure,
                ActivityType.HeroCultivate,
                ActivityType.CrazyArena,
                ActivityType.WisdomStorm,
                ActivityType.RewardSeason,
                ActivityType.UnionRally,
                ActivityType.HeroCome,
                ActivityType.FurnaceGift,
                ActivityType.MysteryTreasure,
                ActivityType.UnionLottery,
                ActivityType.MonthOrder,
                ActivityType.ExchangeDailyLight,
                ActivityType.TreasureDailyLight,
                ActivityType.BoardDailyLight,
                ActivityType.UnionDailyLight
            ]
        }
        return tab;
    }

    // 显示精彩活动中的某个活动
    public doShowPanel(act: TabActivity, call: Function, isLeft?: boolean) {
        let layerUrl: string = this.getPrefabUrl(act);
        console.log(`活动: ${layerUrl} 向左: ${isLeft}`);
        this._bCheck = false;
        let needClose: boolean = false;
        if (this._nowTab) {
            if (this._nowTab.type == act.type) {
                if (call) { call(); }
                this._bCheck = true;
                return;
            } else {
                this._cloingAct = this._nowTab;
                this._nowTab = act;
                // 替换的活动和当前活动不是同一个预制体时,先显示再关闭要替换的
                if (this._cloingAct.prefab != this._nowTab.prefab) {
                    //this.closeActPanel(this._cloingAct);
                    needClose = true;
                }
            }
        }

        // 预制体是同一个时,直接重新刷新
        if (this._cloingAct && this._nowTab && this._cloingAct.prefab == this._nowTab.prefab) {
            let panel = BasePanel.getPanel(this._nowTab.prefab);
            panel.data = this._nowTab.type;
            if (panel instanceof ActivityTaskPanel) {
                (panel as ActivityTaskPanel).reloadPanel(this._nowTab.type);
            } else if (panel instanceof ActivityExchangePanel) {
                (panel as ActivityExchangePanel).reloadPanel(this._nowTab.type);
            } else if (panel instanceof ActivityChargePanel) {
                (panel as ActivityChargePanel).reloadPanel(this._nowTab.type);
            } else if (panel instanceof ActivityAccumPanel) {
                (panel as ActivityAccumPanel).reloadPanel(this._nowTab.type);
            }
            console.log(`预制体相同,直接刷新 ${this._nowTab.name} - ${this._nowTab.prefab}`);
            this._bCheck = true;
            if (call) { call(); }
            this._nowTab = act;
            return;
        }

        console.log(`显示活动 ${act.name} - ${act.prefab}`);
        gcc.core.showLayer(layerUrl, {
            data: act.type, callback: (data) => {
                console.log('act layer show callback');
                this._bCheck = true;
                let panel = BasePanel.getPanel(act.prefab);
                if (panel) {
                    /*let dis: number = isLeft ? cc.winSize.width / 2 : -cc.winSize.width / 2;
                   panel.node.x += dis;
                  
                   let action = cc.sequence(cc.moveBy(1 / 30, cc.v2(-dis, 0)), cc.callFunc(() => {
                       if (needClose) {
                           this.closeActPanel(this._cloingAct);
                           this._cloingAct = null;
                       }
                       if (call) { call(); }
                   }))
                   panel.node.runAction(action);*/
                    if (needClose) {
                        this.closeActPanel(this._cloingAct);
                        this._cloingAct = null;
                    }
                    if (call) { call(); }
                } else {
                    if (call) { call(); }
                }
            }
        });
        this._nowTab = act;
    }

    // 关闭一个活动
    protected closeActPanel(act: TabActivity) {
        BasePanel.closePanel(act.prefab);
    }

    // 处理 监听到有精彩活动关闭
    protected doHidePanel(panel: BasePanel) {
        let name: string = panel['__classname__'];
        let act = ActList.find((a) => { return a.prefab == name; })
        this._nowTab = null;
        if (act) { this.hideTab(); }
        this.checkAllActHide();
    }

    // 精彩活动顶部tab关闭后 关闭相关的活动
    protected checkAllActHide() {
        let tabs = this.getValidActTab(TabType.BetterAct);
        for (let i = 0; i < tabs.length; i++) {
            let tab = tabs[i];
            BasePanel.closePanel(tab.prefab);
        }
    }

    protected getPrefabUrl(act: TabActivity): string {
        return `prefabs/panel/activity/${act.prefab}`;
    }
    public getTopImgUrl(name: string): string {
        return `textures/ui/panel/activity_top/${name}`;
    }
}

let actTabLogic = new ActTabLogic();
export default actTabLogic;