import factionbattlerewardconfig from '../configs/factionbattlerewardconfig';
import Good, { GoodId } from "../data/card/Good";
import Hero from '../data/card/Hero';
import Monster from "../data/card/Monster";
import Npc from "../data/card/Npc";
import IBattleData from "../data/IBattleData";
import RankData from '../data/record/RankData';
import User from '../data/user/User';
import ToastError from '../error/ToastError';
import cm from '../manager/ConfigManager';
import EManager from '../manager/EventManager';
import IGameManager from "../manager/IGameManager";
import GameProxy from '../proxy/GameProxy';
import commonUtils from '../utils/CommonUtils';
import { BattleType } from "../utils/DefineUtils";
import storageUtils from '../utils/StorageUtils';
import stringUtils from '../utils/StringUtils';
import { defaultConfigMap } from './../configs/defaultConfig';
import factionbattleconfig, { factionbattleconfigRow } from './../configs/factionbattleconfig';
import { stringConfigMap } from './../configs/stringConfig';
import { Battle_heroConfig, GHegeHitReq, GHegeRecHeroReq, GuildHegeBO, GuildHegeMapBO, GuildHegeNodeBO, GuildHegeNodeHeroBO, GuildHegeNodeRecBO, GuildHegeRoleDataBO, GuildSimpleReq, GuildSimpleVO, HeroVO, RankVO, RoleVO, ProcessRecordVO } from './../proxy/GameProxy';
import bagLogic from './BagLogic';
import BaseLogic from "./BaseLogic";
import playerLogic from './PlayerLogic';
import unionLogic from './UnionLogic';

export enum UnionStationState {
    /**被怪物占领 */
    Monster,

    /**被其他公会占领 */
    OtherUnion,

    /**被自己公会占领 */
    SelfUnion,

    /**被自己占领 */
    Self
}

export enum UnionStationType {
    /**低级 */
    Low,

    /**中级 */
    Middle,

    /**高级 */
    Senior
}

export enum UnionWarState {
    /**空闲 */
    Idle,

    /**报名中 */
    Joining,

    /**比赛中 */
    Fighting
}

export class UnionWarRecord {
    protected _unionId: number = 0;
    protected _unionName: string = "";
    protected _user: User = null;
    protected _roleId: string = "";
    protected _isWin: boolean = false;
    protected _timestamp: number = 0;
    protected _nodeId: number = 0;
    protected _guards: UnionWarGuard[] = [];

    constructor(proto: GuildHegeNodeRecBO, nodeId: number) {
        this._unionId = proto.guild;
        this._roleId = proto.roleId;
        this._isWin = proto.win;
        this._timestamp = proto.batTs;
        this._nodeId = nodeId;
    }

    get nodeId(): number {
        return this._nodeId;
    }

    get unionId(): number {
        return this._unionId;
    }

    get unionName(): string {
        return this._unionName;
    }

    get timestamp(): number {
        return this._timestamp;
    }

    get isWin(): boolean {
        return this._isWin;
    }

    get user(): User {
        return this._user;
    }

    get guards(): UnionWarGuard[] {
        return this._guards;
    }

    updateUnion(vo: GuildSimpleVO) {
        this._unionName = vo.name;
        for (let member of vo.members) {
            if (member.roleId == this._roleId) {
                let vo = new RoleVO();
                let names = Object.getOwnPropertyNames(member);
                for (let name of names) {
                    vo[name] = member[name];
                }
                this._user = new User(vo);
                break;
            }
        }
    }

    updateGuards(protos: GuildHegeNodeHeroBO[]) {
        this._guards = [];
        for (let proto of protos) {
            let config = commonUtils.getHeroConfig(proto.heroConfigInfo);
            let guard = new UnionWarGuard(config);
            this._guards.push(guard);
        }
    }
}

export class UnionWarRankData extends RankData {
    protected _unionAvatar: string = "";
    protected _unionLevel: number = 0;
    protected _roleId: string = "";

    constructor(proto: RankVO) {
        super(proto);
        this._roleId = proto.roleId;
    }

    updateUnion(proto: GuildSimpleVO) {
        this._unionAvatar = proto.avatar;
        this._unionLevel = proto.lv;
        this._role.setUnionId(proto.id);
        this._role.setUnionName(proto.name);
    }

    getRoleId(): string {
        return this._roleId;
    }

    getUnionAvatar(): string {
        return this._unionAvatar;
    }

    getUnionLevel(): number {
        return this._unionLevel;
    }
}

export class UnionWarGuard extends Hero {
    protected static _createHeroVo(config: rpgfight.HeroConfig): HeroVO {
        let vo = new HeroVO();
        vo.equips = [];
        vo.exp = 0;
        vo.heroAddInfos = [];
        vo.heroCofId = Number(config.heroConfigId);
        vo.heroId = config.heroId;
        vo.lv = config.level;
        vo.rank = config.rank;
        return vo;
    }

    protected _heroConfig: rpgfight.HeroConfig = null;

    constructor(config: rpgfight.HeroConfig) {
        super(UnionWarGuard._createHeroVo(config));
        this._heroConfig = config;
    }

    getBattleCfg(): rpgfight.HeroConfig {
        return this._heroConfig;
    }

    getSpineFile(): string {
        return this._heroConfig.skin;
    }

    getLevel(): number {
        return this._heroConfig.level;
    }

    getRank(): number {
        return this._heroConfig.rank;
    }

    getAtk(): number {
        return this._heroConfig.attack;
    }

    getHp(): number {
        return this._heroConfig.hp;
    }

    getHpMax(): number {
        return this._heroConfig.hpMax;
    }

    getDef(): number {
        return this._heroConfig.defense;
    }

    getCriPct(): number {
        return this._heroConfig.critRate;
    }

    getCriAtk(): number {
        return this._heroConfig.critHurt;
    }

    getHit(): number {
        return this._heroConfig.hitRate;
    }

    getDodge(): number {
        return this._heroConfig.dodgeRate;
    }

    getMoveSpeed(): number {
        return this._heroConfig.moveSpeed;
    }

    getRecoverSec(): number {
        return this._heroConfig.hpHealingSpeed;
    }

    getPhyResist(): number {
        return this._heroConfig.extraDefensePhysicalHurt;
    }

    getMagicResist(): number {
        return this._heroConfig.extraDefenseMagicHurt;
    }

    getLiftLeech(): number {
        return this._heroConfig.suckBloodLv;
    }

    getBeHitEnergy(): number {
        return this._heroConfig.powerChargeSpeedWithHurt;
    }

    getHitEnergy(): number {
        return this._heroConfig.powerChargeSpeedWithUsingSkill;
    }

    getEnergy(): number {
        return this._heroConfig.power;
    }

    getEnergyMax(): number {
        return this._heroConfig.powerMax;
    }

    getAutoEnergy(): number {
        return this._heroConfig.powerChargeSpeedNormal;
    }

    getPower(): number {
        return this._heroConfig.fightPower;
    }

    getSkillHarm(): number {
        return this._heroConfig.skillHarm;
    }

    getSkillSpeed(): number {
        return this._heroConfig.skillSpeed;
    }

    getSkillLevel(): number {
        return this._heroConfig.exclusiveLevel;
    }

    getHealCap(): number {
        return this._heroConfig.healCap;
    }

    getDeCri(): number {
        return this._heroConfig.deCri;
    }

    getIncHarm(): number {
        return this._heroConfig.incHarm;
    }

    getIncArtifactHarm(): number {
        return this._heroConfig.incArtifactHarm;
    }

    getDecArtifactHarm(): number {
        return this._heroConfig.decArtifactHarm;
    }

    getCriPctArtifact(): number {
        return this._heroConfig.criPctArtifact;
    }

    getCriAtkArtifact(): number {
        return this._heroConfig.criAtkArtifact;
    }
}

export class UnionWarData implements IBattleData {
    static Events = {
        StationInfoDirty: "union war station info dirty",
        UnionInfoDirty: "union war union info dirty"
    }

    protected _config: factionbattleconfigRow = null;
    protected _guards: Hero[] = [];
    protected _state: UnionStationState = UnionStationState.Monster;

    protected _battleId: number = 0;
    protected _unionId: number = 0;
    protected _unionAvatar: string = "";
    protected _unionName: string = "";
    protected _unionLevel: number = 0;
    protected _isBattling: boolean = false;
    protected _workStartTimestamp: number = 0;
    protected _occupyTimestamp: number = 0;
    protected _recordReadTimestamp: number = 0;
    protected _records: UnionWarRecord[] = [];
    protected _roleId: string = "";
    protected _roleName: string = "";
    protected _gm: IGameManager = null;

    protected readonly _recordReadKey: string = 'UnionWarRecord${id}';

    constructor(config: factionbattleconfigRow, gm: IGameManager) {
        this._config = config;
        this._gm = gm;
        this._recordReadTimestamp = storageUtils.getNumber({
            Key: stringUtils.getString(this._recordReadKey, { id: this.id }),
            Default: 0
        });
    }

    get state(): UnionStationState {
        return this._state;
    }

    get id(): number {
        return this._config.ID;
    }

    get unionId(): number {
        return this._unionId;
    }

    get unionName(): string {
        return this._unionName;
    }

    get unionAvatar(): string {
        return this._unionAvatar;
    }

    get name(): string {
        return this._config.name;
    }

    get type(): UnionStationType {
        return this._config.resourcepoint - 1;
    }

    get speed(): number {
        return this._config.scoreaddspeed;
    }

    get workTimestamp(): number {
        return this._workStartTimestamp;
    }

    get occupyTimestamp(): number {
        return this._occupyTimestamp;
    }

    get battleId(): number {
        return this._battleId;
    }

    get roleName(): string {
        return this._roleName;
    }

    get records(): UnionWarRecord[] {
        return this._records;
    }

    get isBattling(): boolean {
        return this._isBattling;
    }

    getGuards(): Hero[] {
        let guards: Hero[] = [];
        for (let guard of this._guards) {
            if (guard) {
                guards.push(guard);
            }
        }
        return guards;
    }

    getMonsters(): Hero[] {
        let guards: Hero[] = [];
        for (let guard of this._guards) {
            if (guard && guard.getHp() <= 0) {
                guards.push(null);
            }
            else {
                guards.push(guard);
            }
        }
        return guards;
    }

    getRewards(): Good[] {
        return [];
    }

    getTime(): number {
        return 90;
    }

    getBattleType(): BattleType {
        return BattleType.UnionWar;
    }

    getNpcs(): Npc[] {
        return [];
    }

    getUntroopHeroIds(): Set<string> {
        return unionWarLogic.guardHeroIds;
    }

    getUntroopReason(): string {
        return '已驻守的英雄无法上阵';
    }

    getTroopExpire(): number {
        return unionWarLogic.fightFinishTimestamp;
    }

    hasNewRecords(): boolean {
        for (let record of this._records) {
            if (record.timestamp > this._recordReadTimestamp) {
                return true;
            }
        }
        return false;
    }

    markRecordReadTimestamp() {
        this._recordReadTimestamp = this._gm.getCurrentTimestamp();
    }

    createMonsters(): Monster[] {
        let monsters: Monster[] = [];
        let count = playerLogic.getMaxInstanceTroopCount();
        for (let i = 0; i < count; i++) {
            let c = cm.getMonsterConfig(this._config.monster[i]);
            if (c) {
                let monster = new Monster(this._config.monster[i], this._config.monsterlevel);
                monsters.push(monster);
            }
            else {
                monsters.push(null);
            }
        }
        return monsters;
    }

    updateGuards(configs: rpgfight.HeroConfig[]) {
        let count = playerLogic.getMaxInstanceTroopCount();
        this._guards = [];
        for (let i = 0; i < count; i++) {
            this._guards.push(null);
        }
        for (let config of configs) {
            let guard = new UnionWarGuard(config);
            this._guards[config.battleStation - 1] = guard;
        }
    }

    updateProto(proto: GuildHegeNodeBO) {
        this._battleId = proto.battleSeq;
        this._unionId = proto.guild;
        this._roleId = proto.roleId;
        this._workStartTimestamp = proto.produceStartTs;
        this._occupyTimestamp = proto.occupyTs;
        this._recordReadTimestamp = Math.max(this._occupyTimestamp, this._recordReadTimestamp);
        this._records = [];
        for (let record of proto.records) {
            this._records.push(new UnionWarRecord(record, this.id));
        }
        if (proto.nodeHeroInfos && proto.nodeHeroInfos.length > 0) {
            let configs = [];
            for (let info of proto.nodeHeroInfos) {
                let config = commonUtils.getHeroConfig(info.heroConfigInfo);
                configs.push(config);
            }
            this.updateGuards(configs);
        }
        else {
            this._guards = this.createMonsters();
        }

        if (this._unionId >= 0) {
            if (this._unionId == unionLogic.getUnion().getId()) {
                if (this._roleId == playerLogic.getPlayer().getRoleId()) {
                    this._state = UnionStationState.Self;
                }
                else {
                    this._state = UnionStationState.SelfUnion;
                }
            }
            else {
                this._state = UnionStationState.OtherUnion;
            }
        }
        else {
            this._state = UnionStationState.Monster;
        }

        EManager.emit(UnionWarData.Events.StationInfoDirty, this);
    }

    updateUnionInfo(proto: GuildSimpleVO) {
        this._unionAvatar = proto.avatar;
        this._unionLevel = proto.lv;
        this._unionName = proto.name;
        if (proto.members) {
            for (let member of proto.members) {
                if (member.roleId == this._roleId) {
                    this._roleName = member.nick;
                    break;
                }
            }
        }

        EManager.emit(UnionWarData.Events.UnionInfoDirty, this);
    }
}

class UnionWarLogic extends BaseLogic {
    public Events = {
        PowerDirty: "union war power dirty"
    }

    protected _battleDatas: { [key: number]: UnionWarData } = {};

    protected _joinStartTimestamp: number = 0;
    protected _joinRoleIds: Set<string> = new Set<string>();
    protected _joinGroupId: number = 0;
    protected _joinUnionIds: number[] = [];
    protected _power: number = 0;
    protected _nextRefreshTimestamp: number = 0;
    protected _nextRecoveryTimestamp: number = 0;
    protected _buyCount: number = 0;
    protected _unionScore: number = 0;
    protected _userScore: number = 0;
    protected _occupyPoints: number[] = [];
    protected _guardHeroIds: Set<string> = new Set<string>();

    protected _userRankRewards: Good[][] = [];
    protected _unionRankRewards: Good[][] = [];

    get joinStartTimestamp(): number {
        return this._joinStartTimestamp;
    }

    get joinFinishTimestamp(): number {
        return this._joinStartTimestamp + 24 * 3600 * 1000;
    }

    get fightStartTimestamp(): number {
        return this.joinFinishTimestamp;
    }

    get fightFinishTimestamp(): number {
        return this.fightStartTimestamp + 24 * 3600 * 1000;
    }

    get state(): UnionWarState {
        let timestamp = this._gm.getCurrentTimestamp();
        if (timestamp >= this.joinStartTimestamp && timestamp < this.joinFinishTimestamp) {
            return UnionWarState.Joining;
        }
        else if (timestamp >= this.fightStartTimestamp && timestamp < this.fightFinishTimestamp) {
            return UnionWarState.Fighting;
        }
        else {
            return UnionWarState.Idle;
        }
    }

    get joined(): boolean {
        return this._joinRoleIds.has(playerLogic.getPlayer().getRoleId());
    }

    get joinCount(): number {
        return this._joinRoleIds.size;
    }

    get joinGroupId(): number {
        return this._joinGroupId;
    }

    get power(): number {
        return this._power;
    }

    get buyCount(): number {
        return this._buyCount;
    }

    get nextRefreshTimestamp(): number {
        return this._nextRefreshTimestamp;
    }

    get nextRecoveryTimestamp(): number {
        return this._nextRecoveryTimestamp;
    }

    get buyTiliLimit(): number {
        return defaultConfigMap.factionenergybuylimit.value;
    }

    get unionScore(): number {
        return this._unionScore;
    }

    get userScore(): number {
        return this._userScore;
    }

    get occupyPoints(): number[] {
        return this._occupyPoints;
    }

    get joinUnionIds(): number[] {
        return this._joinUnionIds;
    }

    get guardHeroIds(): Set<string> {
        return this._guardHeroIds;
    }

    init(gm: IGameManager) {
        super.init(null, gm);

        for (let config of factionbattleconfig) {
            this._battleDatas[config.ID] = new UnionWarData(config, this._gm);
        }
        for (let config of factionbattlerewardconfig) {
            let rewards: Good[] = [];
            for (let reward of config.reward) {
                let good = commonUtils.item2Card(reward) as Good;
                rewards.push(good);
            }
            if (config.type == 1) { // 公会排名
                this._unionRankRewards.push(rewards);
            }
            else if (config.type == 2) { // 个人排名
                this._userRankRewards.push(rewards);
            }
        }
    }

    getUserRankRewards(rank: number): Good[] {
        return this._userRankRewards[rank - 1];
    }

    getUnionRankRewards(rank: number): Good[] {
        return this._unionRankRewards[rank - 1];
    }

    getUnionWarData(confId: number) {
        return this._battleDatas[confId];
    }

    update(dt: number) {
        if (this.nextRecoveryTimestamp > 0) {
            if (this._gm.getCurrentTimestamp() >= this.nextRecoveryTimestamp) {
                this._nextRecoveryTimestamp = 0;
                this.doGetMapInfo();
            }
        }
        if (this.nextRefreshTimestamp > 0) {
            if (this._gm.getCurrentTimestamp() >= this.nextRefreshTimestamp) {
                this._nextRefreshTimestamp = 0;
                this.doGetMapInfo();
            }
        }
    }

    async doGetInfo() {
        let proto = await this._gm.request<GuildHegeBO>(GameProxy.apiguild_hegefindHege);
        this._updateInfo(proto);
    }

    async doJoin() {
        if (this.joined) {
            throw new ToastError("报名结束后即可前往战场");
        }

        let timestamp = this._gm.getCurrentTimestamp();
        if (timestamp < this.joinStartTimestamp && timestamp >= this.joinFinishTimestamp) {
            throw new ToastError("报名时间已过期");
        }

        let proto = await this._gm.request<GuildHegeBO>(GameProxy.apiguild_hegesignHege);
        this._updateInfo(proto);
    }

    async doGetMapInfo() {
        let proto = await this._gm.request<GuildHegeMapBO>(GameProxy.apiguild_hegefindHegeMaps);
        await this._updateMapInfo(proto);
    }

    async doGetStationInfo(stationId: number) {
        let protos = await this._gm.request<GuildHegeNodeBO[]>(GameProxy.apiguild_hegefindHegeMap, [stationId]);
        if (protos) {
            await this._updateBattleDatas(protos);
        }
    }

    async doSubmitResult(battleData: UnionWarData, guardConfigs: rpgfight.HeroConfig[], result: boolean, neutral: boolean) {
        let req = new GHegeHitReq();
        req.battleSeq = battleData.battleId;
        req.win = result;
        req.neutral = neutral;
        req.nodeId = battleData.id;
        req.battle_heroConfigs = [];
        for (let config of guardConfigs) {
            let c = new Battle_heroConfig();
            let names = Object.getOwnPropertyNames(config);
            for (let name of names) {
                c[name] = config[name];
            }
            req.battle_heroConfigs.push(c);
        }
        let proto = await this._gm.request<GuildHegeMapBO>(GameProxy.apiguild_hegesubmitHege, req);
        await this._updateMapInfo(proto);
        battleData.updateGuards(guardConfigs);
    }

    canBuyTili(times: number): { result: boolean, message?: string, consumes?: Function[] } {
        let remainTimes = this.buyTiliLimit - this._buyCount;
        if (remainTimes <= 0) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough_buy_tili_times.Value, { minute: defaultConfigMap.factionenergyget.value })
            }
        }

        if (times <= 0) {
            return {
                result: false,
                message: stringConfigMap.key_select_buy_tili_times.Value
            }
        }

        let cost = 0;
        let prices = cm.unionTiliBuyPrice;
        for (let i = this._buyCount; i < times + this._buyCount; i++) {
            cost += prices[Math.min(i, prices.length - 1)];
        }

        let consumes: Function[] = [];
        let good = bagLogic.getGood(GoodId.Diamond);
        if (good.getAmount() < cost) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(GoodId.Diamond, -cost);
            });
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    async doBuyTili(times: number) {
        let ret = this.canBuyTili(times);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let proto = await this._gm.request<GuildHegeMapBO>(GameProxy.apiguild_hegebugTili, times);
        for (let consume of ret.consumes) {
            consume();
        }
        await this._updateMapInfo(proto);
    }

    async doGetRecordGuards(record: UnionWarRecord) {
        let req = new GHegeRecHeroReq();
        req.nodeId = record.nodeId;
        req.ts = record.timestamp.toString();
        let protos = await this._gm.request<GuildHegeNodeHeroBO[]>(GameProxy.apiguild_hegefindRecHero, req);
        record.updateGuards(protos);
    }

    async doBattleStart(data: IBattleData) {
        let battleData = data as UnionWarData;
        let req = new GHegeHitReq();
        req.battleSeq = battleData.battleId;
        req.nodeId = battleData.id;
        let proto = await this._gm.request<GuildHegeNodeBO>(GameProxy.apiguild_hegebatStart, req);
        battleData.updateProto(proto);
    }

    async doCollectScore() {
        let proto = await this._gm.request<GuildHegeMapBO>(GameProxy.apiguild_hegecollectScore, this.occupyPoints);
        await this._updateMapInfo(proto);
    }

    protected async _updateMapInfo(proto: GuildHegeMapBO) {
        if (proto) {
            this._updateRoleData(proto.roleData);
            await this._updateBattleDatas(proto.nodes);
        }
    }

    protected async _updateBattleDatas(nodes: GuildHegeNodeBO[]) {
        let unionMap: { [key: number]: UnionWarData[] } = {};
        for (let node of nodes) {
            let battleData = this._battleDatas[node.nodeId];
            if (battleData) {
                battleData.updateProto(node);
                if (battleData.unionId >= 0) {
                    if (unionMap[battleData.unionId]) {
                        unionMap[battleData.unionId].push(battleData);
                    }
                    else {
                        unionMap[battleData.unionId] = [battleData];
                    }
                }
            }
        }

        let unionIdStrs = Object.keys(unionMap);
        let unionIds: number[] = [];
        for (let str of unionIdStrs) {
            unionIds.push(Number(str));
        }
        if (unionIds.length > 0) {
            let req = new GuildSimpleReq();
            req.guildIds = Array.from(unionIds);
            req.needMember = true;
            let protos = await this._gm.request<GuildSimpleVO[]>(GameProxy.apiguildfindGuildSimple, req);
            for (let proto of protos) {
                let datas = unionMap[proto.id];
                if (datas) {
                    for (let data of datas) {
                        data.updateUnionInfo(proto);
                    }
                }
            }
        }
    }

    protected _updateInfo(proto: GuildHegeBO) {
        this._joinRoleIds = new Set<string>(proto.signIds);
        this._joinStartTimestamp = proto.signStartTs;
        this._joinGroupId = proto.groupId;
        this._joinUnionIds = proto.groupGuildIds;
    }

    protected _updateRoleData(roleData: GuildHegeRoleDataBO) {
        if (roleData) {
            this._power = roleData.nowCount;
            this._nextRefreshTimestamp = roleData.refreshCountTs;
            this._nextRecoveryTimestamp = roleData.refreshTs;
            this._buyCount = roleData.nowBuyCount;
            this._unionScore = roleData.totalScore;
            this._userScore = roleData.score;
            this._occupyPoints = roleData.haveIds;

            this._guardHeroIds.clear();
            for (let key in roleData.outHeroIdsMap) {
                let heroIds = roleData.outHeroIdsMap[key] as string[];
                for (let heroId of heroIds) {
                    this._guardHeroIds.add(heroId);
                }
            }

            EManager.emit(this.Events.PowerDirty);
        }
    }
}

let unionWarLogic = new UnionWarLogic();
export default unionWarLogic;