import { Storage } from './../utils/DefineUtils';
import { defaultConfigMap } from './../configs/defaultConfig';
import { stringConfigMap } from './../configs/stringConfig';
import supplyconfig, { supplyconfigRow } from './../configs/supplyconfig';
import { SupplyInfoBO, GoodVO, SupplyGoReq, SupplyGoResVO } from './../proxy/GameProxy';
import BaseLogic from "./BaseLogic";
import IGameManager from "../manager/IGameManager";
import GameProxy from "../proxy/GameProxy";
import Good, { GoodId } from '../data/card/Good';
import Hero from '../data/card/Hero';
import commonUtils from '../utils/CommonUtils';
import missionLogic from './MissionLogic';
import EManager from '../manager/EventManager';
import cm from '../manager/ConfigManager';
import stringUtils from '../utils/StringUtils';
import ToastError from '../error/ToastError';
import playerLogic from './PlayerLogic';
import bagLogic from './BagLogic';
import rechargeLogic, { RightType } from './RechargeLogic';
import storageUtils from '../utils/StorageUtils';
import heroLogic from './HeroLogic';
import vipconfig from '../configs/vipconfig';

export enum SupplyType {
    /**
     * 普通
     */
    Normal = 1,

    /**
     * 高级
     */
    Senior
}

export class SupplyStation {
    protected _config: supplyconfigRow = null;
    protected _rewards: Good[] = [];
    protected _career: number = Hero.Career.Powerful;
    protected _prevStation: SupplyStation = null;
    protected _unlockTip: string = "";
    protected _heroIndex: number = 0;

    constructor(config: supplyconfigRow) {
        this._config = config;
        this._rewards = [];

        let stageConfig = cm.getStageConfig(this.unlockStageId);
        this._unlockTip = stringUtils.getString(stringConfigMap.key_pass_mission_unlock.Value,
            { buildingId: stageConfig.HouseID, levelId: stageConfig.level });

        let i = 1;
        while (config[`stoneID${i}`]) {
            let vo = new GoodVO();
            vo.propId = config[`stoneID${i}`];
            vo.amt = 0;
            this._rewards.push(new Good(vo));
            this._career = commonUtils.getCareerByGemStone(vo.propId);
            i++;
        }

        if (config.dust) {
            let vo = new GoodVO();
            vo.propId = GoodId.Dust;
            vo.amt = 0;
            this._rewards.push(new Good(vo));
        }

        if (config.artifactstone) {
            let vo = new GoodVO();
            vo.propId = GoodId.NormalStrongStone;
            vo.amt = 0;
            this._rewards.push(new Good(vo));
        }

        if (config.herochip) {
            let vo = new GoodVO();
            vo.propId = config.herochip;
            vo.amt = 0;

            let good = new Good(vo);
            this._rewards.push(good);
            this._heroIndex = good.getConfig().canCompose;
        }
    }

    get heroIndex(): number {
        return this._heroIndex;
    }

    get prevStation(): SupplyStation {
        return this._prevStation;
    }

    set prevStation(value: SupplyStation) {
        this._prevStation = value;
    }

    get config(): supplyconfigRow {
        return this._config;
    }

    get unlockTip(): string {
        return this._unlockTip;
    }

    get isUnlock(): boolean {
        let isUnlock = false;
        let mission = missionLogic.getCurrentMission();
        if (!mission) {
            isUnlock = true;
        }
        else {
            isUnlock = mission.getStageId() - this.unlockStageId > 0;
        }
        return isUnlock;
    }

    get name(): string {
        return this._config.supplyname;
    }

    get type(): SupplyType {
        return this._config.supplytype;
    }

    get unlockStageId(): number {
        return this._config.unlock;
    }

    get rewards(): Good[] {
        return this._rewards;
    }

    get career(): number {
        return this._career;
    }
}

/** 资源征收系统 */
class SupplyLogic extends BaseLogic {
    protected _buyCount: number = 0;
    protected _power: number = 0;
    protected _nextRefreshTimestamp: number = 0;
    protected _nextRecoveryTimestamp: number = 0;
    protected _seniorSearchTime: number = 0;
    protected _resetCanUse: number = 0;
    protected _resetCount: number = 0;

    protected _stations: SupplyStation[] = [];
    protected _seniorStations: SupplyStation[] = [];

    readonly Events = {
        SupplyInfoDirty: 'supply info dirty'
    }

    get isUnlock(): boolean {
        let isUnlock = storageUtils.getBoolean(Storage.SupplyUnlock);
        if (isUnlock) return isUnlock;

        let heroes = heroLogic.getHeroes({
            filter: (hero: Hero) => {
                return hero.getLevel(true) >= defaultConfigMap.tupoherolevel.value
            }
        });
        return heroes.length > 0;
    }

    get buyCount(): number {
        return this._buyCount;
    }

    get power(): number {
        return this._power;
    }

    get nextRefreshTimestamp(): number {
        return this._nextRefreshTimestamp;
    }

    get nextRecoveryTimestamp(): number {
        return this._nextRecoveryTimestamp;
    }

    get buyTiliLimit(): number {
        let level = playerLogic.getPlayer().getVipLevel();
        return defaultConfigMap.tilibuylimit.value + rechargeLogic.getVipBuffValue(RightType.TiliBuyLimit, level);
    }

    get seniorSearchLimit(): number {
        return defaultConfigMap.supplybasictime.value;
    }

    get seniorSearchTimes(): number {
        return this._seniorSearchTime;
    }

    get seniorSearchResetLimit(): number {
        let level = playerLogic.getPlayer().getVipLevel();
        return defaultConfigMap.supplyresettime.value + rechargeLogic.getVipBuffValue(RightType.SupplyReset, level);
    }

    get seniorSearchResetTimes(): number {
        return this._resetCount;
    }

    get seniorSearchResetPrice(): number {
        let prices = cm.supplyresetprice;
        return prices[Math.min(this._resetCount, prices.length - 1)];
    }

    get stations(): SupplyStation[] {
        return this._stations;
    }

    get seniorStations(): SupplyStation[] {
        return this._seniorStations;
    }

    init(gm: IGameManager) {
        super.init(null, gm);

        for (let config of supplyconfig) {
            let station = new SupplyStation(config);
            if (station.type == SupplyType.Normal) {
                station.prevStation = this._stations[this._stations.length - 1];
                this._stations.push(station);
            }
            else {
                station.prevStation = this._seniorStations[this._seniorStations.length - 1];
                this._seniorStations.push(station);
            }
        }
    }

    update(dt: number) {
        if (this.nextRecoveryTimestamp > 0) {
            if (this._gm.getCurrentTimestamp() >= this.nextRecoveryTimestamp) {
                this.doGetSupplyInfo();
            }
        }
        if (this.nextRefreshTimestamp > 0) {
            if (this._gm.getCurrentTimestamp() >= this.nextRefreshTimestamp) {
                this.doGetSupplyInfo();
            }
        }
    }

    async doGetSupplyInfo() {
        this._nextRecoveryTimestamp = 0;
        this._nextRefreshTimestamp = 0;

        let proto = await this._gm.request<SupplyInfoBO>(GameProxy.apisupplysupplyInfo);
        this._updateSupplyInfo(proto);
    }

    canSearchOnce(station: SupplyStation): { result: boolean, message?: string } {
        if (!station.isUnlock) {
            return {
                result: false,
                message: station.unlockTip
            }
        }

        if (station.type == SupplyType.Normal) {
            if (this._power < defaultConfigMap.normalsupply.value) {
                return {
                    result: false,
                    message: stringConfigMap.key_wait_power_recovery.Value
                }
            }
        }
        else {
            if (this._seniorSearchTime >= this.seniorSearchLimit) {
                return {
                    result: false,
                    message: stringConfigMap.key_no_enough_senior_search_time.Value
                }
            }

            if (this._power < defaultConfigMap.advancedsupply.value) {
                return {
                    result: false,
                    message: stringConfigMap.key_wait_power_recovery.Value
                }
            }
        }

        return { result: true }
    }

    /**
     * 资源不足时搜寻
     */
    async doSearchOnce(station: SupplyStation, good: Good, needAmt: number): Promise<Good[]> {
        let ret = this.canSearchOnce(station);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let req = new SupplyGoReq();
        req.needAmt = needAmt;
        req.needGoodsId = good.getIndex();
        req.supplyId = station.config.ID;
        req.supplyTimes = 1;
        let proto = await this._gm.request<SupplyGoResVO>(GameProxy.apisupplysupplyGo, req);
        this._updateSupplyInfo(proto.supplyInfo);

        return playerLogic.addCards(proto.resource) as Good[];
    }

    /**
     * 资源不足时搜寻
     */
    async doSearchTimes(station: SupplyStation, good: Good, needAmt: number): Promise<{ goods: Good[], details: Good[][] }> {
        let ret = this.canSearchOnce(station);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let req = new SupplyGoReq();
        req.needAmt = needAmt;
        req.needGoodsId = good.getIndex();
        req.supplyId = station.config.ID;

        let cost = 0;
        if (station.type == SupplyType.Normal) {
            cost = defaultConfigMap.normalsupply.value;
        }
        else {
            cost = defaultConfigMap.advancedsupply.value;
        }
        req.supplyTimes = Math.floor(this._power / cost);
        let proto = await this._gm.request<SupplyGoResVO>(GameProxy.apisupplysupplyGo, req);
        this._updateSupplyInfo(proto.supplyInfo);

        let details: Good[][] = [];
        let i = 1;
        while (proto.rewardMap[i]) {
            let vos = proto.rewardMap[i] as GoodVO[];
            let goods: Good[] = [];
            for (let vo of vos) {
                if (vo.amt > 0) {
                    goods.push(new Good(vo));
                }
            }
            details.push(goods);
            i++;
        }

        let goodMap: { [key: number]: Good } = {};
        let goods = playerLogic.addCards(proto.resource) as Good[];
        for (let good of goods) {
            if (goodMap[good.getIndex()]) {
                goodMap[good.getIndex()].changeAmount(good.getAmount());
            }
            else {
                goodMap[good.getIndex()] = good;
            }
        }
        return { goods: Object.values(goodMap), details: details };
    }

    /**
     * 地图补给站搜寻
     */
    async doSearchTimesEx(station: SupplyStation, times: number): Promise<{ goods: Good[], details: Good[][] }> {
        let ret = this.canSearchOnce(station);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let req = new SupplyGoReq();
        req.needAmt = 0;
        req.supplyId = station.config.ID;
        req.supplyTimes = times;
        let proto = await this._gm.request<SupplyGoResVO>(GameProxy.apisupplysupplyGo, req);
        this._updateSupplyInfo(proto.supplyInfo);

        let details: Good[][] = [];
        let i = 1;
        while (proto.rewardMap[i]) {
            let vos = proto.rewardMap[i] as GoodVO[];
            let goods: Good[] = [];
            for (let vo of vos) {
                if (vo.amt > 0) {
                    goods.push(new Good(vo));
                }
            }
            details.push(goods);
            i++;
        }

        let goodMap: { [key: number]: Good } = {};
        let goods = playerLogic.addCards(proto.resource) as Good[];
        for (let good of goods) {
            if (goodMap[good.getIndex()]) {
                goodMap[good.getIndex()].changeAmount(good.getAmount());
            }
            else {
                let vo = new GoodVO();
                vo.propId = good.getIndex();
                vo.amt = good.getAmount();
                goodMap[good.getIndex()] = new Good(vo);
            }
        }
        return { goods: Object.values(goodMap), details: details };
    }

    canBuyTili(times: number): { result: boolean, message?: string, consumes?: Function[] } {
        let remainTimes = this.buyTiliLimit - this._buyCount;
        if (remainTimes <= 0) {
            if (rechargeLogic.getVipBuffValue(RightType.TiliBuyLimit, vipconfig.length) > rechargeLogic.getVipBuffValue(RightType.TiliBuyLimit, playerLogic.getPlayer().getVipLevel())) {
                return {
                    result: false,
                    message: stringConfigMap.key_no_enough_buy_tili_times2.Value
                }
            }
            else {
                return {
                    result: false,
                    message: stringUtils.getString(stringConfigMap.key_no_enough_buy_tili_times.Value, { minute: defaultConfigMap.tiliautoadd.value / 60 })
                }
            }
        }

        if (times <= 0) {
            return {
                result: false,
                message: stringConfigMap.key_select_buy_tili_times.Value
            }
        }

        let cost = 0;
        let prices = cm.tilibuyprice;
        for (let i = this._buyCount; i < times + this._buyCount; i++) {
            cost += prices[Math.min(i, prices.length - 1)];
        }

        let consumes: Function[] = [];
        let good = bagLogic.getGood(GoodId.Diamond);
        if (good.getAmount() < cost) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(GoodId.Diamond, -cost);
            });
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    async doBuyTili(times: number) {
        let ret = this.canBuyTili(times);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let proto = await this._gm.request<SupplyInfoBO>(GameProxy.apisupplybugTili, times);
        this._updateSupplyInfo(proto);
        for (let consume of ret.consumes) {
            consume();
        }
    }

    canResetCount(): { result: boolean, message?: string, consumes?: Function[] } {
        let remainTimes = this.seniorSearchResetLimit - this._resetCount;
        if (remainTimes <= 0) {
            if (rechargeLogic.getVipBuffValue(RightType.SupplyReset, vipconfig.length) > rechargeLogic.getVipBuffValue(RightType.SupplyReset, playerLogic.getPlayer().getVipLevel())) {
                return {
                    result: false,
                    message: stringConfigMap.key_no_enough_supply_reset_times2.Value
                }
            }
            else {
                return {
                    result: false,
                    message: stringConfigMap.key_no_enough_supply_reset_times.Value
                }
            }
        }

        let consumes = [];
        let good = bagLogic.getGood(GoodId.Diamond);
        if (good.getAmount() < this.seniorSearchResetPrice) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(GoodId.Diamond, -this.seniorSearchResetPrice);
            });
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    async doResetCount() {
        let ret = this.canResetCount();
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        await this._gm.request(GameProxy.apisupplybugreset, 1);
        let proto = await this._gm.request<SupplyInfoBO>(GameProxy.apisupplyresetAdvFind);
        this._updateSupplyInfo(proto);

        for (let consume of ret.consumes) {
            consume();
        }
    }

    protected _updateSupplyInfo(proto: SupplyInfoBO) {
        this._buyCount = proto.nowBuyCount;
        this._power = proto.nowCount;
        this._seniorSearchTime = proto.findAdvCount;
        this._nextRefreshTimestamp = proto.refreshCountTs;
        this._nextRecoveryTimestamp = proto.refreshTs;
        this._resetCanUse = proto.resetCanUse;
        this._resetCount = proto.resetCount;

        EManager.emit(this.Events.SupplyInfoDirty);
    }
}

let supplyLogic = new SupplyLogic();
export default supplyLogic;