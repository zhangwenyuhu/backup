import equipLevelConfig from '../configs/equipLevelConfig';
import equippowerConfig from '../configs/equippowerConfig';
import equipstrengthconfig from '../configs/equipstrengthconfig';
import Artifact from "../data/card/Artifact";
import Card from '../data/card/Card';
import Equip from "../data/card/Equip";
import Good, { GoodId, GoodType } from "../data/card/Good";
import Hero from "../data/card/Hero";
import PlayerArtifact from '../data/card/PlayerArtifact';
import PlayerEquip from '../data/card/PlayerEquip';
import Property from '../data/Property';
import ToastError from "../error/ToastError";
import cm from '../manager/ConfigManager';
import EManager, { EName } from '../manager/EventManager';
import gm from "../manager/GameManager";
import IGameManager from '../manager/IGameManager';
import GameProxy, { BagVO, GoodUseReq } from "../proxy/GameProxy";
import commonUtils from '../utils/CommonUtils';
import stringUtils from '../utils/StringUtils';
import { defaultConfigMap } from './../configs/defaultConfig';
import { stringConfigMap } from './../configs/stringConfig';
import { EquipBO, EquipCompIntelliItem, EquipCompReq, EquipLvUpReq, EquipRecastReq, EquipStarUpReq, GoodVO, HeroVO, ResourceVO, RewardBO, StrengArtifactVO, StrengEquipVO } from './../proxy/GameProxy';
import BaseLogic from "./BaseLogic";
import commitLogic, { HeroSource } from './CommitLogic';
import heroLogic from './HeroLogic';
import playerLogic from "./PlayerLogic";
import redPointLogic from "./RedPointLogic";
import towerLogic from './TowerLogic';

/**背包系统 */
class BagLogic extends BaseLogic {
    Event = {
        OnEquipListAdd: "on equip list add",
        OnEquipListRemove: "on equip list remove"
    }

    protected _equips: { [key: string]: PlayerEquip } = {};
    protected _artifacts: { [key: string]: PlayerArtifact } = {};
    protected _indexArtifacts: { [key: number]: PlayerArtifact } = {};
    protected _goods: { [key: number]: Good } = {}

    init(bagProto: BagVO, gm: IGameManager) {
        super.init(bagProto, gm);

        this._equips = {};
        let equips: PlayerEquip[] = [];
        for (let proto of bagProto.equips) {
            let equip = new PlayerEquip(proto);
            equips.push(equip);
        }
        if (equips.length > 0) {
            this.addEquips(equips);
        }

        this._artifacts = {};
        for (let proto of bagProto.artifacts) {
            let artifact = new PlayerArtifact(proto);
            this.addArtifact(artifact);
        }

        this._goods = {};
        for (let proto of bagProto.goods) {
            let good = new Good(proto);
            this.addGood(good);
        }
    }

    /**
     * 获取所有装备（可加筛选）
     * @param filter 筛选方法
     */
    getEquips(filter?: (equip: Equip) => boolean): PlayerEquip[] {
        let equips = Object.values(this._equips);
        if (filter) { return equips.where(filter); }
        return equips;
    }

    /**
     * 查询装备
     * @param id 装备ID
     */
    getEquip(id: string): PlayerEquip {
        return this._equips[id];
    }

    /**
     * 添加装备
     * @param equips 装备列表
     */
    addEquips(equips: PlayerEquip[]) {
        for (let equip of equips) {
            this._equips[equip.getId()] = equip;
        }
        if (equips.length > 0) {
            EManager.emit(this.Event.OnEquipListAdd, equips);
        }
    }

    /**
     * 获取所有神器（可加筛选）
     * @param filter 筛选方法
     */
    getArtifacts(filter?: (artifact: Artifact) => boolean): Artifact[] {
        let artifacts = Object.values(this._artifacts);
        if (filter) { return artifacts.where(filter); }
        return artifacts;
    }

    /**
     * 查询神器
     * @param id 神器ID
     */
    getArtifact(id: string): Artifact {
        return this._artifacts[id];
    }

    getIndexArtifact(index: number): Artifact {
        return this._indexArtifacts[index];
    }

    /**
     * 添加神器
     * @param artifact 神器
     */
    addArtifact(artifact: PlayerArtifact) {
        this._artifacts[artifact.getId()] = artifact;
        this._indexArtifacts[artifact.getIndex()] = artifact;
    }

    /**
     * 删除装备
     * @param equipIds 装备ID列表
     */
    removeEquips(equipIds: string[]) {
        let equips: Equip[] = [];
        for (let id of equipIds) {
            let equip = this.getEquip(id);
            if (equip) {
                equips.push(equip);
                delete this._equips[id];
            }
        }
        if (equips.length > 0) {
            EManager.emit(this.Event.OnEquipListRemove, equips);
        }
    }

    /**获取合适英雄穿戴的装备 */
    getSuitableEquipsForHero(hero: Hero, place: number): Equip[] {
        return this.getEquips((e: Equip) => {
            let heroCareer = hero.getCareer() as number;
            let equipCareer = e.getEquipCareer() as number;
            return (e.getEquipPlace() == place && heroCareer == equipCareer);
        });
    }

    /**获取可以被用于强化装备的消耗的装备 */
    getEquipsForStrengthEquip(equip: Equip): Equip[][] {
        let equipDict: { [key: string]: Equip[] } = {}
        let equips = this.getEquips();
        for (let e of equips) {
            if (e == equip) continue;
            if (e.getHero()) continue;
            let hash = e.getHash();
            if (!equipDict[hash]) {
                equipDict[hash] = [];
            }
            equipDict[hash].push(e);
        }

        let equipss = Object.values(equipDict);
        equipss.sort((a: Equip[], b: Equip[]) => {
            return a[0].getTotalExp() - b[0].getTotalExp();
        })
        return equipss;
    }

    /**
     * 道具排序
     * @param goods 道具列表
     */
    sortGoods(goods: Good[]) {
        goods.sort((a: Good, b: Good) => {
            let aQuality = a.getQuality();
            let bQuality = b.getQuality();
            if (aQuality == bQuality) {
                let aType = a.getGoodType();
                let bType = b.getGoodType();
                if (aType == bType) {
                    return a.getSort() - b.getSort();
                }
                return a.getIndex() - b.getIndex();
            }
            return bQuality - aQuality;
        });
    }

    /**
     * 获取所有道具
     * @param filter 筛选方法
     */
    getGoods(filter?: (good: Good) => boolean): Good[] {
        let func = (good: Good) => {
            if (filter && !filter(good)) {
                return false;
            }
            return good.getAmount() > 0;
        }
        let goods = Object.values(this._goods).where(func);
        this.sortGoods(goods);
        return goods;
    }

    /**
     * 查询道具
     * @param goodId 道具ID
     */
    getGood(goodId: number): Good {
        if (this._goods[goodId]) {
            return this._goods[goodId];
        }
        let goodVO = new GoodVO();
        goodVO.propId = goodId;
        goodVO.amt = 0;
        this._goods[goodId] = new Good(goodVO);
        return this._goods[goodId];
    }

    /**
     * 添加道具
     * @param good 道具
     */
    addGood(good: Good) {
        if (!this._goods[good.getIndex()]) {
            let goodVO = new GoodVO();
            goodVO.propId = good.getIndex();
            goodVO.amt = good.getAmount();
            this._goods[good.getIndex()] = new Good(goodVO);
        }
        else {
            this.changeGoodAmount(good.getIndex(), good.getAmount());
        }
    }

    /**物品的消耗或添加 */
    changeGoodAmount(goodId: number, delta: number) {
        let good = this.getGood(goodId);
        if (good) {
            good.setAmount(good.getAmount() + delta);
        }
        else {
            if (delta > 0) {
                let proto = new GoodVO();
                proto.amt = delta;
                proto.propId = goodId;
                good = new Good(proto);
                this.addGood(good);
            }
        }

        if (goodId == GoodId.Diamond && delta < 0) {
            EManager.emit(EName.onCostDiamond, -delta);
        }
    }

    /**
     * 灵魂石生成英雄需要的数量
     */
    getSoulStoneNeed(): number {
        return 60;
    }

    /**获取强化需要消耗的金币 */
    getStrongEquipConsumeGold(equip: PlayerEquip, strongLevel: number): number {
        let gold = 0;
        for (let i = 0; i < strongLevel; i++) {
            let config = equipstrengthconfig[equip.getLevel() + i];
            gold += config.gold;
        }
        return gold;
    }

    /**能否强化装备 */
    canStrongEquip(equip: PlayerEquip, strongLevel: number = 1): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        let level = equip.getLevel() + strongLevel;
        if (level > equip.getMaxLevel()) {
            return {
                result: false,
                message: stringConfigMap.key_equip_level_limited.Value
            }
        }

        let consumes: Function[] = [];
        let gold = this.getStrongEquipConsumeGold(equip, strongLevel);
        let good = this.getGood(Good.GoodId.Gold);
        if (good.getAmount() < gold) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => { bagLogic.changeGoodAmount(Good.GoodId.Gold, -gold); });
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**强化装备 */
    doStrongEquip(equip: PlayerEquip, strongLevel: number = 1): Property {
        let ret = this.canStrongEquip(equip, strongLevel);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        for (let consume of ret.consumes) {
            consume();
        }

        let property = equip.getProperty();
        equip.setLevel(equip.getLevel() + strongLevel);

        let newProperty = equip.getProperty();
        return newProperty.sub(property);
    }

    /**请求强化装备 */
    async requestEquipLvUp(equip: PlayerEquip) {
        let req = new EquipLvUpReq();
        req.equipId = equip.getId();
        req.lv = equip.getLevel();
        let proto = await this._gm.request<StrengEquipVO>(GameProxy.apiequiplvUpEquip, req);
        equip.update(proto.equipInfo);

        if (proto.heroAddInfos) {
            let hero = heroLogic.getHero(proto.heroAddInfos.heroId);
            if (hero) {
                hero.updateAddition([proto.heroAddInfos]);
                if (heroLogic.isPriestHero(hero)) {
                    await heroLogic.doGetEquipAddition();
                }
            }
        }
    }

    /**获取精炼装备需要消耗的金币 */
    getConsumeGoldForRefineEquip(deltaExp: number) {
        return deltaExp * 100;
    }

    /**能否精炼装备 */
    canRefineEquip(equip: PlayerEquip, blackCoinNum?: number): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        if (equip.getMaxStar() <= 0 || equip.getStar() >= equip.getMaxStar()) {
            return { result: false }
        }

        if (blackCoinNum === 0) {
            return {
                result: false,
                message: stringConfigMap.key_exchange_no_good.Value
            }
        }

        let consumes = [];
        if (blackCoinNum === undefined) {
            let needExp: number = equip.getNextStarExp() - equip.getExp();
            let cof = cm.getGoodConfig(GoodId.BlackCoin);
            let mat = [GoodId.BlackCoin, Math.ceil(needExp / cof.effect)];
            let ret = bagLogic.checkGoodCostResult([mat]);
            if (ret.ret) {
                consumes.push(() => { bagLogic.changeGoodAmount(Good.GoodId.BlackCoin, -mat[0][1]); });
                return {
                    result: true,
                    consumes: consumes,
                }
            } else {
                return {
                    result: false,
                    message: stringConfigMap.key_exchange_no_good.Value,
                }
            }
        }

        consumes.push(() => { bagLogic.changeGoodAmount(Good.GoodId.BlackCoin, -blackCoinNum); });
        return {
            result: true,
            consumes: consumes
        }
    }

    /**精炼装备 */
    async doRefineEquip(equip: PlayerEquip, blackCoinNum: number) {
        let ret = this.canRefineEquip(equip, blackCoinNum);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let req = new EquipStarUpReq();
        req.equipId = equip.getId();
        req.blackCoinCount = blackCoinNum;
        req.blackCoinAdvCount = 0;

        let proto = await this._gm.request<StrengEquipVO>(GameProxy.apiequipstarUpEquip, req);
        equip.update(proto.equipInfo);

        if (proto.heroAddInfos) {
            let hero = heroLogic.getHero(proto.heroAddInfos.heroId);
            hero.updateAddition([proto.heroAddInfos]);
        }

        for (let consume of ret.consumes) {
            consume();
        }

        if (proto.resourceVO) {
            let rewards = proto.resourceVO.rewards as any;
            if (rewards) {
                for (let reward of rewards) {
                    let vo = new GoodVO();
                    vo.objId = reward.objId;
                    vo.propId = reward.propId;
                    vo.amt = Number(reward.amt);
                    let good = new Good(vo);
                    bagLogic.addGood(good);
                }
            }
        }
    }

    /**精炼装备 装备升星 */
    async doEquipStarUp(equip: PlayerEquip, blackCoin: number, highBlackCoin: number) {
        let ret = blackCoin > 0 || highBlackCoin > 0;
        if (!ret) {
            throw new ToastError(stringConfigMap.key_exchange_no_good.Value);
        }

        let req = new EquipStarUpReq();
        req.equipId = equip.getId();
        req.blackCoinCount = blackCoin;
        req.blackCoinAdvCount = highBlackCoin;

        let proto = await this._gm.request<StrengEquipVO>(GameProxy.apiequipstarUpEquip, req);
        equip.update(proto.equipInfo);

        if (proto.heroAddInfos) {
            let hero = heroLogic.getHero(proto.heroAddInfos.heroId);
            hero.updateAddition([proto.heroAddInfos]);
        }

        if (proto.resourceVO) {
            let rewards = proto.resourceVO.rewards as any;
            if (rewards) {
                for (let reward of rewards) {
                    let vo = new GoodVO();
                    vo.objId = reward.objId;
                    vo.propId = reward.propId;
                    vo.amt = Number(reward.amt);
                    let good = new Good(vo);
                    bagLogic.addGood(good);
                }
            }
        }
    }

    /**
     * 获取装备从nowLevel强化到toLevel所需要的金币
     * @param nowLevel 当前等级
     * @param toLevel 目标等级
     */
    getEquipUpgradeConsumeGold(nowLevel: number, toLevel: number): number {
        if (nowLevel >= equipstrengthconfig.length) { return 0; }
        if (nowLevel >= toLevel) { return 0; }
        let needGold: number = 0;
        for (let i = nowLevel - 1; i < toLevel; i++) {
            if (equipstrengthconfig[i]) {
                needGold += equipstrengthconfig[i].gold;
            }
        }
        return needGold;
    }

    /**获取合成装备需要消耗的金币 */
    getConsumeGoldForMergeEquip(equip: PlayerEquip) {
        let config = equipLevelConfig[Math.min(equip.getRank(), equipLevelConfig.length - 1)];
        return config.EqComCost;
    }

    /**
     * 询问是否要合成装备
     */
    protected async _askMergeEquip(): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this._gm.dialog({
                content: stringConfigMap.key_sure_to_merge_equip.Value,
                confirm: () => { resolve(true) },
                cancel: () => { resolve(false) }
            });
        });
    }

    checkMatEquip(equips: Equip[]) {
        let hasStar: boolean = false;
        let hasCharging: boolean = false;
        let hasCamp: boolean = false;
        for (let i = 0; i < equips.length; i++) {
            let equip = equips[i];
            if (equip.getStar() > 0) { hasStar = true; }
            if (equip.getChargingLv() > 0) { hasCharging = true; }
            if (equip.getCamp() > 0) { hasCamp = true; }
        }
        /*
        let message: string = `材料中存在`;
        if (hasStar) { message += '星级装备、'; }
        if (hasCharging) { message += '充能装备、'; }
        if (hasCamp) { message += '联盟加成装备'; }
        message += `,是否继续合成`;*/
        let msg = '选中的材料中具有培养过的装备，继续合成将100%返还材料装备培养消耗的资源，是否继续合成?'
        return { ret: !hasStar && !hasCharging && !hasCamp, msg: msg };
    }

    /**能否合成装备 */
    canMergeEquip(equip: PlayerEquip, needEquips: PlayerEquip[]): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        if (equip.getRank() >= equip.getMaxRank()) {
            return {
                result: false,
                message: stringConfigMap.key_equip_rank_limited.Value
            }
        }

        let config = equipLevelConfig[Math.min(equip.getRank(), equipLevelConfig.length - 1)];
        let tower = towerLogic.getCurrentTower();
        if (tower < config.EqComLimit) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_equip_merge_tower_limited.Value, { tower: config.EqComLimit })
            }
        }

        if (needEquips.length != 2) {
            return {
                result: false,
                message: stringConfigMap.key_equip_merge_no_enough_material.Value
            }
        }

        let consumes: Function[] = [];
        let good = this.getGood(Good.GoodId.Gold);
        let gold = this.getConsumeGoldForMergeEquip(equip);
        if (good.getAmount() < gold) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(Good.GoodId.Gold, -gold);
            });
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**合成装备 */
    async doMergeEquip(equip: PlayerEquip, needEquips: PlayerEquip[]) {
        let ret = this.canMergeEquip(equip, needEquips);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        /*
        for (let needEquip of needEquips) {
            if (needEquip.isTrained()) {
                let ret = await this._askMergeEquip();
                if (!ret) return false;
                break;
            }
        }*/

        let req = new EquipCompReq();
        req.equipId = equip.getId();
        req.consumeIds = [];
        for (let e of needEquips) {
            req.consumeIds.push(e.getId());
        }
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiequipcompoundBatch, [req]);
        if (proto.extra) {
            let equipBos = proto.extra[0] as EquipBO[];
            if (equipBos) {
                for (let bo of equipBos) {
                    let equip = this.getEquip(bo.equipId);
                    if (equip) { equip.update(bo); }
                }
            }

            let heroVos = proto.extra[1] as HeroVO[];
            if (heroVos) {
                for (let vo of heroVos) {
                    let hero = heroLogic.getHero(vo.heroId);
                    if (hero) { hero.update(vo, true); }
                }
            }
        }

        for (let consume of ret.consumes) {
            consume();
        }
        this.removeEquips(req.consumeIds);
        //this._gm.getReward(proto, false);
        return { ret: true, proto: proto };
    }

    /**
     * 装备智能合成
     * @param equipCofId 装备表中的ID
     * @param mat 合成材料
     */
    async doAutoMergeEquip(equipCofId: number, mat: string[][]) {
        let params: EquipCompIntelliItem[] = [];
        for (let i = 0; i < mat.length; i++) {
            let param = new EquipCompIntelliItem;
            param.equipConfId = equipCofId;
            param.consumeIds = mat[i];
            params.push(param);
        }

        let proto = await this._gm.request<ResourceVO>(GameProxy.apiequipcompoundIntelli, params);
        for (let i = 0; i < mat.length; i++) { this.removeEquips(mat[i]); }
        gm.getReward(proto);
    }

    /**能否装备充能 */
    canChargingEquip(equip: PlayerEquip): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        if (equip.getChargingLv() >= equip.getMaxCharingLv()) {
            return {
                result: false,
                message: stringConfigMap.key_equip_charging_lv_limited.Value
            }
        }

        let consumes: Function[] = [];
        let config = equippowerConfig[equip.getChargingLv()];
        for (let param of config.EqPCost1) {
            let good = commonUtils.item2Card(param) as Good;
            if (bagLogic.getGood(good.getIndex()).getAmount() < good.getAmount()) {
                return {
                    result: false,
                    message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
                }
            }
            else {
                consumes.push(() => {
                    bagLogic.changeGoodAmount(good.getIndex(), -good.getAmount());
                })
            }
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**装备充能 */
    async doChargingEquip(equip: PlayerEquip) {
        let ret = this.canChargingEquip(equip);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let req = new EquipLvUpReq();
        req.equipId = equip.getId();
        req.lv = equip.getChargingLv() + 1;
        let proto = await this._gm.request<StrengEquipVO>(GameProxy.apiequipchargeEquip, req);
        equip.update(proto.equipInfo);

        if (proto.heroAddInfos) {
            let hero = heroLogic.getHero(proto.heroAddInfos.heroId);
            hero.updateAddition([proto.heroAddInfos]);
        }

        for (let consume of ret.consumes) {
            consume();
        }
    }

    /**装备分解后返还物品预览 */
    async doSplitEquipPreview(equip: PlayerEquip): Promise<Card[]> {
        let protos = await this._gm.request<RewardBO[]>(GameProxy.apiequipdecompPre, [equip.getId()], GameProxy, true);
        let goods: { [key: number]: Good } = {};
        for (let proto of protos) {
            let good = commonUtils.reward2Card(proto) as Good;
            if (good) {
                if (goods[good.getIndex()]) {
                    goods[good.getIndex()].changeAmount(good.getAmount());
                }
                else {
                    goods[good.getIndex()] = good;
                }
            }
        }
        return Object.values(goods);
    }

    /**确认分解装备 */
    protected async _askSplitEquip(equip: PlayerEquip): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this._gm.splitDialog(equip, () => { resolve(true) }, () => { resolve(false) });
        });
    }

    /**分解装备 */
    async doSplitEquip(equip: PlayerEquip): Promise<Card[]> {
        if (equip.getRank() >= 5) {
            let ret = await this._askSplitEquip(equip);
            if (!ret) { return []; }
        }

        let cards: Card[] = [];
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiequipdecompEquip, [equip.getId()]);
        cards.pushList(playerLogic.addCards(proto));
        this.removeEquips([equip.getId()]);

        return cards;
    }

    /**装备重生后返还物品预览 */
    async doResetEquipPreview(equip: PlayerEquip): Promise<Card[]> {
        let protos = await this._gm.request<RewardBO[]>(GameProxy.apiequipresetPre, [equip.getId()], GameProxy, true);
        let cards: Card[] = [];

        let equipCopy = equip.clone();
        equipCopy.reset();
        cards.push(equipCopy);

        for (let proto of protos) {
            let card = commonUtils.reward2Card(proto);
            if (card) { cards.push(card); }
        }
        return cards;
    }

    /**能否装备重生 */
    canResetEquip(equip: PlayerEquip): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        if (!equip.isTrained()) {
            return {
                result: false,
                message: stringConfigMap.key_equip_no_reset.Value
            }
        }

        let consumes: Function[] = [];
        let good = bagLogic.getGood(Good.GoodId.Diamond);
        if (good.getAmount() < defaultConfigMap.equipreborncost.value) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(Good.GoodId.Diamond, -defaultConfigMap.equipreborncost.value);
            });
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**装备重生 */
    async doResetEquip(equip: PlayerEquip): Promise<Card[]> {
        let ret = this.canResetEquip(equip);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let proto = await this._gm.request<ResourceVO>(GameProxy.apiequipresetEquip, [equip.getId()]);

        for (let consume of ret.consumes) {
            consume();
        }

        let cards: Card[] = [];
        if (proto.extra) {
            let equipBos = proto.extra[0] as EquipBO[];
            for (let bo of equipBos) {
                let equip = this.getEquip(bo.equipId);
                if (equip) {
                    equip.update(bo);
                    cards.push(equip);
                }
            }
        }
        cards.pushList(playerLogic.addCards(proto));

        return cards;
    }

    /**获取重铸消耗的钻石 */
    getConsumeDiamondForRecastEquip(equip: PlayerEquip) {
        return equipLevelConfig[Math.min(equip.getRank(), equipLevelConfig.length) - 1].ReFactionCost;
    }

    /**确认重铸 */
    protected async _askRecastEquip(prevFaction: number, nowFaction: number, equip: PlayerEquip, effectCall: Function): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this._gm.recastDialog(prevFaction, nowFaction, equip, () => {
                resolve(true)
            }, () => {
                resolve(false)
            }, effectCall);
        });
    }

    /**随机专属阵营 */
    protected _getRandomFaction(equip: PlayerEquip, excepts: number[]): number {
        let config = equipLevelConfig[Math.min(equip.getRank(), equipLevelConfig.length) - 1];
        let factions: { faction: number, random: number }[] = [];
        let total = 0;
        for (let i = Hero.Faction.Armed; i <= Hero.Faction.Destroy; i++) {
            if (excepts.indexOf(i) >= 0) continue;
            if (i == Hero.Faction.Super || i == Hero.Faction.Destroy) {
                factions.push({ faction: i, random: config.SuperFaction / 2 });
                total += config.SuperFaction / 2;
            }
            else {
                factions.push({ faction: i, random: config.Faction / 4 });
                total += config.Faction / 4;
            }
        }

        if (total > 0) {
            let random = Math.random() * total;
            let value = 0;
            for (let faction of factions) {
                value += faction.random;
                if (random < value) {
                    return faction.faction;
                }
            }
        }
        return factions[Math.floor(Math.random() * factions.length)].faction;
    }

    /**能否重铸装备 */
    canRecastEquip(equip: PlayerEquip): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        if (equip.getCamp() <= 0) {
            return {
                result: false,
                message: stringConfigMap.key_equip_no_camp.Value
            }
        }

        let diamond = this.getConsumeDiamondForRecastEquip(equip);
        let good = this.getGood(Good.GoodId.Diamond);
        let consumes: Function[] = [];
        if (good.getAmount() < diamond) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(Good.GoodId.Diamond, -diamond);
            })
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**重铸装备 */
    async doRecastEquip(equip: PlayerEquip, cancelFaction?: number, effectFuntion?: Function) {
        let ret = this.canRecastEquip(equip);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        if (!cancelFaction) {
            cancelFaction = await this._gm.request<number>(GameProxy.apiequipgetCancelRecast, equip.getId());
        }
        let excepts = [
            cancelFaction,
            equip.getCamp()
        ]
        let req = new EquipRecastReq();
        req.equipId = equip.getId();
        req.fac = this._getRandomFaction(equip, excepts);
        let proto = await this._gm.request<StrengEquipVO>(GameProxy.apiequiprecastEquip, req);

        for (let consume of ret.consumes) {
            consume();
        }

        let result = await this._askRecastEquip(equip.getCamp(), proto.equipInfo.campBonus, equip, effectFuntion);
        if (result) {
            equip.update(proto.equipInfo);
            if (proto.heroAddInfos) {
                let hero = heroLogic.getHero(proto.heroAddInfos.heroId);
                if (hero) { hero.updateAddition([proto.heroAddInfos]); }
            }
        }
        else {
            let req = new EquipRecastReq();
            req.equipId = equip.getId();
            req.fac = proto.equipInfo.campBonus;
            await this._gm.request(GameProxy.apiequipcancelRecast, req);
        }
    }

    /**能否强化神器 */
    canUpgradeArtifact(artifact: PlayerArtifact): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        if (artifact.getStar() == artifact.getStarLimit()) {
            return {
                result: false,
                message: stringConfigMap.key_max_star.Value
            }
        }

        let consumes: Function[] = [];

        let goldGood = bagLogic.getGood(Good.GoodId.Gold);
        let consumeGold = artifact.getConsumeGold();
        if (goldGood.getAmount() < consumeGold) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: goldGood.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(Good.GoodId.Gold, -consumeGold);
            });
        }

        let good = artifact.getConsumeGood();
        if (bagLogic.getGood(good.getIndex()).getAmount() < good.getAmount()) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(good.getIndex(), -good.getAmount());
            })
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**强化神器 */
    async doUpgradeArtifact(artifact: PlayerArtifact) {
        let ret = this.canUpgradeArtifact(artifact);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let proto = await this._gm.request<StrengArtifactVO>(GameProxy.apiartifactstrengArtifact, artifact.getId());
        artifact.update(proto.artifactInfo);

        for (let consume of ret.consumes) {
            consume();
        }

        if (proto.heroAddInfos) {
            let hero = heroLogic.getHero(proto.heroAddInfos.heroId);
            hero.updateAddition([proto.heroAddInfos]);
        }
    }

    /**
     * 是否使用道具
     * @param good 道具
     * @param value 数量
     */
    canUseGood(good: Good, value: number): {
        result: boolean,
        message?: string
    } {
        if (value > good.getAmount()) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        if (good.getGoodType() == Good.GoodType.SoulStone) {
            if (this.getSoulStoneNeed() > good.getAmount()) {
                return {
                    result: false,
                    message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
                }
            }
        }

        return { result: true }
    }

    /**
     * 使用道具
     * @param good 道具
     * @param value 数量
     * @param param 额外参数
     */
    async doUseGood(good: Good, value: number = 1, param?: any) {
        let ret = this.canUseGood(good, value);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }
        if (good.getGoodType() == GoodType.SoulStone) {
            let count = heroLogic.getHeroesCount();
            if (count + Math.floor(value / bagLogic.getSoulStoneNeed()) > playerLogic.getPlayer().getHeroCapacity()) {
                throw new ToastError(stringConfigMap.key_max_hero_grid.Value);
            }
        }

        let req = new GoodUseReq();
        req.goodsId = good.getIndex();
        req.useCount = value;
        if (param) { req.paras = param }
        let proto = await this._gm.request<ResourceVO>(GameProxy.apibaguseGoods, req);
        if (proto) {
            if (good.getIndex() == Good.GoodId.NormalGenius
                || good.getIndex() == Good.GoodId.MiddleGenius
                || good.getIndex() == Good.GoodId.SeniorGenius) {
                heroLogic.updateGeniusPoints(param.heroConfId, proto.extra as any);
            }
            else {
                if (good.getGoodType() == GoodType.UnionDiamondChest) {
                    for (let _reward of proto.rewards) {
                        let _good = new GoodVO();
                        _good.amt = Number(_reward["amt"]);
                        _good.objId = _reward["objId"];
                        _good.propId = _reward["propId"];
                        if (!proto.goods) {
                            proto.goods = [];
                        }
                        proto.goods.push(_good);
                    }
                }
                gm.getReward(proto, true);
                redPointLogic.freshAll();
            }

            good.changeAmount(-value);
        }
        commitLogic.rewardHero(proto, HeroSource.mergePiece, '');
    }

    /**
     * 更新包裹中某种类型的物品的数据
     * @param goodId
     */
    async updateGoodAmt(goodId: number) {
        let proto = await this._gm.request<GoodVO[]>(GameProxy.apibaggetTypeGoods, [goodId]);
        if (proto) {
            for (let i = 0; i < proto.length; i++) {
                let goodInfo = new Good(proto[i]);
                let nowGood = this.getGood(goodInfo.getIndex())
                if (nowGood) {
                    nowGood.setAmount(goodInfo.getAmount());
                } else {
                    this.addGood(nowGood);
                }
            }
        }
    }

    /**
     * 购买普通许愿币
     * @param count 
     */
    async buyWishCoinReq(count: number) {
        let proto = await gm.request<ResourceVO>(GameProxy.apiturntablebuyWishCoin, count);
        gm.getReward(proto);
    }

    /**
     * 获取物品使用效果需要的数量 如果不够 则全部
     * @param effect 
     * @param goodId 
     */
    public getCostGood(effect: number, goodId: number[]) {
        let num: number = 0;
        let result: number[][] = [];
        for (let i = 0; i < goodId.length; i++) {
            result.push([goodId[i], 0]);
            let good = bagLogic.getGood(goodId[i]);
            if (!good) { continue; }
            if (!good.getConfig().effect) { continue; }

            if (num >= effect) { continue; }
            let need: number = Math.ceil((effect - num) / good.getConfig().effect);
            if (need <= good.getAmount()) {
                result[i][1] = need;
                num += need * good.getConfig().effect;
            } else {
                result[i][1] = good.getAmount();
                num += good.getAmount() * good.getConfig().effect;
            }
        }
        return result;
    }

    /**
     * 获取装备自动合成所需的装备
     * @param equipCofId 
     * @param maxRank 
     */
    public getEquipAutoMergeMat(equipCofId: number, maxRank: number) {
        let cfg = cm.getEquipConfig(equipCofId);
        let limitRank: number = cfg.Rank - 1;
        limitRank = limitRank > maxRank ? maxRank : limitRank;
        let all = bagLogic.getEquips((equip) => {
            return (!equip.getHero() && equip.getRank() <= limitRank
                && equip.getEquipPlace() == cfg.Place && equip.getEquipCareer() == cfg.Career);
        });

        let result: { [key: number]: Equip[] } = {};
        let need: number = 3;

        for (let j = cfg.Rank - 1; j > 0; j--) {
            for (let i = 0; i < all.length; i++) {
                if (all[i].getRank() == j) {
                    if (!result[j]) { result[j] = []; }
                    result[j].push(all[i]);
                    need -= 1;
                    if (need == 0) { break; }
                }
            }
            need = need * 3;
            if (need == 0) { break; }
        }


        if (need > 0) { return { res: false, mat: [] }; }
        let arr: Equip[] = [];
        let keys = Object.keys(result);
        for (let i = 0; i < keys.length; i++) {
            arr = arr.concat(result[keys[i]]);
        }
        return { res: true, mat: arr };
    }

    public getEquipAutoMergeMatEx(equipCofId: number) {
        let cof = cm.getEquipConfig(equipCofId);
        let matRank: number = cof.Rank - 1;
        let equips = bagLogic.getEquips((equip) => {
            return (!equip.getHero() && equip.getRank() == matRank
                && equip.getEquipPlace() == cof.Place && equip.getEquipCareer() == cof.Career);
        });

        equips.sort((a, b) => {
            if (a.getChargingLv() == b.getChargingLv()) {
                if (a.getStar() == b.getStar()) {
                    return a.getLevel() - b.getLevel();
                } else {
                    return a.getStar() - b.getStar();
                }
            } else {
                return a.getChargingLv() - b.getChargingLv();
            }
        })
        let num = Math.floor(equips.length / 3);
        equips = equips.slice(0, num * 3);

        return { res: num > 0, mat: equips };
    }

    /**
     * 获取自动合成需要的材料信息
     * @param mat 
     * @param limitRank 
     * @param targetRank 
     */
    public getAutoMergeRankList(mat: { [key: number]: number }, limitRank: number, targetRank: number) {
        let need: number = 3;
        let preNum: number = 0;
        let cost: { [key: number]: number } = {};
        let target: number = limitRank + 1;
        for (let i = 1; i < target; i++) {
            let mat: number = Math.pow(need, (target - i));
            let cur: number = mat[i] ? mat[i] : 0;
            if ((cur + preNum) >= mat) { cost[i] = mat - preNum; break; }

            if (i == limitRank) { cost = {}; preNum = 0; break; }
            let next: number = Math.floor((preNum + cur) / need);
            if (next == 0) { cost = {}, preNum = 0; continue; }
            preNum = next;
            cost[i] = Math.floor(cur / need) * need;
        }
        return cost;
    }

    public checkGoodCostResult(mat: number[][]) {
        let ret: { ret: boolean, msg: string } = { ret: true, msg: '' };
        if (!mat) { return ret; }
        for (let i = 0; i < mat.length; i++) {
            let goodId: number = mat[i][0];
            let good = bagLogic.getGood(goodId);
            if (good.getAmount() < mat[i][1]) {
                ret.ret = false;
                ret.msg = stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() });
                break;
            }
        }
        return ret;
    }
    public costGood(mat: number[][]) {
        if (!mat) { return; }
        for (let i = 0; i < mat.length; i++) {
            let good = bagLogic.getGood(mat[i][0]);
            if (good) { good.changeAmount(-mat[i][1]); }
        }
    }
}
let bagLogic = new BagLogic();
export default bagLogic;