import artifactConfig from "../configs/artifactConfig";
import artifactlevelConfig, { artifactlevelConfigRow } from "../configs/artifactlevelConfig";
import artifactunlockConfig from "../configs/artifactunlockConfig";
import equipstrengmasterconfig from '../configs/equipstrengmasterconfig';
import geniusConfig from '../configs/geniusConfig';
import HeroCompoundConfig from "../configs/HeroCompoundConfig";
import heroConfig from '../configs/heroConfig';
import heroLevelConfig from "../configs/heroLevelConfig";
import heroRankConfig from '../configs/heroRankConfig';
import sevenDaysConfig from "../configs/sevenDaysConfig";
import skinconfig from "../configs/skinconfig";
import { unlockConfigMap } from '../configs/unlockConfig';
import Artifact from "../data/card/Artifact";
import Card from '../data/card/Card';
import Equip from '../data/card/Equip';
import Good, { GoodId } from "../data/card/Good";
import Hero from "../data/card/Hero";
import HeroIllustration from '../data/card/HeroIllustration';
import PlayerArtifact from '../data/card/PlayerArtifact';
import PlayerEquip from '../data/card/PlayerEquip';
import PlayerHero from '../data/card/PlayerHero';
import Skill from '../data/card/Skill';
import { PromptType } from "../data/prompt/PromptModal";
import Property from '../data/Property';
import ToastError from "../error/ToastError";
import cm from '../manager/ConfigManager';
import EManager from '../manager/EventManager';
import gm from "../manager/GameManager";
import IGameManager from '../manager/IGameManager';
import GameProxy, { HeroLvUpReq, LvUpArtifactReq, StrengArtifactVO, UnEquipReq } from "../proxy/GameProxy";
import chatSocket from "../socket/ChatSocket";
import { SystemType } from "../socket/ChatUserData";
import commonUtils from '../utils/CommonUtils';
import { TaskActivityType } from "../utils/DefineUtils";
import heroUtils, { HeroMaterial } from "../utils/HeroUtils";
import stringUtils from '../utils/StringUtils';
import UnlockWrapper from '../view/widget/unlock/UnlockWrapper';
import { defaultConfigMap } from './../configs/defaultConfig';
import { geniusConfigRow } from './../configs/geniusConfig';
import jibanconfig, { jibanconfigRow } from './../configs/jibanconfig';
import { propertyConfigMap, propertyConfigRow } from './../configs/propertyConfig';
import { stringConfigMap } from './../configs/stringConfig';
import { GeniusFruit } from './../data/genius/GeniusFruit';
import { EName } from './../manager/EventManager';
import {
    ArtifactBO,
    ChangeArtifactReq,

























    EquipBO, EquipChangeReq,
    EquipInheritReq, FetterAddBO, FlowerEquipItemBO, FlowerPlaceInfoVO,
    GoodUseReq,
    GoodVO,
    HeroBagVO,
    HeroBookVO,
    HeroLvUpVO,
    HeroModulAddItem,
    HeroModulBO,
    HeroVO,
    RankUpHeroReq,
    ResourceVO,











    RewardBO, SkinBO,
    TalentAddSkillItemBO,













    TalentAddVO, TalentInfoVO,
    TalentReq,
    UpdateFlowerReq,
    UpdateLockReq,
    WearArtifactReq,
    WearEquipReq,
    WearSkinReq
} from './../proxy/GameProxy';
import activityLogic, { ActivityType } from "./ActivityLogic";
import artifactLogic from "./ArtifactLogic";
import bagLogic from "./BagLogic";
import BaseLogic from "./BaseLogic";
import commitLogic, { DiamondCost, DustCost } from './CommitLogic';
import libraryLogic from './LibraryLogic';
import playerLogic from './PlayerLogic';

export enum GeniusPointType {
    /**
     * 普通天赋点
     */
    Normal,

    /**
     * 中级天赋点
     */
    Middle,

    /**
     * 高级天赋点
     */
    Senior
}

export class ArtifactUnlockInfo {
    protected _unlockInfo: Map<number, number> = new Map<number, number>();

    constructor(proto) {
        this.update(proto);
    }

    update(proto) {
        this._unlockInfo = proto;
        let levelAdditions = this.getAllLevelAddition();
        let index = 0;
        for (let addition of levelAdditions.additions) {
            if (levelAdditions.unlock >= index) {
                for (let _addition of addition.artifactPro) {
                    let c = Property.getConfig(_addition);
                    if (c.value < 0) {
                        this[`_${c.config.VarName}ArtifactAddPct`] = c.value;
                    } else {
                        this[`_${c.config.VarName}ArtifactAddValue`] = c.value;
                    }
                }
            }
            index++;
        }
    }

    getLvExp() {
        return this._unlockInfo["-99"] || 0;
    }

    getLevel() {
        let lv = 1;
        let totalExp = 0;
        let config = artifactlevelConfig;
        let lvExp = this.getLvExp();
        for (let i = 0; i < config.length; i++) {
            let levelCfg = config[i];
            totalExp += levelCfg.spend;
            if (totalExp >= lvExp) {
                lv = levelCfg.Level;
                break;
            } else {
                if (i == config.length - 1) {
                    lv = levelCfg.Level;
                    break;
                }
            }
        }
        return lv;
    }

    getLevelMax() {
        return artifactlevelConfig.length;
    }

    getCurrentLevelExp() {
        let lv = 1;
        let totalExp = 0;
        let config = artifactlevelConfig;
        let lvExp = this.getLvExp();
        for (let levelCfg of config) {
            totalExp += levelCfg.spend;
            if (totalExp >= lvExp) {
                lv = levelCfg.Level;
                return lvExp - Math.max(totalExp - levelCfg.spend, 0);
            }
        }
        return 0;
    }

    getNextLevelAddition() {
        let level = this.getLevel();
        for (let i = level; i < artifactlevelConfig.length; i++) {
            let cfg = artifactlevelConfig[i];
            if (cfg.artifactPro.length > 0) {
                return { addition: cfg.artifactPro, level: cfg.Level };
            }
        }
        return null;
    }

    getAllLevelAddition() {
        let additions: artifactlevelConfigRow[] = [];
        let index = -1;
        let unlock = -1;
        for (let i = 0; i < artifactlevelConfig.length; i++) {
            let cfg = artifactlevelConfig[i];
            if (cfg.artifactPro.length > 0) {
                additions.push(cfg);
                index++;
                if (this.getLevel() >= cfg.Level) {
                    unlock = index;
                }
            }
        }
        return { additions: additions, unlock: unlock };
    }

    getArtifactAddValue(config: propertyConfigRow) {
        let value = 0;
        if (this[`_${config.VarName}ArtifactAddValue`]) {
            value += this[`_$${config.VarName}ArtifactAddValue`];
        }
        if (bagLogic.getArtifacts().length > 0) {
            if (config.VarName == 'atk') {
                value += this.getAtkAdd();
            } else if (config.VarName == 'hp') {
                value += this.getHpAdd();
            }
        }
        return value;
    }

    getArtifactAddPct(config: propertyConfigRow) {
        let value = 0;
        if (this[`_${config.VarName}ArtifactAddPct`]) {
            value += this[`_$${config.VarName}ArtifactAddPct`];
        }
        return value;
    }

    getIncArtifactHarm(): number {
        return this.getArtifactAddPct(propertyConfigMap.神器主动技能增伤);
    }

    getDecArtifactHarm(): number {
        return this.getArtifactAddPct(propertyConfigMap.神器主动技能减伤);
    }

    getCriPctArtifact(): number {
        return this.getArtifactAddPct(propertyConfigMap.神器主动技能暴击率);
    }

    getCriAtkArtifact(): number {
        return this.getArtifactAddPct(propertyConfigMap.神器主动技能暴击伤害);
    }

    getAtkAdd(next: boolean = false) {
        let level = this.getLevel();
        if (next && level < this.getLevelMax()) {
            level++;
        }
        let config = artifactlevelConfig;
        return level > 0 ? config[level - 1].attack : 0;
    }

    getHpAdd(next: boolean = false) {
        let level = this.getLevel();
        if (next && level < this.getLevelMax()) {
            level++;
        }
        let config = artifactlevelConfig;
        return level > 0 ? config[level - 1].Hp : 0;
    }

    doAddExp(exp: number) {
        this._unlockInfo["-99"] += exp;
    }

    artifactCanShow() {
        return this.getNewArtifactId() > 0 && !activityLogic.pioneer2CanShow
    }

    getNewArtifactId() {
        let artifactIds: number[] = [];
        for (let i = 1; i <= 7; i++) {
            artifactIds.push(artifactunlockConfig.find(a => a.order == i).ArtifactID);
        }
        let artifacts = bagLogic.getArtifacts();
        for (let id of artifactIds) {
            let artifact = artifacts.find(a => a.getIndex() == id);
            if (!artifact && this.getTaskMaxCnt(id) > 0) {
                return id;
            }
        }
        return 0;
    }

    getTaskMaxCnt(artifactId: number) {
        let tasks = artifactunlockConfig.where(a => a.ArtifactID == artifactId && a.tasktype != null);
        return tasks.length;
    }

    getProgress(confId: number) {
        return this._unlockInfo[confId.toString()] || 0;
    }

    getTaskProgress(confId: number) {
        let cnt = 0;
        let artifactCfg = artifactunlockConfig.where(a => a.ArtifactID == confId);
        for (let artifact of artifactCfg) {
            if (this._unlockInfo[artifact.ID.toString()] >= artifact.tasknumber) {
                cnt++;
            }
        }
        return cnt;
    }

    /**增加进度 */
    addTaskProgress(taskId: number, progress: number = 1) {
        let needEmit: boolean = false;
        let artifactCfgs = artifactunlockConfig.where(a => a.tasktype == taskId);
        for (let artifact of artifactCfgs) {
            if (!this.isArtifactUnlock(artifact.ArtifactID)) {
                if (this._unlockInfo[artifact.ID.toString()]) {
                    // 种族塔直接设置进度
                    if (taskId == 8006) {
                        this._unlockInfo[artifact.ID.toString()] = progress;
                    } else {
                        this._unlockInfo[artifact.ID.toString()] += progress;
                    }
                } else {
                    // 升级英雄任务，默认英雄等级1
                    if (taskId == 3004 || taskId == 3005) {
                        this._unlockInfo[artifact.ID.toString()] = 1 + progress;
                    } else {
                        this._unlockInfo[artifact.ID.toString()] = progress;
                    }
                }
                needEmit = true;
            }
        }
        if (needEmit) {
            EManager.emit(EName.onRedDirty, PromptType.ArtifactMerge);
            EManager.emit(EName.onUpdateArtifact);
            EManager.emit(EName.onActivityBtnFresh, "activity");
        }
    }

    canShowRedPoint() {
        for (let artifactCfg of artifactConfig) {
            if (this.canArtifactMerge(artifactCfg.Id) ||
                this.canArtifactLevelUp(artifactCfg.Id) ||
                this.canArtifactEvolution(artifactCfg.Id)) {
                return true;
            }
        }
        return false;
    }

    artifactRedPoint(confId: number) {
        return this.canArtifactMerge(confId) || this.canArtifactLevelUp(confId) || this.canArtifactEvolution(confId);
    }

    /**可合成 */
    mergeRedPoint() {
        for (let artifactCfg of artifactConfig) {
            if (this.canArtifactMerge(artifactCfg.Id)) {
                return true;
            }
        }
        return false;
    }

    /**可升级红点 */
    levelUpRedPoint() {
        for (let artifactCfg of artifactConfig) {
            if (this.canArtifactLevelUp(artifactCfg.Id)) {
                return true;
            }
        }
        return false;
    }

    /**可进阶红点 */
    evolutionRedPoint() {
        for (let artifactCfg of artifactConfig) {
            if (this.canArtifactEvolution(artifactCfg.Id)) {
                return true;
            }
        }
        return false;
    }

    /**神器可合成 */
    canArtifactMerge(confId: number) {
        let artifactCfg = artifactunlockConfig.where(a => a.ArtifactID == confId);
        let tasks = this.artifactTasks(confId);
        if (tasks.length == 0) {
            return false;
        }
        for (let artifact of artifactCfg) {
            if (this._unlockInfo[artifact.ID.toString()] < artifact.tasknumber) {
                return false;
            }
        }
        return !this.isArtifactUnlock(confId);
    }

    artifactTasks(confId: number) {
        let taskIds = [];
        let artifactUnlockCfgs = artifactunlockConfig.where(a => a.ArtifactID == confId);
        for (let artifactUnlockCfg of artifactUnlockCfgs) {
            let taskTypeCfg = cm.getTaskTypeConfig(artifactUnlockCfg.tasktype);
            if (taskTypeCfg) {
                taskIds.push(artifactUnlockCfg.ID);
            }
        }
        return taskIds;
    }

    /**神器能否升级 */
    canArtifactLevelUp(confId: number) {
        if (this.isArtifactUnlock(confId)) {
            let artifact = this.getArtifact(confId);
            let level = Math.min(artifactlevelConfig.length - 1, artifact.getLevel());
            let config = artifactlevelConfig[level];
            if (config.playerlevel <= playerLogic.getPlayer().getLevel() && artifact.getLevel() < artifact.getLevelMax()) {
                let stone1 = bagLogic.getGood(10480).getAmount();
                let stone2 = bagLogic.getGood(10481).getAmount();
                if (stone1 > 0 || stone2 > 0) {
                    return true;
                }
            }
        }
        return false;
    }

    /**神器能否进阶 */
    canArtifactEvolution(confId: number) {
        if (this.isArtifactUnlock(confId)) {
            let artifactCfg = artifactConfig.find(a => a.Id == confId);
            let artifact = this.getArtifact(confId);
            if (artifact.getStar() < artifact.getStarLimit()) {
                let amt = bagLogic.getGood(artifactCfg.Goods).getAmount();
                return amt >= artifact.getConsumePieceCount();
            }
        }
        return false;
    }

    /**获取神器 */
    getArtifact(confId: number) {
        let artifacts = bagLogic.getArtifacts();
        let artifact = artifacts.find(a => a.getIndex() == confId);
        if (!artifact) {
            let artifactBo = new ArtifactBO();
            artifactBo.artifactCofId = confId;
            artifactBo.artifactId = "";
            artifactBo.heroId = "";
            artifactBo.forgeLv = 0;
            artifactBo.rank = 0;
            artifact = new Artifact(artifactBo);
        }
        return artifact;
    }

    /**神器已解锁 */
    isArtifactUnlock(confId: number) {
        let artifact = this.getArtifact(confId);
        return artifact != null && artifact.getId() != "";
    }

}

/**英雄系统 */
class HeroLogic extends BaseLogic {
    readonly events = {
        onFetterAdditionDirty: 'on fetter addition dirty',
        onTechAdditionDirty: 'on tech addition dirty'
    }

    protected _heroes: { [key: string]: PlayerHero } = {}
    protected _heroIndexMap: { [key: number]: PlayerHero[] } = {}
    protected _heroFactionMap: { [key: number]: PlayerHero[] } = {}
    protected _skillLevels: { [key: number]: number[] } = {}
    protected _heroIllustrations: { [key: number]: HeroIllustration } = {}
    protected _rewardIllustrations: { [key: number]: HeroBookVO } = {};
    protected _shareHeroes: PlayerHero[] = [];
    protected _geniusAdditions: { [key: number]: HeroModulBO } = {};
    protected _geniusPoints: { [key: number]: number[] } = {};
    protected _geniusConfigs: { [key: number]: geniusConfigRow[] } = {};
    protected _geniusFruits: {
        [key: number]: {
            fruits: GeniusFruit[],
            active: boolean,
            details: { [key: number]: number }
        }
    } = {};
    protected _geniusSkills: { [key: number]: TalentAddSkillItemBO[] } = {};
    protected _artifactUnlockInfo: ArtifactUnlockInfo = null;
    protected _skinAdditions: { [key: number]: HeroModulBO[] } = {};
    protected _skins: number[] = [];
    protected _artifactAltarAdditions: HeroModulBO = null;

    protected _medalLvAddtion: HeroModulBO = null;
    protected _medalTreeAdditions: HeroModulBO[] = [];
    protected _techAdditions: { [key: number]: HeroModulBO } = {};
    protected _fetterAdditions: { [key: number]: HeroModulBO } = {};
    protected _equipAdditions: { [key: string]: HeroModulBO } = {};
    protected _equipShares: { [key: string]: string[] } = {};
    protected _fetterConfigs: { [key: number]: { config: jibanconfigRow, active: boolean }[] } = {};

    priestsHeroDirty: boolean = true;
    unlockSlotCount: number = 0;
    buySlotCount: number = 0;

    async init(protos: HeroBagVO, gm: IGameManager) {
        super.init(protos, gm);

        let proto = await this._gm.request<Map<number, number>>(GameProxy.apiartifactartifactUnlockInfo, -1);
        this._artifactUnlockInfo = new ArtifactUnlockInfo(proto);
        artifactLogic.init(this._artifactUnlockInfo, gm);

        playerLogic.getPlayer().setBuyCapacityCost(protos.buyCost);

        let heroProtos = protos.heroes;
        this._heroes = {};
        let heroes: PlayerHero[] = [];
        for (let heroProto of heroProtos) {
            let hero = new PlayerHero(heroProto, false);
            if (!hero.config) continue;

            hero.updateCommonAdd(playerLogic.getPlayer().getCommomHeroAdd());
            heroes.push(hero);
        }
        if (heroes.length > 0) {
            this.addHeroes(heroes, true);
        }

        this._heroIllustrations = {};
        for (let config of heroConfig) {
            if (config.Type == rpgfight.HeroType.Hero) {
                let illustration = new HeroIllustration(config.Id);
                this._heroIllustrations[illustration.getIndex()] = illustration;
            }
        }

        let talentAdd = protos.talentAdd;
        if (talentAdd) {
            for (let add of talentAdd) {
                if (add.heroModulBO) {
                    this._geniusAdditions[add.heroConfId] = add.heroModulBO;
                    this._geniusSkills[add.heroConfId] = add.skillAdd;
                }
            }
        }

        this._fetterConfigs = {};
        for (let config of jibanconfig) {
            let configs = this._fetterConfigs[config.hero];
            if (configs) {
                configs.push({ config: config, active: false });
            }
            else {
                this._fetterConfigs[config.hero] = [{ config: config, active: false }];
            }
        }

        let heroFetterAdd = protos.heroFetterAdd;
        if (heroFetterAdd) {
            this._updateFetterAddition(heroFetterAdd);
        }

        let equipFetterAdd = protos.heroFlowerEquipAdd;
        if (equipFetterAdd) {
            this._updateEquipAddition(equipFetterAdd);
        }
        // 公会科技加成
        let techAdd = protos.gtechAdd;
        if (techAdd) {
            this.updateTechAddition(techAdd);
        }
        // 战略树加成
        let medalTreeAdd = protos.stratAdd;
        if (medalTreeAdd) {
            this.updateMedalTreeAddition(medalTreeAdd);
        }
        // 勋章加成
        if (protos.medalAdd) {
            this.updateMedalLvAddition(protos.medalAdd);
        }
        // 图书馆加成及激活羁绊
        libraryLogic.updateFetterInfo(protos.libFetterAdd);

        let skinAdd = protos.skinAdd;
        if (skinAdd) {
            this._updateSkinAddition(skinAdd);
        }

        this._geniusConfigs = {};
        for (let config of geniusConfig) {
            let configs = this._geniusConfigs[config.type];
            if (!configs) {
                configs = [];
                this._geniusConfigs[config.type] = configs;
            }
            configs.push(config);
        }

        let artifactAdd = protos.artifactAltarAdd;
        if (artifactAdd) {
            this.updateArtifactAltarAddition(artifactAdd);
        }
    }

    // 更新自己英雄的公共加成信息
    updateHeroCommonAdd() {
        let commonAdd = playerLogic.getPlayer().getCommomHeroAdd();
        Object.keys(this._heroes).forEach((v, i, a) => {
            this._heroes[v].updateCommonAdd(commonAdd);
        })
    }

    isSkinExist(skinId: number) {
        return this._skins.indexOf(skinId) != -1;
    }

    /**获取英雄已拥有皮肤*/
    getSkins(heroConfId: number) {
        let skins = [];
        let heroCfg = cm.getHeroConfig(heroConfId);
        if (heroCfg && heroCfg.heroskin) {
            for (let skin of heroCfg.heroskin) {
                if (this._skins.indexOf(skin) != -1) {
                    skins.push(skin);
                }
            }
        }
        return skins;
    }

    /**皮肤头像已解锁*/
    isSkinHeadUnlock(heroConfId: number) {
        let cfg = skinconfig.find(a => a.SkinHead == heroConfId);
        if (cfg) {
            if (this._skins.indexOf(cfg.ID) != -1) {
                return true;
            }
        }
        return false;
    }

    /**获取所有图鉴 */
    getIllustrations(filter?: (hero: HeroIllustration) => boolean): HeroIllustration[] {
        let heroes = Object.values(this._heroIllustrations);
        if (filter) { return heroes.where(filter); }
        return heroes;
    }

    getIllustration(confId: number) {
        return this._heroIllustrations[confId];
    }

    updateHeroIllustrations(protos: HeroBookVO[]) {
        this._rewardIllustrations = {};
        for (let proto of protos) {
            this._rewardIllustrations[proto.heroCofId] = proto;
        }
    }

    getRewardIllustration(index: number): HeroBookVO {
        return this._rewardIllustrations[index];
    }

    sortHeroes(heroes: Hero[], options?: {
        useRealLevel?: boolean,
        sortId?: boolean,
        sortPower?: boolean
    }) {
        if (heroes.length == 0) {
            return;
        }
        if (!options) options = {};
        heroes.sort((a: Hero, b: Hero) => {
            let aLevel = a.getLevel(options.useRealLevel);
            let bLevel = b.getLevel(options.useRealLevel);
            if (aLevel != bLevel) return bLevel - aLevel;

            let aRank = a.getRank(options.useRealLevel);
            let bRank = b.getRank(options.useRealLevel);
            if (aRank != bRank) return bRank - aRank;

            if (options.sortPower) {
                let aPower = a.getPower(options.useRealLevel);
                let bPower = b.getPower(options.useRealLevel);
                if (aPower != bPower) return bPower - aPower;
            }

            if (options.sortId) {
                let aIndex = a.getIndex();
                let bIndex = b.getIndex();
                if (aIndex != bIndex) return aIndex - bIndex;

                if (a.getId() < b.getId()) { return -1; }
                else { return 1; }
            }
            else {
                return a.getIndex() - b.getIndex();
            }
        });
    }

    /**获取所有英雄 */
    getHeroes(options?: {
        filter?: (hero: PlayerHero) => boolean,
        useRealLevel?: boolean,
        sort?: boolean
    }): PlayerHero[] {
        let heroes = Object.values(this._heroes);
        if (options) {
            if (options.filter) { heroes = heroes.where(options.filter); }
            if (options.sort) { this.sortHeroes(heroes, { useRealLevel: options.useRealLevel, sortPower: true }); }
        }
        return heroes;
    }

    getHeroesCount(): number {
        let heroes = Object.values(this._heroes);
        return heroes.length;
    }

    getHeroesIndexCount(): number {
        let indexes = new Set<number>();
        for (let id in this._heroes) {
            let hero = this._heroes[id];
            indexes.add(hero.getIndex());
        }
        return indexes.size;
    }

    /**根据ID获取英雄 */
    getHero(id: string) {
        return this._heroes[id];
    }

    /**根据表ID获取英雄 */
    getHeroesByIndex(index: number): PlayerHero[] {
        return this._heroIndexMap[index] || [];
    }

    /**根据阵营获取英雄 */
    getHeroesByFaction(faction: number): PlayerHero[] {
        return this._heroFactionMap[faction] || [];
    }

    /**获取可进阶的英雄 */
    getEvolutionHeroes(): PlayerHero[] {
        return this.getHeroes({ filter: (hero: PlayerHero) => { return hero.getQuality() != Hero.Quality.Normal } });
    }

    /**获取可升星英雄 */
    getStarHeroes(): PlayerHero[] {
        return this.getHeroes({ filter: (hero: PlayerHero) => { return hero.getQuality() > 2 } });
    }

    /**获取可合成英雄 */
    getMergeHeroes(): Hero[] {
        let heroes: Hero[] = [];
        for (let config of HeroCompoundConfig) {
            let heroVo = new HeroVO();
            heroVo.equips = [];
            heroVo.exp = 0;
            heroVo.heroAddInfos = [];
            heroVo.heroCofId = config.CompoundHero;
            heroVo.heroId = stringUtils.generateUUID();
            heroVo.lv = 1;
            heroVo.rank = cm.getHeroConfig(config.CompoundHero).DefaultRank;
            heroVo.star = 0;
            heroes.push(new Hero(heroVo));
        }
        return heroes;
    }

    /**获取可回退的英雄 */
    getRollbackableHeroes(ignoreLock?: boolean): PlayerHero[] {
        let heroes = this.getHeroes({
            filter: (hero: PlayerHero) => { return hero.canRollback(ignoreLock) },
            useRealLevel: true
        });
        heroes.sort((a: Hero, b: Hero) => {
            let aLock = a.isLock() ? 0 : 1;
            let bLock = b.isLock() ? 0 : 1;
            if (aLock != bLock) return bLock - aLock;

            let aRank = a.getRank(true);
            let bRank = b.getRank(true);
            if (aRank != bRank) return aRank - bRank;

            let aLevel = a.getLevel(true);
            let bLevel = b.getLevel(true);
            if (aLevel != bLevel) return aLevel - bLevel;

            let aPower = a.getPower(true);
            let bPower = b.getPower(true);
            return aPower - bPower;
        })
        return heroes;
    }

    /**获取可重置的英雄 */
    getResetableHeroes(ignoreLock?: boolean): PlayerHero[] {
        let heroes = this.getHeroes({
            filter: (hero: PlayerHero) => { return hero.canReset(ignoreLock) },
            useRealLevel: true
        });
        heroes.sort((a: Hero, b: Hero) => {
            let aLock = a.isLock() ? 0 : 1;
            let bLock = b.isLock() ? 0 : 1;
            if (aLock != bLock) return bLock - aLock;

            let aRank = a.getRank(true);
            let bRank = b.getRank(true);
            if (aRank != bRank) return aRank - bRank;

            let aLevel = a.getLevel(true);
            let bLevel = b.getLevel(true);
            if (aLevel != bLevel) return aLevel - bLevel;

            let aPower = a.getPower(true);
            let bPower = b.getPower(true);
            return aPower - bPower;
        })
        return heroes;
    }

    /**获取可分解的英雄 */
    getSplitableHeroes(ignoreLock?: boolean): PlayerHero[] {
        let heroes = this.getHeroes({
            filter: (hero: PlayerHero) => { return hero.canSplit(ignoreLock); },
            useRealLevel: true
        });
        heroes.sort((a: Hero, b: Hero) => {
            let aLock = a.isLock() ? 0 : 1;
            let bLock = b.isLock() ? 0 : 1;
            if (aLock != bLock) return bLock - aLock;

            let aLevel = a.getLevel(true);
            let bLevel = b.getLevel(true);
            if (aLevel != bLevel) return aLevel - bLevel;

            let aIndex = a.getIndex();
            let bIndex = b.getIndex();
            if (aIndex != bIndex) return aIndex - bIndex;

            let aPower = a.getPower(true);
            let bPower = b.getPower(true);
            return aPower - bPower;
        });

        return heroes;
    }

    /**是否是祭司 */
    isPriestHero(hero: PlayerHero): boolean {
        if (!UnlockWrapper.isUnlock(unlockConfigMap.共享花坛)) {
            return false;
        }
        let heroes = this.getShareHeroes();
        let count = Math.min(heroes.length, this.getPriestsCount());
        for (let i = 0; i < count; i++) {
            if (heroes[i] == hero) {
                hero.setSharePosition(0);
                return true;
            }
        }
        return false;
    }

    /**获取花坛祭司的个数 */
    getPriestsCount(): number {
        return 5;
    }

    /**获取用于共享花坛的英雄 */
    getShareHeroes(): PlayerHero[] {
        if (this.priestsHeroDirty) {
            this.priestsHeroDirty = false;
            let heroes = Object.values(this._heroes);
            this.sortHeroes(heroes, { useRealLevel: true, sortId: true });
            this._shareHeroes = heroes;

            let count = Math.min(heroes.length, this.getPriestsCount());
            for (let i = 0; i < count; i++) {
                heroes[i].setSharePosition(0);
            }
        }
        return this._shareHeroes;
    }

    /**队伍等级 */
    getTeamLevel(): number {
        let heroes = this.getShareHeroes();
        let hero = heroes[Math.min(this.getPriestsCount(), heroes.length) - 1];
        if (hero) { return hero.getLevel(true); }
        return 0;
    }

    /**队伍品阶 */
    getTeamRank(): number {
        let heroes = this.getShareHeroes();
        heroes = heroes.slice(0, this.getPriestsCount());
        heroes.sort((a: Hero, b: Hero) => { return a.getRank(true) - b.getRank(true) });
        let hero = heroes[0];
        if (hero) { return hero.getRank(true); }
        return 0;
    }

    protected _updateHeroAddition(hero: PlayerHero) {
        hero.getGeniusAddValue = (config: propertyConfigRow) => {
            let addition = this._geniusAdditions[hero.getIndex()];
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) { return item.addValue; }
            }
            return 0;
        }
        hero.getGeniusAddPct = (config: propertyConfigRow) => {
            let addition = this._geniusAdditions[hero.getIndex()];
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) { return item.addPct; }
            }
            return 0;
        }
        hero.getGeniusSkills = () => {
            let datas = this._geniusSkills[hero.getIndex()];
            let skills: Skill[] = [];
            if (datas) {
                for (let data of datas) {
                    let skill = new Skill(null, cm.getSkillConfig(data.skillId), []);
                    skill.getLevel = () => { return data.lv };
                    skills.push(skill);
                }
            }
            return skills;
        }
        hero.getSkinAddValue = (config: propertyConfigRow) => {
            let value = 0;
            let addition = this._skinAdditions[hero.getIndex()];
            if (addition) {
                for (let _addition of addition) {
                    let item = _addition[`${config.VarName}Add`] as HeroModulAddItem;
                    if (item && !item.empty) {
                        value += item.addValue;
                    }
                }
            }
            return value;
        }
        hero.getSkinAddPct = (config: propertyConfigRow) => {
            let value = 0;
            let addition = this._skinAdditions[hero.getIndex()];
            if (addition) {
                for (let _addition of addition) {
                    let item = _addition[`${config.VarName}Add`] as HeroModulAddItem;
                    if (item && !item.empty) {
                        value += item.addPct;
                    }
                }
            }
            return value;
        }
        hero.getFetterAddValue = (config: propertyConfigRow) => {
            let value = 0;
            let addition = this._fetterAdditions[hero.getIndex()];
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) { value += item.addValue; }
            }
            return value;
        }
        hero.getFetterAddPct = (config: propertyConfigRow) => {
            let pct = 0;
            let addition = this._fetterAdditions[hero.getIndex()];
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) { pct += item.addPct; }
            }
            return pct;
        }
        hero.getTechAddValue = (config: propertyConfigRow) => {
            let value = 0;
            let addition = this._techAdditions[hero.config.duty];
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) { value += item.addValue; }
            }
            return value;
        }
        hero.getTechAddPct = (config: propertyConfigRow) => {
            let pct = 0;
            let addition = this._techAdditions[hero.config.duty];
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) { pct += item.addPct; }
            }
            return pct;
        }
        // 战略树加成
        hero.getMedalTreeAddValue = (config: propertyConfigRow) => {
            let value = 0;
            let additions = this._medalTreeAdditions;
            if (additions) {
                for (let addition of additions) {
                    if (this._validMedalTreeBuff(addition.heroCofId, hero.getIndex())) {
                        let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                        if (item && !item.empty) { value += item.addValue; }
                    }
                }
            }
            return value;
        }
        hero.getMedalTreeAddPct = (config: propertyConfigRow) => {
            let pct = 0;
            let additions = this._medalTreeAdditions;
            if (additions) {
                for (let addition of additions) {
                    if (this._validMedalTreeBuff(addition.heroCofId, hero.getIndex())) {
                        let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                        if (item && !item.empty) { pct += item.addPct; }
                    }
                }
            }
            return pct;
        }
        hero.getMedalRestrainAddVPct = () => {
            let pct = 0;
            let additions = this._medalTreeAdditions;
            if (additions) {
                for (let addition of additions) {
                    if (addition.heroCofId == 214001) {
                        if (this._validMedalTreeBuff(addition.heroCofId, hero.getIndex())) {
                            let item = addition[`restrainAdd`] as HeroModulAddItem;
                            if (item && !item.empty) { pct += item.addPct; }
                        }
                    }
                }
            }
            return pct;
        }
        hero.getEquipAddValue = (config: propertyConfigRow) => {
            let value = 0;
            let addition = this._equipAdditions[hero.getId()];
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) { value = item.addValue; }
            }
            return value;
        }
        hero.getEquipAddPct = (config: propertyConfigRow) => {
            let pct = 0;
            let addition = this._equipAdditions[hero.getId()];
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) { pct = item.addPct; }
            }
            return pct;
        }
        //神器祭坛、共鸣加成
        hero.getArtifactAltarAddValue = (config: propertyConfigRow) => {
            let value = 0;
            let addition = this._artifactAltarAdditions;
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) {
                    value += item.addValue;
                }
            }
            return value;
        }
        hero.getArtifactAltarAddPct = (config: propertyConfigRow) => {
            let value = 0;
            let addition = this._artifactAltarAdditions;
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) {
                    value += item.addPct;
                }
            }
            return value;
        }
        // 勋章等级加成
        hero.getMedalLvAddValue = (config: propertyConfigRow) => {
            let value = 0;
            let addition = this._medalLvAddtion;
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) {
                    value += item.addValue;
                }
            }
            return value;
        }
        hero.getMedalLvAddPct = (config: propertyConfigRow) => {
            let value = 0;
            let addition = this._medalLvAddtion;
            if (addition) {
                let item = addition[`${config.VarName}Add`] as HeroModulAddItem;
                if (item && !item.empty) {
                    value += item.addPct;
                }
            }
            return value;
        }
    }

    addHeroes(heroes: PlayerHero[], isDefault: boolean = false) {
        if (heroes.length > 0) { EManager.emit(EName.onBeforeAddHeroes, heroes); }

        for (let hero of heroes) {
            let selectHeroes = this._heroIndexMap[hero.getIndex()];
            if (!selectHeroes) {
                selectHeroes = [];
                this._heroIndexMap[hero.getIndex()] = selectHeroes;
            }
            selectHeroes.push(hero);

            selectHeroes = this._heroFactionMap[hero.getFaction()];
            if (!selectHeroes) {
                selectHeroes = [];
                this._heroFactionMap[hero.getFaction()] = selectHeroes;
            }
            selectHeroes.push(hero);

            this._updateHeroAddition(hero);

            this._heroes[hero.getId()] = hero;
            EManager.emit(EName.onAddHero, hero);

            this.priestsHeroDirty = true;

            if (!this._rewardIllustrations[hero.getIndex()]) {
                let proto = new HeroBookVO();
                proto.heroCofId = hero.getIndex();
                proto.isGet = 0;
                this._rewardIllustrations[hero.getIndex()] = proto;
            }
        }
        playerLogic.getPlayer().setPowerDirty();

        if (!isDefault) {
            this._commitAddHeroesTask(heroes);
            this._doGetFetterAddition();
            if (this.priestsHeroDirty) {
                this.doGetEquipAddition();
            }
        }

        if (heroes.length > 0) { EManager.emit(EName.onAddHeroes, heroes); }
    }

    removeHeroes(heroIds: string[]) {
        for (let id of heroIds) {
            let hero = this.getHero(id);
            if (hero) {
                EManager.emit(EName.onRemoveHero, hero);
                delete this._heroes[id];

                let selectHeroes = this._heroIndexMap[hero.getIndex()];
                if (selectHeroes) {
                    let index = selectHeroes.indexOf(hero);
                    if (index >= 0) { selectHeroes.splice(index, 1); }
                }

                selectHeroes = this._heroFactionMap[hero.getFaction()];
                if (selectHeroes) {
                    let index = selectHeroes.indexOf(hero);
                    if (index >= 0) { selectHeroes.splice(index, 1); }
                }

                this.priestsHeroDirty = true;
            }
        }
        playerLogic.getPlayer().setPowerDirty();
    }

    // 战略树节点buff是否可以作用于某个英雄
    protected _validMedalTreeBuff(medalTreeId: number, heroId: number): boolean {
        let medalCof = cm.getMedalTechConfig(medalTreeId);
        let heroCof = cm.getHeroConfig(heroId);
        // 阵营
        if (!medalCof.faction || medalCof.faction.length <= 0) { return false; }
        let fIndex = medalCof.faction.findIndex((a) => { return a == heroCof.Faction; })
        if (!(fIndex >= 0)) { return false; }
        // 定位
        if (!medalCof.herotype || medalCof.herotype.length <= 0) { return false; }
        let dIndex = medalCof.herotype.findIndex((a) => { return a == heroCof.duty; })
        if (!(dIndex >= 0)) { return false; }
        // 职业
        if (!medalCof.herojob || medalCof.herojob.length <= 0) { return false; }
        let cIndex = medalCof.herojob.findIndex((a) => { return a == heroCof.Career; })
        if (!(cIndex >= 0)) { return false; }

        return true;
    }

    /**获取装备需求英雄 */
    getEquipNeedHeros(equip: Equip): PlayerHero[] {
        let needHeros: PlayerHero[] = [];
        let heros = this.getShareHeroes();
        for (let hero of heros) {
            let heroEquip = hero.getEquip(equip.getEquipPlace());
            if (heroEquip && hero.getCareer() == Number(equip.getEquipCareer()) && equip.getPower() > heroEquip.getPower()) {
                needHeros.push(hero);
            }
        }
        return needHeros;
    }

    /**是否能升级英雄 */
    canUpgradeLevel(hero: Hero, upgradeLevel: number = 1): {
        result: boolean,
        message?: string,
        consumes?: Function[],
        goods?: { [key: number]: Good },
        breach?: boolean
    } {
        if (hero.getSharePosition() > 0) {
            return {
                result: false,
                message: stringConfigMap.key_level_sharing.Value
            }
        }

        let ret: {
            result: boolean,
            message?: string,
            consumes?: Function[],
            goods?: { [key: number]: Good },
            breach?: boolean
        } = {
            result: true,
            consumes: [],
            goods: {},
            breach: false
        }
        let level = hero.getLevel();
        let rank = hero.getRank();
        let levelLimited = hero.getLevelLimited();
        let rankLimited = hero.getRankUpperLimited();
        if ((level + upgradeLevel - 1) >= levelLimited) {
            if (rank < rankLimited) {
                ret.result = false;
                ret.message = stringConfigMap.key_level_limited_by_evolution.Value;
            }
            else {
                ret.result = false;
                ret.message = stringConfigMap.key_level_limited.Value;
            }
        }

        for (let i = 0; i < upgradeLevel; i++) {
            let config = heroLevelConfig[level - 1 + i];
            if (!config) { break }

            if (config.Exp > 0) {
                let good = ret.goods[Good.GoodId.Exp];
                if (!good) {
                    let vo = new GoodVO();
                    vo.propId = Good.GoodId.Exp;
                    vo.amt = 0;
                    good = new Good(vo);
                    ret.goods[Good.GoodId.Exp] = good;
                }
                good.changeAmount(config.Exp);

                if (ret.result && bagLogic.getGood(Good.GoodId.Exp).getAmount() < good.getAmount()) {
                    ret.result = false;
                    ret.message = stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() });
                }
            }

            if (config.Gold > 0) {
                let good = ret.goods[Good.GoodId.Gold];
                if (!good) {
                    let vo = new GoodVO();
                    vo.propId = Good.GoodId.Gold;
                    vo.amt = 0;
                    good = new Good(vo);
                    ret.goods[Good.GoodId.Gold] = good;
                }
                good.changeAmount(config.Gold);

                if (ret.result && bagLogic.getGood(Good.GoodId.Gold).getAmount() < good.getAmount()) {
                    ret.result = false;
                    ret.message = stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() });
                }
            }

            if (config.Item > 0) {
                let good = ret.goods[Good.GoodId.Dust];
                if (!good) {
                    let vo = new GoodVO();
                    vo.propId = Good.GoodId.Dust;
                    vo.amt = 0;
                    good = new Good(vo);
                    ret.goods[Good.GoodId.Dust] = good;
                }
                good.changeAmount(config.Item);

                if (ret.result && bagLogic.getGood(Good.GoodId.Dust).getAmount() < good.getAmount()) {
                    ret.result = false;
                    ret.message = stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() });
                }
            }

            if (hero.getQuality() > Hero.Quality.Normal) {
                let cost: number[][] = null;
                let career = hero.getCareer();
                if (career == Hero.Career.Powerful) {
                    cost = config.str;
                }
                else if (career == Hero.Career.Intelligent) {
                    cost = config.wis;
                }
                else if (career == Hero.Career.Quick) {
                    cost = config.spd;
                }
                if (cost) {
                    ret.breach = true;
                    for (let item of cost) {
                        let good = ret.goods[item[0]];
                        if (!good) {
                            let vo = new GoodVO();
                            vo.propId = item[0];
                            vo.amt = 0;
                            good = new Good(vo);
                            ret.goods[item[0]] = good;
                        }
                        good.changeAmount(item[1]);

                        if (ret.result && bagLogic.getGood(good.getIndex()).getAmount() < good.getAmount()) {
                            ret.result = false;
                            ret.message = stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() });
                        }
                    }
                }
            }
        }
        for (let key in ret.goods) {
            let good = ret.goods[key];
            ret.consumes.push(() => { bagLogic.changeGoodAmount(good.getIndex(), -good.getAmount()); });
        }

        return ret;
    }

    /**
     * 升级英雄
     * @param hero     
     */
    doUpgradeLevel(hero: PlayerHero, upgradeLevel: number = 1): Property {
        let ret = this.canUpgradeLevel(hero, upgradeLevel);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }
        for (let consume of ret.consumes) {
            consume();
        }

        let property = hero.getProperty();
        hero.setLevel(hero.getLevel(true) + upgradeLevel);

        this.priestsHeroDirty = true;

        let newProperty = hero.getProperty();
        return newProperty.sub(property);
    }

    async requestLevelup(hero: PlayerHero) {
        let req = new HeroLvUpReq();
        req.heroId = hero.getId();
        req.lv = hero.getLevel();
        let proto = await this._gm.request<HeroLvUpVO>(GameProxy.apiherolvUpV2, req);
        hero.updateBase(proto.heroVO);

        if (this.isPriestHero(hero)) {
            await this.doGetEquipAddition();
        }

        let preDust: number = bagLogic.getGood(GoodId.Dust).getAmount();
        let nowDust: number = 0;
        for (let vo of proto.goods) {
            let good = bagLogic.getGood(vo.propId);
            good.setAmount(vo.amt);
        }
        let costDust: number = preDust - bagLogic.getGood(GoodId.Dust).getAmount();
        commitLogic.costDust(costDust, DustCost.levelUp);

        let sevenDayCfg = sevenDaysConfig.find(a => a.type == 4013);
        let progressLevel = activityLogic.getTaskProgress(sevenDayCfg.Id);
        let minLevel: number = 0;
        let maxLevel: number = 0;
        let heroes = this.getShareHeroes();
        let count = Math.min(heroes.length, heroLogic.getPriestsCount());
        for (let i = 0; i < count; i++) {
            let _hero = heroes[i];
            if (minLevel == 0) {
                minLevel = _hero.getLevel();
            } else if (_hero.getLevel() < minLevel) {
                minLevel = _hero.getLevel();
            }
            if (_hero.getLevel() > maxLevel) {
                maxLevel = _hero.getLevel();
            }
        }
        if (this.artifactUnlockInfo) {
            let artifactUnlockCfg = artifactunlockConfig.find(a => a.tasktype == 3005);
            let progress = this.artifactUnlockInfo.getProgress(artifactUnlockCfg.ID);
            if (maxLevel > progress) {
                this.artifactUnlockInfo.addTaskProgress(3005, maxLevel - progress);
            }
            artifactUnlockCfg = artifactunlockConfig.find(a => a.tasktype == 3008);
            progress = this.artifactUnlockInfo.getProgress(artifactUnlockCfg.ID);
            if (minLevel > progressLevel) {
                this.artifactUnlockInfo.addTaskProgress(3008, minLevel - progress);
            }
        }

        activityLogic.doIncTaskActProgress(ActivityType.HeroCultivate, TaskActivityType.LevelUp, hero.getLevel().toString(), 1, true);
    }

    /**判断是否能装备 */
    canEquip(hero: PlayerHero, equip: PlayerEquip): {
        result: boolean,
        message?: string
    } {
        if (hero.getSharePosition() > 0) {
            return {
                result: false,
                message: stringConfigMap.key_level_sharing.Value
            }
        }

        let place = equip.getEquipPlace();
        let equips = bagLogic.getSuitableEquipsForHero(hero, place);
        let heroEquip = hero.getEquip(place);
        if (heroEquip) equips.remove(heroEquip);
        if (equips.indexOf(equip) >= 0) {
            return { result: true }
        }
        return {
            result: false,
            message: stringUtils.getString(stringConfigMap.key_no_equipable_equip.Value,
                { place: stringConfigMap[`key_equip_place_${place}`].Value })
        }
    }

    /*是否能匹配最好的装备 */
    canEquipBest(hero: PlayerHero, place: number): {
        result: boolean,
        message?: string,
        equip?: Equip
    } {
        if (hero.getSharePosition() > 0) {
            return {
                result: false,
                message: stringConfigMap.key_level_sharing.Value
            }
        }

        let equips = bagLogic.getSuitableEquipsForHero(hero, place);
        if (equips.length == 0) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_equipable_equip.Value,
                    { place: stringConfigMap[`key_equip_place_${place}`].Value })
            }
        }

        let equip = hero.getEquip(place);
        equips.sort((a: Equip, b: Equip) => {
            let aTemp = a.clone();
            aTemp.heroId = hero.getId();
            let bTemp = b.clone();
            bTemp.heroId = hero.getId();

            let aPower = aTemp.getPower();
            let bPower = bTemp.getPower();
            if (aPower != bPower) return bPower - aPower;

            let aValue = a == equip ? 1 : 0;
            let bValue = b == equip ? 1 : 0;
            return bValue - aValue;
        });
        for (let e of equips) {
            if (e == equip) {
                break;
            }
            if (!e.getHero()) {
                return {
                    result: true,
                    equip: e
                }
            }
        }

        return {
            result: false,
            message: stringConfigMap.key_best_equip.Value
        }
    }

    get artifactUnlockInfo(): ArtifactUnlockInfo {
        return this._artifactUnlockInfo;
    }

    /**获取神器解锁进度 */
    async doGetArtifactUnlockInfo() {
        let proto = await this._gm.request<Map<number, number>>(GameProxy.apiartifactartifactUnlockInfo, -1);
        this._artifactUnlockInfo = new ArtifactUnlockInfo(proto);
        EManager.emit(EName.onRedDirty, PromptType.ArtifactLevelup);
        EManager.emit(EName.onRedDirty, PromptType.ArtifactEvolution);
    }

    /**解锁神器 */
    async doUnlockArtifact(confId: number) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiartifactartifactUnlock, confId);
        this.doGetArtifactAltarAddition();
        if (proto) {
            let cards = playerLogic.addCards(proto);
            EManager.emit(EName.onActivityBtnFresh, "activity");
            EManager.emit(EName.onRedDirty, PromptType.ArtifactMerge);
            EManager.emit(EName.onUpdateArtifact);
            return cards;
        }
        return [];
    }

    /**升级神器 */
    async doLvupArtifact(goodId: number) {
        let lvUpArtifactReq = new LvUpArtifactReq();
        let goodUseReq = new GoodUseReq();
        goodUseReq.goodsId = goodId;
        let useCnt = this._getUseCnt(goodId);
        goodUseReq.useCount = useCnt;
        lvUpArtifactReq.consume = [goodUseReq];
        let beforeLv = this.artifactUnlockInfo.getLevel();
        let protos = await this._gm.request<StrengArtifactVO[]>(GameProxy.apiartifactlvUpArtifact, lvUpArtifactReq);
        for (let proto of protos) {
            let artifact = bagLogic.getArtifact(proto.artifactInfo.artifactId);
            if (artifact) {
                artifact.update(proto.artifactInfo);
            }
        }
        bagLogic.getGood(goodId).changeAmount(-useCnt);
        this.artifactUnlockInfo.doAddExp(cm.getGoodConfig(goodId).value * useCnt);
        let afterLv = this.artifactUnlockInfo.getLevel();
        if (afterLv > beforeLv) {
            await this.doGetArtifactAltarAddition();
        }
        EManager.emit(EName.onRedDirty, PromptType.ArtifactLevelup);
    }

    protected _getUseCnt(goodId: number) {
        let lvExp = this.artifactUnlockInfo.getLvExp();
        let totalExp = 0;
        let config = artifactlevelConfig;
        for (let levelCfg of config) {
            totalExp += levelCfg.spend;
        }
        let amount = bagLogic.getGood(goodId).getAmount();
        let exp = cm.getGoodConfig(goodId).effect;
        let canUseCnt = 0;
        for (let i = 0; i < amount; i++) {
            let levelLimit = Math.min(config.length - 1, this._getLevel(lvExp + exp));
            let config2 = artifactlevelConfig[levelLimit];
            canUseCnt++;
            if (lvExp + exp > totalExp || config2.playerlevel > playerLogic.getPlayer().getLevel()) {
                break;
            }
            lvExp += exp;
        }
        return canUseCnt;
    }

    protected _getLevel(exp) {
        let lv = 1;
        let totalExp = 0;
        let config = artifactlevelConfig;
        for (let levelCfg of config) {
            totalExp += levelCfg.spend;
            if (totalExp >= exp) {
                lv = levelCfg.Level;
                break;
            }
        }
        return lv;
    }

    /**进阶神器 */
    async doStrengArtifact(artifact: Artifact) {
        let proto = await this._gm.request<StrengArtifactVO>(GameProxy.apiartifactstrengArtifact, artifact.getId());
        bagLogic.getGood(artifact.getConsumeGood().getIndex()).changeAmount(-artifact.getConsumeGood().getAmount());
        let beforeArtifact = artifact.clone();
        artifact.update(proto.artifactInfo);
        if (proto.heroAddInfos) {
            let hero = heroLogic.getHero(proto.heroAddInfos.heroId);
            hero.updateAddition([proto.heroAddInfos]);
        }
        gcc.core.showLayer("prefabs/panel/equip/ArtifactSuccessPanel", { data: { before: beforeArtifact, after: artifact }, modalTouch: true });
        await this.doGetArtifactAltarAddition();
        EManager.emit(EName.onRedDirty, PromptType.ArtifactEvolution);
    }

    /**脱下神器 */
    async doUnequipArtifact(hero: PlayerHero): Promise<Property> {
        if (!hero.getArtifact()) {
            throw new ToastError("no artifact");
        }

        let property = hero.getProperty();
        let proto = await this._gm.request<HeroVO>(GameProxy.apiartifactunArtifact, hero.getId());
        hero.updateBase(proto);
        hero.updateArtifact(proto);
        hero.updateAddition(proto.heroAddInfos);

        let newProperty = hero.getProperty();
        return newProperty.sub(property);
    }

    /**脱下装备 */
    async doUnequip(hero: PlayerHero, places?: number[]): Promise<Property> {
        if (!places) {
            places = [];
            for (let i = 1; i <= Equip.EquipPlace.Num; i++) {
                places.push(i);
            }
        }

        let newPlaces = [];
        for (let place of places) {
            let equip = hero.getEquip(place, true);
            if (equip) {
                newPlaces.push(equip.getEquipPlace());
            }
        }
        if (newPlaces.length == 0) {
            throw new ToastError("no equips");
        }

        let property = hero.getProperty();
        let req = new UnEquipReq();
        req.heroId = hero.getId();
        req.places = newPlaces;
        let proto = await this._gm.request<HeroVO>(GameProxy.apiequipunEquip, req);
        hero.updateBase(proto);
        hero.updateEquips(proto.equips);
        hero.updateAddition(proto.heroAddInfos);

        if (this.isPriestHero(hero)) {
            await this.doGetEquipAddition();
        }

        let newProperty = hero.getProperty();
        return newProperty.sub(property);
    }

    protected async _askInheritEquip(curEquip: Equip, replaceEquip: Equip): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this._gm.inheritDialog(curEquip, replaceEquip, () => { resolve(true) }, () => { resolve(false) });
        });
    }

    protected async _doInheritEquip(origin: Equip, dst: Equip) {
        let req = new EquipInheritReq();
        req.fstEquipId = origin.getId();
        req.secEquipId = dst.getId();
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiequipinheritEquips, req);
        if (proto.extra) {
            let equipBos = proto.extra[0] as EquipBO[];
            if (equipBos) {
                for (let bo of equipBos) {
                    let equip = bagLogic.getEquip(bo.equipId);
                    if (equip) { equip.update(bo); }
                }
            }

            let heroVos = proto.extra[1] as HeroVO[];
            if (heroVos) {
                for (let vo of heroVos) {
                    let hero = this.getHero(vo.heroId);
                    if (hero) { hero.update(vo, false); }
                }
            }
        }
        this._gm.getReward(proto, true);
    }

    /**装配装备或神器 */
    async doEquip(hero: PlayerHero, equip: PlayerEquip | PlayerArtifact): Promise<Property> {
        if (equip.getType() == Card.Type.Equip) {
            let ret = this.canEquip(hero, equip as PlayerEquip);
            if (!ret.result) {
                throw new ToastError(ret.message);
            }
        }

        let property = hero.getProperty();
        let heroEquip = equip.getType() == Card.Type.Equip ? hero.getEquip(equip.getEquipPlace()) : hero.getArtifact();
        if (heroEquip && heroEquip.getType() == Card.Type.Equip) {
            let e = equip as PlayerEquip;
            if (heroEquip.isTrained() && !e.isTrained()) {
                do {
                    if (e.getMaxStar() == 0 && e.getLevel() == heroEquip.getLevel()) {
                        break;
                    }
                    if (e.getMaxCharingLv() == 0 && e.getLevel() == heroEquip.getLevel()) {
                        break;
                    }
                    let ret = await this._askInheritEquip(heroEquip, equip);
                    if (ret) {
                        await this._doInheritEquip(heroEquip, equip);
                    }
                } while (false);
            }
        }

        let otherHero = equip.getHero();
        let protos: HeroVO[] = [];
        if (heroEquip && otherHero) {
            if (equip.getType() == Card.Type.Equip) {
                let req = new EquipChangeReq();
                req.fstEquipId = heroEquip.getId();
                req.fstHeroId = hero.getId();
                req.secEquipId = equip.getId();
                req.secHeroId = otherHero.getId();
                protos = await this._gm.request<HeroVO[]>(GameProxy.apiequipchangeEquips, req);
            }
            else {
                let req = new ChangeArtifactReq();
                req.fstArtifactId = heroEquip.getId();
                req.fstHeroId = hero.getId();
                req.secArtifactId = equip.getId();
                req.secHeroId = otherHero.getId();
                protos = await this._gm.request<HeroVO[]>(GameProxy.apiartifactchangeArtifact, req);
            }
        }
        else {
            if (equip.getType() == Card.Type.Equip) {
                let req = new WearEquipReq();
                req.heroId = hero.getId();
                req.equipIds = [equip.getId()];
                protos = await this._gm.request<HeroVO[]>(GameProxy.apiequipwearEquips, req);
            }
            else {
                let req = new WearArtifactReq();
                req.artifactId = equip.getId();
                req.heroId = hero.getId();
                protos = await this._gm.request<HeroVO[]>(GameProxy.apiartifactwearArtifact, req);
            }
        }

        if (this.isPriestHero(hero)) {
            await this.doGetEquipAddition();
        }

        for (let proto of protos) {
            let newHero = this.getHero(proto.heroId);
            if (newHero) {
                newHero.updateBase(proto);
                if (equip.getType() == Card.Type.Equip) {
                    newHero.updateEquips(proto.equips);
                }
                else {
                    newHero.updateArtifact(proto);
                }
                newHero.updateAddition(proto.heroAddInfos);
            }
        }

        let newProperty = hero.getProperty();
        return newProperty.sub(property);
    }

    /**一键装备 */
    async doEquipAll(hero: PlayerHero): Promise<Property> {
        if (hero.getSharePosition() > 0) {
            throw new ToastError(stringConfigMap.key_level_sharing.Value);
        }

        let result = false;
        let messages = [];
        for (let i = 1; i <= Equip.EquipPlace.Num; i++) {
            let ret = this.canEquipBest(hero, i);
            if (ret.result) {
                result = true;
                break;
            }
            else {
                messages.push(ret.message);
            }
        }
        if (!result) {
            if (hero.getEquips().length == 0) {
                throw new ToastError(stringConfigMap.key_no_suit_equip.Value);
            } else {
                throw new ToastError(messages[0]);
            }
        }



        let property = hero.getProperty();
        let proto = await this._gm.request<HeroVO>(GameProxy.apiequipwearBestEquips, hero.getId());
        hero.updateBase(proto);
        hero.updateEquips(proto.equips);
        hero.updateAddition(proto.heroAddInfos);

        if (this.isPriestHero(hero)) {
            await this.doGetEquipAddition();
        }

        let newProperty = hero.getProperty();
        return newProperty.sub(property);
    }

    /**一键强化装备 */
    async doStrongEquipAll(hero: PlayerHero) {
        let equips = hero.getEquips(true);
        if (equips.length == 0) {
            throw new ToastError(stringUtils.getString(stringConfigMap.key_no_equip.Value, { name: '' }));
        }

        let num: number = equips.length;
        let result = this._getEquipOneKeyStrongInfo(hero);
        let resultLevel = result.level;
        if (result.cost == 0) {
            throw new ToastError('所有装备已强化到最高级');
        } else if (result.cost < 0) {
            throw new ToastError('金币不足');
        }
        // 提交升级
        for (let i = 0; i < num; i++) {
            if (resultLevel[i]) {
                let equip = equips[i];
                bagLogic.doStrongEquip(equip, resultLevel[i]);
                await bagLogic.requestEquipLvUp(equip);
            }
        }
        bagLogic.getGood(GoodId.Gold).changeAmount(-result.cost);
    }

    protected _getEquipOneKeyStrongInfo(hero: PlayerHero) {
        let equips = hero.getEquips(true);
        let num = equips.length;
        let minLevel: number = 0;
        for (let i = 0; i < num; i++) {
            if (equips[i]) {
                let lv = equips[i].getLevel();
                if (minLevel == 0) { minLevel = lv; }
                if (lv < minLevel) { minLevel = lv; }
            }
        }

        let goldLess: boolean = false;
        let needGold: number = 0;
        let hasGold: number = bagLogic.getGood(GoodId.Gold).getAmount();
        let resultLevel: number[] = equips.map((v, i, a) => { return 0; });

        // 升级到能升到的最高等级
        let masterLv: number = hero.getEquipStrongMasters().length + 1;
        let maxMasterLv: number = equipstrengmasterconfig.length;
        for (let a = masterLv; a <= maxMasterLv; a++) {
            let nextEquipLv = this._getStrongMasterEquipLevel(a);
            let loop = nextEquipLv - minLevel;
            for (let j = 0; j < loop; j++) {
                let canUpgrade: boolean = false;
                for (let i = 0; i < num; i++) {
                    let lv: number = equips[i].getLevel() + resultLevel[i] + 1;
                    if (lv > equips[i].getMaxLevel() || lv > nextEquipLv) { continue; }
                    let cost: number = bagLogic.getEquipUpgradeConsumeGold(lv, lv + 1);
                    if (hasGold < needGold + cost) { goldLess = needGold == 0; break; }
                    needGold += cost;
                    resultLevel[i] += 1;
                    canUpgrade = true;
                }
                if (!canUpgrade) { break; }
            }
        }

        needGold = goldLess ? -1 : needGold;
        return { level: resultLevel, cost: needGold, message: '' };
    }

    // 获取强化大师等级对应的 所有装备需要达到的强化等级
    protected _getStrongMasterEquipLevel(masterLv: number) {
        if (masterLv == 0) { return 0; }
        if (masterLv >= equipstrengmasterconfig.length) { masterLv = equipstrengmasterconfig.length; }
        return equipstrengmasterconfig[masterLv - 1].equiplevel;
    }

    /**是否能升星*/
    canStar(hero: PlayerHero): {
        result: boolean,
        message?: string,
        consumeHeroes?: any[],
        autoConsumeHeroes?: any[],
        heroMaterial: HeroMaterial[],
    } {
        let heroMaterial: HeroMaterial[] = [];
        let heroes = [];
        let autoConsumeHeroes = [];
        let config = hero.getStarConfig(true);

        if (!config) {
            return {
                result: false,
                message: stringConfigMap.key_cannot_star.Value,
                consumeHeroes: [],
                autoConsumeHeroes: [],
                heroMaterial: heroMaterial
            }
        }

        let heroRank = hero.getQuality() == Hero.Quality.Eternal ? config.URHeroRank : config.HeroRank;
        let heroNumber = hero.getQuality() == Hero.Quality.Eternal ? config.URHeroNumber : config.HeroNumber;

        let _heroes = this.getHeroes();
        if (config.HeroType == Hero.EvolutionType.SameId) {
            _heroes = _heroes.filter((h: Hero) => {
                return h != hero
                    && !h.isLock()
                    && h.getQuality() > 2
                    && h.getIndex() == hero.getIndex()
                    && h.getRank(true) == heroRank
            });
            heroes.push(_heroes);
        } else if (config.HeroType == Hero.EvolutionType.SameFaction) {
            _heroes = _heroes.filter((h: Hero) => {
                return h != hero
                    && !h.isLock()
                    && h.getQuality() > 2
                    && h.getFaction() == hero.getFaction()
                    && h.getRank(true) == heroRank
            });
            heroes.push(_heroes);
        }

        let material = new HeroMaterial();
        material.type = config.HeroType;
        material.rank = heroRank;
        material.cnt = heroNumber;
        heroMaterial.push(material);

        _heroes.sort((a: Hero, b: Hero) => {
            let aRank = a.getRank(true);
            let bRank = b.getRank(true);
            if (aRank != bRank) return aRank - bRank;

            let aStar = a.getStar();
            let bStar = b.getStar();
            if (aStar != bStar) return aStar - bStar;

            let aLevel = a.getLevel();
            let bLevel = b.getLevel();
            if (aLevel != bLevel) return aLevel - bLevel;

            return a.getIndex() - b.getIndex();
        });

        autoConsumeHeroes.push(_heroes.slice(0, material.cnt));

        if (config.goodsnumber && bagLogic.getGood(config.goodsnumber[0]).getAmount() < config.goodsnumber[1]) {
            return {
                result: false,
                message: stringConfigMap.key_exchange_no_good.Value,
                consumeHeroes: heroes,
                autoConsumeHeroes: autoConsumeHeroes,
                heroMaterial: heroMaterial
            }
        }

        if (!hero.canStar()) {
            return {
                result: false,
                message: stringConfigMap.key_cannot_star.Value,
                consumeHeroes: heroes,
                autoConsumeHeroes: autoConsumeHeroes,
                heroMaterial: heroMaterial
            }
        }

        if (hero.getLevel() < hero.getStarLevelLimit()) {
            return {
                result: false,
                message: stringConfigMap.key_star_level_limit.Value,
                consumeHeroes: heroes,
                autoConsumeHeroes: autoConsumeHeroes,
                heroMaterial: heroMaterial
            }
        }

        return {
            result: _heroes.length >= config.HeroNumber,
            consumeHeroes: heroes,
            autoConsumeHeroes: autoConsumeHeroes,
            heroMaterial: heroMaterial
        }
    }

    /**是否能合成*/
    canMerge(hero: PlayerHero): {
        result: boolean,
        message?: string,
        consumeHeroes?: any[],
        heroMaterial: HeroMaterial[],
    } {
        let config = cm.getHeroCompoundConfig(hero.getIndex());
        let material = config.HeroSpend;
        let heroes = [];
        let heroMaterial: HeroMaterial[] = [];
        let allHeroes = this.getHeroes();
        for (let spend of material) {
            let heroId = spend[0];
            let heroLevel = spend[1];
            let heroRank = spend[2];
            let heroStar = spend[3] ? spend[3] : 0;
            let _hero = allHeroes.find(a => heroes.indexOf(a) == -1 && a.getIndex() == heroId && a.getLevel() >= heroLevel && a.getRank(true) >= heroRank && a.getStar() >= heroStar);
            if (!_hero) {
                return {
                    result: false,
                    message: stringConfigMap.key_merge_no_material.Value,
                    heroMaterial: []
                }
            }
            heroes.push([_hero]);
            let material = new HeroMaterial();
            heroMaterial.push(material);
        }
        return {
            result: true,
            consumeHeroes: heroes,
            heroMaterial: heroMaterial,
        }
    }

    /**是否能进阶 */
    canEvolution(hero: PlayerHero, excludeHeros?: PlayerHero[], excludeIndexs: string[] = [], v2?: boolean, needAuto: boolean = true): {
        result: boolean,
        autoResult: boolean,
        message?: string,
        consumeHeroes?: any[],        //可选择的英雄
        autoConsumeHeroes?: any[],    //自动选择的英雄
        heroMaterial: HeroMaterial[],
    } {
        let excludeSet = new Set<Hero>(excludeHeros);
        let config = heroRankConfig[hero.getRank(true) - 1];
        let heroes = [];
        let autoConsumeHeroes = [];
        let heroMaterial = [];
        if (v2) {
            heroMaterial = heroUtils.getEvolutionInfo3(hero);
        } else {
            heroMaterial = heroUtils.getEvolutionInfo2(hero);
        }
        let result = heroMaterial.length > 0;
        let autoResult = result;
        let index = 0;
        let needCnt = 0;
        for (let material of heroMaterial) {
            let type = material.type;
            let rank = material.rank;
            let _heroes: Hero[] = [];
            needCnt += material.cnt;
            if (excludeIndexs.indexOf(index.toString()) == -1) {
                if (type == Hero.EvolutionType.SameId) {
                    _heroes = this.getHeroesByIndex(hero.getIndex());
                } else if (type == Hero.EvolutionType.SameFaction) {
                    _heroes = this.getHeroesByFaction(hero.getFaction());
                } else if (type == Hero.EvolutionType.AllFaction) {
                    _heroes = this.getHeroes();
                }
                _heroes = _heroes.filter((h: Hero) => {
                    return h != hero && !h.isLock() && h.getRank(true) == rank && !excludeSet.has(h) && !this._existHero(autoConsumeHeroes, h);
                });
            }
            heroes.push(_heroes);
            if (_heroes.length < material.cnt) {
                result = false;
            }
            if (needAuto) {
                _heroes.sort((a: Hero, b: Hero) => {
                    let aLevel = a.getLevel();
                    let bLevel = b.getLevel();
                    if (aLevel != bLevel) return aLevel - bLevel;

                    let aRank = a.getRank(true);
                    let bRank = b.getRank(true);
                    if (aRank != bRank) return aRank - bRank;

                    return a.getIndex() - b.getIndex();
                });
                let firstHero = _heroes[0];
                let consumeHeroes = _heroes.where(a => a.getRank(true) == firstHero.getRank(true) && a.getLevel() == 1 && a.getStar() == 0);
                if (consumeHeroes.length > material.cnt) {
                    //随机英雄作为材料
                    let autoHeroes = [];
                    for (let i = 0; i < material.cnt; i++) {
                        let hero = heroUtils.getRandomHero(consumeHeroes, autoHeroes);
                        if (hero) {
                            autoHeroes.push(hero);
                        }
                    }
                    autoConsumeHeroes.push(autoHeroes);
                } else {
                    let canAutoHeroes = _heroes.filter((h: Hero) => {
                        return h.getLevel() == 1 && h.getStar() == 0
                    });
                    autoResult = canAutoHeroes.length >= material.cnt;
                    autoConsumeHeroes.push(canAutoHeroes.slice(0, material.cnt));
                }
            }
        }

        if (hero.getRank(true) == hero.getRankUpperLimited()) {
            return {
                result: false,
                autoResult: autoResult,
                message: stringConfigMap.key_rank_limited.Value,
                consumeHeroes: heroes,
                autoConsumeHeroes: autoConsumeHeroes,
                heroMaterial: heroMaterial
            };
        }

        if (hero.getStarUpperLimit() > 0 && hero.getStar() < config.star) {
            return {
                result: false,
                autoResult: autoResult,
                message: stringConfigMap.key_star_not_reach.Value,
                consumeHeroes: heroes,
                autoConsumeHeroes: autoConsumeHeroes,
                heroMaterial: heroMaterial
            }
        }

        let heroSet = new Set<Hero>([]);
        for (let _heroes of heroes) {
            for (let _hero of _heroes) {
                heroSet.add(_hero);
            }
        }
        if (heroes.length < heroMaterial.length || heroSet.size < needCnt) {
            return {
                result: false,
                autoResult: autoResult,
                message: stringConfigMap.key_no_enough_evolution_heroes.Value,
                consumeHeroes: heroes,
                autoConsumeHeroes: autoConsumeHeroes,
                heroMaterial: heroMaterial
            }
        }

        return {
            result: result,
            autoResult: autoResult,
            consumeHeroes: heroes,
            autoConsumeHeroes: autoConsumeHeroes,
            heroMaterial: heroMaterial
        }
    }

    /**检测材料英雄是否在共享中*/
    checkConsumeHeroes(consumeHeroes: Hero[]) {
        let heroNames = "";
        for (let hero of consumeHeroes) {
            if (hero.getSharePosition() > 0) {
                if (heroNames != "") {
                    heroNames += "、";
                }
                heroNames += hero.getName();
            }
        }
        return heroNames;
    }

    protected _existHero(heroes, hero) {
        for (let _heroes of heroes) {
            for (let _h of _heroes) {
                if (_h == hero) {
                    return true;
                }
            }
        }
        return false;
    }

    /**执行一键进化 */
    async doAllEvolution(heroes: any[]) {
        let reqs = [];
        for (let _hero of heroes) {
            let hero = _hero.hero;
            let consumeHeroes = _hero.consumeHeros;
            let req = new RankUpHeroReq();
            req.heroId = hero.getId();
            req.consumeIds = [];
            for (let h of consumeHeroes) {
                req.consumeIds.push(h.getId());
            }
            reqs.push(req);
        }
        let proto = await this._gm.request<HeroVO[]>(GameProxy.apiherorankUpBatch, reqs);
        EManager.emit(EName.onBeforeEvoluteHeroes, heroes);
        for (let _hero of heroes) {
            let hero = _hero.hero;
            let consumeHeroes = _hero.consumeHeros;
            this._updateEvolutionHero(hero, proto.find(a => a.heroId == hero.getId()), consumeHeroes);
        }
        EManager.emit(EName.onEvoluteHeroes, heroes);

        await this.doGetEquipAddition();
    }

    /**执行升星 */
    async doStar(hero: PlayerHero, consumeHeroes: PlayerHero[]) {
        let req = new RankUpHeroReq();
        req.heroId = hero.getId();
        req.consumeIds = [];
        for (let h of consumeHeroes) {
            req.consumeIds.push(h.getId());
        }
        let config = hero.getStarConfig(true);
        let proto = await this._gm.request<HeroVO[]>(GameProxy.apiherostarUpBatch, [req]);
        hero.updateBase(proto[0]);

        if (config && config.goodsnumber != null) {
            bagLogic.getGood(config.goodsnumber[0]).changeAmount(-config.goodsnumber[1]);
        }

        for (let h of consumeHeroes) {
            this.doRevert(h, this.getResetCards);
        }

        for (let h of consumeHeroes) {
            this.removeHeroes([h.getId()]);
        }
        EManager.emit(EName.onStarHeroes, [hero]);

        activityLogic.doIncTaskActProgress(ActivityType.HeroCultivate, TaskActivityType.StarHero, hero.getStar().toString(), 1, true);
    }

    /**执行合成 */
    async doMerge(hero: PlayerHero, consumeHeroes: PlayerHero[]) {
        let req = new RankUpHeroReq();
        let config = cm.getHeroCompoundConfig(hero.getIndex());
        let mainHero = consumeHeroes.find(a => a.getIndex() == config.HeroSpend[0][0]);
        req.heroId = config.ID.toString();
        req.consumeIds = [];
        for (let h of consumeHeroes) {
            req.consumeIds.push(h.getId());
        }
        let proto = await this._gm.request<HeroVO[]>(GameProxy.apiherocompoundBatch, [req]);
        let playerHero = new PlayerHero(proto[0]);
        this.addHeroes([playerHero]);

        for (let h of consumeHeroes) {
            this.doRevert(h, this.getResetCards);
        }

        this.doClearHerosEquip([mainHero]);

        for (let h of consumeHeroes) {
            this.removeHeroes([h.getId()]);
        }
        EManager.emit(EName.onMergeHeroes, [hero]);
    }

    /**执行进化 */
    async doEvolution(hero: PlayerHero, consumeHeroes: PlayerHero[]) {
        if (hero.getSharePosition() > 0) {
            throw new ToastError(stringConfigMap.key_level_sharing.Value);
        }

        // let config = heroRankConfig[hero.getRank() - 1];
        // if (consumeHeroes.length < (hero.getFaction() <= 4 ? config.Counts : config.SpecialCounts)) {
        //     throw new ToastError(stringConfigMap.key_no_enough_evolution_heroes.Value);
        // }

        let req = new RankUpHeroReq();
        req.heroId = hero.getId();
        req.consumeIds = [];
        for (let h of consumeHeroes) {
            req.consumeIds.push(h.getId());
        }
        let proto = await this._gm.request<HeroVO>(GameProxy.apiherorankUp, req);
        EManager.emit(EName.onBeforeEvoluteHeroes, [hero]);
        this._updateEvolutionHero(hero, proto, consumeHeroes);
        EManager.emit(EName.onEvoluteHeroes, [hero]);

        await this.doGetEquipAddition();
    }

    /**回退英雄需要的钻石 */
    getRollbackHeroDiamond(): number {
        return defaultConfigMap.heroresolve.value;
    }

    /**能否回退英雄 */
    canRollbackHero(hero: PlayerHero): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        if (!hero.canRollback()) {
            return {
                result: false,
                message: stringConfigMap.key_no_need_rollback_hero.Value
            }
        }

        let consumes = [];
        let good = bagLogic.getGood(Good.GoodId.Diamond);
        if (good.getAmount() < this.getRollbackHeroDiamond()) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(Good.GoodId.Diamond, -this.getRollbackHeroDiamond());
                commitLogic.costDiamond(this.getRollbackHeroDiamond(), DiamondCost.rollbackHero);
            });
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**回退后返还物品预览 */
    async doGetRollbackPreview(hero: PlayerHero): Promise<Card[]> {
        let cards: Card[] = [];
        let protos = await this._gm.request<RewardBO[]>(GameProxy.apiherobackPre, hero.getId(), GameProxy, true);

        let newHero = hero.clone();
        newHero.resetLevel();
        newHero.resetStar();
        newHero.resetRank();
        cards.push(newHero);

        for (let proto of protos) {
            let card = commonUtils.reward2Card(proto);
            if (card) { cards.push(card); }
        }
        cards.pushList(hero.getEquips(true));
        this.doClearHerosEquip([hero]);

        return cards;
    }

    /**重置英雄 */
    async doRollbackHero(hero: PlayerHero): Promise<Card[]> {
        let ret = this.canRollbackHero(hero);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let equips = hero.getEquips(true);

        let proto = await this._gm.request<ResourceVO>(GameProxy.apiheroback, hero.getId());
        hero.update(proto.extra[0] as HeroVO);

        let cards = playerLogic.addCards(proto);
        cards.pushList(equips);
        cards.unshift(hero);

        this.doClearHerosEquip([hero]);

        for (let consume of ret.consumes) {
            consume();
        }

        let heroes = this.getShareHeroes();
        let count = Math.min(this.getPriestsCount(), heroes.length);
        for (let i = 0; i < count; i++) {
            if (hero == heroes[i]) {
                this.priestsHeroDirty = true;
                break;
            }
        }

        await this.doGetEquipAddition();

        return cards;
    }

    /**重置英雄需要的钻石 */
    getResetHeroDiamond(): number {
        return defaultConfigMap.heroreset.value;
    }

    /**能否重置英雄 */
    canResetHero(hero: PlayerHero): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        if (!hero.canReset()) {
            return {
                result: false,
                message: stringConfigMap.key_no_need_reset_hero.Value
            }
        }

        let consumes = [];
        let good = bagLogic.getGood(Good.GoodId.Diamond);
        if (good.getAmount() < this.getResetHeroDiamond()) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(Good.GoodId.Diamond, -this.getResetHeroDiamond());
                commitLogic.costDiamond(this.getResetHeroDiamond(), DiamondCost.resetHero);
            });
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**重置后返还物品预览 */
    async doGetResetPreview(hero: PlayerHero): Promise<Card[]> {
        let cards: Card[] = [];
        let protos = await this._gm.request<RewardBO[]>(GameProxy.apiheroresetPre, hero.getId(), GameProxy, true);

        let newHero = hero.clone();
        newHero.resetLevel();
        newHero.resetStar();
        cards.push(newHero);

        for (let proto of protos) {
            let card = commonUtils.reward2Card(proto);
            if (card) { cards.push(card); }
        }
        cards.pushList(hero.getEquips(true));
        this.doClearHerosEquip([hero]);

        return cards;
    }

    /**重置英雄 */
    async doResetHero(hero: PlayerHero): Promise<Card[]> {
        let ret = this.canResetHero(hero);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let equips = hero.getEquips(true);

        let proto = await this._gm.request<ResourceVO>(GameProxy.apiheroreset, hero.getId());
        hero.update(proto.extra[0] as HeroVO);

        let cards = playerLogic.addCards(proto);
        cards.pushList(equips);
        cards.unshift(hero);

        this.doClearHerosEquip([hero]);

        for (let consume of ret.consumes) {
            consume();
        }

        let heroes = this.getShareHeroes();
        let count = Math.min(this.getPriestsCount(), heroes.length);
        for (let i = 0; i < count; i++) {
            if (hero == heroes[i]) {
                this.priestsHeroDirty = true;
                break;
            }
        }

        await this.doGetEquipAddition();

        return cards;
    }

    /**遣散英雄 */
    async doSplitHeroes(heroes: PlayerHero[]): Promise<Card[]> {
        let ids = [];
        for (let hero of heroes) {
            ids.push(hero.getId());
        }
        await this._gm.request<boolean>(GameProxy.apiherodemobHero, ids);
        await this.doGetEquipAddition();
        this.removeHeroes(ids);

        let cards = this.getSplitAllCards(heroes);
        for (let hero of heroes) {
            this.doRevert(hero, this.getSplitCards);
        }
        return cards;
    }

    /**返还升级消耗的资源及绑定的装备 */
    doRevert(hero: PlayerHero, getCardsFunc: Function) {
        let cards = getCardsFunc.call(this, hero);
        for (let card of cards) {
            if (card.getType() == Card.Type.Good) {
                bagLogic.addGood(card as Good);
            }
        }

        this.doClearHerosEquip([hero]);
        hero.resetLevel();

        let heroes = this.getShareHeroes();
        let count = Math.min(this.getPriestsCount(), heroes.length);
        for (let i = 0; i < count; i++) {
            if (hero == heroes[i]) {
                this.priestsHeroDirty = true;
                break;
            }
        }
    }

    doClearHerosEquip(heros: PlayerHero[]) {
        for (let hero of heros) {
            let equips = hero.getEquips(true);
            for (let equip of equips) {
                equip.clearHero();
            }
            hero.updateEquips
            hero.resetEquips();

            let artifact = hero.getArtifact();
            if (artifact) {
                artifact.clearHero();
            }
            hero.resetArtifact();
        }
    }

    doRevertCards(cards: Card[]) {
        let equips = []
        for (let card of cards) {
            if (card.getType() == Card.Type.Good) {
                bagLogic.addGood(card as Good);
            } else if (card.getType() == Card.Type.Equip) {
                equips.push(card as Equip);
            }
        }
        if (equips.length > 0) {
            bagLogic.addEquips(equips);
        }
    }

    getSplitAllCards(heroes: PlayerHero[], resolve: boolean = true): Card[] {
        let equips: Equip[] = [];
        let goods: { [key: number]: Good } = {};
        for (let hero of heroes) {
            let cards = this.getSplitCards(hero, resolve);
            for (let card of cards) {
                if (card.getType() == Card.Type.Good) {
                    let good = card as Good;
                    if (goods[good.getIndex()]) {
                        goods[good.getIndex()].setAmount(goods[good.getIndex()].getAmount() + good.getAmount());
                    }
                    else {
                        goods[good.getIndex()] = good;
                    }
                }
                else {
                    equips.push(card as Equip);
                }
            }
        }

        let allCards = [];
        allCards.pushList(equips);
        allCards.pushList(Object.values(goods));
        allCards.sort((a: Card, b: Card) => { return a.getRenderOrder() - b.getRenderOrder() });

        return allCards;
    }

    getSplitEquips(hero: PlayerHero): Card[] {
        let equips: Equip[] = [];
        let cards = this.getSplitCards(hero, false);
        for (let card of cards) {
            if (card.getType() != Card.Type.Good) {
                equips.push(card as Equip)
            }
        }
        return equips;
    }

    /**获取重置后的资源 */
    getSplitCards(hero: PlayerHero, resolve: boolean = true): Card[] {
        let cards = this.getResetCards(hero);
        for (let i = 0; i < cards.length; i++) {
            if (cards[i].getType() == Card.Type.Hero) {
                cards.splice(i, 1);
                break;
            }
        }

        if (resolve) {
            let goodVO = new GoodVO();
            goodVO.amt = defaultConfigMap.resolveHeroDust.value;
            goodVO.propId = Good.GoodId.Dust;
            cards.push(new Good(goodVO));

            goodVO = new GoodVO();
            goodVO.amt = defaultConfigMap.resolveHeroCoin.value;
            goodVO.propId = Good.GoodId.HeroCoin;
            cards.push(new Good(goodVO));
        }

        return cards;
    }

    /**获取重置后的资源 */
    getResetCards(hero: PlayerHero): Card[] {
        let cards: Card[] = [];

        let heroCopy = hero.clone();
        heroCopy.resetLevel();
        heroCopy.setSharePosition(0);
        cards.push(heroCopy);

        for (let equip of hero.getEquips()) {
            //排除继承中装备
            if (equip.getHero() == hero) {
                cards.push(equip);
            }
        }
        if (hero.getArtifact()) { cards.push(hero.getArtifact()); }

        let ret = this.canUpgradeLevel(heroCopy, hero.getLevel(true) - heroCopy.getLevel(true));
        cards.pushList(Object.values(ret.goods));
        cards.sort((a: Card, b: Card) => { return a.getRenderOrder() - b.getRenderOrder() });
        return cards;
    }

    async doUpdateShareHeroes(param: { hero: PlayerHero, position: number }) {
        if (param.hero.getSharePosition() == param.position) {
            return;
        }

        let req = new UpdateFlowerReq();
        req.heroId = param.hero.getId();
        req.position = param.position;
        let proto = await this._gm.request<HeroVO>(GameProxy.apiheroupdateFlowerPlace, req);
        await this.doGetEquipAddition();
        param.hero.update(proto);
    }

    async doToggleHeroLock(hero: PlayerHero) {
        let data = new UpdateLockReq();
        data.heroId = hero.getId();
        data.newStatus = !hero.isLock();
        await this._gm.request<HeroVO>(GameProxy.apiherolock, data);
        hero.setIsLock(!hero.isLock());
    }

    async doUpdateHeroes(heroIndexes: Set<number>) {
        if (heroIndexes.size == 0) return;

        let protos = await this._gm.request<HeroBagVO>(GameProxy.apiherogetTypeHeros, Array.from(heroIndexes));
        playerLogic.getPlayer().setBuyCapacityCost(protos.buyCost);

        let heroProtos = protos.heroes;
        for (let heroProto of heroProtos) {
            let hero = this.getHero(heroProto.heroId);
            if (hero) { hero.updateAddition(heroProto.heroAddInfos, false); }
        }
        if (heroProtos.length > 0) {
            playerLogic.getPlayer().setPowerDirty();
        }
    }

    canBuyFlowerSlot(): { result: boolean, message?: string, consumes?: Function[] } {
        let diamonds = cm.defaultFlowerUnlockDiamond;
        let diamond = diamonds[Math.min(this.buySlotCount, diamonds.length - 1)];
        let good = bagLogic.getGood(Good.GoodId.Diamond);
        let consumes = [];
        if (good.getAmount() < diamond) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(Good.GoodId.Diamond, -diamond);
                commitLogic.costDiamond(diamond, DiamondCost.flowerSlot);
            })
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    async doBuyFlowerSlot() {
        let ret = this.canBuyFlowerSlot();
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let proto = await this._gm.request<FlowerPlaceInfoVO>(GameProxy.apiherobuyFlowerPlace);
        this.unlockSlotCount = proto.nowCount;
        this.buySlotCount = proto.nowBuy;

        for (let consume of ret.consumes) {
            consume();
        }
    }

    async doUpdateGenius(heroConfId: number) {
        let req = new TalentReq();
        req.heroConfId = heroConfId;
        let proto = await this._gm.request<TalentInfoVO>(GameProxy.apitalentgetTalentInfo, req);
        this._updateGeniusInfo(heroConfId, proto);
    }

    canActiveGenius(heroConfId: number, confId: number = 0): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        let consumes: Function[] = [];
        let geniusPoints = this.getGeniusPoints(heroConfId);
        if (confId == 0) {
            if (geniusPoints[GeniusPointType.Normal] < defaultConfigMap.geniusbegin.value) {
                return {
                    result: false,
                    message: stringUtils.getString(stringConfigMap.key_genius_point_not_enough.Value, {
                        name: stringConfigMap[`key_genius_point${GeniusPointType.Normal}`].Value
                    })
                }
            }
        }
        else {
            let config = cm.getGeniusConfig(confId);
            for (let i = 0; i < 3; i++) {
                if (geniusPoints[i] < config[`Lvconsume${i + 1}`]) {
                    return {
                        result: false,
                        message: stringUtils.getString(stringConfigMap.key_genius_point_not_enough.Value, {
                            name: stringConfigMap[`key_genius_point${i}`].Value
                        })
                    }
                }
            }

            let good = bagLogic.getGood(Good.GoodId.Gold);
            if (good.getAmount() < config.goldnumber) {
                return {
                    result: false,
                    message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
                }
            }
            else {
                consumes.push(() => { bagLogic.changeGoodAmount(Good.GoodId.Gold, -config.goldnumber) });
            }
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**
     * 点亮天赋
     * confId = 0时表示播种
     */
    async doActiveGenius(heroConfId: number, confId: number = 0) {
        let ret = this.canActiveGenius(heroConfId, confId);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let req = new TalentReq();
        req.heroConfId = heroConfId;
        req.gconfId = confId;
        let proto = await this._gm.request<TalentInfoVO>(GameProxy.apitalentopenTalentPoint, req);
        this._updateGeniusInfo(heroConfId, proto);
        for (let consume of ret.consumes) {
            consume();
        }
    }

    canResetGenius(heroConfId: number): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        let consumes: Function[] = [];
        let good = bagLogic.getGood(Good.GoodId.GeniusReset);
        if (good.getAmount() < 1) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => { bagLogic.changeGoodAmount(Good.GoodId.GeniusReset, -1) });
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    /**
     * 重置天赋
     */
    async doResetGenius(heroConfId: number) {
        let ret = this.canResetGenius(heroConfId);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let req = new TalentReq();
        req.heroConfId = heroConfId;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apitalentresetTalent, req);
        let extra = proto.extra as any;

        delete this._geniusAdditions[heroConfId];
        delete this._geniusSkills[heroConfId];

        let vo = new TalentInfoVO();
        vo.remainTPoint = extra[0];
        vo.remainTMPoint = extra[1];
        vo.remainTSPoint = extra[2];
        vo.details = { 0: 1 };
        vo.skillAdd = [];
        this._updateGeniusInfo(heroConfId, vo);

        for (let consume of ret.consumes) {
            consume();
        }
    }

    getGeniusPoints(heroConfId: number): number[] {
        return this._geniusPoints[heroConfId];
    }

    getGeniusFruits(heroConfId: number): {
        fruits: GeniusFruit[],
        active: boolean,
        details: { [key: number]: number }
    } {
        return this._geniusFruits[heroConfId];
    }

    getGeniusConfigs(): { [key: number]: geniusConfigRow[] } {
        return this._geniusConfigs;
    }

    updateGeniusPoints(heroConfId: number, points: number[]) {
        this._geniusPoints[heroConfId] = points;
        EManager.emit(EName.onGeniusPointsDirty, heroConfId);
    }

    protected _updateGeniusInfo(heroConfId: number, proto: TalentInfoVO) {
        if (proto.heroAdd) {
            this._geniusAdditions[proto.heroAdd.heroCofId] = proto.heroAdd;
            this._geniusSkills[proto.heroAdd.heroCofId] = proto.skillAdd;
        }

        this._geniusPoints[heroConfId] = [proto.remainTPoint, proto.remainTMPoint, proto.remainTSPoint];
        this._geniusFruits[heroConfId] = { fruits: [], active: false, details: {} }

        let fruits = this._geniusFruits[heroConfId];
        let heroConfigItem = cm.getHeroConfig(heroConfId);
        let geniusConfigs = this._geniusConfigs[heroConfigItem.Career];
        let details = proto.details as { [key: number]: number };
        fruits.active = details[0] > 0;
        fruits.details = details;

        let configMap: { [key: number]: geniusConfigRow[] } = {};
        for (let config of geniusConfigs) {
            let configs = configMap[config.configId];
            if (!configs) {
                configs = [];
                configMap[config.configId] = configs;
            }
            configs.push(config);
        }

        for (let key in configMap) {
            let fruit = new GeniusFruit(configMap[key], details);
            fruits.fruits.push(fruit);
        }
        fruits.fruits.sort((a: GeniusFruit, b: GeniusFruit) => { return a.type - b.type });

        EManager.emit(EName.onGeniusInfoDirty, heroConfId);
        playerLogic.getPlayer().setPowerDirty();
    }

    protected _commitAddHeroesTask(heroes: PlayerHero[]) {
        let diffFactionSRCnt: number = 0;
        let diffFactionSSRCnt: number = 0;
        let diffFactionURCnt: number = 0;
        for (let hero of heroes) {
            if (this.artifactUnlockInfo) {
                if (hero.getQuality() >= Hero.Quality.Myth) {
                    this.artifactUnlockInfo.addTaskProgress(3014);
                }
                if (hero.getRank() >= Hero.Rank.Myth) {
                    this.artifactUnlockInfo.addTaskProgress(8001);
                }
                if (hero.getRank() >= Hero.Rank.Legend) {
                    this.artifactUnlockInfo.addTaskProgress(8002);
                }
            }

            if (hero.getQuality() == Hero.Quality.Epic) {
                activityLogic.doIncTaskActProgress(ActivityType.UnionRally, TaskActivityType.GetFactionSR, hero.getFaction().toString(), 1, true);
            } else if (hero.getQuality() == Hero.Quality.Myth) {
                activityLogic.doIncTaskActProgress(ActivityType.UnionRally, TaskActivityType.GetFactionSSR, hero.getFaction().toString(), 1, true);
            } else if (hero.getQuality() == Hero.Quality.Eternal) {
                activityLogic.doIncTaskActProgress(ActivityType.UnionRally, TaskActivityType.GetFactionUR, hero.getFaction().toString(), 1, true);
            }

            if (activityLogic.taskActivityCloudData) {
                if (hero.getQuality() == Hero.Quality.Epic) {
                    if (!activityLogic.taskActivityCloudData.checkSR(hero.getIndex())) {
                        activityLogic.doIncTaskActProgress(ActivityType.UnionRally, TaskActivityType.GetDiffFactionSR, hero.getFaction().toString(), 1, true, () => {
                            activityLogic.taskActivityCloudData.addSR(hero.getIndex());
                            diffFactionSRCnt++;
                        });
                    }
                } else if (hero.getQuality() == Hero.Quality.Myth) {
                    if (!activityLogic.taskActivityCloudData.checkSSR(hero.getIndex())) {
                        activityLogic.doIncTaskActProgress(ActivityType.UnionRally, TaskActivityType.GetDiffFactionSSR, hero.getFaction().toString(), 1, true, () => {
                            activityLogic.taskActivityCloudData.addSSR(hero.getIndex());
                            diffFactionSSRCnt++;
                        });
                    }
                } else if (hero.getQuality() == Hero.Quality.Eternal) {
                    if (!activityLogic.taskActivityCloudData.checkUR(hero.getIndex())) {
                        activityLogic.doIncTaskActProgress(ActivityType.UnionRally, TaskActivityType.GetDiffFactionUR, hero.getFaction().toString(), 1, true, () => {
                            activityLogic.taskActivityCloudData.addUR(hero.getIndex());
                            diffFactionURCnt++;
                        });
                    }
                }
            }
            activityLogic.doIncTaskActProgress(ActivityType.UnionRally, TaskActivityType.GetFactionQualityHero, `${hero.getFaction()};${hero.getRank()}`, 1, true);
        }

        if (diffFactionSRCnt > 0 || diffFactionSSRCnt > 0 || diffFactionURCnt > 0) {
            if (activityLogic.taskActivityCloudData) {
                activityLogic.taskActivityCloudData.doPutCloudData(activityLogic.getActivityRemainTime(ActivityType.UnionLottery));
            }
        }
    }

    protected _updateEvolutionHero(hero: PlayerHero, proto: HeroVO, consumeHeroes: PlayerHero[]) {
        hero.updateBase(proto);

        for (let h of consumeHeroes) {
            this.doRevert(h, this.getResetCards);
        }

        for (let h of consumeHeroes) {
            this.removeHeroes([h.getId()]);
        }

        if (hero.getRank() >= Hero.Rank.Epic && hero.getRank() < Hero.Rank.Legend) {
            chatSocket.sendMultiSystemMsg(SystemType.ZLTJ, [hero.getHeroVO()]);
        } else if (hero.getRank() >= Hero.Rank.Legend && hero.getRank() < Hero.Rank.Myth) {
            chatSocket.sendMultiSystemMsg(SystemType.FMLJ, [hero.getHeroVO()]);
        } else if (hero.getRank() >= Hero.Rank.Myth) {
            chatSocket.sendMultiSystemMsg(SystemType.WSWW, [hero.getHeroVO()]);
        }
        heroLogic.artifactUnlockInfo && heroLogic.artifactUnlockInfo.addTaskProgress(3016);

        activityLogic.doIncTaskActProgress(ActivityType.HeroCultivate, TaskActivityType.EvoUp, hero.getRank().toString(), 1, true);

        if (hero.getRank() >= Hero.Rank.Myth) {
            this.artifactUnlockInfo.addTaskProgress(8001);
        }
        if (hero.getRank() >= Hero.Rank.Legend) {
            this.artifactUnlockInfo.addTaskProgress(8002);
        }
    }

    /**获取皮肤 */
    async doGetSkin() {
        let proto = await this._gm.request<SkinBO[]>(GameProxy.apiskingetSkins, null);
        if (proto) {
            this._skins = [];
            for (let skin of proto) {
                this._skins.push(skin.skinCofId);
            }
        }
    }

    /**获取皮肤加成信息*/
    async doGetSkinAddition() {
        let proto = await this._gm.request<TalentAddVO[]>(GameProxy.apiherogetHeroSkinAdd, null);
        if (proto) {
            this._updateSkinAddition(proto);
        }
    }

    /**穿戴皮肤 */
    async doWearSkin(hero: PlayerHero, skinId: number) {
        let req = new WearSkinReq();
        req.heroId = hero.getId();
        req.skinId = skinId;
        let proto = await this._gm.request<boolean>(GameProxy.apiskinwearSkin, req);
        if (proto) {
            hero.setSkin(skinId);
        }
    }

    /**碎片兑换皮肤*/
    async doExchangeSkin(skinId: number) {
        let req = new WearSkinReq();
        req.skinId = skinId;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiskinexchangeSkin, req);
        if (proto) {
            this._skins.push(skinId);
            gm.getReward(proto);
            let piece = cm.getHeroSkinConfig(skinId).Price;
            bagLogic.getGood(GoodId.SkinFragment).changeAmount(-piece);
            this.doGetSkinAddition();
        }
    }

    doBuySkin(skinId: number) {
        if (skinId > 0 && this._skins.indexOf(skinId) == -1) {
            this._skins.push(skinId);
        }
    }

    /**获取共享花坛装备加成 */
    async doGetEquipAddition() {
        let protos = await this._gm.request<FlowerEquipItemBO[]>(GameProxy.apiherogetFlowerEquipAdd, undefined, GameProxy, true);
        this._updateEquipAddition(protos);
    }

    /**更新共享花坛装备加成 */
    protected _updateEquipAddition(protos: FlowerEquipItemBO[]) {
        this._equipAdditions = {};
        this._equipShares = {};

        for (let proto of protos) {
            if (proto.heroModulBO) {
                this._equipAdditions[proto.heroId] = proto.heroModulBO;
                this._equipShares[proto.heroId] = proto.equipIds;
            }
        }
    }

    /**皮肤加成*/
    protected _updateSkinAddition(skinAdd: TalentAddVO[]) {
        this._skinAdditions = [];
        for (let add of skinAdd) {
            if (!this._skinAdditions[add.heroConfId]) {
                this._skinAdditions[add.heroConfId] = [];
            }
            this._skinAdditions[add.heroConfId].push(add.heroModulBO);
        }
    }

    /**获取英雄羁绊加成 */
    protected async _doGetFetterAddition() {
        let protos = await this._gm.request<FetterAddBO[]>(GameProxy.apiherogetHeroFetterAdd, undefined, GameProxy, true);
        this._updateFetterAddition(protos);
    }

    /**更新英雄羁绊加成 */
    protected _updateFetterAddition(protos: FetterAddBO[], heroConfId?: number) {
        this._fetterAdditions = {};

        for (let proto of protos) {
            if (proto.heroModulBO) {
                this._fetterAdditions[proto.heroModulBO.heroCofId] = proto.heroModulBO;
                for (let confId of proto.effectConfs) {
                    let config = cm.getJibanConfig(confId);
                    if (config) {
                        let configs = this._fetterConfigs[config.hero];
                        if (configs) {
                            for (let c of configs) {
                                if (c.config == config) {
                                    c.active = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        EManager.emit(this.events.onFetterAdditionDirty, heroConfId);
    }

    /**更新勋章等级加成 */
    public updateMedalLvAddition(proto: HeroModulBO) {
        this._medalLvAddtion = proto;
    }

    /**更新战略点加成 */
    public updateMedalTreeAddition(protos: HeroModulBO[]) {
        this._medalTreeAdditions = protos;
    }

    /**更新英雄公会科技加成 */
    public updateTechAddition(protos: HeroModulBO[]) {
        this._techAdditions = {};

        for (let proto of protos) {
            if (proto) {
                let heroDuty: number = proto.heroCofId;
                this._techAdditions[heroDuty] = proto;
                EManager.emit(this.events.onTechAdditionDirty, heroDuty);
            }
        }
    }

    /**清空某类英雄公会科技加成 */
    public clearTechAddition(duty: number) {
        this._techAdditions[duty] = null;
        EManager.emit(this.events.onTechAdditionDirty, duty);
    }

    /**
     * 激活某条英雄羁绊
     * @param config 
     */
    async doActiveHeroFetter(config: jibanconfigRow) {
        let proto = await this._gm.request<FetterAddBO[]>(GameProxy.apilibraactiveHeroFetter, config.ID);
        this._updateFetterAddition(proto, config.hero);
        playerLogic.getPlayer().setPowerDirty();
    }

    getFetterConfigs(heroConfId: number): { config: jibanconfigRow, active: boolean }[] {
        return this._fetterConfigs[heroConfId];
    }

    getEquipShares(heroId: string): PlayerEquip[] {
        let equips: PlayerEquip[] = [];
        let ids = this._equipShares[heroId];
        if (ids) {
            for (let id of ids) {
                let equip = bagLogic.getEquip(id);
                if (equip) { equips.push(equip); }
            }
        }
        return equips;
    }

    /**获取神器祭坛和共鸣加成 */
    async doGetArtifactAltarAddition() {
        let protos = await this._gm.request<HeroModulBO>(GameProxy.apiherogetArtifactAltarAdd, null);
        this.updateArtifactAltarAddition(protos);
        playerLogic.getPlayer().setPowerDirty();
    }

    updateArtifactAltarAddition(protos: HeroModulBO) {
        this._artifactAltarAdditions = protos;
    }
}

let heroLogic = new HeroLogic();
export default heroLogic;