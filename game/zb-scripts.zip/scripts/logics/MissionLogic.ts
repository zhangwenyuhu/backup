import GameProxy, { ProcessReq, ResourceVO } from './../proxy/GameProxy';
import BaseLogic from "./BaseLogic";
import Mission from '../data/mission/Mission';
import Stageconfig from '../configs/Stageconfig';
import Chapter from '../data/mission/Chapter';
import Building from '../data/mission/Building';
import IGameManager from '../manager/IGameManager';
import Country from '../data/mission/Country';
import { SystemId, BattleType } from '../utils/DefineUtils';
import playerLogic from './PlayerLogic';
import Card from '../data/card/Card';
import activityLogic from "./ActivityLogic";
import EManager, { EName } from "../manager/EventManager";
import heroLogic from "./HeroLogic";

/**关卡系统 */
class MissionLogic extends BaseLogic {
    protected _chapters: { [key: number]: Chapter } = {};
    protected _countries: { [key: number]: Country } = {};

    init(proto: ResourceVO, gm: IGameManager) {
        super.init(proto, gm);

        for (let i = 0; i < Stageconfig.length; i++) {
            let config = Stageconfig[i];
            let mission = new Mission(config, config.ID <= proto.proces.stageId + 1, config.ID <= proto.proces.stageId);
            let country = this.getCountry(mission.getCountryId());
            let isNewCountry = false;
            if (!country) {
                country = new Country();
                isNewCountry = true;
            }

            let chapter = this.getChapter(mission.getChapterId());
            let isNewChapter = false;
            if (!chapter) {
                chapter = new Chapter();
                isNewChapter = true;
            }

            let isNewBuilding = false;
            let building = chapter.getBuilding(mission.getBuildingId());
            if (!building) {
                building = new Building();
                isNewBuilding = true;
            }
            building.addMission(mission);

            if (isNewBuilding) chapter.addBuilding(building);
            if (isNewChapter) {
                this._chapters[chapter.getId()] = chapter;
                country.addChapter(chapter);
            }
            if (isNewCountry) this._countries[country.getId()] = country;
        }
    }

    getCountries(): Country[] {
        let countries = Object.values(this._countries);
        countries.sort((a: Country, b: Country) => { return a.getId() - b.getId() });
        return countries;
    }

    getCountry(id: number): Country {
        return this._countries[id];
    }

    getChapters(): Chapter[] {
        let chapters = Object.values(this._chapters);
        chapters.sort((a: Chapter, b: Chapter) => { return a.getId() - b.getId() });
        return chapters;
    }

    getChapter(id: number): Chapter {
        return this._chapters[id];
    }

    getCurrentChapter(): Chapter {
        let chapters = this.getChapters();
        for (let chapter of chapters) {
            if (chapter.isUnlock() && !chapter.isPassed()) {
                return chapter;
            }
        }
        return null;
    }

    getCurrentCountry(): Country {
        let chapter = this.getCurrentChapter();
        if (chapter) {
            return this.getCountry(chapter.getCountryId());
        }
        return null;
    }

    getLastCountry(): Country {
        let countries = this.getCountries();
        return countries[countries.length - 1];
    }

    getCurrentBuilding(): Building {
        let chapter = this.getCurrentChapter();
        if (chapter) {
            return chapter.getCurrentBuilding();
        }
        return null;
    }

    getCurrentMission(): Mission {
        let building = this.getCurrentBuilding();
        if (building) {
            return building.getCurrentMission();
        }
        return this.getLastCountry().getLastChapter().getLastBuilding().getLastMission();
    }

    getPreMission(mission: Mission) {
        let chapter = this.getChapter(mission.getChapterId());
        let building = chapter.getBuilding(mission.getBuildingId());
        let preMission = building.getMission(mission.getId() - 1);
        if (preMission) {
            return preMission;
        }

        building = chapter.getBuilding(building.getId() - 1);
        if (building) {
            return building.getLastMission();
        }

        chapter = this.getChapter(chapter.getId() - 1);
        if (chapter) {
            return chapter.getLastBuilding().getLastMission();
        }

        return null;
    }

    getNextMission(mission: Mission) {
        let chapter = this.getChapter(mission.getChapterId());
        let building = chapter.getBuilding(mission.getBuildingId());
        let nextMission = building.getMission(mission.getId() + 1);
        if (nextMission) {
            return nextMission;
        }

        building = chapter.getBuilding(building.getId() + 1);
        if (building) {
            return building.getFirstMission();
        }

        chapter = this.getChapter(chapter.getId() + 1);
        if (chapter) {
            return chapter.getFirstBuilding().getFirstMission();
        }

        return null;
    }

    async doPassMission(mission: Mission): Promise<Card[]> {
        let req = new ProcessReq();
        req.stageId = mission.getStageId();
        req.systemId = SystemId.PVE;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiprocesspassProcess, req);
        let cards = playerLogic.addCards(proto);
        let player = playerLogic.getPlayer();
        player.setExp(proto.roleVO.exp);
        player.setLevelExp(proto.roleVO.lvExp);
        player.setLevel(proto.roleVO.lv);

        if (mission.getStageId() == proto.proces.stageId) {
            mission.pass();
            let nextMission = this.getNextMission(mission);
            if (nextMission) { nextMission.unlock(); }
            heroLogic.artifactUnlockInfo && heroLogic.artifactUnlockInfo.addTaskProgress(3001);
        }
        activityLogic.passPioneerMission(mission.getStageId());
        EManager.emit(EName.onUpdateOnline);

        gssdk.logCommitTool.commitCommon({
            eventId: 5,
            index: mission.getStageId(),
            eventName: `${mission.getBuildingId()}-${mission.getId()}`,
        });

        return cards;
    }

    // 获取主线阵容战力
    public async getPveTroopPower() {
        let power: number = 0;
        let troop = await playerLogic.getTroop(BattleType.PVE);
        if (troop && troop.length > 0) {
            for (let i = 0; i < troop.length; i++) {
                if (troop[i]) { power += troop[i].getPower(); }
            }
        }
        return power;
    }
}

let missionLogic = new MissionLogic();
export default missionLogic;