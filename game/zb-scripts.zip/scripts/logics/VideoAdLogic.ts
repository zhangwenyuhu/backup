
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from '../manager/GameManager';
import cm from "../manager/ConfigManager";
import GameProxy from "../proxy/GameProxy";
import { defaultConfigMap } from "../configs/defaultConfig";
import storageUtils from "../utils/StorageUtils";
import { Storage } from "../utils/DefineUtils";

export enum AD_TYPE {
    CallHero = 1,         // 酒馆抽取英雄
    QuickHangup = 2,      // 快速挂机
    WisdomTree = 3,       // 智慧树中复活英雄
    TaskFresh = 4,        // 悬赏任务刷新
    TaskComplete = 5,     // 悬赏任务完成
    Shop = 6,             // 商店物品购买
    VideoGift = 7,        // 视频特惠礼包
    Dice = 8,             // 棋盘骰子
    WonderSpace = 9,      // 奇妙时空复活英雄
    VideoGiftNew = 10,    // 视频特惠礼包新次数
    ZhuanPan = 11,        // 转盘次数
    StatueHuaban = 12,    // 雕像花瓣
    StatueZhigan = 13,    // 雕像枝干
    StatueHuagen = 14,    // 雕像花根
}

/* 视频播放次数管理 */
export class VideoAdLogic extends BaseLogic {

    private videoAdTimes: { [key: number]: number } = {};
    private _nowUtcDay: number = 0;

    init(gm: IGameManager) {
        super.init(null, gm);

        this.dataInit();
    }

    protected dataInit() {
        let date = new Date(gm.getCurrentTimestamp());
        this._nowUtcDay = date.getUTCDay();
    }

    public updatePerSec() {
        let date = new Date(gm.getCurrentTimestamp());
        let utcDay: number = date.getUTCDay();
        if (utcDay != this._nowUtcDay) {
            console.log('重新请求所有视频播放次数信息!');
            this.allVideoAdTimesReq();
            this._nowUtcDay = utcDay;
        }
    }

    videoUnlock(): boolean {
        return true;
    }

    // 请求所有视频播放次数的数据
    async allVideoAdTimesReq() {
        let proto = await gm.request<{ [key: number]: number }>(GameProxy.apivideogetAllVideoCount);
        this.videoAdTimes = proto;
    }

    // 请求某项功能的视频播放次数
    async videoAdTimesReq(id: number) {
        let proto = await gm.request<number>(GameProxy.apivideogetVideoCount, id);
        if (proto) {
            this.videoAdTimes[id] = proto;
        }
    }

    public canVideoAd(type: AD_TYPE) {
        return this.videoAdTimes[type] > 0 && this.videoUnlock();
        //return this.videoAdTimes[type]<cm.getVideoConfig(type).videotime;
    }

    public adNowTimes(type: AD_TYPE) {
        return this.videoAdTimes[type] || 0;
    }

    public adMaxTimes(type: AD_TYPE) {
        return cm.getVideoConfig(type).videotime;
    }

    public videoPlayTimesCount(type: AD_TYPE) {
        if (this.videoAdTimes[type]) {
            this.videoAdTimes[type] -= 1;
        } else {
            this.videoAdTimes[type] = 0;
        }
    }

    // 更新播放CD
    public updatePlayVideoTs(type: AD_TYPE) {
        if (type == AD_TYPE.CallHero) {
            let cd: number = defaultConfigMap.GachaVideoTime.value;
            let ts: number = gm.getCurrentTimestamp() / 1000 + cd;
            storageUtils.setNumber(Storage.LotteryVideoTs.Key, ts);
        }
    }

    // 获取播放CD
    public getPlayVideoLeftSec(type: AD_TYPE): number {
        let sec: number = 0;
        if (type == AD_TYPE.CallHero) {
            let ts: number = storageUtils.getNumber(Storage.LotteryVideoTs)
            sec = ts - gm.getCurrentTimestamp() / 1000;
            sec = sec < 0 ? 0 : sec;
        }
        return sec;
    }
}

let videoAdLogic = new VideoAdLogic();
export default videoAdLogic;