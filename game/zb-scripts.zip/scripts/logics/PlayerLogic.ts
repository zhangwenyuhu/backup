import playerLevelConfig from '../configs/playerLevelConfig';
import Card from '../data/card/Card';
import Equip from "../data/card/Equip";
import Good from '../data/card/Good';
import Hero from '../data/card/Hero';
import Npc from '../data/card/Npc';
import PlayerArtifact from '../data/card/PlayerArtifact';
import PlayerEquip from '../data/card/PlayerEquip';
import PlayerHero from '../data/card/PlayerHero';
import Player from "../data/user/Player";
import { UserGender } from '../data/user/User';
import ToastError from '../error/ToastError';
import EManager from '../manager/EventManager';
import IGameManager from '../manager/IGameManager';
import { BattleType } from '../utils/DefineUtils';
import stringUtils from '../utils/StringUtils';
import { stringConfigMap } from './../configs/stringConfig';
import { EName } from './../manager/EventManager';
import GameProxy, {
    BattleStanceBO,
    BattleStanceReq, EquipBO, GoodVO,
    HangUpProduceVO,
    HangUpSpeedBO,
    HeroCapacityVO, HeroVO,
    ResourceVO,
    RoleVO
} from './../proxy/GameProxy';
import bagLogic from './BagLogic';
import BaseLogic from "./BaseLogic";
import commitLogic, { DiamondCost } from './CommitLogic';
import heroLogic from './HeroLogic';
import rechargeLogic from './RechargeLogic';
import wisdomTreeLogic from "./WisdomTreeLogic";
import wonderSpaceLogic from "./WonderSpaceLogic";

/**玩家系统 */
class PlayerLogic extends BaseLogic {
    protected _player: Player = null;

    goldSpeed: number = 0;
    groupExpSpeed: number = 0;
    heroExpSpeed: number = 0;
    quickHangCost: number = 0;
    quickHangRemain: number = 0;
    quickHangResetTimestamp: number = 0;
    startHangupTS: number = 0;
    top5Power: number = 0;

    protected _troops: { [key: number]: string[] } = {};
    protected _levelup: { from: number, to: number } = { from: 0, to: 0 };

    getPlayer(): Player {
        return this._player;
    }

    init(proto: RoleVO, gm: IGameManager) {
        super.init(proto, gm);

        this._player = new Player(proto);
        console.warn("------------ role id ---------------");
        console.warn(this._player.getRoleId());
        console.warn("------------ role id ---------------");
        gssdk.logCommitTool.roleId = this._player.getRoleId() as any;
    }

    isPayed(): boolean {
        return rechargeLogic.getPayMoney() > 0;
    }

    getLevelUpData() { return this._levelup; }

    checkLevelUp(cards: Card[]): boolean {
        let goods = cards.filter((v, i, a) => {
            return v.getType() == Card.Type.Good;
        }) as Good[];

        let addExp: number = 0;
        goods.forEach((v, i, a) => {
            if (v && v.getIndex() == Good.GoodId.PlayerExp) {
                addExp += v.getAmount();
            }
        });
        if (addExp == 0) { return false; }
        this._levelup.from = this._player.getLevel();
        let addLevel = playerLogic.getLevelUpNum(addExp);
        this._levelup.to = this._levelup.from + addLevel;
        return addLevel > 0;
    }

    addPlayerExp(cards: Card[]): boolean {
        let goods = cards.filter((v, i, a) => {
            return v.getType() == Card.Type.Good;
        }) as Good[];

        let addExp: number = 0;
        goods.forEach((v, i, a) => {
            if (v && v.getIndex() == Good.GoodId.PlayerExp) {
                addExp += v.getAmount();
            }
        });
        if (addExp == 0) { return }

        this._player.setLevelExp(this._player.getLevelExp() + addExp);
        this._player.setExp(this._player.getExp() + addExp);
    }

    getLevelUpNum(addExp: number): number {
        let nowExp: number = this._player.getExp();
        let nowLevel: number = this._player.getLevel();

        let nextExp = nowExp + addExp;
        let levelUpNeed = 0;
        for (let i = 0; i < nowLevel - 1; i++) {
            levelUpNeed += playerLevelConfig[i].Exp;
        }

        let addLevel = 0;
        for (let i = 0; i < 10; i++) {
            let level = nowLevel + i - 1;
            if (playerLevelConfig[level]) {
                levelUpNeed += playerLevelConfig[level].Exp;
                if (levelUpNeed <= nextExp) {
                    addLevel += 1;
                } else {
                    break;
                }
            }
        }

        return addLevel;
    }

    getChangeNameDiamondCount(): number {
        return 200;
    }

    getCardsByReward(reward): Card[] {
        let cards: Card[] = [];
        for (let res of reward) {
            if (res.objId == "goods") {
                let goodVo = new GoodVO();
                goodVo.propId = res.propId;
                goodVo.amt = Number(res.amt);
                if (goodVo.amt > 0) {
                    cards.push(new Good(goodVo));
                }
            } else if (res.objId == "equip") {
                let equipVo = new EquipBO();
                equipVo.equipCofId = res.propId;
                equipVo.campBonus = res.campBonus;
                cards.push(new Equip(equipVo));
            } else if (res.objId == "hero") {
                let heroVo = new HeroVO();
                heroVo.heroCofId = res.propId;
                heroVo.star = res.star;
                heroVo.rank = res.rank;
                heroVo.lv = res.lv;
                cards.push(new Hero(heroVo));
            }
        }
        return cards;
    }

    getCards(proto: ResourceVO): Card[] {
        let cards: Card[] = [];
        if (proto.equips) {
            for (let bo of proto.equips) {
                cards.push(new PlayerEquip(bo));
            }
        }
        if (proto.goods) {
            let map: { [key: number]: Good } = {};
            for (let vo of proto.goods) {
                if (vo.amt > 0) {
                    let good = new Good(vo);
                    if (map[good.getIndex()]) {
                        map[good.getIndex()].changeAmount(good.getAmount());
                    }
                    else {
                        map[good.getIndex()] = good;
                    }
                }
            }
            cards.pushList(Object.values(map));
        }
        if (proto.heros) {
            for (let vo of proto.heros) {
                cards.push(new PlayerHero(vo, false));
            }
        }
        if (proto.artifacts) {
            for (let bo of proto.artifacts) {
                cards.push(new PlayerArtifact(bo));
            }
        }
        return cards;
    }

    addCards(proto: ResourceVO): Card[] {
        let cards = this.getCards(proto);
        this.addRewards(cards);
        return cards;
    }

    addRewards(cards: Card[]) {
        if (this.checkLevelUp(cards)) {
            EManager.emit(EName.onLevelUp);
        } else {
            this.addPlayerExp(cards);
        }

        let heroes: PlayerHero[] = [];
        let equips: PlayerEquip[] = [];
        for (let card of cards) {
            if (card.getType() == Card.Type.Hero) {
                heroes.push(card as PlayerHero);
            }
            else if (card.getType() == Card.Type.Equip) {
                equips.push(card as PlayerEquip);
            }
            else if (card.getType() == Card.Type.Artifact) {
                bagLogic.addArtifact(card as PlayerArtifact);
            }
            else if (card.getType() == Card.Type.Good) {
                bagLogic.addGood(card as Good);
            }
        }
        if (heroes.length > 0) {
            heroLogic.addHeroes(heroes);
        }
        if (equips.length > 0) {
            bagLogic.addEquips(equips);
        }
    }

    protected _updateTroop(protos: BattleStanceBO[], battleType: BattleType) {
        protos.sort((a: BattleStanceBO, b: BattleStanceBO) => { return a.stanceNo - b.stanceNo });
        let troopMap = {};
        for (let proto of protos) {
            troopMap[proto.stanceNo] = proto.heroId;
        }

        let troop: string[] = [];
        let max = this.getMaxInstanceTroopCount();
        if (battleType == BattleType.PVP_Senior) {
            max *= 3;
        }
        for (let i = 1; i <= max; i++) {
            if (troopMap[i]) { troop.push(troopMap[i]); }
            else { troop.push(""); }
        }
        this._troops[battleType] = troop;
    }

    async getTroop(battleType: BattleType, race: number = 0, isRequest: boolean = false): Promise<Hero[]> {
        if (race > 0) { battleType = race + 7; }
        let troop = this._troops[battleType];
        if (troop && !isRequest) {
            let heroes = [];
            for (let id of troop) {
                if (id) {
                    let hero = heroLogic.getHero(id);
                    heroes.push(hero);
                }
                else {
                    heroes.push(null);
                }
            }
            if (battleType == BattleType.Maze || battleType == BattleType.WonderSpace) {
                heroes = [];
                let wisdomStance = {};
                if (battleType == BattleType.Maze) {
                    if (wisdomTreeLogic.wisdomStance) {
                        wisdomStance = wisdomTreeLogic.wisdomStance.stance;
                    }
                } else if (battleType == BattleType.WonderSpace) {
                    if (wonderSpaceLogic.wonderStance) {
                        wisdomStance = wonderSpaceLogic.wonderStance.stance;
                    }
                }
                for (let i = 0; i < 5; i++) {
                    let heroId = wisdomStance[i];
                    if (heroId && heroId != "") {
                        let hero = heroLogic.getHero(heroId);
                        if (hero) {
                            heroes.push(hero);
                        } else {
                            let wisdomHero = null;
                            if (battleType == BattleType.Maze) {
                                wisdomHero = wisdomTreeLogic.wisdomTreeHero.find(a => a.hero == heroId || a.heroVO && a.heroVO.heroId == heroId);
                            } else if (battleType == BattleType.WonderSpace) {
                                wisdomHero = wonderSpaceLogic.wonderSpaceHero.find(a => a.hero == heroId || a.heroVO && a.heroVO.heroId == heroId);
                            }
                            if (wisdomHero && wisdomHero.hp > 0 && wisdomHero.heroVO != null) {
                                heroes.push(new Hero(wisdomHero.heroVO));
                            } else {
                                heroes.push(null);
                            }
                        }
                    } else {
                        heroes.push(null);
                    }
                }
            }
            return heroes;
        }
        else {
            let param: number = battleType - 1;
            let troopProto = await this._gm.request<BattleStanceBO[]>(GameProxy.apiBattlegetBattleStance, param.toString());
            this._updateTroop(troopProto, battleType);
            return await this.getTroop(battleType);
        }
    }

    async isTroopEmpty(battleType: BattleType): Promise<boolean> {
        let troop = await this.getTroop(battleType);
        if (troop) {
            for (let hero of troop) {
                if (hero) {
                    return false;
                }
            }
        }
        return true;
    }

    updateHangup(proto: HangUpSpeedBO) {
        this.goldSpeed = proto.goldSpeed;
        this.groupExpSpeed = proto.groupExpSpeed;
        this.heroExpSpeed = proto.heroExpSpeed;
        this.quickHangCost = proto.quickHangCost;
        this.quickHangRemain = proto.quickRemain;
        this.quickHangResetTimestamp = proto.quickResetTs;
        this.startHangupTS = proto.startTs;
        EManager.emit(EName.onHangupDirty);
    }

    getHangupMinutes(): number {
        let delta = (this._gm.getCurrentTimestamp() - this.startHangupTS);
        return Math.floor(delta / 1000 / 60);
    }

    getHangupGold(): number {
        return this.goldSpeed * this.getHangupMinutes();
    }

    getHangupGroupExp(): number {
        let delta = (this._gm.getCurrentTimestamp() - this.startHangupTS);
        let minutes = Math.floor(delta / 1000 / 60);
        return this.groupExpSpeed * minutes;
    }

    getHangupHeroExp(): number {
        let delta = (this._gm.getCurrentTimestamp() - this.startHangupTS);
        let minutes = Math.floor(delta / 1000 / 60);
        return this.heroExpSpeed * minutes;
    }

    getMaxInstanceTroopCount(): number {
        return 5;
    }

    canExpandHeroCapacity(): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        let consumes = [];
        let good = bagLogic.getGood(Good.GoodId.Diamond);
        let cost = this.getPlayer().getBuyCapacityCost();
        if (good.getAmount() < cost) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(Good.GoodId.Diamond, -cost);
                commitLogic.costDiamond(cost, DiamondCost.heroBlock);
            });
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    async doExpandHeroCapacity() {
        let ret = this.canExpandHeroCapacity();
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let proto = await this._gm.request<HeroCapacityVO>(GameProxy.apiRolebuyHeroCapacity);
        this.getPlayer().setHeroCapacity(proto.heroCapacity);
        this.getPlayer().setBuyCapacityCost(proto.buyCost);
        for (let consume of ret.consumes) {
            consume();
        }
    }

    async doUpdateTroop(selectHeroes: { [key: number]: Hero }, battleType: BattleType, expire: number = -1, race: number = 0) {
        if (race > 0) {
            battleType = race + 7;
        }
        let heroes = Object.values(selectHeroes).filter((a: Hero) => { return a != null; });
        if (heroes.length == 0) {
            throw new ToastError(stringConfigMap.key_please_select_fight_hero.Value);
        }

        let troop = [];
        let max = this.getMaxInstanceTroopCount();
        if (battleType == BattleType.PVP_Senior) {
            max *= 3;
        }
        for (let i = 1; i <= max; i++) {
            if (selectHeroes[i] && !(selectHeroes[i] instanceof Npc)) {
                troop.push(selectHeroes[i]);
            }
            else {
                troop.push(null);
            }
        }

        let isDirty = false;
        let originTroop = await this.getTroop(battleType);
        for (let i = 0; i < originTroop.length; i++) {
            if (originTroop[i] != troop[i]) {
                isDirty = true;
                break;
            }
        }

        if (isDirty) {
            let req = new BattleStanceReq();
            req.stanceTypeEnum = (battleType - 1).toString();
            req.expire = expire;
            req.stance = [];

            for (let i = 0; i < troop.length; i++) {
                let hero = troop[i];
                let bo = new BattleStanceBO();
                bo.stanceNo = i + 1;
                bo.heroId = hero ? hero.getId() : "";
                bo.heroCofId = hero ? hero.getIndex() : 0;
                req.stance.push(bo);
            }
            req.stance.sort((a: BattleStanceBO, b: BattleStanceBO) => { return a.stanceNo - b.stanceNo });
            let protos = await this._gm.request<BattleStanceBO[]>(GameProxy.apiBattlesetBattleStance, req);
            this._updateTroop(protos, battleType);
        }
    }

    async doUpdateMainTroop(selectHeroes: { [key: number]: Hero }) {
        let troop = [];
        for (let i = 1; i <= this.getMaxInstanceTroopCount(); i++) {
            if (selectHeroes[i]) { troop.push(selectHeroes[i]); }
        }

        if (heroLogic.getHeroesIndexCount() >= this.getMaxInstanceTroopCount() && troop.length < this.getMaxInstanceTroopCount()) {
            throw new ToastError(stringUtils.getString(stringConfigMap.key_select_main_troop.Value, { count: this.getMaxInstanceTroopCount() }));
        }

        let isDirty = false;
        let mainTroop = this.getPlayer().getMainTroop();
        for (let i = 0; i < this.getMaxInstanceTroopCount(); i++) {
            if (mainTroop[i] != troop[i]) {
                isDirty = true;
                break;
            }
        }

        if (isDirty) {
            let heroIds = [];
            for (let hero of troop) { heroIds.push(hero.getId()); }
            await this._gm.request<string[]>(GameProxy.apiRolesetMainForce, heroIds);
            this.getPlayer().setMainTroop(troop);
        }
    }

    isNameValid(name: string): { result: boolean, message?: string } {
        if (name.length == 0) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_input.Value, { name: stringConfigMap.key_player_name.Value })
            }
        }
        // if (stringUtils.strlen(name) > 12) {
        //     return {
        //         result: false,
        //         message: stringUtils.getString(stringConfigMap.key_content_max_length.Value,
        //             { name: stringConfigMap.key_player_name.Value, count1: 6, count2: 12 })
        //     }
        // }
        return { result: true }
    }

    isSignatureValid(signature: string): { result: boolean, message?: string } {
        if (signature.length == 0) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_input.Value, { name: stringConfigMap.key_player_signature.Value })
            }
        }
        if (stringUtils.strlen(signature) > 40) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_content_max_length.Value,
                    { name: stringConfigMap.key_player_signature.Value, count1: 20, count2: 40 })
            }
        }
        return { result: true }
    }

    canChangeName(newName: string): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        if (this.getPlayer().getNickname() == newName) {
            return {
                result: false,
                message: stringConfigMap.key_nickname_cannot_same_with_old.Value
            }
        }

        let ret = this.isNameValid(newName);
        if (!ret.result) {
            return ret;
        }

        let consumes = [];
        if (this.getPlayer().getRenameCount() > 0) {
            let good = bagLogic.getGood(Good.GoodId.Diamond);
            if (good.getAmount() < this.getChangeNameDiamondCount()) {
                return {
                    result: false,
                    message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
                }
            }
            else {
                consumes.push(() => {
                    bagLogic.changeGoodAmount(good.getIndex(), -this.getChangeNameDiamondCount());
                    commitLogic.costDiamond(this.getChangeNameDiamondCount(), DiamondCost.changeName);
                })
            }
        }

        return {
            result: true,
            consumes: consumes
        }
    }

    async doChangeName(newName: string) {
        let ret = this.canChangeName(newName);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let proto = await this._gm.request<RoleVO>(GameProxy.apiRolesetNick, newName);
        this.getPlayer().setNickname(proto.nick);
        this.getPlayer().addRenameCount();

        for (let consume of ret.consumes) {
            consume();
        }
    }

    async doChangeSignature(signature: string) {
        if (this.getPlayer().getSignature() == signature) {
            return;
        }

        let ret = this.isSignatureValid(signature);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let proto = await this._gm.request<RoleVO>(GameProxy.apiRolesetSignature, signature);
        this.getPlayer().setSignature(proto.signature);
    }

    async doChangeAvatar(selectAvatar: string, selectRect: string) {
        if (selectAvatar.length > 0 && this.getPlayer().getAvatar() != selectAvatar) {
            let proto = await this._gm.request<RoleVO>(GameProxy.apiRolesetAvatar, selectAvatar);
            this.getPlayer().setAvatar(proto.avatar);
        }

        if (selectRect.length > 0 && this.getPlayer().getAvatarRect() != selectRect) {
            let proto = await this._gm.request<RoleVO>(GameProxy.apiRolesetAvatarFrame, selectRect);
            this.getPlayer().setAvatarRect(proto.avatarFrame);
        }
    }

    async doChangeGender(gender: UserGender) {
        if (this.getPlayer().getGender() == gender) {
            return;
        }
        let proto = await this._gm.request<RoleVO>(GameProxy.apiRolesetGender, gender.toString());
        this.getPlayer().setGender(proto.gender);
    }

    async doClaimHangupReward(): Promise<ResourceVO> {
        let proto = await this._gm.request<HangUpProduceVO>(GameProxy.apihangUpgetHangUpProduce)
        if (proto) {
            this.updateHangup(proto.speed);
            return proto.resource;
        }
        return null;
    }

    canClaimHangupFast(): {
        result: boolean,
        message?: string,
        consumes?: Function[]
    } {
        let consumes = [];
        let good = bagLogic.getGood(Good.GoodId.Diamond);
        if (good.getAmount() < this.quickHangCost) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })
            }
        }
        else {
            consumes.push(() => {
                bagLogic.changeGoodAmount(good.getIndex(), -this.quickHangCost);
                commitLogic.costDiamond(this.quickHangCost, DiamondCost.quickHangup);
            })
        }

        return { result: true, consumes: consumes }
    }

    async doClaimHangupFast(bVideo: boolean = false): Promise<Card[]> {
        let ret = this.canClaimHangupFast();
        if (!ret.result && !bVideo) {
            throw new ToastError(ret.message);
        }

        let proto = await this._gm.request<HangUpProduceVO>(GameProxy.apihangUpgoQuickHangUp, bVideo);
        if (!bVideo) {
            for (let consume of ret.consumes) {
                if (consume) consume();
            }
        }

        if (proto) {
            this.updateHangup(proto.speed);
            return this.addCards(proto.resource);
        }
        return [];
    }

    async doExchangeCode(code: string): Promise<Card[]> {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiShopuseExchangeCode, code);
        return this.addCards(proto);
    }

    /**获取历史最高5战力 */
    async doGetRoleTop5Power() {
        let proto = await this._gm.request<number>(GameProxy.apiRolegetRoleTop5Power, null);
        let heroes = heroLogic.getHeroes().sort((a, b) => {
            return b.getPower() - a.getPower();
        });
        let power = 0;
        let topHeroes = [];
        for (let i = 0; i < heroes.length; i++) {
            if (topHeroes.length < 5 && topHeroes.find(a => a.getIndex() == heroes[i].getIndex()) == null) {
                power += heroes[i].getPower();
                topHeroes.push(heroes[i]);
                if (topHeroes.length == 5) {
                    break;
                }
            }
        }
        this.top5Power = Math.max(proto, power);
    }
}

let playerLogic = new PlayerLogic();
export default playerLogic;