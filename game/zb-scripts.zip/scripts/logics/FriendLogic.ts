import GameProxy, { FriendManageVO, FriendListVO, FriendInfoItem, RoleVO, SearchReq, FPointRecvVO, GoodVO } from './../proxy/GameProxy';
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import Friend from '../data/user/Friend';
import User from '../data/user/User';
import gm from '../manager/GameManager';
import { defaultConfigMap } from '../configs/defaultConfig';
import friendMerLogic from './FriendMerLogic';
import redPointLogic, { RedPointType } from './RedPointLogic';
import ToastError from '../error/ToastError';
import { stringConfigMap } from '../configs/stringConfig';
import bagLogic from './BagLogic';
import activityLogic from "./ActivityLogic";
import { SevenDayTaskType, WeekType } from "../utils/DefineUtils";
import assignmentLogic from './AssignmentLogic';

/**好友系统 */
export class FriendLogic extends BaseLogic {

    protected _friends: { [key: string]: Friend } = {}; // 好友数据
    protected _applys: { [key: string]: Friend } = {};  // 申请玩家数据
    protected _blacks: { [key: string]: Friend } = {};  // 黑名单玩家数据
    protected _sendCount: number = 0;   // 已赠送红心数
    protected _recvCount: number = 0;   // 当天收取红心数
    protected _nowHeartCount: number = 0; // 当前红心数
    protected _players: { [key: string]: User } = {};      // 缓存的部分玩家数据
    protected _searchs: { [key: string]: Friend } = {}; // 搜索的玩家数据
    protected _isValid: boolean = false;
    protected _requesting: boolean = false;

    get isValid(): boolean {
        return this._isValid;
    }

    get isRequesting(): boolean {
        return this._requesting;
    }

    init(gm: IGameManager) {
        super.init(null, gm);

        this.bindRedFunc();
    }

    resetAll() {
        this._friends = {};
        this._applys = {};
        this._blacks = {};
        this._players = {};
        this._searchs = {};
        this._sendCount = 0;
        this._recvCount = 0;
        this._nowHeartCount = 0;
        this._isValid = false;
        this._requesting = false;
    }

    async panelOpenReq() {
        this._isValid = false;
        if (this._requesting) {
            return;
        }
        this._requesting = true;
        friendMerLogic.reset();
        await friendLogic.friendsReq();
        await friendLogic.manageReq();
        await friendMerLogic.mercHerosReq();
        await friendMerLogic.applyToMeMercHeroReq();
        this._isValid = true;
        this._requesting = false;
    }

    // 请求最新好友数据
    async friendsReq() {
        let friendProto = await gm.request<FriendListVO>(GameProxy.apiFriendgetFriends);
        this.friendsFresh(friendProto);
    }
    // 请求申请和黑名单
    async manageReq() {
        let managerProto = await gm.request<FriendManageVO>(GameProxy.apiFriendgetFriendManage);
        this.managerFresh(managerProto);
    }
    // 请求玩家信息
    async playerReq(id: string) {
        let playerProto = await gm.request<RoleVO>(GameProxy.apiRolegetRole, id);
        if (playerProto) {
            this.cachePlayer(playerProto);
        }
    }
    // 搜索玩家
    async searchReq(data: SearchReq) {
        let searchProto = await gm.request<FriendInfoItem[]>(GameProxy.apiFriendsearch, data);
        this.searchsFresh(searchProto);
    }
    // 领取友情点
    async recvHeartReq(id: string) {
        try {
            let heartProto: FPointRecvVO = await gm.request<FPointRecvVO>(GameProxy.apiFriendrecvFPoint, id);
            let ids: string[] = [];
            ids.push(id);
            this.recvHeart(ids, heartProto);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
    // 领取友情点 批量
    async recvHeartBatchReq(ids: string[]) {
        if (ids.length == 0) { return; }
        let heartProto = await gm.request<FPointRecvVO>(GameProxy.apiFriendrecvFPointBatch, ids);
        this.recvHeart(ids, heartProto);

    }
    // 赠送友情点
    async sendHeartReq(id: string) {

        try {
            let sendCount = await gm.request<number>(GameProxy.apiFriendsendFPoint, id);
            let ids: string[] = [];
            ids.push(id);
            this.sendHeart(ids, sendCount);

            assignmentLogic.weekTaskProCommit(WeekType.send_friendship);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
    // 赠送友情点 批量
    async sendHeartBatchReq(ids: string[]) {
        if (ids.length == 0) { return; }

        let sendCount = await gm.request<number>(GameProxy.apiFriendsendFPointBatch, ids);
        this.sendHeart(ids, sendCount);
        assignmentLogic.weekTaskProCommit(WeekType.send_friendship, ids.length);
    }
    // 拉黑
    async addToBlackReq(id: string) {
        let blacks = await gm.request<FriendInfoItem[]>(GameProxy.apiFriendaddToBlackList, id);
        this.addToBlack(id, blacks);
    }
    // 申请成为好友
    async applyFriendReq(id: string) {
        if (this.isInBlackList(id)) {
            throw new ToastError(stringConfigMap.key_common_tip6.Value);
        }
        if (this.isFriend(id)) {
            throw new ToastError(stringConfigMap.key_common_tip7.Value);
        }

        await gm.request<boolean>(GameProxy.apiFriendapplyForFriend, id);
        this.applyFriend(id);
    }
    // 批量同意好友申请
    async acceptApplyReq(ids: string[]) {

        try {
            let friendProto = await gm.request<FriendListVO>(GameProxy.apiFriendbatchAcceptApply, ids);
            this.acceptApply(ids, friendProto);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
    // 批量忽略好友申请
    async ignoreApplyReq(ids: string[]) {
        let result = await gm.request<boolean>(GameProxy.apiFriendbatchRefuseApply, ids);
        this.ignoreApply(ids);
    }
    // 删除好友
    async deleteFriendReq(id: string) {
        let friendProto = await gm.request<FriendListVO>(GameProxy.apiFriendremoveFriend, id);
        this.friendsFresh(friendProto);
    }
    // 移出黑名单
    async removeFromBlackReq(id: string) {
        let blacks = await gm.request<FriendInfoItem[]>(GameProxy.apiFriendremoveBlackList, id);
        this.saveToBlacks(blacks);
    }

    private ignoreApply(ids: string[]) {
        // 清除申请列表
        if (ids.length == 1) {
            Object.keys(this._applys).forEach((v, i, a) => {
                if (this._applys[v].getRelationId() === ids[0]) {
                    delete this._applys[v];
                }
            })
        } else if (ids.length == Object.keys(this._applys).length) {
            this._applys = {};
        }
    }
    private acceptApply(ids: string[], friends: FriendListVO) {
        // 清除申请信息
        if (ids.length == 1) {
            Object.keys(this._applys).forEach((v, i, a) => {
                if (this._applys[v].getRelationId() === ids[0]) {
                    delete this._applys[v];
                }
            })
        } else if (ids.length == Object.keys(this._applys).length) {
            this._applys = {};
        }
        // 更新好友列表
        this.friendsFresh(friends);
    }
    private applyFriend(id: string) {
        // 更新搜索列表信息
        Object.keys(this._searchs).forEach((v, i, a) => {
            if (v === id) {
                //delete this._applys[v];
                this._searchs[v].setRelationStatus(1);
            }
        })
    }
    private addToBlack(id: string, blacks: FriendInfoItem[]) {
        // 从好友队列移除
        if (this._friends[id]) {
            delete this._friends[id];
        }
        // 更新黑名单
        this.saveToBlacks(blacks);
    }
    private saveToBlacks(blacks: FriendInfoItem[]) {
        this._blacks = {}
        blacks.forEach((v, i, a) => {
            let tmp = new Friend(v);
            this._blacks[tmp.getRoleId()] = tmp;
        })
    }

    private sendHeart(ids: string[], num: number) {
        ids.forEach((v, i, a) => {
            if (this._friends[v]) {
                this._friends[v].setCanSend(false);
            }
        })
        //this._sendCount = num;
        this._sendCount += ids.length;
    }
    private recvHeart(ids: string[], heartProto: FPointRecvVO) {
        // 刷新好友数据
        ids.forEach((v, i, a) => {
            if (this._friends[v]) {
                this._friends[v].setCanGet(false);
            }
        })

        // 已领取次数
        this._recvCount = heartProto.recvCount;
        // 友情点道具
        let good: GoodVO = heartProto.fpoint;
        let bagItem = bagLogic.getGood(good.propId);
        bagItem.setAmount(good.amt);
        this._nowHeartCount = good.amt;
    }

    private friendsFresh(friendProto: FriendListVO) {
        this._friends = {}

        if (friendProto && friendProto.friendList && friendProto.friendList instanceof Array) {
            friendProto.friendList.forEach((v, i, arr) => {
                let tmp = new Friend(v);
                this._friends[tmp.getRoleId()] = tmp;
            });
        }

        this._sendCount = friendProto.hasSentCount ? friendProto.hasSentCount : this._sendCount;
        this._recvCount = friendProto.hasRecvCount ? friendProto.hasRecvCount : this._recvCount;
        this._nowHeartCount = friendProto.fPointNow ? friendProto.fPointNow : this._nowHeartCount;
        this.syncHeartCount();
    }

    private managerFresh(managerProto: FriendManageVO) {
        this._blacks = {};
        this._applys = {};

        if (managerProto && managerProto.applyList && managerProto.applyList instanceof Array) {
            managerProto.applyList.forEach((v, i, arr) => {
                let tmp = new Friend(v);
                this._applys[tmp.getRoleId()] = tmp;
            });
        }
        if (managerProto && managerProto.blackList && managerProto.blackList instanceof Array) {
            managerProto.blackList.forEach((v, i, arr) => {
                let tmp = new Friend(v);
                this._blacks[tmp.getRoleId()] = tmp;
            });
        }
    }

    private searchsFresh(searchsProto: FriendInfoItem[]) {
        this._searchs = {};
        if (searchsProto) {
            searchsProto.forEach((v, i, a) => {
                let tmp = new Friend(v);
                this._searchs[tmp.getRoleId()] = tmp;
            });
        }
    }

    // 是否是好友
    isFriend(id: string): boolean {
        return (this._friends && this._friends[id] ? true : false);
    }

    // 好友数量
    friendCount(): number {
        return Object.keys(this._friends).length;
    }
    // 好友申请数量
    applyCount(): number {
        return Object.keys(this._applys).length;
    }
    // 黑名单数量
    blackCount(): number {
        return Object.keys(this._blacks).length;
    }

    isInBlackList(id: string) {
        return (this._blacks && this._blacks[id]) ? true : false;
    }

    isInApplyList(id: string) {
        return (this._applys && this._applys[id]) ? true : false;
    }

    // 已赠送的红心的数量
    getSendedHeart(): number {
        return this._sendCount;
    }
    getGotHeart(): number {
        return this._recvCount;
    }
    getNowHeart(): number {
        return this._nowHeartCount;
    }

    getFriends(): Friend[] {
        let arr: Friend[] = [];
        Object.keys(this._friends).forEach((v, i, a) => {
            arr.push(this._friends[v]);
        });
        return arr;
    }
    getFriendInfo(roleId: string) {
        return this._friends[roleId];
    }
    getCanSendIds(): string[] {
        let tmp: string[] = [];
        Object.keys(this._friends).forEach((v, i, a) => {
            if (this._friends[v].isCanSend()) {
                tmp.push(v);
            }
        });
        let limit: number = defaultConfigMap.friendpointsendlimit.value;
        let leftNum: number = limit - this._sendCount;
        if (leftNum < tmp.length) {
            let removeNum = tmp.length - leftNum
            for (let i = 0; i < removeNum; i++) {
                tmp.pop();
            }
        }
        return tmp;
    }
    getCanGetIds(): string[] {
        let tmp: string[] = [];
        Object.keys(this._friends).forEach((v, i, a) => {
            if (this._friends[v].isCanGet()) {
                tmp.push(v);
            }
        });
        let limit: number = defaultConfigMap.friendpointgetlimit.value;
        let leftNum: number = limit - this._recvCount;
        if (leftNum < tmp.length) {
            let removeNum = tmp.length - leftNum
            for (let i = 0; i < removeNum; i++) {
                tmp.pop();
            }
        }
        return tmp;
    }
    getFriendIds(): string[] {
        return Object.keys(this._friends);
    }
    getApplyPlayers(): Friend[] {
        let arr: Friend[] = [];
        Object.keys(this._applys).forEach((v, i, a) => {
            arr.push(this._applys[v]);
        });
        return arr;
    }
    getAllApplyRelationIds(): string[] {
        let arr: string[] = [];
        Object.keys(this._applys).forEach((v, i, a) => {
            arr.push(this._applys[v].getRelationId());
        });
        return arr;
    }

    getSearchPlayers(): Friend[] {
        let arr: Friend[] = [];
        Object.keys(this._searchs).forEach((v, i, a) => {
            arr.push(this._searchs[v]);
        });
        return arr;
    }
    clearSearchPlayers() {
        this._searchs = {};
    }

    getBlackPlayers(): Friend[] {
        let arr: Friend[] = [];
        Object.keys(this._blacks).forEach((v, i, a) => {
            arr.push(this._blacks[v]);
        });
        return arr;
    }

    cachePlayer(proto: RoleVO) {
        let tmp: User = new User(proto);
        this._players[tmp.getRoleId()] = tmp;
    }

    getPlayerInfo(id: string): User {
        return this._players[id];
    }

    hasPlayerCache(id: string): boolean {
        return this._players[id] ? true : false;
    }

    // 
    async playerShow(id: string, forceUpdate?: boolean) {
        let bupdate: boolean = forceUpdate ? forceUpdate : (!this.hasPlayerCache(id));
        if (bupdate) {
            await friendLogic.playerReq(id);
        }

        if (!friendLogic.hasPlayerCache(id)) {
            console.error("未请求到玩家数据...");
        }
    }

    /*  --红点判断函数--   */

    public bindRedFunc() {
        redPointLogic.addFunc(RedPointType.Friend_TabFriend, this.friendSendRed.bind(this));
        redPointLogic.addFunc(RedPointType.Friend_Manager, this.friendManageRed.bind(this));
        redPointLogic.addFunc(RedPointType.Friend_TabMer, null);
        redPointLogic.addFunc(RedPointType.Friend_TabMer_Manage, this.heroApplyRed.bind(this));
    }
    // 好友管理红点
    friendManageRed(): boolean {
        let bRed: boolean = false;
        bRed = Object.keys(this._applys).length > 0;
        return bRed;
    }

    // 好友领取和赠送红点
    friendSendRed(): boolean {
        let bRed: boolean = false;
        let bRecvLimit: boolean = this._recvCount >= defaultConfigMap.friendpointgetlimit.value;
        if (bRecvLimit) {
            return false;
        }

        let exitRecv: boolean = false;
        if (!bRecvLimit) {
            exitRecv = this.getFriends().some((v, i, a) => {
                return v.isCanGet();
            });
        }
        bRed = exitRecv;

        return bRed;
    }

    // 可租借佣兵红点
    canBorrowHeroRed(): boolean {
        let bRed: boolean = false;
        bRed = friendMerLogic.getBorrowedHeros().length < 3;
        return bRed;
    }

    // 佣兵申请红点
    heroApplyRed(): boolean {
        let bRed: boolean = false;
        bRed = friendMerLogic.getApplyList().length > 0;
        return bRed;
    }

    /*  --红点判断函数--   */

    private syncHeartCount() {
        let good = bagLogic.getGood(10005);
        good.setAmount(this._nowHeartCount);
    }
}

let friendLogic = new FriendLogic();
export default friendLogic;