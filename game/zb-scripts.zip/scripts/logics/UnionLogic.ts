import {
    AppointGuildReq,
    GuildApplyOptReq,
    GuildCreateReq,
    GuildMailSendReq,
    GuildOptVO,
    GuildVO,
    HuntBossVO,
    HuntHitReq,
    HuntRecordVO,
    ResourceVO,
    GuildStatueBO,
    GuildStatueRecVO,
    GuildStatueStrengReq,
    GuildStrengBO,
    GuildTableInfoVO,
    GuildStatuePartBO,
    GuildSimpleVO,
    GuildSimpleReq,
} from './../proxy/GameProxy';
import { stringConfigMap } from './../configs/stringConfig';
import BaseLogic from "./BaseLogic";
import Good, { GoodId } from "../data/card/Good";
import GameProxy, { CloudObjectReq, GoodVO, HuntRecordReq } from "../proxy/GameProxy";
import ToastError from "../error/ToastError";
import stringUtils from '../utils/StringUtils';
import Union, { UnionEnterMode, UnionSimple } from '../data/union/Union';
import bagLogic from './BagLogic';
import IGameManager from '../manager/IGameManager';
import playerLogic from './PlayerLogic';
import User, { UnionJob } from '../data/user/User';
import Monster from "../data/card/Monster";
import battleLogic from "./BattleLogic";
import gm from "../manager/GameManager";
import SeedUtils from "../utils/SeedUtils";
import goodsConfig from "../configs/goodsConfig";
import boxrewardconfig, { boxrewardconfigRow } from "../configs/boxrewardconfig";
import equipConfig from "../configs/equipConfig";
import { defaultConfigMap } from "../configs/defaultConfig";
import activityLogic from "./ActivityLogic";
import { SevenDayTaskType, CommonAdd } from "../utils/DefineUtils";
import factionconfig from '../configs/factionconfig';
import vipconfig from "../configs/vipconfig";
import chatSocket from "../socket/ChatSocket";
import BasePanel from '../view/panel/BasePanel';
import storageUtils from '../utils/StorageUtils';
import commitLogic, { DiamondCost } from './CommitLogic';
import heroLogic from './HeroLogic';
import EManager, { EName } from "../manager/EventManager";
import udgLogic from './UnionDungeonLogic';

export let UnionPermission = {
    /**
     * 批准入盟申请
     */
    AllowApply: "allowapply",

    /**
     * 设置入盟等级
     */
    SetJoinLevel: "setjoinlevel",

    /**
     * 修改公会公告
     */
    ChangeNotice: "changebulletin",

    /**
     * 踢出副会长
     */
    KickVice: "expelviceboss",

    /**
     * 踢出成员
     */
    KickMember: "expelmember",

    /**
     * 任命副会长
     */
    AppointVice: "addviceboss",

    /**
     * 发送个人邮件
     */
    SendPersonalMail: "sendnormalmail",

    /**
     * 发送全员邮件
     */
    SendUnionMail: "sendallmail",

    /**
     * 转让会长
     */
    TransferPresident: "transferboss",

    /**
     * 解散公会
     */
    DismissUnion: "dissolve",

    /**
     * 开启团队狩猎
     */
    OpenHunt: "openvenery",

    /**
     * 公会商店购买
     */
    UnionStore: "shopbuy",

    /**
     * 离开公会
     */
    UnionExit: "leavefaction",

    /**
     * 修改公会名
     */
    ChangeName: "changename"
}

/**公会系统 */
class UnionLogic extends BaseLogic {

    protected _union: Union = null;
    protected _unionHuntMonster: Monster = null;
    protected _unionHuntMonsterHP: number = 0;
    protected _unionHuntMonsterType: number = 1;
    protected _unionHuntBoss: HuntBossVO[] = [];
    protected _unionHuntHurt: number = 0;
    protected _unionHuntRewards = [];
    protected _unionHuntExtraRewards = [];
    protected _unionHuntSeed: string = "";
    public _unionHuntSeedRandom: SeedUtils = null;
    protected _unionHuntRecord: HuntRecordVO[] = [];
    protected _unionHuntWipeKey: string = "huntWipeKey";
    protected _unionHuntWipeData = null;
    protected _unionHuntBossId: string = "";
    protected _unionJoinTimestamp: number = 0;
    public zhuanpanCircle: number = 0;
    public partRead: { [key: number]: boolean } = {};

    protected _unionCache: { [key: number]: UnionSimple } = {};

    init(proto: GuildVO, gm: IGameManager) {
        super.init(proto, gm);
        if (proto) {
            this._union = new Union(proto);
            for (let member of proto.memeber) {
                if (playerLogic.getPlayer().getRoleId() == member.roleId) {
                    playerLogic.getPlayer().setUnionJob(member.guildJob);
                    this._unionJoinTimestamp = member.joinTs;
                    break;
                }
            }
        }
        this.updatePartRead();
    }

    // 读取本地信息
    updatePartRead() {
        for (let i = 1; i <= 3; i++) {
            this.partRead[i] = storageUtils.getBoolean({ Key: `part_read_${i}`, Default: false });
        }
    }
    // 设置已读取本地信息
    setPartRead(key: number, read: boolean) {
        if (this.partRead[key] == read) { return; }
        this.partRead[key] = read;

        storageUtils.setBoolean(`part_read_${key}`, read);
    }
    // 刷新重置本地信息
    resetPartRead() {
        for (let i = 1; i <= 3; i++) {
            storageUtils.setBoolean(`part_read_${i}`, false);
        }
        this.updatePartRead();
    }

    getUnion(): Union {
        return this._union;
    }

    getUnionHuntCnt(): number {
        let cnt: number = 2;
        let vipLevel = playerLogic.getPlayer().getVipLevel();
        let config = vipconfig.find(a => a.viplevel == vipLevel);
        if (config) {
            cnt += config.factionboss;
        }
        return cnt;
    }

    hasPermission(permission: string): boolean {
        let job = playerLogic.getPlayer().getUnionJob();
        let config = factionconfig[job - 1];
        return config[permission] != 0
    }

    getCreateUnionCost(): Good {
        let vo = new GoodVO();
        vo.propId = Good.GoodId.Diamond;
        vo.amt = defaultConfigMap.guildcreateconsum.value;
        return new Good(vo);
    }

    getChangeNameCost(): Good {
        let vo = new GoodVO();
        vo.propId = Good.GoodId.Diamond;
        vo.amt = defaultConfigMap.factionresetname.value;
        return new Good(vo);
    }

    isNameValid(name: string): { result: boolean, message?: string } {
        if (name.length == 0) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_input.Value, { name: stringConfigMap.key_union_name.Value })
            }
        }
        if (stringUtils.strlen(name) > 12) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_content_max_length.Value,
                    { name: stringConfigMap.key_union_name.Value, count1: 6, count2: 12 })
            }
        }
        return { result: true }
    }

    isNoticeValid(notice: string): { result: boolean, message?: string } {
        if (notice.length == 0) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_input.Value, { name: stringConfigMap.key_union_notice.Value })
            }
        }
        if (stringUtils.strlen(notice) > 30) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_content_max_length.Value,
                    { name: stringConfigMap.key_union_notice.Value, count1: 15, count2: 30 })
            }
        }
        return { result: true }
    }

    isMailTitleValid(title: string): { result: boolean, message?: string } {
        if (title.length == 0) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_input.Value, { name: stringConfigMap.key_mail_title.Value })
            }
        }
        if (stringUtils.strlen(title) > 20) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_content_max_length.Value,
                    { name: stringConfigMap.key_mail_title.Value, count1: 10, count2: 20 })
            }
        }
        return { result: true }
    }

    isMailContentValid(content: string): { result: boolean, message?: string } {
        if (content.length == 0) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_input.Value, { name: stringConfigMap.key_mail_content.Value })
            }
        }
        if (stringUtils.strlen(content) > 60) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_content_max_length.Value,
                    { name: stringConfigMap.key_mail_content.Value, count1: 30, count2: 60 })
            }
        }
        return { result: true }
    }

    get unionHuntMonster(): Monster {
        return this._unionHuntMonster;
    }

    set unionHuntMonster(monster: Monster) {
        this._unionHuntMonster = monster;
        this._unionHuntMonsterHP = battleLogic.getHuntMonsterHP(monster.getMonsterId());
    }

    get unionHuntMonsterHP(): number {
        return this._unionHuntMonsterHP;
    }

    get unionHuntMonsterType(): number {
        return this._unionHuntMonsterType;
    }

    set unionHuntMonsterType(type: number) {
        this._unionHuntMonsterType = type;
    }

    get unionHuntRecord(): HuntRecordVO[] {
        return this._unionHuntRecord;
    }

    get unionJoinTimestamp(): number {
        return this._unionJoinTimestamp;
    }

    resetUnionHunt() {
        this._unionHuntHurt = 0;
        this._unionHuntRewards = [];
        this._unionHuntExtraRewards = [];
    }

    getUnionHuntBoss(type: number) {
        return this._unionHuntBoss.find(a => a.type == type);
    }

    getUnionHuntBossById(bossId: string) {
        return this._unionHuntBoss.find(a => a.bossId == bossId);
    }

    addUnionHuntReward(boxId: number) {
        let rewardId = goodsConfig.find(a => a.parameterid == boxId).effect;
        let boxReward = boxrewardconfig.where(a => a.RewardId == rewardId);
        let weight = this._unionHuntSeedRandom.random();
        let rd = 0;
        let rewards = [];
        for (let i = 0; i < boxReward.length; i++) {
            rd += boxReward[i].Weight / this._getTotalWeight(boxReward);
            if (weight <= rd) {
                let reward = {};
                reward["objId"] = this._getObjId(boxReward[i].Item);
                reward["propId"] = boxReward[i].Item;
                reward["amt"] = boxReward[i].Counts;
                if (this._getObjId(boxReward[i].Item) == "equip") {
                    let equip = equipConfig.find(a => a.Id == boxReward[i].Item);
                    reward["lv"] = 1;
                    reward["rank"] = equip.Rank;
                    reward["campBonus"] = 0;
                }
                rewards.push(reward);
                this._unionHuntRewards.push(reward);
                weight = this._unionHuntSeedRandom.random();
                if (weight <= defaultConfigMap.factiondiamond.value) {
                    let rd2 = 0;
                    let diamondboxdrop = JSON.parse(defaultConfigMap.diamondboxdrop.value);
                    for (let index = 0; index < diamondboxdrop.length; index++) {
                        let item = diamondboxdrop[index][0];
                        let rdValue = diamondboxdrop[index][1];
                        rd2 += Number(rdValue);
                        if (weight <= rd2 * defaultConfigMap.factiondiamond.value) {
                            this._unionHuntExtraRewards.push(Number(item));
                            let reward2 = {};
                            reward2["objId"] = "goods";
                            reward2["propId"] = Number(item);
                            reward2["amt"] = 1;
                            rewards.push(reward2);
                            break;
                        }
                    }
                }
                return rewards;
            }
        }
    }

    protected _getTotalWeight(boxreward: boxrewardconfigRow[]) {
        let weight: number = 0;
        for (let reward of boxreward) {
            weight += reward.Weight;
        }
        return weight;
    }

    getUnionHuntWipeData() {
        return this._unionHuntWipeData;
    }

    protected _getObjId(itemId: number) {
        if (itemId >= 10000 && itemId <= 19999) {
            return "goods";
        } else if (itemId >= 20000 && itemId <= 29999) {
            return "hero";
        } else if (itemId >= 30000 && itemId <= 39999) {
            return "equip";
        }
        return "";
    }

    set unionHuntHurt(value: number) {
        if (value > this._unionHuntHurt) {
            this._unionHuntHurt = value;
        }
    }

    get unionHuntHurt(): number {
        return this._unionHuntHurt;
    }

    set unionHuntBossId(bossId: string) {
        this._unionHuntBossId = bossId;
    }

    get unionHuntBossId(): string {
        return this._unionHuntBossId;
    }

    get unionHuntRewards(): any[] {
        return this._unionHuntRewards;
    }

    set unionHuntRewards(rewards: any[]) {
        this._unionHuntRewards = rewards;
    }

    get unionHuntExtraRewards(): any[] {
        return this._unionHuntExtraRewards;
    }

    set unionHuntExtraRewards(rewards: any[]) {
        this._unionHuntExtraRewards = rewards;
    }

    async doRefreshUnion() {
        let protos = await this._gm.request<GuildVO[]>(GameProxy.apiguildfindGuild, this.getUnion().getId().toString());
        this.getUnion().update(protos[0]);
    }

    async doCreateUnion(avatarIndex: number, unionName: string) {
        let good = this.getCreateUnionCost();
        if (bagLogic.getGood(good.getIndex()).getAmount() < good.getAmount()) {
            throw new ToastError(stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() }));
        }

        let ret = this.isNameValid(unionName);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let req = new GuildCreateReq();
        req.avatar = avatarIndex.toString();
        req.name = unionName;
        let proto = await this._gm.request<GuildVO>(GameProxy.apiguildcreateGuild, req);
        this._union = new Union(proto);
        playerLogic.getPlayer().setUnionId(this._union.getId());
        playerLogic.getPlayer().setUnionName(this._union.getName());
        playerLogic.getPlayer().setUnionJob(UnionJob.President);
        chatSocket.reConnectGroup();

        bagLogic.changeGoodAmount(good.getIndex(), -good.getAmount());
        commitLogic.costDiamond(good.getAmount(), DiamondCost.createUnion);
    }

    async doOperateApply(users: User[], isAgree: boolean): Promise<{ newList: User[], ignoreList: User[] }> {
        let req = new GuildApplyOptReq();
        req.agree = isAgree;
        req.targetIds = [];
        for (let user of users) {
            req.targetIds.push(user.getRoleId());
        }
        let proto = await this._gm.request<GuildOptVO>(GameProxy.apiguildoptApply, req);
        let newList: User[] = [];
        for (let vo of proto.newList) {
            newList.push(new User(vo));
        }
        let ignoreList: User[] = [];
        for (let vo of proto.hasGuildList) {
            ignoreList.push(new User(vo));
        }
        if (isAgree) {
            unionLogic.doRefreshUnion();
        }
        return { newList: newList, ignoreList: ignoreList };
    }

    canJoinUnion(union: Union): {
        result: boolean,
        message?: string
    } {
        if (playerLogic.getPlayer().getLevel() < union.getEnterLevel()) {
            return {
                result: false,
                message: stringConfigMap.key_union_level_more_than.Value
            }
        }

        if (union.getMembers().length == union.getMaxMembers()) {
            return {
                result: false,
                message: stringConfigMap.key_union_member_full.Value
            }
        }

        return { result: true }
    }

    async doJoinUnion(union: Union): Promise<Union[]> {
        let ret = this.canJoinUnion(union);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let protos = await this._gm.request<GuildVO[]>(GameProxy.apiguildsubmitApply, union.getId());
        let unions = [];
        if (protos) {
            for (let proto of protos) {
                unions.push(new Union(proto));
            }
        }
        else {
            playerLogic.getPlayer().setUnionId(union.getId());
            playerLogic.getPlayer().setUnionName(union.getName());
            playerLogic.getPlayer().setUnionJob(UnionJob.Member);
            chatSocket.reConnectGroup();
        }
        return unions;
    }

    async doChangeName(name: string) {
        if (this.getUnion().getName() == name) {
            throw new ToastError(stringConfigMap.key_same_union_name.Value);
        }

        let good = this.getChangeNameCost();
        if (bagLogic.getGood(good.getIndex()).getAmount() < good.getAmount()) {
            throw new ToastError(stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() }));
        }

        let ret = this.isNameValid(name);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let proto = await this._gm.request<GuildVO>(GameProxy.apiguildrenameGuild, name);
        this.getUnion().setName(proto.name);

        let union = this.getUnion();
        let members = union.getMembers();
        for (let member of members) {
            if (member.getRoleId() == playerLogic.getPlayer().getRoleId()) {
                member.setUnionName(proto.name);
                break;
            }
        }
        playerLogic.getPlayer().setUnionName(proto.name);

        bagLogic.changeGoodAmount(good.getIndex(), -good.getAmount());
        commitLogic.costDiamond(good.getAmount(), DiamondCost.changeGuildName);
    }

    async doChangeAvatar(avatarIndex: number) {
        if (this.getUnion().getAvatar() == avatarIndex) {
            return;
        }
        await this._gm.request(GameProxy.apiguildchangeAvatar, avatarIndex.toString());
        this.getUnion().setAvatar(avatarIndex);
    }

    async doChangeEnterLevel(level: number) {
        if (this.getUnion().getEnterLevel() == level) {
            return;
        }

        let proto = await this._gm.request<GuildVO>(GameProxy.apiguildchangeEnterLv, level);
        this.getUnion().setEnterLevel(proto.enterLv);
    }

    async doChangeEnterMode(mode: UnionEnterMode) {
        if (this.getUnion().getEnterMode() == mode) {
            return;
        }

        let proto = await this._gm.request<GuildVO>(GameProxy.apiguildchangeEnterMode, mode);
        this.getUnion().setEnterMode(proto.enterMode);
    }

    async doChangeNotice(content: string) {
        if (this.getUnion().getNotice() == content) {
            return;
        }

        let ret = this.isNoticeValid(content);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        if (this.getUnion().getNotice() == content) {
            return;
        }

        let proto = await this._gm.request<GuildVO>(GameProxy.apiguildchangeNotice, content);
        this.getUnion().setNotice(proto.notice);
    }

    async doSendMail(title: string, content: string) {
        let ret = this.isMailTitleValid(title);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        ret = this.isMailContentValid(content);
        if (!ret.result) {
            throw new ToastError(ret.message);
        }

        let req = new GuildMailSendReq();
        req.title = title;
        req.content = content;
        await this._gm.request(GameProxy.apiguildsendGuildMail, req);
    }

    async doExitUnion() {
        await this._gm.request(GameProxy.apiguildexitFromGuild);
        playerLogic.getPlayer().setUnionId(0);
        udgLogic.clearUdgData();
        chatSocket.reConnectGroup();
    }

    async doDismissUnion(): Promise<string> {
        let name = playerLogic.getPlayer().getUnionName();
        await this._gm.request(GameProxy.apiguilddisbanGuild);
        playerLogic.getPlayer().setUnionId(0);
        udgLogic.clearUdgData();
        chatSocket.reConnectGroup();
        return name;
    }

    async doAppointment(user: User) {
        let req = new AppointGuildReq();
        req.targetRoleId = user.getRoleId();
        if (user.getUnionJob() == UnionJob.Member) {
            req.jobId = UnionJob.VicePresident;
        }
        else {
            req.jobId = UnionJob.Member;
        }
        await this._gm.request(GameProxy.apiguildappointGuildJob, req);

        let member = this._union.getMember(user.getRoleId());
        if (member) { member.setUnionJob(req.jobId); }
    }

    async doTransferPresident(user: User) {
        await this._gm.request(GameProxy.apiguildtransGuildBoss, user.getRoleId());
        let unionJob = user.getUnionJob();
        let union = this.getUnion();
        let member = union.getMember(user.getRoleId());
        if (member) { member.setUnionJob(UnionJob.President); }

        let members = union.getMembers();
        for (let member of members) {
            if (member.getRoleId() == playerLogic.getPlayer().getRoleId()) {
                member.setUnionJob(unionJob);
                break;
            }
        }
        playerLogic.getPlayer().setUnionJob(unionJob);
    }

    async doKickout(user: User) {
        await this._gm.request(GameProxy.apiguildkickFromGuild, user.getRoleId());
        await this.doRefreshUnion();
    }

    async doGetBossInfo() {
        this._unionHuntBoss = await this._gm.request<HuntBossVO[]>(GameProxy.apihuntgetBossInfo, [1, 2]);
    }

    async doStartHuntJH() {
        let hunterBoss = await this._gm.request<HuntBossVO>(GameProxy.apihuntstartHuntJH, null);
        if (!hunterBoss) {
            throw new ToastError("毒箭木开启失败");
        }
        let bossJH = this._unionHuntBoss.find(a => a.type == hunterBoss.type);
        if (!bossJH) {
            this._unionHuntBoss.push(hunterBoss);
        } else {
            bossJH = hunterBoss;
        }
        unionLogic.getUnion().setCurActiveScore(unionLogic.getUnion().getCurActiveScore() - defaultConfigMap.huntbossopen.value);
        gm.toast(stringConfigMap.key_auto_551.Value);
    }

    async doGetHuntRecord() {
        let bossInfo = this.getUnionHuntBoss(this._unionHuntMonsterType);
        if (!bossInfo) {
            throw new ToastError("boss不存在");
        }
        let huntRecordReq = new HuntRecordReq();
        huntRecordReq.boosId = bossInfo.bossId;
        huntRecordReq.type = this._unionHuntBoss.find(a => a.bossId == bossInfo.bossId).type;
        this._unionHuntRecord = await this._gm.request<HuntRecordVO[]>(GameProxy.apihuntgetHuntRecord, huntRecordReq);
    }

    async doBuyBossCount(type: number, battleDiamond: number) {
        let boss = this._unionHuntBoss.find(a => a.type == type);
        let req = new HuntHitReq();
        req.bossId = boss.bossId;
        req.type = type;
        let proto = await this._gm.request(GameProxy.apihuntbuyBossCount, req);
        if (proto) {
            boss.hitCountRemain++;
            boss.buyCount++;
            if (battleDiamond > 0) {
                bagLogic.getGood(GoodId.Diamond).changeAmount(-battleDiamond);
            }
        }
    }

    async doCheckHunt(type: number) {
        this._unionHuntBossId = this._unionHuntBoss.find(a => a.type == type).bossId;
        this._unionHuntSeed = await this._gm.request<string>(GameProxy.apihuntcheckHunt, type);
        this._unionHuntSeedRandom = new SeedUtils(this._unionHuntSeed);
    }

    async doHuntResult(contribution: rpgfight.HeroContributionStatistic[], skills: any, type: number, wipe: boolean = false) {
        let report = {};
        if (!wipe) {
            let heroList = battleLogic.getHeroList();
            for (let hero of heroList) {
                for (let skill of hero.skillList) {
                    delete skill.triggerTree;
                }
                delete hero.attackSkill.triggerTree;
            }
            report["heroList"] = heroList;
            report["result"] = contribution;
            report["skills"] = skills;
            report["scene"] = battleLogic.battleData.sceneConfig;
        }
        let huntHitReq = new HuntHitReq();
        huntHitReq.result = report;
        huntHitReq.seed = this._unionHuntSeed;
        huntHitReq.totalHurt = this._unionHuntHurt.toString();
        huntHitReq.type = type;
        huntHitReq.sweep = wipe;
        huntHitReq.bossId = this._unionHuntBossId;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apihuntgoHunt, huntHitReq);
        if (proto) {
            playerLogic.addCards(proto);
            this._unionHuntExtraRewards = [];
            this._unionHuntRewards = [];
            if (proto.rewards) {
                for (let reward of proto.rewards) {
                    if (reward["propId"] != 10001 && reward["propId"] != 10068) {
                        let goodConfig = goodsConfig.find(a => a.parameterid == reward["propId"]);
                        if (goodConfig && goodConfig.type == 27) {
                            this._unionHuntExtraRewards.push(reward["propId"]);
                            bagLogic.getGood(reward["propId"]).changeAmount(Number(reward["amt"]));
                        } else {
                            this._unionHuntRewards.push(reward);
                        }
                    }
                    if (reward["propId"] == 10001 || reward["propId"] == 10068 || reward["propId"] == 10002) {
                        bagLogic.getGood(reward["propId"]).changeAmount(Number(reward["amt"]));
                    }
                }
            }
        }
        let unionHuntBoss = this._unionHuntBoss.find(a => a.type == type);
        if (unionHuntBoss) {
            unionHuntBoss.hitCountRemain = Math.max(0, unionHuntBoss.hitCountRemain - 1);
        }
        return proto;
    }

    /** 服务端公会变更socket推送*/
    doServerGuideChange(data: { type: number, guildId: number }) {
        //{"type":int,"guildId":long}
        //type:对应状态，0离开,1进入 guildId:对应公会ID
        if (data.type == 0) {
            playerLogic.getPlayer().setUnionId(0);
            playerLogic.getPlayer().updateCommonAdd([], CommonAdd.statuePart1);
            playerLogic.getPlayer().updateCommonAdd([], CommonAdd.statuePart2);
            playerLogic.getPlayer().updateCommonAdd([], CommonAdd.statuePart3);
            playerLogic.getPlayer().setPowerDirty();
            heroLogic.updateHeroCommonAdd();
            udgLogic.clearUdgData();
            this.closeUnionPanels();
        }
        else if (data.type == 1) {
            playerLogic.getPlayer().setUnionId(data.guildId);
        }
        else {
            return;
        }
        chatSocket.reConnectGroup();
    }

    // 被踢出公会后,关闭相关界面
    closeUnionPanels() {
        let panels: string[] = [
            "UnionHallNewPanel",
            "RedPackPanel"
        ]
        for (let i = 0; i < panels.length; i++) {
            BasePanel.closePanel(panels[i]);
        }
    }

    /** 雕像加成变更socket推送*/
    doUnionStatueChange(data: GuildStatuePartBO) {
        if (this.getUnion() && this.getUnion().statue) {
            this.getUnion().statue.updateStatuePart(data);
        }
    }

    async doGetHuntWipe() {
        let wipeProto = await this._gm.request<{ [key: string]: object }>(GameProxy.apiutilgetCloudObject, [this._unionHuntWipeKey]);
        if (wipeProto) {
            this._unionHuntWipeData = wipeProto[this._unionHuntWipeKey]["data"];
            this._unionHuntHurt = this._unionHuntWipeData["totalHurt"];
        }
    }

    doPutHuntWipe(totalCnt: number) {
        let req = new CloudObjectReq();
        req.expire = 0;
        req.key = this._unionHuntWipeKey;
        let data = {};
        data["totalHurt"] = this.unionHuntHurt;
        data["totalCnt"] = totalCnt;
        req.objData = { data: data };
        this._gm.request(GameProxy.apiutilsetCloudObject, [req], GameProxy, true);
    }

    async doImpeach(userId: string) {
        await this._gm.request(GameProxy.apiguildimpeachGuildBoss, userId);
    }

    // 雕像信息获取
    async statueReq() {
        let proto = await this._gm.request<GuildStatueBO>(GameProxy.apiguildgetGuildStetueInfo);
        this.getUnion().statue.updateStatue(proto);
    }

    // 雕像强化
    async statueStrengthenReq(type: number, data: any) {
        let param = new GuildStatueStrengReq;
        param.type = type;
        param.give = data;
        let proto = await this._gm.request<GuildStrengBO>(GameProxy.apiguildstrengStatue, param);
        if (proto.info) {
            this.getUnion().statue.updateStatue(proto.info);
        }
        return proto.retComsume;
    }

    // 雕像视频强化
    async statueVideoStrengthenReq(type: number) {
        let proto = await this._gm.request<GuildStatuePartBO>(GameProxy.apiguildvideoStatue, type);
        if (this.getUnion() && this.getUnion().statue) {
            this.getUnion().statue.updateStatuePart(proto);
        }
    }

    // 雕像日志
    async statueLogReq() {
        let proto = await this._gm.request<GuildStatueRecVO[]>(GameProxy.apiguildgetstatuelog);
        return proto;
    }

    // 公会互助
    async guildHelpSendReq(roleId: string) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiguildhelpSend, roleId);
        gm.getReward(proto);
        if (proto) {
            this.getUnion().updateRecHelpTimes(roleId, proto.extra[0] as any);
            this.getUnion().addSendHelpTimes(playerLogic.getPlayer().getRoleId(), 1);
        }
    }

    // 转盘信息
    async zhuanpanReq() {
        let proto = await this._gm.request<GuildTableInfoVO>(GameProxy.apiguildturnTableInfo);
        this.zhuanpanCircle = proto.roleTableCount || 0;
    }

    // 转转盘
    async zhuanpanGo(video: boolean = false) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiguildchoseTable, { useVideo: video });
        this.zhuanpanCircle += 1;
        return proto;
    }

    public async getUnionSimple(id: number) {
        if (this._unionCache[id]) { return this._unionCache[id]; }
        if (id <= 0) { return null; }
        let param = new GuildSimpleReq;
        param.guildIds = [id];
        param.needMember = false;

        let proto = await this._gm.request<GuildSimpleVO[]>(GameProxy.apiguildfindGuildSimple, param);
        if (proto) {
            for (let i = 0; i < proto.length; i++) {
                this._unionCache[proto[i].id] = new UnionSimple(proto[i]);
            }
        }
        return this._unionCache[id];
    }
}

let unionLogic = new UnionLogic();
export default unionLogic;