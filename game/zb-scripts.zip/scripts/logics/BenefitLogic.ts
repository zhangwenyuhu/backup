import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from '../manager/GameManager';
import cm from '../manager/ConfigManager';
import growUpConfig from "../configs/growUpConfig";
import storeConfig, { storeConfigRow } from "../configs/storeConfig";
import GameProxy, { ResourceVO, CloudObjectReq } from "../proxy/GameProxy";
import rechargeLogic from "./RechargeLogic";
import playerLogic from "./PlayerLogic";
import timeGiftConfig, { timeGiftConfigRow } from "../configs/timeGiftConfig";
import timeUtils from "../utils/TimeUtils";
import costlevelconfig from "../configs/costlevelconfig";
import bagLogic from "./BagLogic";
import Good from "../data/card/Good";
import heroLogic from "./HeroLogic";
import Hero from "../data/card/Hero";
import heroLevelConfig from "../configs/heroLevelConfig";
import missionLogic from "./MissionLogic";
import stagedropconfig from "../configs/stagedropconfig";
import surprisegiftconfig, { surprisegiftconfigRow } from "../configs/surprisegiftconfig";
import Equip from "../data/card/Equip";
import heroRankConfig from "../configs/heroRankConfig";
import localLogic, { localIndex } from "./LocalLogic";
import commitLogic, { DiamondSource } from "./CommitLogic";

export enum BenefitStoreType {
    Growup = 4,
    NewPlayer = 5,
    Surprise = 6,
}

enum PopGiftType {
    other = 0,
    dust = 1,
    weapon = 2,
    hat = 3,
    dustAndequip = 4,
    card = 5,
}

export const BenefitLimit = 7 * 24 * 3600 * 1000;
const benefitCloudPre = `benefit_`;
const popGiftTimesKey = "pop_gift";
const popGiftTotalKey = "pop_total";
const popGiftIgnoreKey = "pop_ignore";

/* 限时福利: 新手礼包,成长礼包,惊喜礼包 */
export class BenefitLogic extends BaseLogic {
    private _benefitCfgs: { [key: number]: storeConfigRow } = {};
    private _cloudData: { [key: number]: any } = {};        // 惊喜礼包数据
    private _redRead: { [key: number]: boolean } = {};

    init(gm: IGameManager) {
        super.init(null, gm);

        this.initCfgs();
        this.cloudDataReq();
    }

    private initCfgs() {
        let cfgs = storeConfig.filter((v, i, a) => {
            return v.type == BenefitStoreType.Growup || v.type == BenefitStoreType.NewPlayer || v.type == BenefitStoreType.Surprise;
        });
        this._benefitCfgs = {};
        cfgs.forEach((v, i, a) => {
            this._benefitCfgs[v.Id] = v;
        })
    }

    setRedRead(read: boolean = true) {
        localLogic.setData(localIndex.grownupRead, read);
    }

    getRedRead(): boolean {
        return localLogic.getData(localIndex.grownupRead);
    }

    growupGiftRed(): boolean {
        let bRed: boolean = false;
        if (this.isGrowupValid()) {
            let nowStage = this.getNowStageId();
            for (let i = 0; i < growUpConfig.length; i++) {
                let cfg = growUpConfig[i];
                if (nowStage >= cfg.stage && !this.isGotReward(cfg.Id)) {
                    bRed = true;
                    break;
                }
            }
        }
        return bRed;
    }

    async recvGrowupGiftReq(param: number) {
        let proto = await gm.request<ResourceVO>(GameProxy.apiStorerecvGrowUp, param);
        gm.getReward(proto, true);
        commitLogic.commitReward(proto, DiamondSource.giftGrowup);
    }

    public getBenefitStoreCfgs(type: BenefitStoreType): storeConfigRow[] {
        let tmp: storeConfigRow[] = [];
        Object.keys(this._benefitCfgs).forEach((v, i, a) => {
            if (this._benefitCfgs[v].type == type) {
                tmp.push(this._benefitCfgs[v]);
            }
        })
        return tmp;
    }

    resetAll() {

    }

    // -- 新手礼包 -- //
    public isNewPlayerValid(): boolean {
        // 新手礼包是否显示 1 && 2
        // 1.玩家账号创建15天内
        // 2.存在可购买的新手礼包
        let creatTs: number = playerLogic.getPlayer().getCreateTs();
        let nowTs: number = gm.getCurrentTimestamp()
        let sec = nowTs - creatTs;
        let valid: boolean = sec < BenefitLimit;

        let cfgs = this.getBenefitStoreCfgs(BenefitStoreType.NewPlayer);
        let canBuy = cfgs.some((v, i, a) => { return rechargeLogic.getBuyCount(v.Id) < 1; })
        return valid && canBuy;
    }

    get newPlayerRemaintime(): number {
        let sec = BenefitLimit / 1000 - (gm.getCurrentTimestamp() - playerLogic.getPlayer().getCreateTs()) / 1000;
        sec = sec > 0 ? sec : 0;
        return sec;
    }

    // -- 新手礼包 -- //

    // -- 惊喜礼包 -- //
    public isSurpriseValid(): boolean {
        let cfgs = this.getBenefitStoreCfgs(BenefitStoreType.Surprise);
        cfgs = cfgs.filter((v, i, a) => {
            return this.isSurpriseGiftValid(v.Id);
        })
        return cfgs.length > 0;
    }

    public get surpriseRemaintime(): number {
        let storeCfgs = this.getBenefitStoreCfgs(BenefitStoreType.Surprise);
        storeCfgs = storeCfgs.filter((v: storeConfigRow, i: number, a: storeConfigRow[]) => {
            return benefitLogic.isSurpriseGiftValid(v.Id);
        });

        let remainTime: number = 0;
        for (let config of storeCfgs) {
            let data = benefitLogic.getSurpriseGiftCloudData(config.Id)
            let cfg = cm.getSurpriseGiftConfig(data.id);
            let ts = data.ts;
            ts = ts > 0 ? ts : 0;
            let sec = cfg.time * 3600 - (gm.getCurrentTimestamp() - ts) / 1000;
            //remainTime = Math.max(sec, remainTime);
            remainTime = remainTime == 0 ? sec : Math.min(sec, remainTime);
        }
        return remainTime;
    }

    // 是否是新版本的惊喜礼包
    isNewSurpriseGift(storeId: number): boolean {
        let cfg = cm.getStoreConfig(storeId);
        let goodCfg = cm.getGoodConfig(cfg.item);
        return goodCfg.type == 41;
    }

    // 激活礼包检查
    async checkSurpriseGift(type: number, value: number) {
        let cfg = timeGiftConfig.find((a) => { return a.type == type && a.parameter == value; })
        if (cfg) {
            console.warn(`符合惊喜礼包触发条件 type:${type} value:${value}`);
        }
        await this.cloudCommit(cfg);
    }
    // 测试激活礼包
    async testCheckSurpriseGift(id: number) {
        let cfg = cm.getTimeGiftConfig(id);
        console.warn(`触发惊喜礼包条件 type:${cfg.type} value:${cfg.parameter}`);
        await this.cloudCommit(cfg);
    }
    // 礼包激活信息请求
    async cloudDataReq() {
        let cfgs = this.getBenefitStoreCfgs(BenefitStoreType.Surprise);
        let param: string[] = cfgs.map((v, i, a) => { return benefitCloudPre + v.Id });
        if (param.length == 0) { return; }
        param.push(this.getNowPopGiftTimesKey());
        param.push(popGiftTotalKey);
        param.push(popGiftIgnoreKey);
        let proto = await gm.request<{ [key: string]: any }>(GameProxy.apiutilgetCloudObject, param);
        this._cloudData = proto;
    }
    // 存储激活信息
    async cloudCommit(cfg: timeGiftConfigRow): Promise<number> {
        if (!cfg) { return 0; }
        console.warn("满足惊喜礼包激活条件,开始礼包查找!");

        let surpriseCfgId: number = this.recommendPopGift(cfg);
        console.warn("推荐的惊喜礼包Id: " + surpriseCfgId);

        let surpriseCfg: surprisegiftconfigRow = this.getSurpriseGiftCfg(surpriseCfgId);
        // 找到充值表ID
        let storeId: number = surpriseCfg ? surpriseCfg.storeID : 0;
        if (!storeId || storeId <= 0) {
            console.error("找到的store表id为空");
            return 0;
        }
        // 限时时间
        let expireTime: number = surpriseCfg.time;

        let param = new CloudObjectReq();
        param.key = benefitCloudPre + `${storeId}`;
        param.objData = { valid: true, ts: gm.getCurrentTimestamp(), id: surpriseCfg.ID, pop: cfg.Id };
        param.expire = expireTime * 3600 * 1000;

        let param1 = new CloudObjectReq();
        let curPopTime = this.getTotalPopTimes() < 1 ? 0 : this.getPopGiftTimes() + 1;
        param1.key = this.getNowPopGiftTimesKey();
        param1.objData = { popTimes: curPopTime };
        param1.expire = 0;

        let param2 = new CloudObjectReq();
        param2.key = popGiftTotalKey;
        param2.objData = { popTimes: this.getTotalPopTimes() + 1 };
        param2.expire = 0;

        let param3 = new CloudObjectReq();
        param3.key = popGiftIgnoreKey;
        param3.objData = this.getPopedGift();
        param3.expire = 0;
        let proto = await gm.request<{ [key: string]: any }>(GameProxy.apiutilsetCloudObject, [param, param1, param2, param3]);
        if (!this._cloudData) { this._cloudData = []; }
        Object.keys(proto).forEach((v, i, a) => {
            this._cloudData[v] = proto[v];
        })

        if (storeId > 0) {
            gcc.core.showLayer("prefabs/panel/benefit/SurpriseGiftPanel", { data: { Id: storeId } });
        }
        // 统计激活惊喜礼包
        this.logPopGift(cfg, surpriseCfgId);
        localLogic.setData(localIndex.surpriseGiftRead, false);
        return storeId;
    }
    // 购买后清除激活的该项惊喜礼包
    async rmCloudDataReq(id: number) {
        // 统计购买
        this.logBuyPopGift(id);

        // 清除消费等级和进度对应的强制推荐列表
        let key: string = benefitCloudPre + id;
        let data = this._cloudData[key];
        if (data) {
            this.clearGiftPoped(this.getPayLevel(), data.pop);
            await this.giftPopedCommit();
        }

        // 清除云记录
        delete this._cloudData[key];
        this._cloudData[key] = null;
        await gm.request<number>(GameProxy.apiutilrmCloudObject, [key]);
        await this.cloudDataReq();
    }
    // 惊喜礼包是否被激活
    public isSurpriseGiftValid(storeId: number): boolean {
        let valid: boolean = false;
        let key: string = benefitCloudPre + storeId;
        if (this._cloudData && this._cloudData[key]) {
            let ts = this._cloudData[key].ts;
            let cfg = cm.getSurpriseGiftConfig(this._cloudData[key].id);
            if (!this.isNewSurpriseGift(storeId)) {
                return false;
            }
            if (!cfg) { return false; }
            ts = ts > 0 ? ts : 0;
            let sec = cfg.time * 3600 - (gm.getCurrentTimestamp() - ts) / 1000;
            return sec > 0;
        }
        return valid;
    }
    // 惊喜礼包数据
    public getSurpriseGiftCloudData(storeId: number) {
        let key: string = benefitCloudPre + storeId;
        if (this._cloudData) {
            return this._cloudData[key];
        }
        return null;
    }
    // 获取玩家的消费等级
    getPayLevel(): number {
        let level: number = 1;
        let money: number = rechargeLogic.getPayMoney();
        let cfgs = costlevelconfig
        for (let i = 0; i < cfgs.length; i++) {
            if (cfgs[i].costmoney[0] <= money && cfgs[i].costmoney[1] >= money) {
                level = cfgs[i].costlevel;
            }
        }
        return level;
    }
    getNowPopGiftTimesKey() {
        return benefitCloudPre + popGiftTimesKey + this.getPayLevel();
    }
    // 获取强制推荐的礼包类型数据
    getPopedGift() {
        let data: { [key: string]: number[] } = {};
        if (this._cloudData && this._cloudData[popGiftIgnoreKey]) {
            data = this._cloudData[popGiftIgnoreKey];
            data = data ? data : {};
        }
        return data;
    }
    getGiftPopedKey(payLevel: number, gear: number): string {
        return `${payLevel}-${gear}`;
    }
    isGiftPoped(payLevel: number, gear: number, type: PopGiftType): boolean {
        let data = this.getPopedGift();
        let key = this.getGiftPopedKey(payLevel, gear);
        if (data && data[key]) {
            let index = data[key].findIndex((a) => { return a == type; })
            return index >= 0;
        }
        return false;
    }
    setGiftPoped(payLevel: number, gear: number, type: PopGiftType) {
        let key = popGiftIgnoreKey;
        if (this._cloudData) {
            if (!this._cloudData[key]) { this._cloudData[key] = {}; }

            let data = this._cloudData[key];
            let popedKey = this.getGiftPopedKey(payLevel, gear);
            if (!data[popedKey]) { data[popedKey] = []; }

            let index = data[popedKey].findIndex((a) => { return a == type; })
            if (index < 0) { data[popedKey].push(type); }

            if (data[popedKey].length == PopGiftType.card) {
                console.warn("五种类型都强制推荐过,重置列表为空.")
                data[popedKey] = [];
            }
        }
    }
    clearGiftPoped(payLevel: number, gear: number) {
        let key = popGiftIgnoreKey;
        if (this._cloudData) {
            if (!this._cloudData[key]) { this._cloudData[key] = {}; }

            let data = this._cloudData[key];
            let popedKey = this.getGiftPopedKey(payLevel, gear);
            data[popedKey] = [];
        }
    }
    async giftPopedCommit() {
        let param = new CloudObjectReq();
        param.key = popGiftIgnoreKey;
        param.objData = this.getPopedGift();
        param.expire = 0;
        let proto = await gm.request<{ [key: string]: any }>(GameProxy.apiutilsetCloudObject, [param]);
        if (!this._cloudData) { this._cloudData = []; }
        Object.keys(proto).forEach((v, i, a) => {
            this._cloudData[v] = proto[v];
        })
    }
    // 获取总的弹出次数
    getTotalPopTimes(): number {
        let times: number = 0;
        let key = popGiftTotalKey
        if (this._cloudData && this._cloudData[key]) {
            times = this._cloudData[key].popTimes || 0;
        }
        return times;
    }
    // 获取当前档位 惊喜礼包的已触发次数
    getPopGiftTimes(): number {
        let times: number = 0;
        let key = this.getNowPopGiftTimesKey();
        if (this._cloudData && this._cloudData[key]) {
            times = this._cloudData[key].popTimes || 0;
        }
        return times;
    }
    // 获取惊喜礼包的剩余时间
    getPopGiftLeftSec(storeId: number): number {
        let id = benefitLogic.getSurpriseGiftCloudData(storeId).id;
        let cfg = cm.getSurpriseGiftConfig(id);

        let ts = benefitLogic.getSurpriseGiftCloudData(storeId).ts;
        ts = ts > 0 ? ts : 0;
        let sec = cfg.time * 3600 - (gm.getCurrentTimestamp() - ts) / 1000;
        return sec;
    }
    // 推荐惊喜礼包
    recommendPopGift(cfg: timeGiftConfigRow): number {
        // 已消费等级
        let payLevel = this.getPayLevel();
        // 当前消费等级弹出次数
        let popTimes = this.getPopGiftTimes() + 1;
        // 条件进度
        let gear: number = cfg.gears;
        /* 
        if (this.getTotalPopTimes() < 1) {
            // 惊喜礼包第一次弹出时,固定礼包
            return 4;
        }*/
        if (this.isSmartPopGift()) {
            console.warn(`开始智能推荐 消费水平:${payLevel}  条件进度:${gear}`);
            return this.smartPopGift(payLevel, gear);
        } else {
            console.warn("开始匹配推荐");
            return this.matchPopGift(payLevel, gear);
        }
    }
    // 是否智能推荐惊喜礼包
    isSmartPopGift(): boolean {
        return this.getPayLevel() > 2;
    }
    // 匹配推荐惊喜礼包  消费等级和条件进度
    matchPopGift(payLevel: number, gear: number): number {
        console.warn(`匹配参数- 消费水平:${payLevel} 条件进度:${gear}`);
        let cfgId: number = 0;
        let cfgs = surprisegiftconfig.filter((v, i, a) => {
            return v.gears == gear && v.RichClass == payLevel;
        })
        if (cfgs.length <= 0) {
            console.error("匹配推荐未找到惊喜礼包");
        } else {
            cfgId = cfgs[0].ID;
        }
        return cfgId;
    }
    // 智能推荐惊喜礼包
    smartPopGift(payLevel: number, gear: number): number {
        let cfgs = this.getPopGifts(payLevel, gear);
        if (cfgs.length == 1) {
            console.warn("智能推荐 该消费等级当前条件进度只有一个礼包");
            return cfgs[0].ID;
        }

        let pops = this.getPopedGift();
        let nowPop: number[] = [];
        if (pops) {
            let key = this.getGiftPopedKey(payLevel, gear);
            nowPop = pops[key] ? pops[key] : [];
        }
        console.warn(`智能推荐 已强制推荐列表:${nowPop.join(`-`)}`);
        // 大粉尘->红武器->红帽子->红装粉尘->抽卡 顺序判断推荐礼包
        let cfgId: number = 0;

        // 特殊处理
        if (gear == 2 || gear == 3) {
            if (!this.isGiftPoped(payLevel, gear, PopGiftType.card)) {
                console.warn("特殊处理优先抽卡礼包推荐");
                cfgId = this.cardRecommend(payLevel, gear);
                this.setGiftPoped(payLevel, gear, PopGiftType.card);
                return cfgId;
            }
        }

        if (!this.isGiftPoped(payLevel, gear, PopGiftType.dust)) {
            console.warn("开始大粉尘礼包推荐");
            cfgId = this.dustRecommend(payLevel, gear);
            if (cfgId > 0) {
                this.setGiftPoped(payLevel, gear, PopGiftType.dust);
                return cfgId;
            }
        }

        if (!this.isGiftPoped(payLevel, gear, PopGiftType.weapon)) {
            console.warn("开始红色武器礼包推荐");
            cfgId = this.weaponRecommend(payLevel, gear);
            if (cfgId > 0) {
                this.setGiftPoped(payLevel, gear, PopGiftType.weapon);
                return cfgId;
            }
        }

        if (!this.isGiftPoped(payLevel, gear, PopGiftType.hat)) {
            console.warn("开始红色帽子礼包推荐");
            cfgId = this.hatRecommend(payLevel, gear);
            if (cfgId > 0) {
                this.setGiftPoped(payLevel, gear, PopGiftType.hat);
                return cfgId;
            }
        }

        if (!this.isGiftPoped(payLevel, gear, PopGiftType.dustAndequip)) {
            console.warn("开始红装粉尘礼包推荐");
            cfgId = this.equipAndDustRecommend(payLevel, gear);
            if (cfgId > 0) {
                this.setGiftPoped(payLevel, gear, PopGiftType.dustAndequip);
                return cfgId;
            }
        }

        if (!this.isGiftPoped(payLevel, gear, PopGiftType.card)) {
            console.warn("开始抽卡礼包推荐");
            cfgId = this.cardRecommend(payLevel, gear);
            this.setGiftPoped(payLevel, gear, PopGiftType.card);
        } else {
            // 强制推荐
            for (let i = PopGiftType.dust; i <= PopGiftType.card; i++) {
                if (!this.isGiftPoped(payLevel, gear, i)) {
                    cfgId = this.forceRecommend(payLevel, gear, i);
                    this.setGiftPoped(payLevel, gear, i);
                    console.warn("强制推荐: " + i);
                    break;
                }
            }
        }

        return cfgId;
    }
    // 强制推荐
    forceRecommend(payLevel: number, gear: number, type: PopGiftType): number {
        let cfgId: number = 0;
        // 通过消费等级和进度找到该类型所有礼包
        let cfgs = this.getPopGifts(payLevel, gear);
        let results = cfgs.filter((v, i, a) => { return v.gifttype == type; });
        if (results.length == 1) { cfgId = results[0].ID; }
        if (results.length > 1) {
            let index: number = Math.floor(Math.random() * results.length);
            cfgId = results[index].ID;
        }
        return cfgId;
    }
    // 大粉尘礼包推荐
    dustRecommend(payLevel: number, gear: number): number {
        // 玩家拥有的粉尘 小于 前5的英雄升级到下一级需要的粉尘数之和的一半,则推荐大粉尘礼包
        let cfgId: number = 0;
        let dustNum: number = this.getHasDustNum();
        let needDust: number = this.getTop5LevelUpNeedDust();
        console.warn(`大粉尘- 拥有:${dustNum} 需要:${needDust}`);
        if (dustNum > needDust * 0.5) { return 0; }
        // 通过消费等级和礼包类型找到 大粉尘礼包
        let cfgs = this.getPopGifts(payLevel, gear);
        let cfg = cfgs.find((a) => { return a.gifttype == PopGiftType.dust; });
        if (cfg) { cfgId = cfg.ID; }
        return cfgId;
    }
    // 武器红装资源礼包推荐
    weaponRecommend(payLevel: number, gear: number): number {
        // 前5的英雄存在非红色品阶的武器
        let cfgId: number = 0;
        let weapon: Equip = this.getTop5NotRedEquip(Equip.EquipPlace.Weapon);
        if (!weapon) { return 0; }
        console.warn(`找到非红武器:${weapon.getName()}`);

        // 根据消费等级和非红色武器的信息找到 红装礼包
        let cfgs = this.getPopGifts(payLevel, gear);
        cfgs = cfgs.filter((v, i, a) => { return v.gifttype == PopGiftType.weapon; });
        if (cfgs) {
            for (let i = 0; i < cfgs.length; i++) {
                if (this.hasSameTypeEquip(weapon, cfgs[i].GiftReward)) {
                    cfgId = cfgs[i].ID;
                    break;
                }
            }
        }
        return cfgId;
    }
    // 帽子红装资源礼包推荐
    hatRecommend(payLevel: number, gear: number): number {
        // 前5的英雄存在非红色品阶的帽子
        let cfgId: number = 0;
        let hat: Equip = this.getTop5NotRedEquip(Equip.EquipPlace.Helmet);
        if (!hat) { return 0; }
        console.warn(`找到非红帽子:${hat.getName()}`);

        // 根据消费等级和非红色帽子的信息找到 红装礼包
        let cfgs = this.getPopGifts(payLevel, gear);
        cfgs = cfgs.filter((v, i, a) => { return v.gifttype == PopGiftType.hat; });
        if (cfgs) {
            for (let i = 0; i < cfgs.length; i++) {
                if (this.hasSameTypeEquip(hat, cfgs[i].GiftReward)) {
                    cfgId = cfgs[i].ID;
                    break;
                }
            }
        }
        return cfgId;
    }
    // 红装粉尘礼包推荐
    equipAndDustRecommend(payLevel: number, gear: number): number {
        // 玩家拥有的粉尘 小于 前5的英雄升级到下一级需要的粉尘数之和,则推荐红装粉尘礼包
        let cfgId: number = 0;
        let dustNum: number = this.getHasDustNum();
        let needDust: number = this.getTop5LevelUpNeedDust();
        console.warn(`红装粉尘- 拥有:${dustNum} 需要:${needDust}`);
        if (dustNum > needDust) { return 0; }

        // 通过消费等级和礼包类型找到 红装粉尘礼包
        let cfgs = this.getPopGifts(payLevel, gear);
        let cfg = cfgs.find((a) => { return a.gifttype == PopGiftType.dustAndequip; });
        if (cfg) { cfgId = cfg.ID; }
        return cfgId;
    }
    // 抽卡礼包推荐
    cardRecommend(payLevel: number, gear: number): number {
        let cfgId: number = 0;
        // 通过消费等级和礼包类型找到 抽卡礼包
        let cfgs = this.getPopGifts(payLevel, gear);
        let cfg = cfgs.find((a) => { return a.gifttype == PopGiftType.card; });
        if (cfg) { cfgId = cfg.ID; }
        if (!cfg) {
            if (cfgs) {
                cfgId = cfgs[0].ID;
            }
        }
        return cfgId;
    }

    // 获取前5的英雄中非红色品质的装备信息
    private getTop5NotRedEquip(place: number): Equip {
        let redRank = 9;
        let heros = this.getTop5LevelHero();
        let equipInfo: Equip = null;
        for (let i = 0; i < heros.length; i++) {
            let data = heros[i].getEquip(place)
            if (data && data.getRank() < redRank) {
                equipInfo = data;
                break;
            }
        }
        return equipInfo;
    }
    // 奖励列表中是否存在同类型的装备
    private hasSameTypeEquip(data: Equip, reward: number[][]): boolean {
        let has: boolean = false;
        if (data && reward) {
            for (let i = 0; i < reward.length; i++) {
                let cfg = cm.getEquipConfig(reward[i][0]);
                if (cfg) {
                    if (data.config.Career == cfg.Career && data.config.Place == cfg.Place) {
                        has = true;
                        break;
                    }
                }
            }
        }
        return has;
    }
    // 获取等级最高的五个英雄
    private getTop5LevelHero(): Hero[] {
        let heros = heroLogic.getHeroes({ useRealLevel: true, sort: true });
        let tmpHeros = [];
        for (let i = 0; i < 5; i++) {
            if (heros[i]) { tmpHeros.push(heros[i]); }
        }
        return tmpHeros;
    }
    // 获取等级前5的英雄升级到下一级需要的粉尘
    private getTop5LevelUpNeedDust(): number {
        let heros: Hero[] = this.getTop5LevelHero()
        let needDust: number = 0;
        for (let i = 0; i < heros.length; i++) {
            let heroRankCfg = heroRankConfig.find((a) => { return a.Key == heros[i].getRank(); })
            if (heroRankCfg) {
                let levelMax: number = heroRankCfg.Level;
                let nowLevel: number = heros[i].getLevel();
                if (nowLevel < levelMax && nowLevel <= heroLevelConfig.length) {
                    needDust += heroLevelConfig[nowLevel - 1].Item;
                }
            }
        }
        return needDust;
    }
    // 获取每小时粉尘掉落数
    public getDropDustPerHour(): number {
        let num: number = 0;
        let nowStageId: number = missionLogic.getCurrentMission().getStageId() - 1;
        nowStageId = nowStageId < 1 ? 1 : nowStageId;
        let cfgs = stagedropconfig;
        for (let i = 0; i < cfgs.length; i++) {
            if (cfgs[i].StageLevel[0] <= nowStageId && nowStageId <= cfgs[i].StageLevel[1]) {
                num = cfgs[i].DustDrop * 2;
                break;
            }
        }
        return num;
    }
    // 获取玩家背包拥有的粉尘数 (包括沙漏转换后的)
    private getHasDustNum(): number {
        let dustNum: number = bagLogic.getGood(Good.GoodId.Dust).getAmount();
        let dustProps = bagLogic.getGoods((a) => {
            return a.getGoodType() == Good.GoodType.DustHourGlass || a.getGoodType() == Good.GoodType.EpicDustHourGlass;
        })
        if (dustProps) {
            let dustDropPerHour: number = this.getDropDustPerHour();
            for (let i = 0; i < dustProps.length; i++) {
                dustNum += dustProps[i].getGoodEffect() * dustDropPerHour;
            }
        }
        return dustNum;
    }
    // 获取消费水平和条件进度对应的惊喜礼包
    private getPopGifts(payLevel: number, gear: number): surprisegiftconfigRow[] {
        let cfgs = surprisegiftconfig.filter((v, i, a) => {
            return v.gears == gear && v.RichClass == payLevel;
        })
        return cfgs;
    }
    // 获取惊喜礼包信息
    private getSurpriseGiftCfg(id: number) {
        return surprisegiftconfig.find((a) => { return a.ID == id; });
    }

    // 统计激活惊喜礼包
    public logPopGift(timeCfg: timeGiftConfigRow, surpriseId: number) {
        let surpriseCfg: surprisegiftconfigRow = cm.getSurpriseGiftConfig(surpriseId);
        let storeCfg: storeConfigRow = cm.getStoreConfig(surpriseCfg.storeID);
        let data = {
            district_id: gm.districtId,
            type: timeCfg.type,
            type_value: timeCfg.parameter,
            goods_id: storeCfg.Id,
            goods_name: storeCfg.title,
            index: 1,
        }
        gssdk.logCommitTool.commitCommon({
            eventId: 1001,
            eventStrValue: JSON.stringify(data),
        });
        console.log(`提交激活惊喜礼包日志 条件:${timeCfg.Id} 惊喜礼包:${surpriseCfg.ID}`);
    }
    // 统计购买惊喜礼包
    public logBuyPopGift(storeId: number) {
        console.log(`开始准备提交惊喜礼包购买日志 充值项Id:${storeId}`);
        let storeCfg: storeConfigRow = cm.getStoreConfig(storeId);
        if (!storeCfg) { return; }
        let cloud_data = this.getSurpriseGiftCloudData(storeId);
        if (!cloud_data) { return; }
        let timeGiftId: number = cloud_data.pop;
        if (!timeGiftId) { return; }
        let timeCfg: timeGiftConfigRow = cm.getTimeGiftConfig(timeGiftId);
        if (!timeCfg) { return; }

        let data = {
            district_id: gm.districtId,
            type: timeCfg.type,
            type_value: timeCfg.parameter,
            goods_id: storeCfg.Id,
            goods_name: storeCfg.title,
            index: 2,
        }
        gssdk.logCommitTool.commitCommon({
            eventId: 1001,
            eventStrValue: JSON.stringify(data),
        });
        let surpriseId = this.getSurpriseGiftCloudData(storeId).id;
        console.log(`提交购买惊喜礼包日志 条件:${timeCfg.Id} 惊喜礼包:${surpriseId}`);
    }
    // -- 惊喜礼包 -- //

    // -- 成长礼包 -- //
    public isGrowupValid(): boolean {
        // 成长礼包是否显示 1||2
        //  --> 1. 未购买成长礼包则账号创建15天内
        //  --> 2. 已购买礼包且成长任务未全部完成                      
        let creatTs: number = playerLogic.getPlayer().getCreateTs();
        let valid: boolean = (gm.getCurrentTimestamp() - creatTs) < BenefitLimit;

        let canGet: boolean = false;
        let nowStageId: number = this.getNowStageId();
        if (this.isGrowupGiftOpen()) {
            for (let i = 0; i < growUpConfig.length; i++) {
                let bGot = this.isGotReward(growUpConfig[i].Id);
                let exitReward = this.getNowStageId() < growUpConfig[i].stage;
                if (!bGot || exitReward) {
                    canGet = true;
                    break;
                }
            }
            valid = false;
        }
        return canGet || valid;
    }
    public getNowCompleteCfgId(): number {
        let nowStageId: number = this.getNowStageId();
        let cfgs = growUpConfig.filter((v, i, a) => { return nowStageId >= v.stage });
        return cfgs.length;
    }
    public getNowStageId(): number {
        let nowId = rechargeLogic.growupGiftBuyInfo().stageIdNow;
        nowId = nowId >= 0 ? nowId : 0;
        return nowId;
    }
    public isGotReward(cfgId: number): boolean {
        return rechargeLogic.growupGiftBuyInfo().recvs[cfgId];
    }
    public isGrowupGiftOpen(): boolean {
        return rechargeLogic.growupGiftBuyInfo().open;
    }

    public getMaxStageId(): number {
        let len = growUpConfig.length;
        return growUpConfig[len - 1].stage;
    }

    public getGrowupRewardNum(): number {
        return growUpConfig.length;
    }
    // -- 成长礼包 -- //
}

let benefitLogic = new BenefitLogic();
export default benefitLogic;