import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from '../manager/GameManager';
import MainTask from "../data/assignment/MainTask";
import GameProxy, { MainTaskInfoVO, ResourceVO, TaskProgressSetReq, TaskVO } from "../proxy/GameProxy";
import { AssignPre, DailyType, SevenDayTaskType, WeekType, TaskTypeId } from "../utils/DefineUtils";
import Dailytaskconfig from "../configs/Dailytaskconfig";
import DailyTask from "../data/assignment/DailyTask";
import ActiveRewardconfig from "../configs/ActiveRewardconfig";
import cm from "../manager/ConfigManager";
import { setTimeout } from "timers";
import redPointLogic, { RedPointType } from "./RedPointLogic";
import activityLogic from "./ActivityLogic";
import exploreLogic from "./ExploreLogic";
import Taskconfig from "../configs/Taskconfig";
import commitLogic, { DiamondSource } from "./CommitLogic";

enum taskRewardType {
    daily = 1,
    week = 2,
}

/* 任务系统 */
export class AssignmentLogic extends BaseLogic {

    protected _mainAssignments: { [key: number]: MainTask } = {};     //  主线任务信息集合
    public _runnigMainAssign: MainTask[] = [];                     //  可显示的主线任务
    private _getWeedTaskUidPre: number = 0;
    protected _stageIds: number[] = [];                             // 主线关卡任务参数集合

    private _tasks: { [key: number]: DailyTask } = {};                 // 日常和周常任务信息
    public _dailyRewards: { [key: number]: boolean } = {};            // 日常任务宝箱信息
    public _weekRewards: { [key: number]: boolean } = {};             // 周常任务宝箱信息
    public _dailyScore: number = 0;                             // 日常任务积分
    public _weekScore: number = 0;                              // 周长任务积分
    public _maxScore: number = 100;
    public _dailyTs: number = 0;
    public _weekTs: number = 0;

    public flagWorldPos: cc.Vec2 = null;
    public _mainTouch: { pos: cc.Vec2, id: number } = null;
    public completeTowerDailyTask: boolean = true;                 // 是否完成每日摩天楼挑战
    public completePveDailyTask: boolean = true;                   // 是否完成每日挑战首领
    public arenaTaskFinished: boolean = false;

    init(gm: IGameManager) {
        super.init(null, gm);

        this.startRedFuncBind();
        this.initData();
    }

    resetAll() {

    }

    initData() {
        this._stageIds = [];
        let cfg = Taskconfig.filter((v, i, a) => { return v.tasktype == TaskTypeId.PassMainMission; });
        this._stageIds = cfg.map((v, i, a) => { return v.value; });
        this._stageIds.sort((a, b) => { return a - b; });
    }

    getPassMissionStageId(nowStage: number): number {
        let stageId: number = nowStage;
        for (let i = 0; i < this._stageIds.length; i++) {
            if (this._stageIds[i] >= nowStage) {
                stageId = this._stageIds[i];
                break;
            }
        }
        return stageId;
    }

    // 活跃宝箱额外奖励
    getActivityExReward(type: number, score: number): number[][] {
        let reward: number[][] = [];
        // 探趣寻宝
        let ex = exploreLogic.getActiveExReward(type, score);
        if (ex && ex.length > 0) {
            reward.push(ex);
        }

        return reward;
    }

    // 日常进度提交
    public dailyTaskProCommit(id: DailyType, value: number = 1) {
        if (value == 0) { return; }
        let uid: number = id;
        if (!this._tasks[uid]) { return; }
        let param = value + this._tasks[uid].completeValue;
        let force = id == DailyType.fight_union || id == DailyType.fight_arena;
        setTimeout(() => { this.taskProCommit(uid, param, force); }, 300);
    }
    // 周常进度提交
    public weekTaskProCommit(id: WeekType, value: number = 1) {
        if (value == 0) { return; }
        let uid: number = id;
        if (!this._tasks[uid]) { return; }
        let param = value + this._tasks[uid].completeValue;
        let force = true;
        setTimeout(() => { this.taskProCommit(uid, param, force); }, 500);
    }

    // 获取日常任务信息
    public getDailyTasks(unlockFilter: boolean = false): DailyTask[] {
        let tmp: DailyTask[] = [];
        Object.keys(this._tasks).forEach((v, i, a) => {
            let id: number = parseInt(v);
            if (!this._tasks[id].isWeek()) {
                if (unlockFilter) {
                    if (this._tasks[id].isUnlock()) {
                        tmp.push(this._tasks[id]);
                    }
                } else {
                    tmp.push(this._tasks[id]);
                }
            }
        });
        return tmp;
    }
    // 获取周常任务信息
    public getWeekTasks(unlockFilter: boolean = false): DailyTask[] {
        let tmp: DailyTask[] = [];
        Object.keys(this._tasks).forEach((v, i, a) => {
            let id: number = parseInt(v);
            if (this._tasks[id].isWeek()) {
                if (unlockFilter) {
                    if (this._tasks[id].isUnlock()) {
                        tmp.push(this._tasks[id]);
                    }
                } else {
                    tmp.push(this._tasks[id]);
                }
            }
        });
        return tmp;
    }

    // 请求主线任务信息 参数为0时表示全部
    async mainTaskReq(id: number) {
        let proto: MainTaskInfoVO[] = await gm.request<MainTaskInfoVO[]>(GameProxy.apitaskgetMTaskInfo, id);
        this.mainTask(proto);
    }

    // 领取主线任务奖励
    async mainTaskGetRewardReq(id: number) {
        let proto: ResourceVO = await gm.request<ResourceVO>(GameProxy.apitaskgetMTaskReward, id);

        this._mainAssignments[id].gotReward = true;
        this.freshRunningMainTask();

        gm.getReward(proto);
        commitLogic.commitReward(proto, DiamondSource.mainTask);
    }
    // 领取活跃度奖励
    async activeRewardReq(id: number, bVideo: boolean = false) {
        let proto: ResourceVO = await gm.request<ResourceVO>(GameProxy.apitaskgetActiveReward, { rewardId: id, useVideo: bVideo });
        this.setActiveRewardGot(id);

        gm.getReward(proto);
        commitLogic.commitReward(proto, DiamondSource.taskActive);
    }
    // 获取日常，周常进度及领取状态
    async tasksReq(id: number) {
        let proto: TaskVO = await gm.request<TaskVO>(GameProxy.apitaskgetTaskInfo, id);
        this.freshDailyTask(proto);
    }
    // 提交日常周常任务完成
    async taskCompleteCommit(id: number) {
        let proto: number = await gm.request<number>(GameProxy.apitaskgetTaskReward, id);

        if (cm.getDailyTaskConfig(id).tasktypeID > AssignPre.Week) {
            this._weekScore = proto;
        } else if (cm.getDailyTaskConfig(id).tasktypeID > AssignPre.Daily) {
            this._dailyScore = proto;
        }
        let taskId: number = cm.getDailyTaskConfig(id).tasktypeID;
        this._tasks[taskId].got_reward = true;
    }
    // 设置日常和周常任务进度
    async taskProCommit(id: number, progress: number, force: boolean = false) {
        if (this._tasks[id].complete_task && !force) {
            // 已完成,不再提交进度
            return;
        }

        if (this._tasks[id].cfg.tasktypeID == 1010) {
            this.arenaTaskFinished = !this._tasks[id].complete_task;
        }

        let param: TaskProgressSetReq = new TaskProgressSetReq;
        param.progress = progress;
        param.taskId = this._tasks[id].id;
        let proto: number = await this._gm.request<number>(GameProxy.apitasksetTaskProgress, param, GameProxy, true);
        this._tasks[id].completeValue = progress;
    }

    // 主线绑定账号任务
    async bindAssignCommit() {
        let proto = await gm.request<number>(GameProxy.apitasksetAccountBind, 1);
        console.log("当前绑定进度: " + proto);
    }

    /*  --红点判断函数--   */

    public startRedFuncBind() {
        redPointLogic.addFunc(RedPointType.Assign_Daily, this.dailyTaskRed.bind(this));
        redPointLogic.addFunc(RedPointType.Assign_Week, this.weekTaskRed.bind(this));
        redPointLogic.addFunc(RedPointType.Assign_Main, this.mainTaskRed.bind(this));
    }

    // 日常任务红点
    dailyTaskRed(): boolean {
        let bRed: boolean = false;
        // 存在已完成未提交任务
        let tasks = this.getDailyTasks();
        for (let i = 0; i < tasks.length; i++) {
            if (tasks[i].complete_task && !tasks[i].got_reward) {
                bRed = true;
                break;
            }
        }
        // 存在可领取活跃宝箱
        Object.keys(this._dailyRewards).forEach((v, i, a) => {
            let index = parseInt(v);
            let cfg = cm.getActiveRewardConfig(index);
            let bComplete = this._dailyScore >= cfg.vitality;
            let bRecv = this._dailyRewards[v];
            if (bComplete && !bRecv) {
                bRed = true;
            }
        });

        return bRed;
    }
    // 周常任务红点
    weekTaskRed(): boolean {
        let bRed: boolean = false;
        // 存在已完成未提交任务
        let tasks = this.getWeekTasks();
        for (let i = 0; i < tasks.length; i++) {
            if (tasks[i].complete_task && !tasks[i].got_reward) {
                bRed = true;
                break;
            }
        }
        // 存在可领取活跃宝箱
        Object.keys(this._weekRewards).forEach((v, i, a) => {
            let index = parseInt(v);
            let cfg = cm.getActiveRewardConfig(index);
            let bComplete = this._weekScore >= cfg.vitality;
            let bRecv = this._weekRewards[v];
            if (bComplete && !bRecv) {
                bRed = true;
            }
        });

        return bRed;
    }

    // 主线任务红点
    mainTaskRed() {
        let bRed: boolean = false;
        let len = this._runnigMainAssign.length;
        for (let i = 0; i < len; i++) {
            if (this._runnigMainAssign[i].complete_task &&
                !this._runnigMainAssign[i].gotReward) {
                bRed = true;
                break;
            }
        }
        return bRed;
    }
    /*  --红点判断函数--   */

    protected freshDailyTask(proto: TaskVO) {
        this._tasks = {};
        this._dailyRewards = {};
        this._weekRewards = {};
        this._dailyScore = 0;
        this._weekScore = 0;

        proto.taskInfos.forEach((v, i, a) => {
            let tmp: DailyTask = new DailyTask(v);
            if (tmp.cfg) {
                this._tasks[tmp.taskId] = tmp;
            }
        });

        this._dailyScore = proto.daily.activeSocre;
        this._weekScore = proto.weekly.activeSocre;

        this._dailyTs = proto.daily.refreshTs;
        this._weekTs = proto.weekly.refreshTs;

        ActiveRewardconfig.forEach((v, i, a) => {
            if (v.type == taskRewardType.daily) {
                this._dailyRewards[v.ID] = false;
            } else if (v.type == taskRewardType.week) {
                this._weekRewards[v.ID] = false;
            }
        });

        proto.daily.activeInfos.forEach((v, i, a) => {
            Object.keys(this._dailyRewards).forEach((value, index, arr) => {
                let id: number = parseInt(value);
                if (v.vitaility == cm.getActiveRewardConfig(id).vitality) {
                    this._dailyRewards[id] = v.recv;
                }
            });
        });
        proto.weekly.activeInfos.forEach((v, i, a) => {
            Object.keys(this._weekRewards).forEach((value, index, arr) => {
                let id: number = parseInt(value);
                if (v.vitaility == cm.getActiveRewardConfig(id).vitality) {
                    this._weekRewards[id] = v.recv;
                }
            });
        });
    }
    protected setActiveRewardGot(id: number) {
        Object.keys(this._dailyRewards).forEach((v, i, a) => {
            let taskId: number = parseInt(v);
            if (id == taskId) {
                this._dailyRewards[taskId] = true;
            }
        });
        Object.keys(this._weekRewards).forEach((v, i, a) => {
            let taskId: number = parseInt(v);
            if (id == taskId) {
                this._weekRewards[taskId] = true;
            }
        });
    }

    protected mainTask(progs: MainTaskInfoVO[]) {
        if (progs.length == 1) {
            this._mainAssignments[progs[0].taskId].taskProgress = progs[0].progress;
        } else if (progs.length > 1) {
            this._mainAssignments = {};
            progs.forEach((v, i, a) => {
                let tmp = new MainTask(v.taskId);
                if (tmp.cfg) {
                    tmp.taskProgress = v.progress;
                    tmp.gotReward = v.recv;
                    this._mainAssignments[tmp.id] = tmp;
                }
            });
        }
        this.freshRunningMainTask();
    }

    protected freshRunningMainTask() {
        this._runnigMainAssign = [];
        Object.keys(this._mainAssignments).forEach((v, i, a) => {
            let id: number = parseInt(v);
            if (this._mainAssignments[id].isRunning()) {
                this._runnigMainAssign.push(this._mainAssignments[id]);
            }
        });
    }

    public getMainTaskNum(): number {
        return Object.keys(this._mainAssignments).length;
    }
    public getMainTaskInfo(id: number): MainTask {
        return this._mainAssignments[id];
    }

    private getWeekTaskUidPre(): number {
        if (this._getWeedTaskUidPre == 0) {
            let len: number = Dailytaskconfig.length;
            for (let i = 0; i < len; i++) {
                if (Dailytaskconfig[i].tasktypeID > AssignPre.Week) {
                    this._getWeedTaskUidPre = Dailytaskconfig[i].ID - 1;
                    break;
                }
            }
        }
        return this._getWeedTaskUidPre;
    }

}

let assignmentLogic = new AssignmentLogic();
export default assignmentLogic;