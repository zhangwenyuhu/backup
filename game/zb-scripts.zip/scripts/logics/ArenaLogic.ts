import { arenascorerewardconfigRow } from './../configs/arenascorerewardconfig';
import { arenachallangetimeconfigRow } from './../configs/arenachallangetimeconfig';
import BaseLogic from "./BaseLogic";
import GameProxy, {
    ArenaBattleReq,
    ArenaRecordVO,
    ArenaReq,
    ArenaRevengeReq,
    Battle_ArenaData,
    Battle_heroConfig,
    DefendHeroBO,
    EquipBO,
    HeroBO,
    HeroVO,
    RankVO,
    ResourceVO,
    RoleDefendVO,
    RoleRankVO,
    ArenaTaskVO,
    TaskInfoVO,
} from "../proxy/GameProxy";
import IGameManager from "../manager/IGameManager";
import Hero from "../data/card/Hero";
import heroLogic from "./HeroLogic";
import playerLogic from "./PlayerLogic";
import bagLogic from "./BagLogic";
import HttpProxy from "../proxy/HttpProxy";
import { GoodId } from "../data/card/Good";
import EManager, { EName } from "../manager/EventManager";
import promptLogic, { PromptType } from "./PromptLogic";
import heroConfig, { heroConfigRow } from "../configs/heroConfig";
import stringUtils from "../utils/StringUtils";
import equipConfig from "../configs/equipConfig";
import Equip from "../data/card/Equip";
import equipLevelConfig from "../configs/equipLevelConfig";
import heroUtils from "../utils/HeroUtils";
import { stringConfigMap } from "../configs/stringConfig";
import { npcconfigRow } from "../configs/npcconfig";
import commitLogic, { DiamondCost } from "./CommitLogic";
import storageUtils from "../utils/StorageUtils";
import { BattleType, Storage, TaskActivityType } from "../utils/DefineUtils";
import UnlockWrapper from "../view/widget/unlock/UnlockWrapper";
import { unlockConfigMap } from "../configs/unlockConfig";
import heroRankConfig from "../configs/heroRankConfig";
import activityLogic, { ActivityType } from "./ActivityLogic";
import Card from '../data/card/Card';
import commonUtils from '../utils/CommonUtils';
import gm from '../manager/GameManager';
import cm from '../manager/ConfigManager';
import ToastError from "../error/ToastError";
import {ArenaRankconfigRow} from "../configs/ArenaRankconfig";

export enum RankType {
    Faction1 = 1,
    Faction2,
    Faction3,
    Faction4,
    Mission,
    Tower,
    ArenaNormal,
    ArenaHigh
}

export enum ArenaType {
    Normal,
    High,
    Top
}

export abstract class ArenaBaseTask {
    protected _progress: number = 0;
    protected _isClaimed: boolean = false;
    protected _rewards: Card[] = [];

    constructor(vo: TaskInfoVO) {
        this._progress = vo.progress;
        this._isClaimed = vo.recv;
        this._rewards = [];
    }

    set progress(value: number) {
        this._progress = value;
    }

    get progress(): number {
        return this._progress;
    }

    get isClaimed(): boolean {
        return this._isClaimed;
    }

    set isClaimed(value: boolean) {
        this._isClaimed = value;
    }

    get claimable(): boolean {
        return this.progress >= this.getCompleteValue() && !this.isClaimed;
    }

    get rewards(): Card[] {
        return this._rewards;
    }

    abstract getCompleteValue(): number;
    abstract getConfig(): any;
}

export class ArenaChallengeTask extends ArenaBaseTask {
    protected _config: arenachallangetimeconfigRow = null;

    constructor(vo: TaskInfoVO) {
        super(vo);
        this._config = cm.getArenaChallengeRewardConfig(vo.taskId);
        if (this._config) {
            for (let reward of this._config.reward) {
                this._rewards.push(commonUtils.item2Card(reward));
            }
        }
    }

    getConfig(): arenachallangetimeconfigRow {
        return this._config;
    }

    getCompleteValue(): number {
        return this._config.time;
    }
}

export class ArenaScoreTask extends ArenaBaseTask {
    protected _config: arenascorerewardconfigRow = null;

    constructor(vo: TaskInfoVO) {
        super(vo);
        this._config = cm.getArenaScoreRewardConfig(vo.taskId);
        if (this._config) {
            for (let reward of this._config.reward) {
                this._rewards.push(commonUtils.item2Card(reward));
            }
        }
    }

    getConfig(): arenascorerewardconfigRow {
        return this._config;
    }

    getCompleteValue(): number {
        return this._config.score;
    }
}

export class ArenaRankTask extends ArenaBaseTask {
    protected _config: ArenaRankconfigRow = null;

    constructor(vo: TaskInfoVO) {
        super(vo);
        this._config = cm.getArenaRankIdConfig(vo.taskId);
        if (this._config) {
            for (let reward of this._config.seasonreward) {
                this._rewards.push(commonUtils.item2Card(reward));
            }
        }
    }

    getConfig(): ArenaRankconfigRow {
        return this._config;
    }

    getCompleteValue(): number {
        return this._config.scoreneed;
    }
}

class ArenaLogic extends BaseLogic {
    protected _arenas: RankVO[] = [];
    protected _myArena: RoleRankVO = null;
    protected _myDefend: RoleDefendVO = null;
    protected _roleDefend: RoleDefendVO = null;
    protected _matchList: RankVO[] = [];
    protected _battleData: Battle_ArenaData = null;
    protected _recordList: ArenaRecordVO[] = [];
    protected _battleResult: ResourceVO = null;
    protected _rivalData: RankVO = null;
    protected _rivalRecordData: ArenaRecordVO = null;
    protected _battleDataUrl: string = "";
    protected _aiHeroList: { [key: string]: HeroVO[] } = {};
    protected _challengeTasks: ArenaChallengeTask[] = [];
    protected _scoreTasks: ArenaScoreTask[] = [];
    protected _seniorChallengeTasks: ArenaChallengeTask[] = [];
    protected _seniorRankTasks: ArenaRankTask[] = [];
    protected _seniorScoreTasks: ArenaScoreTask[] = [];

    readonly events = {
        onChallengeTasksDirty: "on challenge tasks dirty",
        onScoreTasksDirty: "on score tasks dirty",
        onRankTasksDirty: "on rank tasks dirty",
    }

    init(gm: IGameManager) {
        super.init(null, gm);
    }

    getArena() {
        return this._arenas;
    }

    getMyArenaInfo() {
        return this._myArena;
    }

    getMyArenaByRankType(rankType: RankType) {
        return this._myArena.myRanks.find(a => a.rankType == rankType);
    }

    getMyDefend() {
        return this._myDefend;
    }

    getRoleDefend() {
        return this._roleDefend;
    }

    getMatchList() {
        return this._matchList;
    }

    getRecordList() {
        return this._recordList;
    }

    getBattleData() {
        return this._battleData;
    }

    getBattleReport() {
        return this._battleResult.battleReport;
    }

    getRivalData() {
        return this._rivalData;
    }

    resetRivalData() {
        this._rivalData = null;
        this._rivalRecordData = null;
    }

    getRivalRecordData() {
        return this._rivalRecordData;
    }

    getAIHeroList(nick: string): HeroVO[] {
        return this._aiHeroList[nick];
    }

    getArenaHeroConfig(hero: Battle_heroConfig[], withoutSkill?: boolean): rpgfight.HeroConfig[] {
        let list: rpgfight.HeroConfig[] = [];
        for (let enemy of hero) {
            let config = commonUtils.getHeroConfig(enemy, withoutSkill);
            list.push(config);
        }
        return list;
    }

    getArenaHero(isDefend: boolean = false): { selfHero: Hero[], enemyHero: Hero[] } {
        let selfHero: Hero[] = [];
        let enemyHero: Hero[] = [];
        for (let enemy of this._battleData.heroList) {
            let heroVo = new HeroVO();
            heroVo.heroId = enemy.heroId;
            heroVo.heroCofId = Number(enemy.heroConfigId);
            heroVo.lv = Number(enemy.level);
            heroVo.rank = Number(enemy.rank);
            heroVo.equips = [];
            let hero = new Hero(heroVo);
            if (isDefend) {
                if (enemy.battleTeam == rpgfight.BattleTeam.our) {
                    enemyHero.push(hero);
                } else {
                    selfHero.push(hero);
                }
            }
            else {
                if (enemy.battleTeam == rpgfight.BattleTeam.our) {
                    selfHero.push(hero);
                } else {
                    enemyHero.push(hero);
                }
            }
        }
        return {
            selfHero: selfHero,
            enemyHero: enemyHero
        };
    }

    getBattleScene(): rpgfight.SceneConfig {
        let json = JSON.stringify(this._battleData.scene);
        return JSON.parse(json) as rpgfight.SceneConfig;
    }

    getMyPower(): number {
        let power = 0;
        for (let defend of this._myDefend.heros) {
            if (defend.heroId && defend.data) {
                let hero = heroLogic.getHero(defend.heroId);
                if (hero) { power += hero.getPower(); }
            }
        }
        return power;
    }

    generateAIHeroes(nick: string, ratio: number, usePower?: number, npc?: npcconfigRow): HeroVO[] {
        if (this._aiHeroList[nick]) {
            return this._aiHeroList[nick];
        }
        let aiHeroes: HeroVO[] = [];
        let heroes = heroLogic.getHeroes({ sort: true });
        let levels = [];
        let ranks = [];
        let power: number = 0;
        for (let i = 0; i < Math.min(5, heroes.length); i++) {
            levels.push(heroes[i].getLevel());
            ranks.push(heroes[i].getRank());
            power += heroes[i].getPower();
        }
        if (usePower) {
            power = usePower;
        } else {
            power *= ratio;
        }
        let perPower = power / Math.min(5, heroes.length);
        if (npc) {
            console.log("npc id:" + npc.ID);
        }
        let generateHeroes: number[] = this._generateHeroId(npc);
        let aiLevels: number[] = this._generateHeroLevel(levels);
        for (let i = 0; i < 5; i++) {
            let heroVO = new HeroVO();
            let heroConfigId = generateHeroes[i];
            let hConfig = heroConfig.find(a => a.Id == heroConfigId);
            heroVO.equips = [];
            if (npc) {
                heroVO.lv = npc.herolevel[i];
                heroVO.rank = npc.herorank[i];
            } else {
                heroVO.lv = aiLevels[i];
                heroVO.rank = ranks[i] != undefined ? ranks[i] : ranks[ranks.length - 1];
            }
            heroVO.star = heroRankConfig[heroVO.rank - 1].starlimit;
            heroVO.heroCofId = heroConfigId;
            heroVO.heroId = stringUtils.generateUUID();
            heroVO.atkValue = hConfig.Atk;
            heroVO.defValue = hConfig.Def;
            heroVO.hp = hConfig.Hp;
            heroVO.exp = 0;
            heroVO.criticalPct = hConfig.CritRate;
            heroVO.criticalAtkValue = hConfig.CritValue;
            heroVO.dodgeValue = hConfig.DodgeRate;
            heroVO.hitValue = hConfig.HitRate;
            heroVO.liftLeechValue = hConfig.HarmAbsorbLv;
            heroVO.magicResistPct = hConfig.M_DeHarmRate;
            heroVO.phyResistPct = hConfig.P_DeHarmRate;
            heroVO.skillSpeed = hConfig.SkillSpeed;
            heroVO.moveSpeed = hConfig.MoveSpeed;
            heroVO.recoverSec = hConfig.Recovery;
            heroVO.hitEnergy = hConfig.HitEnergy;
            heroVO.beHitEnergy = hConfig.BeHitEnergy;
            let _hero = new Hero(heroVO);
            _hero.calcProperties();
            heroVO.atkValue = _hero.getAtk();
            heroVO.defValue = _hero.getDef();
            heroVO.hp = _hero.getHp();
            heroVO.equips = this._generateEquips(heroVO, (perPower - new Hero(heroVO).getPower()) / 4);
            heroVO.heroAddInfos = heroUtils.getHeroAddInfos(heroVO.equips);
            aiHeroes.push(heroVO);
        }
        this._aiHeroList[nick] = aiHeroes;
        return aiHeroes;
    }

    protected _generateHeroLevel(levels: number[]): number[] {
        let aiLevels: number[] = [];
        for (let i = 0; i < 5; i++) {
            let level = levels[i] != undefined ? levels[i] : levels[levels.length - 1];
            let rd = Math.floor(Math.random() * 10) - 5;
            level += rd;
            level = Math.max(1, level);
            level = Math.min(240, level);
            aiLevels.push(level);
        }
        return aiLevels;
    }

    protected _generateHeroId(npc?: npcconfigRow): number[] {
        let heroIds = [];
        for (let battleStation = 1; battleStation <= 5; battleStation++) {
            if (battleStation == 1 || battleStation == 2) {
                //力量型史诗以上品质
                let hConfigs = null;
                if (npc) {
                    hConfigs = heroConfig.where(a => a.Type == 0 && a.Faction <= 4 && a.Career == 1 && a.DefaultRank <= npc.herorank[battleStation - 1]);
                } else {
                    hConfigs = heroConfig.where(a => a.Type == 0 && a.Quality >= 2 && a.Faction <= 4 && a.Career == 1);
                }
                this._generateUniqueHeroId(heroIds, hConfigs);
            } else if (battleStation == 3) {
                //敏捷型神话品质
                let hConfigs = null;
                if (npc) {
                    hConfigs = heroConfig.where(a => a.Type == 0 && a.Faction <= 4 && a.Career == 3 && a.DefaultRank <= npc.herorank[battleStation - 1]);
                } else {
                    hConfigs = heroConfig.where(a => a.Type == 0 && a.Quality == 3 && a.Faction <= 4 && a.Career == 3);
                }
                this._generateUniqueHeroId(heroIds, hConfigs);
            } else if (battleStation == 4 || battleStation == 5) {
                //智力型史诗品质
                let hConfigs = null;
                if (npc) {
                    hConfigs = heroConfig.where(a => a.Type == 0 && a.Faction <= 4 && a.Career == 2 && a.DefaultRank <= npc.herorank[battleStation - 1]);
                } else {
                    hConfigs = heroConfig.where(a => a.Type == 0 && a.Quality >= 2 && a.Faction <= 4 && a.Career == 2);
                }
                this._generateUniqueHeroId(heroIds, hConfigs);
            }
        }
        return heroIds;
    }

    protected _generateUniqueHeroId(heroIds: number[], config: heroConfigRow[]): number {
        let rd = Math.floor(Math.random() * config.length);
        let heroId = config[rd].Id;
        if (heroIds.indexOf(heroId) == -1) {
            heroIds.push(heroId);
            return heroId;
        } else {
            this._generateUniqueHeroId(heroIds, config);
        }
    }

    /**生成装备 */
    protected _generateEquips(heroVO: HeroVO, power: number): EquipBO[] {
        let heroEquips: EquipBO[] = [];
        let hero = new Hero(heroVO);
        for (let i = 1; i < 5; i++) {
            let equipBO = this._generateBestEquip(heroVO, hero.getCareer(), i, power);
            if (equipBO) {
                equipBO.heroId = hero.getId();
                heroEquips.push(equipBO);
            }
        }
        return heroEquips;
    }

    /**生成最佳装备 */
    protected _generateBestEquip(heroVO: HeroVO, career: number, place: number, power: number): EquipBO {
        let bestEquip: EquipBO = null;
        let bestPower: number = 0;
        let hero = new Hero(heroVO);
        let equips = equipConfig.where(a => a.Rank <= hero.getRank() && a.Career == career && a.Place == place);
        for (let equip of equips) {
            let equipBO = new EquipBO();
            equipBO.career = equip.Career;
            equipBO.campBonus = 0;
            equipBO.equipCofId = equip.Id;
            equipBO.place = equip.Place;
            equipBO.equipId = stringUtils.generateUUID();
            equipBO.totalStarExp = 0;
            if (bestEquip) {
                let equipM = new Equip(equipBO);
                if (Math.abs(equipM.getPower() - power) < Math.abs(bestPower - power)) {
                    bestEquip = equipBO;
                    bestPower = equipM.getPower();
                }
                // 去除强化星级，因为强化星级算法战力不准确
                // let maxStar = equipLevelConfig.find(a => a.Rank == equip.Rank).StarLimit;
                // maxStar = Math.max(1, maxStar);
                // for (let i = 1; i <= maxStar; i++) {
                //     equipBO.totalExp = this._calcStarExp(equip.Rank, i);
                //     let equipM = new Equip(equipBO);
                //     if (Math.abs(equipM.getPower() - power) < Math.abs(bestPower - power)) {
                //         bestEquip = equipBO;
                //         bestPower = equipM.getPower();
                //     }
                // }
            } else {
                bestEquip = equipBO;
            }
        }
        return bestEquip;
    }

    /**升级到该星级所需经验 */
    protected _calcStarExp(rank: number, star: number): number {
        let totalExp = 0;
        let levelConfig = equipLevelConfig[rank - 1];
        for (let i = 1; i <= 5; i++) {
            if (i <= star) {
                totalExp += levelConfig[`Exp${i}`];
            }
        }
        return totalExp;
    }

    async doGetArena(arenaType: ArenaType) {
        this._arenas = await this._gm.request<RankVO[]>(GameProxy.apiarenarank, arenaType);
    }

    async doUnlockArena() {
        if (UnlockWrapper.isUnlock(unlockConfigMap.竞技场) && !storageUtils.getBoolean(Storage.ArenaJuniorDefense)) {
            let troop = await playerLogic.getTroop(BattleType.PVE);
            await this._gm.request(GameProxy.apiarenasetDefendHero, this._getArenaReq(troop));
            storageUtils.setBoolean(Storage.ArenaJuniorDefense.Key, true, true);
        }
    }

    async doGetMyArena() {
        if (!storageUtils.getBoolean(Storage.ArenaJuniorDefense)) {
            let troop = await playerLogic.getTroop(BattleType.PVE);
            await this._gm.request(GameProxy.apiarenasetDefendHero, this._getArenaReq(troop));
            storageUtils.setBoolean(Storage.ArenaJuniorDefense.Key, true, true);
        }
        this._myArena = await this._gm.request<RoleRankVO>(GameProxy.apiarenamyRank, "");
    }

    async doGetTasksInfo() {
        this._challengeTasks = [];
        this._scoreTasks = [];
        this._seniorChallengeTasks = [];
        this._seniorRankTasks = [];

        let proto = await this._gm.request<ArenaTaskVO>(GameProxy.apitaskgetArenaTasksInfo, undefined, GameProxy, true);
        if (proto.arenaBcTask) {
            for (let vo of proto.arenaBcTask) {
                let task = new ArenaChallengeTask(vo);
                if (task.getConfig()) {
                    this._challengeTasks.push(task);
                }
            }
        }
        if (proto.topScoreTask) {
            for (let vo of proto.topScoreTask) {
                let task = new ArenaScoreTask(vo);
                if (task.getConfig()) {
                    this._scoreTasks.push(task);
                }
            }
        }
        if (proto.advArenaBcTask) {
            for (let vo of proto.advArenaBcTask) {
                let task = new ArenaChallengeTask(vo);
                if (task.getConfig()) {
                    this._seniorChallengeTasks.push(task);
                }
            }
        }
        if (proto.advArenaRankTask) {
            for (let vo of proto.advArenaRankTask) {
                let task = new ArenaRankTask(vo);
                if (task.getConfig()) {
                    this._seniorRankTasks.push(task);
                }
            }
        }

        EManager.emit(this.events.onChallengeTasksDirty);
        EManager.emit(this.events.onScoreTasksDirty);
    }

    async doClaimChallengeReward(task: ArenaChallengeTask): Promise<Card[]> {
        let protos = await this._gm.request<ResourceVO>(GameProxy.apitaskrecvArenaBcTaskReward, task.getConfig().ID);
        task.isClaimed = true;
        EManager.emit(this.events.onChallengeTasksDirty);
        return playerLogic.addCards(protos);
    }

    async doClaimScoreReward(task: ArenaScoreTask): Promise<Card[]> {
        let protos = await this._gm.request<ResourceVO>(GameProxy.apitaskrecvArenaTsTaskReward, task.getConfig().ID);
        task.isClaimed = true;
        EManager.emit(this.events.onScoreTasksDirty);
        return playerLogic.addCards(protos);
    }

    async doClaimRankReward(task: ArenaRankTask) {
        let protos = await this._gm.request<ResourceVO>(GameProxy.apitaskrecvAdvTopRankReward, task.getConfig().ID);
        task.isClaimed = true;
        EManager.emit(this.events.onRankTasksDirty);
        return playerLogic.addCards(protos);
    }

    getChallengeTasks(): ArenaChallengeTask[] {
        return this._challengeTasks;
    }

    getSeniorChallengeTasks(): ArenaChallengeTask[] {
        return this._seniorChallengeTasks;
    }

    getScoreTasks(): ArenaScoreTask[] {
        return this._scoreTasks;
    }

    getRankTasks(): ArenaRankTask[] {
        return this._seniorRankTasks;
    }

    protected _getArenaReq(troop: Hero[]) {
        let arenaReq = new ArenaReq();
        arenaReq.type = 0;
        arenaReq.heros = [];
        for (let i = 0; i < playerLogic.getMaxInstanceTroopCount(); i++) {
            let hero = troop[i];
            let defendHeroBO = new DefendHeroBO();
            defendHeroBO.groupId = 1;
            defendHeroBO.battleStation = i + 1;
            if (hero) {
                defendHeroBO.heroId = hero.getId();
            } else {
                defendHeroBO.heroId = "";
            }
            arenaReq.heros.push(defendHeroBO);
        }
        return arenaReq;
    }

    async doGetMyDefend(arenaType: ArenaType) {
        let arenaReq = new ArenaReq();
        arenaReq.type = arenaType;
        this._myDefend = await this._gm.request<RoleDefendVO>(GameProxy.apiarenadefendHero, arenaReq);
    }

    async doArenaBattle(rank: RankVO) {
        this._rivalData = rank;
        let arenaBattleReq = new ArenaBattleReq();
        let defendHeroBoList: DefendHeroBO[] = [];
        let heroes = await playerLogic.getTroop(BattleType.PVP);
        for (let i = 0; i < heroes.length; i++) {
            let heroBo = new DefendHeroBO();
            heroBo.heroId = heroes[i] ? heroes[i].getId() : "";
            heroBo.groupId = 1;
            heroBo.battleStation = i + 1;
            defendHeroBoList.push(heroBo);
        }
        arenaBattleReq.heros = defendHeroBoList;
        arenaBattleReq.rivalRoleId = rank.roleId;
        arenaBattleReq.width = cc.director.getWinSize().width;
        arenaBattleReq.height = 750;
        arenaBattleReq.version = gm.fightVersion > 0 ? gm.fightVersion : rpgfight.version.codeVersion;
        if (rank.ai || Number(rank.roleId) < 0) {
            arenaBattleReq.aiList = this.getAIHeroList(rank.role.nick) as HeroBO[];
        }
        try {
            this._battleData = await gm.request<Battle_ArenaData>(GameProxy.apiarenabattle, arenaBattleReq);
            // this._test();
            if (this._myArena.freeTimes <= 0) {
                bagLogic.changeGoodAmount(GoodId.WarriorTicket, -1);
            } else {
                this._myArena.freeTimes--;
                if (this._myArena.freeTimes == 0) {
                    promptLogic.setPromptRead([PromptType.ARENA_NORMAL_READY]);
                }
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    protected async _test() {
        let result = await this.httpRequest(JSON.stringify(this._battleData), "POST");
        console.log(result);
    }

    async httpRequest(params: string, method: string, data?: string) {
        return new Promise<string>((resolve, reject) => {
            let xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && (xhr.status >= 200 && xhr.status < 400)) {
                    let response = xhr.responseText;
                    console.log(response);
                    try {
                        let obj = JSON.parse(response);
                        if (typeof obj.m == "string" && obj.m.length > 0) {
                            reject(obj.m);
                        }
                        else {
                            resolve(obj);
                        }
                    } catch (error) {
                        reject(error);
                    }
                }
            }
            xhr.onerror = (ev) => {
                reject(ev);
            }
            xhr.ontimeout = () => {
                reject("超时")
            }
            xhr.open(method, `http://172.27.17.41:8080/fight/getArenaResult`);
            xhr.setRequestHeader("accept", "*/*");
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.send(params);
        });
    }

    async doMatch(arenaType: ArenaType) {
        this._matchList = await gm.request<RankVO[]>(GameProxy.apiarenamatch, arenaType);
        this._matchList.sort((a, b) => {
            return b.score - a.score;
        });
    }

    async doFreshMatch() {
        this._matchList = await gm.request<RankVO[]>(GameProxy.apiarenafreshMatch, null);
        this._matchList.sort((a, b) => {
            return b.score - a.score;
        });
        if (this._myArena.normalFreshCount > 0) {
            this._myArena.normalFreshCount--;
        }
    }

    async doGetDefendHero(arenaType: ArenaType, roleId: string) {
        let arenaReq = new ArenaReq();
        arenaReq.type = arenaType;
        arenaReq.rivalRoleId = roleId;
        this._roleDefend = await gm.request<RoleDefendVO>(GameProxy.apiarenadefendHero, arenaReq);
    }

    async doSetDefendHero(arenaReq: ArenaReq, updateRank: boolean = true) {
        let needChange: boolean = false;
        for (let hero of arenaReq.heros) {
            let config = null;
            if (this._myDefend) {
                config = this._myDefend.heros.find(a => a.heroId == hero.heroId && a.battleStation == hero.battleStation);
            }
            if (hero.heroId != "" && config == null) {
                needChange = true;
                break;
            } else if (hero.heroId == "" && (this._myDefend && this._myDefend.heros.find(a => a.battleStation == hero.battleStation) != null)) {
                needChange = true;
                break;
            }
        }
        if (needChange) {
            await gm.request(GameProxy.apiarenasetDefendHero, arenaReq);
            await this.doGetMyDefend(arenaReq.type);
            this.getMyArenaByRankType(RankType.ArenaNormal).power = this.getMyPower();
            if (updateRank) {
                EManager.emit(EName.onUpdateRank);
            }
        }
    }

    async doArenaResult(battleNo: number) {
        this._battleResult = null;
        let proto = await gm.request<ResourceVO>(GameProxy.apiarenaresult, battleNo);
        if (!proto.battleReport) {
            throw new ToastError("战斗异常");
        }
        this._battleResult = proto;

        this.doGetTasksInfo();
        this.doGetArena(0);
    }

    showReward() {
        if (this._battleResult && this._battleResult.battleReport.isWin == 0) {
            gm.getReward(this._battleResult, true);
        }
    }

    async doGetArenaRecord(arenaType: ArenaType) {
        this._recordList = await gm.request<ArenaRecordVO[]>(GameProxy.apiarenarecord, arenaType);
    }

    async doArenaRevenge(record: ArenaRecordVO) {
        this._rivalRecordData = record;
        let arenaRevengeReq = new ArenaRevengeReq();
        arenaRevengeReq.heros = this._myDefend.heros;
        arenaRevengeReq.id = record.id;
        arenaRevengeReq.width = cc.director.getWinSize().width;
        arenaRevengeReq.height = 750;
        arenaRevengeReq.version = gm.fightVersion > 0 ? gm.fightVersion : rpgfight.version.codeVersion;
        try {
            this._battleData = await gm.request<Battle_ArenaData>(GameProxy.apiarenarevenge, arenaRevengeReq);
            if (this._myArena.freeTimes <= 0) {
                bagLogic.changeGoodAmount(GoodId.WarriorTicket, -1);
            } else {
                this._myArena.freeTimes--;
                if (this._myArena.freeTimes == 0) {
                    promptLogic.setPromptRead([PromptType.ARENA_NORMAL_READY]);
                }
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    async doArenaPlayBack(battleNo: number, playbackUrl?: string) {
        if (playbackUrl) {
            this._battleDataUrl = playbackUrl;
        } else {
            this._battleDataUrl = await gm.request<string>(GameProxy.apiarenaplayback, battleNo);
        }
        try {
            let proto = await HttpProxy.httpGet<string>(this._battleDataUrl);
            this._battleData = JSON.parse(proto) as Battle_ArenaData;
        } catch (e) {
            gm.toast(stringConfigMap.key_common_tip8.Value);
        }
    }

    async doArenaBuyTickets(cnt: number) {
        let proto = await gm.request<ResourceVO>(GameProxy.apiarenabuyTickets, cnt);
        bagLogic.changeGoodAmount(GoodId.Diamond, -(100 * cnt));
        gm.getReward(proto, true);
        commitLogic.costDiamond((100 * cnt), DiamondCost.arenaTicket);
        activityLogic.doIncTaskActProgress(ActivityType.CrazyArena, TaskActivityType.BuyArenaTicket, null, cnt);
    }

    getTroops(): { selfTroop: Hero[], enemyTroop: Hero[] } {
        let selfHeros: { [key: number]: Hero } = {};
        for (let proto of arenaLogic.getMyDefend().heros) {
            let hero = heroLogic.getHero(proto.heroId);
            if (hero) {
                selfHeros[proto.battleStation] = hero;
            }
        }

        let selfTroop: Hero[] = [];
        for (let i = 0; i < playerLogic.getMaxInstanceTroopCount(); i++) {
            selfTroop.push(selfHeros[i + 1]);
        }

        return {
            selfTroop: selfTroop,
            enemyTroop: []
        }
    }

    getDefenseTroops(): Hero[] {
        let defenseTroop: Hero[] = [];
        if (this._roleDefend) {
            let defenseHeros: { [key: number]: Hero } = {};
            let heros = this._roleDefend.heros;
            for (let hero of heros) {
                if (hero.data) {
                    let _hero = new Hero(hero.data);
                    defenseHeros[hero.battleStation] = _hero;
                }
            }
            for (let i = 0; i < playerLogic.getMaxInstanceTroopCount(); i++) {
                defenseTroop.push(defenseHeros[i + 1]);
            }
        }
        return defenseTroop;
    }

    getAIDefenseTroops(nick: string): Hero[] {
        let defenseTroop: Hero[] = [];
        let aiHeroList: HeroVO[] = this.getAIHeroList(nick);
        let defenseHeroes: { [key: number]: Hero } = {};
        for (let i = 0; i < aiHeroList.length; i++) {
            defenseHeroes[i + 1] = new Hero(aiHeroList[i]);
        }
        for (let i = 0; i < playerLogic.getMaxInstanceTroopCount(); i++) {
            defenseTroop.push(defenseHeroes[i + 1]);
        }
        return defenseTroop;
    }

    getRecordTroops(record: ArenaRecordVO): Hero[] {
        let heroes: Hero[] = [];
        for (let heroVo of record.aiHeroes) {
            if (heroVo) {
                heroes.push(new Hero(heroVo));
            } else {
                heroes.push(null);
            }
        }
        return heroes;
    }
}

let arenaLogic = new ArenaLogic();
export default arenaLogic;