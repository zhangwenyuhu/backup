import BaseLogic from "./BaseLogic";
import IGameManager from "../manager/IGameManager";
import GameProxy, {
    AdvBattleReportVO,
    ArenaAdvBattleReq,
    ArenaAdvRecordVO,
    ArenaReq,
    Battle_ArenaData,
    Battle_ArenaData_Mul,
    Battle_heroConfig,
    DefendHeroBO,
    HeroVO,
    PlayBackReq,
    RankVO,
    ResourceVO,
    RoleDefendVO,
    RoleRankVO
} from "../proxy/GameProxy";
import arenaLogic, { ArenaType } from "./ArenaLogic";
import Hero from "../data/card/Hero";
import playerLogic from "./PlayerLogic";
import EManager, { EName } from "../manager/EventManager";
import HttpProxy from "../proxy/HttpProxy";
import bagLogic from "./BagLogic";
import { GoodId } from "../data/card/Good";
import promptLogic, { PromptType } from "./PromptLogic";
import { BattleType, Storage, TaskActivityType } from "../utils/DefineUtils";
import Card from "../data/card/Card";
import commitLogic, { DiamondCost } from "./CommitLogic";
import storageUtils from "../utils/StorageUtils";
import heroLogic from "./HeroLogic";
import UnlockWrapper from "../view/widget/unlock/UnlockWrapper";
import { unlockConfigMap } from "../configs/unlockConfig";
import activityLogic, { ActivityType } from "./ActivityLogic";
import gm from "../manager/GameManager";
import commonUtils from "../utils/CommonUtils";
import ArenaRankconfig from "../configs/ArenaRankconfig";
import {stringConfigMap} from "../configs/stringConfig";

class ArenaSeniorLogic extends BaseLogic {
    protected _oldRankId: number = 0;
    protected _myRank: RankVO = null;
    protected _ranks: RankVO[] = [];
    protected _roleRankVO: RoleRankVO = null;
    protected _matchList: RankVO[] = [];
    protected _recordList: ArenaAdvRecordVO[] = [];
    protected _defenseHeroVo: RoleDefendVO = null;
    protected _rivalDefenseHeroVo: RoleDefendVO = null;
    protected _rivalData: RankVO = null;
    protected _battleData: Battle_ArenaData_Mul = null;
    protected _battlePlayBackMulData: { [key: number]: any } = {};
    protected _battlePlayBackData: Battle_ArenaData = null;
    protected _battleResult: AdvBattleReportVO = null;
    protected _battleDataUrl: string = "";
    protected _battleTurnResult: { [key: number]: boolean } = {};
    protected _lastCoinsTime: number = 0;
    public fightNo: number = 0;

    async init(gm: IGameManager) {
        super.init(null, gm);
        await this.doGetMyRank();
    }

    get myRoleRank(): RoleRankVO {
        return this._roleRankVO;
    }

    get myRank(): RankVO {
        return this._myRank;
    }

    get Ranks(): RankVO[] {
        return this._ranks;
    }

    getMatchList() {
        return this._matchList;
    }

    getRecordList() {
        return this._recordList;
    }

    getDefense() {
        return this._defenseHeroVo;
    }

    getDefenseByGroup(groupId: number) {
        let defense = this._defenseHeroVo.heros.where(a => a.groupId == groupId);
        return defense;
    }

    getBattleScene(groupId: number): rpgfight.SceneConfig {
        let json = JSON.stringify(this._battleData.datas[groupId - 1].scene);
        return JSON.parse(json) as rpgfight.SceneConfig;
    }

    getBattleSceneMulti(groupId: number): rpgfight.SceneConfig {
        let json = JSON.stringify(this._battlePlayBackMulData[groupId].scene);
        return JSON.parse(json) as rpgfight.SceneConfig;
    }

    getBattleData(): Battle_ArenaData_Mul {
        return this._battleData;
    }

    getBattleDataByGroupId(groupId: number): Battle_ArenaData {
        return this._battleData.datas[groupId - 1];
    }

    getBattleReport() {
        return this._battleResult;
    }

    getScore(): string {
        let winCnt = 0;
        for (let result of Object.values(this._battleResult.battleWin)) {
            if (result) {
                winCnt++;
            }
        }
        return `${winCnt}:${3 - winCnt}`;
    }

    getPlayBackBattleData(): Battle_ArenaData {
        return this._battlePlayBackData;
    }

    getPlayBackMulBattleData(groupId: number): Battle_ArenaData {
        return this._battlePlayBackMulData[groupId];
    }

    setBattleTurnResult(groupId: number, win: boolean) {
        this._battleTurnResult[groupId] = win;
    }

    getBattleTurnResult(groupId: number) {
        return this._battleTurnResult[groupId];
    }

    getRivalData() {
        return this._rivalData;
    }

    getLastCoinsTime() {
        return this._lastCoinsTime;
    }

    async doGetRank() {
        this._ranks = await this._gm.request<RankVO[]>(GameProxy.apiarenarank, 1);
    }

    protected _getArenaReq() {
        let arenaReq = new ArenaReq();
        arenaReq.type = 1;
        arenaReq.heros = [];
        let heroes = heroLogic.getHeroes({ sort: true });
        let selectHeroes: Hero[] = [];
        for (let i = 0; i < heroes.length; i++) {
            if (selectHeroes.length < 15 && selectHeroes.find(a => a.getIndex() == heroes[i].getIndex()) == null) {
                selectHeroes.push(heroes[i]);
            }
        }
        for (let i = 0; i < playerLogic.getMaxInstanceTroopCount() * 3; i++) {
            let hero = selectHeroes[i];
            let defendHeroBO = new DefendHeroBO();
            defendHeroBO.groupId = Math.floor(i / 5) + 1;
            defendHeroBO.battleStation = i % 5 + 1;
            if (hero) {
                defendHeroBO.heroId = hero.getId();
            } else {
                defendHeroBO.heroId = "";
            }
            arenaReq.heros.push(defendHeroBO);
        }
        return arenaReq;
    }

    async doUnlockArena() {
        if (UnlockWrapper.isUnlock(unlockConfigMap.高阶竞技场) && !storageUtils.getBoolean(Storage.ArenaSeniorDefense)) {
            await this._gm.request(GameProxy.apiarenasetDefendHero, this._getArenaReq());
            storageUtils.setBoolean(Storage.ArenaSeniorDefense.Key, true, true);
            this.doGetDefenseHero();
        }
    }

    async doGetMyRank() {
        if (!storageUtils.getBoolean(Storage.ArenaSeniorDefense)) {
            await this._gm.request(GameProxy.apiarenasetDefendHero, this._getArenaReq());
            storageUtils.setBoolean(Storage.ArenaSeniorDefense.Key, true, true);
            this.doGetDefenseHero();
        }
        this._roleRankVO = await this._gm.request<RoleRankVO>(GameProxy.apiarenaadvmyRank, null);
        this._myRank = this._roleRankVO.myRanks[0];
        if (this._roleRankVO.freeTimes == 0 || this._myRank.no == 1) {
            promptLogic.setPromptRead([PromptType.ARENA_ADV_READY]);
        }
        this._lastCoinsTime = this._gm.getCurrentTimestamp();
    }

    async doMatch(arenaType: ArenaType, touch: boolean = false) {
        this._matchList = await this._gm.request<RankVO[]>(GameProxy.apiarenamatch, arenaType);
        this._matchList.sort((a, b) => {
            return b.score - a.score;
        });
        if (touch) {
            gm.toast(stringConfigMap.key_auto_557.Value);
        }
    }

    async doGetDefenseHero() {
        let arenaReq = new ArenaReq();
        arenaReq.type = 1;
        this._defenseHeroVo = await gm.request<RoleDefendVO>(GameProxy.apiarenadefendHero, arenaReq);
    }

    async doSetDefenseHero(arenaReq: ArenaReq, force: boolean = false) {
        let needChange: boolean = false;
        for (let hero of arenaReq.heros) {
            let config = null;
            if (this._defenseHeroVo) {
                config = this._defenseHeroVo.heros.find(a => a.heroId == hero.heroId && a.battleStation == hero.battleStation);
            }
            if (hero.heroId != "" && config == null) {
                needChange = true;
                break;
            } else if (hero.heroId == "" && (this._defenseHeroVo && this._defenseHeroVo.heros.find(a => a.battleStation == hero.battleStation) != null)) {
                needChange = true;
                break;
            }
        }
        if (needChange || force) {
            await gm.request(GameProxy.apiarenasetDefendHero, arenaReq);
            await this.doGetDefenseHero();
            await this.doGetMyRank();
            for (let rank of this._ranks) {
                if (rank.roleId == this._myRank.roleId) {
                    rank.power = this._myRank.power;
                }
            }
            EManager.emit(EName.onArenaDefenseRefresh);
        }
    }

    async doGetRivalDefenseHero(rivalRoleId: string) {
        let arenaReq = new ArenaReq();
        arenaReq.type = 1;
        arenaReq.rivalRoleId = rivalRoleId;
        this._rivalDefenseHeroVo = await gm.request<RoleDefendVO>(GameProxy.apiarenadefendHero, arenaReq);
    }

    async doBuyTickets(price: number) {
        // let proto = await gm.request<ResourceVO>(GameProxy.apiarenaadvbuyTickets, null);
        // bagLogic.changeGoodAmount(GoodId.Diamond, -price);
        // this._roleRankVO.buyTimes++;
        // gm.getReward(proto);
        // commitLogic.costDiamond(price, DiamondCost.seniorArenaTicket);
        // activityLogic.doIncTaskActProgress(ActivityType.CrazyArena, TaskActivityType.BuySeniorTicket, null, 1);
    }

    async doBattle(rank: RankVO) {
        this._rivalData = rank;
        let arenaAdvBattleReq = new ArenaAdvBattleReq();
        let list = [];
        let troops = await playerLogic.getTroop(BattleType.PVP_Senior);
        for (let i = 1; i <= 3; i++) {
            let defendHeroBoList: DefendHeroBO[] = [];
            for (let index = (i - 1) * 5; index < i * 5; index++) {
                let hero = troops[index];
                let heroBo = new DefendHeroBO();
                heroBo.heroId = hero ? hero.getId() : "";
                heroBo.groupId = i;
                heroBo.battleStation = index % 5 + 1;
                defendHeroBoList.push(heroBo);
            }
            list.push(defendHeroBoList);
        }
        arenaAdvBattleReq.type = 1;
        arenaAdvBattleReq.heros = list;
        arenaAdvBattleReq.rivalRoleId = rank.role.roleId;
        arenaAdvBattleReq.width = cc.director.getWinSize().width;
        arenaAdvBattleReq.height = 750;
        arenaAdvBattleReq.version = gm.fightVersion > 0 ? gm.fightVersion : rpgfight.version.codeVersion;
        this._battleTurnResult = {};
        try {
            this._battleData = await gm.request<Battle_ArenaData_Mul>(GameProxy.apiarenaadvbattle, arenaAdvBattleReq);
            if (this._roleRankVO.freeTimes <= 0) {
                bagLogic.changeGoodAmount(GoodId.SeniorWarriorTicket, -1);
            } else {
                this._roleRankVO.freeTimes--;
                if (this._roleRankVO.freeTimes == 0) {
                    promptLogic.setPromptRead([PromptType.ARENA_ADV_READY]);
                }
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    async doPlaybackMul(battleNo: string) {
        let playBackReq = new PlayBackReq();
        playBackReq.battleNo = battleNo;
        playBackReq.type = 1;
        let proto = await gm.request<string[]>(GameProxy.apiarenaadvplayback, playBackReq);
        if (proto.length == 0) {
            gm.toast(stringConfigMap.key_auto_558.Value);
            return;
        }
        let groupId = 1;
        for (let pro of proto) {
            let result = await HttpProxy.httpGet<string>(pro);
            this._battlePlayBackMulData[groupId] = JSON.parse(result) as Battle_ArenaData;
            groupId++;
        }
    }

    async doGetRecord() {
        this._recordList = await gm.request<ArenaAdvRecordVO[]>(GameProxy.apiarenaadvrecord, null);
    }

    async doRecvAdvCoin(): Promise<Card[]> {
        let proto = await gm.request<ResourceVO>(GameProxy.apiarenaadvrecvAdvCoin, null);
        if (proto) {
            let cards = gm.getReward(proto, false);
            this._myRank.conins = 0;
            this._lastCoinsTime = gm.getCurrentTimestamp();
            return cards;
        }
        return [];
    }

    async doResult(battleNo: string) {
        this._battleResult = await gm.request<AdvBattleReportVO>(GameProxy.apiarenaadvresult, battleNo);
        this._oldRankId = this._myRank.advRankId;
        this._rivalData.no = Number(this._battleResult.rivalNewRank);
        this._rivalData.advRankId = this._battleResult.rivalNewRankId;
        this._rivalData.score = this._battleResult.rivalNewScore;
        this._myRank.no = Number(this._battleResult.newRank);
        this._myRank.advRankId = this._battleResult.newRankId;
        this._myRank.score = this._battleResult.newScore;
        if (this._battleResult.resourceVO) {
            gm.getReward(this._battleResult.resourceVO);
        }
        arenaLogic.doGetTasksInfo();
    }

    get oldRankId(): number {
        return this._oldRankId;
    }

    getArenaHeroConfig(hero: Battle_heroConfig[], withoutSkill: boolean, defense: boolean = false): rpgfight.HeroConfig[] {
        let list: rpgfight.HeroConfig[] = [];
        for (let enemy of hero) {
            let config = commonUtils.getHeroConfig(enemy, withoutSkill, defense);
            list.push(config);
        }
        return list;
    }

    getMyAttackTroops(heroes: Hero[], groupId: number): Hero[] {
        let list = [];
        for (let i = 0; i < heroes.length; i++) {
            let hero = heroes[i];
            let group = Math.floor(i / 5) + 1;
            if (group == groupId) {
                if (hero) {
                    list.push(hero);
                } else {
                    list.push(null);
                }
            }
        }
        return list;
    }

    getMyDefenseTroops(groupId: number): Hero[] {
        let defenseTroop: Hero[] = [];
        if (this._defenseHeroVo) {
            let defenseHeros: { [key: number]: Hero } = {};
            let heros = this._defenseHeroVo.heros;
            for (let hero of heros) {
                if (hero.data && hero.groupId == groupId) {
                    let _hero = new Hero(hero.data);
                    defenseHeros[hero.battleStation] = _hero;
                }
            }
            for (let i = 0; i < playerLogic.getMaxInstanceTroopCount(); i++) {
                defenseTroop.push(defenseHeros[i + 1]);
            }
        }
        return defenseTroop;
    }

    getEnemyDefenseTroops(groupId: number): Hero[] {
        let defenseTroop: Hero[] = [];
        if (this._rivalDefenseHeroVo) {
            let defenseHeros: { [key: number]: Hero } = {};
            let heros = this._rivalDefenseHeroVo.heros;
            for (let hero of heros) {
                if (hero.data && hero.groupId == groupId) {
                    let _hero = new Hero(hero.data);
                    defenseHeros[hero.battleStation] = _hero;
                }
            }
            for (let i = 0; i < playerLogic.getMaxInstanceTroopCount(); i++) {
                defenseTroop.push(defenseHeros[i + 1]);
            }
        }
        return defenseTroop;
    }

    getHeroCnt(heroes: Hero[]) {
        let cnt = 0;
        for (let hero of heroes) {
            if (hero) {
                cnt++;
            }
        }
        return cnt;
    }

    getArenaHero(groupId: number, isDefend: boolean = false): { selfHero: Hero[], enemyHero: Hero[] } {
        let selfHero: Hero[] = [];
        let enemyHero: Hero[] = [];
        for (let enemy of this._battlePlayBackMulData[groupId].heroList) {
            let heroVo = new HeroVO();
            heroVo.heroId = enemy.heroId;
            heroVo.heroCofId = Number(enemy.heroConfigId);
            heroVo.lv = Number(enemy.level);
            heroVo.rank = Number(enemy.rank);
            heroVo.equips = [];
            let hero = new Hero(heroVo);
            if (isDefend) {
                if (enemy.battleTeam == rpgfight.BattleTeam.our) {
                    enemyHero.push(hero);
                } else {
                    selfHero.push(hero);
                }
            }
            else {
                if (enemy.battleTeam == rpgfight.BattleTeam.our) {
                    selfHero.push(hero);
                } else {
                    enemyHero.push(hero);
                }
            }
        }
        return {
            selfHero: selfHero,
            enemyHero: enemyHero
        };
    }

}

let arenaSeniorLogic = new ArenaSeniorLogic();
export default arenaSeniorLogic;