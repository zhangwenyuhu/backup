import { stringConfigMap } from './../configs/stringConfig';
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from '../manager/GameManager';
import cm from '../manager/ConfigManager';
import growUpConfig from "../configs/growUpConfig";
import storeConfig, { storeConfigRow } from "../configs/storeConfig";
import vipconfig, { vipconfigRow } from "../configs/vipconfig";
import EManager, { EName } from "../manager/EventManager";
import GameProxy, { StoreVO, ResourceVO, PayOrderDO, GrowUpBO } from "../proxy/GameProxy";
import playerLogic from "./PlayerLogic";
import giftLogic from "./GiftLogic";
import benefitLogic from "./BenefitLogic";
import redPointLogic, { RedPointType } from "./RedPointLogic";
import Info from "../Info";
import { PromptType } from "../data/prompt/PromptModal";
import missionLogic from "./MissionLogic";
import commitLogic, { DiamondSource } from "./CommitLogic";
import { ActivityType } from "./ActivityLogic";
import activityLogic from "./ActivityLogic";
import heroLogic from "./HeroLogic";

export enum RightType {
    None = 0,
    IdleGold = 1,           // 挂机金币额外产出
    IdleExp = 2,            // 挂机英雄经验额外产出
    IdleCount = 3,          // 挂机次数上限
    AreaFreeCount = 4,      // 竞技场每日免费次数
    HeroTakeLimit = 5,      // 英雄数量
    SpeedUp = 6,            // 战斗加速
    SkipBattle = 7,         // 竞技场跳过战斗
    MazeGold = 8,           // 智慧树产出金币
    GuildBattle = 9,        // 公会BOSS挑战增加
    AutoXuanshang = 10,     // 一键派遣
    AutoTeamBattle = 11,    // 狩猎扫荡功能
    WheelTen = 12,          // 普通十连抽解锁
    WheelTenVip = 13,       // 普通转盘10连抽加成
    WheelAdv = 14,          // 高级转盘解锁
    resBuyTimes = 15,       // 资源副本购买次数
    Niudan = 16,            // 解锁扭蛋功能
    SupplyReset = 17,       // 高级搜寻重置次数
    TiliBuyLimit = 18,      // 体力点购买次数
}

export const SYSTEM = {
    ANDROID: 1,
    IOS: 2,
    OTHER: 3,
}

export enum PLAT {
    CN = 1,
    US = 2,
}
/*
"grow": {
    "recvs": {},
    "stageIdNow": 0,
    "open": false
  },
  "normalCard": {
    "cardType": 0,
    "endTs": 0
  },
  "superCard": {
    "cardType": 1,
    "endTs": 0
  },
  "buyInfo": [
    {
      "configId": 1,
      "buyCount": 0
    },
    {
      "configId": 2,
      "buyCount": 0
    },]
*/
/* 商城&vip */
export class RechargeLogic extends BaseLogic {
    protected firstPayInfo: GrowUpBO = null;
    protected costFirstPayInfo: { [key: string]: GrowUpBO } = {};
    public vipReward: { [key: number]: boolean } = {};
    private _payCfgs: { [key: number]: storeConfigRow } = {};
    private _vipCfgs: { [key: number]: { cfg: vipconfigRow, desc: { isNew: boolean, desc: string, value: string }[] } } = {};
    private _storeBuyInfo: StoreVO = null;
    public orderIdList: { orderId: string, checkTimes: number }[] = [];
    public pushOrderList: string[] = [];
    public _paying: boolean = false;
    public pioneerReward: boolean = false;

    init(gm: IGameManager) {
        super.init(null, gm);

        this.initCfgs();
        this.initGSSdkPay();
        this.initPayEventListen();
        this.bindRedFunc();
    }

    resetAll() {

    }

    public onMessage(msg: any) {
        if (msg) {
            let res = msg.resourceVO;
            let orderNo = msg.tradeOutNo;
            let storeConfigId = msg.storeConfigId;
            this.pushOrderList.push(msg.tradeOutNo);
            this.onReward(msg);
        }
    }

    async onReward(msg: any) {
        let id = msg.storeConfigId;
        let cfg = cm.getStoreConfig(id);
        if (!this.pioneerReward) {
            gm.getReward(msg.resourceVO);
        }
        await this.storeBuyInfoReq();
        if (cfg.type == 6) {
            await benefitLogic.rmCloudDataReq(id);
        }
        if (giftLogic.dailyLightModal && giftLogic.dailyLightModal.remainTime > 0) {
            giftLogic.dailyLightModal.doCharge(cfg.price);
        }
        let types = [2014, 2006, 2008, 2019];
        for (let type of types) {
            let actData = activityLogic.getActivityConfigs(type);
            if (actData && actData.sevenInfo) {
                actData.sevenInfo.doCharge(cfg.price);
            }
        }
        if (cfg.type == 19) {
            heroLogic.doBuySkin(cfg.item);
        }
        EManager.emit(EName.onApplyOrder, msg);
        EManager.emit(EName.onActivityBtnFresh);
        EManager.emit(EName.onRecharge, id);

        commitLogic.commitReward(msg.resourceVO, cfg.title);
    }

    // vip 奖励领取情况
    async vipRewardStatuReq() {
        this.vipReward = await gm.request<{ [key: number]: boolean }>(GameProxy.apiStoregetVipRerwardStatus);
        this.vipReward = this.vipReward ? this.vipReward : {};
    }

    // 领取vip奖励
    async getVipRewardReq(level: number) {
        let proto = await gm.request<ResourceVO>(GameProxy.apiStorerecvVipReward, level);
        this.vipReward[level] = true;
        gm.getReward(proto);
        commitLogic.commitReward(proto, DiamondSource.vip);
    }

    // 领取首充礼包奖励
    async getFirstPayRewardReq(money: number) {
        let proto = await gm.request<ResourceVO>(GameProxy.apiStorerecvFirstReward, money);
        gm.getReward(proto);
        commitLogic.commitReward(proto, DiamondSource.firstPay);
    }

    // 充值表充值情况
    async storeBuyInfoReq() {
        let proto = await gm.request<StoreVO>(GameProxy.apiStoregetStore);
        this._storeBuyInfo = proto;
        if (proto) {
            this.firstPayInfo = proto.firstPay;
            this.costFirstPayInfo = proto.costFirstPay as any;
            giftLogic.activeGiftData = proto.active;
            giftLogic.wisdomGiftData = proto.wisdom;
            giftLogic.tehuiGiftData = proto.cycle;
            giftLogic.videoGiftData = proto.free;
            giftLogic.newPlayerFund = proto.sevenFund;
            giftLogic.mainOrder = proto.mainOrder;
            giftLogic.towerOrder = proto.towerOrder;
        }

        EManager.emit(EName.onRedDirty, PromptType.GrowupGiftBtn);
        EManager.emit(EName.onRedDirty, PromptType.FirstPayBtn);
        EManager.emit(EName.onRedDirty, PromptType.MonthCardBtn);
        EManager.emit(EName.onRedDirty, PromptType.WeekCardBtn);
        EManager.emit(EName.onRedDirty, PromptType.LifeCardBtn);
        EManager.emit(EName.onRedDirty, PromptType.PVECommand);
        EManager.emit(EName.onRedDirty, PromptType.TowerCommand);
    }

    // 购买过
    get hasStoreBuy() {
        return this._storeBuyInfo.buyInfo.find(a => a.buyCount > 0) != null;
    }

    // 获取玩家已充值金额
    public getPayMoney(): number {
        let money: number = 0;
        if (!this._storeBuyInfo) { return money; }
        let buyInfos = this._storeBuyInfo.buyInfo;
        if (buyInfos) {
            for (let i = 0; i < buyInfos.length; i++) {
                if (buyInfos[i].buyCount > 0) {
                    money += cm.getStoreConfig(buyInfos[i].configId).money * buyInfos[i].buyCount;
                }
            }
        }
        return money;
    }

    async iap(id: number, limitTs: number = -1) {
        let cfg = cm.getStoreConfig(id);
        if (!cfg) {
            gm.toast(stringConfigMap.key_auto_552.Value);
            return;
        }
        commitLogic.payPanelClick('', id);

        if (CC_JSB) {
            if (cc.sys.os == cc.sys.OS_IOS) {
                this._doPay(id, "IosPay");
            }
            else {
                gcc.core.showLayer("prefabs/panel/benefit/PaywayPanel", {
                    data: {
                        success: (payWay: string) => {
                            let nowTs: number = gm.getCurrentTimestamp() / 1000;
                            if (limitTs < 0 || nowTs <= limitTs) {
                                this._doPay(id, payWay);
                            } else {
                                gm.toast(stringConfigMap.key_desc_11.Value);
                            }
                        }
                    }
                });
            }
        }
        else {
            let roleId = playerLogic.getPlayer().getRoleId();
            await this.httpRequest("/api/index/buyStore", `roleId=${roleId}&storeConfig=${id}&amt=${cfg.money * 100}`, "GET");
        }
    }

    protected _doPay(id: number, payWay: string) {
        let cfg = cm.getStoreConfig(id);
        if (!cfg) { return; }

        this._paying = true;
        console.info("开始调用gssdk充值: " + cfg.title);
        this._payment(payWay, cfg, () => {
            console.error(cfg.title + " 支付成功")
        }, () => {
            console.error(cfg.title + " 支付失败");
        });
    }

    async httpRequest(api: string, params: string, method: string, data?: string) {
        return new Promise<string>((resolve, reject) => {
            let xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && (xhr.status >= 200 && xhr.status < 400)) {
                    let response = xhr.responseText;
                    console.log(response);
                    try {
                        let obj = JSON.parse(response);
                        if (typeof obj.m == "string" && obj.m.length > 0) {
                            reject(obj.m);
                        }
                        else {
                            resolve(obj);
                        }
                    } catch (error) {
                        reject(error);
                    }
                }
            }
            xhr.onerror = (ev) => {
                reject(ev);
            }
            xhr.ontimeout = () => {
                reject("服务器超时")
            }
            xhr.open(method, `https://${GameProxy.gameClient.host}:443${api}?${params}`);
            xhr.setRequestHeader("accept", "*/*");
            xhr.setRequestHeader("Authorization", "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhcHBpZCI6MTAxMDAsInVzZXJpZCI6MSwidWlkIjoiMSIsInJvbGVpZCI6MSwiY2RpZCI6LTEsImRpc3RyaWN0bmFtZSI6IlRFU1QxIiwiZGlzdHJpY3RvcGVuYXQiOjE1NTQzNTg3MDMwMDAsInJvbGVjcmVhdGUiOjE1NTQzNTg3MDMwMDAsImV4cCI6MTU3MTM1MzE3N30.r7VwjghvCp2Ju8rqm3yzaHPWX_zlCvKSOfJjRPJXCWQ");
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.send(data);
        });
    }

    public getBuyCount(cfgId: number): number {
        let num: number = 0;
        if (this._storeBuyInfo && this._storeBuyInfo.buyInfo) {
            let item = this._storeBuyInfo.buyInfo.find((a) => { return a.configId == cfgId });
            if (item) { num = item.buyCount };
        }
        return num;
    }
    public isPayed() {
        if (this._storeBuyInfo && this._storeBuyInfo.buyInfo) {
            let payed: boolean = Object.keys(this._storeBuyInfo.buyInfo).some((v, i, a) => {
                return this._storeBuyInfo.buyInfo[v].buyCount > 0;
            })
            return payed;
        }
        return false;
    }
    public isFirstPayCanRecv(tag?: string) {
        let canRecv: boolean = false;
        let len = Object.keys(this.firstPayInfo.recvs).length;
        for (let i = 0; i < len; i++) {
            let day: number = i + 1;
            if (rechargeLogic.getFirstPayNowDay(tag) >= day && !rechargeLogic.isFirstPayRecv(day, tag)) {
                canRecv = true;
                break;
            }
        }
        return canRecv;
    }
    public isAllRecved(tag?: string) {
        let allRecved: boolean = true;
        let len = Object.keys(this.firstPayInfo.recvs).length;
        let nowDay: number = rechargeLogic.getFirstPayNowDay(tag);
        if (nowDay < len) { return false; }
        for (let i = 0; i < len; i++) {
            let day: number = i + 1;
            if (!rechargeLogic.isFirstPayRecv(day, tag)) {
                allRecved = false;
            }
        }
        return allRecved;
    }
    public getFirstPayNowDay(tag?: string) {
        if (tag && this.costFirstPayInfo[tag]) {
            return this.costFirstPayInfo[tag].stageIdNow;
        }
        return this.firstPayInfo.stageIdNow;
    }
    public isFirstPayRecv(day: number, tag?: string) {
        if (tag && this.costFirstPayInfo[tag]) {
            return this.costFirstPayInfo[tag].recvs[`${day}`] || false;
        }
        return this.firstPayInfo.recvs[`${day}`] || false;
    }
    public isFirstPayValid(tag?: string): boolean {
        if (tag && this.costFirstPayInfo[tag]) {
            return this.costFirstPayInfo[tag].open;
        }

        let keys = Object.keys(this.costFirstPayInfo);
        let valid = keys.some((v, i, a) => { return this.costFirstPayInfo[v].open; });
        return this.firstPayInfo.open || valid;
    }
    public growupGiftBuyInfo() {
        if (this._storeBuyInfo) { return this._storeBuyInfo.grow; }
        return null;
    }
    public normalMonthCardBuyInfo() {
        if (this._storeBuyInfo) { return this._storeBuyInfo.normalCard; }
        return null;
    }
    public superMonthCardBuyInfo() {
        if (this._storeBuyInfo) { return this._storeBuyInfo.superCard; }
        return null;
    }
    public weekCardBuyInfo() {
        if (this._storeBuyInfo) { return this._storeBuyInfo.weekCard; }
    }
    public lifeCardBuyInfo() {
        if (this._storeBuyInfo) { return this._storeBuyInfo.lifeCard; }
    }
    public skinBuyLimit(id) {
        if (this._storeBuyInfo) {
            let storeCfg = cm.getStoreConfig(id);
            let buyCount = this._storeBuyInfo.buyInfo.find(a => a.configId == id).buyCount;
            return storeCfg.buylimit - buyCount <= 0;
        }
        return false;
    }
    // 月卡是否购买过
    public isMonthCardBuy(): boolean {
        return this.getBuyCount(7) > 0 || this.getBuyCount(8) > 0;
    }

    // 超级月卡是否购买过
    public isSuperMonthCardBuyed(): boolean {
        return this.getBuyCount(8) > 0;
    }

    // 支付接口
    protected _payment(payWay: any, cfg: storeConfigRow, success: Function, fail?: Function) {
        let userLevel: number = playerLogic.getPlayer().getLevel();
        let mission: number = missionLogic.getCurrentMission().getStageId();
        let districtId: number = gm.districtId;
        let snode: string = gm.snode || gssdk.loginData.getLoginData().node || "CN";
        let money = Info.mode == "develop" ? 1 : cfg.money;
        const item: GSSDK.PayFlow.PaymentParams = {
            amount: cfg.amount1,
            id: cfg.Id,
            price: money,
            money: money,
            productId: cfg.productId || "com.glee.zombiewar2.u6",
            title: cfg.title,
            payWay: payWay,
            options: {
                customExtra: `${districtId},${snode},${userLevel},${mission}`,
                customJsonExtra: `{"level":${userLevel} }`,
            },
        }
        return gssdk.payflow.payment(item, success as any, fail);
    }

    private initGSSdkPay() {
        let isCN = this.getPlat() == PLAT.CN;
        let payConfig: GSSDK.PayFlow.RechargeConfigRow[] = [];
        for (let cfg of storeConfig) {
            payConfig.push({
                amount: cfg.amount1,
                id: cfg.Id,
                price: isCN ? cfg.money : cfg.usd,
                money: cfg.usd,
                productId: cfg.productId,
                title: cfg.title,
            })
        }
        let opt = { chargeconfig: payConfig, payWays: [] }
        if (Info.requireWechatPay) {
            opt.payWays.push("WechatPay")
            opt.payWays.push("AliPay")
        }
        gssdk.payflow.initConfig(opt);
        gssdk.payflow.initListener();
    }

    private initPayEventListen() {
        gssdk.payEvent.on("onApplyOrder", (info) => {
            console.info("gssdk pay over:");
            console.info(info);
            if (!this._paying) { return; }
            this._paying = false;
            this.orderIdList.push({ orderId: info.orderInfo.outTradeNo, checkTimes: 5 });
            let iconfig = info.config
            let config: storeConfigRow = cm.getStoreConfig(iconfig.id);
            let notifyData = { orderInfo: info.orderInfo, config: config, isDelayedApply: info.isDelayedApply };
            EManager.emit(EName.onApplyOrder, notifyData);
        })
    }

    // 获取用于选择货币类型的标志
    public getPlat() {
        return PLAT.CN;
        // if (gdk && gdk.country) {
        //     if (gdk.country.indexOf("CN") != -1) {
        //         return PLAT.CN;
        //     } else {
        //         return PLAT.US;
        //     }
        // }
        // if (cc.sys.os == cc.sys.OS_ANDROID) {
        //     unit = PLAT.US;
        // } else if (cc.sys.os == cc.sys.OS_IOS) {
        //     unit = PLAT.CN;
        // } else {
        //     unit = PLAT.CN;
        // }
        // return unit;
    }
    // 是否app ios平台
    public isIosApp() {
        return cc.sys.os == cc.sys.OS_IOS;
    }
    // 是否app android平台
    public isAndroidApp() {
        return cc.sys.os == cc.sys.OS_ANDROID;
    }
    // 返回用于购买界面显示的值
    public getChargeValue(cfg: storeConfigRow) {
        if (cfg) {
            if (this.getPlat() == PLAT.CN) {
                return cfg.money;
            } else if (this.getPlat() == PLAT.US) {
                return cfg.usd;
            } else {
                return cfg.money;
            }
        }
        return 0;
    }
    // 返回用于购买界面显示的货币符号
    public getMoneyUnit() {
        let unit: string = "";
        if (this.getPlat() == PLAT.CN) {
            unit = "¥";
        } else if (this.getPlat() == PLAT.US) {
            unit = "$";
        } else {
            unit = "¥";
        }
        return unit;
    }

    public getVipCfgInfo(level: number) {
        return this._vipCfgs[level];
    }

    // 获取vip功能的解锁等级
    public getUnlockVipLevel(type: RightType): number {
        let level: number = 1;
        let max = vipconfig.length;
        for (let i = 0; i < max; i++) {
            let data = this._vipCfgs[i + 1]
            if (data && data.desc) {
                let len = data.desc.length;
                for (let j = 0; j < len; j++) {
                    if (data.desc[j].isNew && data.desc[j].desc === this.rightDesc(type)) {
                        return data.cfg.viplevel;
                    }
                }
            }
        }
        return level;
    }

    // 获取vip等级对应功能的值
    public getVipBuffValue(type: RightType, level: number): number {
        let data: number = 0;
        let cfg = vipconfig.find((a) => { return a.viplevel == level; })
        if (cfg) {
            if (type == RightType.IdleGold) {
                data = cfg.idlegold;
            } else if (type == RightType.IdleExp) {
                data = cfg.idleexp;
            } else if (type == RightType.IdleCount) {
                //data = cfg.quickidle;
            } else if (type == RightType.AreaFreeCount) {
                data = cfg.arenafreetime;
            } else if (type == RightType.HeroTakeLimit) {
                data = cfg.herotakelimit;
            } else if (type == RightType.SpeedUp) {
                //data = cfg.speedup;
            } else if (type == RightType.SkipBattle) {
                data = cfg.skipbattle;
            } else if (type == RightType.MazeGold) {
                data = cfg.mazegold;
            } else if (type == RightType.GuildBattle) {
                data = cfg.factionboss;
            } else if (type == RightType.AutoXuanshang) {
                data = cfg.gotobattle;
            } else if (type == RightType.AutoTeamBattle) {
                data = cfg.wipeout;
            } else if (type == RightType.WheelTen) {
                data = cfg.wheelTenLock;
            } else if (type == RightType.WheelTenVip) {
                data = cfg.wheelVipAdd;
            } else if (type == RightType.WheelAdv) {
                data = cfg.wheelAdvLock;
            } else if (type == RightType.resBuyTimes) {
                data = cfg.resourcetimebuy;
            } else if (type == RightType.Niudan) {
                data = cfg.egglock;
            } else if (type == RightType.TiliBuyLimit) {
                data = cfg.tilibuylimit;
            } else if (type == RightType.SupplyReset) {
                data = cfg.supplyreset;
            }
        }
        return data;
    }

    private initCfgs() {
        // 充值
        let cfgs = storeConfig.filter((v, i, a) => {
            return v.type == 1
        });
        this._payCfgs = {};
        cfgs.forEach((v, i, a) => {
            this._payCfgs[v.Id] = v;
        })

        // vip
        vipconfig.forEach((v, i, a) => {
            this._vipCfgs[v.ID] = { cfg: v, desc: [] }
        })
        this.initVipDesc();
    }

    private initVipDesc() {
        Object.keys(this._vipCfgs).forEach((v, i, a) => {
            let level = parseInt(v);
            let cfg: vipconfigRow = this._vipCfgs[level].cfg;

            this.addVipDesc(level, RightType.IdleGold, cfg.idlegold);
            this.addVipDesc(level, RightType.IdleExp, cfg.idleexp);
            //this.addVipDesc(level, RightType.IdleCount, cfg.quickidle);
            this.addVipDesc(level, RightType.AreaFreeCount, cfg.arenafreetime);
            this.addVipDesc(level, RightType.HeroTakeLimit, cfg.herotakelimit);
            //this.addVipDesc(level, RightType.SpeedUp, cfg.speedup);
            this.addVipDesc(level, RightType.SkipBattle, cfg.skipbattle);
            this.addVipDesc(level, RightType.MazeGold, cfg.mazegold);
            this.addVipDesc(level, RightType.GuildBattle, cfg.factionboss);
            this.addVipDesc(level, RightType.AutoXuanshang, cfg.gotobattle);
            this.addVipDesc(level, RightType.AutoTeamBattle, cfg.wipeout);
            this.addVipDesc(level, RightType.WheelTen, cfg.wheelTenLock);
            this.addVipDesc(level, RightType.WheelTenVip, cfg.wheelVipAdd);
            this.addVipDesc(level, RightType.WheelAdv, cfg.wheelAdvLock);
            this.addVipDesc(level, RightType.resBuyTimes, cfg.resourcetimebuy);
            this.addVipDesc(level, RightType.Niudan, cfg.egglock);
            //this.addVipDesc(level, RightType.SupplyReset, cfg.supplyreset);
            //this.addVipDesc(level, RightType.TiliBuyLimit, cfg.tilibuylimit);
        })
    }

    private addVipDesc(level: number, type: RightType, data: any) {
        if (data) {
            let bNew = this.isVipRightNew(level, type, data);
            this._vipCfgs[level].desc.push({ isNew: bNew, desc: this.rightDesc(type), value: this.rightValue(type, data) });
        }
    }

    private isVipRightNew(level: number, type: RightType, data: any): boolean {
        if (!data) { return false; }
        if (level == 1) { return true; }

        let notNew: boolean = false;
        let preCfgs = vipconfig.filter((v, i, a) => {
            return level > v.ID;
        })

        notNew = preCfgs.some((v, i, a) => {
            let result: boolean = false;
            if (type == RightType.IdleGold || type == RightType.IdleExp || type == RightType.IdleCount) {
                result = true;
            } else if (type == RightType.AreaFreeCount) {
                result = v.arenafreetime ? true : false;
            } else if (type == RightType.HeroTakeLimit) {
                result = v.herotakelimit ? true : false;
            } else if (type == RightType.SpeedUp) {
                //result = v.speedup ? true : false;
            } else if (type == RightType.SkipBattle) {
                result = v.skipbattle ? true : false;
            } else if (type == RightType.MazeGold) {
                result = v.mazegold ? true : false;
            } else if (type == RightType.GuildBattle) {
                result = v.factionboss ? true : false;
            } else if (type == RightType.AutoXuanshang) {
                result = v.gotobattle ? true : false;
            } else if (type == RightType.AutoTeamBattle) {
                result = v.wipeout ? true : false;
            } else if (type == RightType.WheelTen) {
                result = v.wheelTenLock ? true : false;
            } else if (type == RightType.WheelTenVip) {
                result = v.wheelVipAdd ? true : false;
            } else if (type == RightType.WheelAdv) {
                result = v.wheelAdvLock ? true : false;
            } else if (type == RightType.resBuyTimes) {
                result = v.resourcetimebuy ? true : false;
            } else if (type == RightType.Niudan) {
                result = v.egglock ? true : false;
            } else if (type == RightType.TiliBuyLimit) {
                result = v.tilibuylimit ? true : false;
            } else if (type == RightType.SupplyReset) {
                result = v.supplyreset ? true : false;
            }
            return result;
        })
        return !notNew;
    }

    private rightDesc(type: RightType): string {
        let desc: string = "";
        if (type == RightType.IdleGold) {
            desc = `挂机额外金币产出`;
        } else if (type == RightType.IdleExp) {
            desc = `挂机额外英雄经验产出`;
        } else if (type == RightType.IdleCount) {
            //desc = `每日快速挂机次数增加至`;
        } else if (type == RightType.AreaFreeCount) {
            desc = `竞技场每日免费次数增加:`;
        } else if (type == RightType.HeroTakeLimit) {
            desc = `英雄携带数量上限:`;
        } else if (type == RightType.SpeedUp) {
            desc = `解锁战斗加速`;
        } else if (type == RightType.SkipBattle) {
            desc = `解锁竞技场跳过战斗`;
        } else if (type == RightType.MazeGold) {
            desc = `智慧树产出智慧币增加`;
        } else if (type == RightType.GuildBattle) {
            desc = `公会Boss挑战次数增加:`;
        } else if (type == RightType.AutoXuanshang) {
            desc = `解锁悬赏栏一键上阵`;
        } else if (type == RightType.AutoTeamBattle) {
            desc = `解锁团队狩猎扫荡功能`;
        } else if (type == RightType.WheelTen) {
            desc = `解锁日常寻宝10连抽`;
        } else if (type == RightType.WheelTenVip) {
            desc = `公会日常寻宝10连抽额外增加至`;
        } else if (type == RightType.WheelAdv) {
            desc = `解锁精英寻宝`;
        } else if (type == RightType.resBuyTimes) {
            desc = `资源副本额外购买次数增加至`
        } else if (type == RightType.Niudan) {
            desc = `解锁心愿机`;
        } else if (type == RightType.SupplyReset) {
            desc = `高级搜寻重置次数增加至`;
        } else if (type == RightType.TiliBuyLimit) {
            desc = `体力点购买次数增加至`;
        }
        return desc;
    }

    public rightValue(type: RightType, data?: any): string {
        if (!data) { return ``; }
        let value: string = "";
        if (type == RightType.IdleGold) {
            value = `+${Math.floor(data * 100)}%`;
        } else if (type == RightType.IdleExp) {
            value = `+${Math.floor(data * 100)}%`;
        } else if (type == RightType.IdleCount) {
            value = `${data}`;
        } else if (type == RightType.AreaFreeCount) {
            value = `${data}` + `次`;
        } else if (type == RightType.HeroTakeLimit) {
            value = `+${data}`;
        } else if (type == RightType.SpeedUp) {
            value = ``;
        } else if (type == RightType.SkipBattle) {
            value = ``;
        } else if (type == RightType.MazeGold) {
            value = `+${Math.floor(data * 100)}%`;
        } else if (type == RightType.GuildBattle) {
            value = `${data}` + `次`;
        } else if (type == RightType.AutoXuanshang) {
            value = ``;
        } else if (type == RightType.AutoTeamBattle) {
            value = ``;
        } else if (type == RightType.WheelTen) {
            value = ``;
        } else if (type == RightType.WheelTenVip) {
            value = `${data}次`;
        } else if (type == RightType.WheelAdv) {
            value = ``;
        } else if (type == RightType.resBuyTimes) {
            value = `${data}次`;
        } else if (type == RightType.Niudan) {
            value = ``;
        } else if (type == RightType.SupplyReset) {
            value = `${data}次`;
        } else if (type == RightType.TiliBuyLimit) {
            value = `${data}次`;
        }
        return value;
    }

    public getRechargeStoreCfgs(): storeConfigRow[] {
        let tmp: storeConfigRow[] = [];
        Object.keys(this._payCfgs).forEach((v, i, a) => {
            tmp.push(this._payCfgs[v]);
        })
        tmp.sort((a, b) => {
            return a.order - b.order;
        })
        return tmp;
    }

    /*  --红点判断函数--   */

    public bindRedFunc() {
        redPointLogic.addFunc(RedPointType.Pay, null);
        redPointLogic.addFunc(RedPointType.Pay_Vip, this.isVipRed.bind(this));
    }

    public isVipRed(): boolean {
        let tmp: boolean = false;
        let vipLevel: number = playerLogic.getPlayer().getVipLevel();
        if (vipLevel == 0) { return false; }
        if (Object.keys(this.vipReward).length <= 0) { return false; }
        for (let i = 0; i < vipLevel; i++) {
            if (!this.vipReward[i + 1]) {
                tmp = true;
                break;
            }
        }
        return tmp;
    }
    /*  --红点判断函数--   */
}

let rechargeLogic = new RechargeLogic();
export default rechargeLogic;