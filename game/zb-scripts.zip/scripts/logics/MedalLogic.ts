
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import medalconfig from "../configs/medalconfig";
import medaltechinfoconfig from "../configs/medaltechinfoconfig";
import MedalTechData from "../data/medal/MedalTechData";
import medaltechconfig, { medaltechconfigRow } from "../configs/medaltechconfig";
import GameProxy, { ResourceVO, StrategicBO, HeroModulBO, MainTaskInfoVO } from "../proxy/GameProxy";
import gm from "../manager/GameManager";
import playerLogic from "./PlayerLogic";
import cm from "../manager/ConfigManager";
import heroLogic from "./HeroLogic";

export class MedalResNode {
    techId: number = 0;
    child: MedalResNode[] = [];
}

/* 勋章系统逻辑 */
export class MedalLogic extends BaseLogic {
    // 树节点信息集
    protected _techData: { [key: number]: MedalTechData } = {};
    // 树节点关系
    protected _techMap: { [key: number]: MedalResNode[] } = {};
    protected _quickTechMap: { [key: number]: MedalResNode } = {};
    // 树类型对应节点数量
    protected _medalTechCount: { [key: number]: number } = {};
    // 勋章通关任务奖励领取信息
    protected _medalReward: { [key: number]: boolean } = {};
    // 战略树加成信息
    protected _medalTreeBuff: number[][] = [];
    init(gm: IGameManager) {
        super.init(null, gm);
    }

    public getMaxMedalLv() { return medalconfig.length; }
    public getTechInfoCof(techType: number) {
        let cof = medaltechinfoconfig.find((a) => { return a.type == techType; });
        return cof;
    }

    // 战略树节点信息
    public getMedalTechData(id: number) { return this._techData[id]; }
    // 战略树节点
    public getMedalTechTreeNode(id: number) { return this._quickTechMap[id]; }
    // 类型对应的战略树
    public getMedalTechTree(type: number) { return this._techMap[type]; }
    // 获取树的节点数量
    public getMedalTechTreeCount(type: number) { return this._medalTechCount[type] || 0; }
    // 获取树的节点数量
    public getMedalTechTreeUnlockCount(type: number) {
        let num: number = 0;
        let cfgs = medaltechconfig.filter((v, i, a) => { return v.type == type; })
        for (let i = 0; i < cfgs.length; i++) {
            let data = this.getMedalTechData(cfgs[i].ID);
            if (data && data.isUnlock()) { num += 1; }
        }
        return num;
    }
    // 获取树消耗的战略点数量
    public getMedalTreeCostTech(type: number) {
        let num: number = 0;
        let cfgs = medaltechconfig.filter((v, i, a) => { return v.type == type; })
        for (let i = 0; i < cfgs.length; i++) {
            let data = this.getMedalTechData(cfgs[i].ID);
            if (data && data.isUnlock()) { num += data.getCostTech(); }
        }
        return num;
    }
    // 获取树可以消耗的战略点数量总量
    public getMedalTreeMaxTech(type: number) {
        let num: number = 0;
        let cfgs = medaltechconfig.filter((v, i, a) => { return v.type == type; })
        for (let i = 0; i < cfgs.length; i++) {
            let data = this.getMedalTechData(cfgs[i].ID);
            if (data) { num += data.getMaxTech(); }
        }
        return num;
    }
    // 解锁树条件
    public getMedalTreeUnlockData(type: number) {
        let cof = cm.getMedalTechInfoConfig(type);
        if (cof) { return [type - 1, cof.require]; }
        return [0, 0];
    }
    // 树是否解锁
    public isTreeUnlock(type: number) {
        if (type > 1) { if (!this.isTreeUnlock(type - 1)) { return false; } }

        let data = this.getMedalTreeUnlockData(type);
        if (data[0] == 0 || data[1] == 0) { return true; }
        return this.getMedalTreeCostTech(data[0]) >= data[1];
    }
    // 树节点当前等级
    public getMedalTechLv(id: number) { return this._techData[id].level; }
    // 树节点最高等级
    public getMedalTechLvMax(id: number) { return this._techData[id].getMaxLv(); }
    // 战略树信息获取
    public async medalTechReq() {
        let proto = await this._gm.request<StrategicBO>(GameProxy.apiRolegetStrategicInfo);
        this._initMedalTechData(proto.cfgLvMap as any);
        this._updateMedalTreeBuff();
    }

    // 净化任务奖励是否领取
    public isMedalTaskRecv(id: number) { return this._medalReward[id]; }
    // 获取战略树加成信息
    public getMedalTreeBuff() { return this._medalTreeBuff; }

    // 勋章升级
    public async medalLvupReq() {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiRolemedalLvUp);
        gm.getReward(proto);
        playerLogic.getPlayer().addMedalLevel();

        // 更新勋章加成
        await this._updateMedalLvAddReq();
    }

    protected async _updateMedalLvAddReq() {
        let proto = await this._gm.request<HeroModulBO>(GameProxy.apiherogetMedalAdd);
        if (proto) { heroLogic.updateMedalLvAddition(proto); }
    }

    protected async _updateMedalTreeAddReq() {
        let proto = await this._gm.request<HeroModulBO[]>(GameProxy.apiherogetStrategicAdd);
        if (proto) { heroLogic.updateMedalTreeAddition(proto); }
    }

    // 战略树节点升级
    public async medalTreeNodeLvupReq(id: number) {
        let proto = await this._gm.request<HeroModulBO[]>(GameProxy.apiRolelvUpStrategic, id);
        heroLogic.updateMedalTreeAddition(proto);
        let data = this.getMedalTechData(id);
        if (!data.isUnlock()) {
            data.level = 1;
        } else {
            data.level += 1;
        }
        this._updateMedalTreeBuff();
    }

    // 战略树重置
    public async resetMedalTree(type: number) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiRoleresetStrategic, type);
        gm.getReward(proto);

        this._updateMedalTreeAddReq();
        this._resetMedalTree(type);
        this._updateMedalTreeBuff();
    }

    // 净化任务信息
    public async medalTaskReq(id: number = 0) {
        let proto = await this._gm.request<MainTaskInfoVO[]>(GameProxy.apitaskgetMedalTaskInfo, id);
        this._updateMedalTask(proto);
    }

    // 领取净化任务奖励
    public async recvMedalTaskReq(id: number) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apitaskgetMedalTaskReward, id);
        gm.getReward(proto);

        if (!this._medalReward) { this._medalReward = {}; }
        this._medalReward[id] = true;
    }

    protected _resetMedalTree(type: number) {
        for (let i = 0; i < medaltechconfig.length; i++) {
            let cof = medaltechconfig[i];
            if (cof.type == type) {
                let data = this._techData[cof.ID];
                data.level = 1;
                data.setLock();
            }
        }
    }

    protected _updateMedalTask(proto: MainTaskInfoVO[]) {
        if (!proto) { return; }
        for (let i = 0; i < proto.length; i++) {
            let data = proto[i];
            this._medalReward[data.taskId] = data.recv;
        }
    }

    protected _initMedalTechData(proto: { [key: number]: number }) {
        this._techData = {};
        this._techMap = {};
        this._quickTechMap = {};
        this._medalTechCount = {};

        for (let i = 0; i < medaltechconfig.length; i++) {
            let cof = medaltechconfig[i];

            let tmp = new MedalTechData(cof.ID);
            if (proto && proto[cof.ID] > 0) { tmp.level = proto[cof.ID]; }
            this._techData[cof.ID] = tmp;

            if (!cof.techID || cof.techID.length <= 0) {
                let temp = new MedalResNode;
                temp.techId = cof.ID;
                if (!this._techMap[cof.type]) { this._techMap[cof.type] = []; }
                this._techMap[cof.type].push(temp);
                this._quickTechMap[cof.ID] = temp;
            }

            if (!this._medalTechCount[cof.type]) { this._medalTechCount[cof.type] = 0; }
            this._medalTechCount[cof.type] += 1;
        }

        for (let i = 0; i < medaltechconfig.length; i++) {
            let cfg = medaltechconfig[i];
            if (cfg.techID && cfg.techID.length > 0) {
                let id = cfg.techID[0];
                if (this._quickTechMap[id]) {
                    let child = new MedalResNode;
                    child.techId = cfg.ID;
                    this._quickTechMap[cfg.ID] = child;
                    this._quickTechMap[id].child.push(child);
                }
            }
        }
    }

    public _updateMedalTreeBuff() {
        this._medalTreeBuff = [];
        for (let i = 0; i < medaltechconfig.length; i++) {
            let cof = medaltechconfig[i];
            let data = this.getMedalTechData(cof.ID);
            if (data && data.isUnlock() && this.isTreeUnlock(cof.type)) {
                this._addMedalTreeBuff(data.getProp1Buff(), cof);
                this._addMedalTreeBuff(data.getProp2Buff(), cof);
            }
        }

        if (this._medalTreeBuff.length > 1) {
            this._medalTreeBuff.sort((a, b) => {
                return cm.getMedalTechConfig(a[a.length - 1]).sortnum - cm.getMedalTechConfig(b[b.length - 1]).sortnum;
            })
        }
    }

    public _addMedalTreeBuff(buff: number[], cof: medaltechconfigRow) {
        if (!buff || buff.length <= 0) { return; }
        if (buff[0] == 0 || buff[1] == 0) { return; }

        buff.push(cof.ID);
        if (!this._medalTreeBuff) { this._medalTreeBuff = []; }
        if (this._medalTreeBuff.length == 0) {
            this._medalTreeBuff.push(buff);
        } else {
            let bPush: boolean = true;
            for (let j = 0; j < this._medalTreeBuff.length; j++) {
                let treeBuff = this._medalTreeBuff[j];
                if (treeBuff[0] == buff[0]) {
                    let techId = treeBuff[3];
                    if (cm.getMedalTechConfig(techId).desc === cm.getMedalTechConfig(buff[3]).desc) {
                        this._medalTreeBuff[j][1] += buff[1];
                        bPush = false;
                        break;
                    }
                }
            }
            if (bPush) {
                this._medalTreeBuff.push(buff);
            }
        }
    }
}

let medalLogic = new MedalLogic();
export default medalLogic;