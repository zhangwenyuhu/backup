
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import marqueeConfig from "../configs/marqueeConfig";

export enum MARQUEE_TYPE {
    default = 0,
}

export class MarqueeData {
    protected _id: number;
    protected _roleId: string;
    protected _templateValue: any;

    constructor(data: any) {
        this._id = data.templateId;
        this._roleId = data.fromRoleId;
        this._templateValue = data.paras;
    }

    getContent(): string {
        let content: string = '';
        if (this._id && this._id > 0) {
            // 模板替换
            let config = marqueeConfig.find(a => a.Id == this._id);
            if (config) {
                content = config.content;
                if (this._templateValue) {
                    let keys = Object.keys(this._templateValue);
                    for (let key of keys) {
                        let value = this._templateValue[key];
                        content = content.replace(`%${key}%`, value);
                    }
                }
            }
        }
        console.log('跑马灯内容: ' + content);
        return content;
    }

    getCfg() {
        let cfg = marqueeConfig.find((a) => { return a.Id == this._id; });
        return cfg;
    }
}

/* 跑马灯管理 */
export class MarqueeLogic extends BaseLogic {

    public mqSec: number = 6;
    public mqMoveSec: number = 3;
    protected _maxLen: number = 100;
    protected _data: MarqueeData[] = [];

    init(gm: IGameManager) {
        super.init(null, gm);
    }

    // 保存推送过来的跑马灯信息
    onMarqueeMessage(msg: any) {
        if (msg) {
            let data = new MarqueeData(msg);
            this.addMessage(data);
        }
    }
    // 从数组头弹出一个跑马灯信息
    getMessage(): MarqueeData {
        if (this._data.length <= 0) { return null; }
        let data = this._data.shift();
        return data;
    }
    addMessage(data: MarqueeData) {
        if (data && this._data.length < this._maxLen) {
            this._data.push(data);
        }
    }
}

let mqLogic = new MarqueeLogic();
export default mqLogic;