import BaseLogic from "./BaseLogic";
import IGameManager from "../manager/IGameManager";
import EManager, { EName } from "../manager/EventManager";
import gm from "../manager/GameManager";
import GameProxy, { RedPointItem } from "../proxy/GameProxy";

export enum PromptType {
    NONE = 0,
    MAIL = 1,
    ARENA = 2,
    UNION = 3,
    UNION_APPLY = 4,
    UNION_HUNT_NORMAL = 5,
    UNION_HUNT_ADVANCE = 6,
    ARENA_NORMAL_READY = 7,

    RACE_WUZHANG = 8,
    RACE_JIXIE = 9,
    RACE_BIANZHONG = 10,
    RACE_CHAONENG = 11,
    RACE_MISSION = 12,
    RACE_TOWER = 13,

    ARENA_ADV_READY = 14,
    SEVEN_TASK_NEW = 15,
    RMISSION_FREE = 16,
    CLONE_FREE = 17,
    TREABOX_READY = 18,

    ACTIVITY_NEW = 100,
    ACTIVITY_SIGN = 101,
    ACTIVITY_NEWSERVER = 102,
    ACTIVITY_PURITY = 103,
    ACTIVITY_CHESS = 104,
    ACTIVITY_ONLINE = 105,

    CHAT = 200,
}

export let PromptStr = {
    1: "mail",
    2: "arenaRecord",
    3: "guild",
    4: "guild_new_apply",
    5: "guild_hunter_normal_ready",
    6: "guild_hunter_advance_ready",
    7: "arena_normal_ready",
    8: "rank_all_reward_1",
    9: "rank_all_reward_2",
    10: "rank_all_reward_3",
    11: "rank_all_reward_4",
    12: "rank_all_reward_5",
    13: "rank_all_reward_6",
    14: "arena_adv_ready",
    15: "task_sevenday",
    16: "rmission_free",
    17: "clone_free",
    18: "treabox_ready",

    100: "activity_new",
    101: "activity_sign",
    102: "activity_newserver",
    103: "activity_purity",
    104: "chess_main",
    105: "activity_online",

    200: "chat",
};

export class PromptData {
    pointType: string = "";
    status: boolean = false;
    local?: boolean = false;    //本地红点
}

class PromptLogic extends BaseLogic {

    protected _promptData: PromptData[] = [];

    init(gm: IGameManager) {
        super.init(null, gm);
    }

    doReceivePrompt(proto: string, data?: RedPointItem[]) {
        if (proto) {
            let json = JSON.parse(proto);
            if (json.msg) {
                for (let msg of json.msg) {
                    let data = this._promptData.find(a => a.pointType == msg["pointType"]);
                    if (!data) {
                        let promptData = new PromptData();
                        promptData.pointType = msg["pointType"];
                        promptData.status = msg["status"];
                        this._promptData.push(promptData);

                        if (promptData.pointType == PromptStr[PromptType.SEVEN_TASK_NEW]) {
                            gm.sevenTaskNewRed = promptData.status;
                            EManager.emit(EName.onUpdateActivityDatas, 1101);
                        }
                    } else {
                        data.status = msg["status"];
                        if (msg["pointType"] == PromptStr[PromptType.SEVEN_TASK_NEW]) {
                            gm.sevenTaskNewRed = msg["status"];
                            EManager.emit(EName.onUpdateActivityDatas, 1101);
                        }
                    }
                }
                EManager.emit(EName.PromptRefresh);
            }
        }
        if (data) {
            for (let dt of data) {
                let promptData = new PromptData();
                promptData.pointType = dt.pointType;
                promptData.status = dt.status;
                this._promptData.push(promptData);

                if (promptData.pointType == PromptStr[PromptType.SEVEN_TASK_NEW]) {
                    gm.sevenTaskNewRed = promptData.status;
                    EManager.emit(EName.onUpdateActivityDatas, 1101);
                }
            }
            EManager.emit(EName.PromptRefresh);
        }
    }

    getPrompt(promptType: PromptType): boolean {
        let data = this._promptData.find(a => a.pointType == PromptStr[promptType]);
        if (data) {
            return data.status;
        }
        return false;
    }

    getPrompts(promptTypes: PromptType[]): boolean {
        for (let prompt of promptTypes) {
            if (this.getPrompt(prompt)) {
                return true;
            }
        }
        return false;
    }

    setPrompt(promptType: PromptType, status: boolean) {
        let data = this._promptData.find(a => a.pointType == PromptStr[promptType]);
        if (data) {
            data.status = status;
        } else {
            let promptData = new PromptData();
            promptData.pointType = PromptStr[promptType];
            promptData.status = status;
            this._promptData.push(promptData);
        }
        EManager.emit(EName.PromptRefresh);
    }

    addLocalPrompt(promptType: PromptType, status: boolean) {
        if (!this._promptData.find(a => a.pointType == PromptStr[promptType])) {
            let promptData = new PromptData();
            promptData.pointType = PromptStr[promptType];
            promptData.status = status;
            promptData.local = true;
            this._promptData.push(promptData);
            EManager.emit(EName.PromptRefresh);
        }
    }

    setLocalPromptStatus(promptType: PromptType, status: boolean) {
        let promptData = this._promptData.find(a => a.pointType == PromptStr[promptType]);
        if (promptData) {
            promptData.status = status;
            EManager.emit(EName.PromptRefresh);
        } else {
            this.addLocalPrompt(promptType, status);
        }
        if (promptType == PromptType.SEVEN_TASK_NEW) {
            EManager.emit(EName.onRedDirty, 4000);
            gm.sevenTaskNewRed = status;
        }
    }

    async setPromptRead(promptTypes: PromptType[]) {
        let needSync: boolean = false;
        let closeName: string[] = [];
        for (let prompt of promptTypes) {
            let data = this._promptData.find(a => a.pointType == PromptStr[prompt]);
            if (data) {
                data.status = false;
                if (data.pointType == PromptStr[PromptType.SEVEN_TASK_NEW]) {
                    gm.sevenTaskNewRed = false;
                }
                if (!data.local) {
                    closeName.push(data.pointType);
                    needSync = true;
                }
            } else {
                closeName.push(PromptStr[prompt]);
                needSync = true;
            }
        }
        if (needSync) {
            EManager.emit(EName.PromptRefresh);
        }
        if (closeName.length > 0) {
            await gm.request<Object>(GameProxy.apiRolecloseRP, closeName);
        }
    }
}

let promptLogic = new PromptLogic();
export default promptLogic;