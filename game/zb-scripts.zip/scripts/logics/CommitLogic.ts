import playerLogic from "./PlayerLogic";
import { ZhuanPanEvent } from "../utils/DefineUtils";
import heroLogic from "./HeroLogic";
import { ResourceVO } from "../proxy/GameProxy";
import gm from "../manager/GameManager";
import Card, { CardType } from "../data/card/Card";
import Hero from "../data/card/Hero";
import towerLogic from "./TowerLogic";
import missionLogic from "./MissionLogic";
import cm from "../manager/ConfigManager";

export let DiamondCost = {
    chouKa: '抽卡',
    worldBoss: '世界BOSS挑战',
    promotionBuy: '购买促销商品',
    dungeonRefreshHero: '地牢刷新助力英雄',
    resetHero: '重置英雄',
    rollbackHero: '回退英雄',
    flowerSlot: '共享花坛格子购买',
    heroBlock: '英雄格子购买',
    changeName: '玩家改名',
    quickHangup: '快速挂机',
    resTimesBuy: '资源副本次数购买',
    shopRefresh: '商店刷新',
    arenaTicket: '竞技场挑战券购买',
    seniorArenaTicket: '高阶竞技场挑战券购买',
    createUnion: '创建公会',
    changeGuildName: '公会改名',
    xuanshangRefresh: '悬赏任务刷新',
    treaRaindeTicket: '夺宝奇兵门票购买',
    shopBuy: '商店购买',
    reSign: '补签',
    goodBuy: '物品购买',
    niudan: ' 扭蛋',
    recycle: '资源回收',
    zpRefresh: '转盘刷新',

}

export let DustCost = {
    levelUp: '英雄升级',
}

export let DiamondSource = {
    mainTask: '主线任务',
    taskActive: '任务活跃奖励',
    guideTask: '引导任务奖励',
    vip: 'vip等级奖励',
    firstPay: '首充礼包奖励',
    monthCard: '月卡领取',
    activeGift: '活跃礼包',
    wisdomTreeGift: '智慧树礼包',
    limitCycleFree: '限时特惠免费领取',
    limitCycleVideo: '限时特惠视频领取',
    onlineReward: '在线奖励',
    sevenLight: '新手7日光环',
    newFund: '新手基金',
    sevenSign: '七日签到',
    sevenTask: '七日任务',
    sevenTaskNew: '新手七日任务新版',
    pioneer: '先锋奖励',
    pioneer2: '先锋奖励储蓄罐版',
    trearaider: '夺宝奇兵boss伤害',
    trearaiderBuy: '奇兵商店兑换',
    honorRank: '荣耀榜奖励',
    niudan: '扭蛋获得',
    chouka: '抽卡获得',
    mail: '邮件获得',
    wisdomTreeGuard: '智慧树守卫奖励',
    wisdomTreeCicle: '智慧树层数奖励',
    wonderSpaceBox: '奇妙时空关卡宝箱',
    xuanshang: '悬赏任务',
    levelup: '升级',
    unionRedPack: '公会红包',
    memberRedPack: '成员红包',
    zhuanpan: '转盘',

    actSevenDayCum: '七日累充奖励',
    actWorldBoss: '世界boss累计伤害',
    actXiaofeiDaren: '消费达人',
    actDefault: '活动',
    actSign: '签到有礼活动',
    actChessCicle: '棋盘寻宝圈数奖励',
    actChess: '棋盘寻宝',
    actExploreFloor: '探秘寻宝层数奖励',
    actExplore: '探秘寻宝一格',

    giftGrowup: '成长礼包奖励',
    dungeonEvent: '地牢事件',
    dungeonFight: '地牢通关',
}

export let HeroSource = {
    chouKa: '抽卡',
    niuDan: '扭蛋',
    mergePiece: '碎片合成',
    vip: 'vip',
}
export let HeroSubSource = {
    allFact: '全阵营券',
    fact: '阵营券',
    factCard: '种族英雄卡',
    friend: '友情点',
    video: '视频',
    niudanTicket: '扭蛋券',
    diamond: '钻石',
}

export let ArenaPvpType = {
    normal: '普通',
    high: '高阶'
}

export let PayPanel = {
    NewPlayer: '新手礼包',
    Surprise: '惊喜礼包列表',
}


let EventTrack = {
    // 玩家数据
    UserSet: 'user_set',

    // 转盘
    ZpNormal: 'turntable_normal',
    ZpAdvance: 'turntable_advanced',
    ZpShopBuy: 'turntable_shop_buy',
    ZpShopRefresh: 'turntable_shop_refresh',

    // 钻石消耗和获取
    CostDiamond: 'diamond_consume',
    RecvDiamond: 'diamond_get',

    // 粉尘消耗和获取
    CostDust: 'powder_consume',
    RecvDust: 'powder_get',

    RecvHero: 'hero_get',           // 获得英雄
    WisdomTree: 'wisdom_tree',      // 智慧树
    Arena: 'arena',                 // 竞技场
    ShopBuy: 'shop_buy',            // 商店购买
    Tower: 'sky_build',             // 摩天楼
    Mission: 'stage',               // 主线关卡
    MainTask: 'main_mission_claim', // 主线任务领取奖励
    WeekTask: 'week_mission_claim',// 周活跃奖励领取
    DailyTask: 'day_mission_claim',// 日活跃奖励领取
    Dungeon: 'dungeon',              // 地牢
    SpaceTime: 'spaceTime',          // 奇妙时空
    UpgradeHeroRank: 'hero_upgrade_rank',   // 英雄升阶
    UpgradeHeroLevel: 'hero_upgrade_level', // 英雄升级

    UnionBoss: 'union_boss',         // 公会狩猎
    MatFight: 'resource_mission',    // 资源副本
    XuanShang: 'xs_arrange',         // 悬赏任务
    NpTask: 'new_mission',           // 新兵任务
    Artifact: 'magic_weapon',        // 神器
    PayPanelShow: 'pay_show',         // 付费页面展示 带充值表ID
    PayShopPanelShow: 'pay_shop_show',// 付费页面展示 不带充值表ID
    PayPanelClick: 'pay_click',      // 付费点击
}
/* 数据统计 */
export class CommitLogic {

    init() {

    }
    // 奖励领取
    public commitReward(reward: ResourceVO, source: string) {
        if (!reward) { return; }
        // diamond
        let diamond = gm.getDiamondFromReward(reward);
        this.recvDiamond(diamond, source);

        // dust
        let dust = gm.getDustFromReward(reward);
        this.recvDust(dust, source);

        if (source === DiamondSource.vip) {
            this.rewardHero(reward, source, '');
        }
    }

    // 抽卡获得英雄
    public lotteryHeros(heros: Hero[], source: string, subSource: string) {
        if (!heros || heros.length <= 0) { return; }
        let ids: number[] = [];
        let ranks: number[] = [];
        for (let i = 0; i < heros.length; i++) {
            ids.push(heros[i].getIndex());
            ranks.push(heros[i].getRank());
        }
        if (ids.length > 0 && ranks.length > 0) {
            this.recvHeros(ids, ranks, source, subSource);
        }
    }

    // 奖励英雄整卡
    public rewardHero(proto: ResourceVO, source: string, subSource: string) {
        if (!proto) { return; }
        let total = playerLogic.getCards(proto);
        let ids: number[] = []
        let rank: number[] = [];
        for (let i = 0; i < total.length; i++) {
            let card = total[i];
            if (card.getType() == CardType.Hero) {
                let data = card as Hero;
                ids.push(data.getIndex());
                rank.push(data.getRank());
            }
        }
        if (ids.length > 0 && rank.length > 0) {
            this.recvHeros(ids, rank, source, subSource);
        }
    }

    // 升级打点
    public levelUp(level?: number) {
        level = level ? level : this.getLevel();
        this.trackUserData({ current_level: level });
    }
    // vip升级打点
    public vipLevelUp(level?: number) {
        level = level ? level : this.getVipLevel();
        this.trackUserData({ vip_level: level });
    }
    // 主线关卡过关
    public missionPass(stageId: number) {
        this.trackUserData({ main_task: stageId });
    }
    // 摩天楼过关
    public towerPass(level: number) {
        this.trackUserData({ tower_level: level });
    }
    // 拥有英雄
    public haveHeros() {
        let ids: string[] = [];
        let ranks: string[] = [];
        let heros = heroLogic.getHeroes({ sort: true });
        for (let i = 0; i < heros.length; i++) {
            if (i < 20) {
                ids.push(`${heros[i].getIndex()}`);
                ranks.push(`${heros[i].getRank()}`);
            }
        }
        gssdk.logCommitTool.commitUserData("user_set", {
            hero_id: ids as any
        })
        gssdk.logCommitTool.commitUserData('user_set', {
            hero_rank: ranks as any
        })
    }
    // 普通转盘
    public zpNormalTrack(action: string, num: number) {
        let count: number = action == ZhuanPanEvent.normalCoinBuy ? num : 1;
        let hero_num: number = 0;
        if (action == ZhuanPanEvent.once || action == ZhuanPanEvent.ten) { hero_num = num; }
        this.track(EventTrack.ZpNormal, {
            turn_action: action,
            turn_count: count,
            purple_hero: hero_num,
        });
    }
    // 精英转盘
    public zpAdvanceTrack(action: string, hero: number, artifactNum: number) {
        this.track(EventTrack.ZpAdvance, {
            turn_action: action,
            turn_count: 1,
            purple_hero: hero,
            artifact: artifactNum,
        })
    }
    // 转盘商店购买
    public zpShopBuy(id: number, count: number) {
        this.track(EventTrack.ShopBuy, {
            buy_item: id,
            but_count: count,
        })
    }
    // 转盘商店刷新
    public zpShopRefresh() {
        this.track(EventTrack.ZpShopRefresh, {
            level: this.getLevel(),
            vip_level: this.getVipLevel()
        })
    }

    // 钻石消耗
    public costDiamond(num: number, reason: string) {
        this.track(EventTrack.CostDiamond, {
            consume_amount: num,
            reason: reason,
        });
    }
    // 钻石获取
    protected recvDiamond(num: number, reason: string) {
        if (num <= 0) { return; }
        this.track(EventTrack.RecvDiamond, {
            get_amount: num,
            reason: reason,
        })
    }

    // 英雄获取
    public recvHeros(ids: number[], ranks: number[], source: string, sourceSub: string) {
        if (ids.length <= 0 || ranks.length <= 0) { return; }
        let num: number = ids.length;

        let list = ids.map((v, i, a) => { return '' + v; })
        let rank = ranks.map((v, i, a) => { return '' + v; })
        this.track(EventTrack.RecvHero, {
            hero_source: source,
            hero_source_detail: sourceSub,
            hero_target: '',
            hero_count: num,
            hero_list: list as any,
            hero_rank: rank as any,
        })
    }

    // 智慧树战斗
    public wisdomTreeBattle(treeId: number, win: boolean) {
        let result: number = win == true ? 1 : 0;
        this.track(EventTrack.WisdomTree, {
            tree_id: treeId,
            is_win: result,
        })
    }

    // 竞技场挑战
    public arenaBattle(type: string, win: boolean) {
        let result: number = win == true ? 1 : 0;
        this.track(EventTrack.Arena, {
            arena_type: type,
            is_win: result,
        })
    }

    // 商店购买
    public shopBuy(type: string, id: number, count: number) {
        this.track(EventTrack.ShopBuy, {
            shop_type: type,
            buy_item: id,
            buy_count: count,
        })
    }

    // 种族塔挑战
    public async raceTowerBattle(type: number, level: number, win: boolean, quick: boolean = false) {
        let result: number = win == true ? 1 : 0;
        let myPower: number = 0;
        let npcPower: number = 0;
        if (quick) {
            myPower = towerLogic.getTop5HeroPower(type);
        } else {
            myPower = await towerLogic.getFightTroopPower(type);
        }
        let info = towerLogic.getTowerInfo(level, type);
        npcPower = info ? info.getMonsterPower() : 0;
        this.track(EventTrack.Tower, {
            build_type: type,
            build_level: level,
            is_win: result,
            my_power: myPower,
            enemy_power: npcPower,
        })
    }

    // 主线关卡挑战
    public async missionBattle(stage: number, win: boolean) {
        let result: number = win == true ? 1 : 0;
        let nowMission = missionLogic.getCurrentMission();
        let missionInfo = win ? missionLogic.getPreMission(nowMission) : nowMission;

        let myPower: number = await missionLogic.getPveTroopPower();
        let npcPower: number = missionInfo.getMonstersPower();
        this.track(EventTrack.Mission, {
            stage_id: stage,
            is_win: result,
            my_power: myPower,
            enemy_power: npcPower,
        })
    }
    // 主线任务领取奖励
    public recvMainTaskReward(taskId: number) {
        this.track(EventTrack.MainTask, {
            mission_id: taskId
        })
    }

    // 周任务奖励领取
    public recvWeekTask(taskId: number, vitality: number) {
        this.track(EventTrack.WeekTask, {
            mission_id: taskId,
            vitality: vitality
        })
    }
    // 日任务奖励领取
    public recvDailyTask(taskId: number, vitality: number) {
        this.track(EventTrack.DailyTask, {
            mission_id: taskId,
            vitality: vitality,
        })
    }

    // 地牢挑战
    public dungeonBattle(level: number, win: boolean, first: boolean = false) {
        let result: number = win == true ? 1 : 0;
        this.track(EventTrack.Dungeon, {
            dungeon_level: level,
            is_win: result,
            is_first: first
        })
    }

    // 奇妙时空挑战
    public spaceTimeBattle(id: number, eventId: number, prog: number) {
        this.track(EventTrack.SpaceTime, {
            space_id: id,
            space_event_id: eventId,
            space_progress: prog
        })
    }

    // 英雄升阶
    public upgradeRank(id: number, rank: number) {
        if (rank < 4) {
            console.log('升阶未到紫及紫以上,不提交打点');
            return;
        }
        this.track(EventTrack.UpgradeHeroRank, {
            hero_id: id,
            to_rank: rank
        })
    }
    // 英雄升级
    public upgradeLevel(id: number, level: number) {
        this.track(EventTrack.UpgradeHeroLevel, {
            hero_id: id,
            to_level: level
        })
    }

    // 消耗粉尘
    public costDust(num: number, reason: string) {
        if (num <= 0) { return; }
        this.track(EventTrack.CostDust, {
            consume_amount: num,
            reason: reason,
        })
    }

    // 获得粉尘
    public recvDust(num: number, source: string) {
        if (num <= 0) { return; }
        this.track(EventTrack.RecvDust, {
            get_amount: num,
            reason: source,
        })
    }

    // 公会狩猎获得箱子
    public guildFightBox(boxNum: number) {
        if (boxNum <= 0) { return; }
        this.track(EventTrack.UnionBoss, {
            box_count: boxNum,
        })
    }

    // 资源副本挑战
    public matFight(type: number, win: boolean, quick: boolean) {
        let matType: string[] = ['', '金币', '经验', '强化铸币', '神器强化石', '灵魂石']
        let matStr: string = matType[type] ? matType[type] : `${type}`;
        this.track(EventTrack.MatFight, {
            mission_type: matStr,
            is_win: win ? 1 : 0,
            is_quick: quick ? 1 : 0,
        })
    }

    // 悬赏任务
    public xuanshangGo(id: number) {
        this.track(EventTrack.XuanShang, {
            id: id,
        })
    }

    // 新兵任务领取奖励
    public recvNpTaskReward(id: number) {
        this.track(EventTrack.NpTask, {
            id: id,
        })
    }

    // 神器 1:解锁 2: +10强化 3:+150强化 4:进阶
    public artifactTrack(action: number) {
        this.track(EventTrack.Artifact, {
            action: action,
        })
    }

    // 付费页面展示
    protected payShopPanelShow(source: string) {
        this.track(EventTrack.PayShopPanelShow, {
            item_name: source,
        })
    }

    // 付费页面展示
    public payPanelShow(source: string, storeId: number, isPop: boolean = false) {
        let cfg = cm.getStoreConfig(storeId);
        if (!cfg || storeId == 0) { this.payShopPanelShow(source); return; }
        source = cfg ? cfg.title : source;

        let str: string = isPop ? '智能推荐' : '主动浏览';
        this.track(EventTrack.PayPanelShow, {
            item_name: source,
            item_id: storeId,
            source: str,
        })
    }

    // 付费点击
    public payPanelClick(source: string, storeId: number) {
        let cfg = cm.getStoreConfig(storeId);
        source = cfg ? cfg.title : source;
        this.track(EventTrack.PayPanelClick, {
            item_name: source,
            item_id: storeId,
        })
    }

    protected trackUserData(param: any) {
        console.log('玩家信息: ' + this.obj2string(param));
        gssdk.logCommitTool.commitUserData('user_set', param);
    }
    protected track(eventName: string, param: any, addLevel: boolean = true) {
        if (addLevel) {
            param['level'] = this.getLevel();
            param['vip_level'] = this.getVipLevel();
        }
        console.log('数据追踪: ' + eventName + ': ' + this.obj2string(param));
        gssdk.logCommitTool.commitTrack(eventName, param);
    }
    private obj2string(data: any): string {
        let result: string = '';
        if (data instanceof Object) {
            Object.keys(data).forEach((v, i, a) => {
                result += `${v}:${data[v]} `
            })
        }
        return result;
    }

    protected getVipLevel(): number {
        return playerLogic.getPlayer().getVipLevel();
    }
    protected getLevel(): number {
        return playerLogic.getPlayer().getLevel();
    }

}

let commitLogic = new CommitLogic();
export default commitLogic;