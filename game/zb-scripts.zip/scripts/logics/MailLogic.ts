import BaseLogic from "./BaseLogic";
import GameProxy, { MailVO, ResourceVO } from "../proxy/GameProxy";
import IGameManager from "../manager/IGameManager";
import Mail from "../data/card/Mail";
import gm from "../manager/GameManager";
import EManager from "../manager/EventManager";
import redPointLogic, { RedPointType } from "./RedPointLogic";
import promptLogic, { PromptType } from "./PromptLogic";
import commitLogic, { DiamondSource } from "./CommitLogic";
import {stringConfigMap} from "../configs/stringConfig";

class MailLogic extends BaseLogic {
    protected _mails: Mail[] = [];

    init(mailProto: MailVO[], gm: IGameManager) {
        super.init(mailProto, gm);

        this._mails = [];
        for (let proto of mailProto) {
            let mail = new Mail(proto);
            this._mails.push(mail);
        }
    }

    getMails() {
        this._mails.sort((a, b) => {
            if (a.getReadSort() == b.getReadSort()) {
                return b.getTime() - a.getTime();
            }
            return a.getReadSort() - b.getReadSort();
        });
        return this._mails;
    }

    hasUnReceivedMail() {
        for (let mail of this._mails) {
            if (!mail.getRewardGot()) {
                return true;
            }
        }
        return false;
    }

    isAllReaded(): boolean {
        for (let mail of this._mails) {
            if (!mail.getRead()) {
                return false;
            }
        }
        return true;
    }

    setRedPoint() {
        if (this.isAllReaded()) {
            promptLogic.setPromptRead([PromptType.MAIL]);
        }
    }

    async doDelete() {
        await this._gm.request<boolean>(GameProxy.apimaildelete);
    }

    async doDeleteAll() {
        let proto = await this._gm.request<boolean>(GameProxy.apimaildeleteAll);
        if (proto) {
            this._doDeleteAllRead();
        }
        gm.toast(stringConfigMap.key_auto_555.Value);
    }

    async doReceive(id: string) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apimailreceive, id);
        this._doReceive(id);
        gm.getReward(proto, true);
        commitLogic.commitReward(proto, DiamondSource.mail);
    }

    async doReceiveAll() {
        if (!this.hasUnReceivedMail()) {
            gm.toast(stringConfigMap.key_auto_556.Value);
            return;
        }
        let proto = await this._gm.request<ResourceVO>(GameProxy.apimailreceiveAll);
        this._doReceiveAll();
        gm.getReward(proto, true);
        commitLogic.commitReward(proto, DiamondSource.mail);
    }

    async doSetRead(id: string) {
        let proto = await this._gm.request<boolean>(GameProxy.apimailsetRead, id);
        if (proto) {
            this._doRead(id);
            EManager.emit(Mail.Event.onRead);
        }
    }

    async doSend() {
        await this._gm.request<MailVO>(GameProxy.apimailsend);
    }

    protected _doDeleteAllRead() {
        let needRemove = [];
        for (let i = 0; i < this._mails.length; i++) {
            let mail = this._mails[i];
            if (mail.getRead()) {
                needRemove.push(mail);
            }
        }
        if (needRemove.length > 0) {
            this._mails.remove(needRemove);
        }
        this.setRedPoint();
    }

    protected _doReceive(id: string) {
        let mail = this._mails.find(a => a.getId() == id);
        mail.setRead();
        mail.setRewartGot();
        EManager.emit(Mail.Event.onRead);
        this.setRedPoint();
    }

    protected _doReceiveAll() {
        for (let mail of this._mails) {
            if (mail.hasReward()) {
                mail.setRead();
                mail.setRewartGot();
            }
        }
        EManager.emit(Mail.Event.onRead);
        this.setRedPoint();
    }

    protected _doRead(id: string) {
        let mail = this._mails.find(a => a.getId() == id);
        mail.setRead();
        this.setRedPoint();
    }

}

let mailLogic = new MailLogic();
export default mailLogic;