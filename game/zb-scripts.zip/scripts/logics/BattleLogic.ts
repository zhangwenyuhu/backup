import { propertyConfigMap, propertyConfigRow } from './../configs/propertyConfig';
import { BattleType, Storage } from './../utils/DefineUtils';
import groupbuffConfig, { groupbuffConfigRow } from './../configs/groupbuffConfig';
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import Hero from '../data/card/Hero';
import storageUtils from '../utils/StorageUtils';
import cm from "../manager/ConfigManager";
import Summon from "../data/card/Summon";
import huntconfig from "../configs/huntconfig";
import { defaultConfigMap } from "../configs/defaultConfig";
import unionLogic from "./UnionLogic";
import wisdomTreeLogic from "./WisdomTreeLogic";
import heroConfig from "../configs/heroConfig";
import WisdomSkill from "../data/wisdomtree/data/WisdomSkill";
import activityLogic, { ActivityType } from "./ActivityLogic";
import TreasureActConfig from "../data/activity/actconfig/TreasureActConfig";
import arenaLogic from "./ArenaLogic";
import wonderSpaceLogic from "./WonderSpaceLogic";
import dungeonLogic from './DungeonLogic';
import arenaSeniorLogic from "./ArenaSeniorLogic";

/**
 * 阵营羁绊
 */
export class FactionRelation {
    protected _isSatisfy = false;
    protected _gains: { config: propertyConfigRow, value: number, newKey: string }[] = [];
    protected _count: number = 0;
    protected _config: groupbuffConfigRow = null;
    protected _useSuperRelation: boolean = false;

    protected _factionCounts: { faction: number, count }[] = [];

    constructor(config: groupbuffConfigRow, factions: { [key: number]: number }) {
        this._config = config;
        if (config.Id <= 4) {
            let factionsArray: { faction: number, amount: number }[] = [];

            for (let key in factions) {
                if (Number(key) != Hero.Faction.Destroy && Number(key) != Hero.Faction.Super) {
                    factionsArray.push({ faction: Number(key), amount: factions[key] });
                }
            }
            factionsArray.sort((a: { faction: number, amount: number }, b: { faction: number, amount: number }) => { return b.amount - a.amount });

            this._isSatisfy = true;
            this._useSuperRelation = false;
            for (let i = 0; i < config.groupby.length; i++) {
                this._count += config.groupby[i];
                if (i < factionsArray.length) {
                    let amount = factionsArray[i].amount;
                    let faction = factionsArray[i].faction;
                    if (amount >= config.groupby[i]) {
                        this._factionCounts.push({ faction: faction, count: amount });
                        continue;
                    }
                    if (!this._useSuperRelation && faction != Hero.Faction.Super) {
                        amount += factions[Hero.Faction.Super];
                        this._useSuperRelation = true;
                    }
                    if (amount >= config.groupby[i]) {
                        this._factionCounts.push({ faction: faction, count: amount });
                        continue;
                    }

                    this._isSatisfy = false;
                }
                else {
                    this._isSatisfy = false;
                }
            }
        }
        else if (config.Id == 10) {
            let count = 0;
            for (let key in factions) {
                if (factions[key] > 1) {
                    break;
                }
                else {
                    count += factions[key];
                    if (factions[key] > 0) {
                        this._factionCounts.push({ faction: Number(key), count: factions[key] });
                    }
                }
            }
            this._isSatisfy = count == 5;
        }
        else {
            if (factions[Hero.Faction.Destroy]) {
                let count = factions[Hero.Faction.Destroy];
                this._isSatisfy = count >= config.devilnum;
                if (this._isSatisfy) {
                    this._factionCounts.push({ faction: Hero.Faction.Destroy, count: count });
                }
            }
            this._count = config.devilnum;
        }

        let keyvalues = [
            { key: 'atkadd', config: propertyConfigMap.攻击, newKey: 'attack' },
            { key: 'hpadd', config: propertyConfigMap.生命, newKey: 'hp' },
            { key: 'defadd', config: propertyConfigMap.防御, newKey: 'defense' },
            { key: 'energyrecoveradd', config: propertyConfigMap.受击回能, newKey: 'powerChargeSpeedWithHurt' },
            { key: 'critadd', config: propertyConfigMap.暴击率, newKey: 'critRate' },
            { key: 'critharmadd', config: propertyConfigMap.暴击伤害, newKey: 'critHurt' },
            { key: 'skillspeedadd', config: propertyConfigMap.施法迅捷, newKey: 'skillSpeed' },
        ]
        for (let keyvalue of keyvalues) {
            if (typeof config[keyvalue.key] == 'number' && config[keyvalue.key] > 0) {
                this._gains.push({ config: keyvalue.config, value: config[keyvalue.key], newKey: keyvalue.newKey });
            }
        }
    }

    /**
     * 修改激活状态
     * @param value 值
     */
    setIsSatisfy(value: boolean) {
        this._isSatisfy = value;
    }

    /**
     * 是否激活
     */
    isSatisfy(): boolean {
        return this._isSatisfy;
    }

    /**
     * 是否使用了超能匹配
     */
    isUseSuperRelation(): boolean {
        return this._useSuperRelation;
    }

    /**
     * 毁灭英雄数量
     */
    getCount(): number {
        return this._count;
    }

    /**
     * 加成效果
     */
    getGains(): { config: propertyConfigRow, value: number, newKey: string }[] {
        return this._gains;
    }

    /**
     * 描述
     */
    getDesc(): string {
        return this._config.des;
    }

    /**
     * 表中的ID
     */
    getId(): number {
        return this._config.Id;
    }

    /**
     * 相同种族的数量
     */
    getFactionCounts(): { faction: number, count: number }[] {
        return this._factionCounts;
    }

    /**
     * 将加成值加到英雄配置中
     * @param heroCfg 英雄配置
     */
    updateHeroConfig(heroCfg: rpgfight.HeroConfig) {
        if (this.isSatisfy()) {
            let gains = this.getGains();
            for (let gain of gains) {
                if (gain.config == propertyConfigMap.攻击
                    || gain.config == propertyConfigMap.生命
                    || gain.config == propertyConfigMap.防御) {
                    heroCfg[gain.newKey] *= (1 + gain.value);
                }
                else {
                    heroCfg[gain.newKey] += gain.value;
                }
            }
        }
    }

    /**
     * 将英雄按种族分组
     * @param heroes 英雄列表
     */
    static getFactions(heroes: Hero[]): { [key: number]: number } {
        let factions: { [key: number]: number } = {};
        for (let i = 1; i < Hero.Faction.Num; i++) {
            factions[i] = 0;
        }

        for (let hero of heroes) {
            if (hero) {
                factions[hero.getFaction()]++;
            }
        }

        return factions;
    }
}

/**战斗相关 */
class BattleLogic extends BaseLogic {
    protected _battleData = null;
    protected _selfTroop: Hero[] = [];
    protected _enemyTroop: Hero[] = [];
    protected _heroList: rpgfight.HeroConfig[] = [];
    protected _heroSummonList: rpgfight.HeroConfig[] = [];
    protected _selfFactionRelations: FactionRelation[] = [];
    protected _enemyFactionRelations: FactionRelation[] = [];
    protected _battleType: BattleType = BattleType.PVE;

    protected _isAutoSkill: boolean = false;
    protected _isSpeedX2: boolean = false;

    init(battleData: { selfTroop: Hero[], enemyTroop: Hero[] }, gm: IGameManager) {
        super.init(battleData, gm);
        this._selfTroop = battleData.selfTroop;
        this._enemyTroop = battleData.enemyTroop;

        let selfFactions = FactionRelation.getFactions(this._selfTroop);
        this._selfFactionRelations = [];

        let enemyFactions = FactionRelation.getFactions(this._enemyTroop);
        this._enemyFactionRelations = [];

        for (let k = 0; k < 2; k++) {
            let factions = k == 0 ? selfFactions : enemyFactions;
            let relations = k == 0 ? this._selfFactionRelations : this._enemyFactionRelations;
            for (let config of groupbuffConfig) {
                relations.push(new FactionRelation(config, factions));
            }
            let newRelations = relations.where((f: FactionRelation) => { return f.getId() <= 4 });
            newRelations.sort((a: FactionRelation, b: FactionRelation) => { return b.getId() - a.getId() });
            for (let i = 0; i < newRelations.length; i++) {
                if (newRelations[i].isSatisfy()) {
                    for (let j = i + 1; j < newRelations.length; j++) {
                        newRelations[j].setIsSatisfy(false);
                    }
                    break;
                }
            }
        }

        this._heroList = [];
        this._heroSummonList = [];
        let _summonIdList = [];

        for (let i = 0; i < this._selfTroop.length; i++) {
            let hero = this._selfTroop[i];
            if (!hero) continue;
            let cfg = hero.getBattleCfg();
            cfg.battleStation = i + 1;
            cfg.battleTeam = rpgfight.BattleTeam.our;
            this._heroList.push(cfg);

            for (let relation of this._selfFactionRelations) {
                relation.updateHeroConfig(cfg);
            }

            let summon = cm.getHeroConfig(hero.getIndex()).summon;
            if (summon && summon.length > 0) {
                for (let id of summon) {
                    if (_summonIdList.indexOf(summon) == -1) {
                        let monster = new Summon(id, hero.getLevel());
                        let cfg = monster.getBattleCfg();
                        cfg.battleTeam = rpgfight.BattleTeam.neutral;
                        this._heroSummonList.push(cfg);
                        _summonIdList.pushList(summon);
                    }
                }
            }
        }

        for (let i = 0; i < this._enemyTroop.length; i++) {
            let hero = this._enemyTroop[i];
            if (!hero) continue;
            let cfg = hero.getBattleCfg();
            cfg.battleStation = i + 1;
            cfg.battleTeam = rpgfight.BattleTeam.enemy;
            this._heroList.push(cfg);

            for (let relation of this._enemyFactionRelations) {
                relation.updateHeroConfig(cfg);
            }

            let summon = cm.getHeroConfig(hero.getIndex()).summon;
            if (summon && summon.length > 0) {
                for (let id of summon) {
                    if (_summonIdList.indexOf(summon) == -1) {
                        let monster = new Summon(id, hero.getLevel());
                        let cfg = monster.getBattleCfg();
                        cfg.battleTeam = rpgfight.BattleTeam.neutral;
                        this._heroSummonList.push(cfg);
                        _summonIdList.pushList(summon);
                    }
                }
            }
        }

        this._isAutoSkill = storageUtils.getBoolean(Storage.AutoSkill);
        this._isSpeedX2 = storageUtils.getBoolean(Storage.SpeedX2);
    }

    initPVP() {
        this._heroList = arenaLogic.getArenaHeroConfig(arenaLogic.getBattleData().heroList);
        this._heroSummonList = arenaLogic.getArenaHeroConfig(arenaLogic.getBattleData().summonList);
        this.isAutoSkill = true;
    }

    initHunt(monsterId: number) {
        unionLogic.resetUnionHunt();
        for (let hero of this._heroList) {
            if (hero.battleTeam == rpgfight.BattleTeam.enemy) {
                hero.hp = this.getHuntMonsterHP(monsterId);
            }
        }
    }

    initMaze(wonderSpace?: boolean) {
        let skills: WisdomSkill[] = [];
        if (wonderSpace) {
            skills = wonderSpaceLogic.wonderBag.getSkills();
        } else {
            skills = wisdomTreeLogic.wisdomBag.getSkills();
        }
        let removeHeroList: rpgfight.HeroConfig[] = [];
        let buffAddedOnce: boolean = true;
        for (let hero of this._heroList) {
            if (hero.battleTeam == rpgfight.BattleTeam.our) {
                if (buffAddedOnce) {
                    let skillList: rpgfight.SkillConfig[] = [];
                    for (let i = 0; i < skills.length; i++) {
                        let skill = skills[i];
                        //排除恢复果实和泉水果实
                        if (skill.getIndex() != 999004 && skill.getIndex() != 999020) {
                            let cfg = new rpgfight.SkillConfig(rpgfight.Config.getTriggerData(skill.getFile()));
                            cfg.skillId = skill.getIndex().toString();
                            cfg.name = skill.getName();
                            cfg.skillLevel = skill.getLevel();
                            cfg.startCd = skill.getStartCD();
                            cfg.intervalCd = skill.getIntervalCD();
                            cfg.distance = skill.getAttackDistance();
                            cfg.isWithCloseUp = skill.isBig();
                            cfg.skillType = skill.getSkillType() as any;
                            cfg.skillNo = i + 1;
                            cfg.priority = skill.getPrority();
                            cfg.skillQuality = skill.getQuality();
                            let _config = heroConfig.find(a => a.Id == parseInt(hero.heroConfigId));
                            cfg.requiredPower = skill.isBig() ? _config.powerMax : 0;
                            cfg.ignoreNoAttack = skill.getIgnoreNoAttack();
                            skillList.push(cfg);
                        }
                    }
                    hero.skillList.pushList(skillList);
                    let wisdomHero = null;
                    if (wonderSpace) {
                        wisdomHero = wonderSpaceLogic.wonderHero.wisdomTreeHeroData.find(a => a.hero == hero.heroId);
                    } else {
                        wisdomHero = wisdomTreeLogic.wisdomHero.wisdomTreeHeroData.find(a => a.hero == hero.heroId);
                    }
                    if (wisdomHero) {
                        if (wisdomHero.hp <= 0) {
                            removeHeroList.push(hero);
                        } else {
                            hero.hp = wisdomHero.hp;
                            hero.hpMax = wisdomHero.hpMax;
                            hero.power = wisdomHero.power;
                            buffAddedOnce = false;
                        }
                    }
                }
            } else if (hero.battleTeam == rpgfight.BattleTeam.enemy) {
                if (!wonderSpace) {
                    let wisdomTreeData = wisdomTreeLogic.wisdomTreeData;
                    for (let treeData of wisdomTreeData) {
                        for (let wisdomData of treeData) {
                            if (wisdomData.wisdomData.grardData) {
                                for (let grardData of wisdomData.wisdomData.grardData) {
                                    if (grardData.heroVO.heroId == hero.heroId) {
                                        if (grardData.hp <= 0) {
                                            removeHeroList.push(hero);
                                        } else {
                                            hero.hp = grardData.hp;
                                            hero.hpMax = grardData.hpMax;
                                            hero.power = grardData.power;
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    let wonderSpaceData = wonderSpaceLogic.wonderSpaceData;
                    for (let wonderData of wonderSpaceData) {
                        if (wonderData && wonderData.wonderData.guardData) {
                            for (let guardData of wonderData.wonderData.guardData) {
                                if (guardData.heroVO.heroId == hero.heroId) {
                                    if (guardData.hp <= 0) {
                                        removeHeroList.push(hero);
                                    } else {
                                        hero.hp = guardData.hp;
                                        hero.hpMax = guardData.hpMax;
                                        hero.power = guardData.power;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        for (let hero of removeHeroList) {
            this._heroList.remove(hero);
        }
    }

    initDungeon() {
        let fruitIds = dungeonLogic.fruitIds;
        let skills: rpgfight.SkillConfig[] = [];
        for (let i = 0; i < fruitIds.length; i++) {
            let fruitId = fruitIds[i];
            let config = cm.getFruitConfig(fruitId);
            let skillConfig = cm.getSkillConfig(config.skillID);
            let cfg = new rpgfight.SkillConfig(rpgfight.Config.getTriggerData(skillConfig.File));
            cfg.skillId = skillConfig.Id.toString();
            cfg.name = skillConfig.Name;
            cfg.skillLevel = 0;
            cfg.startCd = skillConfig.StartCd[cfg.skillLevel];
            cfg.intervalCd = skillConfig.IntervalCd[cfg.skillLevel];
            cfg.distance = skillConfig.Distance[cfg.skillLevel];
            cfg.isWithCloseUp = false;
            cfg.skillType = 'passive';
            cfg.skillNo = i + 99999;
            cfg.priority = skillConfig.Skillpriority;
            cfg.skillQuality = config.rarity;
            cfg.requiredPower = 0
            cfg.ignoreNoAttack = skillConfig.IgnoreNoattack;
            skills.push(cfg);
        }
        for (let heroConfig of this._heroList) {
            if (heroConfig.battleTeam == rpgfight.BattleTeam.our) {
                heroConfig.skillList.pushList(skills);
                break;
            }
        }
    }

    initMazeTroops(selectHeroes: { [key: number]: Hero }) {
        for (let key in selectHeroes) {
            let hero = selectHeroes[key];
            let wisdomHero = wisdomTreeLogic.wisdomHero.wisdomTreeHeroData.find(a => a.hero == hero.getId());
            if (wisdomHero) {
                if (wisdomHero.hp <= 0) {
                    delete selectHeroes[key];
                }
            }
        }
    }

    initWonderTroops(selectHeroes: { [key: number]: Hero }) {
        for (let key in selectHeroes) {
            let hero = selectHeroes[key];
            let wisdomHero = wonderSpaceLogic.wonderHero.wisdomTreeHeroData.find(a => a.hero == hero.getId());
            if (wisdomHero) {
                if (wisdomHero.hp <= 0) {
                    delete selectHeroes[key];
                }
            }
        }
    }

    initMazePikerTroops(heroes: Hero[]) {
        let removeHeroList = [];
        for (let hero of heroes) {
            let wisdomHero = wisdomTreeLogic.wisdomHero.wisdomTreeHeroData.find(a => a.hero == hero.getId());
            if (wisdomHero) {
                if (wisdomHero.hp <= 0) {
                    removeHeroList.push(hero);
                }
            }
        }
        for (let hero of removeHeroList) {
            heroes.remove(hero);
        }
    }

    initTreasure() {
        let activity = activityLogic.getActivityConfigs(ActivityType.Treasure);
        let actConfig = activity.actConfig as TreasureActConfig;
        for (let hero of this._heroList) {
            if (hero.battleTeam == rpgfight.BattleTeam.enemy) {
                hero.hp = actConfig.hp;
                hero.hpMax = actConfig.hp;
            }
        }
    }

    initSeniorPVP(groupId: number) {
        this._heroList = arenaSeniorLogic.getArenaHeroConfig(arenaSeniorLogic.getBattleData().datas[groupId - 1].heroList, false);
        this._heroSummonList = arenaSeniorLogic.getArenaHeroConfig(arenaSeniorLogic.getBattleData().datas[groupId - 1].summonList, true);
        this.isAutoSkill = true;
    }

    initSeniorPVPRecord(groupId: number, defense: boolean = false) {
        this._heroList = arenaSeniorLogic.getArenaHeroConfig(arenaSeniorLogic.getPlayBackMulBattleData(groupId).heroList, false, defense);
        this._heroSummonList = arenaSeniorLogic.getArenaHeroConfig(arenaSeniorLogic.getPlayBackMulBattleData(groupId).summonList, true);
        this.isAutoSkill = true;
    }

    /**
     * 获取智慧树死亡的英雄列表
     * @param heroes 英雄列表
     */
    getMazeDeadTroops(heroes: Hero[]): Hero[] {
        let heroList = [];
        for (let hero of heroes) {
            let wisdomHero = wisdomTreeLogic.wisdomHero.wisdomTreeHeroData.find(a => a.hero == hero.getId());
            if (wisdomHero) {
                if (wisdomHero.hp <= 0) {
                    heroList.push(hero);
                }
            }
        }
        return heroList;
    }

    /**
     * 获取秘境时空死亡的英雄列表
     * @param heroes 英雄列表
     */
    getWonderDeadTroops(heroes: Hero[]): Hero[] {
        let heroList = [];
        for (let hero of heroes) {
            let wisdomHero = wonderSpaceLogic.wonderHero.wisdomTreeHeroData.find(a => a.hero == hero.getId());
            if (wisdomHero) {
                if (wisdomHero.hp <= 0) {
                    heroList.push(hero);
                }
            }
        }
        return heroList;
    }

    /**
     * 获取公会狩猎的Boss血量
     * @param monsterId 怪物ID
     */
    getHuntMonsterHP(monsterId: number) {
        let monsterList = defaultConfigMap.huntboss.value.split(';');
        let config = huntconfig.where(a => a.type == (monsterList.indexOf(monsterId) + 1));
        let hp = 0;
        for (let hunt of config) {
            hp += hunt.hurtnum;
        }
        return hp;
    }

    set battleType(battleType: BattleType) {
        this._battleType = battleType;
    }

    get battleType(): BattleType {
        return this._battleType;
    }

    set battleData(value) {
        this._battleData = value;
    }

    get battleData() {
        return this._battleData;
    }

    get isAutoSkill(): boolean {
        return this._isAutoSkill;
    }

    set isAutoSkill(value: boolean) {
        if (this._isAutoSkill == value) {
            return;
        }
        this._isAutoSkill = value;
        storageUtils.setBoolean(Storage.AutoSkill.Key, value, true);
    }

    get isSpeedX2(): boolean {
        return this._isSpeedX2;
    }

    set isSpeedX2(value: boolean) {
        if (this._isSpeedX2 == value) {
            return;
        }
        this._isSpeedX2 = value;
        storageUtils.setBoolean(Storage.SpeedX2.Key, value, true);
    }

    createHeroConfigs(datas: any[]): rpgfight.HeroConfig[] {
        let list: rpgfight.HeroConfig[] = [];
        for (let data of datas) {
            let skillConfig = new rpgfight.SkillConfig(rpgfight.Config.getTriggerData(data.attackSkill.triggerTreeName));
            let skillConfigList: rpgfight.SkillConfig[] = [];
            let propertyNames = Object.getOwnPropertyNames(data.attackSkill);
            for (let objName of propertyNames) {
                if (objName != "triggerTree") {
                    skillConfig[objName] = data.attackSkill[objName];
                }
            }

            for (let skill of data.skillList) {
                let propertyNames = Object.getOwnPropertyNames(skill);
                let _skill = new rpgfight.SkillConfig(rpgfight.Config.getTriggerData(skill.triggerTreeName));
                for (let objName of propertyNames) {
                    if (objName != "triggerTree") {
                        _skill[objName] = skill[objName];
                    }
                }
                skillConfigList.push(_skill);
            }

            let config = new rpgfight.HeroConfig(skillConfig, skillConfigList);
            propertyNames = Object.getOwnPropertyNames(data);
            for (let objName of propertyNames) {
                if (objName != "attackSkill" && objName != "skillList") {
                    config[objName] = data[objName];
                }
            }
            list.push(config);
        }
        return list;
    }

    getHeroList(): rpgfight.HeroConfig[] {
        return this._heroList;
    }

    setHeroList(heroList: rpgfight.HeroConfig[]) {
        this._heroList = heroList;
    }

    /**设置狩猎弱点联盟伤/减伤系数*/
    setHeroHuntHurtFact(faction: number, factor: number) {
        if (!faction || !factor) {
            return;
        }
        for (let _hero of this._heroList) {
            if (_hero.faction == faction && (_hero.battleTeam == rpgfight.BattleTeam.our || _hero.battleTeam == rpgfight.BattleTeam.neutral)) {
                _hero.incHarm = _hero.extraDefenseMagicHurt = _hero.extraDefensePhysicalHurt = factor;
            }
        }
    }

    getSummonList(): rpgfight.HeroConfig[] {
        return this._heroSummonList;
    }

    getTroop(isSelf: boolean): Hero[] {
        return isSelf ? this._selfTroop : this._enemyTroop;
    }

    addHeroToTroop(hero: Hero, isSelf: boolean) {
        let troop = isSelf ? this._selfTroop : this._enemyTroop;
        troop.push(hero);
    }

    getFactionRelations(isSelf: boolean): FactionRelation[] {
        return isSelf ? this._selfFactionRelations : this._enemyFactionRelations;
    }

    getSatisfyFactionRelation(isSelf: boolean): FactionRelation {
        let relations = isSelf ? this._selfFactionRelations : this._enemyFactionRelations;
        relations = relations.filter(a => a.getId() <= 4 || a.getId() == 10);
        for (let relation of relations) {
            if (relation.isSatisfy()) {
                return relation;
            }
        }
        return null;
    }

    getFlowerAnimation(isSelf: boolean) {
        let animation = "";
        let relation = this.getSatisfyFactionRelation(isSelf);
        if (relation) {
            if (relation.getCount() >= 3) {
                if (relation.getCount() == 5) {
                    if (relation.getId() == 2) {
                        animation = "5ban2";
                    }
                    else {
                        animation = "5ban1";
                    }
                }
                else {
                    animation = `${relation.getCount()}ban`;
                }
            }
            else if (relation.getCount() == 0) {
                animation = "6ban";
            }
        }

        if (animation.length == 0) {
            animation = "0ban"
        }

        return animation;
    }
}

let battleLogic = new BattleLogic();
export default battleLogic;