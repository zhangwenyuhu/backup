
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from "../manager/GameManager";
import GameProxy, { ResourceVO, ActChessStepReq, ActivityCumRewardReq, RankListReq, RankListVO, ChessEventItem, ChessTenItemVO } from "../proxy/GameProxy";
import SeedUtils from "../utils/SeedUtils";
import boardconfig from "../configs/boardconfig";
import ChessActivityDatas from "../data/activity/roleactivitydatas/ChessActivityDatas";
import activityLogic, { ActivityType } from "./ActivityLogic";
import bagLogic from "./BagLogic";
import Good, { GoodId } from "../data/card/Good";
import ChessTask from "../data/assignment/ChessTask";
import boardtaskconfig from "../configs/boardtaskconfig";
import { EventGroup } from "../utils/DefineUtils";
import commitLogic, { DiamondSource } from "./CommitLogic";
import defaultConfig, { defaultConfigMap } from "../configs/defaultConfig";
import cm from "../manager/ConfigManager";
import boardeventconfig from "../configs/boardeventconfig";

const maxStep: number = 24;

export enum ChessEvent {
    CostWish = 101,       // 消耗骰子 参数0普通 1心愿
    Reward = 102,         // '奖励configId, 奖励索引'
    MeetZoombie = 103,      // 和僵尸相遇  0为玩家追上僵尸 1为僵尸追上玩家
    MoguStar = 104,         // 获取星星


    MoGuHome = 1001,    // 蘑菇屋
    WishHome = 2001,    // 心意小屋
    LuckyHome = 3001,   // 幸运小屋
    StandHome = 4001,   // 正邪小屋
}

export enum DiceType {
    Zombie = 1,
    Normal = 2,
    Wish = 3,
    Event = 4,  // 无消耗,事件触发
}

/* 棋盘寻宝数据 */
export class ChessLogic extends BaseLogic {

    public bInited: boolean = false;
    public chessRandom: SeedUtils = null;                       // 棋盘奖励随机对象
    public chessRewards: { [key: number]: number[] } = {};      // 棋盘奖励
    public chessRewardIndex: { [key: number]: number } = {};    // 棋盘奖励在表中对应的index
    public chessEvents: { [key: number]: number } = {}          // 棋盘位置对应的事件

    public diceTasks: ChessTask[] = [];                         // 骰子任务
    public chessTenStep: { [key: number]: { rand: number[], step: number[], event: ChessEventItem[][] } } = {};

    private randomEx: number = 100000;
    private defaultZombieStep: number = 12;
    init(gm: IGameManager) {
        super.init(null, gm);
    }

    resetAll() {

    }

    getChessModal() {
        return activityLogic.getActivityConfigs(ActivityType.CheckerBoard);
    }

    getChessData(): ChessActivityDatas {
        return this.getChessModal().roleActivityDatas as ChessActivityDatas;
    }

    getNowCircle(): number {
        let circle = this.getCircle(this.getChessData().playerStep);
        return circle;
    }

    getNowStarCount(): number {
        return this.getChessData().getStarCount();
    }

    hasCircleReward(): boolean {
        let has: boolean = false;
        let circleRewards = this.getChessData().getCircleRewards();
        if (circleRewards) {
            for (let i = 0; i < circleRewards.length; i++) {
                if (this.getNowCircle() >= circleRewards[i].needProgress && !circleRewards[i].recv) {
                    has = true;
                    break;
                }
            }
        }
        return has;
    }

    initChessRewards(seed: number) {
        if (!this.chessRandom || !this.chessRewards) {
            this.chessRandom = new SeedUtils(seed);
            this.randomChessRewards();
        }
    }
    // 随机棋盘奖励
    randomChessRewards() {
        if (!this.chessRandom || !this.chessRewards) { return; }
        console.warn("开始随机更新棋盘奖励!");
        for (let i = 0; i < boardconfig.length; i++) {
            let key = i + 1;
            let randomNum = this.chessRandom.random()
            let num: number = Math.floor(randomNum * this.randomEx)
            if (boardconfig[i].reward && boardconfig[i].reward.length) {
                let index: number = num % boardconfig[i].reward.length;
                this.chessRewards[key] = boardconfig[i].reward[index];
                this.chessRewardIndex[key] = index;

                let event = boardconfig[i].event;
                if (event) {
                    if (event.length == 1) {
                        this.chessEvents[key] = event[0];
                    } else {
                        let num: number = event.length;
                        let rIndex: number = Math.floor(Math.random() * num);
                        this.chessEvents[key] = event[rIndex];
                    }
                }
            } else {
                this.chessRewards[key] = [10001, 0];
                this.chessRewardIndex[key] = -1;
            }
        }
    }
    // 获取棋盘格子奖励信息
    getChessReward(key: number) {
        return this.chessRewards[key];
    }
    // 获取棋盘格子奖励索引
    getChessRewardIndex(key: number): number {
        return this.chessRewardIndex[key];
    }
    // 根据步数获取在棋盘的位置
    getChessCfgIndex(step: number): number {
        let index = step % maxStep;
        return index == 0 ? maxStep : index;
    }

    // 骰子任务数据初始化
    initDiceTasks() {
        let cfgs = boardtaskconfig;
        this.diceTasks = [];
        for (let i = 0; i < cfgs.length; i++) {
            let tmp = new ChessTask(cfgs[i].ID);
            if (tmp.isRunning()) {
                this.diceTasks.push(tmp);
            }
        }
        this.diceTasks = this.diceTasks.sort((a, b) => { return b.getSortIndex() - a.getSortIndex(); })
    }
    // 骰子任务存在可领取的任务
    hasDiceTaskReward(): boolean {
        let has: boolean = false;
        for (let i = 0; i < this.diceTasks.length; i++) {
            let data = this.diceTasks[i];
            if (data.hasReward()) {
                has = true;
                break;
            }
        }
        return has;
    }

    isMeet(myStep: number, zombieStep: number): boolean {
        let max: number = maxStep;
        return myStep % max == zombieStep % max;
    }
    getCircle(step: number): number {
        let circle: number = Math.floor(step / maxStep);
        let board: number = step % maxStep;
        if (board == 0) { circle -= 1; }
        circle = circle > 0 ? circle : 0;
        return circle;
    }
    getCircleStr(step: number): string {
        let circle: number = Math.floor(step / maxStep);
        let board: number = step % maxStep;
        if (board == 0) {
            circle -= 1;
            board = maxStep;
        }
        let str: string = circle > 0 ? `${circle}圈${board}格` : `${board}格`;
        return str;
    }

    // 获取随机步数
    getRandomStep(zombie: boolean = false): number {
        let maxUStep = 6;
        let maxZStep = 4;
        let max = zombie ? maxZStep : maxUStep;
        let randomStep = Math.ceil(Math.random() * max);
        //console.warn("随机步数: "+randomStep+"  僵尸:"+zombie);
        return randomStep;
    }

    // 视频获得一个骰子
    async videoDiceReq() {
        let proto = await gm.request<ResourceVO>(GameProxy.apiActivityrecvCVideoDice);
        gm.getReward(proto);
    }

    // 骰子任务领取
    async getDiceTaskRewardReq(uid: string) {
        let param = new ActivityCumRewardReq;
        param.actId = this.getChessModal().id;
        param.recTag = uid;
        let proto = await gm.request<ResourceVO>(GameProxy.apiActivitygetCTaskReward, param);
        this.getChessData().setDiceTaskGotReward(uid);
        gm.getReward(proto);
    }

    // 排行榜获取
    async chessRankReq(num: number) {
        let param = new RankListReq;
        param.customKey = this.getChessModal().id;
        param.start = 0;
        param.end = num - 1;;
        let proto = await gm.request<RankListVO>(GameProxy.apirankmyGameRank, param);
        return proto;
    }

    // 十连推进
    async tenStepCommit() {
        this.chessTenStep = {};
        this.chessTenStep[DiceType.Zombie] = { rand: [], step: [], event: [] };
        this.chessTenStep[DiceType.Normal] = { rand: [], step: [], event: [] };

        let cost: number = bagLogic.getGood(GoodId.RandomDice).getAmount();
        let newStep: number = this.getChessData().playerStep;
        let newZombieStep: number = this.getChessData().playerStep;
        let count: number = 10;
        let randomStep: number = 0;
        let myEvent: ChessEventItem[] = [];
        let zombieEvent: ChessEventItem[] = [];

        cost = 10;
        for (let i = 0; i < count; i++) {
            if (cost <= 0) { break; }
            cost -= 1;
            // 玩家随机投掷
            randomStep = this.getRandomStep(false);
            this.chessTenStep[DiceType.Normal].rand.push(randomStep);
            if (this.needUpdateRewards(newStep, newStep + randomStep)) {
                this.randomChessRewards();
            }
            newStep += randomStep;
            let myTmp = this.stepEvent(DiceType.Normal, newStep, newStep - randomStep, newZombieStep);
            // 随机位置有正邪小屋
            let index = this.getChessCfgIndex(newStep);
            if (this.getEventId(index) == ChessEvent.StandHome) {
                let addStep: number = this.getEventRandomStep(this.getRandomStep(false));
                newStep += addStep;
                let standEvent = this.stepEvent(DiceType.Event, newStep, newStep - addStep, newZombieStep);
                myTmp.pushList(standEvent);
            }
            if (this.isMeet(newStep, newZombieStep)) {
                newZombieStep += this.defaultZombieStep;
            }
            myEvent.pushList(myTmp);
            this.chessTenStep[DiceType.Normal].event.push(myTmp);
            this.chessTenStep[DiceType.Normal].step.push(newStep);

            // 僵尸随机投掷
            randomStep = this.getRandomStep(true);
            this.chessTenStep[DiceType.Zombie].rand.push(randomStep);
            newZombieStep += randomStep;
            let zombieTmp = this.stepEvent(DiceType.Zombie, newZombieStep, newStep, newZombieStep - randomStep);
            if (zombieTmp && zombieTmp.length > 0) {
                let tmp = zombieTmp.find((a) => { return a.eventId == ChessEvent.MeetZoombie; })
                if (tmp) { cost -= 1; console.log('被僵尸追到,骰子减1'); }
            }
            if (cost >= 0) {
                zombieEvent.pushList(zombieTmp);
                this.chessTenStep[DiceType.Zombie].event.push(zombieTmp);
            }
            this.chessTenStep[DiceType.Zombie].step.push(newZombieStep);
        }
        // log
        console.log(`棋盘十连前位置 玩家:${this.getChessData().playerStep} 僵尸:${this.getChessData().zombieStep}`)
        console.log(`棋盘十连后位置 玩家:${newStep} 僵尸:${newZombieStep}`)
        let events: number[] = [];
        let params: string[] = [];
        for (let i = 0; i < this.chessTenStep[DiceType.Normal].rand.length; i++) {
            let my = this.chessTenStep[DiceType.Normal];
            if (my.event[i]) {
                events = my.event[i].map((v, i, a) => { return v.eventId; });
                params = my.event[i].map((v, i, a) => { return v.para; })
            }
            console.log(`${i + 1}-玩家随机: ${my.rand[i]} 事件: ${events.join(';')} 参数: ${params.join(';')}`);
        }
        for (let i = 0; i < this.chessTenStep[DiceType.Normal].rand.length; i++) {
            let zo = this.chessTenStep[DiceType.Zombie];
            if (zo.event[i]) {
                events = zo.event[i].map((v, i, a) => { return v.eventId; });
                params = zo.event[i].map((v, i, a) => { return v.para; })
            }
            console.log(`${i + 1}-僵尸随机: ${zo.rand[i]} 事件: ${events.join(';')} 参数: ${params.join(';')}`);
        }


        let param = new ActChessStepReq;
        param.actId = this.getChessModal().id;
        param.newPlayerStep = newStep;
        param.newZombieStep = newZombieStep;
        param.eventList = [];
        param.eventList.pushList(myEvent);
        param.eventList.pushList(zombieEvent);
        let proto = await gm.request<ChessTenItemVO>(GameProxy.apiActivitysetChessPlayerStep, param);
        this.updateActChessData(proto);
        //bagLogic.getGood(GoodId.RandomDice).changeAmount(-this.chessTenStep[DiceType.Normal].rand.length);
        bagLogic.getGood(GoodId.RandomDice).changeAmount(-count);

        gm.commitEvent(EventGroup.Chess, [], 10);
        return { reward: proto.resourceVO, rands: this.chessTenStep };
    }

    // 棋盘奖励充值判断 --> 跨越一圈则重置
    needUpdateRewards(oldStep: number, newStep: number): boolean {
        let needUpdate: boolean = false;
        let newCircle: number = this.getCircle(newStep);
        let nowCircle: number = this.getCircle(oldStep);

        let tmp: number = this.getChessCfgIndex(newStep);
        let oldTmp: number = this.getChessCfgIndex(oldStep)

        if (newCircle > nowCircle) {
            needUpdate = true;
        }
        if (needUpdate) {
            console.warn(`移动前步数:${oldStep} 圈数:${nowCircle} 格子:${oldTmp}`);
            console.warn(`移动后步数:${newStep} 圈数:${newCircle} 格子:${tmp}`);
        }

        return needUpdate;
    }

    // 正邪小屋事件触发的 前进或者后退
    async standEvent(addStep: number) {
        let nowStep: number = this.getChessData().playerStep;
        let newStep: number = nowStep + addStep;
        let actId: string = this.getChessModal().id;

        let param = new ActChessStepReq;
        param.actId = actId;
        param.newPlayerStep = newStep;
        param.newZombieStep = -1;
        param.eventList = this.stepEvent(DiceType.Event, newStep, nowStep, this.getChessData().zombieStep);

        if (this.needUpdateRewards(this.getChessData().playerStep, newStep)) {
            this.randomChessRewards();
        }
        let proto = await gm.request<ChessTenItemVO>(GameProxy.apiActivitysetChessPlayerStep, param);
        this.updateActChessData(proto);
        return proto.resourceVO;
    }

    // 推进棋盘上玩家/僵尸的位置
    async stepCommit(actId: string, type: number, newStep: number) {
        let now = this.getChessData().playerStep;
        let nowZobie = this.getChessData().zombieStep;

        let param = new ActChessStepReq;
        param.actId = actId;
        param.newPlayerStep = type > DiceType.Zombie ? newStep : -1;
        param.newZombieStep = type > DiceType.Zombie ? -1 : newStep;
        param.eventList = this.stepEvent(type, newStep, now, nowZobie);

        if (type > DiceType.Zombie) {
            if (this.needUpdateRewards(now, newStep)) {
                this.randomChessRewards();
            }
        }

        // log
        console.log(`棋盘推进 type:${type} 玩家:${now} 僵尸:${nowZobie} 目标:${newStep}`);
        let events = param.eventList.map((v, i, a) => { return v.eventId; });
        let params = param.eventList.map((v, i, a) => { return v.para; })
        console.log(`棋盘推进 事件:${events.join(';')} 参数:${params.join(';')}`)

        let proto = await gm.request<ChessTenItemVO>(GameProxy.apiActivitysetChessPlayerStep, param);
        this.updateActChessData(proto);
        // event log
        if (type > 1) {
            gm.commitEvent(EventGroup.Chess, [], 1);
            this.getChessData().playerStep = newStep;
        }

        return proto.resourceVO;
    }

    // 更新棋盘数据
    protected updateActChessData(data: ChessTenItemVO) {
        this.getChessData().playerStep = data.playerStep;
        this.getChessData().zombieStep = data.zombieStep;
        this.getChessData().setStarCount(data.starCount);
        this.getChessData().setEventData(data.mashLvMap);
    }

    // 获取玩家从当前到新位置的事件
    protected stepEvent(type: number, newStep: number, nowMyStep: number, nowZombieStep: number): ChessEventItem[] {
        let events: ChessEventItem[] = [];
        let cfgId: number = this.getChessCfgIndex(newStep);

        let playerStep: number = nowMyStep;
        let zombieStep: number = nowZombieStep;

        if (type > DiceType.Zombie) {
            let addStar: number = 0;
            if (type == DiceType.Normal || type == DiceType.Wish) {
                // 消耗骰子
                let param: number = type == DiceType.Wish ? 1 : 0;
                events.push({ eventId: ChessEvent.CostWish, para: `${param}` });

                // 经过蘑菇屋时增加星星数
                let nowCfgId: number = this.getChessCfgIndex(playerStep);
                if (nowCfgId < cfgId) {
                    for (let i = nowCfgId + 1; i < cfgId; i++) {
                        if (this.getEventId(i) == ChessEvent.MoGuHome) {
                            addStar += this.getMoguEventStar(this.getEventBuildLevel(i));
                        }
                    }
                } else {
                    for (let i = nowCfgId + 1; i < maxStep; i++) {
                        if (this.getEventId(i) == ChessEvent.MoGuHome) {
                            addStar += this.getMoguEventStar(this.getEventBuildLevel(i));
                        }
                    }
                    for (let i = 2; i < cfgId; i++) {
                        if (this.getEventId(i) == ChessEvent.MoGuHome) {
                            addStar += this.getMoguEventStar(this.getEventBuildLevel(i));
                        }
                    }
                }
            }

            if (this.hasEvent(cfgId)) {
                let eventId: number = this.getEventId(cfgId);
                if (eventId == ChessEvent.MoGuHome) {
                    // 获取星星
                    addStar += this.getMoguEventStar(this.getEventBuildLevel(cfgId));

                    // 蘑菇屋升级 
                    events.push({ eventId: ChessEvent.MoGuHome, para: `${cfgId}` });
                } else {
                    if (eventId != ChessEvent.StandHome) {
                        events.push({ eventId: eventId, para: `` });
                    }
                }
            } else {
                // 奖励
                let rewardIndex: number = this.getChessRewardIndex(cfgId);
                if (rewardIndex >= 0) {
                    events.push({ eventId: ChessEvent.Reward, para: `${cfgId},${rewardIndex}` });
                } else {
                    console.error('读取到的奖励索引数值错误,当前位置为起点');
                }
            }

            // 获取星星
            if (addStar > 0) {
                events.push({ eventId: ChessEvent.MoguStar, para: `${addStar}` });
            }

            // 追上僵尸
            if (this.isMeet(newStep, zombieStep)) {
                events.push({ eventId: ChessEvent.MeetZoombie, para: `0` });
            }
        } else {
            // 被僵尸追上
            if (this.isMeet(playerStep, newStep)) {
                if (bagLogic.getGood(GoodId.RandomDice).getAmount() > 1) {
                    events.push({ eventId: ChessEvent.MeetZoombie, para: `1` });
                }
            }
        }
        return events;
    }

    // 棋盘寻宝圈数奖励
    async circleRewardReq(actId: string, tag: string) {
        let param = new ActivityCumRewardReq;
        param.actId = actId;
        param.recTag = tag;

        let proto = await gm.request<ResourceVO>(GameProxy.apiActivityrecvChessBoardCircle, param);
        gm.getReward(proto);
        commitLogic.commitReward(proto, DiamondSource.actChessCicle);
    }

    // 获取蘑菇可获得的星星数量
    public getMoguEventStar(level: number): number {
        let star: string = defaultConfigMap.moguhomestar.value;
        let stars = star.split(';');
        if (!stars || stars.length == 0) { return 1; };

        let index = level > stars.length ? stars.length : level;
        return parseInt(stars[index - 1]);
    }

    // 获取蘑菇屋等级
    public getEventBuildLevel(cfgId: number) {
        if (this.getEventId(cfgId) == ChessEvent.MoGuHome) {
            return this.getChessData().getEventLevel(cfgId);
        } else {
            return 0;
        }
    }
    // 蘑菇屋最大等级
    public getMaxEventLevel(): number {
        let star: string = defaultConfigMap.moguhomestar.value;
        let stars = star.split(';');
        return stars.length;
    }

    public getEventBuildUrl(eventId: number, level: number = 0) {
        let name: string = level > 0 ? `chess_event_${eventId}_${level}` : `chess_event_${eventId}`;
        return `textures/ui/panel/chess/${name}`;
    }

    // 当前格子是否有事件
    public hasEvent(cfgId: number) {
        let cfg = cm.getChessConfig(cfgId);
        let has: boolean = cfg.event ? true : false;
        return has;
    }
    // 获取棋盘格子事件Id
    public getEventId(cfgId: number) {
        return this.chessEvents[cfgId];
    }
    // 获取事件信息
    public getEventDesc(eventId: number): string {
        let desc: string = ``;
        for (let cfg of boardeventconfig) {
            if (cfg.eventID == eventId) {
                desc = cfg.effectdes;
                break;
            }
        }
        return desc;
    }

    public getEventRandomStep(num: number): number {
        let step: number[] = [1, -1];
        let rand: number = num % 2;
        return step[rand];
    }

}

let chessLogic = new ChessLogic();
export default chessLogic;