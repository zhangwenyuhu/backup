
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from "../manager/GameManager";
import GameProxy, { MainTaskInfoVO, ResourceVO, TaskProgressSetReq } from "../proxy/GameProxy";
import GuideTask from "../data/assignment/GuideTask";
import guidetaskconfig from "../configs/guidetaskconfig";
import EManager, { EName } from "../manager/EventManager";
import commitLogic, { DiamondSource } from "./CommitLogic";

/* 引导任务数据 */
export class GuideTaskLogic extends BaseLogic {

    public guideTaskComplete: boolean = false;
    public _guideTask: { [key: number]: GuideTask } = {};
    public _guideTaskPro: { [key: number]: { req: boolean, pro: number } } = {};
    public bInited: boolean = false;
    init(gm: IGameManager) {
        super.init(null, gm);

    }

    resetAll() {

    }

    getGuideTask(id: number) {
        return this._guideTask[id];
    }

    async guideTaskStatuReq(id: number = 0) {
        let proto: MainTaskInfoVO[] = await gm.request<MainTaskInfoVO[]>(GameProxy.apitaskgetGTaskInfo, id);
        if (id <= 0) {
            this._guideTask = {};
            this.bInited = true;
        }
        proto.forEach((v, i, a) => {
            let tmp = new GuideTask(v);
            this._guideTask[v.taskId] = tmp;
        })

        this.guideTaskComplete = Object.keys(this._guideTask).every((v, i, a) => {
            let uid = parseInt(v);
            return this._guideTask[uid].isGotReward();
        })
    }

    async guideTaskRewardReq(id: number) {
        let proto: ResourceVO = await gm.request<ResourceVO>(GameProxy.apitaskgetGTaskReward, id);
        if (proto) {
            gm.getReward(proto);
            this._guideTask[id].setGotReward();

            this.guideTaskComplete = Object.keys(this._guideTask).every((v, i, a) => {
                let uid = parseInt(v);
                return this._guideTask[uid].isGotReward();
            })
            commitLogic.commitReward(proto, DiamondSource.guideTask);
        }
    }

    async guideTaskProgressCommit(taskType: number, num: number, noBlock?: boolean) {

        if (this.guideTaskComplete) { return; }

        let param = new TaskProgressSetReq;
        param.taskId = taskType;
        param.progress = num;
        let proto = await gm.request<number>(GameProxy.apitaskincGTaskProgress, param, GameProxy, noBlock);
        Object.keys(this._guideTask).forEach((v, i, a) => {
            let id = parseInt(v);
            if (this._guideTask[id].getCfg().tasktype == taskType) {
                this._guideTaskPro[id] = { req: true, pro: proto };
            }
        })
        /*
        if(taskType==5007){
            let nowTask=this.getNowGuideTask();
            if(nowTask && nowTask.getCfg().tasktype==5007){
                EManager.emit(EName.onFreshGuideTask);
            }
        }*/
    }

    getGuideTaskPro(id: number) {
        if (this._guideTask[id]) {
            if (this._guideTaskPro[id]) {
                return this._guideTaskPro[id].pro;
            }
        }
        return -1;
    }

    getNowGuideTask() {
        let cfgs = guidetaskconfig;
        for (let i = 0; i < cfgs.length; i++) {
            if (!this._guideTask[cfgs[i].ID].isGotReward()) {
                return this._guideTask[cfgs[i].ID];
            }
        }
        return null;
    }
}

let guideTaskLogic = new GuideTaskLogic();
export default guideTaskLogic;