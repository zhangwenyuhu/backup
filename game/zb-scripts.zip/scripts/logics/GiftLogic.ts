import { WarOrderBO } from './../proxy/GameProxy';
import BaseLogic from "./BaseLogic";
import IGameManager from '../manager/IGameManager';
import gm from '../manager/GameManager';
import cm from '../manager/ConfigManager';
import kaoshangConfig, { kaoshangConfigRow } from "../configs/kaoshangConfig";
import { giftConfigRow } from "../configs/giftConfig";
import GameProxy, {
    ResourceVO,
    KaoShangBO,
    CycleGiftBO,
    FreeGiftBO,
    TaskInfoVO,
    OnlineGiftRecvReq, TaskSevenNewVO, GrowUpBO, CloudObjectReq
} from "../proxy/GameProxy";
import rechargeLogic from "./RechargeLogic";
import MainScene from "../scenes/MainScene";
import videoAdLogic, { AD_TYPE } from "./VideoAdLogic";
import playerLogic from "./PlayerLogic";
import onlinegiftconfig from "../configs/onlinegiftconfig";
import onlineTimeWidget from "../view/component/OnlineTimeWidget";
import EManager, { EName } from "../manager/EventManager";
import newplayerchargeconfig from "../configs/newplayerchargeconfig";
import promptLogic, { PromptType } from "./PromptLogic";
import storageUtils from "../utils/StorageUtils";
import { Storage } from "../utils/DefineUtils";
import sevendayfundconfig from "../configs/sevendayfundconfig";
import { defaultConfigMap } from "../configs/defaultConfig";

export class DailyLightModal {
    protected _dailyLightDetail: TaskSevenNewVO = null;

    constructor(proto: TaskSevenNewVO) {
        this._dailyLightDetail = proto;
    }

    get isDailyLightValid() {
        return this._dailyLightDetail && this._dailyLightDetail.nowDay <= newplayerchargeconfig[newplayerchargeconfig.length - 1].days && gm.getCurrentTimestamp() <= this.finishTs || this.hasUnRecvBigItem;
    }

    get hasUnRecvItem() {
        if (!this._dailyLightDetail) {
            return false;
        }
        for (let detail of this._dailyLightDetail.detail) {
            if (detail.taskId > 0) {
                if (this.canReceive(detail.taskId) != -1) {
                    return true;
                }
            } else {
                if (this.canReceiveBig(detail.taskId)) {
                    return true;
                }
            }
        }
        return false;
    }

    get hasUnRecvBigItem() {
        if (!this._dailyLightDetail) {
            return false;
        }
        for (let detail of this._dailyLightDetail.detail) {
            if (detail.taskId < 0) {
                if (this.canReceiveBig(detail.taskId)) {
                    return true;
                }
            }
        }
        return false;
    }

    get finishTs() {
        if (this._dailyLightDetail && this._dailyLightDetail.startTs) {
            let finish = this._dailyLightDetail.startTs + 7 * 24 * 3600 * 1000;
            return finish;
        }
        return 0;
    }

    isBBXValid() {
        if (!UnlockWrapper.isUnlock(unlockConfigMap.新手光环)) {
            return false;
        }
        let time = new Date(this.finishTs);
        time.setUTCHours(0);
        time.setUTCMinutes(0);
        time.setUTCSeconds(0);
        time.setUTCMilliseconds(0);
        let ts = time.getTime() + 24 * 3600 * 1000;
        return gm.getCurrentTimestamp() >= ts;
    }

    get remainTime() {
        let time = Math.max(this.finishTs - gm.getCurrentTimestamp(), 0);
        return time;
    }

    /**连充天数 */
    get continuityChargeDays() {
        let max = 0;
        let cnt = 0;
        for (let i = 1; i <= 7; i++) {
            if (this._dailyLightDetail.amtProgress[i.toString()] > 0) {
                cnt++;
                max = Math.max(cnt, max);
            } else {
                cnt = 0;
            }
        }
        return max;
    }

    get nowDay() {
        return this._dailyLightDetail.nowDay;
    }

    nextDay() {
        this._dailyLightDetail.nowDay++;
    }

    get nowDayCharge() {
        return this._dailyLightDetail.amtProgress[this._dailyLightDetail.nowDay.toString()];
    }

    /**能否领取 */
    canReceive(id: number) {
        if (this._dailyLightDetail && this._dailyLightDetail.detail) {
            let detail = this._dailyLightDetail.detail.find(a => a.taskId == id);
            let chargeCfg = newplayerchargeconfig.find(a => a.ID == detail.taskId && a.days == this.nowDay);
            if (!chargeCfg) {
                return -1;
            }
            let chargeCfgs = newplayerchargeconfig.where(a => a.days == chargeCfg.days);
            let whichTotal: number = -1;
            if (this.nowDayCharge >= chargeCfg.chargenumber) {
                whichTotal = chargeCfgs.indexOf(chargeCfg);
            }
            if (whichTotal >= 0 && !this.isReceived(id)) {
                return whichTotal;
            }
        }
        return -1;
    }

    /**能否领取大奖 */
    canReceiveBig(id: number) {
        if (this._dailyLightDetail && this._dailyLightDetail.detail) {
            let detail = this._dailyLightDetail.detail.find(a => a.taskId == id);
            let chargeCfg = newplayertimespendconfig.find(a => a.ID == Math.abs(detail.taskId));
            if (!chargeCfg) {
                return false;
            }
            if (this.continuityChargeDays >= chargeCfg.days && !detail.recv) {
                return true;
            }
        }
        return false;
    }

    /**是否已领取 */
    isReceived(id: number) {
        if (this._dailyLightDetail && this._dailyLightDetail.detail) {
            let detail = this._dailyLightDetail.detail.find(a => a.taskId == id);
            if (detail) {
                return detail.recv;
            }
        }
        return false;
    }

    /**领取奖励 */
    doReceive(id: number) {
        if (this._dailyLightDetail && this._dailyLightDetail.detail) {
            let detail = this._dailyLightDetail.detail.find(a => a.taskId == id);
            if (detail) {
                detail.recv = true;
            }
        }
    }

    /**充值 */
    doCharge(amt: number) {
        if (this._dailyLightDetail && amt > 0) {
            this._dailyLightDetail.amtProgress[this._dailyLightDetail.nowDay.toString()] += amt;
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.DailyLight);
        }
    }

    /**日充 */
    dayCharge(id: number) {
        let chargeCfg = newplayerchargeconfig.find(a => a.ID == id);
        if (this._dailyLightDetail && this._dailyLightDetail.amtProgress) {
            return this._dailyLightDetail.amtProgress[chargeCfg.days.toString()];
        }
        return 0;
    }

}

/* 礼包: 智慧礼包&月卡礼包&活跃礼包 */
export class GiftLogic extends BaseLogic {

    public activeCfgs: kaoshangConfigRow[] = [];
    public wisdomCfgs: kaoshangConfigRow[] = [];
    public firstPayCfg: giftConfigRow = null;
    public activeGiftData: KaoShangBO = null;       //  成长礼包相关数据
    public wisdomGiftData: KaoShangBO = null;       //  智慧树礼包相关数据
    public tehuiGiftData: CycleGiftBO[] = [];       //  日周月特惠礼包相关数据
    public videoGiftData: FreeGiftBO[] = [];        //  视频礼包
    public videoGiftRed: boolean = true;
    public onlineDetail: TaskInfoVO[] = [];
    public dailyLightModal: DailyLightModal = null;
    public newPlayerFund: GrowUpBO = null;           //  新手基金相关数据
    public mainOrder: WarOrderBO = null;
    public towerOrder: WarOrderBO = null;
    protected _fundTs: number = 0;
    protected _fundCloudKey: string = "sevenFundKey";

    init(gm: IGameManager) {
        super.init(null, gm);

        this.initCfgs();
        this.funcTsReq();
    }

    resetAll() {

    }

    private initCfgs() {
        this.activeCfgs = kaoshangConfig.filter((v, i, a) => { return v.type == 1; })
        this.wisdomCfgs = kaoshangConfig.filter((v, i, a) => { return v.type == 2; })
        this.firstPayCfg = cm.getGiftConfig(6);
    }

    leftMenuOpen(): boolean {
        let bOpen = true;
        let sceneScript: MainScene = cc.find(`Canvas`).getComponent(MainScene);
        if (sceneScript) {
            bOpen = sceneScript._isLeftOpen;
        }
        return bOpen;
    }

    monthCardRed(): boolean {
        let bRed = this.isCanGotMonthCardToday(7) || this.isCanGotMonthCardToday(8);
        return bRed;
    }

    weekCardRed(): boolean {
        let bRed = this.isCanGotWeekCardToday();
        return bRed;
    }

    activeRed(): boolean {
        let bRed: boolean = false;
        let nowValue: number = this.getActiveValue();
        let vip: boolean = this.activeGiftData.pay;
        if (this.activeGiftData.endTs > 0) {
            for (let i = 0; i < this.activeCfgs.length; i++) {
                let cfg = this.activeCfgs[i];
                if (nowValue >= cfg.conditions) {
                    if (!this.isActiveGiftGot(cfg.Id)) {
                        bRed = true;
                        break;
                    }
                    if (vip && !this.isActiveGiftGot(cfg.Id, true)) {
                        bRed = true;
                        break;
                    }
                }
            }
        }
        return bRed;
    }

    wisdomRed(): boolean {
        let bRed: boolean = false;
        let nowValue: number = this.getWisdomValue();
        let vip: boolean = this.wisdomGiftData.pay;
        if (this.wisdomGiftData.endTs > 0) {
            for (let i = 0; i < this.wisdomCfgs.length; i++) {
                let cfg = this.wisdomCfgs[i];
                if (nowValue >= cfg.conditions) {
                    if (!this.isWisdomGiftGot(cfg.Id)) {
                        bRed = true;
                        break;
                    }
                    if (vip && !this.isWisdomGiftGot(cfg.Id, true)) {
                        bRed = true;
                        break;
                    }
                }
            }
        }
        return bRed;
    }

    // 领取月卡奖励
    async recvMonthCardReq(param: number) {
        let proto = await gm.request<ResourceVO>(GameProxy.apiStorerecvMonthCard, param);
        gm.getReward(proto, true);

        let source: string[] = ['普通月卡', '超级月卡', '周卡', '终生卡'];
        commitLogic.commitReward(proto, source[param]);
    }

    // 领取犒赏礼包奖励 活跃礼包和智慧树礼包
    async recvKaoshangGiftReq(id: number) {
        let proto = await gm.request<ResourceVO>(GameProxy.apiStorerecvKsReward, id);
        gm.getReward(proto, true);

        let cfg = cm.getKaoshangConfig(id);
        if (cfg.type == 1) {
            let index = this.activeGiftData.recvs.findIndex((v, i, a) => { return v.id == id; });
            if (index >= 0) {
                let bUnlock = this.activeGiftData.pay;
                this.activeGiftData.recvs[index].recvfree = true;
                this.activeGiftData.recvs[index].recvPay = bUnlock;
            }
            commitLogic.commitReward(proto, DiamondSource.activeGift);
        } else if (cfg.type == 2) {
            let index = this.wisdomGiftData.recvs.findIndex((v, i, a) => { return v.id == id; });
            if (index >= 0) {
                let bUnlock = this.wisdomGiftData.pay;
                this.wisdomGiftData.recvs[index].recvfree = true;
                this.wisdomGiftData.recvs[index].recvPay = bUnlock;
            }
            commitLogic.commitReward(proto, DiamondSource.wisdomTreeGift);
        }
    }

    // 获取月卡到期时间
    public getMonthCardEndTs(storeCfgId: number) {
        let id = storeCfgId == 7 ? 0 : 1;
        if (id == 0) {
            return rechargeLogic.normalMonthCardBuyInfo().endTs;
        } else {
            return rechargeLogic.superMonthCardBuyInfo().endTs;
        }
    }
    public getWeekCardEndTs() {
        return rechargeLogic.weekCardBuyInfo().endTs;
    }
    // 今日月卡奖励是否领取
    public isCanGotMonthCardToday(storeCfgId: number) {
        let id = storeCfgId == 7 ? 0 : 1;
        if (id == 0) {
            let info = rechargeLogic.normalMonthCardBuyInfo();
            return !info.recv && this.isBuyNormalMonthCard();
        } else {
            let info = rechargeLogic.superMonthCardBuyInfo();
            return !info.recv && this.isBuySuperMonthCard();
        }
    }
    public isCanGotWeekCardToday() {
        let info = rechargeLogic.weekCardBuyInfo();
        return !info.recv && this.isBuyWeekCard();
    }
    public isCanGotLifeCardToday() {
        let info = rechargeLogic.lifeCardBuyInfo();
        return !info.recv && this.isBuyLifeCard();
    }
    // 月卡是否购买
    public isBuyNormalMonthCard() {
        return this.getMonthCardEndTs(7) > gm.getCurrentTimestamp();
    }
    public isBuySuperMonthCard() {
        return this.getMonthCardEndTs(8) > gm.getCurrentTimestamp();
    }
    public isBuyWeekCard() {
        return this.getWeekCardEndTs() > gm.getCurrentTimestamp();
    }
    public isBuyLifeCard() {
        return rechargeLogic.getBuyCount(MonthCardStoreId.Life) > 0;
    }
    public leftTime(timestamp: number): string {
        let time: number = Math.floor(timestamp / (1000 * 3600 * 24));
        if (time > 0) { return `${time}` + `天` };
        time = Math.floor(timestamp / (1000 * 3600));
        if (time > 0) { return `${time}` + `小时` };
        time = Math.floor(timestamp / (1000 * 60));
        if (time > 0) { return `${time}` + `分钟` };
        return ``;
    }

    public getActiveValue() {
        return this.activeGiftData.nowScore;
    }
    public getMaxActiveValue() {
        let len = this.activeCfgs.length;
        return this.activeCfgs[len - 1].conditions;
    }

    public getWisdomValue() {
        return this.wisdomGiftData.nowScore;
    }
    public getMaxWisdomValue() {
        let len = this.wisdomCfgs.length;
        return this.wisdomCfgs[len - 1].conditions;
    }

    public getActiveVipReward(value?: number) {
        return this.getVipReward(1, value);
    }

    public getWisdomVipReward(value?: number) {
        return this.getVipReward(2, value);
    }

    private getVipReward(type: number, value: number = -1): number[][] {
        let cfg = type == 1 ? this.activeCfgs : this.wisdomCfgs;
        let len = cfg.length;
        let target: number = value >= 0 ? value : cfg[len - 1].conditions;

        let cfgs = cfg.filter((v, i, a) => { return v.conditions <= target; });
        let totalReward: { [key: number]: number } = {};
        for (let i = 0; i < cfgs.length; i++) {
            let vipReward: number[][] = cfgs[i].privilege;
            for (let j = 0; j < vipReward.length; j++) {
                let id: number = vipReward[j][0];
                let num: number = vipReward[j][1];

                totalReward[id] = totalReward[id] ? totalReward[id] + num : num;
            }
        }

        let result: number[][] = [];
        Object.keys(totalReward).forEach((v, i, a) => {
            result.push([parseInt(v), totalReward[v]]);
        })
        return result;
    }

    // 活跃礼包某一项是否领取
    isActiveGiftGot(id: number, vip: boolean = false) {
        let item = this.activeGiftData.recvs.find((a) => { return a.id == id });
        if (vip) {
            return item && item.recvPay;
        } else {
            return item && item.recvfree;
        }
    }

    // 智慧树礼包某一项是否领取
    isWisdomGiftGot(id: number, vip: boolean = false) {
        let item = this.wisdomGiftData.recvs.find((a) => { return a.id == id });
        if (vip) {
            return item && item.recvPay;
        } else {
            return item && item.recvfree;
        }
    }

    // 特惠礼包 begin
    // 特惠礼包免费领取
    async recvFreeCycleGift(id: number) {
        let proto = await gm.request<ResourceVO>(GameProxy.apiStorerecvFreeCycleReward, id);
        gm.getReward(proto);
        commitLogic.commitReward(proto, DiamondSource.limitCycleFree);
    }
    // 特惠礼包视频领取
    async recvVideoGift(id: number) {
        let proto = await gm.request<ResourceVO>(GameProxy.apiStorerecvFreeReward, id);
        gm.getReward(proto);
        commitLogic.commitReward(proto, DiamondSource.limitCycleVideo);
    }

    getVideoGiftType() {
        let createTs: number = playerLogic.getPlayer().getCreateTs();
        let tmpTs: number = 1585843200;
        let oldUser: boolean = createTs / 1000 < tmpTs;
        return oldUser ? AD_TYPE.VideoGift : AD_TYPE.VideoGiftNew;
    }

    isTehuiGiftRed(storeType: number): boolean {
        let red: boolean = false;
        let gifts = this.getTehuiGifts(storeType);
        if (gifts) {
            red = gifts.some((v, i, a) => { return !v.pay && this.noLimitTehuiGift(v.storeId); });
            if (storeType == 9) {
                let canVideo: boolean = videoAdLogic.canVideoAd(this.getVideoGiftType());
                red = (this.videoGiftRed && canVideo) ? true : red;
            }
        }
        return red;
    }

    noLimitTehuiGift(id: number): boolean {
        let gift = this.getTehuiGift(id);
        let cfg = cm.getStoreConfig(id);
        return gift.nowCount < cfg.buylimit || cfg.buylimit == 0;
    }
    getTehuiGifts(type: number) {
        let gifts = this.tehuiGiftData.filter((v, i, a) => { return v.type == type; });
        return gifts;
    }
    getTehuiGift(id: number) {
        let gift = this.tehuiGiftData.find((a) => { return a.storeId == id; })
        return gift;
    }
    getBuyLimitDesc(num: number): string {
        num = num < 0 ? 0 : num;
        return `限购${num}次`;
    }

    getDayVideoGift() {
        return this.videoGiftData[0];
    }
    // 根据礼包充值表ID获取对应的活动ID
    getActivityTypeByStoreId(id: number) {
        let aType = ActivityType.None;
        let storeCfg = cm.getStoreConfig(id);
        if (storeCfg) {
            aType = storeCfg.activitytype;
        }
        return aType;
    }
    // 获取限时礼包关闭的时间戳
    getTehuiLimitGiftTs(storeId: number) {
        let aType = this.getActivityTypeByStoreId(storeId);
        let activityData = activityLogic.getActivityConfigs(aType);
        if (!activityData) { return 0; }
        let closeTs = activityData.closeAt / 1000;
        if (aType == ActivityType.CheckerBoard) {
            closeTs = closeTs - 24 * 3600;
        }
        closeTs = closeTs < 0 ? 0 : closeTs;
        return closeTs;
    }
    // 获取限时礼包的剩余时间
    getTehuiLimitGiftLeftSec(storeId: number) {
        let aType = this.getActivityTypeByStoreId(storeId);
        if (aType <= 0) {
            return -1;
        }
        let activityData = activityLogic.getActivityConfigs(aType);
        if (!activityData) { return 0; }
        let closeTs = activityData.closeAt;
        let leftSec: number = (closeTs - gm.getCurrentTimestamp()) / 1000;
        leftSec = leftSec < 0 ? 0 : leftSec;
        return leftSec;
    }
    // 限时存在有效的活动礼包
    tehuiLimitGiftTimeValid(): boolean {
        let valid: boolean = true;
        let gifts = this.getTehuiGifts(12);
        if (gifts) {
            valid = gifts.some((v, i, a) => {
                return this.getTehuiLimitGiftLeftSec(v.storeId) > 0;
            })
        }
        return valid;
    }
    // 特惠礼包 end

    /**获取在线奖励详情 */
    async doGetOnlineDetail() {
        this.onlineDetail = await this._gm.request<TaskInfoVO[]>(GameProxy.apigiftgetOnlineDetail, null);
        promptLogic.setLocalPromptStatus(PromptType.ACTIVITY_ONLINE, this.getLastUnRecv() != -1);
    }

    /**获取在线奖励 */
    async doGetOnlineReward(confId: number, recvAll: boolean) {
        let onlineGiftRecvReq = new OnlineGiftRecvReq();
        onlineGiftRecvReq.confId = confId;
        onlineGiftRecvReq.recvAll = recvAll;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apigiftgetOnlineReward, onlineGiftRecvReq);
        if (recvAll) {
            for (let detail of this.onlineDetail) {
                if (detail.taskId <= confId) {
                    detail.recv = true;
                }
            }
        } else {
            this.onlineDetail.find(a => a.taskId == confId).recv = true;
        }
        gm.getReward(proto);
        if (!storageUtils.getBoolean(Storage.OnlineGuide)) {
            storageUtils.setBoolean(Storage.OnlineGuide.Key, true, true);
        }
        EManager.emit(EName.onUpdateOnline);
        promptLogic.setLocalPromptStatus(PromptType.ACTIVITY_ONLINE, this.getLastUnRecv() != -1);
        commitLogic.commitReward(proto, DiamondSource.onlineReward);
    }

    /**第一个未满足条件 */
    getFirstUnReachDetail() {
        let onlineTime = onlineTimeWidget.getOnlineTime();
        for (let config of onlinegiftconfig) {
            if (onlineTime < config.time) {
                return config.ID;
            }
        }
        return -1;
    }

    /**第一个未领取 */
    getFirstUnRecvDetail() {
        let onlineTime = onlineTimeWidget.getOnlineTime();
        for (let config of onlinegiftconfig) {
            let detail = this.onlineDetail.find(a => a.taskId == config.ID);
            if (!detail.recv && (onlineTime < config.time || (config.ID == onlinegiftconfig.length && onlineTime >= config.time))) {
                return config.ID;
            }
        }
        return -1;
    }

    /**最后一个未领取或倒计时中 */
    getLastUnRecvDetail() {
        let onlineTime = onlineTimeWidget.getOnlineTime();
        let id = -1;
        for (let config of onlinegiftconfig) {
            let detail = this.onlineDetail.find(a => a.taskId == config.ID);
            if (!detail.recv && onlineTime >= config.time) {
                id = config.ID;
            }
        }
        if (id == -1) {
            return this.getFirstUnRecvDetail();
        }
        return id;
    }

    getLastUnRecv() {
        let onlineTime = onlineTimeWidget.getOnlineTime();
        let id = -1;
        for (let config of onlinegiftconfig) {
            let detail = this.onlineDetail.find(a => a.taskId == config.ID);
            if (!detail.recv && onlineTime >= config.time) {
                id = config.ID;
            }
        }
        return id;
    }

    onlineFinished() {
        return this.onlineDetail.find(a => a.recv == false) == null;
    }

    async doGetDailyLightDetail() {
        let proto = await this._gm.request<TaskSevenNewVO>(GameProxy.apigiftgetNewSevenDetail, null);
        this.dailyLightModal = new DailyLightModal(proto);
        EManager.emit(EName.onUpdateActivityDatas, ActivityType.DailyLight);
    }

    async doGetNewSevenReward(id: number) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apigiftgetNewSevenReward, id);
        if (proto) {
            this.dailyLightModal.doReceive(id);
            gm.getReward(proto);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.DailyLight);
            commitLogic.commitReward(proto, DiamondSource.sevenLight);
        }
    }

    // 新手基金 begin
    sevenFundRed(): boolean {
        let red: boolean = false;
        if (!this.isNewPlayerFundValid()) { return false; }
        if (this.isNewPlayerFundOpen()) {
            for (let cfg of sevendayfundconfig) {
                if (!this.isFundRecved(cfg.day) && this.isFundCanRecv(cfg.day)) {
                    red = true;
                    break;
                }
            }
        } else {
            red = false;
        }

        let read: boolean = localLogic.getData(localIndex.sevenFundRead);
        console.log("新手基金今天是否进入过: " + read);
        return red || !read;
    }
    async recvSevenFundRewardReq(id: number) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiStorerecvSevenFund, id);
        gm.getReward(proto);
        commitLogic.commitReward(proto, DiamondSource.newFund);
    }
    isNewPlayerFundValid(): boolean {
        // 全部领取则无效
        let allRecv = sevendayfundconfig.every((v, i, a) => { return this.isFundRecved(v.day); })
        if (allRecv) { return false; }

        // 首充完成之后才会显示新手基金
        if (!rechargeLogic.hasStoreBuy) { return false; }

        // 剩余未领取或剩余时间内
        let day = defaultConfigMap.fundover.value;
        let ts = this._fundTs + day * 24 * 3600 * 1000;
        let leftTs = (ts - gm.getCurrentTimestamp()) / 1000;
        return leftTs > 0 || this.isNewPlayerFundOpen();
    }
    isNewPlayerFundOpen(): boolean {
        if (!this.newPlayerFund) { return false; }
        return this.newPlayerFund.open;
    }
    // 返利是否领取
    isFundRecved(day: number): boolean {
        if (!this.newPlayerFund) { return false; }
        return this.newPlayerFund.recvs[`${day}`];
    }
    setFundRecved(day: number, recv: boolean) {
        if (!this.newPlayerFund) { return; }
        this.newPlayerFund.recvs[`${day}`] = recv;
    }
    isFundCanRecv(day: number): boolean {
        if (!this.newPlayerFund) { return false; }
        return this.newPlayerFund.open && this.newPlayerFund.stageIdNow >= day;
    }
    async commitFuncTs() {
        if (this._fundTs > 0) { return; }
        let ts = gm.getCurrentTimestamp();

        let param = new CloudObjectReq();
        param.key = this._fundCloudKey;
        param.objData = { ts: ts };
        param.expire = 0;
        console.warn("提交新手基金开启时间: " + ts);
        let proto = await gm.request<{ [key: string]: any }>(GameProxy.apiutilsetCloudObject, [param]);
        if (proto) {
            this._fundTs = proto[this._fundCloudKey] ? proto[this._fundCloudKey].ts : 0;
            this._fundTs = this._fundTs ? this._fundTs : 0;
        }
    }
    async funcTsReq() {
        let param: string[] = [];
        param.push(this._fundCloudKey);
        let proto = await gm.request<{ [key: string]: any }>(GameProxy.apiutilgetCloudObject, param);
        if (proto) {
            this._fundTs = proto[this._fundCloudKey] ? proto[this._fundCloudKey].ts : 0;
            this._fundTs = this._fundTs ? this._fundTs : 0;
        }
        console.warn("初始化新手基金开启时间: " + this._fundTs);
    }
    getSevenFundTs() { return this._fundTs; }
    // 新手基金 end
}

let giftLogic = new GiftLogic();
export default giftLogic;

import activityLogic, { ActivityType } from "./ActivityLogic";
import newplayertimespendconfig from "../configs/newplayertimespendconfig";
import localLogic, { localIndex } from "./LocalLogic"; import commitLogic, { DiamondSource } from "./CommitLogic";
import { MonthCardStoreId } from "../view/component/Market/MonthCardModule";
import UnlockWrapper from "../view/widget/unlock/UnlockWrapper";
import { unlockConfigMap } from "../configs/unlockConfig";

