import BaseLogic from "./BaseLogic";
import GameProxy, { BuyFromStoreReq, ResourceVO, ShopVO } from "../proxy/GameProxy";
import Shop from "../data/card/Shop";
import ToastError from "../error/ToastError";
import bagLogic from "./BagLogic";
import { GoodId } from "../data/card/Good";
import IGameManager from "../manager/IGameManager";
import playerLogic from "./PlayerLogic";
import gm from "../manager/GameManager";
import assignmentLogic from "./AssignmentLogic";
import { SevenDayTaskType, WeekType, EventGroup, ZhuanPanEvent, DailyType } from "../utils/DefineUtils";
import Card from "../data/card/Card";
import goodsConfig, { goodsConfigRow } from "../configs/goodsConfig";
import activityLogic from "./ActivityLogic";
import stringUtils from "../utils/StringUtils";
import { stringConfigMap } from "../configs/stringConfig";
import commitLogic, { DiamondCost } from "./CommitLogic";

class ShopLogic extends BaseLogic {
    protected _shopGoods: Shop[] = [];
    protected _refreshCost: number = 0;
    protected _refreshTs: number = 0;
    protected _showType: string = "";

    init(shopProto: ShopVO, gm: IGameManager) {
        super.init(shopProto, gm);

        this._shopGoods = [];
        for (let proto of shopProto.goodsInfo) {
            let shop = new Shop(proto, shopProto.shopType);
            this._shopGoods.push(shop);
        }
        this._shopGoods.orderBy(a => a.getOrder());
        this._refreshCost = shopProto.refreshCost;
        this._refreshTs = shopProto.refreshTs;
        this._showType = shopProto.shopType;
    }

    getShopGood(shopId: number) {
        return this._shopGoods.find(a => a.getItemIndex() == shopId);
    }

    getShopGoods() {
        return this._shopGoods;
    }

    getRefreshCost(): number {
        return this._refreshCost;
    }

    getRefreshTs(): number {
        return this._refreshTs;
    }

    getShowType(): string {
        return this._showType;
    }

    async doBuyGood(shop: Shop) {
        if (bagLogic.getGood(shop.getCostType()).getAmount() < shop.getPrice() && !shop.getUseVideo()) {
            let goodConfig = goodsConfig.find(a => a.parameterid == shop.getCostType());
            if (goodConfig) {
                let message = stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: goodConfig.name });
                throw new ToastError(message);
            }
        }
        let req = new BuyFromStoreReq();
        req.order = shop.getOrder();
        req.shopType = shop.getShopType();
        req.useVideo = shop.getUseVideo();
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiShopbugFromStore, req);
        let propId = shop.getShopConfig().costType;
        if (!shop.getUseVideo()) {
            // 消耗金币,钻石,英雄币,公会币,迷宫币,角斗士硬币
            let ids: number[] = [
                GoodId.Gold, GoodId.Diamond, GoodId.HeroCoin,
                GoodId.UnionCoin, GoodId.WisdomCoin, GoodId.SeniorCoin,
                GoodId.ZhuanPanCoin, GoodId.WorldTreeCoin
            ]
            let index = ids.findIndex((a) => { return a == propId; })
            if (index >= 0) {
                bagLogic.getGood(propId).changeAmount(-shop.getPrice());
                if (propId == GoodId.Diamond) {
                    commitLogic.costDiamond(shop.getPrice(), DiamondCost.shopBuy);
                }
            }
        }
        if (shop.getBuyLimit()) {
            shop.setRemainCount(0);
        }
        gm.getReward(proto, true);

        if (req.shopType == "NormalShop") {
            assignmentLogic.weekTaskProCommit(WeekType.buy_shop);
            assignmentLogic.dailyTaskProCommit(DailyType.buy_store);
        } else if (req.shopType == "MazeShop") {
            assignmentLogic.weekTaskProCommit(WeekType.buy_maze_shop);
        } else if (req.shopType == "GuildShop") {
            if (shop.getIdType() == Card.Type.Equip) {
                assignmentLogic.weekTaskProCommit(WeekType.buy_equip_unionshop);
            }
        }

        this.commitShopBuyEvent(req.shopType, shop.getIndex(), shop.getAmount());
    }

    protected commitShopBuyEvent(type: string, id: number, num: number) {
        let shopType = {
            NormalShop: '普通',
            MazeShop: '智慧树',
            GuildShop: '公会',
            HeroDemoShop: '遣散',
            ArenaShop: '竞技场',
            TurnScoreShop: '转盘'
        }
        if (shopType[type]) {
            if (type == "TurnScoreShop") {
                this.commitEvent(EventGroup.ZhuanPanShop, ZhuanPanEvent.buy, `${id}`, 1);
                commitLogic.zpShopBuy(id, 1);
            } else {
                commitLogic.shopBuy(shopType[type], id, num);
            }
        }
    }

    async doRefreshShop() {
        let good = bagLogic.getGood(GoodId.Diamond);
        if (good.getAmount() < this._refreshCost) {
            throw new ToastError(stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() }));
        }
        let proto = await this._gm.request<ShopVO>(GameProxy.apiShopdiamondRefresh, this._showType);
        bagLogic.changeGoodAmount(GoodId.Diamond, -this._refreshCost);
        commitLogic.costDiamond(this._refreshCost, DiamondCost.shopRefresh);
    }

    commitEvent(group: string, event: string, param: string, value: number) {
        let userLevel: string = `${playerLogic.getPlayer().getLevel()}`;
        let vipLevel: string = `${playerLogic.getPlayer().getVipLevel()}`;

        gm.commitEvent(group, [userLevel, vipLevel, event, param], value);
    }
}

let shopLogic = new ShopLogic();
export default shopLogic;