import BaseLogic from "./BaseLogic";
import GameProxy, { ProcessReq, ResourceVO, RMissionBuyReq, RMissionCycleReq, RMissonInfoBO } from "../proxy/GameProxy";
import RMission from "../data/mission/RMission";
import resourcegameconfig from "../configs/resourcegameconfig";
import Card from "../data/card/Card";
import playerLogic from "./PlayerLogic";
import gm from "../manager/GameManager";
import bagLogic from "./BagLogic";
import { GoodId } from "../data/card/Good";
import EManager, { EName } from "../manager/EventManager";
import commitLogic, { DiamondCost } from "./CommitLogic";
import { defaultConfigMap } from "../configs/defaultConfig";
import assignmentLogic from "./AssignmentLogic";
import { WeekType } from "../utils/DefineUtils";
import promptLogic, { PromptType } from "./PromptLogic";
import {stringConfigMap} from "../configs/stringConfig";

export enum RMissionType {
    GOLD = 1,         //金币
    EXP,              //经验
    STRONGTH_STONE,   //强化铸币
    ARTIFACT_STONE,   //神器强化石
    SOUL_STONE,       //灵魂石
}

export let RMissionName = [
    "金币副本",
    "经验副本",
    "强化铸币副本",
    "神器强化石副本",
    "灵魂石副本"
];

class RMissionLogic extends BaseLogic {

    protected _rMissionInfo: RMissonInfoBO = null;
    protected _rMission: RMission[] = [];

    init(gm) {
        super.init(null, gm);
    }

    updateRMission(rMissionInfo: RMissonInfoBO) {
        this._rMission = [];
        for (let missionItem of rMissionInfo.info) {
            let cfgs = resourcegameconfig.where(a => a.type == missionItem.type);
            for (let cfg of cfgs) {
                let rMission = new RMission(cfg, missionItem);
                this._rMission.push(rMission);
            }
        }
    }

    get rMissionInfo(): RMissonInfoBO {
        return this._rMissionInfo;
    }

    getRMission(type): RMission[] {
        return this._rMission.where(a => a.getType() == type);
    }

    getRecycleMission(): RMission[] {
        return this._rMission.where(a => a.canRecycle());
    }

    canFreeChallenge(): boolean {
        for (let rm of this._rMission) {
            if (rm.canShowRedPoint()) {
                return true;
            }
        }
        return false;
    }

    /**购买挑战次数 */
    async doBuyRMissionCount(rMission: RMission, buyCnt: number, tip: boolean = true) {
        let rMissionBuyReq = new RMissionBuyReq();
        rMissionBuyReq.type = rMission.getType();
        rMissionBuyReq.buyCount = buyCnt;
        let proto = await this._gm.request<number>(GameProxy.apirmissionbuyRMissionCount, rMissionBuyReq);
        if (proto) {
            if (tip) {
                gm.toast(stringConfigMap.key_auto_554.Value);
            }
            bagLogic.getGood(GoodId.Diamond).changeAmount(-rMission.getPrice(buyCnt));
            commitLogic.costDiamond(rMission.getPrice(buyCnt), DiamondCost.resTimesBuy);
            let info = this._rMissionInfo.info.find(a => a.type == rMission.getType());
            if (info) {
                info.buyCount = proto;
                let buyPrice: string[] = defaultConfigMap.resourcebuyprice.value.split(';');
                if (proto > (buyPrice.length - 1)) {
                    info.buyPrice = Number(buyPrice[buyPrice.length - 1]);
                } else {
                    info.buyPrice = Number(buyPrice[proto]);
                }
            }
            EManager.emit(EName.onUpdateMaterial, true);
            promptLogic.setPrompt(PromptType.RMISSION_FREE, true);
        }
    }

    /**获取资源副本数据 */
    async doGetRMissionInfo(type: RMissionType) {
        this._rMissionInfo = await this._gm.request<RMissonInfoBO>(GameProxy.apirmissiongetRMissionInfo, type);
        this.updateRMission(this._rMissionInfo);
        if (!this.canFreeChallenge()) {
            promptLogic.setPromptRead([PromptType.RMISSION_FREE]);
        }
    }

    updateRedPoint() {
        if (this.canFreeChallenge()) {
            promptLogic.setPrompt(PromptType.RMISSION_FREE, true);
        }
    }

    /**资源回收 */
    async doRecycle(pay: boolean, types: number[], diamond?: number) {
        let rMissionCycleReq = new RMissionCycleReq();
        rMissionCycleReq.pay = pay;
        rMissionCycleReq.types = types;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apirmissionrecycle, rMissionCycleReq);
        if (proto) {
            gm.getReward(proto);
            if (diamond) {
                bagLogic.getGood(GoodId.Diamond).changeAmount(-diamond);
            }
            for (let type of types) {
                let info = this._rMissionInfo.info.find(a => a.type == type);
                if (info) {
                    info.recovCount = 0;
                }
            }
        }
    }

    /**扫荡 */
    async doSweep(rMission: RMission) {
        let proto = await this._gm.request<ResourceVO>(GameProxy.apirmissionsweep, rMission.getType());
        if (proto) {
            gm.getReward(proto);
            let info = this._rMissionInfo.info.find(a => a.type == rMission.getType());
            if (info) {
                info.nowCount++;
            }
            EManager.emit(EName.onUpdateMaterial, true);
            assignmentLogic.weekTaskProCommit(WeekType.fight_mat);
            commitLogic.matFight(rMission.getType(), true, true);
            if (!this.canFreeChallenge()) {
                promptLogic.setPromptRead([PromptType.RMISSION_FREE]);
            }
        }
    }

    /**过关 */
    async doPassMission(mission: RMission): Promise<Card[]> {
        let req = new ProcessReq();
        req.stageId = mission.getStageId();
        req.systemId = mission.getType() + 7;
        let proto = await this._gm.request<ResourceVO>(GameProxy.apiprocesspassProcess, req);
        let cards = playerLogic.addCards(proto);
        let player = playerLogic.getPlayer();
        player.setExp(proto.roleVO.exp);
        player.setLevelExp(proto.roleVO.lvExp);
        player.setLevel(proto.roleVO.lv);

        if (mission.getStageId() == proto.proces.stageId) {
            mission.pass();
        }
        if (!this.canFreeChallenge()) {
            promptLogic.setPromptRead([PromptType.RMISSION_FREE]);
        }

        return cards;
    }

}

let rMissionLogic = new RMissionLogic();
export default rMissionLogic;