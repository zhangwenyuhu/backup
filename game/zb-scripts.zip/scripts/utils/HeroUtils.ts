import { stringConfigMap } from './../configs/stringConfig';
import { EquipBO, HeroModulAddItem, HeroModulBO } from "../proxy/GameProxy";
import Equip from "../data/card/Equip";
import heroRankConfig, { heroRankConfigRow } from "../configs/heroRankConfig";
import equipLevelConfig from "../configs/equipLevelConfig";
import Hero from "../data/card/Hero";
import Property from '../data/Property';

const HeroQualityHead = ["green", "blue", "purple", "yellow", "red", "white"];
const HeroQualityStr = ["普通", "稀有", "精英", "史诗", "传说", "神话"];
const QualityColor = ["#5de86c", "#00c6ff", "#f85ef9", "#efce48", "#ff2525", "#fff8de"];

export class HeroQualityInfo {
    qualityHead: string;
    qualityStr: string;
    qualityHigh: number = 0; //进阶
    qualityColor: string = "";
    qualityLevel: number = 0;
}

export class HeroMaterial {
    type: number = 0;
    rank: number = 1;
    cnt: number = 1;
}

class HeroUtils {

    /**
     * 获取英雄品质信息
     * @param rank    卡牌品阶
     */
    getHeroQualityInfo(rank: number): HeroQualityInfo {
        let heroRankCfg = heroRankConfig[rank - 1];
        let heroQualityInfo = new HeroQualityInfo();
        heroQualityInfo.qualityHead = heroRankCfg.RankHead;
        heroQualityInfo.qualityStr = heroRankCfg.RankName;
        heroQualityInfo.qualityHigh = Number(heroRankCfg.RankHigh);
        heroQualityInfo.qualityColor = heroRankCfg.RankColor;
        heroQualityInfo.qualityLevel = Number(heroRankCfg.RankHead);
        return heroQualityInfo;
    }

    getEquipQuality(rank: number) {
        let equipRankCfg = equipLevelConfig[rank - 1];
        return { qualityHead: equipRankCfg.RankHead, qualityColor: equipRankCfg.RankColor, qualityStr: equipRankCfg.RankName, qualityHigh: Number(equipRankCfg.RankHigh) };
    }

    getArtifactQuality() {
        return { qualityHead: "6", qualityColor: "", qualityStr: "" };
    }

    getFactionStr(faction: number) {
        return stringConfigMap[`key_faction_${faction}`].Value;
    }

    getXsQualityStr(quality: number) {
        return HeroQualityStr[quality - 1];
    }

    getXsQualityColor(quality: number) {
        return QualityColor[quality];
    }

    getUnionStatueLevelColor(level: number) {
        let index = level > QualityColor.length ? QualityColor.length : level;
        return { color: QualityColor[index - 1], colorName: HeroQualityHead[index - 1] };
    }

    getHeroAddInfos(equips: EquipBO[]) {
        let heroAddInfos: HeroModulBO[] = [];
        for (let equip of equips) {
            let _equip = new Equip(equip);
            let info = new HeroModulBO();
            for (let config of Property.Config) {
                let item = new HeroModulAddItem();
                item.addValue = _equip.getValue(config);
                info[`${config.VarName}Add`] = item;
            }
            heroAddInfos.push(info);
        }
        return heroAddInfos;
    }

    getPropertyStrings(): string[] {
        return [
            stringConfigMap.key_atk.Value,
            stringConfigMap.key_def.Value,
            stringConfigMap.key_hp.Value,
            stringConfigMap.key_crit_rate.Value,
            stringConfigMap.key_hit.Value,
            stringConfigMap.key_dodge.Value,
            stringConfigMap.key_rapid.Value,
            stringConfigMap.key_magic_resist.Value,
            stringConfigMap.key_phy_resist.Value
        ]
    }

    getPropertyNames(): string[] {
        return [
            'atk',
            'def',
            'hp',
            'criPct',
            'criAtk',
            'hit',
            'dodge',
            'rapid',
            'magicResist',
            'phyResist'
        ]
    }

    getEvolutionInfo(hero: Hero) {
        let type = [];
        let rank = [];
        let heroRank: heroRankConfigRow = heroRankConfig[hero.getRank(true) - 1];
        let faction = hero.getFaction();
        if (faction == 5 || faction == 6) {
            type = heroRank.SpecialType;
            rank = heroRank.SpecialRank;
        } else if (hero.getQuality() <= 3) {
            type = heroRank.Type;
            rank = heroRank.Rank;
        } else if (hero.getQuality() == 4) {
            type = heroRank.URSpecialType;
            rank = heroRank.URSpecialRank;
        }
        return { type: type, rank: rank };
    }

    getEvolutionInfo2(hero: Hero) {
        let _materials: HeroMaterial[] = [];
        let evoInfo = this.getEvolutionInfo(hero);
        for (let i = 0; i < evoInfo.type.length; i++) {
            let type = evoInfo.type[i];
            let rank = evoInfo.rank[i];
            let _material = new HeroMaterial();
            _material.type = type;
            _material.rank = rank;
            _material.cnt = 1;
            _materials.push(_material);
        }
        return _materials;
    }

    getEvolutionInfo3(hero: Hero) {
        let _materials: HeroMaterial[] = [];
        let evoInfo = this.getEvolutionInfo(hero);
        for (let i = 0; i < evoInfo.type.length; i++) {
            let type = evoInfo.type[i];
            let rank = evoInfo.rank[i];
            let material = _materials.find(a => a.type == type && a.rank == rank);
            if (material) {
                material.cnt++;
            } else {
                let _material = new HeroMaterial();
                _material.type = type;
                _material.rank = rank;
                _material.cnt = 1;
                _materials.push(_material);
            }
        }
        return _materials;
    }

    getEvolutionIndex(hero: Hero, index: number) {
        let material: HeroMaterial[] = this.getEvolutionInfo2(hero);
        let _index = 0;
        for (let i = 0; i < material.length; i++) {
            if (_index == index) {
                return i;
            }
            for (let j = 0; j < material[i].cnt; j++) {
                _index++;
            }
        }
        return -1;
    }

    getRandomHero(allHeroes: Hero[], excludeHeroes: Hero[]) {
        while (true) {
            let rd = Math.floor(Math.random() * allHeroes.length);
            let hero = allHeroes[rd];
            if (excludeHeroes.indexOf(hero) == -1) {
                return hero;
            }
        }
    }
}

let heroUtils = new HeroUtils();
export default heroUtils;