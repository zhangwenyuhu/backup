import playerLogic from "../logics/PlayerLogic";
import gm from "../manager/GameManager";
import GameProxy, { CloudObjectReq } from "../proxy/GameProxy";
import { Storage } from "./DefineUtils";

/**
 * 存储工具类
 */
class StorageUtils {
    protected _cloudKeyValues: { [key: string]: any } = {};

    init() {
        gm.request<{ [key: string]: any }>(GameProxy.apiutilgetCloudObject, [
            Storage.AutoSplit.Key,
            Storage.AutoSkill.Key,
            Storage.SpeedX2.Key,
            Storage.FirstFail.Key,
            Storage.ChatMsgCard.Key,
            Storage.ChatMsgHero.Key,
            Storage.RecycleGuide.Key,
            Storage.EvolutionGuide.Key,
            Storage.FreeVideoTimestamp.Key,
            Storage.GuideStrongEquip.Key,
            Storage.GuideMergeEquip.Key,
            Storage.GuideStarEquip.Key,
            Storage.GuideChargeEquip.Key,
            Storage.GuideSpeedX2.Key,
            Storage.LeftButtonsOpen.Key,
            Storage.RightButtonsOpen.Key,
            Storage.OnlineTime.Key,
            Storage.TenLottery.Key,
            Storage.OnlineGuide.Key,
            Storage.DungeonGuide.Key,
            Storage.DungeonGuideFruit.Key,
            Storage.DungeonGuideReward.Key,
            Storage.DungeonGuideDoor.Key,
            Storage.LastDungeonIn.Key,
            Storage.LastGeniusIn.Key,
            Storage.StoryProcess.Key,
            Storage.ArtifactGuide.Key,
            Storage.ArtifactForgeGuide.Key,
            Storage.ArenaJuniorDefense.Key,
            Storage.ArenaSeniorDefense.Key,
            Storage.ShengXingGuide.Key,
            Storage.HeChengGuide.Key,
            Storage.CloneGuide.Key,
            Storage.TreasureShopTs.Key,
            Storage.ArenaReportTs.Key,
            Storage.ArenaSeniorReportTs.Key,
            Storage.FirstSupplyGuide.Key,
            Storage.FirstSeniorSupplyGuide.Key,
            Storage.SupplyUnlock.Key,
            Storage.ArenaSeniorLimitTime.Key
        ]).then((protos: { [key: string]: any }) => {
            if (protos) {
                for (let key in protos) {
                    if (protos[key]) {
                        this._cloudKeyValues[key] = protos[key].data;
                    }
                }
            }
        }).catch(err => { console.error(err) });
    }

    async request(key: string) {
        try {
            let protos = await gm.request<{ [key: string]: any }>(GameProxy.apiutilgetCloudObject, [key]);
            if (protos) {
                for (let key in protos) {
                    if (protos[key]) {
                        this._cloudKeyValues[key] = protos[key].data;
                    }
                }
            }
        } catch (e) {
            console.error(e);
        }
    }

    getString(item: { Key: string, Default: string }, withRoleId: boolean = true): string {
        if (typeof this._cloudKeyValues[item.Key] == "string") {
            return this._cloudKeyValues[item.Key] as string;
        }

        let newKey = item.Key;
        if (withRoleId && playerLogic.getPlayer()) {
            newKey = `${newKey}_${playerLogic.getPlayer().getRoleId()}`;
        }
        let value = localStorage.getItem(newKey);
        if (!value) value = item.Default;
        return value;
    }

    setString(key: string, value: string, cloud?: boolean, withRoleId: boolean = true): boolean {
        if (cloud) {
            if (this._cloudKeyValues[key] === value) return false;

            let req = new CloudObjectReq();
            req.expire = 0;
            req.key = key;
            req.objData = { data: value };
            gm.request(GameProxy.apiutilsetCloudObject, [req], GameProxy, true);
            this._cloudKeyValues[key] = value;
        }
        else {
            let newKey = key;
            if (withRoleId && playerLogic.getPlayer()) {
                newKey = `${newKey}_${playerLogic.getPlayer().getRoleId()}`;
            }
            localStorage.setItem(newKey, value);
        }
        return true;
    }

    getNumber(item: { Key: string, Default: number }, withRoleId: boolean = true): number {
        if (typeof this._cloudKeyValues[item.Key] == "number") {
            return this._cloudKeyValues[item.Key] as number;
        }

        let newKey = item.Key;
        if (withRoleId && playerLogic.getPlayer()) {
            newKey = `${newKey}_${playerLogic.getPlayer().getRoleId()}`;
        }
        let value = localStorage.getItem(newKey);
        if (!value) {
            return item.Default;
        }
        else {
            return new Number(value).valueOf();
        }
    }

    setNumber(key: string, value: number, cloud?: boolean, withRoleId: boolean = true): boolean {
        if (cloud) {
            if (this._cloudKeyValues[key] === value) return false;

            let req = new CloudObjectReq();
            req.expire = 0;
            req.key = key;
            req.objData = { data: value };
            gm.request(GameProxy.apiutilsetCloudObject, [req], GameProxy, true);
            this._cloudKeyValues[key] = value;
        }
        else {
            let newKey = key;
            if (withRoleId && playerLogic.getPlayer()) {
                newKey = `${newKey}_${playerLogic.getPlayer().getRoleId()}`;
            }
            localStorage.setItem(newKey, value.toString());
        }
        return true;
    }

    getBoolean(item: { Key: string, Default: boolean }, withRoleId: boolean = true) {
        if (typeof this._cloudKeyValues[item.Key] == "boolean") {
            return this._cloudKeyValues[item.Key] as boolean;
        }

        let newKey = item.Key;
        if (withRoleId && playerLogic.getPlayer()) {
            newKey = `${newKey}_${playerLogic.getPlayer().getRoleId()}`;
        }
        let value = localStorage.getItem(newKey);
        if (!value) {
            return item.Default;
        }
        else {
            return value == "true" ? true : false;
        }
    }

    setBoolean(key: string, value: boolean, cloud?: boolean, withRoleId: boolean = true): boolean {
        if (cloud) {
            if (this._cloudKeyValues[key] === value) return false;

            let req = new CloudObjectReq();
            req.expire = 0;
            req.key = key;
            req.objData = { data: value };
            gm.request(GameProxy.apiutilsetCloudObject, [req], GameProxy, true);
            this._cloudKeyValues[key] = value;
        }
        else {
            let newKey = key;
            if (withRoleId && playerLogic.getPlayer()) {
                newKey = `${newKey}_${playerLogic.getPlayer().getRoleId()}`;
            }
            localStorage.setItem(newKey, value ? "true" : "false");
        }
        return true;
    }
}

let storageUtils = new StorageUtils();
export default storageUtils;