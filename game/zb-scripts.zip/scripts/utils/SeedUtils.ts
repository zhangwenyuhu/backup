export default class SeedUtils {
    seed: number;

    constructor(startSeed: number) {
        this.seed = startSeed
    }

    /**
     * 创建新的随机数 范围为0~1
     */
    random(): number {
        this.seed = (this.seed * 9301 + 49297) % 233280;
        return this.seed / 233280.0;
    }

}