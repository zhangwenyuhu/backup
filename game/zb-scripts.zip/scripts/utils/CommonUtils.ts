import { EquipBO, HeroVO, GoodVO, ArtifactBO, RewardBO, Battle_heroConfig } from './../proxy/GameProxy';
import heroUtils from "./HeroUtils";
import Info from "../Info";
import { BattleType } from "./DefineUtils";
import playerLogic from "../logics/PlayerLogic";
import loadUtils from './LoadUtils';
import artifactConfig from "../configs/artifactConfig";
import cm from '../manager/ConfigManager';
import BgMixerEx from '../view/component/BgMixerEx';
import Card from '../data/card/Card';
import Good, { GoodId } from '../data/card/Good';
import Hero from '../data/card/Hero';
import Equip from '../data/card/Equip';
import Artifact from '../data/card/Artifact';
import equippowerConfig from '../configs/equippowerConfig';

/**
 * 通用工具类
 */
class CommonUtils {
    /**
     * 延迟
     * @param time 事件
     * @param comp 依赖组件
     */
    async sleep(time: number, comp?: cc.Component) {
        return new Promise((resolve, reject) => {
            if (comp) {
                comp.scheduleOnce(() => {
                    resolve();
                }, time);
            }
            else {
                setTimeout(() => {
                    resolve();
                }, time * 1000);
            }
        });
    }

    /**
     * 重载节点
     * @param node 节点
     */
    reload(node: cc.Node) {
        for (let child of node.children) {
            this.reload(child);
        }

        let components = node.getComponents(cc.Component) as any;
        for (let comp of components) {
            if (comp.reload) { comp.reload(); }
        }
    }

    /**
     * 暂停节点
     * @param node 节点
     */
    pauseNode(node: cc.Node) {
        cc.director.getActionManager().pauseTarget(node);
        let components = node.getComponents(cc.Component);
        for (let comp of components) {
            cc.director.getScheduler().pauseTarget(comp);
        }
        let animations = node.getComponents(cc.Animation);
        for (let animation of animations) {
            animation.pause();
        }
        let spines = node.getComponents(sp.Skeleton);
        for (let spine of spines) {
            spine.paused = true;
        }
        for (let child of node.children) {
            this.pauseNode(child);
        }
    }

    /**
     * 恢复节点
     * @param node 节点
     */
    resumeNode(node: cc.Node) {
        cc.director.getActionManager().resumeTarget(node);
        let components = node.getComponents(cc.Component);
        for (let comp of components) {
            cc.director.getScheduler().resumeTarget(comp);
        }
        let animations = node.getComponents(cc.Animation);
        for (let animation of animations) {
            animation.resume();
        }
        let spines = node.getComponents(sp.Skeleton);
        for (let spine of spines) {
            spine.paused = false;
        }
        for (let child of node.children) {
            this.resumeNode(child);
        }
    }

    /**
     * 加载场景
     * @param sceneName 场景名
     * @param afterLaunch 加载完成后回调
     */
    loadScene(sceneName: string, afterLaunch?: Function) {
        cc.director.loadScene(sceneName, (error: Error, scene: cc.Scene) => {
            if (error) {
                console.error(error)
                setTimeout(() => {
                    this.loadScene(sceneName, afterLaunch);
                }, 1000);
            }
            else {
                if (afterLaunch) {
                    afterLaunch(scene);
                }
            }
        });
    }

    /**
     * 英雄种族底图地址
     * @param color 
     */
    getHeroCircleUrl(color: string) {
        return `textures/icon/hero/hero_icon_bg_c_${color}`;
    }

    /**
     * 英雄框地址
     * @param color 
     */
    getHeroRectUrl(color: string) {
        return `textures/icon/hero/hero_icon_bg_${color}`;
    }

    /**
     * 英雄底地址
     * @param color 
     */
    getHeroBgUrl(color: string) {
        return `textures/icon/hero/hero_icon_bg_d_${color}`;
    }

    /**
     * 英雄种族地址
     * @param faction 
     */
    getHeroFactionUrl(faction: number) {
        return `textures/icon/hero/hero_tag_${faction}`;
    }

    /**
     * 英雄种族抽卡提示
     * @param faction 
     */
    getHeroFactionLotteryTip(faction: number) {
        return `textures/icon/hero/hero_lottery_${faction}`;
    }

    /**
     * 英雄图鉴种族图标
     * @param faction 
     */
    getBigHeroFactionUrl(faction: number) {
        return `textures/hero/hero_tag_${faction}`;
    }

    /**
     * 英雄职业图标
     * @param carceer 
     */
    getHeroCareerUrl(carceer: number) {
        return `textures/icon/hero/hero_career_${carceer}`;
    }

    /**
     * 英雄定位图标
     * @param duty 
     */
    getHeroDutyUrl(duty: number) {
        return `textures/icon/hero/hero_duty_b_${duty}`;
    }

    /**
     * 英雄图鉴图标
     * @param index 
     */
    getHeroBigUrl(index: number) {
        return `textures/hero/hero_head_${index}`;
    }

    /**
     * 英雄图鉴框
     * @param quality 
     */
    getHeroBigRectUrl(quality: number) {
        return `textures/hero/hero_icon_bg_big${quality}`;
    }

    /**
     * 英雄品质图标
     * @param quality 
     */
    getHeroQualityIconUrl(quality: number) {
        return `textures/hero/hero_quality_${quality}`;
    }

    /**
     * 英雄Spine地址
     * @param name 
     */
    getHeroSpineUrl(name: string) {
        return `spine/hero/${name}`;
    }

    /**
     * 英雄皮肤图标
     * @param index 
     */
    getHeroSkinUrl(index: number) {
        return `textures/skin/hero_skin_${index}`;
    }

    /**
     * UI的Spine地址
     * @param name 
     */
    getUISpineUrl(name: string) {
        return `spine/ui/${name}`;
    }

    /**
     * 英雄图标地址
     * @param index 
     */
    getHeroIconUrl(index: number) {
        return `textures/icon/hero/hero_icon_${index}`;
    }

    getHeroUdgIconUrl(index: number) {
        return `textures/ui/panel/union_dungeon/fb_hero_${index}`;
    }

    /**
     * 英雄品质图标
     * @param qualityLevel 
     */
    getHeroQualityUrl(qualityLevel: number) {
        return `textures/icon/hero/hero_quality_gem_${qualityLevel}`;
    }

    /**
     * 英雄品质角标地址
     * @param index 
     */
    getHeroHighUrl(index: number) {
        return `textures/icon/hero/hero_icon_high${index}`;
    }

    getHeroBattleStationUrl(rank: string): string {
        return `textures/ui/common/battle_station_${rank}`;
    }

    getHeroBattleRectUrl(rank: string): string {
        return `textures/ui/panel/battle/battle_card_rect_${rank}`;
    }

    getHeroDungeonHeroStation(rank: string): string {
        return `textures/ui/common/battle_station_${rank}`;
    }

    getHeroBattleDizuoUrl(rank: string): string {
        return `textures/ui/panel/battle/battle_card_dizuo_${rank}`;
    }

    getHeroDutyIcoUrl(index: number) {
        return `textures/icon/hero/hero_duty_${index}`;
    }

    getHeroTitleUrl(index: number) {
        return `textures/ui/hero/hero_icon_title${index}`;
    }

    getHeroRankExUrl(index: number) {
        return `textures/icon/hero/hero_icon_rank_ex_${index}`;
    }

    getSkillIconUrl(index: number) {
        return `textures/icon/skill/skill_icon_${index}`;
    }

    getHeroSkillIconUrl(name: string) {
        return `textures/icon/skill/${name}`;
    }

    getArtifactIconUrl(artifactId: number, star: number = 0) {
        let artifactCfg = artifactConfig.find(a => a.Id == artifactId);
        let icon = artifactCfg.icon[star];
        return `textures/icon/equip/artifact_icon_${artifactId}_${icon}`;
    }

    getArtifactRectUrl() {
        return 'textures/icon/equip/artifact_frame';
    }

    getArtifactBgUrl() {
        return 'textures/icon/equip/artifact_frame_bg';
    }

    getUnionIconUrl(index: string) {
        return `textures/ui/panel/union/union_avatar_icon${index}`;
    }

    getEquipCircleUrl(quality: number) {
        let color = heroUtils.getEquipQuality(quality).qualityHead;
        return `textures/icon/equip/equip_icon_bg_c_${color}`;
    }

    getEquipIconUrl(equipId: number) {
        let config = cm.getEquipConfig(equipId);
        return `textures/icon/equip/${config.icon}`;
    }

    getEquipBgUrl(quality: number) {
        let name = heroUtils.getEquipQuality(quality).qualityHead;
        return `textures/icon/equip/equip_icon_bg_d_${name}`;
    }

    getEquipRectUrl(quality: number) {
        let name = heroUtils.getEquipQuality(quality).qualityHead;
        return `textures/icon/equip/equip_icon_bg_${name}`;
    }

    getEquipTypeUrl(career: number) {
        return `textures/icon/hero/hero_career_${career}`;
    }

    // 获取装备充能套装图标
    getEquipOutfitIcon(chargeLv: number, active: boolean = false) {
        if (chargeLv <= 0) { return ''; }
        let outfit = this.getEquipChargeOutFitIconLv();
        let outfitId: number = 0;
        for (let i = 0; i < outfit.length; i++) {
            if (chargeLv >= outfit[i][1]) {
                outfitId = outfit[i][0];
            }
        }
        if (outfitId <= 0) { return ''; }
        let url: string = "";
        if (active) {
            url = `textures/ui/common2/common_outfit_${outfitId}${outfitId}`;
        } else {
            url = `textures/ui/common2/common_outfit_${outfitId}`;
        }
        return url;
    }

    getGoodSIconUrl(goodId: number) {
        let config = cm.getGoodConfig(goodId);
        let icon = config.icon.replace('icon', "s_icon");
        return `textures/icon/good/${icon}`;
    }

    getGoodIconUrl(goodId: number) {
        let config = cm.getGoodConfig(goodId);
        if (config.icon.startsWith('gift')) {
            return `textures/icon/gift/${config.icon}`;
        }
        else if (config.icon.startsWith('box')) {
            return `textures/icon/good/box/${config.icon}`;
        }
        else {
            return `textures/icon/good/${config.icon}`;
        }
    }

    getGoodBgUrl(quality: number) {
        return `textures/icon/good/good_icon_bg_d_${quality + 1}`;
    }

    getGoodRectUrl(quality: number) {
        return `textures/icon/good/good_icon_bg_${quality + 1}`;
    }

    getPropertyIconUrl(name: string) {
        return `textures/icon/hero/property/${name}`;
    }

    getPropIconUrl(propId: number) {
        let cof = cm.getPropertyConfig(propId);
        if (!cof) { return ''; }
        return `textures/ui/common/icon_property_${cof.VarName}`
    }

    getCommonUrl(name: string) {
        return `textures/ui/common/${name}`;
    }

    getCommon2Url(name: string) {
        return `textures/ui/common2/${name}`;
    }

    getPanelIconUrl(panel: string, name: string) {
        return `textures/ui/panel/${panel}/${name}`;
    }

    getPanelEquipUrl(name: string) {
        return `textures/ui/panel/equip/${name}`;
    }

    getBgUrl(name: string) {
        return `textures/bg/${name}`;
    }

    getBattleBgUrl(battleType: BattleType, name?: string) {
        if (name) {
            return commonUtils.getBgUrl(name);
        }
        else {
            if (battleType == BattleType.Tower) {
                return commonUtils.getBgUrl("tower_battle_bg");
            }
            else if (battleType == BattleType.PVP || battleType == BattleType.PVE) {
                return commonUtils.getBgUrl("arena_battle_bg");
            }
            else if (battleType == BattleType.Dungeon) {
                return commonUtils.getBgUrl("dungeon_battle_bg");
            }
            else {
                return commonUtils.getBgUrl("battle_bg");
            }
        }
    }

    getAssignmentIconUrl(name: string) {
        return `textures/ui/panel/assignment/${name}`;
    }

    /**获取段位图标*/
    getArenaIconUrl(rankId: number) {
        let arenaRankCfg = cm.getArenaRankIdConfig(rankId);
        return `textures/ui/panel/arena/arena_common/arena_title${arenaRankCfg.icon}`;
    }

    /**获取段位名*/
    getArenaTitleTextUrl(rankId: number) {
        let arenaRankCfg = cm.getArenaRankIdConfig(rankId);
        return `textures/ui/panel/arena/arena_common/arena_title_text${arenaRankCfg.icon}`;
    }

    /**获取段位阿拉伯数字*/
    getArenaRankTextUrl(level: number) {
        return `textures/ui/panel/arena/arena_common/arena_rank${level}`;
    }

    getPrivateId(): string {
        // return `${Info.appId}-${gssdk.loginData.roleId}`;
        return `${Info.appId}-${playerLogic.getPlayer().getRoleId()}`;
    }

    setColor(node: cc.Node, color: cc.Color) {
        for (let child of node.children) {
            child.color = color;
            this.setColor(child, color);
        }
    }

    setMaterial(node: cc.Node, material: cc.Material) {
        for (let child of node.children) {
            if (child.getComponent(cc.Sprite)) {
                child.getComponent(cc.Sprite).setMaterial(0, material);
                // } else if (child.getComponent(cc.Label)) {
                //     child.getComponent(cc.Label).setMaterial(0, material);
            }
            this.setMaterial(child, material);
        }
    }

    setOpacity(node: cc.Node, opacity) {
        for (let child of node.children) {
            if (child.children.length > 0) {
                this.setOpacity(child, opacity);
            } else {
                child.opacity = opacity;
            }
        }
    }

    createEquipBO(params: number[]): EquipBO[] {
        let bos: EquipBO[] = [];
        let configId = params[0];
        let count = params[1];
        let faction = params[2];
        for (let i = 0; i < count; i++) {
            let bo = new EquipBO();
            bo.equipCofId = configId;
            bo.campBonus = faction | 0;
            bos.push(bo);
        }
        return bos;
    }

    createHeroVO(params: number[]): HeroVO[] {
        let vos: HeroVO[] = [];
        let configId = params[0];
        let count = params[1];
        let rank = params[2];
        for (let i = 0; i < count; i++) {
            let vo = new HeroVO();
            vo.heroCofId = configId;
            vo.lv = 1;
            vo.rank = rank | 0;
            vos.push(vo);
        }
        return vos;
    }

    createGoodVO(params: number[]): GoodVO {
        let configId = params[0];
        let count = params[1];
        let vo = new GoodVO();
        vo.propId = configId;
        vo.amt = count;
        return vo;
    }

    async addChapterFgSpriteFrame(node: cc.Node) {
        let sprite = node.getComponent(cc.Sprite);
        let exts = sprite.spriteFrame.name.split('_');
        let spriteFrame = await loadUtils.loadRes(commonUtils.getBgUrl(`main_battle_fg${exts[2]}`), cc.SpriteFrame) as cc.SpriteFrame;
        node.getChildByName("fg").getComponent(BgMixerEx).spriteFrame = spriteFrame;
    }

    card2Item(cards: Card[]) {
        let item = [];
        for (let card of cards) {
            let _item = [];
            _item.push(card.getIndex());
            if (card.getType() == Card.Type.Good) {
                _item.push((card as Good).getAmount());
            } else {
                _item.push(1);
            }
            item.push(_item);
        }
        return item;
    }

    item2Card(item: number[]) {
        let id = item[0];
        let num = item[1] ? item[1] : 0;
        let type = Math.floor(id / 10000);
        let card: Card = null;
        if (type == Card.Type.Good) {
            let vo = new GoodVO();
            vo.amt = num;
            vo.propId = id;
            card = new Good(vo);
        } else if (type == Card.Type.Hero) {
            let heroVo = new HeroVO();
            heroVo.heroCofId = id;
            heroVo.lv = 1;
            heroVo.rank = item.length > 2 ? item[2] : 0;
            heroVo.equips = [];
            card = new Hero(heroVo);
        } else if (type == Card.Type.Equip) {
            let equipBo = new EquipBO();
            equipBo.equipCofId = id;
            let camp = item.length > 2 ? item[2] : 0;
            camp = camp ? camp : 0;
            equipBo.campBonus = camp;
            card = new Equip(equipBo);
        } else if (type == Card.Type.Artifact) {
            let artifactBo = new ArtifactBO();
            artifactBo.artifactCofId = id;
            artifactBo.rank = 0;
            artifactBo.forgeLv = 0;
            card = new Artifact(artifactBo);
        }
        return card;
    }

    reward2Card(reward: RewardBO): Card {
        let card: Card = null;
        if (reward.objId == 'goods') {
            let vo = new GoodVO();
            vo.amt = Number(reward.amt);
            vo.propId = reward.propId;
            card = new Good(vo);
        } else if (reward.objId == 'hero') {
            let heroVo = new HeroVO();
            heroVo.heroCofId = reward.propId;
            heroVo.lv = 1;
            heroVo.rank = 0;
            heroVo.equips = [];
            card = new Hero(heroVo);
        } else if (reward.objId == 'equip') {
            let equipBo = new EquipBO();
            equipBo.equipCofId = reward.propId;
            card = new Equip(equipBo);
        } else if (reward.objId == 'artifacts') {
            let artifactBo = new ArtifactBO();
            artifactBo.artifactCofId = reward.propId;
            artifactBo.rank = 0;
            artifactBo.forgeLv = 0;
            card = new Artifact(artifactBo);
        }
        return card;
    }

    getCareerByGemStone(goodIndex: GoodId): number {
        let config = cm.getGoodConfig(goodIndex);
        return (config.effect - 1) % 3 + 1;
    }

    protected _equipChargeIconLv: number[][] = [];// 充能套装激活等级
    // 获取套装激活对应的充能等级
    public getEquipChargeOutFitIconLv(): number[][] {
        if (this._equipChargeIconLv.length == 0) {
            let outfitId: number = 0;
            for (let i = 0; i < equippowerConfig.length; i++) {
                let cfg = equippowerConfig[i];
                if (cfg.EqOutfitID > outfitId) {
                    this._equipChargeIconLv.push([cfg.EqOutfitID, cfg.EqPLv]);
                    outfitId = cfg.EqOutfitID;
                }
            }
        }
        return this._equipChargeIconLv;
    }

    getHeroConfig(cfg: Battle_heroConfig, withoutSkill?: boolean, defense?: boolean): rpgfight.HeroConfig {
        let json = JSON.stringify(cfg);
        let heroConfig = JSON.parse(json);
        let skillConfig = new rpgfight.SkillConfig(rpgfight.Config.getTriggerData(heroConfig.attackSkill.triggerTreeName));
        let skillConfigList: rpgfight.SkillConfig[] = [];
        let propertyNames = Object.getOwnPropertyNames(heroConfig.attackSkill);
        for (let objName of propertyNames) {
            skillConfig[objName] = heroConfig.attackSkill[objName];
        }
        if (!withoutSkill) {
            for (let skill of heroConfig.skillList) {
                let propertyNames = Object.getOwnPropertyNames(skill);
                let _skill = new rpgfight.SkillConfig(rpgfight.Config.getTriggerData(skill.triggerTreeName));
                for (let objName of propertyNames) {
                    _skill[objName] = skill[objName];
                }
                skillConfigList.push(_skill);
            }
        }
        let config = new rpgfight.HeroConfig(skillConfig, skillConfigList);
        propertyNames = Object.getOwnPropertyNames(heroConfig);
        for (let objName of propertyNames) {
            if (objName != "attackSkill" && objName != "skillList") {
                if (defense && objName == "battleTeam") {
                    config[objName] = heroConfig[objName] == 1 ? 0 : 1;
                } else {
                    config[objName] = heroConfig[objName];
                }
            }
        }
        return config;
    }

    public playAnimation(node: cc.Node, name: string, callback?: Function) {
        if (node) {
            let ani = node.getComponent(cc.Animation);
            if (ani) {
                ani.play(name, 0);
                ani.off('finished');
                ani.on('finished', () => {
                    ani.setCurrentTime(0, name);
                    if (callback) { callback(); }
                })
            } else {
                if (callback) { callback(); }
            }
        } else {
            if (callback) { callback(); }
        }
    }
}

let commonUtils = new CommonUtils();
export default commonUtils