import Hero from "../data/card/Hero";

export enum SystemId {
    /**主线副本 */
    PVE = 1,

    Tower = 2,
    Wuzhang = 3,
    Jixie = 4,
    Bianzhong = 5,
    Jiangshi = 6,
    Dungeon = 7,

    Material_1 = 8,
    Material_2 = 9,
    Material_3 = 10,
    Material_4 = 11,
    Material_5 = 12,
}

export enum StanceType {
    /**主线副本 */
    PVE = 1,

    /**竞技场 */
    PVP
}

export enum BattleType {
    /**
     * 试玩
     */
    Trail,

    /**
     * 关卡
     */
    PVE,

    /**
     * 竞技场
     */
    PVP,

    /**
     * 摩天楼
     */
    Tower,

    /**
     * 迷宫
     */
    Maze,

    /**
     * 工会狩猎
     */
    Hunt,

    /**
     * 夺宝奇兵
     */
    Treasure,

    /**
     * 世界Boss
     */
    WorldBoss,

    /**
     * 奇妙时空
     */
    WonderSpace = 12,

    /**
     * 高级竞技场
     */
    PVP_Senior = 13,

    /**
     * 材料副本
     */
    Material = 14,

    /**
     * 克隆副本
     */
    Clone = 15,

    /**
     * 公会争霸
     */
    UnionWar = 16,

    /**
     * 公会副本
     */
    UnionDungeon = 17,

    /**
     * 竞技场回放
     */
    PVP_PlayBack,

    /**
     * 高级竞技场回放
     */
    PVP_Senior_Record,

    /**
     * 回放
     */
    Record,

    /**
     * 切磋
     */
    Friend,

    /**
     * 测试
     */
    Test,

    /**
     * 地牢
     */
    Dungeon,

    /**
     * 挂机
     */
    Hangup,
}

export enum Goto {
    /**建筑详情界面 */
    BuildingInfo,

    /**阵容编辑界面 */
    EditTroop,

    /**英雄列表 */
    HeroList,

    /**章节完成界面 */
    ChapterPassed,

    /**国家解放界面 */
    CountryPassed,

    /**基因实验室 */
    Evolution,

    /**回到主界面 */
    MainScene,

    /**摩天楼重新挑战 */
    TowerFight,
}

let COLOR_WHITE = cc.Color.WHITE;
let COLOR_GREEN = cc.Color.GREEN;
let COLOR_BLUE = cc.Color.BLUE;
let COLOR_PURPLE = cc.color(128, 0, 128);
let COLOR_YELLOW = cc.Color.YELLOW;
let COLOR_RED = cc.Color.RED;
export let RankColors = {
    "white": COLOR_WHITE,
    "green": COLOR_GREEN,
    "blue": COLOR_BLUE,
    "purple": COLOR_PURPLE,
    "yellow": COLOR_YELLOW,
    "red": COLOR_RED
}

export let Storage = {
    WorldBossHurt: { Key: "world boss hurt", Default: 0 },
    LastLogin: { Key: "last login", Default: 0 },
    FirstFail: { Key: "first fail", Default: false },
    AutoSplit: { Key: "auto split hero", Default: false },
    AutoSkill: { Key: "auto battle skill", Default: false },
    SpeedX2: { Key: "auto battle speedx2", Default: false },
    GuideId: { Key: "guideId", Default: 1001 },
    Music: { Key: "music", Default: 1.0 },
    Sound: { Key: "sound", Default: 1.0 },
    DebugTroops: { Key: "debug_troops", Default: "" },
    ChatMsgCard: { Key: "chat msg card", Default: false },
    ChatMsgHero: { Key: "chat msg hero", Default: false },
    RecycleGuide: { Key: "recycle guide", Default: false },
    EvolutionGuide: { Key: "evolution guide", Default: false },
    FreeVideoTimestamp: { Key: "free video timestamp", Default: 0 },
    GuideStrongEquip: { Key: "guide strong equip", Default: false },
    GuideMergeEquip: { Key: "guide merge equip", Default: false },
    GuideStarEquip: { Key: "guide star equip", Default: false },
    GuideChargeEquip: { Key: "guide charge equip", Default: false },
    GuideSpeedX2: { Key: "guide speed x2", Default: false },
    LeftButtonsOpen: { Key: "left buttons open", Default: false },
    RightButtonsOpen: { Key: "right buttons open", Default: false },
    OnlineTime: { Key: "online time", Default: 0 },
    TenLottery: { Key: "ten lottery", Default: false },
    OnlineGuide: { Key: "online guide", Default: false },
    DungeonGuide: { Key: "dungeon guide", Default: false },
    DungeonGuideReward: { Key: "dungeon guide reward", Default: false },
    DungeonGuideFruit: { Key: "dungeon guide fruit", Default: false },
    DungeonGuideDoor: { Key: "dungeon guide door", Default: false },
    LastDungeonIn: { Key: "last dungeon in", Default: 0 },
    LastGeniusIn: { Key: "last genius in", Default: 0 },
    StoryProcess: { Key: "story process", Default: 0 },
    VipTipTimestamp: { Key: "vip tip timestamp", Default: 0 },
    ArtifactGuide: { Key: "artifact guide", Default: false },
    ArtifactForgeGuide: { Key: "artifact forge guide", Default: false },
    RedPackPos: { Key: "user_union_packpos", Default: "" },
    ArenaJuniorDefense: { Key: "arena junior defense", Default: false },
    ArenaSeniorDefense: { Key: "arena senior defense", Default: false },
    XsSenlinRead: { Key: "xuanshang senlin read", Default: false },
    XsFeixuRead: { Key: "xuanshang feixu read", Default: false },
    XsKuangdongRead: { Key: "xuanshang kuangdong read", Default: false },
    VideoIgnoreTip: { Key: 'video ignore tip', Default: false },
    LotteryVideoTs: { Key: 'lottery video ts', Default: 0 },
    UnlockHeroSchoolTs: { Key: 'unlock heroschool ts', Default: 0 },
    ZhuanPanRead: { Key: "zhuanpan read", Default: false },
    ShengXingGuide: { Key: "shengxing guide", Default: false },
    HeChengGuide: { Key: "hecheng guide", Default: false },
    RepalceIgnoreHero: { Key: 'replace ignore hero', Default: 0 },
    RaceTowerWipeTip: { Key: "race tower wipe tip", Default: false },
    LastVisitHome: { Key: "last visit home", Default: 0 },
    CloneGuide: { Key: "clone guide", Default: false },
    TreasureShopTs: { Key: "treasure shop ts", Default: 0 },
    LotteryFactionSelect: { Key: "lottery faction select", Default: Hero.Faction.Armed },
    ArenaReportTs: { Key: "arena report ts", Default: 0 },
    ArenaSeniorReportTs: { Key: "arena senior report ts", Default: 0 },
    FirstSupplyGuide: { Key: "first supply guide", Default: false },
    FirstSeniorSupplyGuide: { Key: "first senior supply guide", Default: false },
    SupplyUnlock: { Key: "supply unlock", Default: false },
    EquipMergeRankLimit: { Key: "equip merge rank limit", Default: 5 },
    ArenaSeniorLimitTime: { Key: "arena senior limit time", Default: 0 }
}

export enum AssignPre {
    Daily = 1000,
    Week = 2000,
    Main = 3000,
}

export enum TaskTypeId {
    PassMainMission = 3001,
}

export enum MainView {
    /**
     * 挑战
     */
    Base,

    /**
     * 家园
     */
    Home,

    /**
     * 出发
     */
    Battle,

    /**
     * 英雄
     */
    Hero,

    /**
     * 聊天
     */
    Chat
}

/**
 * 每日任务
 */
export enum DailyType {
    default = 0,

    /**
     * 首领挑战
     */
    fight_header = 1001,

    /**
     * 升级英雄
     */
    levelup_hero = 1002,

    /**
     * 装备强化
     */
    strong_equip = 1003,

    /**
     * 摩天大楼挑战
     */
    fight_tower = 1004,

    /**
     * 挂机战利品领取
     */
    hangup_reward = 1005,

    /**
     * 赠送友情点
     */
    send_friend = 1006,

    /**
     * 快速挂机
     */
    hangup_quick = 1007,

    /**
     * 召唤英雄
     */
    summon_hero = 1008,

    /**
     * 工会狩猎
     */
    fight_union = 1009,

    /**
     * 竞技场挑战
     */
    fight_arena = 1010,

    /**
     * 接受悬赏
     */
    task_xuanshang = 1011,

    /**
     * 商铺购买道具
     */
    buy_store = 1012,

    /**
     * 转盘
     */
    zhuanpan_go = 1013,
}

/**
 * 周任务
 */
export enum WeekType {
    default = 0,

    /**
     * 迷宫第一层boss
     */
    fight_maze_boss = 2001,

    /**
     * 迷宫商店购买道具或英雄
     */
    buy_maze_shop = 2002,

    /**
     * 进阶英雄
     */
    advance_hero = 2003,

    /**
     * 召唤英雄
     */
    summon_hero = 2004,

    /**
     * 迷宫第三层boss
     */
    fight_maze_bossex = 2005,

    /**
     * 商店购买
     */
    buy_shop = 2006,

    /**
     * 工会商店购买装备
     */
    buy_equip_unionshop = 2007,

    /**
     * 竞技场胜利
     */
    win_arena = 2008,

    /**
     * 接受悬赏
     */
    task_xuanshang = 2009,

    /**
     * 阵营抽卡
     */
    faction_summon_hero = 2010,

    /**
     * 花房升星
     */
    evolution_hero = 2011,

    /**
     * 挑战资源副本
     */
    fight_mat = 2012,

    /**
     * 赠送好友友情点
     */
    send_friendship = 2013,
}

/**
 * 主线任务
 */
export enum MainType {
    default = 0,

    /**
     * 关卡通关
     */
    mission_complete = 1,

    /**
     * 迷宫第三层通关
     */
    maze_complete = 2,

    /**
     * 摩天大楼通关
     */
    tower_complete = 3,

    /**
     * 战队等级
     */
    level_team = 4,

    /**
     * 英雄等级
     */
    level_hero = 5,

    /**
     * 章节通关
     */
    chapter_complete = 6,

    /**
     * 竞技场胜利
     */
    win_arena = 7,

    /**
     * 共享等级
     */
    level_share = 8,

    /**
     * 四族高塔等级
     */
    level_raceTower = 9,

    /**
     * 账号绑定
     */
    account_bind = 10,

    /**
     * 竞技场积分
     */
    score_arena = 11,

    /**
     * 累积获得英雄个数
     */
    num_hero = 12,

    /**
     * 挂机获得金币
     */
    hangup_gold = 13,

    /**
     * 累积获得紫色品质英雄个数
     */
    num_purpleHero = 14,
}

/**
 * 排行榜类型
 */
export enum HonorRankType {
    /**
     * 武装排名
     */
    race_wuzhuang = 1,

    /**
     * 机械排名
     */
    race_jixie = 2,

    /**
     * 变种排名
     */
    race_bianzhong = 3,

    /**
     * 超能排名
     */
    race_chaoneng = 4,

    /**
     * 通关排名
     */
    mission = 5,

    /**
     * 摩天楼排名
     */
    tower = 6,

    /**
     * 战斗力排名
     */
    power = 9,
}

export enum DunRankType {
    Union_Contribution = 1,
    Union_Battle = 2,
}

export enum UdgDiff {
    Easy = 1,
    Normal = 2,
    Hard = 3,
    Max = 4,
}

/**
 * 七日任务
 */
export enum SevenDayTaskType {
    /**
     * 分解普通英雄
     */
    split_hero = 4001,

    /**
     * 召唤精英品质以上英雄
     */
    call_hero = 4002,

    /**
     * 商店购买
     */
    buy_shop = 4003,

    /**
     * 赠送友情点
     */
    send_friendship = 4004,

    /**
     * 获取日常任务点数
     */
    get_dailytask_point = 4005,

    /**
     * 完成章节
     */
    chapter_complete = 4006,

    /**
     * 参与公会狩猎
     */
    union_hunt = 4007,

    /**
     * 提升装备强化等级
     */
    upgrade_equip = 4008,

    /**
     * 竞技场挑战次数
     */
    arena_challenge = 4009,

    /**
     * 悬赏任务完成
     */
    xstask_complete = 4010,

    /**
     * 智慧树中击败敌人
     */
    tree_defeat_cnt = 4011,

    /**
     * 使用快速挂机
     */
    use_fast_hangup = 4012,

    /**
     * 最低等级英雄等级达到
     */
    hero_level_reachat = 4013,

    /**
     * 进阶英雄
     */
    evolution_hero = 4014,

    /**
     * 共享花坛上阵英雄达到
     */
    share_hero = 4015
}

/**
 * 充值项类型
 */
export enum StoreType {
    /**
     * 钻石
     */
    Diamond = 1,

    /**
     * 普通月卡
     */
    NormalMonth = 2,

    /**
     * 超级月卡
     */
    SuperMonth = 3,

    /**
     * 成长礼包
     */
    Growup = 4,

    /**
     * 新手礼包
     */
    NewPlayer = 5,

    /**
     * 惊喜礼包
     */
    Surprise = 6,

    /**
     * 活跃礼包
     */
    Active = 7,

    /**
     * 智慧树礼包
     */
    Wisdom = 8,

    /**
     * 日礼包
     */
    Daily = 9,

    /**
     * 周礼包
     */
    Weekly = 10,

    /**
     * 月礼包
     */
    Month = 11,

    /**
     * 活动礼包 - 夺宝 棋盘 探趣
     */
    ActivityGift = 12,

    /**
     * 净化先锋礼物
     */
    JinhuaXianfeng = 13,

    /**
     * 新手基金
     */
    SevenFund = 14,
}

export enum ZhuanPanType {
    Normal = 1,
    Better = 2,
}

export let VideoKey = {
    DailyTask: "日常任务奖励翻倍",
    XsComplete: "悬赏任务快速完成",
    XsFresh: "悬赏任务免费刷新",
    QuickHangup: "快速挂机",
    WisdomTree: "智慧树复活英雄",
    Shop: "商店免费购买",
    CallHero: "视频抽卡",
    TehuiGift: "特惠礼包",
    ChessDice: "棋盘骰子",
    WonderSpace: "奇妙时空复活英雄",
    StatuePart: "雕像铸造",
    ZhuanPan: "转盘",
}

export let EventGroup = {
    Chess: "棋盘寻宝",
    Promotion: "超值促销",
    UserLevel: "玩家等级",
    ZhuanPanNormal: "普通转盘",
    ZhuanPanBetter: "高级转盘",
    ZhuanPanShop: "转盘商店",
}

export let ZhuanPanEvent = {
    fresh: "刷新",
    once: "单抽",
    ten: "10连抽",
    hero: "紫英雄",
    artifact: "神器",
    buy: "购买",
    normalCoinBuy: "购买币"
}

export let RewardType = {
    equip: "equip",
    good: "goods",
    hero: "hero",
}

export let CommonAdd = {
    statuePart1: 'StatueModul_1',
    statuePart2: 'StatueModul_2',
    statuePart3: 'StatueModul_3',
    library: 'FetterModul'
}

export let AdvEffectName = {
    levelUp: 'Levelupitem',
    recast: 'EquipAdvancePanelCZ'
}

export enum EvolutionType {
    Evolution = 1,
    EquipMerge,           // 修改为装备合成
    Merge,
    Star
}

export enum AdvanceType {
    Upgrade = 1,
    Star,
    Charging,
    Recast,
}

/**
 * 充值表ID
 */
export enum StoreId {
    MonthOrder = 323,
}

/**
 * yuekaconfig id
 */
export enum YueKaType {
    normal = 1,
    super = 2,
    week = 3,
    life = 4,
}

export enum DutyType {
    /**
     * 输出
     */
    Atk = 1,

    /**
     * 辅助
     */
    Help = 2,

    /**
     * 坦克
     */
    Tank = 3,

    /**
     * 控制
     */
    Control = 4,
}

export let HeroQualityTitle = {
    1: 'N',
    2: 'SR',
    3: 'SSR',
    4: 'UR',
}

export let CampBonusName = {
    1: '武装联盟',
    2: '机械联盟',
    3: '变种联盟',
    4: '僵尸联盟',
    5: '超能联盟',
    6: '毁灭联盟',
}

export enum TaskActivityType {
    GetLottery = 1,
    ZhuanPanNormal = 2,
    ZhuanPanBetter = 3,
    LevelUp = 4,
    EvoUp = 5,
    JoinArena = 6,
    ArenaWin = 7,
    JoinSeniorArena = 8,
    SeniorArenaWin = 9,
    BuyArenaTicket = 10,
    BuySeniorTicket = 11,
    JoinWisdomTree = 12,
    DefeatWisdom = 13,
    RefreshXuanShang = 14,
    CompleteXSTask = 15,
    GetFactionSR = 16,
    GetFactionSSR = 17,
    GetFactionUR = 18,
    GetUnionLottery = 19,
    GetDiffFactionSR = 20,
    GetDiffFactionSSR = 21,
    GetDiffFactionUR = 22,
    GetFactionQualityHero = 23,
    StarHero = 24,
}

export enum MedalTechTab {
    /**
     * 总览
     */
    Total = 0,

    /**
     * 基础研习
     */
    Base = 1,

    /**
     * 联盟研习
     */
    Faction = 2,

    /**
     * 职责研习
     */
    Duty = 3,

    /**
     * 大师研习
     */
    Master = 4,
}