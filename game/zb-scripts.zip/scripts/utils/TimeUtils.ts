import chatSocket from "../socket/ChatSocket";

/**
 * 时间格式化工具
 */
class TimeUtils {
    formatTime(time: number) {
        let lastTime = time;
        let hour = Math.floor(time / 3600);
        lastTime -= hour * 3600;
        let hourStr = `${hour}`;
        if (hourStr.length == 1) {
            hourStr = `0${hourStr}`;
        }
        let minute = Math.floor(lastTime / 60);
        lastTime -= minute * 60;
        let minuteStr = `${minute}`;
        if (minuteStr.length == 1) {
            minuteStr = `0${minute}`;
        }
        let second = Math.floor(lastTime);

        let str = `${second}`;
        if (str.length == 1) {
            str = `0${second}`;
        }

        return `${hourStr}:${minuteStr}:${str}`;
    }

    formatTimeToStr(timestamp: number, ignoreYear: boolean = false) {
        let date = new Date(timestamp);
        let str = "";
        str = ignoreYear ? "" : `${date.getFullYear()}/`;

        let month = date.getMonth() + 1;
        str += this._getFormatStr(month, `/`);

        let day = date.getDay();
        str += this._getFormatStr(day, ``);

        str += "  ";
        str += this._getFormatStr(date.getHours(), `:`);
        str += this._getFormatStr(date.getMinutes(), `:`);
        str += this._getFormatStr(date.getSeconds(), ``);
        return str;
    }

    formatTimeToStr1(timestamp: number, ignoreYear: boolean = false) {
        let date = new Date(timestamp);
        let str = "";
        str = ignoreYear ? "" : `${date.getFullYear()}.`;

        let month = date.getMonth() + 1;
        str += this._getFormatStrEx(month, `.`);

        let day = date.getDay();
        str += this._getFormatStrEx(day, ``);

        str += "  ";
        str += this._getFormatStr(date.getHours(), `:`);
        str += this._getFormatStr(date.getMinutes(), ``);
        //str += this.getFormatStr(date.getSeconds(), ``);
        return str;
    }

    formatTimeToStr2(timestamp: number) {
        let date = new Date(timestamp);
        let str = "";
        str = `${date.getFullYear()}`;

        let month = date.getMonth() + 1;
        if (month < 10) {
            str += `0${month}`;
        } else {
            str += `${month}`;
        }
        let day = date.getDay();
        if (day < 10) {
            str += `0${day}`;
        } else {
            str += `${day}`
        }
        return str;
    }

    private _getFormatStr(num: number, ex: string): string {
        if (num < 10) {
            return `0${num}` + ex;
        } else {
            return `${num}` + ex;
        }
    }
    private _getFormatStrEx(num: number, ex: string): string {
        return `${num}` + ex;
    }

    formatDay(diffTime: number, showMinute: boolean = false, simple: boolean = false) {
        let hour = diffTime / 1000 / 3600;
        let day = Math.floor(hour / 24);
        let lastHour = hour;
        if (day > 0) {
            lastHour = hour - day * 24;
        }
        let str = "";
        if (day > 0) {
            str = `${day}天`;
        }
        if (Math.floor(lastHour) > 0) {
            str += `${Math.floor(lastHour)}小时`;
        }
        if (simple) {
            if (day <= 0) {
                if (Math.floor(lastHour) <= 0) {
                    str = "";
                } else {
                    str = `${Math.floor(lastHour)}小时`;
                }
            }
        }
        if (showMinute) {
            let minute = (lastHour * 60) % 60;
            if (minute < 1) {
                str += `${Math.ceil(minute)}分`;
            }
            else {
                str += `${Math.floor(minute)}分`;
            }
        }
        return str;
    }

    formatDaySecond(diffTime: number) {
        let hour = diffTime / 1000 / 3600;
        let day = Math.floor(hour / 24);
        let lastHour = hour;
        if (day > 0) {
            lastHour = hour - day * 24;
        }
        let str = "";
        if (day > 0) {
            str = `${day}天`;
        }
        if (Math.floor(lastHour) > 0) {
            str += `${Math.floor(lastHour)}小时`;
        }
        let minute = (lastHour * 60) % 60;
        if (Math.floor(minute) > 0) {
            str += `${Math.floor(minute)}分`;
        }
        let second = lastHour * 3600 % 60;
        str += `${Math.floor(second)}秒`;
        return str;
    }

    formatRecordDay(diffTime: number) {
        let hour = diffTime / 1000 / 3600;
        let day = Math.floor(hour / 24);
        let lastHour = hour;
        if (day > 0) {
            return `${day}天前`;
        }
        if (Math.floor(lastHour) > 0) {
            return `${Math.floor(lastHour)}小时前`;
        }
        let minute = Math.floor((lastHour * 60) % 60);
        if (minute > 0) {
            return `${minute}分钟前`;
        }
        let second = Math.floor((lastHour * 3600) % 60);
        return `${second}秒前`;
    }

    formatToBetweenString(time: number, diffTime: number, limit: number = 0) {
        let dataStr = "";
        if (diffTime > limit) {
            let serverDate = new Date(chatSocket.getCurrentTimestamp());
            serverDate.setHours(0);
            serverDate.setMinutes(0);
            serverDate.setSeconds(0);
            serverDate.setMilliseconds(0);

            let msgDate = new Date(time);
            msgDate.setHours(0);
            msgDate.setMinutes(0);
            msgDate.setSeconds(0);
            msgDate.setMilliseconds(0);

            let date = new Date(time);
            let minute = date.getMinutes().toString();
            if (minute.length == 1) {
                minute = `0${minute}`;
            }
            let hourStr = date.getHours().toString();
            if (hourStr.length == 1) {
                hourStr = `0${hourStr}`;
            }
            let timeStr = `${hourStr}:${minute}`;

            let diffTime2 = serverDate.getTime() - msgDate.getTime();
            let hour = diffTime2 / 1000 / 3600;
            if (hour == 0) {
                dataStr = timeStr;
            } else if (hour <= 24) {
                dataStr = "昨天 " + timeStr;
            } else {
                dataStr = new Date(time).format("yyyy-MM-dd");
            }
        }
        return dataStr;
    }

    printNowTimeSec() {
        let date = new Date();
        console.log(`NowTime: ${date.getMinutes()}:${date.getSeconds()}:${date.getMilliseconds()}`);
    }
}

let timeUtils = new TimeUtils();
export default timeUtils;