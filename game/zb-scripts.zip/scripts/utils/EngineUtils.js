cc._compat_2_0_8 = true

let func1 = cc.Animation.prototype._init;
cc.Animation.prototype["_initEx"] = function () {
    if (this._didInit) {
        return;
    }

    func1.call(this);

    let animator = this._animator;
    let func = animator.playState;
    animator.playState = function (state, startTime) {
        for (let curve of state.curves) {
            if (curve.__classname__ == 'cc.DynamicAnimCurve') {
                if (curve.prop == 'x' || curve.prop == 'y' || curve.prop == 'position') {
                    if (curve.values) {
                        if (curve.values.length > 0) {
                            if (curve.prop == 'position') {
                                let offset = new cc.Vec2(-curve.values[0].x, -curve.values[0].y);
                                if (curve.values.length > 1) {
                                    for (let i = 1; i < curve.values.length; i++) {
                                        curve.values[i].x += curve.target[curve.prop].x + offset.x;
                                        curve.values[i].y += curve.target[curve.prop].y + offset.y;
                                    }
                                }
                            }
                            else {
                                let offset = -curve.values[0];
                                if (curve.values.length > 1) {
                                    for (let i = 1; i < curve.values.length; i++) {
                                        curve.values[i] += curve.target[curve.prop] + offset;
                                    }
                                }
                            }
                            curve.values[0] = curve.target[curve.prop];
                        }
                    }
                }
            }
        }
        func.call(animator, state, startTime);
    }
}

let func2_handleTouchesBegin = _cc.inputManager.handleTouchesBegin;
let func2_handleTouchesMove = _cc.inputManager.handleTouchesMove;
let func2_handleTouchesEnd = _cc.inputManager.handleTouchesEnd;
let func2_handleTouchesCancel = _cc.inputManager.handleTouchesCancel;
let s_touch = null;
_cc.inputManager.handleTouchesBegin = function (touches) {
    if (s_touch) return;
    s_touch = touches[0];
    func2_handleTouchesBegin.call(_cc.inputManager, [touches[0]]);
};
_cc.inputManager.handleTouchesMove = function (touches) {
    for (let touch of touches) {
        if (s_touch && s_touch.getID() == touch.getID()) {
            func2_handleTouchesMove.call(_cc.inputManager, [touch]);
            break;
        }
    }
}
_cc.inputManager.handleTouchesEnd = function (touches) {
    for (let touch of touches) {
        if (s_touch && s_touch.getID() == touch.getID()) {
            func2_handleTouchesEnd.call(_cc.inputManager, [touch]);
            s_touch = null;
            break;
        }
    }
};
_cc.inputManager.handleTouchesCancel = function (touches) {
    for (let touch of touches) {
        if (s_touch && s_touch.getID() == touch.getID()) {
            func2_handleTouchesCancel.call(_cc.inputManager, [touch]);
            s_touch = null;
            break;
        }
    }
};

let LayerType = gcc.LayerType;
let LayerData = gcc.LayerData;
gcc.Core.prototype.showLayer = function (url, params) {
    if (params === undefined) params = {};
    var { data, modalWindow, layer, single, cache, modalTouch, callback } = params;

    if (modalWindow === undefined) modalWindow = true;
    if (single === undefined) single = true;
    if (layer === undefined) layer = LayerType.FLOAT;

    if (cache && (layer == LayerType.FLOAT || layer == null)) {
        //we set layertype to float as default for cache 
        layer = layer ? layer || layer : LayerType.FLOAT
        if (this.getLayerCount(layer) > 0) {
            console.warn(`${url} cached`);
            let cachedInfo = {
                url: url,
                data: {
                    data: data,
                    modalWindow: modalWindow,
                    layer: layer,
                    single: single,
                    cache: cache,
                    modalTouch: modalTouch,
                    callback: callback
                }
            }
            this._cachedLayer.push(cachedInfo)
            return
        }
    }

    if (url == "prefabs/panel/hero/HeroInfoPanel") {
        single = false;
    }

    let index = this.showLoading(url)

    //创建图层信息
    let layerData = new LayerData(null, data, null, layer, url)
    this._layerList.push(layerData)

    let loadRes = () => {
        cc.loader.loadRes(url, (err, prefab) => {
            if (layerData.isCancel) {
                this.closeLoading(index, url);
                return;//已经被取消
            }

            if (err || !prefab || prefab instanceof cc.Prefab == false) {
                // log.error("can not load prefab ", url, err);
                this.closeLoading(index, url);

                this.resLoadRetry(() => {
                    loadRes();
                })
                return
            }

            this.showLayerPrefab(layerData, prefab, data, modalWindow, layer, url, modalTouch, (l) => {
                console.warn(`show layer:${url}`);
                this.closeLoading(index, url);
                if (callback) { callback(l); }
                this.emit(gcc.Core.LayerChange);
            }, single);
        })
    }
    loadRes()
}

gcc.Core.prototype.showLayerPrefab = async function (layerData, prefab,
    data, modalWindow,
    layer, url,
    modalTouch, callback, single) {
    if (modalWindow === undefined) modalWindow = true;
    if (layer === undefined) layer = LayerType.FLOAT;

    var node = null;
    if (single) {
        node = prefab.data;
        node._onBatchRestored();
    }
    else {
        node = cc.instantiate(prefab);
    }
    node.single = single;

    var dialogComp = node.getComponent(gcc.Dialog);
    var closeFunc = dialogComp.close;
    dialogComp.close = () => {
        if (dialogComp._unloadRes) {
            dialogComp._unloadRes(prefab);
        }
        closeFunc.call(dialogComp);
    }

    var size = cc.winSize;
    if (modalWindow) {
        var bg = new cc.Node("modalBg");
        bg.setContentSize(size.width, size.height)
        bg.color = cc.Color.BLACK;
        bg.opacity = 200;
        bg.addComponent(cc.BlockInputEvents);
        node.addChild(bg, -1);

        var sprite = bg.addComponent(cc.Sprite);
        sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
        sprite.spriteFrame = new cc.SpriteFrame(this.bgTexture);

        if (modalTouch) {
            bg.once(cc.Node.EventType.TOUCH_END, () => {
                dialogComp.close();
            })
        }
    }

    if (dialogComp && dialogComp.allowModifyPosition) {
        //使用编辑器中默认坐标
        node.setPosition((size.width) / 2 + node.x, (size.height) / 2 + node.y)//偏移半个屏幕，使其在中间
    } else {
        node.setPosition((size.width) / 2, (size.height) / 2)//强制居中
    }

    //绑定数据
    if (dialogComp) {
        dialogComp.data = data
        dialogComp.onInit(data);
        if (dialogComp._preloadRes) {
            await dialogComp._preloadRes();
        }
    }

    switch (layer) {
        case gcc.LayerType.FLOAT:
            this._floatLayer.addChild(node, dialogComp.getZIndex())
            break
        case gcc.LayerType.INFO:
            this._infoLayer.addChild(node, dialogComp.getZIndex())
            break
        case gcc.LayerType.DEBUG:
            this._debugLayer.addChild(node, dialogComp.getZIndex())
            break
    }
    dialogComp.layerType = layer;

    //入场动画
    dialogComp.playEnterAnimation(() => { })

    layerData["_node"] = node
    layerData["_prefab"] = prefab

    if (callback) {
        callback(layerData);
    }

    return layerData;
}

gcc.Core.prototype.toast = function (text, _a) {
    gm.toast(text);
};

let updateChild = function () {
    if (!this._supportSlotNode) {
        return
    }

    let slotNames = [];
    if (this.skeletonData && this.skeletonData.skeletonJson) {
        let slots = this.skeletonData.skeletonJson.slots;
        for (let slot of slots) {
            slotNames.push(slot.name);
        }
    }

    for (let name of slotNames) {
        let child = this.node.getChildByName('*' + `${name}`.replace('/', '_'));
        if (!child) {
            continue;
        }

        let slot = this.findSlot(name);
        if (!slot) {
            continue;
        }
        let nodeColor = {
            r: this.node.color.r / 255,
            g: this.node.color.g / 255,
            b: this.node.color.b / 255,
            a: this.node.color.a / 255
        }
        let bone = slot.bone;
        let color = { r: 1, g: 1, b: 1, a: 1 };
        let slotColor = {};
        if (CC_JSB && slot.color == undefined) {
            slotColor = {
                r: slot.r,
                g: slot.g,
                b: slot.b,
                a: slot.a
            }
        }
        else {
            slotColor = {
                r: slot.color.r,
                g: slot.color.g,
                b: slot.color.b,
                a: slot.color.a
            }
        }

        let multiplier = this.premultipliedAlpha ? slotColor.a * 255 : 255;
        child.color = cc.color(
            color.r * nodeColor.r * slotColor.r * multiplier,
            color.g * nodeColor.g * slotColor.g * multiplier,
            color.b * nodeColor.b * slotColor.b * multiplier,
            255
        )
        child.opacity = color.a * nodeColor.a * slotColor.a * 255;
        child.setPosition(bone.worldX, bone.worldY);
        if (!child.noScale) child.setScale(bone.scaleX, bone.scaleY);
        child.rotation = -bone.rotation;

        if (!this._drawOrigionAttachmentForce) {
            if (slot.attachment) {
                this.setAttachment(name, null);
            }
        }
    }
}

let sp_skeleton_onLoad = sp.Skeleton.prototype.onLoad;
sp.Skeleton.prototype.onLoad = function () {
    if (sp_skeleton_onLoad) sp_skeleton_onLoad.call(this);
    updateChild.call(this);
}

let sp_skeleton_update = sp.Skeleton.prototype.update;
sp.Skeleton.prototype.update = function (dt) {
    updateChild.call(this);
    if (sp_skeleton_update) sp_skeleton_update.call(this, dt);
}

cc.Asset.prototype.lock = function () {
    if (typeof this._lock == "number") {
        this._lock++;
    }
    else {
        this._lock = 1;
    }
}

cc.Asset.prototype.unlock = function () {
    if (typeof this._lock == "number") {
        this._lock = Math.max(0, this._lock - 1);
    }
}

cc.Asset.prototype.isLock = function () {
    return typeof this._lock == "number" && this._lock > 0;
}

let cc_button_onenable = cc.Button.prototype.onEnable;
cc.Button.prototype.onEnable = function () {
    cc_button_onenable.call(this);
    this._enableTimetamp = new Date().getTime();
}

let cc_button_ontouchbegan = cc.Button.prototype._onTouchBegan;
cc.Button.prototype._onTouchBegan = function (event) {
    if (new Date().getTime() - this._enableTimetamp < 200) {
        return;
    }
    cc_button_ontouchbegan.call(this, event);
}

cc.Button.prototype._onTouchEnded = function (event) {
    if (!this.interactable || !this.enabledInHierarchy) return;

    if (this._pressed) {
        this.node.emit('pre-click', this);
        this.node.emit('click', this);
        cc.Component.EventHandler.emitEvents(this.clickEvents, event);

        if (!this.getComponent(window['ButtonAudio'])) {
            window['am'].playEffect("button");
        }
    }
    this._pressed = false;
    this._updateState();
    event.stopPropagation();
}

cc.ScrollView.prototype._scrollChildren = function (deltaMove) {
    let delta = deltaMove.clone();
    deltaMove = this._clampDelta(deltaMove);

    let realMove = deltaMove;
    let outOfBoundary;
    if (this.elastic) {
        outOfBoundary = this._getHowMuchOutOfBoundary();
        realMove.x *= (outOfBoundary.x === 0 ? 1 : 0.5);
        realMove.y *= (outOfBoundary.y === 0 ? 1 : 0.5);
    }

    if (!this.elastic) {
        outOfBoundary = this._getHowMuchOutOfBoundary(realMove);
        realMove = realMove.add(outOfBoundary);
    }

    let scrollEventType = -1;

    if (realMove.y > 0 || delta.y > 0) { //up
        let icBottomPos = this.content.y - this.content.anchorY * this.content.height;

        if (icBottomPos + realMove.y >= this._bottomBoundary) {
            scrollEventType = 'scroll-to-bottom';
        }
    }
    else if (realMove.y < 0 || delta.y < 0) { //down
        let icTopPos = this.content.y - this.content.anchorY * this.content.height + this.content.height;

        if (icTopPos + realMove.y <= this._topBoundary) {
            scrollEventType = 'scroll-to-top';
        }
    }
    if (realMove.x < 0 || delta.x < 0) { //left
        let icRightPos = this.content.x - this.content.anchorX * this.content.width + this.content.width;
        if (icRightPos + realMove.x <= this._rightBoundary) {
            scrollEventType = 'scroll-to-right';
        }
    }
    else if (realMove.x > 0 || delta.x > 0) { //right
        let icLeftPos = this.content.x - this.content.anchorX * this.content.width;
        if (icLeftPos + realMove.x >= this._leftBoundary) {
            scrollEventType = 'scroll-to-left';
        }
    }

    this._moveContent(realMove, false);

    if (realMove.x !== 0 || realMove.y !== 0) {
        if (!this._scrolling) {
            this._scrolling = true;
            this._dispatchEvent('scroll-began');
        }
        this._dispatchEvent('scrolling');
    }

    if (scrollEventType !== -1) {
        this._dispatchEvent(scrollEventType);
    }

}

cc.Label.prototype._activateMaterialWebgl = function (force) {
    if (!force) return;


    // If frame not create, disable render and return.
    if (!this._frame) {
        this.disableRender();
        return;
    }

    // Label's texture is generated dynamically,
    // we should always get a material instance for this label.
    let material = this.sharedMaterials[0];

    if (!material) {
        material = cc.Material.getInstantiatedBuiltinMaterial('2d-sprite', this);
    }
    else {
        material = cc.Material.getInstantiatedMaterial(material, this);
    }

    material.setProperty('texture', this._frame._texture);
    if (material.name.startsWith("font-")) {
        material.effect.setBlend(
            true,
            cc.macro.BlendFactor.BLEND_FUNC_ADD,
            cc.macro.BlendFactor.SRC_ALPHA, cc.macro.BlendFactor.ONE_MINUS_SRC_ALPHA,
            cc.macro.BlendFactor.BLEND_FUNC_ADD,
            cc.macro.BlendFactor.SRC_ALPHA, cc.macro.BlendFactor.ONE_MINUS_SRC_ALPHA
        );
    }
    else {
        if (CC_JSB && (cc.sys.os == cc.sys.OS_IOS || cc.sys.os == cc.sys.OS_WINDOWS)) {
            if (this.font instanceof cc.BitmapFont) {
                material.effect.setBlend(
                    true,
                    cc.macro.BlendFactor.BLEND_FUNC_ADD,
                    cc.macro.BlendFactor.ONE, cc.macro.BlendFactor.ONE_MINUS_SRC_ALPHA,
                    cc.macro.BlendFactor.BLEND_FUNC_ADD,
                    cc.macro.BlendFactor.ONE, cc.macro.BlendFactor.ONE_MINUS_SRC_ALPHA
                );
            }
            else {
                material.effect.setBlend(
                    true,
                    cc.macro.BlendFactor.BLEND_FUNC_ADD,
                    cc.macro.BlendFactor.SRC_ALPHA, cc.macro.BlendFactor.ONE_MINUS_SRC_ALPHA,
                    cc.macro.BlendFactor.BLEND_FUNC_ADD,
                    cc.macro.BlendFactor.SRC_ALPHA, cc.macro.BlendFactor.ONE_MINUS_SRC_ALPHA
                );
            }
        }
        else {
            material.effect.setBlend(
                true,
                cc.macro.BlendFactor.BLEND_FUNC_ADD,
                cc.macro.BlendFactor.ONE, cc.macro.BlendFactor.ONE_MINUS_SRC_ALPHA,
                cc.macro.BlendFactor.BLEND_FUNC_ADD,
                cc.macro.BlendFactor.ONE, cc.macro.BlendFactor.ONE_MINUS_SRC_ALPHA
            );
        }
    }
    this.setMaterial(0, material);

    this.markForUpdateRenderData(true);
    this.markForRender(true);
}

let destroyAllChildren = cc.Node.prototype.destroyAllChildren;
cc.Node.prototype.destroyAllChildren = function () {
    destroyAllChildren.call(this);
    this.removeAllChildren();
}

if (CC_JSB) {
    let httpClient = new slib.HttpClient();
    let reportError = function (error) {
        let data = {
            level: "ERROR",
            appId: gssdk.info.appId,
            instanceId: "com.glee.zombie2",
            userId: gssdk.loginData.roleId,
            deviceId: gssdk.deviceId,
            message: {
                msg: error.message,
                trace: error.stack
            },
            component: "JSError"
        }
        httpClient.request({
            method: "POST",
            headMap: {
                'Content-Type': "application/json;charset=utf-8"
            },
            url: "https://logweb.mosoga.net/logweb/post",
            data: JSON.stringify(data)
        });
    }

    let totalErrors = new Set();
    window.errorCatch = function (error) {
        if (error.stack === undefined) {
            return;
        }
        if (totalErrors.has(error.stack)) {
            return;
        }
        totalErrors.add(error.stack);
        console.error(error);
        if (gssdk.checkFeature('commit_error')) {
            reportError(error);
        }
    }

    cc.Pipeline.Downloader.prototype.handle = function (item, callback) {
        var self = this;
        var downloadFunc = this.extMap[item.type] || this.extMap["default"];
        var syncRet = void 0;
        if (this._curConcurrent < cc.macro.DOWNLOAD_MAX_CONCURRENT) {
            this._curConcurrent++;
            syncRet = downloadFunc.call(this, item, (function (err, result) {
                self._curConcurrent = Math.max(0, self._curConcurrent - 1);
                if (err) {
                    setTimeout(function () { self.handle(item, callback); }, 100);
                    return;
                }
                self._handleLoadQueue();
                callback && callback(err, result);
            }));
            if (void 0 !== syncRet) {
                this._curConcurrent = Math.max(0, this._curConcurrent - 1);
                this._handleLoadQueue();
                return syncRet;
            }
        } else if (item.ignoreMaxConcurrency) {
            syncRet = downloadFunc.call(this, item, callback);
            if (void 0 !== syncRet) return syncRet;
        } else this._loadQueue.push({
            item: item,
            callback: callback
        });
    }
}