/**
 * 计算工具类
 */
class MathUtils {
    /**
     * 相加
     * @param a 
     * @param b 
     */
    add(a: number, b: number) {
        let c: number, d: number, e: number;
        try {
            c = a.toString().split(".")[1].length;
        } catch (f) {
            c = 0;
        }
        try {
            d = b.toString().split(".")[1].length;
        } catch (f) {
            d = 0;
        }
        return e = Math.pow(10, Math.max(c, d)), (this.mul(a, e) + this.mul(b, e)) / e;
    }

    /**
     * 相减
     * @param a 
     * @param b 
     */
    sub(a: number, b: number) {
        let c: number, d: number, e: number;
        try {
            c = a.toString().split(".")[1].length;
        } catch (f) {
            c = 0;
        }
        try {
            d = b.toString().split(".")[1].length;
        } catch (f) {
            d = 0;
        }
        return e = Math.pow(10, Math.max(c, d)), (this.mul(a, e) - this.mul(b, e)) / e;
    }

    /**
     * 相乘
     * @param a 
     * @param b 
     */
    mul(a: number, b: number) {
        let c = 0,
            d = a.toString(),
            e = b.toString();
        try {
            c += d.split(".")[1].length;
        } catch (f) { }
        try {
            c += e.split(".")[1].length;
        } catch (f) { }
        return Number(d.replace(".", "")) * Number(e.replace(".", "")) / Math.pow(10, c);
    }

    /**
     * 相除
     * @param a 
     * @param b 
     */
    div(a: number, b: number) {
        let c: number, d: number, e = 0,
            f = 0;
        try {
            e = a.toString().split(".")[1].length;
        } catch (g) { }
        try {
            f = b.toString().split(".")[1].length;
        } catch (g) { }
        return c = Number(a.toString().replace(".", "")), d = Number(b.toString().replace(".", "")), this.mul(c / d, Math.pow(10, f - e));
    }

    /**
     * 角度转弧度
     * @param deg 
     */
    rad(deg: number): number {
        return deg * Math.PI / 180;
    }

    /**
     * 弧度转角度
     * @param rad 
     */
    deg(rad: number): number {
        return rad * 180 / Math.PI;
    }

    /**
     * 随机
     * @param start 起始
     * @param end 结束（不包含）
     * @param isInt 是否随机整数
     */
    random(start: number, end: number, isInt: boolean = true) {
        let value = start + Math.random() * (end - start);
        if (isInt) {
            value = Math.round(value);
        }
        return value;
    }

    /**
     * 从数组中随机抽取一组数据
     * @param arr 
     * @param count 
     */
    randomPickup<T>(arr: T[], count: number): T[] {
        let picks: T[] = [];
        for (let i = 0; i < count; i++) {
            if (arr.length == 0) {
                break;
            }

            let index = Math.floor(Math.random() * arr.length);
            let value = arr[index];
            arr.splice(index, 1);
            picks.push(value);
        }
        return picks;
    }

    /**
     * 根据权重随机
     * @param weight 
     */
    randomByWeight(weight: number[]) {
        let total = 0;
        for (let i = 0; i < weight.length; i++) {
            total += weight[i];
        }
        let randomValue = Math.random() * total;
        let lastValue = 0;
        for (let i = 0; i < weight.length; i++) {
            if (randomValue >= lastValue && randomValue < weight[i]) {
                return i;
            }
            lastValue += weight[i];
        }
        return weight.length - 1;
    }
}

let mathUtils = new MathUtils();
export default mathUtils;