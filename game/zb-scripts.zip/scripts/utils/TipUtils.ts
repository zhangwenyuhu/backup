import CommonTip from "../view/component/CommonTip";
import loadUtils from "./LoadUtils";

class TipUtils {

    protected _tipNode: cc.Node = null;

    async showTip(node: cc.Node, desc: string) {
        this.destroyTip();
        if (!this._tipNode) {
            try {
                let prefab = cc.loader.getRes("prefabs/common/common_tip", cc.Prefab);
                if (!prefab) {
                    prefab = await loadUtils.loadRes("prefabs/common/common_tip", cc.Prefab) as cc.Prefab;
                }
                this._tipNode = cc.instantiate(prefab) as cc.Node;
                cc.director.getScene().addChild(this._tipNode, 399);
            } catch (error) {
                console.error(error);
            }
        }
        if (this._tipNode) {
            this._tipNode.active = true;
            this._tipNode.getComponent(CommonTip).refresh(desc);
            let size = this._tipNode.getComponent(CommonTip).getTipSize();
            let position = node.convertToWorldSpaceAR(cc.v2(0, 0));
            position.y -= 60;
            if (position.x < size.width / 2) {
                position.x = size.width / 2;
            } else if (position.x > cc.winSize.width - size.width / 2) {
                position.x = cc.winSize.width - size.width / 2;
            }
            if (position.y < size.height / 2) {
                position.y = size.height / 2;
            } else if (position.y > cc.winSize.height - size.height / 2) {
                position.y = cc.winSize.height - size.height / 2;
            }
            this._tipNode.position = position;
        }
    }

    destroyTip() {
        if (this._tipNode) {
            this._tipNode.active = false;
        }
    }

}

let tipUtils = new TipUtils();
export default tipUtils;