import { stringConfigMap } from './../configs/stringConfig';

/**
 * 字符串工具类
 */
class StringUtils {
    /**
     * 格式化字符串 
     */
    formatStr(msg: string | any, ...subst: any[]): string {
        var REGEXP_NUM_OR_STR = /(%d)|(%s)/;
        var REGEXP_STR = /%s/;
        var argLen = arguments.length;
        if (argLen === 0) {
            return '';
        }
        var msg = arguments[0];
        if (argLen === 1) {
            return '' + msg;
        }

        var hasSubstitution = typeof msg === 'string' && REGEXP_NUM_OR_STR.test(msg);
        if (hasSubstitution) {
            for (let i = 1; i < argLen; ++i) {
                var arg = arguments[i];
                var regExpToTest = typeof arg === 'number' ? REGEXP_NUM_OR_STR : REGEXP_STR;
                if (regExpToTest.test(msg))
                    msg = msg.replace(regExpToTest, arg);
                else
                    msg += ' ' + arg;
            }
        }
        else {
            for (let i = 1; i < argLen; ++i) {
                msg += ' ' + arguments[i];
            }
        }
        return msg;
    }

    /**
     * 格式化字符串2
     */
    formatStr2(msg: string | any, subst: any[]): string {
        var REGEXP_NUM_OR_STR = /(%d)|(%s)/;
        var REGEXP_STR = /%s/;
        var argLen = arguments.length;
        if (argLen === 0) {
            return '';
        }
        var msg = arguments[0];
        if (argLen === 1) {
            return '' + msg;
        }

        var hasSubstitution = typeof msg === 'string' && REGEXP_NUM_OR_STR.test(msg);
        if (hasSubstitution) {
            for (let i = 0; i < subst.length; ++i) {
                var arg = subst[i];
                var regExpToTest = typeof arg === 'number' ? REGEXP_NUM_OR_STR : REGEXP_STR;
                if (regExpToTest.test(msg))
                    msg = msg.replace(regExpToTest, arg);
                else
                    msg += ' ' + arg;
            }
        }
        else {
            for (let i = 0; i < subst.length; ++i) {
                msg += ' ' + subst[i];
            }
        }
        return msg;
    }

    /**
     * 分割后缀名
     * @param path 
     */
    splitExt(path: string) {
        let exts = [];
        let index = path.lastIndexOf('.');
        if (index > 0) {
            exts.push(path.substring(0, index));
            exts.push(path.substring(index));
        }
        return exts;
    }

    getString(value: string, params: any): string {
        value = "" + value;
        let list = value.match(/\${[a-zA-Z0-9]+}/g);
        if (list) {
            for (let i = 0; i < list.length; i++) {
                let m = list[i];
                let key_1 = m.replace(/\$|{|}/g, "");
                value = value.replace(m, String(params[key_1]));
            }
        }
        return value;
    }

    /**
     * 保留几位小数
     * @param value 
     * @param count 
     */
    toFixed(value: number, count: number): string {
        let float = value.toFixed(count);
        let num = parseFloat(float);
        return `${num}`;
    }

    /**
     * 生成唯一ID
     */
    generateUUID(): string {
        let d = new Date().getTime();
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return uuid;
    }

    /**
     * 格式化时间
     * @param time 
     */
    formatTime(time: number): string {
        time = Math.floor(time);
        if (time <= 0) {
            return "00:00:00";
        }

        let hour = Math.floor(time / 3600);
        let minute = Math.floor((time % 3600) / 60)
        let second = time % 60

        let str = `${second}`
        if (str.length == 1) {
            str = `0${second}`
        }

        let minuteStr = minute.toString();
        if (minute < 10) {
            minuteStr = `0${minute}`;
        }

        let hourStr = hour.toString();
        if (hour < 10) {
            hourStr = `0${hour}`;
        }

        if (hour > 0) {
            return `${hourStr}:${minuteStr}:${str}`
        }
        else {
            return `${minuteStr}:${str}`
        }
    }

    /**
     * 格式化时间
     * @param time 
     */
    formatTimeWithHour(time: number): string {
        let lastTime = time;
        let hour = Math.floor(time / 3600);
        let day = Math.floor(hour / 24);
        lastTime -= hour * 3600;
        let hourStr = `${hour % 24}`;
        if (hourStr.length == 1) {
            hourStr = `0${hourStr}`;
        }
        let minute = Math.floor(lastTime / 60);
        lastTime -= minute * 60;
        let minuteStr = `${minute}`;
        if (minuteStr.length == 1) {
            minuteStr = `0${minute}`;
        }
        let second = Math.floor(lastTime);

        let str = `${second}`;
        if (str.length == 1) {
            str = `0${second}`;
        }

        if (day > 0) {
            return `${day}天 ${hourStr}:${minuteStr}:${str}`;
        }
        return `${hourStr}:${minuteStr}:${str}`;
    }

    /**
     * 多久之前
     * @param time 
     */
    formatTimeAgo(time: number) {
        if (time < 60) {
            return this.getString(stringConfigMap.key_second_ago.Value, { count: time });
        }
        let minute = Math.floor(time / 60);
        if (time < 60 * 60) {
            return this.getString(stringConfigMap.key_minute_ago.Value, { count: minute });
        }
        let hour = Math.floor(minute / 60);
        if (time < 24 * 60 * 60) {
            return this.getString(stringConfigMap.key_hour_ago.Value, { count: hour });
        }
        let date = Math.floor(hour / 24);
        date = date > 7 ? 7 : date;
        return this.getString(stringConfigMap.key_date_ago.Value, { count: date });
    }

    /**
     * 多久之后
     * @param time 
     */
    formatTimeLater(time: number) {
        if (time < 60) {
            return "1分钟后统一归还";
        }
        let minute = Math.floor(time / 60);
        if (time < 60) {
            return `${minute}分钟后统一归还`;
        }
        let hour = Math.floor(minute / 60);
        if (time < 24) {
            return `${hour}小时后统一归还`;
        }
        let day = Math.floor(hour / 24);
        hour = Math.floor(hour % 24);
        return `${day}天${hour}小时后统一归还`;
    }

    /**
     * 格式化数量
     * @param value 
     * @param floor 
     */
    formatValueByWan(value: number, floor: boolean = false): string {
        if (value < 1000000) {
            return value.toString();
        }
        else {
            return stringUtils.getString(stringConfigMap.key_wan.Value, { count: floor ? Math.floor(value / 10000) : Math.ceil(value / 10000) });
        }
    }

    /**
     * 格式化数量
     * @param value 
     * @param threshold 
     */
    formatValue(value: number, threshold: number) {
        if (value < threshold) {
            return value.toString();
        }
        else {
            return slib.BigNumberHelper.convertNumStr2UnitStr(value.toString());
        }
    }

    /**
     * 截取字符串（包含中文）
     * @param str 
     * @param len 
     */
    subStr(str: string, len: number) {
        let total = 0;
        let _str = "";
        for (var i = 0; i < str.length; i++) {
            var c = str.charCodeAt(i);
            _str += str.charAt(i);
            //单字节加1
            if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
                total++;
            }
            else {
                total += 2;
            }
            if (total >= len) {
                break;
            }
        }
        return _str;
    }

    /**
     * 字符串实际长度
     * @param str 
     */
    strlen(str: string): number {
        var len = 0;
        for (var i = 0; i < str.length; i++) {
            var c = str.charCodeAt(i);
            //单字节加1
            if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
                len++;
            }
            else {
                len += 2;
            }
        }
        return len;
    }

    /**
     * 字符串缩写
     * @param str 
     */
    strshort(str: string): string {
        return str.length > 18 ? (str.substr(0, 15) + "...") : str;
    }

    /**
     * 格式化战斗力
     * @param power 
     */
    formatPower(power: number): string {
        if (power < 100000) {
            return power.toString();
        } else {
            return slib.BigNumberHelper.convertNumStr2UnitStr(power.toString(), 0, 0);
        }
    }

    /**
     * 格式化数量
     * @param amount 
     */
    formatAmount(amount: number): string {
        if (amount < 100000) {
            return amount.toString();
        } else {
            return slib.BigNumberHelper.convertNumStr2UnitStr(amount.toString(), 0, 2);
        }
    }

    /**
     * 格式化属性
     * @param value 
     */
    formatProperty(value: number): string {
        if (value < 100000) {
            return value.toString();
        }
        else {
            return slib.BigNumberHelper.convertNumStr2UnitStr(value.toString(), 0, 0);
        }
    }

    /**
     * 检查昵称是否合法
     * @param str 
     */
    isValidName(str: string) {
        let pat = new RegExp("[^a-zA-Z0-9\_\u4e00-\u9fa5]", "i");
        return !pat.test(str);
    }

    /**
     * 截取字符串
     * @param str 
     * @param len 
     */
    cutString(str: string, len: number) {
        //length属性读出来的汉字长度为1
        if (str.length * 2 <= len) {
            return str;
        }
        var strlen = 0;
        var s = "";
        for (var i = 0; i < str.length; i++) {
            s = s + str.charAt(i);
            if (str.charCodeAt(i) > 128) {
                strlen = strlen + 2;
                if (strlen >= len) {
                    return s.substring(0, s.length - 1) + "...";
                }
            } else {
                strlen = strlen + 1;
                if (strlen >= len) {
                    return s.substring(0, s.length - 2) + "...";
                }
            }
        }
        return s;
    }

    /**
     * 字节大小转化
     * @param size 
     */
    convertByte(size: number): string {
        if (size < 1024 * 1024) {
            if (size % 1024 == 0) {
                return `${Math.floor(size / 1024)}K`;
            }
            else {
                return `${(size / 1024).toFixed(1)}K`
            }
        }
        else {
            if (size % (1024 * 1024) == 0) {
                return `${Math.floor(size / (1024 * 1024))}M`;
            }
            else {
                return `${(size / (1024 * 1024)).toFixed(1)}M`;
            }
        }
    }

    /**首字符大写 */
    upperCaseFirstChar(content: string): string {
        if (content.length == 0) return content;
        return content.charAt(0).toUpperCase() + content.substring(1);
    }
}

let stringUtils = new StringUtils();
export default stringUtils