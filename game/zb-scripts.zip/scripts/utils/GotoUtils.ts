import { unlockConfigMap } from './../configs/unlockConfig';
import gm from "../manager/GameManager";
import towerLogic from "../logics/TowerLogic";
import xsLogic from "../logics/XuanshangLogic";
import playerLogic from "../logics/PlayerLogic";
import unionLogic from "../logics/UnionLogic";
import GameProxy, { GuildVO } from "../proxy/GameProxy";
import UnlockWrapper from "../view/widget/unlock/UnlockWrapper";
import { MarketTab } from "../view/panel/market/MarketPanel";
import { MarketDateTab } from "../view/component/Market/DateMarketModule";
import dungeonLogic from "../logics/DungeonLogic";
import storageUtils from "./StorageUtils";
import { EvolutionType, Storage, ZhuanPanType } from "./DefineUtils";
import EManager, { EName } from "../manager/EventManager";
import { PromptType } from "../data/prompt/PromptModal";
import heroLogic from "../logics/HeroLogic";
import stringUtils from "./StringUtils";
import { stringConfigMap } from "../configs/stringConfig";
import rechargeLogic, { RightType } from "../logics/RechargeLogic";
import giftLogic from "../logics/GiftLogic";
import activityLogic, { ActivityType } from "../logics/ActivityLogic";
import { StoreTab } from "../view/panel/store/StorePanel";
import benefitLogic from "../logics/BenefitLogic";
import { LotteryTab } from '../view/panel/lottery/LotteryPanel';
import { NavigateTabIndex } from '../view/common/NavigateButton';
import LimitMarketModule, { MarketLimitTab } from '../view/component/Market/LimitMarketModule';
import supplyLogic, { SupplyType } from '../logics/SupplyLogic';
import { MarketDiscountTab } from '../view/component/Market/DiscountMarketModule';

export enum GotoModule {
    /**
     * 快速挂机
     */
    HangUpFast = 0,

    /**
     * 摩天楼
     */
    Tower = 1,

    /**
     * 好友
     */
    Friend = 2,

    /**
     * 抽卡
     */
    ChouKa = 3,

    /**
     * 公会
     */
    Union = 4,

    /**
     * 竞技场
     */
    Arena = 5,

    /**
     * 悬赏
     */
    Xuanshang = 6,

    /**
     * 智慧树
     */
    Mazon = 7,

    /**
     * 商店
     */
    Store = 8,

    /**
     * 英雄升阶
     */
    AdvanceHero = 9,

    /**
     * 改名
     */
    ChangeName = 10,

    /**
     * 充值
     */
    BuyDiamond = 11,

    /**
     * 主界面战斗
     */
    Battle = 12,

    /**
     * 地牢
     */
    Dungeon = 13,

    /**
     * 共享花坛
     */
    ShareLevel = 14,

    /**
     * 英雄列表
     */
    Hero = 15,

    /**
     * VIP界面
     */
    VIP = 16,

    /**
     * 首充弹框
     */
    FirstPay = 17,

    /**
     * 新手基金
     */
    NewFund = 18,

    /**
     * 抽卡
     */
    Lottery = 19,

    /**
     * 七日签到
     */
    Sign = 20,

    /**
     * 新手礼包
     */
    NewGift = 21,

    /**
     * 七日光环
     */
    DailyLight = 22,

    /**
     * 开服竞赛
     */
    NewServer = 23,

    /**
     * 高阶竞技场商店
     */
    ArenaAdvStore = 24,

    /**
     * 新手任务
     */
    NewTask = 25,

    /**
     * 神器
     */
    Artifact = 26,

    /**
     * 奇妙时空
     */
    WonderSpace = 28,

    /**
     * 资源副本
     */
    Material = 29,

    /**
     * 转盘商店
     */
    ZhuanPanStore = 30,

    /**
     * 转盘
     */
    ZhuanPan,

    /**
     * 高级转盘
     */
    SeniorZhuanPan,

    /**
     * 智慧树商店
     */
    WisdomStore,

    /**
     * 扭蛋机
     */
    NiuDan,

    /**
     * 合成
     */
    Compose,

    /**
     * 高阶竞技场
     */
    SeniorPVP,

    /**
     * 限时铺子
     */
    LimitModule,

    /**
     * 种族抽卡
     */
    FactionChouka,

    /**
     * 月令
     */
    MonthOrder,

    /**
     * 补给
     */
    SeniorSupply,

    /**
     * 时装商店
     */
    SkinStore,

    /**
     * 公会副本
     */
    GuildMission,

    /**
     * 升星
     */
    AddStar = 1000,
}

class GotoUtils {
    gotoView(value: NavigateTabIndex) {
        EManager.emit(EName.onGotoModule, value);
    }

    parseGoto(gotos: string): { module: GotoModule, data?: number }[] {
        let results: { module: GotoModule, data?: number }[] = [];
        let modules = gotos.split(';');
        for (let module of modules) {
            let str = module.split('|');
            let gotoModule = Number(str[0]);
            let gotoData = str.length > 1 ? Number(str[1]) : undefined;
            results.push({ module: gotoModule, data: gotoData });
        }
        return results;
    }

    gotoPanels(gotos: string) {
        let results = this.parseGoto(gotos);
        for (let result of results) {
            let valid = this.gotoPanel(result.module, true, result.data);
            if (valid.result) {
                break;
            }
        }
    }

    gotoPanel(module: GotoModule, changeView: boolean = true, data?: any, ignoreLock?: boolean): { result: boolean, message?: string } {
        let valid = this.isValid(module);
        if (!valid.result && !ignoreLock) {
            return valid;
        }

        switch (module) {
            case GotoModule.HangUpFast:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Battle);
                }
                gcc.core.showLayer("prefabs/panel/hangup/HangupFastPanel");
                break;
            case GotoModule.Tower:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Field);
                }
                this.goTower();
                break;
            case GotoModule.Friend:
                this.goFriend();
                break;
            case GotoModule.Lottery:
            case GotoModule.ChouKa:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                let lottery = data ? data : 1;
                this.goLottery(lottery);
                break;
            case GotoModule.FactionChouka:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this._gotoFaction();
                break;
            case GotoModule.Union:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.goUnion();
                break;
            case GotoModule.ZhuanPan:
            case GotoModule.SeniorZhuanPan:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this._gotoZhuanPan(module);
                break;
            case GotoModule.Arena:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Field);
                }
                this.goArena();
                break;
            case GotoModule.SeniorPVP:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Field);
                }
                this.goArenaSenior();
                break;
            case GotoModule.LimitModule:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Field);
                }
                this.gotoLimitModule(data);
                break;
            case GotoModule.Xuanshang:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Field);
                }
                this.goXuanshang();
                break;
            case GotoModule.Mazon:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Field);
                }
                this.goMazon();
                break;
            case GotoModule.Store:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.goStore(data);
                break;
            case GotoModule.ZhuanPanStore:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.goStore({ tab: StoreTab.Turn });
                break;
            case GotoModule.AdvanceHero:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.goAdvanceHero();
                break;
            case GotoModule.ChangeName:
                gcc.core.showLayer("prefabs/panel/player/PlayerNamePanel", { modalTouch: true });
                break;
            case GotoModule.BuyDiamond:
                gcc.core.showLayer("prefabs/panel/market/MarketPanel", {
                    data: {
                        tabIndex: MarketTab.Normal,
                        tabChildIndex: MarketDateTab.Diamond
                    }
                });
                break;
            case GotoModule.Battle:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Battle);
                }
                break;
            case GotoModule.Dungeon:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Field);
                }
                this.onDilao();
                break;
            case GotoModule.ShareLevel:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onFlowerBed();
                break;
            case GotoModule.Hero:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Hero);
                }
                break;
            case GotoModule.VIP:
                let vip = data ? data : 1;
                gcc.core.showLayer("prefabs/panel/market/VIPPanel", { data: vip });
                break;
            case GotoModule.FirstPay:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onFirstPay();
                break;
            case GotoModule.NewFund:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onNewFund();
                break;
            case GotoModule.Sign:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onSign();
                break;
            case GotoModule.NewGift:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onNewGift();
                break;
            case GotoModule.DailyLight:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onDailyLight();
                break;
            case GotoModule.NewServer:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onNewServer();
                break;
            case GotoModule.ArenaAdvStore:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onArenaAdvStore();
                break;
            case GotoModule.NewTask:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onNewTask();
                break;
            case GotoModule.Artifact:
                if (changeView) {
                    gm.heroTab = 3;
                    this.gotoView(NavigateTabIndex.Hero);
                }
                break;
            case GotoModule.WonderSpace:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Field);
                }
                this.onWonderSpace();
                break;
            case GotoModule.Material:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Field);
                }
                this.onMaterial();
                break;
            case GotoModule.WisdomStore:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.goStore({ tab: StoreTab.Maze });
                break;
            case GotoModule.NiuDan:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this._gotoNiuDan();
                break;
            case GotoModule.Compose:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this._gotoCompose();
                break;
            case GotoModule.AddStar:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this._gotoAddStar();
                break;
            case GotoModule.MonthOrder:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onMonthOrder();
                break;
            case GotoModule.SeniorSupply:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onSeniorSupply();
                break;
            case GotoModule.SkinStore:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onSkinStore();
                break;
            case GotoModule.GuildMission:
                if (changeView) {
                    this.gotoView(NavigateTabIndex.Home);
                }
                this.onGuildMission();
                break;
            default:
                break;
        }

        return { result: true };
    }

    isNotExpired(gotoModule: GotoModule): boolean {
        switch (gotoModule) {
            case GotoModule.FirstPay:
                return rechargeLogic.isFirstPayValid();
            case GotoModule.NewFund:
                return giftLogic.isNewPlayerFundValid();
            case GotoModule.Sign:
                return activityLogic.isActivityValid(ActivityType.Day7Sign);
            case GotoModule.NewGift:
                return benefitLogic.isNewPlayerValid();
            case GotoModule.DailyLight:
                return giftLogic.dailyLightModal.isDailyLightValid;
            case GotoModule.NewServer:
                return activityLogic.isActivityValid(ActivityType.NewServer);
            case GotoModule.NewTask:
                return activityLogic.isActivityValid(ActivityType.NewPlayerTask) || activityLogic.isActivityValid(ActivityType.NewPlayer2Task);
            case GotoModule.MonthOrder:
                return activityLogic.isActivityValid(ActivityType.MonthOrder);
            case GotoModule.SeniorSupply:
                return supplyLogic.isUnlock;
            default:
                return true;
        }
    }

    isValid(gotoModule: GotoModule): { result: boolean, message?: string } {
        switch (gotoModule) {
            case GotoModule.Tower:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.摩天楼), message: unlockConfigMap.摩天楼.tips };
            case GotoModule.Friend:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.好友), message: unlockConfigMap.好友.tips };
            case GotoModule.Lottery:
            case GotoModule.ChouKa:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.抽卡机), message: unlockConfigMap.抽卡机.tips };
            case GotoModule.Union:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.公会), message: unlockConfigMap.公会.tips };
            case GotoModule.Arena:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.竞技场), message: unlockConfigMap.竞技场.tips };
            case GotoModule.Xuanshang:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.悬赏大厅), message: unlockConfigMap.悬赏大厅.tips };
            case GotoModule.Mazon:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.智慧树考验), message: unlockConfigMap.智慧树考验.tips };
            case GotoModule.Store:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.商店), message: unlockConfigMap.商店.tips };
            case GotoModule.AdvanceHero:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.花房), message: unlockConfigMap.花房.tips };
            case GotoModule.Dungeon:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.地牢), message: unlockConfigMap.地牢.tips };
            case GotoModule.ShareLevel:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.共享花坛), message: unlockConfigMap.共享花坛.tips };
            case GotoModule.FirstPay:
                return { result: this.isNotExpired(gotoModule), message: stringConfigMap.key_expired.Value }
            case GotoModule.NewFund:
                if (UnlockWrapper.isUnlock(unlockConfigMap.新手基金)) {
                    return { result: this.isNotExpired(gotoModule), message: stringConfigMap.key_expired.Value };
                }
                else {
                    return { result: false, message: unlockConfigMap.新手基金.tips };
                }
            case GotoModule.Sign:
                return { result: this.isNotExpired(gotoModule), message: stringConfigMap.key_expired.Value };
            case GotoModule.NewGift:
                if (UnlockWrapper.isUnlock(unlockConfigMap.新手礼包)) {
                    return { result: this.isNotExpired(gotoModule), message: stringConfigMap.key_expired.Value };
                }
                else {
                    return { result: false, message: unlockConfigMap.新手礼包.tips };
                }
            case GotoModule.DailyLight:
            case GotoModule.NewServer:
            case GotoModule.NewTask:
                return { result: this.isNotExpired(gotoModule), message: stringConfigMap.key_expired.Value };
            case GotoModule.ArenaAdvStore:
            case GotoModule.SeniorPVP:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.高阶竞技场), message: unlockConfigMap.高阶竞技场.tips };
            case GotoModule.ZhuanPanStore:
            case GotoModule.ZhuanPan:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.公会), message: unlockConfigMap.公会.tips };
            case GotoModule.SeniorZhuanPan:
                if (UnlockWrapper.isUnlock(unlockConfigMap.公会)) {
                    let level = rechargeLogic.getUnlockVipLevel(RightType.WheelAdv);
                    return {
                        result: playerLogic.getPlayer().getVipLevel() >= level,
                        message: stringUtils.getString(stringConfigMap.key_vip_unlock.Value, { level: level })
                    }
                }
                else {
                    return { result: false, message: unlockConfigMap.公会.tips };
                }
            case GotoModule.Artifact:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.神器), message: unlockConfigMap.神器.tips };
            case GotoModule.WonderSpace:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.奇妙时空), message: unlockConfigMap.奇妙时空.tips };
            case GotoModule.Material:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.资源副本), message: unlockConfigMap.资源副本.tips };
            case GotoModule.WisdomStore:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.迷宫商店), message: unlockConfigMap.迷宫商店.tips };
            case GotoModule.NiuDan:
                return { result: UnlockWrapper.isUnlockEx(unlockConfigMap.扭蛋机), message: unlockConfigMap.扭蛋机.tips };
            case GotoModule.LimitModule:
                return { result: this.isLimitModuleValid(), message: '限时铺子中没有礼包' };
            case GotoModule.FactionChouka:
                return { result: UnlockWrapper.isUnlock(unlockConfigMap.抽卡机), message: unlockConfigMap.抽卡机.tips };
            case GotoModule.MonthOrder:
                return { result: this.isNotExpired(GotoModule.MonthOrder), message: stringConfigMap.key_expired.Value };
            default:
                return { result: true };
        }
    }

    protected isLimitModuleValid() {
        let valid = UnlockWrapper.isUnlock(unlockConfigMap.棋盘活动) && LimitMarketModule.getGifts(MarketLimitTab.Chess).length > 0;
        if (valid) { return true; }
        valid = UnlockWrapper.isUnlock(unlockConfigMap.夺宝奇兵) && LimitMarketModule.getGifts(MarketLimitTab.Superise).length > 0;
        if (valid) { return true; }
        valid = UnlockWrapper.isUnlock(unlockConfigMap.世界BOSS) && LimitMarketModule.getGifts(MarketLimitTab.WorldBoss).length > 0;
        if (valid) { return true; }
        valid = UnlockWrapper.isUnlock(unlockConfigMap.探趣寻宝) && LimitMarketModule.getGifts(MarketLimitTab.Explore).length > 0;
        if (valid) { return true; }
        valid = UnlockWrapper.isUnlock(unlockConfigMap.抽卡机) && LimitMarketModule.getGifts(MarketLimitTab.LotteryCard).length > 0;
        if (valid) { return true; }
        return false;
    }

    // 前往限时铺子
    protected gotoLimitModule(data?: any) {
        gcc.core.showLayer("prefabs/panel/market/MarketPanel", {
            data: {
                tabIndex: MarketTab.Limit,
                tabChildIndex: MarketLimitTab.LotteryCard,
            }
        });
    }

    // 花房 进阶英雄
    protected async goAdvanceHero() {
        gcc.core.showLayer("prefabs/panel/evolution/EvolutionPanel");
    }

    // 商店
    protected goStore(data?: any) {
        gcc.core.showLayer("prefabs/panel/store/StorePanel", { data: data });
    }

    // 竞技场
    protected goArena() {
        gcc.core.showLayer("prefabs/panel/arena/ArenaJuniorPanel");
    }

    // 高阶竞技场
    protected goArenaSenior() {
        gcc.core.showLayer("prefabs/panel/arena/ArenaSeniorPanel");
    }

    // 摩天楼
    protected async goTower() {
        await towerLogic.towerProcessReq();
        if (towerLogic.isRaceUnlock()) {
            gcc.core.showLayer("prefabs/panel/tower/TowerRacePanel");
        } else {
            gcc.core.showLayer("prefabs/panel/tower/SimpleRaceTowerPanel", { data: 0 });
        }
    }

    // 好友
    protected async goFriend() {
        gcc.core.showLayer("prefabs/panel/friend/FriendPanel");
    }

    // 抽卡
    protected goLottery(lottery: number) {
        gcc.core.showLayer("prefabs/panel/lottery/LotteryPanel", { data: lottery });
    }

    // 悬赏任务
    protected async goXuanshang() {
        await xsLogic.xsTaskReq();
        gcc.core.showLayer("prefabs/panel/xs/XuanshangPanel");
    }

    // 公会
    protected async goUnion() {
        if (playerLogic.getPlayer().getUnionId() < 1) {
            unionLogic.init(null, gm);
            gcc.core.showLayer("prefabs/panel/union/UnionListPanel");
        }
        else {
            let protos = await gm.request<GuildVO[]>(GameProxy.apiguildfindGuild, playerLogic.getPlayer().getUnionId().toString());
            unionLogic.init(protos[0], gm);
            gcc.core.showLayer("prefabs/panel/union/UnionHuntPanel");
        }
    }

    // 扭蛋机
    protected _gotoNiuDan() {
        gcc.core.showLayer("prefabs/panel/lottery/LotteryPanel", { data: LotteryTab.Niudan });
    }

    // 种族抽卡
    protected _gotoFaction() {
        gcc.core.showLayer("prefabs/panel/lottery/LotteryPanel", { data: LotteryTab.Faction });
    }

    // 合成
    protected _gotoCompose() {
        gcc.core.showLayer("prefabs/panel/evolution/EvolutionPanel", { data: EvolutionType.Merge });
    }

    // 升星
    protected _gotoAddStar() {
        gcc.core.showLayer("prefabs/panel/evolution/EvolutionPanel", { data: EvolutionType.Star });
    }

    // 转盘
    protected async _gotoZhuanPan(module: GotoModule) {
        if (module == GotoModule.ZhuanPan) {
            gcc.core.showLayer("prefabs/panel/union/ZhuanPanPanel", { data: ZhuanPanType.Normal });
        }
        else {
            gcc.core.showLayer("prefabs/panel/union/ZhuanPanPanel", { data: ZhuanPanType.Better });
        }
    }

    // 智慧树
    protected async goMazon() {
        gcc.core.showLayer("prefabs/panel/wisdomtree/WisdomTreePanel");
    }

    // 地牢
    protected async onDilao() {
        try {
            await dungeonLogic.request();
            if (dungeonLogic.battleHero) {
                gcc.core.showLayer("prefabs/panel/dungeon/DungeonMapPanel");
            }
            else {
                gcc.core.showLayer("prefabs/panel/dungeon/DungeonSelectPanel");
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }

        storageUtils.setNumber(Storage.LastDungeonIn.Key, gm.getCurrentTimestamp(), true);
        EManager.emit(EName.onRedDirty, PromptType.DungeonBtn);
    }

    // 共享花坛
    protected onFlowerBed() {
        if (heroLogic.getHeroesCount() < heroLogic.getPriestsCount()) {
            gm.toast(stringUtils.getString(stringConfigMap.key_hero_less_than.Value, { count: heroLogic.getPriestsCount() }));
            return;
        }
        gcc.core.showLayer("prefabs/panel/share_level/ShareLevelPanel");
    }

    // 首充
    protected onFirstPay() {
        gcc.core.showLayer("prefabs/panel/benefit/FirstPayPanel");
    }

    // 新手基金
    protected onNewFund() {
        gcc.core.showLayer("prefabs/panel/market/MarketPanel", { data: { tabIndex: MarketTab.Discount, tabChildIndex: MarketDiscountTab.NewFund } });
    }

    // 七日签到
    protected onSign() {
        gcc.core.showLayer("prefabs/panel/activity/ActivitySignPanel");
    }

    // 新手礼包
    protected onNewGift() {
        gcc.core.showLayer("prefabs/panel/newplayer/NewPlayerGiftListPanel");
    }

    // 七日光环
    protected onDailyLight() {
        gcc.core.showLayer("prefabs/panel/activity/ActivityDailyLightPanel");
    }

    // 开服竞赛
    protected onNewServer() {
        gcc.core.showLayer("prefabs/panel/activity/ActivityNewServerPanel");
    }

    // 高阶竞技场商店
    protected onArenaAdvStore() {
        gcc.core.showLayer("prefabs/panel/store/StorePanel", { data: StoreTab.Arena });
    }

    // 新手任务
    protected onNewTask() {
        gcc.core.showLayer("prefabs/panel/activity/ActivityNew2Panel");
    }

    // 奇妙时空
    protected onWonderSpace() {
        gcc.core.showLayer("prefabs/panel/wonderspace/WonderSpaceListPanel");
    }

    // 资源副本
    protected onMaterial() {
        gcc.core.showLayer("prefabs/panel/material/MaterialPanel");
    }

    // 月令
    protected onMonthOrder() {
        gcc.core.showLayer("prefabs/panel/activity/ActivityMonthOrderPanel");
    }

    // 高级补给站
    protected onSeniorSupply() {
        gcc.core.showLayer("prefabs/panel/supply/SupplyMapPanel", { data: SupplyType.Senior });
    }

    // 时装商店
    protected onSkinStore() {
        gcc.core.showLayer("prefabs/panel/market/MarketPanel", { data: { tabIndex: MarketTab.Normal, tabChildIndex: MarketDateTab.Skin } });
    }

    // 公会副本
    protected onGuildMission() {
        this.goUnion();
    }
}

let gotoUtils = new GotoUtils();
export default gotoUtils;