const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("给力组件/ResDownloader")
export default class ResDownloader extends cc.Component {
    start() {
        if (CC_JSB) {
            let loader = cc.loader;
            let resources = (loader as any)._resources;
            let uuidToPath = resources._uuidToPath;
            for (let uuid in uuidToPath) {
                let path = (loader as any)._getResPath(uuid);
                console.log(path);
            }
        }
    }
}
