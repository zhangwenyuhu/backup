const { ccclass, property, menu } = cc._decorator;
@ccclass
@menu("给力组件/GleeScrollView")
export default class GleeScrollView extends gcc.CustomScrollView {
}
