import { Storage } from './../utils/DefineUtils';
import commonUtils from "../utils/CommonUtils";
import loadUtils from "../utils/LoadUtils";
import gm from "../manager/GameManager";
import storageUtils from "../utils/StorageUtils";
import ad from '../manager/AdManager';
import timeUtils from '../utils/TimeUtils';
import videoAdLogic, { AD_TYPE } from '../logics/VideoAdLogic';
import EManager, { EName } from '../manager/EventManager';
import {stringConfigMap} from "../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

// 视频组件状态
enum VideoStatu {
    default = 0,    //
    loading = 1,    // 加载中
    loaded = 2,     // 加载完成
    ignore = 3,     // 忽略播放
    cding = 4,      // 播放CD中
}
@ccclass
@menu("给力组件/VideoBtn")
export default class VideoBtn extends cc.Component {

    @property({
        tooltip: "按钮文字",
        type: cc.Node
    })
    btnText: cc.Node = null;

    @property({
        tooltip: "加载中菊花",
        type: cc.Node
    })
    prepareImg: cc.Node = null;

    @property({
        tooltip: "加载中文字",
        type: cc.Node
    })
    preparing: cc.Node = null;

    @property(cc.Material)
    normalMaterial: cc.Material = null;

    @property(cc.Material)
    grayMaterial: cc.Material = null;

    @property(cc.Node)
    leftTimes: cc.Node = null;

    @property(cc.Node)
    leftTimesBg: cc.Node = null;

    @property
    videoKey: string = "";

    public onSuccessFunc: () => void;
    public onFailFunc: () => void;
    public onVideoLimitFunc: () => void;
    public videoLimit: boolean = false;
    public videoFunc: () => void;
    public spaceX: number = 0;
    public imageFrame: boolean = true;
    public ignoreVideoStatu: boolean = false;
    public limitTs: number = 0;
    protected _leftTs: number = 0;
    protected _showText: string = '';
    protected _nowStatu: VideoStatu = VideoStatu.default;
    protected _adType: AD_TYPE = null;

    start() {
        console.log('VideoBtn start');
        if (!this.btnText) {
            this.btnText = cc.find("layout/rewardText", this.node);
        }
        if (!this.preparing) {
            this.preparing = cc.find("layout/preparingText", this.node);
        }
        if (!this.prepareImg) {
            this.prepareImg = cc.find("layout/preparIcon", this.node);
        }
        if (!this.leftTimes) {
            this.leftTimes = cc.find('layout2/num', this.node);
        }
        if (!this.leftTimesBg) {
            this.leftTimesBg = cc.find('bg', this.node);
        }
        if (this.btnText) {
            this.btnText.active = true;
        }
        if (this.preparing) {
            this.preparing.active = false;
        }
        if (this.prepareImg) {
            this.prepareImg.active = false;
        }
        if (this.leftTimes) {
            this.leftTimes.parent.active = false;
            this.leftTimesBg.active = false;
            if (this._adType && this._adType == AD_TYPE.CallHero) {
                this.leftTimes.parent.active = true;
                this.leftTimesBg.active = true;
                this.updateLeftTimes();
            }
        }
        let btn = this.node.getComponent(cc.Button);
        btn.enableAutoGrayEffect = true;
        this.node.on("click", this.onClick, this)
        this.preloadVideo();

        this.setImageFrame(this.imageFrame);
        this.unschedule(this.updateText);
        this.schedule(this.updateText, 1);
        if (this._leftTs) { this.updateText(); }
    }

    public setImageFrame(bFrame: boolean) {
        this.imageFrame = bFrame;

        let url = bFrame ? "common_btn_green_b" : "common_btn_green_s";
        url = commonUtils.getCommonUrl(url);
        if (this.node && this.node.getComponent(cc.Sprite)) {
            loadUtils.loadSpriteFrame(url, this.node.getComponent(cc.Sprite));
        }
    }

    public setAdType(type: AD_TYPE) {
        this._adType = type;
        if (type == AD_TYPE.CallHero) {
            if (this.leftTimes) {
                this.leftTimes.parent.active = true;
                if (this.leftTimesBg) { this.leftTimesBg.active = true; }
            }
        }
    }

    set videoText(value: string) {
        this._showText = value;
        this.setVideoText(value);
    }
    set eventName(value: string) {
        this.videoKey = value;
    }
    set playVideoCD(ts: number) {
        this._leftTs = ts;
        if (this._leftTs > 0) {
            this.videoStatu = VideoStatu.cding;
            this.unschedule(this.updateText);
            this.schedule(this.updateText, 1);
            this.updateText();
        }
    }

    set videoStatu(statu: VideoStatu) {
        if (this._nowStatu == statu) { return; }

        console.log('视频组件状态: ' + statu);
        if (statu == VideoStatu.loading) {
            this.changeToPreparing();
        } else if (statu == VideoStatu.loaded) {
            this.changeToReady();
        } else if (statu == VideoStatu.ignore) {
            this.changeToIgnore();
        } else if (statu == VideoStatu.cding) {
            this.changeToCD();
        }
        this._nowStatu = statu;
        this.updateLeftTimes();
    }

    protected setVideoText(value: string) {
        if (!this.btnText) {
            this.btnText = cc.find("layout/rewardText", this.node);
        }
        this.btnText.getComponent(cc.Label).string = value;
    }

    // 更新该类型视频播放次数信息
    protected updateLeftTimes() {
        if (this.leftTimes) {
            if (this.leftTimes.parent.active && this._adType == AD_TYPE.CallHero) {
                let numStr: string = `(${videoAdLogic.adNowTimes(this._adType)}/${videoAdLogic.adMaxTimes(this._adType)})`;
                this.leftTimes.getComponent(cc.Label).string = numStr;
            }
        }
    }

    onClick() {
        if (this.ignoreVideoStatu && !this.needIgnoreVideo()) {
            gm.toast(stringConfigMap.key_auto_550.Value);
            this.preloadVideo();
            return;
        }
        this.onVideo()
    }

    async preloadVideo() {
        if (this.needIgnoreVideo() && this._leftTs <= 0) {
            this.ignoreVideoStatu = true;
            this.videoStatu = VideoStatu.ignore;
            return;
        }
        if (this._leftTs > 0) {
            this.videoStatu = VideoStatu.cding;
            return;
        }
        this.ignoreVideoStatu = false;
        if (ad.videoLoaded) {
            this.videoStatu = this._leftTs > 0 ? VideoStatu.cding : VideoStatu.loaded;
        } else {
            this.videoStatu = VideoStatu.loading;
            await ad.preloadVideoAd(() => {
                this.videoStatu = this._leftTs > 0 ? VideoStatu.cding : VideoStatu.loaded;
            });
        }
    }

    isReceive = false;

    successCallBack() {
        if (!this.isReceive) {
            this.isReceive = true;
            this.scheduleOnce(() => {
                this.isReceive = false;
                this.onSuccessFunc && this.onSuccessFunc();
            }, 0.5);
        }
    }

    _clickVideo = false
    onVideo() {
        if (this._clickVideo) {
            return
        }
        if (this.limitTs > 0 && gm.getCurrentTimestamp() / 1000 > this.limitTs) {
            gm.toast(stringConfigMap.key_desc_41.Value)
            return;
        }

        this._clickVideo = true

        if (this.videoLimit) {
            this.onVideoLimitFunc && this.onVideoLimitFunc();
            return;
        }
        this.videoFunc && this.videoFunc();

        if (this.needIgnoreVideo()) {
            if (!storageUtils.getBoolean(Storage.VideoIgnoreTip)) {
                gm.toast(stringConfigMap.key_skip_ad.Value);
            }
            storageUtils.setBoolean(Storage.VideoIgnoreTip.Key, true);
            this.successCallBack();
            this._clickVideo = false;
            return;
        }
        //cc.game.emit(Define.Event.PauseBgMusic)
        ad.showVideoAd(this.videoKey, () => {
            console.info("视频播放成功回调")
            this.successCallBack();
            //cc.game.emit(Define.Event.ResumeBgMusic)

            this._clickVideo = false;
            this.preloadVideo();
        }, () => {
            this.onFailFunc && this.onFailFunc();
            //cc.game.emit(Define.Event.ResumeBgMusic)

            this._clickVideo = false;
            this.preloadVideo();
        });
    }

    protected updateText() {
        if (this._nowStatu == VideoStatu.cding) {
            if (this._leftTs <= 0) {
                console.log('结束视频播放冷却');
                this.preloadVideo();
                this.setVideoText(this._showText);
                this.unschedule(this.updateText.bind(this));
                if (this._adType && this._adType == AD_TYPE.CallHero) {
                    EManager.emit(EName.onUseVideoLottery);
                }
            } else {
                let str: string = timeUtils.formatTime(this._leftTs);
                this.setVideoText(str);
            }
        }
        this._leftTs -= 1;
        this._leftTs = this._leftTs < 0 ? 0 : this._leftTs;
    }

    /**
     * 切换至准备中状态
     */
    protected changeToPreparing() {
        console.log("changeToPreparing");
        if (this.node) {
            let btn = this.node.getComponent(cc.Button);
            btn.interactable = false;
            if (this.btnText) {
                this.btnText.active = false;
            }
            if (this.preparing) {
                this.preparing.active = true;
            }
            if (this.prepareImg) {
                this.prepareImg.active = true;
            }
            this.prepareAnim();

            let layout = this.node.getChildByName("layout");
            if (layout) {
                layout.getComponent(cc.Layout).spacingX = 0;

                let videoIcon = layout.getChildByName("videoIcon");
                let sprite = videoIcon.getComponent(cc.Sprite);
                sprite.setMaterial(0, this.grayMaterial);
            }
        }
    }

    /**
     * 切换至准备完成状态
     */
    protected changeToReady() {
        console.log("changeToReady");
        if (this.node) {
            let btn = this.node.getComponent(cc.Button);
            btn.interactable = true;
            if (this.btnText) {
                this.btnText.active = true;
            }
            if (this.preparing) {
                this.preparing.active = false;
            }
            if (this.prepareImg) {
                this.prepareImg.active = false;
            }
            this.stopAnim();

            let animComp = this.node.getComponent(cc.Animation)
            if (animComp) {
                animComp.play()
            }

            let layout = this.node.getChildByName("layout");
            if (layout) {
                layout.getComponent(cc.Layout).spacingX = this.spaceX || 5;

                let videoIcon = layout.getChildByName("videoIcon");
                loadUtils.loadSpriteFrame("textures/ui/common/common_video", videoIcon.getComponent(cc.Sprite));
                let sprite = videoIcon.getComponent(cc.Sprite);
                sprite.setMaterial(0, this.normalMaterial);
            }
        }
    }

    /**
     * 切换至忽略视频状态
     */
    protected changeToIgnore() {
        console.log("changeToIgnore");
        this.changeToReady();
        let layout = this.node.getChildByName("layout");
        if (layout) {
            let videoIcon = layout.getChildByName("videoIcon");
            if (videoIcon) {
                loadUtils.loadSpriteFrame("textures/ui/common/common_video_ignore", videoIcon.getComponent(cc.Sprite));
            }
        }
    }

    /**
     * 切换至播放CD状态
     */
    protected changeToCD() {
        console.log("changeToCD");
        this.changeToReady();
        let btn = this.node.getComponent(cc.Button);
        btn.interactable = false;

        let layout = this.node.getChildByName("layout");
        if (layout) {
            layout.getComponent(cc.Layout).spacingX = 0;

            let videoIcon = layout.getChildByName("videoIcon");
            loadUtils.loadSpriteFrame("textures/ui/common/common_video", videoIcon.getComponent(cc.Sprite));
            let sprite = videoIcon.getComponent(cc.Sprite);
            sprite.setMaterial(0, this.grayMaterial);
        }
    }

    // 是否可以忽略视频
    protected needIgnoreVideo(): boolean {
        return gm.needIgnoreVideo();
    }

    protected prepareAnim() {
        if (!this.prepareImg) {
            return;
        }
        this.prepareImg.rotation = 0;
        let action = cc.sequence(
            cc.rotateBy(1, 360),
            cc.callFunc(() => {
                this.prepareAnim();
            })
        );
        this.prepareImg.runAction(action);
    }

    protected stopAnim() {
        if (!this.prepareImg) {
            return;
        }
        this.prepareImg.stopAllActions();
    }

}