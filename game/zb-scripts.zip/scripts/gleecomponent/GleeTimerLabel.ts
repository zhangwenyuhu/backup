const { ccclass, property, menu } = cc._decorator;
@ccclass
@menu("给力组件/GleeTimerLabel")
export default class GleeTimerLabel extends gcc.TimerLabel {
}
