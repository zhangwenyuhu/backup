const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("给力组件/GleeLoading")
export default class GleeLoading extends gcc.Dialog {

}
