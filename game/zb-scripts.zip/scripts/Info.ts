class Info extends gssdk.Info {
    appId: string = "10125"
    mode: "develop" | "test" | "release" = "develop"
    platform: string = "develop"
    version: string = "1.7"
    accountServer: string = "sb-focus.mosoga.net"
    gameUrl: string = "sb-zombieiiplus.mosoga.net"
    bussinessServer: string = "sb-ipirate.mosoga.net"
    gameServerUrl: string = "wss://sb-flash.mosoga.net/ws"
    webSocketUrl: string = "wss://sb-im-flash.mosoga.net/ws"
    resVersion: number = 1234
    logUrl: string = "https://us-log.mosoga.net"
    cdnUrl: string = "https://sb-cdn.mosoga.net/zomblieii2/1"
    shareConfigUrl: string = "https://sb-cdn.mosoga.net/zombie2/share/share.json"

    offerId: string = "1450018847";//支付id
    chargeSandbox: boolean = true

    shareProxyUrl: string = "https://appx.mosoga.net";//分享代理服务器

    language: string = "cn";
    requireWechatPay: boolean = true;
    waiterAccessId: string = "78a784b0-25ee-11ea-b939-199f066a240d"; //  云客服id

    payWay: string = "IosPay";
    apiVersion: number = 6;
}

export default new Info()