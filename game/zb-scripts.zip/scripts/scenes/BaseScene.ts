import EManager, { EListener } from './../manager/EventManager';

const { ccclass, property, menu } = cc._decorator;

/**
 * 场景基类
 */
@ccclass
@menu("scenes/BaseScene")
export default class BaseScene extends gcc.Scene {
    protected _eventListeners: EListener[] = [];

    // LIFE-CYCLE CALLBACKS:
    onLoad() {

    }

    onEnable() {
        this._eventListeners = [];
    }

    onDisable() {
        for (let listener of this._eventListeners) {
            EManager.removeEvent(listener);
        }
        this._eventListeners = [];
    }

    onDestroy() {

    }

    start() { }
    update(dt: number) { }
}
