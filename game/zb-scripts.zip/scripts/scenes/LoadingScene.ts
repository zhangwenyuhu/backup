import { stringConfigMap } from './../configs/stringConfig';
import { AnnouncementDO, AnnouncementRequest } from './../proxy/IPirateProxy';
import BaseScene from "./BaseScene";
import gm from '../manager/GameManager';
import loadUtils from '../utils/LoadUtils';
import commonUtils from '../utils/CommonUtils';
import missionLogic from '../logics/MissionLogic';
import guideLogic from "../logics/GuideLogic";
import GameProxy from "../proxy/GameProxy";
import IPirateProxy, { MyDistrictListVO, ChooseV2Request, MyListRequest, DistrictDO } from "../proxy/IPirateProxy";
import List from "../view/common/List";
import announceLogic from '../logics/AnnounceLogic';
import playerLogic from '../logics/PlayerLogic';
import { BattleType } from '../utils/DefineUtils';
import poolManager from '../manager/PoolManager';
import ToastError from '../error/ToastError';
import Info from '../Info';
import stringUtils from '../utils/StringUtils';

const { ccclass, property, menu } = cc._decorator;
const districtNum = 50;

/**
 * 加载场景
 */
@ccclass
@menu("scenes/LoadingScene")
export default class LoadingScene extends BaseScene {

    @property(cc.ProgressBar)
    loadingBar: cc.ProgressBar = null;

    @property(cc.Node)
    loginBarNode: cc.Node = null;

    @property(cc.Node)
    videoPlayer: cc.Node = null;

    @property(cc.Node)
    layer: cc.Node = null;

    @property(cc.Node)
    serverStatu: cc.Node = null;

    @property(cc.Node)
    serverName: cc.Node = null;

    @property(cc.Node)
    loginNode: cc.Node = null;

    @property(cc.Node)
    selectNode: cc.Node = null;

    @property(cc.Node)
    title: cc.Node = null;

    @property(cc.Node)
    cnTag: cc.Node = null;

    @property(cc.Node)
    enTag: cc.Node = null;

    @property(List)
    allServerList: List = null;

    @property(List)
    selectServerList: List = null;

    @property(cc.Label)
    labelVersion: cc.Label = null;

    @property(cc.Node)
    indicator: cc.Node = null;

    @property(sp.SkeletonData)
    skeletonDatas: sp.SkeletonData[] = [];

    @property(cc.Label)
    labelLoading: cc.Label = null;

    private _serverData: MyDistrictListVO = null;
    private _selectedDistrictId: number = 0;
    private _selectIndex: number = 0;
    private _showCn: boolean = true;
    private _getServerListing: boolean = false;
    private _host: string = "";
    protected _tween: cc.Tween = null;
    protected _hotupdateTid: string = "";
    protected _hotupdateCompleteFunc: Function = null;

    async onLoad() {
        super.onLoad();

        if (!CC_JSB) {
            GSSDK.CheckIdentityCertification.prototype['guestLogic'] = function () { return true; };
        }
        GSSDK.ArchivesLoader.prototype.logic = async () => {
            return new Promise<slib.LogicResult>((resolve, reject) => {
                resolve(new slib.LogicResult);
            })
        }
        GSSDK.CheckArchivesVersion.prototype.logic = async () => {
            return new Promise<slib.LogicResult>((resolve, reject) => {
                resolve(new slib.LogicResult);
            })
        }

        GSSDK.StorageCenter.prototype.loadFromLocalStorage = function () {
            var storage = GSSDK.LocalStorage.getItem(this.storageKey);
            if (!storage) {
                return;
            }
            try {
                var data = JSON.parse(storage);
                slib.setDynamicDecodeKey();
                if (data) {
                    for (var key in data) {
                        if (key == "loginData") continue;
                        this._storageMap[key] = this.loadObject(data[key]);
                    }
                }
            }
            catch (e) {
                console.error("存档解析失败", this.storageKey, storage);
                console.error(e);
                throw new Error("存档解析失败");
            }
        }

        logicchart.statetree.devlog.enabled = false;

        this.videoPlayer.zIndex = 480;
        cc.game.addPersistRootNode(this.videoPlayer);

        let request = GameProxy.gameClient.request;
        GameProxy.gameClient.request = function (action: any, data: any, callback: (data: slib.HttpResponseData) => void, params?: {
            version?: number;
            tag?: string;
            name?: string;
            modal?: boolean;
            downloadProgress?: (loaded: number, total: number) => void;
            uploadProgress?: (loaded: number, total: number) => void;
            errorCallback?: (error: any, retry: () => void) => void;
            customUrl?: string;
        }) {
            params.version = Info.apiVersion;
            request.call(this, action, data, callback, params);
        }

        gcc.injectCompatibleObject();
        gcc.core.init();
        gcc.core['resLoadRetry'] = function (retry) {
            gdk.showConfirm({
                title: stringConfigMap.key_alert_title.Value,
                content: stringConfigMap.key_network_error.Value
            }).then(function (res) {
                retry();
            });
        };

        rpgfight.useSafeProperty = true;

        //关闭自动合图，提升addChild相关性能
        if (cc['dynamicAtlasManager'])
            cc['dynamicAtlasManager'].enabled = false;
    }

    onDestroy() {
        super.onDestroy();

        let loader = cc.loader;
        let resources = (loader as any)._resources;
        let uuids = resources.getUuidArray("textures/ui/loading", cc.SpriteFrame);
        for (let uuid of uuids) {
            let ref = (cc.loader as any)._getReferenceKey(uuid);
            let item = (cc.loader as any)._cache[ref];
            if (item && item.alias) {
                item = item.alias;
            }
            if (item && item.complete) {
                let res = item.content;
                loadUtils.releaseAssetRecursively(res);
            }
        }

        let res = cc.loader.getRes(commonUtils.getBgUrl("loading_bg"), cc.SpriteFrame);
        if (res) { loadUtils.releaseAssetRecursively(res); }

        for (let skeletonData of this.skeletonDatas) {
            loadUtils.releaseAssetRecursively(skeletonData);
        }
    }

    start() {
        super.start();
        this.indicator.active = false;
        this.loginBarNode.active = true;
        this.loginNode.active = false;
        this.selectNode.active = false;
        this.init();
    }

    async init() {
        this._host = Info.accountServer;
        Info.accountServer = "https://" + Info.accountServer;
        gssdk.init(Info as any);
        gssdk.gameClient.setErrorCallback((error: any, retry: () => void) => {
            gdk.showAlert({
                title: stringConfigMap.key_alert_title.Value,
                content: stringConfigMap.key_network_error.Value
            }).then(function (res) {
                retry();
            });
        });
        gdk.setLoginSupport({
            google: false,
            visitor: true,
            facebook: false,
            wechat: true,
            gamecenter: false,
        })

        let versionName = CC_JSB ? gdk.systemInfo.versionName : Info.version;
        versionName = versionName || Info.version;
        this.labelVersion.string = `v${versionName}.${gssdk.info.resVersion}.${rpgfight.version.codeVersion}`;

        let keyName = "zombie2"
        if (Info.mode == "release") {
            gssdk.storage.storageKey = `glee_${keyName}_storage`
            gssdk.storage.timestampKey = `glee_${keyName}_storage_timestamp`
            gssdk.storage.roleIdKey = `glee_${keyName}_roleId`
        } else if (Info.mode == `test`) {
            gssdk.storage.storageKey = `glee_${keyName}_storage.test`
            gssdk.storage.timestampKey = `glee_${keyName}_storage_timestamp.test`
            gssdk.storage.roleIdKey = `glee_${keyName}_roleId.test`
        } else if (Info.mode == `develop`) {
            gssdk.storage.storageKey = `glee_${keyName}_storage.develop`
            gssdk.storage.timestampKey = `glee_${keyName}_storage_timestamp.develop`
            gssdk.storage.roleIdKey = `glee_${keyName}_roleId.develop`
        }

        this.loginBarNode.active = false;

        if (CC_JSB) {
            this.loginBarNode.active = true;
            await this._hotUpdate();
            this.loginBarNode.active = false;
        }
        this.loginNode.active = true;
        let btnGameStart = this.loginNode.getChildByName("btnGameStart").getComponent(cc.Button);
        btnGameStart.interactable = false;
        await this._login();
    }

    /**
     * 取消热更
     */
    protected _hotUpdateCancel() {
        if (this._hotupdateCompleteFunc) {
            this.labelLoading.string = "下载完成";
            this.loadingBar.progress = 1;

            this._hotupdateCompleteFunc();
            this._hotupdateCompleteFunc = null;

            let gdkjsb = window['gdkjsb'];
            if (gdkjsb && gdkjsb.hotupdatePause) {
                gdkjsb.hotupdatePause(this._hotupdateTid);
            }
        }
    }

    /**
     * 热更新
     */
    protected async _hotUpdate() {
        return new Promise((resolve, reject) => {
            this._hotupdateCompleteFunc = resolve;

            let inputList = [].concat([
                "animations/*",
                "effects/*",
                "font/*",
                "materials/*",
                "particles/*",
                "prefabs/*",
                "sounds/skill/*",
                "sounds/button.mp3",
                "textures/bg/announce_bg",
                "textures/bg/building_mask",
                "textures/bg/field_bg",
                "textures/bg/home_bg",
                "textures/bg/artifact_bg",
                "textures/bg/battle_bg1",
                "textures/bg/battle_bg2",
                "textures/bg/battle_bg3",
                "textures/bg/battle_bg4",
                "textures/bg/lottery_bg",
                "textures/bg/main_battle_1",
                "textures/bg/main_battle_2",
                "textures/bg/main_battle_fg1",
                "textures/bg/main_battle_fg2",
                "textures/bg/hero_get_bg",
                "textures/hero/*",
                "textures/icon/*",
                "textures/ui/common/*",
                "textures/ui/common2/*",
                "textures/ui/guide/*",
                "textures/ui/loading/*",
                "textures/ui/main/*",
                "textures/ui/panel/artifact/*",
                "textures/ui/panel/artifact_effect/*",
                "textures/ui/panel/assignment/*",
                "textures/ui/panel/battle/*",
                "textures/ui/panel/first_pay/*",
                "textures/ui/panel/hero/*",
                "textures/ui/panel/hero_get/*",
                "textures/ui/panel/lottery/*",
                "textures/ui/panel/mission/*",
                "textures/ui/panel/unlock/*",
                "textures/ui/panel/market/*",
                "spine/ui/jiazai/*",
                "spine/ui/home/*",
                "spine/ui/xiaozhen/*",
                "spine/buff/*",
                "spine/effect/*",
                "spine/hero/chaoren/*",
                "spine/hero/xiaochou/*",
                "spine/hero/yumijianongpao/*",
                "spine/hero/haicaosuoxiao/*",
                "spine/hero/quanjizhusun/*",
                "spine/hero/jichujiangshi/*",
                "spine/hero/feijijiangshi/*",
                "spine/hero/gaojimogu/*",
                "spine/hero/xianrenzhang/*",
                "spine/hero/gangtiexia/*",
                "spine/hero/yangcongzhadan/*",
                "spine/hero/mieba/*",
                "spine/hero/longzhongshirenhua/*",
                "spine/hero/hudi/*",
                "spine/hero/dajiangshi/*",
                "spine/hero/leishen_jinfa/*",
                "spine/hero/dalihuacai/*",
                "spine/hero/xiangyuantanke/*",
                "spine/hero/dujianmu/*",
            ]);

            this.labelLoading.string = "正在检查更新...";
            this.loadingBar.progress = 0;
            this.scheduleOnce(() => {
                let outputList = cc.loader.getUUIDList(inputList);
                let json = outputList.join(",");
                let gdkjsb = window['gdkjsb'];
                if (gdkjsb && gdkjsb.hotupdateInGame) {
                    this._hotupdateTid = gdkjsb.hotupdateInGame(json, (cur: number, total: number) => {
                        if (!this._hotupdateCompleteFunc) return;

                        this.labelLoading.string = `下载进度：${stringUtils.convertByte(cur)}/${stringUtils.convertByte(total)}`;
                        this.loadingBar.progress = cur / total;

                        this.unschedule(this._hotUpdateCancel);
                        this.scheduleOnce(this._hotUpdateCancel, 8);
                    }, () => {
                        if (!this._hotupdateCompleteFunc) return;

                        this.unschedule(this._hotUpdateCancel);
                        resolve();
                    });
                }
                else {
                    resolve();
                }
            }, 0.1);
        });
    }

    /**
     * 登陆
     */
    protected async _login() {
        this.indicator.active = true;
        this.indicator.opacity = 0;
        this.indicator.runAction(cc.sequence(cc.delayTime(1), cc.callFunc(() => { this.indicator.opacity = 0xff })));

        // this.loadingBar.progress = 0;
        // this.labelLoading.string = "正在登陆中...";

        try {
            if (CC_JSB) {
                let gdkjsb = window['gdkjsb'];
                if (gdkjsb && gdkjsb.setAppInfo) {
                    // 自动登录，false且无历史记录，会弹窗，false且有历史记录，会转圈
                    gdkjsb.setAppInfo("gleeui.autoLogin", "false");
                    // 静默登录，自动登录为true时生效，true静默登录，false转圈登录
                    gdkjsb.setAppInfo("gleeui.silent", "false");
                }
            }

            await gssdk.login({ silent: false, autoLogin: true });//登录到服务器        

            if (cc.sys.os == cc.sys.OS_IOS) {
                let versionName = CC_JSB ? gdk.systemInfo.versionName : Info.version;
                gm.appReview = gssdk.loginData.getLoginData().shareSwitch["iosreview"] == versionName;
            }

            if (gm.appReview) {
                guideLogic.noGuide = true;
                Info.gameServerUrl = "wss://pre-ultron-zp2.mosoga.net/ws";
                Info.webSocketUrl = "wss://pre-flash-zp2.mosoga.net/ws";
            }

            gssdk.storage.autoSave = false;
            gssdk.storage.autoInterval = 1000000000000;
            gssdk.storage.startBackup = (backupTime: number) => { }

            await this._getServerList();
        } catch (error) {
            console.error(error);
            await commonUtils.sleep(1, this);
            await this._login();
        }

        this.indicator.active = false;
    }

    /**
     * 检测区服列表
     */
    protected _checkServerList() {
        if (this._serverData && this._serverData.list) { return; }
        if (this._getServerListing) { return; }
        this._getServerList();
    }

    /**
     * 获取区服列表
     */
    protected async _getServerList() {
        this._getServerListing = true;

        try {
            // 获取游戏服务器列表
            IPirateProxy.gameClient.host = Info.bussinessServer;
            IPirateProxy.gameClient.timeout = 10000;
            IPirateProxy.gameClient.getAppId = () => Info.appId
            IPirateProxy.gameClient.getGameToken = () => gssdk.loginData.gameToken;
            IPirateProxy.gameClient.getToken = () => gssdk.loginData.token;

            let request = new MyListRequest();
            request.packageTag = gdk.packageTag;
            request.tishen = gm.appReview;
            this._serverData = await gm.request<MyDistrictListVO>(IPirateProxy.apidistrictmylist, request, IPirateProxy);

            // 根据no从小到大排序 
            this._serverData.list = this._serverData.list.sort((a, b) => { return a.no - b.no; })

            // 保存游戏服信息到缓存中
            gm.districtMap = {};
            for (let district of this._serverData.list) {
                gm.districtMap[district.districtId] = district;
            }

            // 默认登陆显示的服务器 -> 已登陆的服务器列表的第一个,如果空则在所有服列表中选择最后一个
            let districtId: number = 0;
            let myServerList: number[] = this._serverData.myList;
            if (myServerList && myServerList.length > 0) {
                districtId = myServerList[0];
                this._selectIndex = 0;
            } else {
                this._selectIndex = 1;
            }
            this._selectDistrictId(districtId);
            this._getServerListing = false;
            this.scheduleOnce(this._checkServerList.bind(this), 2);

            // 公告信息
            let req = new AnnouncementRequest();
            req.language = slib.i18n.language;
            req.packageTag = gdk.packageTag || 'CN';
            let announces = await gm.request<AnnouncementDO[]>(IPirateProxy.apiannouncementlist, req, IPirateProxy);
            announceLogic.init(announces, districtId);
            if (announceLogic.announces.length > 0) {
                gcc.core.showLayer("prefabs/panel/announce/AnnouncePanel", {
                    modalTouch: true,
                    callback: (layerData) => {
                        let node = layerData["_node"];
                        node.parent = null;
                        let nowScene = cc.director.getScene();
                        nowScene.addChild(node, 1024);
                        cc.game.addPersistRootNode(node);
                    }
                });
            }
        } catch (error) {
            console.error(error);
        }
    }

    /**
     * 登陆选定的游戏服
     * @param districtId 区服ID
     */
    protected async _selectServer(districtId: number) {
        let district = gm.districtMap[districtId];
        if (!district) {
            throw new ToastError("服务器选择失败");
        };

        let data = new ChooseV2Request();
        data.channelId = gdk.channelId;
        data.id = districtId;
        data.sourceId = gdk.launchOptions ? gdk.launchOptions.scene : 0;
        let str = gdk.system.toLowerCase();
        data.system = str.startsWith("ios") ? 2 : (str.startsWith("android") ? 1 : 0);
        data.systemInfo = gdk.systemInfo.clone();
        data.v = gssdk.info.version;
        data.ad = gssdk.loginData.getLoginData().ad;

        try {
            let gametoken = await gm.request<string>(IPirateProxy.apidistrictchoose, data, IPirateProxy);

            if (district.host) {
                GameProxy.gameClient.host = district.host.replace("https://", "");
            }
            else {
                GameProxy.gameClient.host = Info.gameUrl;
            }
            GameProxy.gameClient.getAppId = () => Info.appId
            GameProxy.gameClient.timeout = 10000;
            GameProxy.gameClient.getGameToken = () => gametoken;
            GameProxy.gameClient.getToken = () => gametoken;

            gssdk.gameClient.host = this._host;
            gssdk.gameClient.timeout = 10000;
            gssdk.gameClient.getGameToken = () => gametoken;
            gssdk.gameClient.getToken = () => gssdk.loginData.token;

            gssdk.logCommitTool.districtId = districtId;
            gm.districtId = districtId;
            gm.curServerInfo = this._serverData.list.find((a) => { return a.districtId == districtId; });
        } catch (e) {
            if (e.name == "ToastError") {
                this.loginBarNode.active = false;
                this.loginNode.active = true;
            }
            throw e;
        }
    }

    /**
     * 进入主场景
     */
    protected _replaceScene() {
        let step = guideLogic.currentStep;
        if (step && step.ID == 1001) {
            if (cc.sys.platform == cc.sys.WIN32
                || cc.sys.platform == cc.sys.DESKTOP_BROWSER
                || cc.sys.platform == cc.sys.MOBILE_BROWSER) {
                this.videoPlayer.destroy();
                gcc.core.replaceScene("MainScene");
            }
            else {
                this.videoPlayer.active = true;
            }
        }
        else {
            this.videoPlayer.destroy();
            gcc.core.replaceScene("MainScene");
        }
    }

    /**
     * 更新进度条
     * @param duration 时间
     * @param progress 进度
     * @param callback 完成后回调
     */
    protected _tweenProgress(duration: number, progress: number, callback?: Function) {
        if (this._tween) { this._tween.stop(); }

        this._tween = cc.tween(this.loadingBar).to(duration, { progress: Math.max(progress, this.loadingBar.progress) }).call(() => { if (callback) callback() });
        this._tween.start();
    }

    /**
     * 开始加载
     */
    protected async _loading() {
        try {
            this.loginBarNode.active = true;
            this.loginNode.active = false;
            this.labelLoading.string = "即将进入废墟世界";
            this.loadingBar.progress = 0;
            gm.isIndicatorEnabled = false;

            this._tweenProgress(8, 0.75, this._tweenProgress.bind(this, 24, 0.95));
            console.time("加载通用预制体");
            await this._loadCommonPrefabs();
            console.timeEnd("加载通用预制体");
            this._tweenProgress(6, 0.75, this._tweenProgress.bind(this, 18, 0.95));
            console.time("请求服务器");
            await this._selectServer(this._selectedDistrictId);
            await gm.init();
            console.timeEnd("请求服务器");
            this._tweenProgress(5, 0.75, this._tweenProgress.bind(this, 15, 0.95));
            console.time("加载关卡预制体");
            await this._loadChapterPrefabs();
            console.timeEnd("加载关卡预制体");
            this._tweenProgress(4, 0.75, this._tweenProgress.bind(this, 12, 0.95));
            console.time("加载纹理");
            await this._loadTextures();
            console.timeEnd("加载纹理");
            this._tweenProgress(2, 0.75, this._tweenProgress.bind(this, 6, 0.95));
            console.time("加载spine");
            await this._loadSpines();
            console.timeEnd("加载spine");
            this._tweenProgress(1, 0.75, this._tweenProgress.bind(this, 3, 0.95));
            console.time("加载主场景");
            await loadUtils.loadRes("prefabs/panel/market/MarketPanel", cc.Prefab);
            await loadUtils.loadRes("prefabs/panel/market/module/MonthCardModule", cc.Prefab);
            await loadUtils.loadRes("textures/bg/market_bg_0", cc.SpriteFrame);
            await loadUtils.loadScene("MainScene");
            console.timeEnd("加载主场景");
            this._tweenProgress(0.25, 1, this._replaceScene.bind(this));
            gm.isIndicatorEnabled = true;
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message, this.node);
            }
            else {
                console.error(e);
                setTimeout(this._loading.bind(this), 1000);
            }
            this._tween.stop();
            this._tween = null;
            this.loadingBar.progress = 0;
        }
    }

    /**
     * 加载通用预制体
     */
    protected async _loadCommonPrefabs() {
        try {
            await loadUtils.loadRes("prefabs/common/indicator", cc.Prefab);
            await loadUtils.loadRes("prefabs/common/guide", cc.Prefab);
            await loadUtils.loadRes("prefabs/common/lock", cc.Prefab);

            let prefab = await loadUtils.loadRes("prefabs/common/hero/hero_card", cc.Prefab) as cc.Prefab;
            prefab.compileCreateFunction();

            prefab = await loadUtils.loadRes("prefabs/common/good/good_card", cc.Prefab) as cc.Prefab;
            prefab.compileCreateFunction();

            prefab = await loadUtils.loadRes("prefabs/common/equip/equip_card", cc.Prefab) as cc.Prefab;
            prefab.compileCreateFunction();

            prefab = await loadUtils.loadRes("prefabs/common/artifact/artifact_item", cc.Prefab) as cc.Prefab;
            prefab.compileCreateFunction();

            prefab = await loadUtils.loadRes("prefabs/fight/fight_start", cc.Prefab) as cc.Prefab;
            prefab.compileCreateFunction();

            await poolManager.createHeroItemPool(40);
            await poolManager.createBagItemPool(40);
        }
        catch (e) {
            console.error(e);
            await commonUtils.sleep(1);
            await this._loadCommonPrefabs();
        }
    }

    /**
     * 加载关卡预制体
     */
    protected async _loadChapterPrefabs() {
        try {
            let country = missionLogic.getCurrentCountry();
            if (!country) country = missionLogic.getLastCountry();
            let chapters = country.getChapters();
            for (let chapter of chapters) {
                if (chapter.isUnlock()) {
                    let prefab = await loadUtils.loadRes(`prefabs/chapter/chapter${chapter.getId()}`, cc.Prefab) as cc.Prefab;
                    if (!gm.usePerformance) {
                        await commonUtils.addChapterFgSpriteFrame(prefab.data)
                    }
                }
                else {
                    break;
                }
            }
        } catch (e) {
            console.error(e);
            await commonUtils.sleep(1);
            await this._loadChapterPrefabs();
        }
    }

    /**
     * 加载通用纹理
     */
    protected async _loadTextures() {
        try {
            let paths = [
                "textures/ui/common",
                "textures/ui/common2",
                "textures/icon/hero",
                "textures/icon/equip",
                "textures/icon/good",
                "textures/hero"
            ];
            for (let path of paths) {
                if (CC_BUILD) {
                    await loadUtils.loadRes(`${path}/AutoAtlas`, cc.SpriteAtlas);
                }
                else {
                    await loadUtils.loadDir(path, cc.SpriteFrame);
                }
            }
            if (!gm.usePerformance) {
                await loadUtils.loadRes(commonUtils.getBgUrl("building_mask"), cc.Texture2D);
            }
        } catch (e) {
            console.error(e);
            await commonUtils.sleep(1);
            await this._loadTextures();
        }
    }

    /**
     * 加载通用Spine
     */
    protected async _loadSpines() {
        try {
            let heroes = await playerLogic.getTroop(BattleType.PVE);
            for (let hero of heroes) {
                if (!hero) continue;
                await loadUtils.loadRes(commonUtils.getHeroSpineUrl(hero.getSpineFile()), sp.SkeletonData);
                if (gm.usePerformance) { break; }
            }
            let skeletonData = await loadUtils.loadRes(commonUtils.getHeroSpineUrl("jichujiangshi"), sp.SkeletonData);
            skeletonData.lock();

            await loadUtils.loadRes("spine/buff/CommonBuff/buff", sp.SkeletonData);
            await loadUtils.loadRes("spine/buff/CommonBuff2/buff2", sp.SkeletonData);
        } catch (e) {
            console.error(e);
            await commonUtils.sleep(1);
            await this._loadSpines();
        }
    }

    /**
     * 选择区服
     * @param id 区服ID
     */
    protected _selectDistrictId(id: number) {
        let allList: DistrictDO[] = this._showCn ? this._serverData.list : [];
        if (allList && allList.length > 0) {
            let item = gm.districtMap[id];
            let len: number = allList.length;
            // 新玩家则选择最后的一个
            if (!item) { item = allList[len - 1]; }

            this._selectedDistrictId = item.districtId;
            this._freshLoginUI(item.name, item.state, item.open);
            this.loginNode.getChildByName("btnGameStart").getComponent(cc.Button).interactable = true;
        } else {
            console.error("服务器列表为空!")
            this._selectedDistrictId = -10000;
            this._freshLoginUI("", 0, false);
            this.loginNode.getChildByName("btnGameStart").getComponent(cc.Button).interactable = false;
        }
    }

    /**
     * 服务器的标记图标  通畅,火爆,繁忙
     * @param statu 
     * @param open 
     */
    protected _getStatuImageUrl(statu: number, open: boolean): string {
        let serverState: number = open ? statu : 3;
        return "textures/ui/loading/login/login_s_" + serverState;
    }

    /**
     * 刷新当前选中服的名称和标记
     * @param name 
     * @param state 
     * @param open 
     */
    protected _freshLoginUI(name: string, state: number, open: boolean) {
        this.serverName.getComponent(cc.Label).string = name;
        let url: string = this._getStatuImageUrl(state, open);
        cc.loader.loadRes(url, cc.SpriteFrame, (err, texture: cc.SpriteFrame) => {
            if (err) {
                console.log(`加载失败: `, err);
            } else if (cc.isValid(this.serverStatu.getComponent(cc.Sprite))) {
                this.serverStatu.getComponent(cc.Sprite).spriteFrame = texture;
            }
        })
    }

    onClickGameStart() {
        // 判断当前服状态
        let server = gm.districtMap[this._selectedDistrictId];
        if (!server) {
            gm.toast("未找到服务器", this.node);
            return;
        }
        else if (!server.open) {
            gm.toast("服务器正在维护", this.node);
            return;
        }

        // 登录
        this._loading();
    }

    onClickSelectServer() {
        this.selectNode.active = true;
        this._initAllServer();
    }
    /*  --login--  */

    /*  --select--  */
    protected _initAllServer() {
        this.allServerList.getComponent(cc.Widget).updateAlignment();
        this.allServerList.numItems = this._getTotalServerListNum();

        this._freshSelectServerList();
        if (this._showCn) {
            this.onClickCnArea();
        } else {
            this._freshSelectServerList();
            this.onClickEnArea()
        }

    }

    /**
     * 计算左侧的行数
     */
    protected _getTotalServerListNum(): number {
        let num: number = 2;
        let serverList: DistrictDO[] = this._showCn ? this._serverData.list : [];
        num = Math.ceil(serverList.length / districtNum) + 1;
        return num;
    }

    /**
     *  0 -> 我的
     * 
     *  1   01-50
     * 
     *  2   51-100
     *  
     *  根据左侧的index返回对应的服务器列表信息    
     */
    protected _getServerItemByIndex(index: number): DistrictDO[] {
        let data: DistrictDO[] = [];
        if (index == 0) {
            let myList: number[] = this._showCn ? this._serverData.myList : [];
            if (!myList) { return []; }
            for (let i = 0; i < myList.length; i++) {
                let item = this._serverData.list.find((a) => { return a.districtId == myList[i]; })
                if (item) {
                    data.push(item);
                }
            }
        } else {
            let serverList: DistrictDO[] = this._showCn ? this._serverData.list : [];
            data = serverList.filter((v, i, a) => {
                let maxIndex = this._getTotalServerListNum();
                let tmp = maxIndex - index;
                return (v.no >= (tmp - 1) * districtNum + 1 && v.no <= tmp * districtNum) || v.no < 0;
            })
        }
        return data || [];
    }

    protected _getTitleByIndex(index: number): string {
        let serverList: DistrictDO[] = this._showCn ? this._serverData.list : [];
        let title: string = "";
        let maxIndex = this._getTotalServerListNum();
        let maxLen = serverList.length;

        let tmp = maxIndex - index;
        maxLen = tmp * 50 > maxLen ? maxLen : tmp * 50;
        title = `${1 + (tmp - 1) * 50} - ${maxLen}区`;
        title = index == 0 ? `我的服务器` : title;
        return title;
    }

    protected _freshSelectServerList() {
        this.selectServerList.getComponent(cc.Widget).updateAlignment();
        this.selectServerList.numItems = this._getServerItemByIndex(this._selectIndex).length;

        this.title.getComponent(cc.Label).string = this._getTitleByIndex(this._selectIndex);
    }

    onAllServerItemRender(item: cc.Node, index: number) {
        let selected: boolean = index == this._selectIndex;
        item.getChildByName("normal").active = !selected;
        item.getChildByName("select").active = selected;
        item.getChildByName("text").getComponent(cc.Label).string = this._getTitleByIndex(index);

        let btn = item.getChildByName("btn").getComponent(cc.Button);
        btn.clickEvents[0].customEventData = `` + index;
    }

    onSelectServerItemRender(item: cc.Node, index: number) {
        let data: DistrictDO[] = this._getServerItemByIndex(this._selectIndex);
        if (data.length > index) {
            item.active = true;
            let serverState: number = data[index].open ? data[index].state : 3;

            item.getChildByName("bg").active = index % 2 == 1;
            item.getChildByName("text").getComponent(cc.Label).string = data[index].name;
            let tag = item.getChildByName("tag");
            let statu = item.getChildByName("statu");
            tag.active = serverState == 0 || serverState == 1;
            let url: string = `textures/ui/loading/login/login_tag_${serverState}`;
            if (tag.active) {
                cc.loader.loadRes(url, cc.SpriteFrame, (err, texture: cc.SpriteFrame) => {
                    if (cc.isValid(tag) && cc.isValid(tag.getComponent(cc.Sprite))) {
                        tag.getComponent(cc.Sprite).spriteFrame = texture;
                    }
                })
            }
            url = `textures/ui/loading/login/login_s_${serverState}`;
            cc.loader.loadRes(url, cc.SpriteFrame, (err, texture: cc.SpriteFrame) => {
                if (cc.isValid(statu) && cc.isValid(statu.getComponent(cc.Sprite))) {
                    statu.getComponent(cc.Sprite).spriteFrame = texture;
                }
            })

            item.getChildByName("select").active = false;
            item.getChildByName("text").scale = 1;
            item.getChildByName("statu").scale = 1;
            item.getChildByName("tag").scale = 1;

            item.off(cc.Node.EventType.TOUCH_START);
            item.off(cc.Node.EventType.TOUCH_END);
            item.off(cc.Node.EventType.TOUCH_CANCEL);
            item.on(cc.Node.EventType.TOUCH_START, (e: cc.Event.EventTouch) => {
                item.getChildByName("select").active = true;
                item.getChildByName("text").scale = 1.2;
                item.getChildByName("statu").scale = 1.2;
                item.getChildByName("tag").scale = 1.2;
            })
            item.on(cc.Node.EventType.TOUCH_END, (e: cc.Event.EventTouch) => {
                item.getChildByName("select").active = false;
                item.getChildByName("text").scale = 1;
                item.getChildByName("statu").scale = 1;
                item.getChildByName("tag").scale = 1;
                this._selectedDistrictId = data[index].districtId;
                this.selectNode.active = false;
                this._selectDistrictId(this._selectedDistrictId);
            })
            item.on(cc.Node.EventType.TOUCH_CANCEL, (e: cc.Event.EventTouch) => {
                item.getChildByName("select").active = false;
                item.getChildByName("text").scale = 1;
                item.getChildByName("statu").scale = 1;
                item.getChildByName("tag").scale = 1;
            })

        } else {
            item.active = false;
        }
    }

    onClickSelectServerItem(sender: cc.Event.EventTouch, index: string) {
        let btn: cc.Node = sender.currentTarget;
        if (btn) {
            btn.getChildByName("select").active = true;

            let data: DistrictDO[] = this._getServerItemByIndex(this._selectIndex);
            let tmp: number = parseInt(index);
            if (data[tmp]) {
                this._selectedDistrictId = data[tmp].districtId;
            }
        }
        this.scheduleOnce(() => {
            this.selectNode.active = false;
        }, 1 / 30);
    }

    onClickCnArea() {
        this.cnTag.active = true;
        this.enTag.active = false;
        this._showCn = true;
        this.allServerList.numItems = this._getTotalServerListNum();
        this._freshSelectServerList();
    }

    onClickEnArea() {
        this.cnTag.active = false;
        this.enTag.active = true;
        this._showCn = false;
        this.allServerList.numItems = this._getTotalServerListNum();
        this._freshSelectServerList();
    }

    onClickBtnClose() {
        this.selectNode.active = false;
    }

    onClickAllServerItem(sender: cc.Event.EventTouch, index: string) {
        this._selectIndex = parseInt(index);
        this.allServerList.updateAll();

        this._freshSelectServerList();
    }
    /*  --select--  */
}
