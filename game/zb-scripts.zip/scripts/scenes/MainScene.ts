import { Storage } from './../utils/DefineUtils';
import unlockConfig, { unlockConfigMap, unlockConfigRow } from './../configs/unlockConfig';
import BasePanel, { PopupPanel, InternalView } from './../view/panel/BasePanel';
import { stringConfigMap } from './../configs/stringConfig';
import { EName } from './../manager/EventManager';
import BaseScene from "./BaseScene";
import EManager from "../manager/EventManager";
import { Goto, EventGroup } from '../utils/DefineUtils';
import missionLogic from '../logics/MissionLogic';
import Mission from '../data/mission/Mission';
import stringUtils from '../utils/StringUtils';
import ChatUserData, { ChatExtra, ChatGroup, ChatType, ChatTab } from "../socket/ChatUserData";
import Building from '../data/mission/Building';
import commonUtils from '../utils/CommonUtils';
import gm from '../manager/GameManager';
import GameProxy, { PayOrderDO, PayOrderReq, ResourceVO } from "../proxy/GameProxy";
import redPointLogic, { RedPointType } from "../logics/RedPointLogic";
import bagLogic from "../logics/BagLogic";
import CommonLoader from "../view/common/CommonLoader";
import TopBar from "../view/component/TopBar";
import assignmentLogic from '../logics/AssignmentLogic';
import playerLogic from '../logics/PlayerLogic';
import rechargeLogic from '../logics/RechargeLogic';
import benefitLogic from '../logics/BenefitLogic';
import UnlockWrapper from '../view/widget/unlock/UnlockWrapper';
import { GoodType } from "../data/card/Good";
import activityLogic, { ActivityType } from "../logics/ActivityLogic";
import { PromptType } from '../data/prompt/PromptModal';
import guideLogic from '../logics/GuideLogic';
import GuideBaseStep from '../view/widget/guide/GuideBaseStep';
import timeUtils from '../utils/TimeUtils';
import promptLogic from "../logics/PromptLogic";
import pushManager from "../manager/PushManager";
import wisdomTreeLogic from "../logics/WisdomTreeLogic";
import { defaultConfigMap } from '../configs/defaultConfig';
import storageUtils from '../utils/StorageUtils';
import ActivityPioneerBtn from "../view/component/Activity/ActivityPioneerBtn";
import onlineTimeWidget from "../view/component/OnlineTimeWidget";
import giftLogic from "../logics/GiftLogic";
import OnlineItem from "../view/component/Online/OnlineItem";
import RootView from '../view/panel/view/RootView';
import heroLogic from "../logics/HeroLogic";
import ActivityArtifactBtn from "../view/component/Activity/ActivityArtifactBtn";
import Marquee from '../view/component/Marquee';
import mqLogic from '../logics/MarqueeLogic';
import commitLogic, { DiamondSource } from '../logics/CommitLogic';
import arenaLogic from "../logics/ArenaLogic";
import arenaSeniorLogic from "../logics/ArenaSeniorLogic";
import cm from '../manager/ConfigManager';
import videoAdLogic from '../logics/VideoAdLogic';
import NavigateButton, { NavigateTabIndex } from '../view/common/NavigateButton';
import ChatPanel from '../view/panel/chat/ChatPanel';
import actTabLogic, { TabType } from '../logics/ActTabLogic';
import loadUtils from "../utils/LoadUtils";
import { SupplyType } from '../logics/SupplyLogic';
import rMissionLogic from "../logics/RMissionLogic";
import ArenaFailReport from "../view/component/Arena/ArenaFailReport";
import udgLogic from '../logics/UnionDungeonLogic';
import PlayerMain from '../view/component/Player/PlayerMain';

const { ccclass, property, menu } = cc._decorator;

enum LeftButtonType {
    /**首充 */
    FirstPay,

    /**新手礼包 */
    NewPlayerGift,

    /**惊喜礼包 */
    Surprise,

    /**活动 */
    Activity,

    /**七日签到 */
    Day7,

    /**新手任务 */
    NewPlayer,

    /**英雄学堂 */
    HeroSchool,

    /**新手活动 */
    NpActivity,

    /**精彩活动 */
    BetterActivity,

    /**夺宝奇兵 */
    Treasure,

    /**世界boss */
    WorldBoss,

    /**棋盘寻宝 */
    ChessBoard,

    /** 探趣寻宝 */
    Explore,

    /**百宝箱 */
    BBX,

    /** 长度 */
    Len,
}

enum RightButtonType {
    /**
     * 任务
     */
    Task,

    /**
     * 好友
     */
    Friend,

    /**
     * 邮件
     */
    Mail,

    /**
     * 背包
     */
    Bag
}

/**
 * 主界面场景
 */
@ccclass
@menu("scenes/MainScene")
export default class MainScene extends BaseScene {
    @property(cc.Node)
    contentArea: cc.Node = null;

    @property(cc.Node)
    customContentArea: cc.Node = null;

    @property(cc.Node)
    popContentArea: cc.Node = null;

    @property(cc.Node)
    root: cc.Node = null;

    @property(NavigateButton)
    bottomButtons: NavigateButton[] = [];

    @property({
        type: cc.Prefab
    })
    viewPrefabs: cc.Prefab[] = [];

    @property(cc.Node)
    topBar: cc.Node = null;

    @property(CommonLoader)
    topNode: CommonLoader = null;

    @property(cc.Node)
    leftButtonContainer: cc.Node = null;

    @property(cc.Node)
    rightButtonContainer: cc.Node = null;

    @property(cc.Sprite)
    leftOpenBtn: cc.Sprite = null;

    @property(cc.Sprite)
    rightOpenBtn: cc.Sprite = null;

    @property(cc.Node)
    leftButtons: cc.Node[] = [];

    @property(cc.Node)
    rightButtons: cc.Node[] = [];

    @property(cc.SpriteFrame)
    openBtnFrames: cc.SpriteFrame[] = [];

    @property(cc.Node)
    bagBtn: cc.Node = null;

    @property(cc.Node)
    bubbleNode: cc.Node = null;

    @property(cc.Node)
    purityBtn: cc.Node = null;

    @property(cc.Node)
    onlineBtn: cc.Node = null;

    @property(cc.Node)
    onlineGuide: cc.Node = null;

    @property(cc.Node)
    artifactBtn: cc.Node = null;

    @property(cc.Node)
    redPoint: cc.Node = null;

    @property(cc.Node)
    expNode: cc.Node = null;

    @property(cc.VideoPlayer)
    videoPlayer: cc.VideoPlayer = null;

    @property(cc.Node)
    marquee: cc.Node = null;

    @property(cc.Node)
    newServerBtn: cc.Node = null;

    @property(cc.Node)
    topRankBtn: cc.Node = null;

    @property(cc.Node)
    chatBar: cc.Node = null;

    @property(cc.Node)
    arenaFail: cc.Node = null;

    protected _areaIndex: number = -1;
    protected _areaIndex2: number = -1;
    protected _isRightOpen: boolean = true;
    protected _onlineForceHide: boolean = false;
    protected _onlineInited: boolean = false;
    public _isLeftOpen: boolean = true;
    protected _validMarquee: boolean = true;
    protected _leftActStatu: { [key: number]: boolean } = {}; // 左侧大型活动状态
    protected _lastCheckTs: number = 0;

    async onLoad() {
        super.onLoad();

        cc.sys.garbageCollect();

        let view = this.viewPrefabs[NavigateTabIndex.Home].data as any;
        view._onBatchRestored();
        view = this.viewPrefabs[NavigateTabIndex.Field].data as any;
        view._onBatchRestored();
        view = this.viewPrefabs[NavigateTabIndex.Battle].data as any;
        view._onBatchRestored();

        let rootView = this.root.getComponent(RootView);
        rootView.init(this._showUnlockModule.bind(this));

        this.marquee.active = false;
        this._initOnline();
        this._updateNewServer();
        this._updateTopRank();
        this.customContentArea.addComponent(InternalView);

        if (playerLogic && playerLogic.getPlayer().getExp() >= 0) {
            console.info("请求红点信息!");
            //gm.redPointsReq();
        }
        promptLogic.setLocalPromptStatus(200, ChatUserData.saved.chatRedPointCnt > 0);
        await wisdomTreeLogic.doGetCloudData();
        await pushManager.clearLocalPush();
        pushManager.updateLocalPushs();
    }

    start() {
        super.start();
        this.topNode.loaderNode;
        this.expNode.getComponent(CommonLoader).loaderNode;
        this.gotoView(null, NavigateTabIndex.Battle.toString());

        redPointLogic.freshAll();
        this.schedule(() => { redPointLogic.update(); }, 1);
        this.schedule(this._checkOrderStatu.bind(this), 2);
        this._redFuncBind();
        this._initLeftActBtnEventData();
        this._updateLeftActStatu();
        this._checkLeftBtnValid();
        this._checkRightBtnValid();
        this._checkActivityBtnValid();
        this._checkBind();
        this.scheduleOnce(() => { this._checkSurpriseGiftPop(); }, 2);

        this._updateMedalInfo();
        gm.checkDayFresh();
        //this.schedule(()=>{ gm.checkDayFresh();},6);

        if (!storageUtils.getBoolean(Storage.LeftButtonsOpen)) {
            this.onLeftOpen();
        }
        if (!storageUtils.getBoolean(Storage.RightButtonsOpen)) {
            this.onRightOpen();
        }
        this.scheduleOnce(() => { this._onMarquee(); }, mqLogic.mqSec);
        this.schedule(this._updatePer, 1);
        this.schedule(this._checkComingNewDay, 3);
    }

    /**
     * 每秒进入一次
     */
    protected _updatePer() {
        videoAdLogic.updatePerSec();
        this._updateNewServer();
        this._updateTopRankTime();
        this._updateLeftActStatu();
        udgLogic.updatePer();
    }

    /**
     * 检查是否进入到了新的一天
     */
    protected _checkComingNewDay() {
        if (this._lastCheckTs <= 0) {
            this._lastCheckTs = gm.getCurrentTimestamp();
        } else {
            let nowTs = gm.getCurrentTimestamp()
            let lastDate = new Date(this._lastCheckTs);
            let nowDate = new Date(nowTs);

            if (nowDate.getUTCDay() > lastDate.getUTCDay() ||
                nowDate.getUTCFullYear() > lastDate.getUTCFullYear() ||
                nowDate.getUTCMonth() > lastDate.getUTCMonth()) {
                console.log(`在线时跨天,开始刷新待刷新的数据 last:${this._lastCheckTs} now:${nowTs}`);
                this._comingNewDayRefresh();
            }
            this._lastCheckTs = nowTs;
        }
    }

    /**
     * 跨天数据刷新
     */
    protected _comingNewDayRefresh() {
        // 事件通知,界面接收后处理
        EManager.emit(EName.onComingNewDay);
        // 未打开界面的,直接请求更新数据
        this.checkDailyTaskRefresh();
    }

    protected checkDailyTaskRefresh() {
        let panel = BasePanel.getPanel('AssignmentPanel');
        if (panel) { console.log('任务界面已打开'); return; }

        assignmentLogic.tasksReq(0);
    }

    protected _checkBind() {
        // 直接用微信登录时,提交绑定进度
        if (gdk.checkIsUserBind(gssdk.loginData.roleId)) {
            assignmentLogic.bindAssignCommit();
        }
    }

    onEnable() {
        super.onEnable();

        let listener = EManager.addEvent(EName.onGotoView, (data: { goto: Goto, mission: Mission }) => {
            this._gotoView(data.goto, data.mission);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onGotoModule, (index: NavigateTabIndex) => {
            if (index == NavigateTabIndex.Battle || index == NavigateTabIndex.Home || index == NavigateTabIndex.Field) {
                this.gotoView(null, index.toString());
            }
            else {
                if (index == NavigateTabIndex.Hero && this.isOpenView2()) {
                    this.gotoView2(null, index.toString());
                }
                this.gotoView2(null, index.toString());
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onOpenPrivate, (data: { extra: ChatExtra, select?: boolean }) => {
            if (!BasePanel.getPanel("ChatPanel")) {
                let group = ChatUserData.saved.openPrivateTopic(data.extra);
                ChatPanel.LastChatGroup = group;
                this.onChat();
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onRewardFly, (cards) => {
            let top_node = this.topNode.loaderNode;
            let goldNode = top_node.getComponent(TopBar).getGoldNode();
            gm.rewardFly(cards, this.bagBtn, this.expNode, goldNode);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onLevelUp, (data) => {
            this._userLevelUp();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onActivityBtnFresh, (data) => {
            if (data == "activity") {
                this._checkActivityBtnValid(false);
            } else {
                this._checkLeftBtnValid();
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onMissionPass, (data) => {
            this._fightRed();
            this._checkActivityRed();
            this._checkLeftBtnValid();
            this._checkRightBtnValid();
            this._checkActivityBtnValid(false);
            this._checkPopFirstPay();
            this._checkUnlockSevenFund();
            this._checkZhuanPanRed();
            this._updateMedalInfo();

            let stageId: number = missionLogic.getCurrentMission().getStageId();
            commitLogic.missionPass(stageId - 1);
            arenaLogic.doUnlockArena();
            arenaSeniorLogic.doUnlockArena();
            this._checkUnlockHeroSchool(stageId - 1);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onApplyOrder, () => {
            if (activityLogic.isActivityValid(ActivityType.LeiChong)) {
                activityLogic.activityReq(ActivityType.LeiChong);
            }
            this._checkUnlockSevenFund();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onShow, () => {
            if (cc.isValid(this.videoPlayer)) {
                if (this.videoPlayer.node.active) {
                    this.videoPlayer.node.active = false;
                    this.videoPlayer.node.destroy();
                }
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onUpdateOnline, () => {
            if (!this._onlineInited) {
                this._initOnline();
            } else {
                this._refreshOnlineItem();
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onUpdateOnlineGuide, () => {
            this._refreshOnlineGuide();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onCostDiamond, (data) => {
            // 消耗钻石 
            console.log('消耗钻石:' + data);
            this._checkActRedCostDiamond(data as number);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onRecharge, (data) => {
            // 充值
            console.log('充值事件:' + data);
            this._checkActRedRecharge(data as number);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onClearGuideObstruct, (step: GuideBaseStep) => {
            if (step.guideId == 180002) {
                if (this._isLeftOpen) {
                    this.onLeftOpen();
                }
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onReportFail, (data) => {
            this.chatBar.active = false;
            this.arenaFail.getComponent(ArenaFailReport).refresh(data);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onReportClose, (data) => {
            this.chatBar.active = true;
        });
        this._eventListeners.push(listener);

        this.bubbleNode.active = false;
        this.schedule(this._scheduleBubble, 0.5);
    }

    update(dt: number) {
        super.update(dt);

        let isActive = false;
        for (let button of this.leftButtons) {
            if (button.active) {
                isActive = true;
                break;
            }
        }
        this.leftButtonContainer.opacity = isActive ? 255 : 0;

        isActive = false;
        for (let button of this.rightButtons) {
            if (button.active) {
                isActive = true;
                break;
            }
        }
        this.rightButtonContainer.opacity = isActive ? 255 : 0;

        if (GuideBaseStep.isGuiding && this.onlineGuide.active) {
            this.onlineGuide.active = false;
        }

        actTabLogic.update(dt);
        //supplyLogic.update(dt);
    }

    protected _scheduleBubble(dt: number) {
        let config = unlockConfigMap.家园;
        if (UnlockWrapper.isUnlock(config)) {
            this.bubbleNode.active = false;
            this.unschedule(this._scheduleBubble);
        }
        else {
            this.bubbleNode.active = this.redPoint.active;
        }
    }

    /**
     * 显示升级界面
     */
    protected async _userLevelUp() {
        try {
            let proto = await gm.request<ResourceVO>(GameProxy.apiRolegetLvUpReward);
            gcc.core.showLayer("prefabs/panel/player/PlayerLevelUp");
            if (proto) {
                gm.getReward(proto, false);
                let player = playerLogic.getPlayer();
                if (proto.roleVO) {
                    player.setLevelExp(proto.roleVO.lvExp);
                    player.setLevel(proto.roleVO.lv);
                    player.setExp(proto.roleVO.exp);
                }

                commitLogic.commitReward(proto, DiamondSource.levelup);
            }
            let level = playerLogic.getPlayer().getLevel();
            gssdk.logCommitTool.commitLevel(level, EventGroup.UserLevel);
            commitLogic.levelUp(level);
            rMissionLogic.updateRedPoint();

            heroLogic.artifactUnlockInfo && heroLogic.artifactUnlockInfo.addTaskProgress(3004);
        } catch (e) {
            if (e.name == "ToastError") {
                console.error("levelup error: " + e.message);
            }
            else {
                throw e;
            }
        }
    }

    protected _fightRed() {
        let cfg = unlockConfigMap.挑战;
        let unlock = UnlockWrapper.isUnlock(cfg);
        redPointLogic.setRedPointIgnore(RedPointType.Town, !unlock);
    }

    protected async _redFuncBind() {
        redPointLogic.addFunc(RedPointType.Bag, this._bagAllRed.bind(this));
        this._homeRightRed();
        this._fightRed();
        redPointLogic.freshAll();
    }

    protected _homeRightRed() {
        redPointLogic.setRedPointIgnore(RedPointType.HomeRight, this._isRightOpen);
    }

    protected _bagStoneRed() {
        let goods = bagLogic.getGoods(a => a.getGoodType() == GoodType.SoulStone || a.getGoodType() == GoodType.HeroPiece);
        for (let good of goods) {
            if (good.getAmount() >= bagLogic.getSoulStoneNeed()) {
                return true;
            }
        }
        return false;
    }

    protected _bagGoodRed() {
        let goods = bagLogic.getGoods(a => a.getGoodType() == GoodType.HeroRandom);
        return goods.length > 0;
    }

    protected _bagAllRed() {
        return this._bagGoodRed() || this._bagStoneRed();
    }

    protected _setActive(value: boolean, index: string) {
        this.topBar.active = value;

        if (gm.appReview) {
            this.leftButtonContainer.active = false;
        } else {
            this.leftButtonContainer.active = value;
            this.chatBar.active = value && !this.arenaFail.active;
            this.purityBtn.active = this._purityUnlock() && activityLogic.pioneer2CanShow;
            if (UnlockWrapper.isUnlock(unlockConfigMap.在线奖励)) {
                this._onlineForceHide = false;
                this.onlineBtn.active = !giftLogic.onlineFinished();
            }

            this.newServerBtn.active = activityLogic.isNewServerValid;
            this.topRankBtn.active = activityLogic.isCycleRankValid;
            this.artifactBtn.active = UnlockWrapper.isUnlock(unlockConfigMap.神器) && heroLogic.artifactUnlockInfo.artifactCanShow();
            this.artifactBtn.getComponent(ActivityArtifactBtn).refresh(null);
        }
        this.rightButtonContainer.active = value;
        this._validMarquee = true;
        if (index == NavigateTabIndex.Hero.toString()) {
            this.leftButtonContainer.active = false;
            this.rightButtonContainer.active = false;
            this.chatBar.active = false;
            this.purityBtn.active = false;
            this._onlineForceHide = true;
            this.onlineBtn.active = false;
            this.artifactBtn.active = false;
            this._validMarquee = false;
            this.newServerBtn.active = false;
            this.topRankBtn.active = false;
            this._hideMarqueeTxt();
        }
        if (this._areaIndex != NavigateTabIndex.Battle || this.isOpenView2()) {
            this.purityBtn.active = false;
            this.onlineBtn.active = false;
            this.artifactBtn.active = false;
            if (this.isOpenView2()) {
                this.newServerBtn.active = false;
                this.topRankBtn.active = false;
            }
        }
    }

    protected _heroClickTimestamp: number = 0;

    onHero() {
        let currentTimestamp = new Date().getTime();
        if (currentTimestamp - this._heroClickTimestamp < 400) {
            return;
        }
        this._heroClickTimestamp = currentTimestamp;
        this.gotoView2(null, NavigateTabIndex.Hero.toString());
    }

    onChat() {
        gcc.core.showLayer("prefabs/panel/chat/ChatPanel");

        if (playerLogic.getPlayer().getRenameCount() == 0) {
            gcc.core.showLayer("prefabs/panel/player/PlayerNamePanel", {
                modalTouch: true,
                layer: gcc.LayerType.INFO
            });
        }
    }

    onStore() {
        this.gotoView2(null, NavigateTabIndex.Store.toString());
    }

    gotoView(event: cc.Event.EventTouch, index: string) {
        let areaIndex = parseInt(index);
        if (areaIndex == NavigateTabIndex.Store) {
            if (!UnlockWrapper.isUnlock(unlockConfigMap.福利)) {
                gm.toast(unlockConfigMap.福利.tips);
                return;
            }
        }

        gm.heroTab = 1;
        this.popContentArea.destroyAllChildren();
        this._setActive(true, index);

        if (this.bottomButtons[this._areaIndex2]) {
            this.bottomButtons[this._areaIndex2].unfocus();
            this._areaIndex2 = -1;

            let button = this.bottomButtons[this._areaIndex];
            if (button) { button.focus(); }
        }

        if (this._areaIndex == areaIndex) {
            return;
        }
        let button = this.bottomButtons[this._areaIndex];
        if (button) { button.unfocus(); }
        this._areaIndex = parseInt(index);

        this.contentArea.removeAllChildren();
        let tabIndex = parseInt(index);
        let prefab = this.viewPrefabs[tabIndex];
        let view = prefab.data;
        view.parent = this.contentArea;

        commonUtils.reload(view);

        this._setActive(true, index);

        this.bottomButtons[this._areaIndex].focus();
    }

    gotoView2(event: cc.Event.EventTouch, index: string) {
        this.popContentArea.destroyAllChildren();

        let button = this.bottomButtons[this._areaIndex2];
        if (button) { button.unfocus(); }

        button = this.bottomButtons[this._areaIndex];
        if (button) { button.unfocus(); }

        if (this._areaIndex2 != parseInt(index)) {
            this._areaIndex2 = parseInt(index);
            this.bottomButtons[this._areaIndex2].focus();

            if (this._areaIndex2 == NavigateTabIndex.Hero) {
                let view = cc.instantiate(this.viewPrefabs[this._areaIndex2]);
                view.parent = this.popContentArea;

                this._setActive(true, index);
            }
        } else {
            gm.heroTab = 1;
            this._areaIndex2 = -1;
            this._setActive(true, "");

            if (button) { button.focus(); }
        }

        if (this._areaIndex2 == NavigateTabIndex.Store) {
            gcc.core.showLayer("prefabs/panel/market/MarketPanel", {
                data:
                {
                    closeCallback: () => { this.gotoView2(null, NavigateTabIndex.Store.toString()); }
                }
            });
        }
    }

    isOpenView2() {
        return this.popContentArea.children.length > 0;
    }

    /**
     * 从战场返回主界面的跳转
     * @param goto 跳转类型
     * @param mission 当前关卡
     */
    protected async _gotoView(goto: Goto, mission: Mission) {
        if (goto == Goto.BuildingInfo
            || goto == Goto.EditTroop
            || goto == Goto.ChapterPassed
            || goto == Goto.CountryPassed
            || goto == Goto.MainScene) {
            guideLogic.isPause = true;

            this.gotoView(null, NavigateTabIndex.Battle.toString());

            let currentBuilding = null;
            if (mission) {
                let building = missionLogic.getChapter(mission.getChapterId()).getBuilding(mission.getBuildingId());
                currentBuilding = missionLogic.getCurrentBuilding();
                if (building.isPassed()) {
                    if (building.getId() == 1) {
                        if (cc.sys.platform != cc.sys.WIN32
                            && cc.sys.platform != cc.sys.DESKTOP_BROWSER
                            && cc.sys.platform != cc.sys.MOBILE_BROWSER) {
                            if (cc.isValid(this.videoPlayer)) {
                                this.videoPlayer.remoteURL = `${gssdk.info.cdnUrl}/start.mp4`;
                                this.videoPlayer.keepAspectRatio = false;
                                this.videoPlayer.isFullscreen = true;
                                this.videoPlayer.node.active = true;
                                await commonUtils.sleep(2);
                            }
                        }
                    }

                    gm.showIndicator(100);
                    EManager.emit(Building.Event.onPassedDirty, { target: building });
                    await commonUtils.sleep(2);
                    if (currentBuilding) {
                        EManager.emit(Building.Event.onUnlockDirty, { target: currentBuilding });
                    }
                    gm.hideIndicator();
                }
            }

            if (goto == Goto.ChapterPassed || goto == Goto.CountryPassed) {
                let isCountryPassed = goto == Goto.CountryPassed;
                await this.showChapterPassed(mission, isCountryPassed);
            }

            guideLogic.isPause = false;

            if (mission && mission.isPassed()) {
                gm.isNewUnlock = true;
                for (let config of unlockConfig) {
                    if (config.newModule == 1) {
                        if (UnlockWrapper.isNewUnlock(config)) {
                            this._showUnlockModule(config);
                            return;
                        }
                    }
                    else if (config == unlockConfigMap.合成) {
                        if (UnlockWrapper.isNewUnlock(config)) {
                            guideLogic.guideId = 210001;
                            return;
                        }
                    }
                    else if (config == unlockConfigMap.克隆大作战) {
                        if (UnlockWrapper.isNewUnlock(config)) {
                            guideLogic.guideId = 230001;
                            return;
                        }
                    }
                    else if (config == unlockConfigMap.勋章) {
                        if (UnlockWrapper.isNewUnlock(config)) {
                            guideLogic.guideId = 300001;
                            return;
                        }
                    }
                    /*
                    if (supplyLogic.seniorStations[0].isUnlock) {
                        if (!storageUtils.getBoolean(Storage.FirstSeniorSupplyGuide)) {
                            storageUtils.setBoolean(Storage.FirstSeniorSupplyGuide.Key, true, true);
                            this._defaultSupplyTab = SupplyType.Senior;
                            guideLogic.guideId = 250001;
                            return;
                        }
                    }*/
                }
            }

            if (goto == Goto.BuildingInfo) {
                if (currentBuilding) {
                    gcc.core.showLayer("prefabs/panel/mission/BuildingInfoPanel", { data: currentBuilding });
                }
            }

            if (goto == Goto.EditTroop) {
                let mission = missionLogic.getCurrentMission();
                if (mission) {
                    gcc.core.showLayer("prefabs/panel/battle/BattlePreparePanel", { data: mission });
                }
            }
        }
        else if (goto == Goto.HeroList) {
            this.gotoView2(null, NavigateTabIndex.Hero.toString());
        }
        else if (goto == Goto.Evolution) {
            this.gotoView(null, NavigateTabIndex.Home.toString());
            gcc.core.showLayer("prefabs/panel/evolution/EvolutionPanel");
        }
    }

    checkButtonsOpen(step: GuideBaseStep) {
        if (!this._isRightOpen) {
            this.onRightOpen();
            step.delay += 0.5;
        }
    }

    onRightOpen() {
        this._isRightOpen = !this._isRightOpen;
        if (this._isRightOpen) {
            storageUtils.setBoolean(Storage.RightButtonsOpen.Key, true, true);

            this.rightOpenBtn.spriteFrame = this.openBtnFrames[1];
            for (let i = 0; i < this.rightButtons.length; i++) {
                if (i != RightButtonType.Task) {
                    this.rightButtonContainer.insertChild(this.rightButtons[i], i);
                }
            }
        }
        else {
            this.rightOpenBtn.spriteFrame = this.openBtnFrames[0];
            for (let i = 0; i < this.rightButtons.length; i++) {
                if (i != RightButtonType.Task) {
                    this.rightButtons[i].parent = null;
                }
            }
        }
        this._homeRightRed();
        redPointLogic.freshRedType(RedPointType.HomeRight);
    }

    async onLeftOpen() {
        this._isLeftOpen = !this._isLeftOpen;
        if (this._isLeftOpen) {
            storageUtils.setBoolean(Storage.LeftButtonsOpen.Key, true, true);

            this.leftOpenBtn.spriteFrame = this.openBtnFrames[1];
            for (let i = 0; i < this.leftButtons.length; i++) {
                if (i != LeftButtonType.FirstPay
                    && i != LeftButtonType.NewPlayerGift
                    && i != LeftButtonType.NpActivity
                    && i != LeftButtonType.BetterActivity
                    && i != LeftButtonType.Treasure
                    && i != LeftButtonType.WorldBoss
                    && i != LeftButtonType.ChessBoard
                    && i != LeftButtonType.Explore
                    && i != LeftButtonType.Surprise
                    && i != LeftButtonType.Activity
                    && i != LeftButtonType.HeroSchool
                    && i != LeftButtonType.BBX) {
                    this.leftButtonContainer.insertChild(this.leftButtons[i], i);
                }
            }
        } else {
            this.leftOpenBtn.spriteFrame = this.openBtnFrames[0];
            for (let i = 0; i < this.leftButtons.length; i++) {
                if (i != LeftButtonType.FirstPay
                    && i != LeftButtonType.NewPlayerGift
                    && i != LeftButtonType.NpActivity
                    && i != LeftButtonType.BetterActivity
                    && i != LeftButtonType.Treasure
                    && i != LeftButtonType.WorldBoss
                    && i != LeftButtonType.ChessBoard
                    && i != LeftButtonType.Explore
                    && i != LeftButtonType.Surprise
                    && i != LeftButtonType.Activity
                    && i != LeftButtonType.HeroSchool
                    && i != LeftButtonType.BBX) {
                    this.leftButtons[i].parent = null;
                }
            }
        }
        EManager.emit(EName.onRedDirty, PromptType.LeftMenuBtn);
        EManager.emit(EName.PromptRefresh);
        if (missionLogic.getCurrentMission().getStageId() - 1 == unlockConfigMap.七日签到.battleId) {
            await activityLogic.doGetSevenDaySignInfo();
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.Day7Sign);
        }
    }

    /**
     * 检测左侧按钮是否生效
     */
    protected _checkLeftBtnValid() {
        if (CC_PREVIEW) {
            let date = new Date(gm.getCurrentTimestamp());
            console.log(`服务器时间: ` + date.toUTCString());
            let time = playerLogic.getPlayer().getCreateTs();
            let createDate = new Date(time);
            console.log(`创号时间: ` + createDate.toUTCString());
        }

        let btnGift = this.leftButtons[LeftButtonType.Surprise];
        btnGift.active = benefitLogic.isSurpriseValid();
        if (btnGift.active) {
            let nodeTime = btnGift.getChildByName("time");
            nodeTime.active = benefitLogic.isSurpriseValid();
            if (nodeTime.active) {
                let labelTime = nodeTime.getComponent(cc.Label);
                labelTime.string = timeUtils.formatTime(benefitLogic.surpriseRemaintime);
                labelTime.schedule(() => {
                    if (benefitLogic.isSurpriseValid()) {
                        labelTime.string = timeUtils.formatTime(benefitLogic.surpriseRemaintime);
                    }
                    else {
                        this._checkLeftBtnValid();
                    }
                }, 1);
            }
        }

        let btnNewPlayerGift = this.leftButtons[LeftButtonType.NewPlayerGift];
        btnNewPlayerGift.active = benefitLogic.isNewPlayerValid()
        if (btnNewPlayerGift.active) {
            let nodeTime = btnNewPlayerGift.getChildByName("time");
            nodeTime.active = benefitLogic.isNewPlayerValid();
            if (nodeTime.active) {
                let labelTime = nodeTime.getComponent(cc.Label);
                let remainTime = benefitLogic.newPlayerRemaintime;
                if (remainTime < 24 * 3600) {
                    labelTime.string = timeUtils.formatTime(remainTime);
                }
                else {
                    labelTime.string = timeUtils.formatDay(remainTime * 1000);
                }
                labelTime.schedule(() => {
                    if (benefitLogic.isNewPlayerValid()) {
                        let remainTime = benefitLogic.newPlayerRemaintime;
                        if (remainTime < 24 * 3600) {
                            labelTime.string = timeUtils.formatTime(remainTime);
                        }
                        else {
                            labelTime.string = timeUtils.formatDay(remainTime * 1000);
                        }
                    }
                    else {
                        this._checkLeftBtnValid();
                    }
                }, 1);
            }
        }
        let cfg = unlockConfigMap.新手礼包;
        let unlock = UnlockWrapper.isUnlock(cfg);
        if (!unlock) {
            btnNewPlayerGift.active = false;
        }

        let btnFirstPay = this.leftButtons[LeftButtonType.FirstPay];
        btnFirstPay.active = rechargeLogic.isFirstPayValid();

        cfg = unlockConfigMap.首充礼包
        unlock = UnlockWrapper.isUnlock(cfg);
        if (!unlock) {
            btnFirstPay.active = false;
        }

        let btnHeroSchool = this.leftButtons[LeftButtonType.HeroSchool];
        cfg = unlockConfigMap.新手学堂;
        btnHeroSchool.active = UnlockWrapper.isUnlock(cfg) && activityLogic.heroSchoolvalid();

        for (let i = LeftButtonType.NpActivity; i < LeftButtonType.Len; i++) {
            let btn = this.leftButtons[i];
            btn.active = this._leftActValid(i);
        }

        let btnBBX = this.leftButtons[LeftButtonType.BBX];
        btnBBX.active = giftLogic.dailyLightModal && giftLogic.dailyLightModal.isBBXValid();
    }

    /**
     * 左侧部分活动设置按钮点击参数
     */
    protected _initLeftActBtnEventData() {
        for (let i = 0; i < LeftButtonType.Len; i++) {
            let btn = this.leftButtons[i].getComponent(cc.Button);
            if (btn && btn.clickEvents.length > 0) {
                btn.clickEvents[0].customEventData = `${i}`;
            }
        }
    }

    /**
     * 左侧部分活动是否显示
     * @param type 按钮类型
     */
    protected _leftActValid(type: LeftButtonType): boolean {
        let valid: boolean = true;
        if (type == LeftButtonType.NpActivity) {
            valid = actTabLogic.isTabValid(TabType.NewPlayerAct);
        } else if (type == LeftButtonType.BetterActivity) {
            valid = actTabLogic.isTabValid(TabType.BetterAct);
        } else if (type == LeftButtonType.Treasure) {
            valid = activityLogic.isActivityValid(ActivityType.Treasure);
        } else if (type == LeftButtonType.WorldBoss) {
            valid = activityLogic.isActivityValid(ActivityType.WorldBoss);
        } else if (type == LeftButtonType.ChessBoard) {
            valid = activityLogic.isActivityValid(ActivityType.CheckerBoard);
        } else if (type == LeftButtonType.Explore) {
            valid = activityLogic.isActivityValid(ActivityType.Explore);
        }
        return valid;
    }

    /**
     * 刷新左侧部分大型活动的状态
     */
    protected _updateLeftActStatu() {
        let type: number[] = [
            LeftButtonType.Treasure,
            LeftButtonType.WorldBoss,
            LeftButtonType.ChessBoard,
            LeftButtonType.Explore,
            LeftButtonType.BetterActivity,
            LeftButtonType.NpActivity]
        let keys = Object.keys(this._leftActStatu);
        if (keys.length <= 0) {
            for (let i = 0; i < type.length; i++) {
                this._leftActStatu[type[i]] = this._leftActValid(type[i]);
            }
        } else {
            let needRefresh: boolean = false;
            for (let i = 0; i < type.length; i++) {
                let newStatu: boolean = this._leftActValid(type[i]);
                if (this._leftActStatu[type[i]] != newStatu) {
                    needRefresh = true;
                }
                this._leftActStatu[type[i]] = newStatu;
            }
            if (needRefresh) {
                console.log('左侧活动状态有变化,重新刷新');
                this._checkLeftBtnValid();
            }
        }
    }

    /**
     * 检查右侧按钮是否生效
     */
    protected _checkRightBtnValid() {
        this.rightButtons[RightButtonType.Task].active = UnlockWrapper.isUnlock(unlockConfigMap.任务);
        this.rightButtons[RightButtonType.Friend].active = UnlockWrapper.isUnlock(unlockConfigMap.好友);
        this.rightButtons[RightButtonType.Mail].active = UnlockWrapper.isUnlock(unlockConfigMap.邮件);
        this.rightButtons[RightButtonType.Bag].active = UnlockWrapper.isUnlock(unlockConfigMap.背包);
    }

    /**
     * 检查活动按钮是否生效
     * @param flag 是否请求活动最新数据
     */
    protected async _checkActivityBtnValid(flag: boolean = true) {
        if (flag) {
            await activityLogic.doGetPioneer2Info();
        }
        let isUnlock = this._purityUnlock() && activityLogic.pioneer2CanShow;
        if (!this.isOpenView2() || !isUnlock) {
            this.purityBtn.active = isUnlock;
        }
        this.purityBtn.getComponent(ActivityPioneerBtn).refresh(null);

        if (flag) {
            await activityLogic.doGetSevenDaySignInfo();
        }
        let btnDay7 = this.leftButtons[LeftButtonType.Day7];
        btnDay7.active = false;
        if (activityLogic.isActivityValid(ActivityType.Day7Sign)) {
            if (flag && activityLogic.hasUnRecvSignReward) {
                gm.needCheckPopFirstPay = true;
                gcc.core.showLayer("prefabs/panel/activity/ActivitySignPanel", { data: { auto: true } });
            }
        }
        gm.checkArenaReport();

        if (flag) {
            await activityLogic.doGetSevenNewTaskInfo();
            await giftLogic.doGetDailyLightDetail();
        }
        let btnNewPlayer = this.leftButtons[LeftButtonType.NewPlayer];
        // btnNewPlayer.active = activityLogic.isActivityValid(ActivityType.NewPlayerTask);
        btnNewPlayer.active = false;

        let btnActivity = this.leftButtons[LeftButtonType.Activity];
        btnActivity.active = activityLogic.hasActivityValid;
        if (!UnlockWrapper.isUnlock(unlockConfigMap.活动)) {
            btnActivity.active = false;
        }
        btnActivity.active = false;

        let btnBBX = this.leftButtons[LeftButtonType.BBX];
        btnBBX.active = giftLogic.dailyLightModal && giftLogic.dailyLightModal.isBBXValid();

        let artifactActive = UnlockWrapper.isUnlock(unlockConfigMap.神器) && heroLogic.artifactUnlockInfo.artifactCanShow();
        if (!this.isOpenView2() || !artifactActive) {
            this.artifactBtn.active = artifactActive;
        }
        this.artifactBtn.getComponent(ActivityArtifactBtn).refresh(null);

        this.topRankBtn.active = activityLogic.isCycleRankValid;

        if (this._areaIndex != NavigateTabIndex.Battle || this.isOpenView2()) {
            this.purityBtn.active = false;
            this.onlineBtn.active = false;
            this.artifactBtn.active = false;
            if (this.isOpenView2()) {
                this.newServerBtn.active = false;
                this.topRankBtn.active = false;
            }
        }
    }

    protected async _checkOrderStatu() {
        if (rechargeLogic.orderIdList && rechargeLogic.orderIdList.length > 0) {
            let order = rechargeLogic.orderIdList[0];
            console.info("开始查询订单: " + order.orderId + " 剩余查询次数: " + order.checkTimes);
            let pushed: boolean = rechargeLogic.pushOrderList.some((v, i, a) => { return v == order.orderId; })
            if (pushed) {
                console.info("订单奖励已推送,取消查询.");
                rechargeLogic.orderIdList.shift();
            } else {
                if (order.checkTimes > 0) {
                    order.checkTimes -= 1;
                    let param = new PayOrderReq;
                    param.cdid = gm.districtId;
                    param.tradeOutNo = order.orderId;
                    let proto = await gm.request<PayOrderDO>(GameProxy.apipaycheckTrade, param);
                    if (proto && proto.resource) {
                        console.info("通过订单查询发放奖励!");
                        rechargeLogic.orderIdList.shift();
                        rechargeLogic.onReward(proto.resource);
                    }
                } else {
                    rechargeLogic.orderIdList.shift();
                }
            }
        }
    }

    /**
     * 好友界面
     */
    onFriend() {
        gcc.core.showLayer("prefabs/panel/friend/FriendPanel");
    }

    /**
     * 签到界面
     */
    onAssignment() {
        gcc.core.showLayer("prefabs/panel/assignment/AssignmentPanel");
    }

    /**
     * VIP界面
     */
    onVip() {
        gcc.core.showLayer("prefabs/panel/market/VIPPanel");
    }

    /**
     * 显示章节过关界面
     * @param mission 当前关卡
     * @param isCountryPassed 是否通关一个国家
     */
    async showChapterPassed(mission: Mission, isCountryPassed: boolean) {
        return new Promise((resolve, reject) => {
            let chapter = missionLogic.getChapter(mission.getChapterId());
            let chapterName = stringUtils.getString(stringConfigMap.key_chapter.Value, { chapter: chapter.getId() });
            gcc.core.showLayer("prefabs/panel/mission/ChapterPassedPanel", {
                data: {
                    name: `${chapterName}-${chapter.getCountryName()}${chapter.getName()}`,
                    isCountryPassed: isCountryPassed,
                    closeCallback: () => { resolve(); }
                }
            });
        });
    }

    /**
     * 背包界面
     */
    onBag() {
        gcc.core.showLayer("prefabs/panel/bag/BagPanel");
    }

    /**
     * 勋章界面
     */
    onMedal() {
        gcc.core.showLayer("prefabs/panel/medal/MedalMainPanel");
    }

    /**
     * 邮件界面
     */
    onMail() {
        gcc.core.showLayer("prefabs/panel/mail/MailPanel");
    }

    /**
     * 福利界面
     */
    onBenefit() {
        gcc.core.showLayer("prefabs/panel/benefit/BenefitPanel");
    }

    /**
     * 新手礼包
     */
    onNewPlayerGift() {
        gcc.core.showLayer("prefabs/panel/newplayer/NewPlayerGiftListPanel");
    }

    /**
     * 活动
     */
    onActivity() {
        gcc.core.showLayer("prefabs/panel/activity/ActivityPanel");
    }

    /**
     * 首充
     */
    onFirstPay() {
        gcc.core.showLayer("prefabs/panel/benefit/FirstPayPanel");
    }

    /**
     * 商城
     */
    onGift() {
        gcc.core.showLayer("prefabs/panel/market/MarketPanel");
    }

    /**
     * 7日签到
     */
    onSevenDay() {
        gcc.core.showLayer("prefabs/panel/activity/ActivitySignPanel");
    }

    /**
     * 新兵任务
     */
    onNewTask() {
        gcc.core.showLayer("prefabs/panel/activity/ActivityNew2Panel");
    }

    /**
     * 净化先锋
     */
    onPurity() {
        gcc.core.showLayer("prefabs/panel/activity/ActivityPurity2Panel");
    }

    /**
     * 视频事件回调
     * @param sender 视频组件 
     * @param event 事件类型
     */
    onVideoEvents(sender: cc.VideoPlayer, event: cc.VideoPlayer.EventType) {
        if (event === cc.VideoPlayer.EventType.READY_TO_PLAY) {
            this.videoPlayer.play();
        }
        else if (event === cc.VideoPlayer.EventType.COMPLETED) {
            this.videoPlayer.node.active = false;
            this.videoPlayer.node.destroy();
        }
    }

    /**
     * 左侧部分活动点击入口 新手活动,精彩活动,夺宝,世界boss,棋盘,大乱斗,探趣
     * @param sender 
     * @param customData 
     */
    onLeftActivityClick(sender: cc.Event.EventTouch, customData: string) {
        let type = parseInt(customData);
        if (type == LeftButtonType.NpActivity) {
            // actTabLogic.showTab(TabType.NewPlayerAct);
            this.onActivity();
        } else if (type == LeftButtonType.BetterActivity) {
            actTabLogic.showTab(TabType.BetterAct);
        } else if (type == LeftButtonType.Treasure) {
            gcc.core.showLayer("prefabs/panel/activity/ActivityRaiderPanel");
        } else if (type == LeftButtonType.WorldBoss) {
            gcc.core.showLayer("prefabs/panel/activity/ActivityWorldBossPanel");
        } else if (type == LeftButtonType.ChessBoard) {
            gcc.core.showLayer("prefabs/panel/chess/ChessPanel");
        } else if (type == LeftButtonType.Explore) {
            gcc.core.showLayer("prefabs/panel/activity/ActExplorePanel");
        } else {
            console.error(`未找到左侧活动类型: ${customData}`);
        }

    }

    onUnlockHome() {
        gm.isNewUnlock = true;
    }

    /**
     * 登录后检查限时礼包的弹出
     */
    protected _checkSurpriseGiftPop() {
        if (gm.appReview) return;

        let cfgs = benefitLogic.getBenefitStoreCfgs(6);
        cfgs = cfgs.filter((v, i, a) => {
            return benefitLogic.isSurpriseGiftValid(v.Id);
        })
        if (cfgs.length > 0) {
            cfgs.sort((a, b) => {
                let leftA = benefitLogic.getPopGiftLeftSec(a.Id);
                let leftB = benefitLogic.getPopGiftLeftSec(b.Id);
                return leftA - leftB;
            })
            let storeId = cfgs[0].Id;
            gcc.core.showLayer("prefabs/panel/benefit/SurpriseGiftPanel", { data: { Id: storeId } });
        }
    }

    /**
     * 通关后弹出首充礼包
     */
    protected _checkPopFirstPay() {
        if (gm.appReview) {
            return;
        }
        let passId: number = missionLogic.getCurrentMission().getStageId() - 1;
        let popId: number = defaultConfigMap.rechargepopup.value;
        let cost: number = rechargeLogic.getPayMoney();
        console.log(`pass:${passId} popId:${popId} cost:${cost}`);
        if (popId == passId && cost <= 0) {
            //gcc.core.showLayer("prefabs/panel/benefit/FirstPayPanel");
            gm.popFirstPay = true;
        }
    }

    /**
     * 活动解锁后红点刷新
     */
    protected async _checkActivityRed() {
        let stageId: number = missionLogic.getCurrentMission().getStageId() - 1;
        if (unlockConfigMap.新手光环.battleId == stageId) {
            this.scheduleOnce(() => {
                giftLogic.doGetDailyLightDetail().then(() => {
                    EManager.emit(EName.onUpdateActivityDatas, ActivityType.DailyLight);
                    let btnBBX = this.leftButtons[LeftButtonType.BBX];
                    btnBBX.active = giftLogic.dailyLightModal && giftLogic.dailyLightModal.isBBXValid();
                    this._checkActivityBtnValid(false);
                });
            }, 1);
        }
        if (unlockConfigMap.棋盘活动.battleId == stageId || unlockConfigMap.夺宝奇兵.battleId == stageId) {
            await activityLogic.doGetCycleActRank(0, 9);
            this.topRankBtn.active = activityLogic.isCycleRankValid;
        }
        if (unlockConfigMap.活动.battleId == stageId) {
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.NewServer);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.WorldBoss);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.Treasure);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.Explore);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.LeiXiao);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.LeiChong);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.SignNew);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.Day7Sign);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.Day7);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.Promotion);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.XiaoFeiDaRen);
            return;
        }

        if (unlockConfigMap.开服竞赛.battleId == stageId) {
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.NewServer);
        }
        if (unlockConfigMap.世界BOSS.battleId == stageId) {
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.WorldBoss);
        }
        if (unlockConfigMap.夺宝奇兵.battleId == stageId) {
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.Treasure);
        }
        if (unlockConfigMap.探趣寻宝.battleId == stageId) {
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.Explore);
        }
        if (unlockConfigMap.消费竞赛.battleId == stageId) {
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.LeiXiao);
        }
        if (unlockConfigMap.充值竞赛.battleId == stageId) {
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.LeiChong);
        }
    }

    protected _checkZhuanPanRed() {
        let stageId: number = missionLogic.getCurrentMission().getStageId() - 1;
        if (unlockConfigMap.寻宝.battleId == stageId) {
            EManager.emit(EName.onRedDirty, PromptType.ZhuanPanBtn);
        }
    }

    /**
     * 更新勋章信息
     */
    protected _updateMedalInfo() {
        let comp = this.expNode.getComponent(CommonLoader).loaderNode.getComponent(PlayerMain);
        comp.updateMedalInfo();
    }

    /**
     * 消耗钻石 活动红点检查
     * @param num 
     */
    protected _checkActRedCostDiamond(num: number) {
        // 消费达人
        let valid: boolean = activityLogic.isActivityValid(ActivityType.XiaoFeiDaRen);
        if (valid) { activityLogic.costDiamond(num); }
        // 累计消费
        if (activityLogic.isActivityValid(ActivityType.LeiXiao)) {
            let modal = activityLogic.getActivityConfigs(ActivityType.LeiXiao);
            if (modal) {
                for (let config of modal.configs) {
                    let tag = `${Math.floor(config.count * 100)}`;
                    let activityData = activityLogic.getActivityData(ActivityType.LeiXiao, tag);
                    if (activityData) {
                        activityData.changeCurValue(num);
                    }
                }
            }
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.LeiXiao);
        }
    }

    /**
     * 充值 活动数据更新
     * @param storeId 商品ID
     */
    protected async _checkActRedRecharge(storeId: number) {
        // 累充
        if (activityLogic.isActivityValid(ActivityType.LeiChong)) {
            await activityLogic.activityReq(ActivityType.LeiChong);
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.LeiChong);
        }

        // 新手任务中充值任务
        let cfg = cm.getStoreConfig(storeId);
        if (cfg) {
            if (activityLogic.sevenNew) {
                activityLogic.sevenNew.taskRecharge(cfg.money);
                EManager.emit(EName.onRedDirty, PromptType.LeftMenuBtn)

                let valid: boolean = activityLogic.isActivityValid(ActivityType.NewPlayerTask) || activityLogic.isActivityValid(ActivityType.NewPlayer2Task);
                let hasUnRecv: boolean = activityLogic.sevenNew && activityLogic.sevenNew.hasUnRecvTaskReward;
                let newPlayTaskRed: boolean = valid && hasUnRecv;
                if (newPlayTaskRed) {
                    promptLogic.setPrompt(15, true);
                }
            }
        }
    }

    /**
     * 新手基金解锁
     */
    protected async _checkUnlockSevenFund() {
        if (gm.appReview) {
            return;
        }
        if (UnlockWrapper.isUnlock(unlockConfigMap.新手基金) && rechargeLogic.hasStoreBuy) {
            await giftLogic.commitFuncTs();
            console.log("新手基金红点刷新");
            EManager.emit(EName.onRedDirty, PromptType.SevenFundBtn);
        }
    }

    protected _checkUnlockHeroSchool(passStage: number) {
        if (UnlockWrapper.isUnlock(unlockConfigMap.新手学堂)) {
            let ts = gm.getCurrentTimestamp();
            let unlockTs: number = storageUtils.getNumber(Storage.UnlockHeroSchoolTs);
            if (unlockTs <= 0) {
                storageUtils.setNumber(Storage.UnlockHeroSchoolTs.Key, ts);
                console.log('记录英雄学院通关时间:' + ts);
            }
        }
    }

    protected _purityUnlock() {
        if (UnlockWrapper.isUnlock(unlockConfigMap.净化先锋)) {
            return true;
        }
        return false;
    }

    /**
     * 在线礼包界面
     */
    onOnlineGift() {
        gcc.core.showLayer("prefabs/panel/online/OnlineRewardPanel", { modalTouch: true });
        if (!storageUtils.getBoolean(Storage.OnlineGuide) && this.onlineGuide.active) {
            storageUtils.setBoolean(Storage.OnlineGuide.Key, true, true);
            this._refreshOnlineGuide();
        }
    }

    protected async _initOnline() {
        this.onlineBtn.active = false;
        if (this._onlineInited) {
            return;
        }
        if (UnlockWrapper.isUnlock(unlockConfigMap.在线奖励)) {
            await giftLogic.doGetOnlineDetail();
            this._refreshOnlineItem();
            onlineTimeWidget.init(gm.getCurrentTimestamp() / 1000, this);
            this._onlineInited = true;
        }
    }

    protected async _updateNewServer() {
        if (this.newServerBtn.active) {
            this.newServerBtn.active = activityLogic.isNewServerValid;
            if (this.newServerBtn.active) {
                // 开服竞赛倒计时
                let node = this.newServerBtn.getChildByName('time');
                node.getComponent(cc.Label).string = stringUtils.formatTimeWithHour(activityLogic.newServerRemainTime / 1000);
            }
        }
    }

    /**
     * 新服竞赛
     */
    onNewServer() {
        gcc.core.showLayer("prefabs/panel/activity/ActivityNewServerPanel");
    }

    protected async _updateTopRank() {
        if (this.topRankBtn.active) {
            this.topRankBtn.active = activityLogic.isCycleRankValid;
            if (this.topRankBtn.active) {
                this._updateTopRankTime();
            }
        }
    }

    protected _updateTopRankTime() {
        if (this.topRankBtn.active) {
            if (activityLogic.cycleRankRemainTime <= 0) {
                this.topRankBtn.active = false;
            } else {
                let id = cm.activeList.indexOf(activityLogic.cycleRankType) + 2;
                let text = this.topRankBtn.getChildByName('text').getComponent(cc.Sprite);
                loadUtils.loadSpriteFrame(`textures/ui/main/top_rank_text${id}`, text);
                let icon = this.topRankBtn.getChildByName('icon').getComponent(cc.Sprite);
                loadUtils.loadSpriteFrame(`textures/ui/main/top_rank_icon${id}`, icon);
                let node = this.topRankBtn.getChildByName('time');
                node.getComponent(cc.Label).string = stringUtils.formatTimeWithHour(activityLogic.cycleRankRemainTime / 1000);
            }
        }
    }

    onTopRank() {
        gcc.core.showLayer("prefabs/panel/activity/ActivityTopRankPanel");
    }

    protected _refreshOnlineItem() {
        let lastUnRecvId = giftLogic.getLastUnRecvDetail();
        if (giftLogic.onlineFinished()) {
            this.onlineBtn.active = false;
            onlineTimeWidget.stopOnlineTime();
            return;
        }
        if (lastUnRecvId == -1) {
            return;
        }
        this.onlineBtn.active = true;
        if (!storageUtils.getBoolean(Storage.OnlineGuide)) {
            let lastUnRecv = giftLogic.getLastUnRecv();
            if (lastUnRecv != -1) {
                this.onlineGuide.active = true;
            }
        } else {
            this.onlineBtn.active = !giftLogic.onlineFinished();
        }
        let loaderNode = this.onlineBtn.children[0];
        loaderNode.getComponent(OnlineItem).refresh({ id: lastUnRecvId, homeShow: true });
        if (loaderNode.getComponent(cc.Button)) {
            loaderNode.removeComponent(cc.Button);
        }
    }

    protected _refreshOnlineGuide() {
        this.onlineGuide.active = !storageUtils.getBoolean(Storage.OnlineGuide);
    }

    protected _showUnlockModule(config: unlockConfigRow) {
        gcc.core.showLayer("prefabs/panel/unlock/UnlockModulePanel", {
            data: {
                config: config,
                go: (name: string) => {
                    if (name == "家园") {
                        this.gotoView(null, NavigateTabIndex.Home.toString());
                    }
                    else {
                        this.gotoView(null, NavigateTabIndex.Field.toString());
                    }
                }
            }
        });
    }

    onHeroSchool() {
        gcc.core.showLayer("prefabs/panel/hero/HeroSchoolPanel");
    }

    onBaiBaoXiang() {
        gcc.core.showLayer("prefabs/panel/activity/ActivityBBXPanel");
    }

    protected _defaultSupplyTab: number = SupplyType.Normal;

    onSupply() {
        gcc.core.showLayer("prefabs/panel/supply/SupplyMapPanel", { data: this._defaultSupplyTab });
    }

    async onArtifact() {
        gm.heroTab = 3;
        let newArtifactId = heroLogic.artifactUnlockInfo.getNewArtifactId();
        if (newArtifactId > 0) {
            gcc.core.showLayer("prefabs/panel/equip/ArtifactNewPanel", {
                data: { artifactId: newArtifactId },
                callback: () => {
                    this.gotoView2(null, NavigateTabIndex.Hero.toString());

                    let panel = BasePanel.getPanel("ArtifactNewPanel");
                    BasePanel.Panels.remove(panel);
                    BasePanel.Panels.push(panel);
                }
            });
        }
        else {
            this.gotoView2(null, NavigateTabIndex.Hero.toString());
        }
    }

    /**
     * 定时播放跑马灯内容
     */
    protected _onMarquee() {
        // console.log('定时跑马灯开始');
        this.marquee.active = false;
        let mq = this.marquee.getComponent(Marquee);
        if (!UnlockWrapper.isUnlock(unlockConfigMap.跑马灯) || mq.isRunning() || !this._validMarquee) {
            this.scheduleOnce(() => { this._onMarquee(); }, mqLogic.mqSec);
            return;
        }

        let data = mqLogic.getMessage();
        if (!data) {
            this.scheduleOnce(() => { this._onMarquee(); }, mqLogic.mqSec);
            if (data) { mqLogic.addMessage(data); }
            return;
        }

        let cfg = data.getCfg();
        if (cfg) {
            mqLogic.mqMoveSec = cfg.cxtime;
            mqLogic.mqSec = mqLogic.mqMoveSec + cfg.jgtime;
            this._showMarqueeTxt(data.getContent());
        }
        this.scheduleOnce(() => { this._onMarquee(); }, mqLogic.mqSec);
    }

    protected _showMarqueeTxt(txt: string) {
        if (!this.marquee) { return; }
        let mq = this.marquee.getComponent(Marquee);
        if (!mq) { return; }
        console.log('开始跑马灯');
        mq.show(txt);
    }

    protected _hideMarqueeTxt() {
        if (!this.marquee) { return; }
        let mq = this.marquee.getComponent(Marquee);
        if (!mq) { return; }
        mq.hide();
    }
}