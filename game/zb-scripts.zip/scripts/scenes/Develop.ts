import { WonderExtraReq } from './../proxy/GameProxy';
import FightRoot from "../view/fight/FightRoot";
import HeroView from "../view/fight/HeroView";
import guideLogic from "../logics/GuideLogic";
import EManager, { EName } from "../manager/EventManager";
import DevelopTool from "../../dev/DevelopTool";
import wisdomTreeLogic from "../logics/WisdomTreeLogic";
import chatSocket from "../socket/ChatSocket";
import arenaLogic from "../logics/ArenaLogic";
import cm from '../manager/ConfigManager';
import wonderSpaceLogic from "../logics/WonderSpaceLogic";
import gm from '../manager/GameManager';
import GameProxy from '../proxy/GameProxy';
import dungeonLogic from '../logics/DungeonLogic';
import Info from '../Info';
import pushManager from "../manager/PushManager";
import ad from '../manager/AdManager';
import Player from '../data/user/Player';

const { ccclass, property, menu } = cc._decorator;

/**
 * 开发调试场景（只会在开发模式下生效）
 */
@ccclass
@menu("scenes/Develop")
export default class Develop extends gcc.Scene {

    @property(cc.Label)
    labelVersion: cc.Label = null;

    @property(cc.Prefab)
    playerTool: cc.Prefab = null;

    @property(cc.Prefab)
    battleTool: cc.Prefab = null;

    @property(cc.Prefab)
    developTool: cc.Prefab = null;

    @property(cc.Prefab)
    chessTool: cc.Prefab = null;

    @property(cc.RichText)
    richText: cc.RichText = null;

    private _enterGame: boolean = false;

    start() {
        cc.sys.garbageCollect();
        gcc.injectCompatibleObject();
        rpgfight.useSafeProperty = true;

        if (window["wx"]) {
            // 子域排行榜需要先初始化
            if (gdk.getOpenDataContext && typeof gdk.getOpenDataContext == "function") {
                gdk.getOpenDataContext().postMessage({ action: "initSubDomain", value: '' })
            }
        }
        core.init()
        core.debugLayer.zIndex = 600;

        let develop = new DevelopTool();
        develop.init(this.developTool, this.playerTool, this.battleTool, this.chessTool);
        develop.registerDefault()
        develop.showDevelopButton()

        logicchart.statetree.devlog.enabled = false
        develop.registerCheck("英雄状态日志开关", () => logicchart.statetree.devlog.enabled, (value) => {
            logicchart.statetree.devlog.enabled = value
        })

        let isFightLogEnabled = true
        develop.registerCheck("英雄战斗日志开关", () => isFightLogEnabled, (value) => {
            isFightLogEnabled = value
            if (this.fightRoot) {
                this.fightRoot.setFightLogEnabled(value)
            }
        })

        let videoLoading = ad ? !ad.videoLoaded : false;
        develop.registerCheck('视频加载中', () => videoLoading, (value) => {
            videoLoading = value;
            if (ad) { ad.setVideoLoadingStatu(value); }
        })

        develop.registerInput('竞技场测试', "开始竞技测试", () => "", async (value: string) => {

            HeroView.isDebugMode = true

            let oldNode = this.node.getChildByName('fightNode')
            if (oldNode) {
                oldNode.removeFromParent()
                oldNode.destroy()
            }

            //创建战斗视图
            let fightNode = cc.find('fightNode', this.node) || new cc.Node('fightNode')
            let root = fightNode.addComponent(FightRoot);

            let rawdata: {
                heroList: rpgfight.HeroConfig[],
                scene: rpgfight.SceneConfig,
                inputDataVersion: string,
                battleNo: string,
                rivalRoleId: string,
                roleId: string,
            } = JSON.parse(value)

            let heroList: rpgfight.HeroConfig[] = rawdata.heroList.map(rawHeroCfg => {
                let attackCfg = new rpgfight.SkillConfig(rpgfight.Config.getTriggerData(rawHeroCfg.attackSkill!.triggerTreeName!)!);
                this.assignObjectBasicValue(attackCfg, rawHeroCfg.attackSkill)

                let skillList = (rawHeroCfg.skillList || []).map(skillCfg => {
                    let skill = new rpgfight.SkillConfig(rpgfight.Config.getTriggerData(skillCfg.triggerTreeName!)!)
                    this.assignObjectBasicValue(skill, skillCfg)
                    return skill
                })

                let heroCfg = new rpgfight.HeroConfig(attackCfg, skillList)
                this.assignObjectBasicValue(heroCfg, rawHeroCfg)

                return heroCfg
            })

            let scene = new rpgfight.SceneConfig()
            this.assignObjectBasicValue(scene, rawdata.scene)

            let data = new rpgfight.NormalData(scene, heroList);

            root.startFight(data);
            root.setFightLogEnabled(isFightLogEnabled)

            this.fightRoot = root

            fightNode.parent = this.node
        });

        develop.registerButton("智慧树工具", () => {
            return true;
        }, () => {
            let wisdomDevelop = new DevelopTool();
            wisdomDevelop.registerInput('智慧树修改关卡', "修改", () => "1-1", async (value: string) => {
                EManager.emit(EName.onWisdomModifyStage, value);
            });
            wisdomDevelop.registerInput('增加/减少果实', "修改", () => '', async (value: string) => {
                EManager.emit(EName.onWisdomAddFruit, value);
            });
            wisdomDevelop.registerCheck("获得果实", () => {
                return wisdomTreeLogic.wisdomTreeGetFruit;
            }, (value: boolean) => {
                EManager.emit(EName.onWisdomSetFruitValue, value);
            });
            wisdomDevelop.registerButton("重置智慧树", () => {
                return true;
            }, () => {
                EManager.emit(EName.onWisdomReset);
            });
            wisdomDevelop.registerInput('修改过关次数', "修改", () => "0", async (value: string) => {
                EManager.emit(EName.onWisdomModifyCloud, Number(value));
            });
            wisdomDevelop.showDevelopDialog(develop.developTool);
        });

        develop.registerButton("聊天测试工具", () => {
            return true;
        }, () => {
            let chatDevelop = new DevelopTool();
            chatDevelop.registerCheck("聊天日志", () => {
                return chatSocket.isDebugChatLog;
            }, (value: boolean) => {
                chatSocket.isDebugChatLog = value;
            });

            chatDevelop.registerCheck("聊天时间限制", () => {
                return chatSocket.isChatTimeLimit;
            }, (value: boolean) => {
                chatSocket.isChatTimeLimit = value;
            });
            chatDevelop.showDevelopDialog(develop.developTool);
        });

        develop.registerButton("修改玩家数值", () => {
            return true;
        }, () => {
            let node = cc.instantiate(develop.playerTool);
            node.parent = core.debugLayer;
        });

        develop.registerButton("棋盘数据测试", () => { return true }, () => {
            let node = cc.instantiate(develop.chessTool);
            node.parent = core.debugLayer;
        });

        develop.registerButton("战斗测试工具", () => { return true }, () => {
            let node = cc.instantiate(develop.battleTool);
            node.parent = core.debugLayer;
        });

        develop.registerInput("设置战斗版本", "设置", () => '', async (value: string) => {
            gm.fightVersion = Number(value);
        });

        develop.registerInput('普通竞技场回放', "回放", () => '', async (value: string) => {
            this._pvpBack(value);
        });

        develop.registerInput('高阶竞技场回放', "回放", () => '', async (value: string) => {
            this._pvpBack(value, true);
        });

        develop.registerInput('设置新手任务', "修改", () => '', async (value: string) => {
            EManager.emit(EName.onActivityNewProgress, value);
        });

        develop.registerButton("奇妙时空测试工具", () => {
            return true;
        }, () => {
            let wonderDevelop = new DevelopTool();
            wonderDevelop.registerInput('重置当前关卡', "重置", () => "1", async (value: string) => {
                if (wonderSpaceLogic.wonderOpenedChapter) {
                    wonderSpaceLogic.resetWonder(wonderSpaceLogic.wonderOpenedChapter.id);
                }
            });
            wonderDevelop.registerInput('进入奇妙时空', "进入", () => "1", async (value: string) => {
                gcc.core.showLayer("prefabs/panel/wonderspace/WonderSpacePanel", { data: Number(value) });
            });
            wonderDevelop.registerInput('重置奇妙时空积分', "重置", () => "1", async (value: string) => {
                wonderSpaceLogic.resetWonderScore(Number(value));
            });
            wonderDevelop.registerInput('重置奇妙时空迷雾', "重置", () => "1", async (value: string) => {
                wonderSpaceLogic.resetWonderExtraFog();
            });
            wonderDevelop.registerInput('一键清除迷雾', "清除", () => "1", async (value: string) => {
                wonderSpaceLogic.clearWonderExtraFog();
            });
            wonderDevelop.registerInput('增加/减少果实', "修改", () => '', async (value: string) => {
                let fruits = value.split(';');
                for (let id of fruits) {
                    if (id != "") {
                        if (parseInt(id) > 0) {
                            wonderSpaceLogic.doFruitAdd(parseInt(id));
                        } else {
                            wonderSpaceLogic.doFruitSub(Math.abs(parseInt(id)));
                        }
                    }
                }
            });
            wonderDevelop.showDevelopDialog(develop.developTool);
        });

        develop.registerButton('重置地牢探险', () => {
            return true;
        }, () => {
            let req = new WonderExtraReq();
            req.pairs = [];
            for (let key in dungeonLogic.keys) {
                req.pairs.push({ key: dungeonLogic.keys[key], objData: null });
            }
            req.stageId = dungeonLogic.globalDungeonId;
            gm.request(GameProxy.apidungeonputDungeonExtra, req);

            req = new WonderExtraReq();
            req.pairs = [];
            for (let key in dungeonLogic.saveKeys) {
                req.pairs.push({ key: dungeonLogic.saveKeys[key], objData: null });
            }
            req.stageId = dungeonLogic.globalDungeonId;
            gm.request(GameProxy.apidungeonputDungeonExtraSave, req);
        });

        develop.registerInput('重置英雄地牢数据', '重置', () => '', (value: string) => {
            let req = new WonderExtraReq();
            req.pairs = [];
            for (let key in dungeonLogic.keys) {
                req.pairs.push({ key: dungeonLogic.keys[key], objData: null });
            }
            req.stageId = Number(value);
            gm.request(GameProxy.apidungeonputDungeonExtra, req);

            req = new WonderExtraReq();
            req.pairs = [];
            for (let key in dungeonLogic.saveKeys) {
                req.pairs.push({ key: dungeonLogic.saveKeys[key], objData: null });
            }
            req.stageId = Number(value);
            gm.request(GameProxy.apidungeonputDungeonExtraSave, req);
        });

        develop.registerButton('推送测试工具', () => {
            return true;
        }, () => {
            let pushDevelop = new DevelopTool();
            pushDevelop.registerCheck("推送测试小时变秒", () => {
                return localStorage.getItem("pushDebug") && localStorage.getItem("pushDebug") == "1";
            }, (value: boolean) => {
                localStorage.setItem("pushDebug", value ? "1" : "0");
                pushManager.pushDebug = value;
            });
            pushDevelop.registerInput('测试一条推送', "测试", () => "60", async (value: string) => {
                let notice: GDK.LocalPushBundle = new GDK.LocalPushBundle();
                notice.title = "怪物别戳我";
                notice.identifier = "99";
                notice.content = "测试一条推送";
                notice.interval = Number(value);
                gdk.removeAllLocalNotices();
                gdk.addLocalNotices([notice]);
            });
            pushDevelop.showDevelopDialog(develop.developTool);
        });

        develop.registerButton("隐藏调试", () => {
            return true;
        }, () => {
            develop.hideDevelopButton();
            cc.debug.setDisplayStats(false);
            Info.mode = 'test';
        });

        develop.registerButton("打印战力", () => {
            return true;
        }, () => {
            Player.LogEnabled = true;
        });

        develop.registerInput("测试服账号", "登陆", () => '', async (value: string) => {
            GDK.UserAPI.prototype.login = function (params?: GDK.LoginParams): Promise<GDK.LoginResult> {
                const ret = new GDK.RPromise<GDK.LoginResult>();

                this._m.user.server.loginTest({ loginCode: Number(value), node: params.node }, (resp) => {
                    if (resp.succeed) {
                        const data = resp.data
                        const userdata = this.userData
                        userdata.channelId = data.channelId
                        userdata.createTime = data.createTime
                        userdata.userId = data.userId
                        localStorage.setItem('sdk_glee_userId', `${data.userId}`)
                        userdata.followGzh = data.followGzh
                        userdata.nickName = data.nickname
                        userdata.isNewUser = data.userNew

                        this.systemInfo.tableConf = resp.data.tableConf;//记录登录时传入的表格信息

                        ret.success({
                            extra: data,
                        })
                    }
                    else {
                        ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.UNKNOWN, {
                            data: {
                                extra: resp,
                            }
                        }))
                    }
                }, () => {
                    ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.NETWORK_ERROR));
                });

                return ret.promise;
            }

            develop.hideDevelopDialog();

            this.enterGuide(null);
        });

        develop.registerInput("正式服账号", "登陆", () => '', async (value: string) => {
            GDK.UserAPI.prototype.login = function (params?: GDK.LoginParams): Promise<GDK.LoginResult> {
                const ret = new GDK.RPromise<GDK.LoginResult>();

                this._m.user.server.loginTest({ loginCode: Number(value), node: params.node }, (resp) => {
                    if (resp.succeed) {
                        const data = resp.data
                        const userdata = this.userData
                        userdata.channelId = data.channelId
                        userdata.createTime = data.createTime
                        userdata.userId = data.userId
                        localStorage.setItem('sdk_glee_userId', `${data.userId}`)
                        userdata.followGzh = data.followGzh
                        userdata.nickName = data.nickname
                        userdata.isNewUser = data.userNew

                        this.systemInfo.tableConf = resp.data.tableConf;//记录登录时传入的表格信息

                        ret.success({
                            extra: data,
                        })
                    }
                    else {
                        ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.UNKNOWN, {
                            data: {
                                extra: resp,
                            }
                        }))
                    }
                }, () => {
                    ret.fail(GDK.GDKResultTemplates.make(GDK.GDKErrorCode.NETWORK_ERROR));
                });

                return ret.promise;
            }

            develop.hideDevelopDialog();

            Info.accountServer = "usaccount.mosoga.net";
            Info.gameUrl = "zombieiiplus.mosoga.net";
            Info.bussinessServer = "ipirate.mosoga.net";

            this.enterGuide(null);
        });
    }

    preloadList: string[] = []

    protected assignObjectBasicValue(target: any, source: any) {
        for (let key of Object.keys(source)) {
            let value = source[key]
            let t = typeof (value)
            if (t == "number" || t == "boolean" || t == "string") {
                target[key] = value
            }
        }
    }

    fightRoot?: FightRoot

    // update (dt) {}

    onInit(data: any) {

    }

    enterGuide(event: cc.Event.EventTouch) {
        if (this._enterGame) { return; }
        this._enterGame = true;
        core.pushScene("LoadingScene");
    }

    enterGame() {
        //进入第一个场景
        if (this._enterGame) { return; }
        this._enterGame = true;
        guideLogic.noGuide = true;
        core.pushScene("LoadingScene");
    }

    clearCache() {
        localStorage.clear();
    }

    protected async _pvpBack(no: string, high: boolean = false) {
        cm.init();
        await arenaLogic.doArenaPlayBack(0, `https://cdn-game-record.mosoga.net/10100/${high ? "highArena" : "arena"}/${no}.json`);
        gcc.core.showLayer("prefabs/panel/battle/BattlePVPRecordPanel", {
            data: {
                battleData: arenaLogic.getBattleData(),
                troops: {
                    selfTroop: arenaLogic.getArenaHero().selfHero,
                    enemyTroop: arenaLogic.getArenaHero().enemyHero,
                },
                sceneConfig: arenaLogic.getBattleScene(),
                skills: {},
            },
            layer: gcc.LayerType.DEBUG
        });
    }
}
