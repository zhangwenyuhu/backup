import { FightViewPool } from "./FightViewPool";
import { effectViewConfigRow } from "../../configs/effectViewConfig";
import HeroView from "./HeroView";
import mathUtils from "../../utils/MathUtils";
import FightViewFactory from "./FightViewFactory";
import { SharedHeroEffectView } from "./SharedHeroEffectView";
import cm from "../../manager/ConfigManager";

export class HeroEffectView extends rpgfight.SkillView {
	root: cc.Node = new cc.Node("HeroEffectView");
	animRoot: cc.Node = null as any
	effectConfig: effectViewConfigRow
	skeleton: sp.Skeleton
	spineNode: cc.Node
	nodeName: string

	protected _positionDirty: boolean = false;

	constructor(
		public effectId: string,
		owner: rpgfight.Hero,
		skillData: rpgfight.SkillData
	) {
		super(effectId, owner, skillData)

		if (this.owner.manager && (this.owner.manager as any).skip) {
			return;
		}

		if (effectId == null) {
			console.error(`effectId is null`)
			return
		}

		if (effectId == 'none') {
			// 表示没有特效
			return
		}

		let effectConfig = cm.getEffectView(Number(effectId))
		if (effectConfig == null) {
			console.error(`缺少id为[${effectId}]的特效配置`)
			return
		}

		this.effectConfig = effectConfig
		let name = effectConfig.Path
		let bLoop = effectConfig.Loop
		let mountPoint = effectConfig.MountPoint
		let layerIndex = effectConfig.LayerIndex
		let shallAutoHide = effectConfig.AutoHide || false
		let nodeName = `hero_effect_${effectConfig.Id}`;
		this.nodeName = nodeName

		let onLoad = (animRoot: cc.Node, spineNode: cc.Node, skeleton: sp.Skeleton) => {
			// 避免还未加载到，就已经移除了
			if (!this.isAlive) {
				return
			}

			if (!cc.isValid(this.root)) {
				return
			}

			spineNode.name = "spine"
			this.spineNode = spineNode
			this.setMountPoint(this.root, mountPoint, layerIndex)

			this.skeleton = skeleton
			if (!bLoop) {
				//加载完立即执行相关命令
				this.completeHandler = () => {
					// this.unmount(nodeName)
					if (shallAutoHide) {
						this.root.active = false
					}
				}
			}
			this.playDefaultEffect()

			if (this.animPaused) {
				this.pause()
			} else {
				this.resume()
			}
		}

		let animRoot = FightViewPool.inst.get(nodeName)
		if (!animRoot) {
			FightViewPool.inst.getSpine(`spine/${name}`, (spineNode, skeleton) => {
				if (cc.isValid(this.root)) {
					this.animRoot = new cc.Node(nodeName);
					this.animRoot.parent = this.root;
					this.animRoot.width = spineNode.width;
					this.animRoot.height = spineNode.height;
					spineNode.parent = this.animRoot;
					onLoad(animRoot, spineNode, skeleton)
				}
			})
		} else {
			this.animRoot = animRoot;
			this.animRoot.parent = this.root;

			let spineNode = this.animRoot.getChildByName("spine")
			onLoad(animRoot, spineNode, spineNode.getComponent(sp.Skeleton))
		}
	}

	protected setMountPoint(node: cc.Node, mountPoint: string, layerIndex: number): void {
		let factory = this.owner.manager.viewFactory as FightViewFactory;
		let effectView = factory.getSharedEffectView() as SharedHeroEffectView;

		if (!!mountPoint) {
			if (layerIndex == 0) {
				let heroView = this.owner.view as HeroView
				heroView.addToMountPoint(node, mountPoint)
				if (!this.effectConfig.overturn) {
					node.scaleX = -heroView.root.scaleX;
				}
			} else {
				let heroView = this.owner.view as HeroView
				let p = heroView.getCurrentMountPoint(mountPoint)
				node.position = cc.p(this.owner.position.x, this.owner.position.y).add(cc.p(p.position.x, p.position.y))

				let parent = layerIndex < 0 ? effectView.rootBg : effectView.root;
				node.parent = parent
				node.zIndex = layerIndex
				if (this.effectConfig.overturn) {
					node.scaleX = heroView.root.scaleX;
				}
				else {
					node.scaleX = -heroView.root.scaleX;
				}
			}
		} else {
			let heroView = this.owner.view as HeroView
			if (!this._positionDirty) {
				node.position = cc.p(this.owner.position.x, this.owner.position.y);
			}
			else {
				this._positionDirty = false;
			}
			let parent = layerIndex < 0 ? effectView.rootBg : effectView.root;
			node.parent = parent
			node.zIndex = layerIndex
			if (this.effectConfig.overturn) {
				node.scaleX = heroView.root.scaleX;
			}
			else {
				node.scaleX = -heroView.root.scaleX;
			}
		}
	}

	protected unmount(name: string) {
		if (cc.isValid(this.animRoot) && this.animRoot.parent) {
			this.animRoot.parent = null
			FightViewPool.inst.put(name, this.animRoot)
			this.animRoot = null
			this.spineNode = null
		}
		this.root.removeFromParent()
		this.root.destroy()
	}

	protected setAnimation(trackIndex: number, name: string, loop: boolean) {
		let anim = this.skeleton.findAnimation(name)
		if (anim == null) {
			const tip = `动画缺失：英雄 [${this.nodeName}] 缺少动画：[${name}]`
			console.warn(tip);
			return;
		}
		this.skeleton.setAnimation(trackIndex, name, loop);
		return anim;
	}

	protected addAnimation(trackIndex: number, name: string, loop: boolean, delay?: number) {
		let anim = this.skeleton.findAnimation(name);
		if (anim == null) {
			const tip = `动画缺失：英雄 [${this.nodeName}] 缺少动画：[${name}]`
			console.warn(tip)
			if (HeroView.isDebugMode) {
				setTimeout(() => {
					core.toast(tip)
				}, 0)
			}
		}
		this.skeleton.addAnimation(trackIndex, name, loop, delay);
		return anim;
	}

	setParent(p: cc.Node) {
		if (!this.root.parent) {
			this.root.parent = p
		}
	}

	completeHandler?: Function

	/**
	 * 播放默认多段动画
	 */
	playDefaultEffect(): void {
		if (this.owner.manager && (this.owner.manager as any).skip) {
			return;
		}


		let anims = this.effectConfig.Anim
		let bLoop = this.effectConfig.Loop
		if (anims.length == 1) {
			this.setAnimation(0, anims[0], bLoop);
			this.skeleton.setCompleteListener(() => { this.completeHandler && this.completeHandler() });
		}
		else if (anims.length > 1) {
			this.setAnimation(0, anims[0], false);
			this.skeleton.setCompleteListener(() => {
				this.setAnimation(0, anims[1], false);
			});

			if (this.duration > 0) {
				let loopDuration = this.duration;
				for (let i = 2; i < anims.length; i++) {
					let anim = this.skeleton.findAnimation(anims[i]);
					if (anim) loopDuration -= anim.duration * 1000;
				}
				this.skeleton.scheduleOnce(async () => {
					this.skeleton.setCompleteListener(null);
					try {
						for (let i = 2; i < anims.length; i++) {
							await this.playAnimation(anims[i]);
						}
					} catch (error) {
						// undo
					}
				}, loopDuration / 1000);
			}
		}
	}

	async playAnimation(animation: string) {
		return new Promise((resolve, reject) => {
			this.setAnimation(0, animation, false);
			this.skeleton.setCompleteListener(resolve);
			this.skeleton.setDisposeListener(reject);
			this.skeleton.setInterruptListener(reject);
		});
	}

	animPaused: boolean = false

	pause() {
		this.animPaused = true
		if (this.skeleton) {
			this.skeleton.paused = true
		}
	}

	resume() {
		this.animPaused = false
		if (this.skeleton) {
			this.skeleton.paused = false
		}
	}

	setTimeScale(value: number) {
		if (this.skeleton) {
			this.skeleton.timeScale = value
		}
	}

	destroy(): void {
		this.unmount(this.nodeName)
		super.destroy()
	}

	setPosition(p: ml.Point, isRotation?: boolean): void {
		let position = this.root.position;
		this.root.position = cc.p(p.x, p.y)
		this._positionDirty = true;
		if (isRotation) {
			let delta = cc.v2(this.root.x - position.x, this.root.y - position.y);
			if (delta.x != 0 || delta.y != 0) {
				let angle = delta.normalize().signAngle(cc.v2(this.owner.direction == rpgfight.HeroDirection.Right ? 1 : -1, 0));
				let rotation = mathUtils.deg(angle);
				this.root.rotation = rotation;
			}
		}
	}

	/**
	 * 设置旋转角度
	 * @param angle 
	 */
	setRotation(angle: number) {
		this.root.setRotation(angle);
	}

	/**
	 * 设置长度
	 * @param length 
	 */
	setWidth(value: number) {
		if (cc.isValid(this.animRoot) && this.animRoot.width > 0) {
			this.animRoot.scaleX = value / this.animRoot.width;
		}
	}

	setScaleX(scaleX: number) {
		this.root.scaleX = scaleX;
	}
}
