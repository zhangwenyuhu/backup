import { EName } from './../../manager/EventManager';
import Hero from "../../data/card/Hero";
import loadUtils from "../../utils/LoadUtils";
import EManager from "../../manager/EventManager";
import heroUtils from '../../utils/HeroUtils';
import gm from '../../manager/GameManager';
import Npc from '../../data/card/Npc';
import commonUtils from '../../utils/CommonUtils';

const { ccclass, property, menu } = cc._decorator;

/**
 * 战斗上阵界面的站位组件
 */
@ccclass
@menu("view/fight/FightStation")
export default class FightStation extends cc.Component {
    @property(cc.Sprite)
    spriteStation: cc.Sprite = null;

    @property(sp.Skeleton)
    skeleton: sp.Skeleton = null;

    @property(cc.Node)
    levelBg: cc.Node = null;

    @property(cc.Sprite)
    spriteFaction: cc.Sprite = null;

    @property(cc.Label)
    labelLevel: cc.Label = null;

    @property(cc.Node)
    moveArea: cc.Node = null;

    @property(cc.Sprite)
    dutyIcon: cc.Sprite = null;

    protected _hero: Hero = null;
    protected _isMoved: boolean = false;
    protected _originPosition: cc.Vec2;
    protected _startPosition: cc.Vec2;
    protected _moveAreaPosition: cc.Vec2;
    protected _stationNo: number = 0;
    protected _isSelf: boolean = false;
    protected _releaseCallback: Function = null;
    protected _labelNo: cc.Label = null;
    protected _isPressed: boolean = false;

    init(labelNo: cc.Label, stationNo: number, isSelf: boolean, releaseCallback?: Function) {
        this._labelNo = labelNo;
        this._stationNo = stationNo;
        this._isSelf = isSelf;
        this._releaseCallback = releaseCallback;
        this.levelBg.active = false;
    }

    start() {
        this._moveAreaPosition = cc.v2(this.moveArea.x, this.moveArea.y);
    }

    onEnable() {
        if (this._isSelf) {
            this.moveArea.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
            this.moveArea.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
            this.moveArea.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
            this.moveArea.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this);
        }
        else {
            this.moveArea.on(cc.Node.EventType.TOUCH_END, () => {
                if (this._hero) {
                    if (CC_DEBUG) {
                        gcc.core.showLayer("prefabs/panel/hero/HeroDetailPanel", { data: this._hero, modalWindow: true, modalTouch: true });
                    }
                    EManager.emit(EName.onFightStationClick, this);
                }
            }, this);
        }
    }

    onDisable() {
        if (this._isSelf) {
            this.moveArea.off(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
            this.moveArea.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
            this.moveArea.off(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
            this.moveArea.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouchEnd, this);
        }
        else {
            this.moveArea.off(cc.Node.EventType.TOUCH_END);
        }
    }

    protected updateHeroStar() {
        if (this.moveArea) {
            let star = this.moveArea.getChildByName('stars');
            if (star) {
                star.active = this._hero ? true : false;
                if (this._hero) {
                    for (let i = 0; i < star.childrenCount; i++) {
                        star.children[i].active = i < this._hero.getStar();
                    }
                }
            }
        }
    }

    async updateView(hero: Hero, isMoved: boolean = false) {
        if (this._hero == hero) {
            return;
        }
        this._hero = hero;
        this.updateHeroStar();
        if (hero) {
            if (this._labelNo) this._labelNo.node.active = false;

            if (hero instanceof Npc) {
                this.moveArea.off(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
                this.moveArea.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
                this.moveArea.off(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
            }

            let info = heroUtils.getHeroQualityInfo(hero.getRank());

            this.skeleton.node.active = true;
            this.skeleton.node.scaleX = this._isSelf ? 1 : -1;
            gm.createHeroSpine(hero, this.skeleton, undefined, !this._isSelf);

            this.levelBg.active = true;
            this.spriteFaction.spriteFrame = cc.loader.getRes(`textures/icon/hero/hero_tag_${hero.getFaction()}`, cc.SpriteFrame) as cc.SpriteFrame;
            this.labelLevel.string = `Lv.${hero.getLevel()}`;
            if (hero.getSharePosition() > 0) {
                this.labelLevel.node.color = cc.Color.YELLOW;
            }
            else {
                this.labelLevel.node.color = cc.Color.WHITE;
            }

            loadUtils.loadSpriteFrame(commonUtils.getHeroBattleStationUrl(info.qualityHead), this.spriteStation);

            if (hero.getHeroType() == rpgfight.HeroType.Hero) {
                loadUtils.loadSpriteFrame(`textures/ui/panel/battle/hero_duty_${hero.getDuty()}`, this.dutyIcon);
            }
            else {
                this.dutyIcon.spriteFrame = null;
            }
        }
        else {
            if (this._labelNo) this._labelNo.node.active = true;
            this.spriteStation.spriteFrame = null;
            this.dutyIcon.spriteFrame = null;

            let skeletonData = this.skeleton.skeletonData;
            this.skeleton.skeletonData = null;
            (this.skeleton as any)._updateSkeletonData();
            this.skeleton.node.active = false;
            this.levelBg.active = false;
            if (!this._isMoved) {
                if (this._releaseCallback) {
                    this._releaseCallback(skeletonData);
                }
            }
        }
    }

    onClick() {
        if (this._hero) {
            EManager.emit(EName.onFightStationSelected, { hero: this._hero, position: this._stationNo });
        }
    }

    resetMoveArea() {
        this.moveArea.position = cc.v2(this._moveAreaPosition.x, this._moveAreaPosition.y);
        this.moveArea.parent = this.node;
    }

    setPositionForStation(station: FightStation) {
        station.moveArea.position = cc.v2(this._moveAreaPosition.x, this._moveAreaPosition.y);
        station.moveArea.parent = this.node;
    }

    get stationNumber(): number {
        return this._stationNo;
    }

    getHero(): Hero {
        return this._hero;
    }

    onTouchStart(e: cc.Event.EventTouch) {
        if (!this.skeleton.skeletonData) return;

        let position = this.moveArea.convertToWorldSpaceAR(cc.v2());
        let parent = this.node.parent.parent;
        this.moveArea.position = parent.convertToNodeSpaceAR(position);
        this.moveArea.parent = parent;
        this._isMoved = false;
        this._originPosition = this.moveArea.position;
        this._startPosition = this.moveArea.parent.convertToNodeSpaceAR(e.getLocation());
        this._isPressed = true;
    }

    onTouchMove(e: cc.Event.EventTouch) {
        if (!this._isPressed) return

        let distance = e.getLocation().sub(e.getStartLocation()).mag();
        if (distance < 10) return;

        let position = this.moveArea.parent.convertToNodeSpaceAR(e.getLocation());
        this.moveArea.position = this._originPosition.add(position.sub(this._startPosition));
        this._isMoved = true;
        EManager.emit(EName.onFightStationMoved, this);
    }

    onTouchEnd(e: cc.Event.EventTouch) {
        if (!this._isPressed) return
        this._isPressed = false;

        this.resetMoveArea();
        if (this._isMoved) {
            EManager.emit(EName.onFightStationChanged, this);
        }
        else {
            this.onClick();
        }
    }
}
