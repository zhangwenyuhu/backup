import { EName } from './../../manager/EventManager';
import { FightViewPool } from "./FightViewPool";
import EManager from "../../manager/EventManager";
import FightHpBar from './FightHpBar';
import BuffView from "./BuffView";
import effectViewConfig, { effectViewConfigRow } from "../../configs/effectViewConfig";
import heroConfig from '../../configs/heroConfig';
import cm from '../../manager/ConfigManager';
import am from '../../manager/AudioManager';
import gm from '../../manager/GameManager';
import { BattleType } from '../../utils/DefineUtils';
import Hero from '../../data/card/Hero';

/**
 * 用于播放英雄的spine动画
 */
export default class HeroView extends rpgfight.View {

    root: cc.Node = new cc.Node("HeroView");

    spineNode: cc.Node;
    hpBar: cc.Node;

    skeleton: sp.Skeleton;

    /**
     * 当前播放的动画
     */
    currentAnim: string = null;

    /**
     * 当前的动画是否循环
     */
    currentLoop: boolean = false;

    isLoaded: boolean = false;

    flip: boolean = false;
    scale: number = 1;

    static isDebugMode = false

    protected _resPath: string = "";
    protected _skin: string = "";

    constructor(
        /**
         * 加载的资源id
         */
        public resId: string,
        public owner: rpgfight.Hero,
    ) {
        super();

        this.root.name = "hero_" + resId;

        let enterCloseUp = rpgfight.Hero.prototype.enterCloseUp;
        this.owner.enterCloseUp = (context: logicchart.trigger.Context) => {
            enterCloseUp.call(this.owner);
            if (this.owner.isInCloseUp) {
                this._onEnterCloseUp();
            }
        }

        let enterCloseUpForce = rpgfight.Hero.prototype.enterCloseUpForce;
        this.owner.enterCloseUpForce = (context: logicchart.trigger.Context) => {
            enterCloseUpForce.call(this.owner);
            if (this.owner.isInCloseUp) {
                this._onEnterCloseUp();
            }
        }

        let leaveCloseUp = rpgfight.Hero.prototype.leaveCloseUp;
        this.owner.leaveCloseUp = (context: logicchart.trigger.Context) => {
            leaveCloseUp.call(this.owner);
            if (!this.owner.isInCloseUp) {
                this._onLeaveCloseUp();
            }
        }

        let heroCfg = heroConfig.filter(cfg => ("" + cfg.Id) == this.owner.heroData.config.heroConfigId)[0]
        let skin = ""
        let heroScale = 1
        if (heroConfig) {
            skin = heroCfg.skin
            heroScale = heroCfg.scaling
        }
        this._skin = skin;

        let resPath = "spine/hero/" + resId
        this._resPath = resPath;
        FightViewPool.inst.getSpineInst(resPath, resPath, (err, node, sk) => {
            if (err) {
                return
            }

            if (!cc.isValid(this.root)) {
                return
            }

            node.name = "spine";
            this.spineNode = node;
            this.spineNode.position = cc.v2();
            this.skeleton = sk;

            this.setScale(heroScale)

            this._addHpBar(owner);
            this.root.addChild(this.spineNode);

            if (skin) {
                sk.setSkin(skin);
            }

            if (this.currentAnim != null) {
                //加载完立即执行相关命令
                this.setAnimation(0, this.currentAnim, this.currentLoop);
            }
            this.isLoaded = true;

            this._addMessageHandlerCallbacks(owner);
            this._loadSpineFinished(sk.skeletonData);
        });
    }

    protected _loadSpineFinished(res: sp.SkeletonData) {
        // override
    }

    protected _addMessageHandlerCallbacks(owner: rpgfight.Hero) {
        owner.stateTree.addMessageHandleCallback(rpgfight.HeroState.Dead, (message: logicchart.statetree.StatusEventMessage) => {
            switch (message.params.stateStage) {
                case 'onenter': {
                    // 击杀者
                    let killer = owner.killer!
                    this.onKill(killer, owner);

                    if (this.isAlive) {
                        this.isAlive = false
                        this.onDead(owner)
                    }
                    break
                }
            }
        });
    }

    protected _addHpBar(owner: rpgfight.Hero) {
        if (gm.battleType == BattleType.Hunt
            || gm.battleType == BattleType.WorldBoss
            || gm.battleType == BattleType.Treasure) {
            return;
        }

        let index = Number(owner.heroData.heroConfigId);
        let config = cm.getHeroConfig(index);
        let url = ""
        if (config.Blood > 0) {
            url = 'prefabs/fight/fight_boss_hp_bar';
        }
        else {
            url = 'prefabs/fight/fight_hp_bar';
        }

        cc.loader.loadRes(url, cc.Prefab, (error, res: cc.Prefab) => {
            if (error) {
                console.error(error)
            }
            if (!cc.isValid(this.root)) {
                return
            }

            let bar = new cc.Node("hpBar");
            bar.position = cc.v2(0, config.Hpheight);
            this.root.addChild(bar);
            this.hpBar = bar;

            let node = cc.instantiate(res);
            node.position = cc.v2();
            node.parent = bar;

            let comp = node.getComponent(FightHpBar);
            comp.initWithFightHero(owner, this.root);
            if (config.Blood > 0) {
                comp.setWidth(config.Blood);
            }
        })
    }

    buffViewList: { [key: number]: BuffView } = {};
    updateBuffView() {
        let buffList = this.owner.runner.manager.buffManager.filterBuffForHero(this.owner) as rpgfight.HeroBuff[]
        let existList: { [key: number]: BuffView } = {};
        let hasBuff = false;
        for (let buff of buffList) {
            if (buff.name == "无敌") {
                hasBuff = true;
            }

            let buffConfig: effectViewConfigRow = null;
            if (buff.name == "护盾" && buff.sender instanceof rpgfight.Hero) {
                buffConfig = cm.getBuffEffectView(buff.name, buff.sender.heroData.heroConfigId);
            }
            else {
                buffConfig = cm.getBuffEffectView(buff.name.split("-")[0], (buff.owner as rpgfight.Hero).heroData.heroConfigId)
            }
            if (!buffConfig) continue;

            if (buff.theSkill && buffConfig.MountPoint == 'headbuff') {
                let skillId = Number(buff.theSkill.config.skillId);
                let config = cm.getSkillConfig(skillId);
                if (config) {
                    if (config.fruitskill > 0
                        || Math.floor(config.Id / 1000) == 998) {
                        continue;
                    }
                }
            }
            let view = this.buffViewList[buffConfig.Id];
            if (!view) {
                view = new BuffView(buffConfig.Id.toString(), this.owner, buff);
                this.buffViewList[buffConfig.Id] = view;
            }
            existList[buffConfig.Id] = view;
        }

        if (cc.isValid(this.hpBar)) {
            this.hpBar.active = !hasBuff;
        }

        let removeIds: number[] = [];
        for (let id in this.buffViewList) {
            if (!existList[id]) {
                removeIds.push(Number(id));
            }
        }
        for (let id of removeIds) {
            let view = this.buffViewList[id];
            if (view) view.destroy();
            delete this.buffViewList[id];
        }
        this.buffViewList = existList;
    }

    protected clearBuffView() {
        for (let id in this.buffViewList) {
            this.buffViewList[id].destroy();
        }
        this.buffViewList = {};
    }

    isAlive: boolean = true

    /**击杀敌人回调 */
    onKill(killer: rpgfight.Hero, victim: rpgfight.Hero) {
        EManager.emit(EName.onHeroKill, { hero: this.owner, killer: killer, victim: victim });
    }

    /**
     * 英雄死亡回调
     */
    onDead(hero: rpgfight.Hero) {
        EManager.emit(EName.onHeroDead, hero);
    }

    revive() {
        EManager.emit(EName.onHeroRevive, this.owner);
    }

    setParent(p: cc.Node) {
        this.root.parent = p
    }

    getHeroName() {
        let index = Number(this.owner.heroData.heroConfigId);
        // let config = cm.getHeroConfig(index);
        let config = heroConfig.find(cfg => cfg.Id == index)
        return config.Name
    }

    play(name: string, loop: boolean): void {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        //循环的动画 不重新播放
        if (this.currentAnim == name && this.currentLoop == loop && loop) {
            return;
        }

        this.currentAnim = name;
        this.currentLoop = loop;
        if (this.isLoaded) {
            //播放动画
            this.setAnimation(0, this.currentAnim, this.currentLoop);
        }
    }

    playAudio(name: string, loop: boolean): void {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }
        if (this.owner.manager.battleType == BattleType.Hangup) {
            return;
        }
        am.playEffect(`skill/${name}`, loop);
    }

    protected setAnimation(trackIndex: number, name: string, loop: boolean) {
        let anim = this.skeleton.findAnimation(name)
        if (anim == null) {
            const tip = `动画缺失：英雄 [${this.getHeroName()}] 缺少动画：[${name}]`
            console.warn(tip)
            return;
        }
        this.skeleton.setAnimation(trackIndex, name, loop);
    }

    setSkin(skin: string) {
        if (skin.length > 0) {
            this.skeleton.setSkin(skin);
        }
        else {
            this.skeleton.setSkin(this._skin);
        }
    }

    setPosition(p: ml.Point): void {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        this.root.x = p.x;
        this.root.y = p.y;
        let zIndex = Math.floor(-p.y)
        if (this.owner.battleTeam == rpgfight.BattleTeam.our) {
            zIndex++
        }
        this.root.zIndex = zIndex;
    }

    setScale(scale: number): void {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        this.scale = scale;
        this.refreshScale();
    }

    setDirection(dir: number): void {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        if (dir == 1) {
            this.flip = false;
        } else if (dir == -1) {
            this.flip = true;
        }
        this.refreshScale();
    }

    /**
     * 设置英雄飞行的高度
     * @param value 高度值
     */
    setFlyHeight(value: number): void {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        this.spineNode.y = value;
    }

    /**
     * 高亮
     */
    highlight() {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        EManager.emit(EName.onHighlight, { hero: this.owner, root: this.root });
    }

    /**
     * 震屏
     */
    shake() {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        EManager.emit(EName.onShakeScreen, this.owner);
    }

    protected refreshScale() {
        if (this.flip) {
            this.root.scaleX = -this.scale;
        } else {
            this.root.scaleX = this.scale;
        }
        this.root.scaleY = this.scale;
    }

    /**
     * 进入技能特写
     */
    protected _onEnterCloseUp() {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        if (this.owner.battleTeam == rpgfight.BattleTeam.enemy) {
            if (!this.owner.manager.effectViewManager.isEnemyCloseupEnabled) {
                return;
            }
        }
        EManager.emit(EName.onUseHeroSkill, this.owner);
        EManager.emit(EName.onEnterHeroCloseUp, { hero: this.owner, root: this.root });
    }

    /**
    * 离开技能特写
    */
    protected _onLeaveCloseUp() {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        if (this.owner.battleTeam == rpgfight.BattleTeam.enemy) {
            if (!this.owner.manager.effectViewManager.isEnemyCloseupEnabled) {
                return;
            }
        }
        EManager.emit(EName.onLeaveHeroCloseUp, { hero: this.owner, root: this.root });
    }

    hide() {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        if (this.spineNode) {
            this.spineNode.active = false
        }
    }
    show() {
        if (this.spineNode) {
            this.spineNode.active = true
        }
    }

    resume() {
        if (this.skeleton) {
            this.skeleton.paused = false
        }
    }

    pause() {
        if (this.skeleton) {
            this.skeleton.paused = true
        }
    }

    setTimeScale(value: number) {
        if (this.skeleton) {
            this.skeleton.timeScale = value
        }
    }

    destroy() {
        this.clearBuffView()
        if (this.root.parent) {
            this.root.removeFromParent();
            if (this.spineNode && cc.isValid(this.spineNode)) {
                this.spineNode.parent = null;
                FightViewPool.inst.put(this._resPath, this.spineNode);
            }
        }
    }

    update(dt: number, hero: rpgfight.Hero) {
        if (this.owner.manager && (this.owner.manager as any).skip) {
            return;
        }

        this.updateBuffView();
        if (this.spineNode) {
            this.spineNode.opacity = hero.heroData.opacityRealtime;
        }
        if (this.hpBar) {
            this.hpBar.opacity = hero.heroData.opacityRealtime;
        }
        EManager.emit(EName.onUpdateFightHero, { fightHero: hero, spineNode: this.spineNode });
    }

    getCurrentMountPoint(mountPoint: string) {
        if (!this.spineNode) return;

        let nodeName = `*${mountPoint}`
        let slotNode: cc.Node = this.spineNode.getChildByName(nodeName)
        if (!slotNode) {
            slotNode = new cc.Node(nodeName)
            this.spineNode.addChild(slotNode)

            if (mountPoint == "headbuff") {
                let layout = slotNode.addComponent(cc.Layout);
                layout.type = cc.Layout.Type.HORIZONTAL;
                layout.resizeMode = cc.Layout.ResizeMode.CONTAINER;
                layout.spacingX = 50;

                (slotNode as any).noScale = true;
            }
        }
        return slotNode
    }

    addToMountPoint(node: cc.Node, mountPoint: string) {
        if (!this.spineNode) return;

        let nodeName = `*${mountPoint}`
        let slotNode: cc.Node = this.spineNode.getChildByName(nodeName)
        if (!slotNode) {
            slotNode = new cc.Node(nodeName)
            this.spineNode.addChild(slotNode)

            if (mountPoint == "headbuff") {
                let layout = slotNode.addComponent(cc.Layout);
                layout.type = cc.Layout.Type.HORIZONTAL;
                layout.resizeMode = cc.Layout.ResizeMode.CONTAINER;
                layout.spacingX = 50;

                (slotNode as any).noScale = true;
            }
        }
        if (slotNode) {
            if (mountPoint == "headbuff") slotNode.scaleX = this.root.scaleX;
            node.parent = slotNode
        } else {
            console.error(`不存在特效挂载槽点: ${mountPoint}`)
        }
    }

    heroCallback(key: string, params: any[]) {
        EManager.emit(EName.onHeroCallback, { key: key, params: params });
    }
}