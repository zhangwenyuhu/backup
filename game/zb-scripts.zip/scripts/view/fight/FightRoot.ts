import EManager from "../../manager/EventManager";
import { BattleType } from '../../utils/DefineUtils';
import { EName } from './../../manager/EventManager';
import FightViewFactory from "./FightViewFactory";
import HeroView from "./HeroView";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/fight/FightRoot")
export default class FightRoot extends cc.Component {
    manager: rpgfight.ManagerBase;
    dt: number = 0;

    // LIFE-CYCLE CALLBACKS:
    update(dt: number) {
        if (this.manager == null) {
            return;
        }

        this.dt += dt * 1000;
        let fixedTimestep = this.manager.runner.frameStep;
        if (this.dt >= fixedTimestep) {
            this.manager.runner.update();
            this.dt -= fixedTimestep;
        }
    }

    get fightManager(): rpgfight.ManagerBase {
        return this.manager;
    }

    /**
     * 设置是否启用战斗日志
     */
    setFightLogEnabled(b: boolean) {
        if (this.manager) {
            this.manager.devLog.enableRuntimeLog = b
        }
        rpgfight.devLog.enabled = b
        rpgfight.Config.isDebugMode = b
        HeroView.isDebugMode = b
    }

    /**
     * 直接结束战斗
     * @param win 是否我方胜利
     */
    finishGame(win: boolean) {
        if (win) {
            this.manager.finishGame(rpgfight.BattleTeam.our)
        } else {
            this.manager.finishGame(rpgfight.BattleTeam.enemy)
        }
    }

    protected _createFactory(): FightViewFactory {
        return new FightViewFactory();
    }

    startFight(data: any, battleType?: BattleType) {
        if (data) {
            //普通类型的战斗
            let fightViewFactory = this._createFactory();
            fightViewFactory.defaultViewRoot = this.node

            let manager = null;
            if (battleType == BattleType.PVP ||
                battleType == BattleType.PVP_PlayBack ||
                battleType == BattleType.PVP_Senior ||
                battleType == BattleType.PVP_Senior_Record) {
                manager = new rpgfight.ArenaManager(data, fightViewFactory);
            }
            else if (battleType == BattleType.PVE ||
                battleType == BattleType.Tower ||
                battleType == BattleType.Hunt ||
                battleType == BattleType.Maze ||
                battleType == BattleType.Record ||
                battleType == BattleType.Friend ||
                battleType == BattleType.Treasure ||
                battleType == BattleType.WorldBoss ||
                battleType == BattleType.WonderSpace ||
                battleType == BattleType.Dungeon ||
                battleType == BattleType.Material ||
                battleType == BattleType.UnionDungeon ||
                battleType == BattleType.UnionWar ||
                battleType == BattleType.Clone) {
                manager = new rpgfight.BattleManager(data, fightViewFactory);
            }
            else {
                manager = new rpgfight.NormalManager(data, fightViewFactory);
            }
            this.manager = manager;
            manager.onOurHeroDeadAll = () => { this.onOurHeroDeadAll() }
            manager.onEnemyDeadAll = () => { this.onEnemyDeadAll() }
            manager.onGameTimeout = () => { this.onGameTimeout() }
            manager.onGameResult = (options) => { this.onGameResult(options) }
            manager.gameStart(battleType);
        }

    }

    onGameResult(options: {
        /**
         * 我方胜利
         */
        win: boolean,
    }) {
        if (this.manager instanceof rpgfight.ArenaManager) {
            console.log("竞技场战损统计:", this.manager.getContributionResult())
        }
        // console.log("战斗日志汇总：", this.manager.devLog.serializeRecords())
    }

    /**
     * 新加入英雄
     * @param heroConfig 
     */
    addHeroWithHeroConfig(heroConfig: rpgfight.HeroConfig) {
        if (this.manager) {
            this.manager.addHeroWithHeroConfig(heroConfig)
        }
    }

    /**
     * 所有友军死亡
     */
    onOurHeroDeadAll() {
        EManager.emit(EName.onSelfTroopDead, { type: this.manager.battleType });
    }
    /**
     * 所有敌人死亡
     */
    onEnemyDeadAll() {
        EManager.emit(EName.onEnemyTroopDead, { type: this.manager.battleType });
    }
    /**
     * 游戏超时
     */
    onGameTimeout() {
        EManager.emit(EName.onGameTimeout, { type: this.manager.battleType });
    }

    /**
     * 主动激活大招
     * @param heroId 
     */
    activeTheSkill(heroId: string) {
        if (this.manager) {
            this.manager.robotPlayer.activeHeroSkillWithHeroId(heroId)
        }
    }

    /**
     * 取消激活大招
     * @param heroId      
     */
    deactiveTheSkill(heroId: string) {
        if (this.manager) {
            this.manager.robotPlayer.deactiveHeroSkillWithHeroId(heroId)
        }
    }

    pause() {
        if (this.manager) {
            this.manager.runner.pause()
        }
    }
    resume() {
        if (this.manager) {
            this.manager.runner.resume()
        }
    }

    /**
     * 丢弃战役，清理战场
     */
    abortBattle() {
        if (this.manager) {
            this.manager.abortBattle()
            this.manager = null
        }
    }
}
