import { NodePoolV2 } from "./NodePoolV2";

export class MyNodePool {
	protected _nodePoolMap: { [key: string]: cc.NodePool } = {};

	get(name: string): cc.Node | null {
		let pool = this._nodePoolMap[name];
		if (pool) { return pool.get(); }
	}

	size(name: string): number {
		let pool = this._nodePoolMap[name];
		if (pool) { return pool.size() }
		return 0;
	}

	put(name: string, node: cc.Node, allowParent: boolean = false) {
		if ((!allowParent) && node.parent) {
			console.error("不可回收的节点，存在外部依赖")
			node.parent = null
		}
		if (!cc.isValid(node)) {
			console.error("不可回收的节点，过期节点")
		}

		let pool = this._nodePoolMap[name];
		if (!pool) {
			pool = new cc.NodePool();
			this._nodePoolMap[name] = pool;
		}
		return pool.put(node);
	}

	clear(name: string) {
		let pool = this._nodePoolMap[name]
		if (pool) {
			pool.clear()
			delete this._nodePoolMap[name]
		}
	}

	clearAll() {
		for (let key in this._nodePoolMap) {
			this._nodePoolMap[key].clear();
		}
		this._nodePoolMap = {};
	}
}
