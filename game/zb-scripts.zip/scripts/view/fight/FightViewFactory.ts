import HeroView from "./HeroView";
import { HeroEffectView } from "./HeroEffectView";
import { SharedHeroEffectView } from "./SharedHeroEffectView";

export default class FightViewFactory extends rpgfight.ViewFactory {
    defaultViewRoot: cc.Node = null
    createView(name: string, owner: rpgfight.Hero): rpgfight.View {
        //加载对应的
        let animType = "hero"

        if (animType == "hero") {
            let view = this._createHeroView(name, owner);
            view.setParent(this.defaultViewRoot)
            return view
        }
    }

    protected _createHeroView(name: string, owner: rpgfight.Hero) {
        return new HeroView(name, owner);
    }

    protected _effectView: SharedHeroEffectView
    getSharedEffectView(): rpgfight.SharedEffectView {
        if (this._effectView) {
            return this._effectView
        }

        this._effectView = this._createSharedEffectView();
        this._effectView.setParent(this.defaultViewRoot)
        return this._effectView

    }

    protected _createSharedEffectView(): SharedHeroEffectView {
        return new SharedHeroEffectView();
    }

    /**
     * 创建技能关联特效
     * @param name 
     * @param owner 
     * @param skillData 
     */
    createSkillEffectView(name: string, owner: rpgfight.Hero, skillData: rpgfight.SkillData): rpgfight.SkillView {
        let view = new HeroEffectView(name, owner, skillData)
        view.setParent(this.defaultViewRoot)
        // owner.runner.manager.effectViewManager.add(view)
        return view
    }
}