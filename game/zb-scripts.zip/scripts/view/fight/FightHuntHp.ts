import EManager, { EListener, EName } from "../../manager/EventManager";
import unionLogic from "../../logics/UnionLogic";
import huntconfig from "../../configs/huntconfig";
import battleLogic from "../../logics/BattleLogic";
import { BattleType } from "../../utils/DefineUtils";

const { ccclass, property, menu } = cc._decorator;

/**
 * 公会狩猎中的血条
 */
@ccclass
@menu("view/fight/FightHuntHp")
export default class FightHuntHp extends cc.Component {

    @property(cc.ProgressBar)
    hpProgress: cc.ProgressBar = null;

    @property(cc.ProgressBar)
    hpProgressEx: cc.ProgressBar = null;

    @property(cc.Label)
    hurtLabel: cc.Label = null;

    @property(cc.Node)
    chestIcon: cc.Node = null;

    @property(cc.Node)
    bossBuff: cc.Node = null;

    @property(cc.Node)
    buff1: cc.Node = null;

    @property(cc.Node)
    buff2: cc.Node = null;

    @property(cc.Label)
    buffLevel: cc.Label = null;

    protected _eventListeners: EListener[] = [];
    protected _progress: number = 0;
    protected _chestCnt: number = 0;

    start() {
        this.hpProgress.progress = this.hpProgressEx.progress = 0;
        this.bossBuff.active = false;
        this.buff1.active = unionLogic.unionHuntMonsterType == 1;
        this.buff2.active = unionLogic.unionHuntMonsterType == 2;
    }

    onEnable() {
        let listener = EManager.addEvent(EName.onUpdateFightHero, (data: { fightHero: rpgfight.Hero, spineNode: cc.Node }) => {
            if (data.fightHero.heroData.heroConfigId == unionLogic.unionHuntMonster.getIndex().toString()) {
                this._onUpdate(data);
            }
        });
        this._eventListeners.push(listener);
    }

    onDisable() {
        for (let listener of this._eventListeners) {
            EManager.removeEvent(listener);
        }
        this._eventListeners = [];
    }

    update(dt: number) {
        if (this.hpProgress.progress < this.hpProgressEx.progress) {
            let progress = this.hpProgress.progress + 0.5 * dt;
            this.hpProgress.progress = Math.min(progress, this.hpProgressEx.progress);
        }
        else if (this.hpProgress.progress > this.hpProgressEx.progress) {
            let progress = this.hpProgress.progress - 0.5 * dt;
            this.hpProgress.progress = Math.max(progress, this.hpProgressEx.progress);
        }
    }

    protected _onUpdate(data: { fightHero: rpgfight.Hero, spineNode: cc.Node }) {
        if (data.fightHero.heroData.hpRealtime >= 0 && unionLogic.unionHuntMonsterHP > 0) {
            let hpLevel = this._getHpLevel(data);
            this.hurtLabel.string = `${hpLevel.now}/${hpLevel.total}`;
            if (hpLevel.now > 0) {
                this.hpProgressEx.progress = hpLevel.now / hpLevel.total;
                if (this.hpProgress.progress > this.hpProgressEx.progress) {
                    this.hpProgress.progress = 0;
                }
            }
        }
    }

    protected _getHpLevel(data: { fightHero: rpgfight.Hero, spineNode: cc.Node }) {
        let startPos = null;
        if (data.spineNode) {
            startPos = data.spineNode.convertToWorldSpaceAR(cc.p(0, 0));
        }
        let hurtHp = data.fightHero.heroData.hpMaxRealtime - data.fightHero.heroData.hpRealtime;
        if (hurtHp > unionLogic.unionHuntHurt) {
            if (startPos) {
                if (data.fightHero.hasValue(null, "buff累计层数")) {
                    this.bossBuff.active = true;
                    let buff = data.fightHero.getValue(null, "buff累计层数");
                    if (buff > 0) {
                        this.buffLevel.string = buff.toString();
                    } else {
                        this.buffLevel.string = "";
                    }
                } else {
                    this.bossBuff.active = false;
                }
                EManager.emit(EName.onGoldDrop, startPos);
            }
        }
        unionLogic.unionHuntHurt = hurtHp;
        let config = huntconfig.where(a => a.type == unionLogic.unionHuntMonsterType);
        let hp = 0;
        let levelHp = 0;
        for (let i = 0; i < config.length; i++) {
            let hunt = config[i];
            levelHp = hunt.hurtnum;
            hp += hunt.hurtnum;
            if (hurtHp <= hp) {
                if (battleLogic.battleType != BattleType.Record) {
                    if (i > this._chestCnt) {
                        // 掉落宝箱
                        for (let index = 0; index < i - this._chestCnt; index++) {
                            let rewards = unionLogic.addUnionHuntReward(hunt.rewardbox);
                            this.chestIcon.getComponent(cc.Animation).play("gonghuishouliehuodebaoxiang", 0);
                            for (let reward of rewards) {
                                EManager.emit(EName.onHuntChest, {
                                    startPos: startPos,
                                    chestId: hunt.rewardbox,
                                    reward: reward
                                });
                            }
                        }
                        this._chestCnt = i;
                    }
                }
                break;
            }
        }
        return { now: hurtHp == 0 ? 0 : Math.floor(hurtHp - (hp - levelHp)), total: levelHp };
    }

}