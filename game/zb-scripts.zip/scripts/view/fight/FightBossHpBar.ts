import FightHpBar from './FightHpBar';

const { ccclass, property, menu } = cc._decorator;

/**
 * 战场中Boss的血条
 */
@ccclass
@menu("view/fight/FightBossHpBar")
export default class FightBossHpBar extends FightHpBar {
    @property({
        override: true,
        visible: false,
        type: cc.ProgressBar
    })
    shieldProgress: cc.ProgressBar = null;

    setWidth(width: number) {
        super.setWidth(width);
        this.node.width += 36;
    }
}
