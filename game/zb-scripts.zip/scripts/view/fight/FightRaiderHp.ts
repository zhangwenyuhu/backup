import EManager, { EListener, EName } from "../../manager/EventManager";
import activityLogic, { ActivityType } from "../../logics/ActivityLogic";
import TreasureActConfig from "../../data/activity/actconfig/TreasureActConfig";
import TreasureRoleActivityDatas from "../../data/activity/roleactivitydatas/TreasureRoleActivityDatas";
import Monsterconfig from "../../configs/Monsterconfig";
import challengerewardConfig from "../../configs/challengerewardConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/fight/FightRaiderHp")
export default class FightRaiderHp extends cc.Component {

    @property(cc.ProgressBar)
    hpProgress: cc.ProgressBar = null;

    @property(cc.ProgressBar)
    hpProgressEx: cc.ProgressBar = null;

    @property(cc.Label)
    hurtLabel: cc.Label = null;

    @property(cc.Node)
    icon: cc.Node = null;

    @property(cc.Label)
    ticket: cc.Label = null;

    @property(cc.Node)
    bossBuff: cc.Node = null;

    @property(cc.Node)
    buff1: cc.Node = null;

    @property(cc.Node)
    buff2: cc.Node = null;

    @property(cc.Label)
    buffLevel: cc.Label = null;

    protected _eventListeners: EListener[] = [];
    protected _progress: number = 0;
    protected _chestCnt: number = 0;
    protected _actConfig: TreasureActConfig = null;
    protected _roleActivityDatas: TreasureRoleActivityDatas = null;
    protected _monsterHeroId: string = "";

    start() {
        this.hpProgress.progress = this.hpProgressEx.progress = 0;
        this.bossBuff.active = false;
    }

    onEnable() {
        let activity = activityLogic.getActivityConfigs(ActivityType.Treasure);
        this._actConfig = activity.actConfig as TreasureActConfig;
        this._roleActivityDatas = activity.roleActivityDatas as TreasureRoleActivityDatas;
        let monsterCfg = Monsterconfig.find(a => a.MonsterID == this._actConfig.monsterId);
        this._monsterHeroId = monsterCfg.HeroID.toString();
        let listener = EManager.addEvent(EName.onUpdateFightHero, (data: { fightHero: rpgfight.Hero, spineNode }) => {
            if (this._actConfig && data.fightHero.heroData.heroConfigId == this._monsterHeroId) {
                this._onUpdate(data);
            }
        });
        this._eventListeners.push(listener);
    }

    onDisable() {
        for (let listener of this._eventListeners) {
            EManager.removeEvent(listener);
        }
        this._eventListeners = [];
    }

    update(dt: number) {
        if (this.hpProgress.progress < this.hpProgressEx.progress) {
            let progress = this.hpProgress.progress + 0.5 * dt;
            this.hpProgress.progress = Math.min(progress, this.hpProgressEx.progress);
        }
        else if (this.hpProgress.progress > this.hpProgressEx.progress) {
            let progress = this.hpProgress.progress - 0.5 * dt;
            this.hpProgress.progress = Math.max(progress, this.hpProgressEx.progress);
        }
    }

    protected _onUpdate(data: { fightHero: rpgfight.Hero, spineNode: cc.Node }) {
        if (data.fightHero.heroData.hpRealtime >= 0) {
            let hpLevel = this._getHpLevel(data);
            this.hurtLabel.string = `${hpLevel.now}/${hpLevel.total}`;
            if (hpLevel.now > 0) {
                this.hpProgressEx.progress = hpLevel.now / hpLevel.total;
                if (this.hpProgress.progress > this.hpProgressEx.progress) {
                    this.hpProgress.progress = 0;
                }
            }
        }
    }

    protected _getHpLevel(data: { fightHero: rpgfight.Hero, spineNode: cc.Node }) {
        let startPos = null;
        if (data.spineNode) {
            startPos = data.spineNode.convertToWorldSpaceAR(cc.p(0, 0));
        }
        let hurtHp = data.fightHero.heroData.hpMaxRealtime - data.fightHero.heroData.hpRealtime;
        this._actConfig.treasureTotalHurt = hurtHp;
        let config = challengerewardConfig;
        let hp = 0;
        let levelHp = 0;
        for (let i = 0; i < config.length; i++) {
            let hunt = config[i];
            levelHp = hunt.hurtnum;
            hp += hunt.hurtnum;
            if (hurtHp <= hp) {
                if (i > this._chestCnt) {
                    this._actConfig.treasureRewardCnt += i - this._chestCnt;
                    this.ticket.string = this._actConfig.treasureRewardCnt.toString();
                    this.icon.getComponent(cc.Animation).play("gonghuishouliehuodebaoxiang", 0);
                    this._chestCnt = i;
                }
                break;

            }
        }
        if (this._chestCnt == config.length - 1 && hurtHp >= hp) {
            if (this._chestCnt < config.length) {
                this._actConfig.treasureRewardCnt++;
                this.ticket.string = this._actConfig.treasureRewardCnt.toString();
                this.icon.getComponent(cc.Animation).play("gonghuishouliehuodebaoxiang", 0);
                this._chestCnt = config.length;
            }
        }

        return { now: hurtHp == 0 ? 0 : Math.floor(hurtHp - (hp - levelHp)), total: levelHp };
    }

}
