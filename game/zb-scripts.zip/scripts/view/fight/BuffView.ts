import { HeroEffectView } from "./HeroEffectView";

/**
 * 用于播放英雄的spine动画
 */
export default class BuffView extends HeroEffectView {
	buffType: rpgfight.BuffType = "common"

	protected _buff: rpgfight.HeroBuff = null;

	constructor(
		effectId: string,
		owner: rpgfight.Hero,
		buff: rpgfight.HeroBuff,
	) {
		super(effectId, owner, buff.theSkill);
		this.root.name = "BuffView";
		this._buff = buff;
	}

	playDefaultEffect() {
		this.root.runAction(cc.callFunc(this._playEffect, this));
	}

	protected _playEffect() {
		do {
			let anims = this.effectConfig.Anim
			let bLoop = this.effectConfig.Loop
			if (anims.length > 0) {
				if (anims.length > 1) {
					if (this._buff.effectList.length > 0) {
						let effect = this._buff.effectList[0];
						if (effect instanceof rpgfight.HeroAttrBuffEffect) {
							if (effect.options.enhanceRate > 0 || effect.options.enhanceValue > 0) {
								this.setAnimation(0, anims[0], bLoop);
								this.skeleton.setCompleteListener(() => { this.completeHandler && this.completeHandler() });
							}
							else if (effect.options.enhanceRate < 0 || effect.options.enhanceValue < 0) {
								this.setAnimation(0, anims[1], bLoop);
								this.skeleton.setCompleteListener(() => { this.completeHandler && this.completeHandler() });
							}
							return;
						}
					}
				}
				else {
					this.setAnimation(0, anims[0], bLoop);
					this.skeleton.setCompleteListener(() => { this.completeHandler && this.completeHandler() });
					return;
				}
			}
		} while (false);
		super.playDefaultEffect();
	}
}
