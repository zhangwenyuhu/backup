const { ccclass, property, menu } = cc._decorator;

/**
 * 战斗中的飘字
 */
@ccclass
@menu("view/fight/FightToast")
export default class FightToast extends cc.Component {
    @property(cc.Node)
    nodeHurt: cc.Node = null;

    @property(cc.Node)
    nodeCrit: cc.Node = null;

    @property(cc.Node)
    nodeBuf: cc.Node = null;

    @property(cc.Node)
    nodePower: cc.Node = null;

    @property(cc.SpriteFrame)
    buffTextSpriteFrames1: cc.SpriteFrame[] = [];

    @property(cc.SpriteFrame)
    buffTextSpriteFrames2: cc.SpriteFrame[] = [];

    @property(cc.SpriteFrame)
    buffArrowSpriteFrame1: cc.SpriteFrame = null;

    @property(cc.SpriteFrame)
    buffArrowSpriteFrame2: cc.SpriteFrame = null;

    hero: rpgfight.Hero = null;

    protected _labelHeal: cc.Label = null;
    protected _labelHurt: cc.Label = null;
    protected _labelCrit: cc.Label = null;
    protected _labelPower: cc.Label = null;

    onLoad() {
        this.nodeHurt.opacity = 0;
        this.nodeCrit.opacity = 0;
        this.nodeBuf.opacity = 0;

        this._labelHeal = this.nodeBuf.getChildByName("heal").getComponent(cc.Label);
        this._labelHurt = this.nodeHurt.getComponent(cc.Label);
        this._labelCrit = cc.find("crit/label_crit", this.nodeCrit).getComponent(cc.Label);
        this._labelPower = this.nodePower.getChildByName("label").getComponent(cc.Label);
    }

    update(dt: number) {
        if (this.hero) {
            this.node.x = this.hero.position.x;
        }
    }

    reset() {
        this.nodeHurt.active = false;
        this.nodeCrit.active = false;
        this.nodeBuf.active = false;
    }

    showHurt(value: string, callback?: Function) {
        if (!this.node) {
            return;
        }
        this.nodeCrit.active = false;
        this.nodeBuf.active = false;
        this.nodeHurt.active = true;
        this.nodeHurt.opacity = 0;
        this._labelHurt.string = value;

        let animation = this.nodeHurt.getComponent(cc.Animation);
        animation.off("finished");
        animation.on("finished", () => {
            if (callback) {
                try {
                    callback()
                } catch (e) {
                    console.error(e)
                }
            } else {
                this.node.destroy()
            }
        }, this);
        animation.play();
    }

    showPower(value: string, callback?: Function) {
        if (!this.node) {
            return;
        }
        this.nodeCrit.active = false;
        this.nodeHurt.active = false;

        this.nodeBuf.active = true;
        this.nodeBuf.opacity = 0;

        this._labelHeal.node.active = false;
        this.nodeBuf.getChildByName("buff").active = false;

        this.nodePower.active = true;
        this._labelPower.string = value;

        let animation = this.nodeBuf.getComponent(cc.Animation);
        animation.off("finished");
        animation.on("finished", () => {
            if (callback) {
                try {
                    callback()
                } catch (e) {
                    console.error(e)
                }
            } else {
                this.node.destroy()
            }
        }, this);
        animation.play();
    }

    showCrit(value: string, callback?: Function) {
        this.nodeBuf.active = false;
        this.nodeHurt.active = false;
        this.nodeCrit.active = true;
        this.nodeCrit.opacity = 255;
        this._labelCrit.string = value;

        let animation = this.nodeCrit.getComponent(cc.Animation);
        animation.off("finished");
        animation.on("finished", () => {
            if (callback) {
                try {
                    callback()
                } catch (e) {
                    console.error(e)
                }
            } else {
                this.node.destroy()
            }
        }, this);
        animation.play();
    }

    showBuf(hero: rpgfight.Hero, type: rpgfight.BuffEffectEnum, callback?: Function, value?: number) {
        this.nodeHurt.active = false;
        this.nodeCrit.active = false;
        this.nodeBuf.active = true;
        this.nodeBuf.opacity = 0;

        this._labelHeal.node.active = false;
        this.nodePower.active = false;

        let buff = this.nodeBuf.getChildByName("buff");
        buff.active = true;

        let isSelf = hero.heroData.battleTeamRuntime == rpgfight.BattleTeam.our;
        let sprite = buff.getChildByName("text").getComponent(cc.Sprite);
        sprite.spriteFrame = isSelf ? this.buffTextSpriteFrames1[type] : this.buffTextSpriteFrames2[type];

        let arrow = buff.getChildByName("arrow");
        if (typeof value == "number") {
            arrow.active = true;
            arrow.scaleY = value > 0 ? 1 : -1;
            arrow.getComponent(cc.Sprite).spriteFrame = isSelf ? this.buffArrowSpriteFrame1 : this.buffArrowSpriteFrame2;
        }
        else {
            arrow.active = false;
        }

        let animation = this.nodeBuf.getComponent(cc.Animation);
        animation.off("finished");
        animation.on("finished", () => {
            if (callback) {
                try {
                    callback()
                } catch (e) {
                    console.error(e)
                }
            } else {
                this.node.destroy()
            }
        }, this);
        animation.play();
    }

    showHeal(value: string, callback?: Function) {
        this.nodeHurt.active = false;
        this.nodeCrit.active = false;
        this.nodeBuf.active = true;
        this.nodeBuf.opacity = 0;

        this.nodeBuf.getChildByName("buff").active = false;
        this.nodePower.active = false;
        this._labelHeal.node.active = true;
        this._labelHeal.string = value;

        let animation = this.nodeBuf.getComponent(cc.Animation);
        animation.off("finished");
        animation.on("finished", () => {
            if (callback) {
                try {
                    callback()
                } catch (e) {
                    console.error(e)
                }
            } else {
                this.node.destroy()
            }
        }, this);
        animation.play();
    }
}