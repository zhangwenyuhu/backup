import Hero from "../../data/card/Hero";
import loadUtils from "../../utils/LoadUtils";
import EManager, { EName, EListener } from "../../manager/EventManager";
import FightHpBar from "./FightHpBar";
import heroUtils from "../../utils/HeroUtils";
import HeroMerc from "../../data/card/HeroMerc";
import commonUtils from "../../utils/CommonUtils";
import battleLogic from "../../logics/BattleLogic";
import { BattleType } from "../../utils/DefineUtils";

const { ccclass, property, menu } = cc._decorator;

/**
 * 战场底部大招图标
 */
@ccclass
@menu("view/fight/FightSkill")
export default class FightSkill extends cc.Component {
    @property(cc.Sprite)
    spriteIcon: cc.Sprite = null;

    @property(sp.Skeleton)
    skeleton: sp.Skeleton = null;

    @property(FightHpBar)
    hpBar: FightHpBar = null;

    @property(cc.Sprite)
    spriteRect: cc.Sprite = null;

    @property(cc.Node)
    high: cc.Node = null;

    @property(cc.Node)
    stars: cc.Node = null;

    @property(cc.Node)
    nodeFlag: cc.Node = null;

    @property(cc.Sprite)
    spriteDizuo: cc.Sprite = null;

    @property(cc.Sprite)
    spriteBigIcon: cc.Sprite = null;

    @property(cc.Sprite)
    graySprites: cc.Sprite[] = [];

    @property(cc.Material)
    normalMaterial: cc.Material = null;

    @property(cc.Material)
    grayMaterial: cc.Material = null;

    @property(cc.Node)
    artifactNode: cc.Node = null;

    @property(cc.Sprite)
    artifactBg: cc.Sprite = null;

    @property(cc.Sprite)
    artifactIco: cc.Sprite = null;

    protected _hero: Hero = null;
    protected _eventListeners: EListener[] = [];
    protected _isDead: boolean = false;
    protected _battleType: BattleType;

    async init(hero: Hero, type: BattleType) {
        this._hero = hero;
        this._battleType = type;
        this.node.name = this._hero.getRName();
        this.hpBar.initWithHero(this._hero, this._battleType);

        let info = heroUtils.getHeroQualityInfo(this._hero.getRank());
        this.node.opacity = 0;

        let artifact = this._hero.getArtifact();
        if (artifact) {
            this.artifactNode.active = true;
            loadUtils.loadSpriteFrame(commonUtils.getHeroCircleUrl(info.qualityHead), this.artifactBg)
            loadUtils.loadSpriteFrame(commonUtils.getArtifactIconUrl(artifact.getIndex(), artifact.getStar()), this.artifactIco);
        }
        else {
            this.artifactNode.active = false;
        }

        let spriteFrame = await loadUtils.loadRes(commonUtils.getHeroBattleRectUrl(info.qualityHead), cc.SpriteFrame) as cc.SpriteFrame;
        if (!cc.isValid(this.spriteRect)) return;
        this.spriteRect.spriteFrame = spriteFrame;

        this.high.active = info.qualityHigh > 0;
        if (info.qualityHigh > 0) {
            this.high.getComponent(cc.Sprite).spriteFrame = cc.loader.getRes(commonUtils.getHeroRankExUrl(info.qualityHigh), cc.SpriteFrame);
        }
        if (hero.getStar() > 0) {
            this.stars.active = true;
            for (let i = 0; i < this.stars.childrenCount; i++) {
                this.stars.children[i].active = i < hero.getStar();
            }
        } else {
            this.stars.active = false;
        }

        if (this._hero instanceof HeroMerc) {
            this.nodeFlag.active = true;
        }
        else {
            this.nodeFlag.active = false;
        }

        spriteFrame = await loadUtils.loadRes(commonUtils.getHeroBattleDizuoUrl(info.qualityHead), cc.SpriteFrame) as cc.SpriteFrame;
        if (!cc.isValid(this.spriteDizuo)) return;
        this.spriteDizuo.spriteFrame = spriteFrame;
        this.spriteDizuo.node.active = false;

        spriteFrame = cc.loader.getRes(commonUtils.getHeroBigUrl(this._hero.getIndex()), cc.SpriteFrame);
        if (!spriteFrame) {
            spriteFrame = await loadUtils.loadRes(commonUtils.getHeroBigUrl(this._hero.getIndex()), cc.SpriteFrame) as cc.SpriteFrame;
        }
        this.spriteBigIcon.spriteFrame = spriteFrame;
        this.spriteBigIcon.node.scale = hero.config.battle_scale;

        let worldPoint = this.spriteDizuo.node.convertToWorldSpace(cc.p(hero.config.battle_x, -hero.config.battle_y));
        let localPoint = this.spriteBigIcon.node.parent.convertToNodeSpaceAR(worldPoint);
        this.spriteBigIcon.node.position = localPoint;
        this.spriteBigIcon.node.active = false;

        spriteFrame = await loadUtils.loadRes(`textures/ui/panel/battle/hero_icon_${this._hero.getIndex()}`, cc.SpriteFrame) as cc.SpriteFrame;
        if (!cc.isValid(this.spriteIcon)) return;
        this.spriteIcon.sizeMode = cc.Sprite.SizeMode.RAW;
        this.spriteIcon.trim = false;
        this.spriteIcon.spriteFrame = spriteFrame;

        this.node.opacity = 255;
    }

    onEnable() {
        let listener = EManager.addEvent(EName.onUpdateFightHero, (data: { fightHero: rpgfight.Hero, spineNode: cc.Node }) => {
            if (data.fightHero.manager.battleType != this._battleType) return;
            if (data.fightHero.heroData.heroId == this._hero.getId()) {
                this.onUpdate(data.fightHero);
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onUseHeroSkill, (fightHero: rpgfight.Hero) => {
            if (fightHero.manager.battleType != this._battleType) {
                return;
            }
            if (fightHero.heroData.heroId == this._hero.getId()) {
                this.onUseSkill();
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onHeroDead, (fightHero: rpgfight.Hero) => {
            if (fightHero.manager.battleType != this._battleType) return;
            if (fightHero.heroData.heroId == this._hero.getId()) {
                this._onHeroDead();
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onHeroRevive, (fightHero: rpgfight.Hero) => {
            if (fightHero.manager.battleType != this._battleType) return;
            if (fightHero.heroData.heroId == this._hero.getId()) {
                this._onHeroRevive();
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onHeroReset, (heroConfig: rpgfight.HeroConfig) => {
            if (heroConfig.heroId == this._hero.getId()) {
                this._onHeroReset();
            }
        });
        this._eventListeners.push(listener);
    }

    onDisable() {
        for (let listener of this._eventListeners) {
            EManager.removeEvent(listener);
        }
        this._eventListeners = [];
    }

    onUpdate(fightHero: rpgfight.Hero) {
        if (this._isDead) {
            return;
        }

        if (fightHero.isBSkillAvailable()) {
            if (this.skeleton.animation == "") {
                this.skeleton.animation = "daiji";
                this.skeleton.loop = true;
                this.spriteRect.node.active = false;
            }
        }
        else {
            if (this.skeleton.animation == "daiji") {
                this.skeleton.animation = "";
                this.spriteRect.node.active = true;
            }
        }
    }

    onUseSkill() {
        this.spriteDizuo.node.active = true;
        this.spriteBigIcon.node.active = true;
        this.spriteIcon.node.active = false;

        this.skeleton.animation = "shifang";
        this.skeleton.loop = false;
        this.skeleton.setCompleteListener(() => {
            this.skeleton.animation = "";
            this.spriteDizuo.node.active = false;
            this.spriteBigIcon.node.active = false;
            this.spriteRect.node.active = true;
            this.spriteIcon.node.active = true;
        });
    }

    onClickSkill() {
        if (!battleLogic.isAutoSkill) {
            EManager.emit(EName.onClickHeroSkill, this._hero);
        }
    }

    protected _onHeroDead() {
        this._isDead = true;

        this.skeleton.animation = "";
        this.spriteDizuo.node.active = false;
        this.spriteBigIcon.node.active = false;
        this.spriteRect.node.active = true;
        this.spriteIcon.node.active = true;

        for (let sprite of this.graySprites) {
            sprite.setMaterial(0, this.grayMaterial);
        }
    }

    protected _onHeroReset() {
        this._isDead = false;
        this.spriteDizuo.node.active = false;
        this.spriteBigIcon.node.active = false;
        this.spriteRect.node.active = true;

        for (let sprite of this.graySprites) {
            sprite.setMaterial(0, this.normalMaterial);
        }
    }

    protected _onHeroRevive() {
        this._onHeroReset();
    }
}
