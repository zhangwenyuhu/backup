export class NodePoolV2 {
	protected _pool: cc.Node[] = []
	size(): number {
		return this._pool.length
	}
	clear(): void {
		this._pool.forEach(node => {
			if (cc.isValid(node)) {
				node.parent = null
				node.destroy()
			}
		})
		this._pool = []
	}
	put(obj: cc.Node): void {
		let index = this._pool.indexOf(obj)
		if (index < 0) {
			this._pool.push(obj)
		}
	}
	get(): cc.Node | undefined {
		return this._pool.pop()
	}
}
