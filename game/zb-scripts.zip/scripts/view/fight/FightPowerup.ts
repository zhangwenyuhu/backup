import EManager, { EListener } from './../../manager/EventManager';
import Player from '../../data/user/Player';
import playerLogic from '../../logics/PlayerLogic';
import commonUtils from '../../utils/CommonUtils';
import BasePanel from '../panel/BasePanel';
const { ccclass, property, menu } = cc._decorator;

/**
 * 玩家战斗力变化
 */
@ccclass
@menu("view/fight/FightPowerup")
export default class FightPowerup extends cc.Component {
    @property(cc.Animation)
    animationPower: cc.Animation = null;

    @property(cc.Label)
    labelPower: cc.Label = null;

    @property(cc.Animation)
    animationDeltaPower: cc.Animation = null;

    @property(cc.Label)
    labelDeltaPower: cc.Label = null;

    protected _oldPower: number = 0;
    protected _newPower: number = 0;
    protected _eventListeners: EListener[] = [];

    onLoad() {
        this.animationPower.node.active = false;
        this.animationDeltaPower.node.active = false;
    }

    onEnable() {
        let listener = EManager.addEvent(Player.Event.onPowerDirty, (data: { target: Player, oldValue: number, newValue: number }) => {
            if (data.target == playerLogic.getPlayer()) {
                if (typeof data.oldValue == 'number' && typeof data.newValue === 'number') {
                    if (data.oldValue != data.newValue && this._newPower != data.newValue) {
                        if (BasePanel.getPanel("LotteryPanel")) {
                            return;
                        }

                        this._oldPower = data.oldValue;
                        this._newPower = data.newValue;
                        this.unscheduleAllCallbacks();
                        this.scheduleOnce(this._showPowerEffect, 0.5);
                    }
                }
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent("test", (data: { oldValue: number, newValue: number }) => {
            this._oldPower = data.oldValue;
            this._newPower = data.newValue;
            this.unscheduleAllCallbacks();
            this.scheduleOnce(this._showPowerEffect, 0.5);
        });
    }

    protected _showPowerEffect() {
        this.labelPower.string = this._oldPower.toString();

        this.animationPower.node.active = true;
        this.animationPower.off("finished");
        this.animationPower.on("finished", this._scrollNumbers, this);
        this.animationPower.play("fightup_start");
    }

    protected _scrollNumbers() {
        let isBigger = false;
        this.animationDeltaPower.node.active = true;
        if (this._newPower > this._oldPower) {
            this.labelDeltaPower.string = `+${this._newPower - this._oldPower}`;
            this.animationDeltaPower.play('poweru');
            isBigger = true;
        }
        else {
            this.labelDeltaPower.string = `${this._newPower - this._oldPower}`;
            this.animationDeltaPower.play('powerd');
            isBigger = false;
        }
        this.animationDeltaPower.off("finished");
        this.animationDeltaPower.on("finished", () => { this.animationDeltaPower.node.active = false; }, this);

        let newPowerStr = this._newPower.toString();
        let len = this._oldPower.toString().length;
        let scrollCount = 0;
        for (let i = 0; i < len; i++) {
            let newIndex = newPowerStr.length - i - 1;
            let index = len - i - 1;
            if (newIndex < 0) {
                return;
            }
            let oldNum = Number(this.labelPower.string.charAt(index));
            let newNum = Number(newPowerStr.charAt(newIndex));
            this.scheduleOnce(async () => {
                while (oldNum != newNum) {
                    if (isBigger) {
                        oldNum = (oldNum + 1) % 10;
                    }
                    else {
                        oldNum = (oldNum - 1 + 10) % 10;
                    }
                    this.labelPower.string = this.labelPower.string.substring(0, index) + oldNum.toString() + this.labelPower.string.substring(index + 1);
                    await commonUtils.sleep(0.05, this);
                }
                scrollCount++;
                if (scrollCount == Math.min(newPowerStr.length, len)) {
                    this._scrollEnd();
                }
            }, i * 0.05);
        }
    }

    protected _scrollEnd() {
        this.labelPower.string = this._newPower.toString();
        this.scheduleOnce(() => {
            this.animationPower.off("finished");
            this.animationPower.on("finished", () => { this.animationPower.node.active = false; }, this);
            this.animationPower.play("fightup_start2");
        }, 0.5);
    }
}
