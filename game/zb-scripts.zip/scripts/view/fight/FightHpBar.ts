import { EName, EConnection } from './../../manager/EventManager';
import EManager, { EListener } from "../../manager/EventManager";
import Hero from '../../data/card/Hero';
import { BattleType } from '../../utils/DefineUtils';

const { ccclass, property, menu } = cc._decorator;

/**
 * 战场上的英雄血条
 */
@ccclass
@menu("view/fight/FightHpBar")
export default class FightHpBar extends cc.Component {
    @property(cc.ProgressBar)
    hpProgress: cc.ProgressBar = null;

    @property(cc.ProgressBar)
    hpProgressEx: cc.ProgressBar = null;

    @property(cc.ProgressBar)
    powerProgress: cc.ProgressBar = null;

    @property(cc.ProgressBar)
    shieldProgress: cc.ProgressBar = null;

    @property(cc.SpriteFrame)
    enemyHpFrame: cc.SpriteFrame = null;

    @property(cc.SpriteFrame)
    enemyHpFrameEx: cc.SpriteFrame = null;

    protected _fightHero: rpgfight.Hero;
    protected _eventListeners: EListener[] = [];
    protected _root: cc.Node = null;
    protected _hero: Hero = null;
    protected _isDead: boolean = false;
    protected _progress: number = 0;
    protected _battleType: BattleType;

    setWidth(width: number) {
        this.node.width = width;
        this.hpProgress.totalLength = width - 2;
        this.hpProgressEx.totalLength = width;
        this.powerProgress.totalLength = width;
        if (this.shieldProgress) {
            this.shieldProgress.totalLength = width;
        }
    }

    setFightHero(hero: rpgfight.Hero) {
        this._fightHero = hero;
    }

    initWithFightHero(fightHero: rpgfight.Hero, root: cc.Node) {
        this._fightHero = fightHero;
        this._root = root;
        this.node.opacity = 0;
        this._progress = 1;
        this.hpProgress.progress = this._progress;
        this.hpProgressEx.progress = this._progress;
        this.powerProgress.progress = this._progress;
        if (this.shieldProgress) this.shieldProgress.node.active = false;
        this._battleType = fightHero.manager.battleType;
    }

    initWithHero(hero: Hero, battleType: BattleType) {
        this._hero = hero;
        this._battleType = battleType;
    }

    start() {
        if (this._fightHero) {
            if (this._fightHero.heroData.battleTeam == rpgfight.BattleTeam.enemy) {
                this.hpProgress.barSprite.spriteFrame = this.enemyHpFrame;
                this.hpProgressEx.barSprite.spriteFrame = this.enemyHpFrameEx;
            }
        }
    }

    onEnable() {
        let listener = EManager.addEvent(EName.onUpdateFightHero, (data: { fightHero: rpgfight.Hero, spineNode }, connection: EConnection) => {
            if (data.fightHero.manager.battleType != this._battleType) {
                return;
            }

            if (this._fightHero == data.fightHero) {
                connection.listener.once = true;
                connection.stop = true;
            }
            else if (this._hero && this._hero.getId() == data.fightHero.heroData.heroId) {
                this._fightHero = data.fightHero;
                this._onUpdate(data.fightHero);
                connection.listener.once = true;
                connection.stop = true;
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onHeroDead, (fightHero: rpgfight.Hero, connection: EConnection) => {
            if (fightHero.manager.battleType != this._battleType) {
                return;
            }
            if (fightHero == this._fightHero || (this._hero && this._hero.getId() == fightHero.heroData.heroId)) {
                this._onHeroDead();
                connection.stop = true;
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onHeroReset, (heroConfig: rpgfight.HeroConfig, connection: EConnection) => {
            if ((this._fightHero && heroConfig.heroId == this._fightHero.heroData.heroId)
                || (this._hero && this._hero.getId() == heroConfig.heroId)) {
                this._onHeroReset();
                connection.stop = true;
            }
        });
        this._eventListeners.push(listener);

        if (this._fightHero) {
            listener = EManager.addEvent(EName.onHeroKill, (data: { hero: rpgfight.Hero, killer: rpgfight.Hero, victim: rpgfight.Hero }, connection: EConnection) => {
                if (data.hero.manager.battleType != this._battleType) {
                    return;
                }

                if (data.killer == this._fightHero) {
                    this.node.opacity = 0;
                    this._progress = this.hpProgress.progress;
                    connection.stop = true;
                }
            });
            this._eventListeners.push(listener);
        }
    }

    onDisable() {
        for (let listener of this._eventListeners) {
            EManager.removeEvent(listener);
        }
        this._eventListeners = [];
    }

    update(dt: number) {
        if (this._root) {
            this.node.scaleX = 1 / this._root.scaleX;
            this.node.scaleY = 1 / this._root.scaleY;
        }
        if (this.hpProgressEx.progress < this.hpProgress.progress) {
            let progress = this.hpProgressEx.progress + 0.5 * dt;
            this.hpProgressEx.progress = Math.min(progress, this.hpProgress.progress);
        }
        else if (this.hpProgressEx.progress > this.hpProgress.progress) {
            let progress = this.hpProgressEx.progress - 0.5 * dt;
            this.hpProgressEx.progress = Math.max(progress, this.hpProgress.progress);
        }

        if (this._fightHero) { this._onUpdate(this._fightHero); }
    }

    protected _onUpdate(fightHero: rpgfight.Hero) {
        if (this._isDead) {
            return;
        }
        this.hpProgress.progress = fightHero.heroData.hpRealtime / fightHero.heroData.hpMaxRealtime
        this.powerProgress.progress = fightHero.heroData.powerRealtime / fightHero.heroData.powerMaxRealtime
        if (this.shieldProgress) {
            if (this.hpProgress.progress <= 0) { this.node.opacity = 0 }
            else if (this.hpProgress.progress < this._progress) { this.node.opacity = 255; }

            this.shieldProgress.node.active = fightHero.heroData.shieldMaxHp > 0;
            if (this.shieldProgress.node.active) {
                this.shieldProgress.progress = fightHero.heroData.shieldHp / fightHero.heroData.shieldMaxHp;
            }
        }
    }

    protected _onHeroDead() {
        this._isDead = true;
        this.reset();
    }

    protected _onHeroReset() {
        this._isDead = false;
        this.node.opacity = 255;
    }

    reset() {
        this.hpProgress.progress = 0;
        this.hpProgressEx.progress = 0;
        this.powerProgress.progress = 0;

        if (this._fightHero) {
            this.node.opacity = 0;
            this._progress = 1;
        }
    }
}
