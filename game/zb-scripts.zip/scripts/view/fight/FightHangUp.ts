import FightRoot from "./FightRoot";
import playerLogic from "../../logics/PlayerLogic";
import FightViewFactory from "./FightViewFactory";
import HeroView from "./HeroView";
import { SharedHeroEffectView } from "./SharedHeroEffectView";
import Monster from "../../data/card/Monster";
import commonUtils from "../../utils/CommonUtils";
import Hero from "../../data/card/Hero";
import Mission from "../../data/mission/Mission";
import { BattleType } from "../../utils/DefineUtils";
import FightCircle from "../component/FightCircle";
import mathUtils from "../../utils/MathUtils";
import gm from "../../manager/GameManager";
import FightPath from "../component/FightPath";
import cm from "../../manager/ConfigManager";
import loadUtils from "../../utils/LoadUtils";
import MoveTips from "../component/MoveTips";

const { ccclass, property, menu } = cc._decorator;

/**
 * 挂机不播放受伤或治疗效果
 */
class HangUpHeroEffectView extends SharedHeroEffectView {
    async playHurtEffect(hero: rpgfight.Hero, options: rpgfight.HurtOptions) {
        // undo
    }

    async playHealEffect(hero: rpgfight.Hero, options: rpgfight.HealOptions) {
        // undo
    }

    async playPowerEffect(hero: rpgfight.Hero, options: rpgfight.PowerOptions) {
        // undo
    }

    async playBuffEffect(hero: rpgfight.Hero, options: rpgfight.BuffOptions) {
        // undo
    }

    async playKillEffect(hero: rpgfight.Hero, options: rpgfight.KillOptions) {
        // undo
    }
}

/**
 * 挂机不显示血量，不播放音效
 */
class HangUpHeroView extends HeroView {
    protected _skeletonData: sp.SkeletonData = null;
    playAudio(name: string, loop: boolean): void {
        // undo
    }

    protected _addHpBar(owner: rpgfight.Hero) {
        // undo
    }

    protected _addMessageHandlerCallbacks(owner: rpgfight.Hero) {
        // undo
    }

    protected _loadSpineFinished(res: sp.SkeletonData) {
        res.lock();
        this._skeletonData = res;
        if (this.owner.battleTeam == rpgfight.BattleTeam.enemy) {
            this.addTip();
        }
    }

    async addTip() {
        // 气泡
        if (this.spineNode && cc.isValid(this.spineNode)) {

            let node = this.spineNode.getChildByName("moveTip");
            if (node && cc.isValid(node)) {
                node.getComponent(MoveTips).showTip(false);
                return;
            }

            try {
                let prefab = cc.loader.getRes("prefabs/common/move_tips", cc.Prefab);
                if (!prefab) {
                    prefab = await loadUtils.loadRes("prefabs/common/move_tips", cc.Prefab);
                }
                let tipNode = cc.instantiate(prefab) as cc.Node;
                tipNode.parent = this.spineNode;
                tipNode.name = "moveTip";
                tipNode.position = cc.v2(0, 225);
                tipNode.getComponent(MoveTips).showTip(false);
                gm.tipNode.push(tipNode);
            } catch (error) {
                console.error(error);
            }
        }
    }

    destroy() {
        super.destroy();
        if (this._skeletonData) {
            this._skeletonData.unlock();
            this._skeletonData = null;
        }
    }
}

class FightHangUpFactory extends FightViewFactory {
    protected _createHeroView(name: string, owner: rpgfight.Hero): HeroView {
        return new HangUpHeroView(name, owner);
    }

    protected _createSharedEffectView(): SharedHeroEffectView {
        return new HangUpHeroEffectView();
    }
}

@ccclass
@menu("view/fight/FightHangUp")
export default class FightHangUp extends FightRoot {
    protected _width: number = 0;
    protected _height: number = 0;
    protected _heroes: Hero[] = [];
    protected _monsters: Monster[] = [];
    protected _nextMonsterTime: number = 0;
    protected _monsterInterval: number = 2;
    protected _monsterLimited: number = 0;
    protected _fightCircle: FightCircle = null;

    init(mission: Mission, width: number, height: number) {
        this._width = width;
        this._height = height;
        this._monsters = mission.getHangUpMonsters();
        if (gm.usePerformance) {
            this._monsterLimited = 1;
        }
        else {
            this._monsterLimited = mission.getHangUpMonsterLimited();
        }
    }

    async start() {
        this._fightCircle = this.node.parent.getComponent(FightCircle);
        let heroList = [];
        let summonList = [];
        let heroes = await playerLogic.getTroop(BattleType.PVE);
        let count = heroes.length;
        if (gm.usePerformance) { count = Math.min(1, count); }
        for (let i = 0; i < count; i++) {
            let hero = heroes[i];
            if (!hero) continue;
            let cfg = hero.getBattleCfg(true);
            cfg.hp = Number.MAX_VALUE;
            if (this._fightCircle) {
                let rotation = Math.random() * 360;
                let angle = mathUtils.rad(rotation);
                cfg.battleInitPosition = new ml.Point(this._fightCircle.hero.center.x + this._fightCircle.hero.radius * Math.sin(angle),
                    this._fightCircle.hero.center.y + this._fightCircle.hero.radius * Math.cos(angle));
            }
            else {
                cfg.battleInitPosition = new ml.Point(-this._width / 2 + 20 - (i + 0.5 - count / 2) * 10,
                    (i + 0.5 - count / 2) * 20);
            }
            cfg.battleTeam = rpgfight.BattleTeam.our;
            heroList.push(cfg);
            this._heroes.push(hero);
            summonList.pushList(cm.getHeroConfig(hero.getIndex()).summon);
        }

        let scene = new rpgfight.SceneConfig();
        scene.width = this._width;
        scene.height = this._height;
        scene.seed = gm.getCurrentTimestamp();

        let data = new rpgfight.NormalData(scene, heroList, summonList);
        this.startFight(data, BattleType.Hangup);
        this.setFightLogEnabled(false);
    }

    onDestroy() {
        if (this.manager) {
            let heroes = this.manager.getHeroList();
            for (let hero of heroes) {
                hero.view.destroy();
            }
        }
    }

    update(dt: number) {
        super.update(dt);

        let walkNode = this.node.parent.getChildByName("walkNode");
        if (walkNode && this._fightCircle) {
            let distance = walkNode.position.sub(this._fightCircle.monster.center).mag();
            if (distance <= this._fightCircle.monster.radius) {
                gm.destroyWalkZombie(this.node.parent);

                let path = walkNode.getComponent(FightPath);
                this._addEnemy(path.monster, false, walkNode.position);
            }
        }

        if (this._nextMonsterTime < 0) {
            this._nextMonsterTime = this._monsterInterval;

            if (this.manager) {
                let heroes = this.manager.getHeroList((hero: rpgfight.Hero) => { return hero.battleTeam == rpgfight.BattleTeam.enemy; });
                if (heroes.length < this._monsterLimited) {
                    let monster = this._monsters[Math.floor(Math.random() * this._monsters.length)];
                    this._addEnemy(monster, true);
                }
            }
        }
        else {
            this._nextMonsterTime -= dt;
        }
    }

    protected _createFactory(): FightViewFactory {
        return new FightHangUpFactory();
    }

    protected async _addEnemy(hero: Hero, newBorth: boolean, position?: cc.Vec2) {
        let newPos: cc.Vec2 = cc.v2();
        if (position) {
            newPos = position;
        }
        else {
            if (this._fightCircle) {
                let rotation = Math.random() * 360;
                let angle = mathUtils.rad(rotation);
                newPos.x = this._fightCircle.monster.center.x + this._fightCircle.monster.radius * Math.sin(angle);
                newPos.y = this._fightCircle.monster.center.y + this._fightCircle.monster.radius * Math.cos(angle);
            }
            else {
                newPos.x = this._width / 2;
                newPos.y = 0;
            }
        }

        if (newBorth) {
            let node = new cc.Node("tudui");
            node.position = newPos;
            node.parent = this.node;
            let sprite = node.addComponent(cc.Sprite);
            loadUtils.loadSpriteFrame(commonUtils.getCommonUrl("common_tudui"), sprite);
            node.runAction(cc.sequence(cc.delayTime(1.0), cc.fadeOut(0.5), cc.callFunc(() => {
                node.destroy();
            }, this)));
            await commonUtils.sleep(0.2, this);
        }

        if (this.manager && this.manager.gameState != rpgfight.GameState.running) {
            this.manager.gameState = rpgfight.GameState.running;
        }

        let cfg = hero.getBattleCfg(true);
        cfg.battleInitPosition = new ml.Point(newPos.x, newPos.y);
        cfg.battleTeam = rpgfight.BattleTeam.enemy;
        this.addHeroWithHeroConfig(cfg);
    }
}
