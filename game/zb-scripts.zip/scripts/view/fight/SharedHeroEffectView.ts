import { FightViewPool } from "./FightViewPool";
import FightToast from "./FightToast";
import { MyNodePool } from "./MyNodePool";
import cm from "../../manager/ConfigManager";
import commonUtils from "../../utils/CommonUtils";
import loadUtils from "../../utils/LoadUtils";
/**
 * 用于播放英雄的spine动画
 */
export class SharedHeroEffectView extends rpgfight.SharedEffectView {
	root: cc.Node = new cc.Node("SharedHeroEffectView");
	rootBg: cc.Node = new cc.Node("SharedHeroEffectView");
	rootToast: cc.Node = new cc.Node("SharedHeroEffectView");

	constructor() {
		super();
		this.root.name = "hero_effect_root";
		this.root.zIndex = 1024;
		this.rootBg.name = "hero_effect_root_bg";
		this.rootBg.zIndex = -1024;
		this.rootToast.name = "hero_effect_root_toast";
		this.rootToast.zIndex = 1025;

		this._effectPool = new MyNodePool();
	}
	setParent(p: cc.Node) {
		this.root.parent = p;
		this.rootBg.parent = p;
		this.rootToast.parent = p;
	}
	protected _effectPool: MyNodePool;
	protected _toastEffectKey: string = "play_toast_effect";
	protected _killEffectKey: string = "play_kill_effect";

	protected async _createFightToast(hero: rpgfight.Hero): Promise<FightToast> {
		if (hero.manager && (hero.manager as any).skip) {
			return;
		}

		return new Promise<FightToast>((resolve, reject) => {
			let key = this._toastEffectKey
			FightViewPool.inst.getPrefabInst(key, "prefabs/fight/fight_toast", (error, node: cc.Node) => {
				if (error) {
					reject(error);
					return;
				}
				if (!cc.isValid(this.rootToast)) {
					reject("root not valid");
					return;
				}

				for (let child of this.rootToast.children) {
					if (child.name == hero.heroData.heroId) {
						child.stopAllActions();
						child.runAction(cc.callFunc(() => { child.y += 60; }));
					}
				}

				let toast = node.getComponent(FightToast);
				toast.reset();
				toast.hero = hero;

				node.name = hero.heroData.heroId;

				node.x = hero.position.x;
				node.y = hero.position.y + 140;
				node.parent = this.rootToast;
				resolve(toast);
			});
		})
	}

	async playHurtEffect(hero: rpgfight.Hero, options: rpgfight.HurtOptions) {
		if (hero.manager && (hero.manager as any).skip) {
			return;
		}


		let value = Math.floor(options.value);
		if (value <= 0) {
			return;
		}

		// 是否暴击
		let isCrit = options.isCrit;
		try {
			let toast = await this._createFightToast(hero);
			if (isCrit) {
				toast.showCrit(`-${value}`, () => {
					toast.node.parent = null
					FightViewPool.inst.put(this._toastEffectKey, toast.node, true)
				});
			}
			else {
				toast.showHurt(`-${value}`, () => {
					toast.node.parent = null
					FightViewPool.inst.put(this._toastEffectKey, toast.node, true)
				});
			}
		} catch (error) {
			console.error(error);
		}
	}

	async playHealEffect(hero: rpgfight.Hero, options: rpgfight.HealOptions) {
		if (hero.manager && (hero.manager as any).skip) {
			return;
		}

		if (options.from == rpgfight.HealFrom.Self) {
			return;
		}

		let value = Math.floor(options.value);
		if (value <= 0) {
			return;
		}

		try {
			let toast = await this._createFightToast(hero);
			toast.showHeal(`+${value}`, () => {
				toast.node.parent = null
				FightViewPool.inst.put(this._toastEffectKey, toast.node, true)
			});
		} catch (error) {
			console.error(error);
		}
	}

	async playPowerEffect(hero: rpgfight.Hero, options: rpgfight.PowerOptions) {
		if (hero.manager && (hero.manager as any).skip) {
			return;
		}

		if (options.from != rpgfight.PowerFrom.Buff
			&& options.from != rpgfight.PowerFrom.Kill
			&& options.from != rpgfight.PowerFrom.Skill) {
			return;
		}

		let value = Math.floor(options.value);
		if (value <= 0) {
			return;
		}

		try {
			let toast = await this._createFightToast(hero);
			toast.showPower(`+${value}`, () => {
				toast.node.parent = null
				FightViewPool.inst.put(this._toastEffectKey, toast.node, true)
			});
		} catch (error) {
			console.error(error);
		}
	}

	async playBuffEffect(hero: rpgfight.Hero, options: rpgfight.BuffOptions) {
		if (hero.manager && (hero.manager as any).skip) {
			return;
		}

		let value = Math.floor(options.value);
		if (value == 0) {
			return;
		}

		let skillIdTables = {
			"6004": true,
			"7003": true,
			"7004": true,
			"9004": true,
			"34003": true,
			"34004": true,
			"35004": true,
			"36004": true,
			"24003": true,
			"24004": true,
			"22003": true
		}
		if (options.theSkill && skillIdTables[options.theSkill.config.skillId]) {
			return;
		}

		if (options.theSkill) {
			let skillId = Number(options.theSkill.config.skillId);
			let config = cm.getSkillConfig(skillId);
			if (config) {
				if (config.fruitskill > 0 || Math.floor(config.Id / 1000) == 998) {
					return;
				}
			}
		}

		try {
			let toast = await this._createFightToast(hero);
			toast.showBuf(hero, options.effect, () => {
				toast.node.parent = null
				FightViewPool.inst.put(this._toastEffectKey, toast.node, true)
			}, options.value);
		} catch (error) {
			console.error(error);
		}
	}

	playKillEffect(hero: rpgfight.Hero, options: rpgfight.KillOptions) {
		if (hero.manager && (hero.manager as any).skip) {
			return;
		}

		let value = Math.floor(options.killCount);
		if (value < 2 || value > 5) {
			return;
		}

		let key = this._killEffectKey
		FightViewPool.inst.getPrefabInst(key, "prefabs/fight/fight_kill", (error, node: cc.Node) => {
			if (error) { console.error(error); }
			if (!cc.isValid(this.rootToast)) {
				return;
			}

			for (let child of this.rootToast.children) {
				if (child.name == hero.heroData.heroId) {
					child.stopAllActions();
					child.runAction(cc.callFunc(() => { child.y += 60; }));
				}
			}

			node.name = hero.heroData.heroId;
			node.position = cc.p(hero.position.x, hero.position.y + 160);
			node.parent = this.rootToast

			let ico = node.getChildByName("ico");
			ico.getComponent(cc.Sprite).spriteFrame = null;

			let animation = ico.getComponent(cc.Animation);
			animation.off("finished");
			animation.on("finished", () => {
				node.parent = null
				FightViewPool.inst.put(key, node, true)
			}, this);
			animation.play(`kill${value}`);

			let update = cc.Animation.prototype['update'];
			animation['update'] = (dt: number) => {
				if (update) { update.call(animation, dt); }
				node.x = hero.position.x;
			}
		});
	}

	async playMaskEffect(opacity: number, duration: number) {
		let node = new cc.Node("mask effect");
		let res = cc.loader.getRes(commonUtils.getCommonUrl("common_splash"), cc.SpriteFrame);
		if (!res) {
			res = await loadUtils.loadRes(commonUtils.getCommonUrl("common_splash"), cc.SpriteFrame) as cc.SpriteFrame;
		}
		let sprite = node.addComponent(cc.Sprite);
		sprite.spriteFrame = res;
		sprite.type = cc.Sprite.Type.SLICED;
		sprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;

		node.setContentSize(cc.winSize.width, 2048);
		node.opacity = opacity;
		node.color = cc.Color.BLACK;
		node.zIndex = -2;
		node.parent = this.root;
		node.runAction(cc.sequence(cc.delayTime(duration / 1000), cc.callFunc(() => { node.destroy() })));
	}

	destroy() {
		let node = FightViewPool.inst.get(this._toastEffectKey)
		while (node) {
			node.parent = null
			node.destroy()
			node = FightViewPool.inst.get(this._toastEffectKey)
		}

		node = FightViewPool.inst.get(this._killEffectKey)
		while (node) {
			node.parent = null;
			node.destroy();
			node = FightViewPool.inst.get(this._killEffectKey);
		}

		if (this.root.parent) {
			this.root.removeFromParent();
			this.root.destroy();
			this.root = null
		}
		if (this.rootBg.parent) {
			this.rootBg.removeFromParent();
			this.rootBg.destroy();
			this.rootBg = null;
		}
		if (this.rootToast.parent) {
			this.rootToast.removeFromParent();
			this.rootToast.destroy();
			this.rootToast = null;
		}
	}
}
