import { MyNodePool } from "./MyNodePool";
import loadUtils from "../../utils/LoadUtils";

export class FightViewPool {
    static readonly inst: FightViewPool = new FightViewPool;

    nodePool: MyNodePool = new MyNodePool()

    /**
     * 预加载某一场战斗的所有资源
     */
    preload() {

    }

    /**
     * 获取一个spine动画，如果对象池中没有则会异步加载
     * @param callback 动画回调
     */
    async getSpine(path: string, callback: (animNode: cc.Node, anim: sp.Skeleton) => void) {
        try {
            let res = cc.loader.getRes(path, sp.SkeletonData);
            if (!res) {
                res = await loadUtils.loadResOnce(path, sp.SkeletonData) as sp.SkeletonData;
            }
            let node = new cc.Node();
            let sk = node.addComponent(sp.Skeleton);
            sk.skeletonData = res;
            callback(node, sk);
        } catch (err) {
            console.error(err);
        }
    }

    /**
     * 获取一个spine动画，如果对象池中没有则会异步加载
     * @param callback 动画回调
     */
    async getSpineInst(key: string, path: string, callback: (err: Error, animNode: cc.Node, anim: sp.Skeleton) => void) {
        let node = this.nodePool.get(key)
        if (node) {
            let sk = node.getComponent(sp.Skeleton)
            callback(null, node, sk)
        } else {
            try {
                let res = await loadUtils.loadResOnce(path, sp.SkeletonData) as sp.SkeletonData;
                let node = new cc.Node();
                let sk = node.addComponent(sp.Skeleton);
                sk.skeletonData = res;
                callback(null, node, sk);
            } catch (err) {
                console.error(err);
                callback(err, null, null);
            }
        }
    }

    /**
     * 用key从节点池中寻找缓存节点，如果没有，则加载预制体，并实例化一个节点
     * @param key 
     * @param path 
     * @param callback 
     */
    async getPrefabInst(key: string, path: string, callback: (error: Error, node: cc.Node) => void) {
        if (this.nodePool.size(key) > 0) {
            let node = this.nodePool.get(key)
            callback(null, node)
        } else {
            try {
                let prefab = await loadUtils.loadResOnce(path, cc.Prefab) as cc.Prefab;
                let node = cc.instantiate(prefab);
                callback(null, node);
            } catch (error) {
                callback(error, null);
            }
        }
    }

    /**
     * 回收节点
     * @param key 
     * @param node 
     */
    put(key: string, node: cc.Node, allowParent: boolean = false) {
        this.nodePool.put(key, node, allowParent)
    }

    /**
     * 获取缓存节点
     * @param key 
     */
    get(key: string) {
        return this.nodePool.get(key)
    }

    unloadAll() {
        this.nodePool.clearAll()
    }

}