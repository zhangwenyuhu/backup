import { PopupPanel } from "../BasePanel";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import DailyTask from "../../../data/assignment/DailyTask";
import MainTask from "../../../data/assignment/MainTask";
import commonUtils from "../../../utils/CommonUtils";
import loadUtils from "../../../utils/LoadUtils";
import cm from "../../../manager/ConfigManager";
import CommonLoader from "../../common/CommonLoader";
import assignmentLogic from "../../../logics/AssignmentLogic";
import { AssignPre, DailyType, WeekType, MainType, VideoKey, MainView } from "../../../utils/DefineUtils";
import gm from "../../../manager/GameManager";
import stringUtils from "../../../utils/StringUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import { StoreTab } from "../store/StorePanel";
import VideoBtn from "../../../gleecomponent/VideoBtn";
import EManager, { EName } from "../../../manager/EventManager";
import redPointLogic, { RedPointType } from "../../../logics/RedPointLogic";
import bagLogic from "../../../logics/BagLogic";
import gotoUtils, { GotoModule } from "../../../utils/GotoUtils";
import commitLogic from '../../../logics/CommitLogic';
import { NavigateTabIndex } from "../../common/NavigateButton";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/assignment/AssignmentPanel")
export default class AssignmentPanel extends PopupPanel {

    @property(cc.Node)
    dailyNode: cc.Node = null;

    @property(cc.Node)
    weekNode: cc.Node = null;

    @property(cc.Node)
    mainNode: cc.Node = null;

    @property(cc.Node)
    dailyScrollView: cc.Node = null;

    @property(cc.Node)
    weekScrollView: cc.Node = null;

    @property(cc.Node)
    mainScrollView: cc.Node = null;

    @property(cc.Node)
    rewards: cc.Node = null;

    @property(cc.Node)
    reward: cc.Node = null;

    @property(cc.Node)
    scoreProgress: cc.Node = null;

    @property(cc.Node)
    tips: cc.Node = null;

    @property(cc.Node)
    tips_reward: cc.Node = null;

    @property(cc.Node)
    touch: cc.Node = null;

    @property(cc.Node)
    week_rewards: cc.Node = null;

    @property(cc.Node)
    week_reward: cc.Node = null;

    @property(cc.Node)
    week_scoreProgress: cc.Node = null;

    @property(cc.Node)
    dailyTimeStamp: cc.Node = null;

    @property(cc.Node)
    weekTimeStamp: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    boxEffectNode: cc.Node = null;

    @property(cc.Node)
    scoreEffectNode: cc.Node = null;

    @property(CommonLoader)
    btnVideoAd: CommonLoader = null;

    @property(cc.Node)
    adNode: cc.Node = null;

    private _currentTab: number = 1;
    private _touchBtns: { desc?: any, btn: cc.Node, index: number }[] = [];
    private _dailyBoxs: { node: cc.Node, index: number, uid: number }[] = [];
    private _weekBoxs: { node: cc.Node, index: number, uid: number }[] = [];
    private _dailyTs: number = 0;
    private _weekTs: number = 0;
    private _rewarding: boolean = false;
    private _rewardingId: number = 0;
    private _effecting: boolean = false;
    private _btnClicking: boolean = false;

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
        this.tips_reward.parent = null;
        this.reward.parent = null;
        this.week_reward.parent = null;

        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data == "AssignmentPanel") {
                this.mainTaskReq();
            }
        });
        this._eventListeners.push(listener);
    }

    onDestroy() {
        super.onDestroy();

        this.unregisterTouch();
        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
        this.tips_reward.destroy();
        this.reward.destroy();
        this.week_reward.destroy();
    }

    async start() {
        super.start();
        this.boxEffectNode.active = false;
        this.adNode.active = false;
        this.showTab(1);
        this.initDailyRewards();
        this.initWeekRewards();
        this.registerTouch();
        this.freshDaily();
        this.freshTaskTimeStamp();

        this.registerEvent();
        EManager.emit(EName.onFreshRed, RedPointType.Assign);
    }

    protected registerEvent() {
        let listener = EManager.addEvent(EName.onComingNewDay, (data) => {
            this.refreshDailyData();
        });
        this._eventListeners.push(listener);
    }
    protected async refreshDailyData() {
        console.log('跨天,重新请求每日任务数据');
        await assignmentLogic.tasksReq(0);
        if (this._currentTab == 1) {
            this.showDailyScrollView();
            this.freshDaily();
        }
    }

    async mainTaskReq() {
        await assignmentLogic.mainTaskReq(0);
        if (this.mainNode.active) { this.showMainScrollView(); }
    }

    private showTips(data: { desc?: any, btn: cc.Node, index: number }, pos: cc.Vec2) {
        this.touch.active = true;

        let rewards: cc.Node = this.tips.getChildByName("rewards");
        let bg: cc.Node = this.tips.getChildByName("bg");
        let desc: cc.Node = this.tips.getChildByName("desc");
        this.tips.active = true;

        let tmpPos = this.tips.parent.convertToNodeSpace(pos);
        let size = this.tips.parent.getContentSize();
        //this.tips.position = cc.v2(tmpPos.x - size.width / 2, tmpPos.y - size.height + 50);
        let px: number = cc.winSize.width / 2 > pos.x ? pos.x - cc.winSize.width / 2 : pos.x - cc.winSize.width / 2;
        let py: number = cc.winSize.height / 2 > pos.y ? pos.y - cc.winSize.height / 2 : pos.y - cc.winSize.height / 2;
        this.tips.position = cc.v2(px, py + this.tips.getContentSize().height);
        let anchX: number = this.tips.x > 0 ? 1 : 0;
        bg.anchorX = anchX;
        desc.anchorX = anchX;
        rewards.anchorX = anchX;
        if (data && data.desc) {
            // 文字提示
            rewards.active = false;
            desc.active = true;
            desc.getComponent(cc.Label).string = data.desc;
            this.scheduleOnce(() => {
                bg.width = desc.width + 20;
                bg.height = desc.height + 20;
                if (bg.anchorX == 1) {
                    bg.x = 10;
                } else {
                    bg.x = -10;
                }
            });
        } else {
            // 物品奖励
            rewards.active = true;
            rewards.destroyAllChildren();
            desc.active = false;

            let cfg = cm.getActiveRewardConfig(data.index);
            let boxRewards: number[][] = cfg.reward;
            let exReward = assignmentLogic.getActivityExReward(cfg.type, cfg.vitality);
            if (exReward && exReward.length > 0) { boxRewards = boxRewards.concat(exReward); }
            for (let i = 0; i < boxRewards.length; i++) {
                let tmp = cc.instantiate(this.tips_reward);
                tmp.parent = rewards;
                tmp.getChildByName("good").destroyAllChildren();
                gm.showGoodItem(boxRewards[i], {
                    goodItem: this.goodItem,
                    equipItem: this.equipItem,
                    heroItem: this.heroItem
                }, tmp.getChildByName("good"), 0.66);

                let got: boolean = false;
                if (this._currentTab == 1) {
                    got = assignmentLogic._dailyRewards[data.index];
                } else if (this._currentTab == 2) {
                    got = assignmentLogic._weekRewards[data.index];
                }
                tmp.getChildByName("got").active = got;
                tmp.getChildByName("gray").active = got;
            }

            this.scheduleOnce(() => {
                bg.width = rewards.width + 20;
                bg.height = rewards.height + 20;
                if (bg.anchorX == 1) {
                    bg.x = 10;
                } else {
                    bg.x = -10;
                }
            });
        }
    }
    private hideTips() {
        this.tips.active = false;
        this.touch.active = false;
        assignmentLogic._mainTouch = null;
    }
    async boxReward(data: { desc?: any, btn: cc.Node, index: number }) {
        if (data.index > 0) {
            let cfg = cm.getActiveRewardConfig(data.index);
            if (this._currentTab == 1) {
                if (!assignmentLogic._dailyRewards[data.index]) {
                    if (assignmentLogic._dailyScore >= cfg.vitality) {
                        this.showBoxEffect(() => {
                            this._rewardingId = data.index;
                            this.validAd(true);
                        });
                    }
                }
            } else if (this._currentTab == 2) {
                if (!assignmentLogic._weekRewards[data.index]) {
                    if (assignmentLogic._weekScore >= cfg.vitality) {
                        this.showBoxEffect(() => {
                            this.showBoxEffect(() => {
                                this.getActiveReward(data.index);
                            }, "baoxianxiang2")
                            //await assignmentLogic.activeRewardReq(data.index);
                            //this.freshWeek();
                        });
                    }
                }
            }
        }
    }

    // 宝箱打开动画
    showBoxEffect(callback: Function, name: string = "baoxianxiang1") {
        if (this._effecting) { return; };

        this._effecting = true;
        this.boxEffectNode.active = true;
        let action = this.boxEffectNode.getComponent(cc.Animation);
        action.play(name, 0);
        action.off("finished");
        action.on("finished", (e) => {
            if (name == "baoxianxiang2") {
                this.boxEffectNode.active = false;
            }
            this._effecting = false;
            if (callback) {
                callback();
            }
        })
    }

    validAd(valid: boolean) {
        this.adNode.active = valid;
        if (this.adNode.active) {
            this.btnVideoAd.loaderNode.getComponent(VideoBtn).videoText = "双倍领取";
            this.btnVideoAd.loaderNode.getComponent(VideoBtn).eventName = VideoKey.DailyTask;
            this.btnVideoAd.loaderNode.getComponent(VideoBtn).onSuccessFunc = () => {
                this.showBoxEffect(() => {
                    this.adNode.active = false;
                    this.getActiveReward(this._rewardingId, true);
                }, "baoxianxiang2");
            }

            let btnFree = this.adNode.getChildByName("btnFree");
            btnFree.off(cc.Node.EventType.TOUCH_END);
            btnFree.off(cc.Node.EventType.TOUCH_START);
            btnFree.off(cc.Node.EventType.TOUCH_CANCEL);
            btnFree.on(cc.Node.EventType.TOUCH_START, (e) => {
                btnFree.scale = 1.1;
            });
            btnFree.on(cc.Node.EventType.TOUCH_CANCEL, (e) => {
                btnFree.scale = 1;
            });
            btnFree.on(cc.Node.EventType.TOUCH_END, (e) => {
                btnFree.scale = 1;
                this.showBoxEffect(() => {
                    this.adNode.active = false;
                    this.getActiveReward(this._rewardingId);
                }, "baoxianxiang2");
            });
        }

        let adRewards = this.adNode.getChildByName("adReward").getChildByName("rewards");
        let cfg = cm.getActiveRewardConfig(this._rewardingId);
        let boxRewards: number[][] = cfg.reward;
        adRewards.destroyAllChildren();
        for (let i = 0; i < boxRewards.length; i++) {
            gm.showGoodItem([boxRewards[i][0], boxRewards[i][1]], {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem
            }, adRewards, 0.66);
        }
    }

    async getActiveReward(id: number, bVideo: boolean = false) {
        try {
            await assignmentLogic.activeRewardReq(id, bVideo);
            EManager.emit(EName.onFreshRed, RedPointType.Assign);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
        if (this._currentTab == 1) {
            this.freshDaily();
        } else if (this._currentTab == 2) {
            this.freshWeek();
        }
    }

    // 积分获得动画
    showGetScoreEffect(from: cc.Vec2, callback: Function) {
        this._rewarding = true;

        let toPos = this.rewards.position;
        from.x -= 375;
        from.y -= 667;
        toPos.x += 50;

        this.scoreEffectNode.active = true;
        this.scoreEffectNode.position = from;

        let action = this.scoreEffectNode.getComponent(cc.Animation);
        action.play("daily_itemeffect", 0);
        let sec: number = (toPos.y - from.y) / 1400 + 0.3;
        sec = sec > 1 ? 1 : sec;
        this.scoreEffectNode.runAction(cc.moveTo(sec, toPos));
        this.scheduleOnce(() => {
            if (callback) {
                this.scoreEffectNode.active = false;
                callback();
            }
        }, sec);
    }

    canReward(data: { desc?: any, btn: cc.Node, index: number }): boolean {
        if (data.index > 0) {
            let cfg = cm.getActiveRewardConfig(data.index);
            if (this._currentTab == 1) {
                if (!assignmentLogic._dailyRewards[data.index]) {
                    if (assignmentLogic._dailyScore >= cfg.vitality) {
                        return true;
                    }
                }
            } else if (this._currentTab == 2) {
                if (!assignmentLogic._weekRewards[data.index]) {
                    if (assignmentLogic._weekScore >= cfg.vitality) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    registerTouch() {
        this._touchBtns.forEach((v, i, a) => {
            v.btn.on(cc.Node.EventType.TOUCH_START, (e: cc.Touch) => {
            })
            v.btn.on(cc.Node.EventType.TOUCH_END, (e: cc.Touch) => {
                console.log("AssignmentPanel TouchEnd: " + `(${e.getLocationX()},${e.getLocationY()})`);
                console.log('touch btnClicking: ' + this._btnClicking);
                if (this._btnClicking) { return; }
                this._btnClicking = true;
                if (this.canReward(v)) {
                    this.boxReward(v);
                } else {
                    this.showTips(v, cc.v2(e.getLocationX(), e.getLocationY()));
                }
                this._btnClicking = false;
            })
            v.btn.on(cc.Node.EventType.TOUCH_CANCEL, (e: cc.Touch) => {
            })
        });
    }
    unregisterTouch() {
        this._touchBtns.forEach((v, i, a) => {
            v.btn.off(cc.Node.EventType.TOUCH_START);
            v.btn.off(cc.Node.EventType.TOUCH_END);
            v.btn.off(cc.Node.EventType.TOUCH_CANCEL);
        });
    }

    onClickTab(sender: cc.Event.EventTouch, index: string) {
        let clickTab: number = parseInt(index);
        if (this._currentTab == clickTab) {
            return;
        }

        this._currentTab = clickTab;
        this.showTab(clickTab);
    }

    private showTab(index: number) {

        this.hideTips();
        this.dailyNode.active = false;
        this.weekNode.active = false;
        this.mainNode.active = false;
        if (index == 1) {
            // 日常
            this.dailyNode.active = true;
            this.showDailyScrollView();
            this.freshDaily();
        } else if (index == 2) {
            // 周常 
            this.weekNode.active = true;
            this.showWeekScrollView();
            this.freshWeek();
        } else if (index == 3) {
            // 主线    
            this.mainNode.active = true;
            this.showMainScrollView();
        }
    }

    private showDailyScrollView() {
        let tmp: DailyTask[] = assignmentLogic.getDailyTasks();
        tmp.sort((a, b) => {
            // 小于0 a在b之前 大于0 a在b之后
            return b.getSortIndex() - a.getSortIndex();
        });
        this.dailyScrollView.getComponent(ScrollViewLoader).refresh(tmp, false, this.onClickDailyCell.bind(this));
    }
    private showWeekScrollView() {
        let tmp: DailyTask[] = assignmentLogic.getWeekTasks();
        tmp.sort((a, b) => {
            // 小于0 a在b之前 大于0 a在b之后
            return b.getSortIndex() - a.getSortIndex();
        });
        this.weekScrollView.getComponent(ScrollViewLoader).refresh(tmp, false, this.onClickWeekCell.bind(this));
    }
    private showMainScrollView() {
        let tmp: MainTask[] = assignmentLogic._runnigMainAssign;
        tmp.sort((a, b) => {
            // 小于0 a在b之前 大于0 a在b之后
            return b.getSortIndex() - a.getSortIndex();
        });
        this.mainScrollView.getComponent(ScrollViewLoader).refresh(tmp, false, this.onClickMainCell.bind(this));
    }

    async onClickDailyCell(data: any) {
        this.hideTips();

        if (this._rewarding) { return; }
        if (data instanceof DailyTask) {
            if (data.complete_task) {
                this.showGetScoreEffect(assignmentLogic.flagWorldPos, async () => {
                    await assignmentLogic.taskCompleteCommit(data.id);
                    this.showDailyScrollView();
                    this.freshDaily();
                    this.scheduleOnce(() => { this._rewarding = false; }, 0.1);

                    commitLogic.recvDailyTask(data.id, data.cfg.vitality);
                });
            } else {
                this.assignmentGoto(data.cfg.tasktypeID);
            }
        }
    }
    async onClickWeekCell(data: any) {
        this.hideTips();
        if (this._rewarding) { return; }
        if (data instanceof DailyTask) {
            if (data.complete_task) {
                this.showGetScoreEffect(assignmentLogic.flagWorldPos, async () => {
                    this.dailyTaskReward(data.id);
                    commitLogic.recvWeekTask(data.id, data.cfg.vitality);
                })

            } else {
                this.assignmentGoto(data.cfg.tasktypeID);
            }
        }
    }

    onClickMainCell(data: any) {
        if (data instanceof MainTask) {
            if (data.complete_task) {
                // get reward
                this.mainTaskReward(data.id);
            } else {
                // goto
                //this.assignmentGoto(data.cfg.tasktype);
                gm.toast(stringConfigMap.key_common_tip1.Value);
            }
        }
    }

    // 任务前往
    assignmentGoto(taskTypeId: number) {
        if (taskTypeId > AssignPre.Daily && taskTypeId < AssignPre.Week) {
            // 日常
            let type: number = taskTypeId;
            switch (type) {
                case DailyType.fight_header:
                    gotoUtils.gotoView(NavigateTabIndex.Battle);
                    break;
                case DailyType.hangup_reward:
                    gotoUtils.gotoView(NavigateTabIndex.Battle);
                    break;
                case DailyType.hangup_quick:
                    gotoUtils.gotoPanel(GotoModule.HangUpFast);
                    break;
                case DailyType.levelup_hero:
                    gotoUtils.gotoView(NavigateTabIndex.Hero);
                    break;
                case DailyType.strong_equip:
                    {
                        let canStrong = false;
                        let equips = bagLogic.getEquips();
                        for (let equip of equips) {
                            if (equip.getRank() > 2 && equip.getStar() < equip.getStarLimit()) {
                                canStrong = true;
                                break;
                            }
                        }
                        if (!canStrong) {
                            gm.toast(stringConfigMap.key_goto_strong_equip_tip.Value);
                            return;
                        }
                        gotoUtils.gotoView(NavigateTabIndex.Hero);
                    }
                    break;
                case DailyType.fight_tower:
                    gotoUtils.gotoPanel(GotoModule.Tower);
                    break;
                case DailyType.send_friend:
                    gotoUtils.gotoPanel(GotoModule.Friend);
                    break;
                case DailyType.summon_hero:
                    gotoUtils.gotoPanel(GotoModule.ChouKa);
                    break;
                case DailyType.fight_union:
                    gotoUtils.gotoPanel(GotoModule.Union);
                    break;
                case DailyType.fight_arena:
                    gotoUtils.gotoPanel(GotoModule.Arena);
                    break;
                case DailyType.task_xuanshang:
                    gotoUtils.gotoPanel(GotoModule.Xuanshang);
                    break;
                case DailyType.buy_store:
                    gotoUtils.gotoPanel(GotoModule.Store);
                    break;
                case DailyType.zhuanpan_go:
                    gotoUtils.gotoPanel(GotoModule.ZhuanPan);
                    break;
                default:
                    break;
            }
        } else if (taskTypeId > AssignPre.Week && taskTypeId < AssignPre.Main) {
            // 周常
            let type: number = taskTypeId;
            switch (type) {
                case WeekType.fight_maze_boss:
                case WeekType.fight_maze_bossex:
                    gotoUtils.gotoPanel(GotoModule.Mazon);
                    break;
                case WeekType.buy_maze_shop:
                    gotoUtils.gotoPanel(GotoModule.Store, true, StoreTab.Maze);
                    break;
                case WeekType.buy_shop:
                    gotoUtils.gotoPanel(GotoModule.Store);
                    break;
                case WeekType.buy_equip_unionshop:
                    gotoUtils.gotoPanel(GotoModule.Store, true, StoreTab.Normal);
                    break;
                case WeekType.advance_hero:
                    gotoUtils.gotoPanel(GotoModule.AdvanceHero);
                    break;
                case WeekType.summon_hero:
                    gotoUtils.gotoPanel(GotoModule.ChouKa);
                    break;
                case WeekType.win_arena:
                    gotoUtils.gotoPanel(GotoModule.Arena);
                    break;
                case WeekType.task_xuanshang:
                    gotoUtils.gotoPanel(GotoModule.Xuanshang);
                    break;
                case WeekType.faction_summon_hero:
                    gotoUtils.gotoPanel(GotoModule.FactionChouka);
                    break;
                case WeekType.evolution_hero:
                    gotoUtils.gotoPanel(GotoModule.AddStar);
                    break;
                case WeekType.fight_mat:
                    gotoUtils.gotoPanel(GotoModule.Material);
                    break;
                case WeekType.send_friendship:
                    gotoUtils.gotoPanel(GotoModule.Friend);
                    break;
                default:
                    break;
            }
        } else if (taskTypeId > AssignPre.Main) {
            // 主线
            let type: number = taskTypeId - AssignPre.Main;
            switch (type) {
                case MainType.mission_complete:
                case MainType.maze_complete:
                case MainType.tower_complete:
                case MainType.level_team:
                case MainType.level_hero:
                case MainType.chapter_complete:
                case MainType.win_arena:
                case MainType.level_share:
                case MainType.level_raceTower:
                case MainType.account_bind:
                case MainType.score_arena:
                case MainType.num_hero:
                case MainType.hangup_gold:
                case MainType.num_purpleHero:
                    // 
                    break;
                default:
                    break;
            }
        }
        this.closePanel();
    }

    async dailyTaskReward(id: number) {
        try {
            await assignmentLogic.taskCompleteCommit(id);
            this.showWeekScrollView();
            this.freshWeek();
            this.scheduleOnce(() => { this._rewarding = false; }, 0.1);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
                this.showTab(this._currentTab);
            }
            else {
                throw e;
            }
        }
    }

    async mainTaskReward(id: number) {
        try {
            await assignmentLogic.mainTaskGetRewardReq(id);
            this.showMainScrollView();
            EManager.emit(EName.onFreshRed, RedPointType.Assign);
            commitLogic.recvMainTaskReward(id);

            if (!assignmentLogic.mainTaskRed()) {
                redPointLogic.closeRedPoint(RedPointType.Assign_Main);
                redPointLogic.closeRedPoint(RedPointType.Assign);
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
                this.showTab(this._currentTab);
            }
            else {
                throw e;
            }
        }
    }

    private initDailyRewards() {
        this.rewards.destroyAllChildren();
        this.rewards.getComponent(cc.Layout).spacingX = 0;

        let tmp: cc.Node = cc.instantiate(this.reward);
        let str: string = stringConfigMap.key_assignment_tip1.Value;
        tmp.parent = this.rewards;
        this._touchBtns.push({ desc: str, btn: tmp.getChildByName("btn"), index: 0 });
        this._dailyBoxs.push({ node: tmp, index: 0, uid: 0 });

        Object.keys(assignmentLogic._dailyRewards).forEach((v, i, a) => {
            let node: cc.Node = cc.instantiate(this.reward);
            node.parent = this.rewards;

            this._touchBtns.push({ btn: node.getChildByName("btn"), index: parseInt(v) });
            this._dailyBoxs.push({ node: node, index: i + 1, uid: parseInt(v) });
        });
    }
    // 刷新日常任务进度和宝箱状态
    private freshDaily() {
        // 进度
        this.scoreProgress.getComponent(cc.ProgressBar).progress = assignmentLogic._dailyScore / assignmentLogic._maxScore;

        // 宝箱
        this._dailyBoxs.forEach((v, i, a) => {
            if (v.node) {
                let bg: cc.Node = v.node.getChildByName("bg");
                let icon: cc.Node = v.node.getChildByName("icon");
                let score: cc.Node = v.node.getChildByName("score");

                if (v.uid <= 0) {
                    bg.active = false;
                    loadUtils.loadSpriteFrame(commonUtils.getAssignmentIconUrl("assignment_12"), icon.getComponent(cc.Sprite));
                    score.getComponent(cc.Label).string = `${assignmentLogic._dailyScore}`;
                } else {
                    let cfg = cm.getActiveRewardConfig(v.uid);
                    let complete: boolean = assignmentLogic._dailyScore >= cfg.vitality;
                    let recv: boolean = assignmentLogic._dailyRewards[v.uid];

                    let bgValid: boolean = complete && !recv;
                    bg.active = bgValid;
                    let iconStr: string = recv ? "assignment_7" : "assignment_6";
                    loadUtils.loadSpriteFrame(commonUtils.getAssignmentIconUrl(iconStr), icon.getComponent(cc.Sprite));
                    score.getComponent(cc.Label).string = `${cfg.vitality}`;

                    if (complete && !recv) {
                        v.node.getComponent(cc.Animation).play("ap_miniicon");
                    } else {
                        let ani = v.node.getComponent(cc.Animation);
                        if (ani) {
                            ani.setCurrentTime(0);
                            ani.stop("ap_miniicon");
                        }
                        v.node.y = 0;
                    }
                }
            }
        });
    }

    private initWeekRewards() {
        this.week_rewards.destroyAllChildren();
        this.week_rewards.getComponent(cc.Layout).spacingX = 0;

        let tmp: cc.Node = cc.instantiate(this.week_reward);
        let str: string = stringConfigMap.key_assignment_tip1.Value;
        tmp.parent = this.week_rewards;
        this._touchBtns.push({ desc: str, btn: tmp.getChildByName("btn"), index: 0 });
        this._weekBoxs.push({ node: tmp, index: 0, uid: 0 });

        Object.keys(assignmentLogic._weekRewards).forEach((v, i, a) => {
            let node: cc.Node = cc.instantiate(this.week_reward);
            node.parent = this.week_rewards;

            this._touchBtns.push({ btn: node.getChildByName("btn"), index: parseInt(v) });
            this._weekBoxs.push({ node: node, index: i + 1, uid: parseInt(v) });
        });
    }
    // 刷新周任务进度和宝箱状态
    private freshWeek() {
        // 进度
        this.week_scoreProgress.getComponent(cc.ProgressBar).progress = assignmentLogic._weekScore / assignmentLogic._maxScore;

        // 宝箱
        this._weekBoxs.forEach((v, i, a) => {
            if (v.node) {
                let bg: cc.Node = v.node.getChildByName("bg");
                let icon: cc.Node = v.node.getChildByName("icon");
                let score: cc.Node = v.node.getChildByName("score");

                if (v.uid <= 0) {
                    bg.active = false;
                    loadUtils.loadSpriteFrame(commonUtils.getAssignmentIconUrl("assignment_12"), icon.getComponent(cc.Sprite));
                    score.getComponent(cc.Label).string = `${assignmentLogic._weekScore}`;
                } else {
                    let cfg = cm.getActiveRewardConfig(v.uid);
                    let complete: boolean = assignmentLogic._weekScore >= cfg.vitality;
                    let recv: boolean = assignmentLogic._weekRewards[v.uid];

                    let bgValid: boolean = complete && !recv;
                    bg.active = bgValid;
                    let iconStr: string = recv ? "assignment_7" : "assignment_6";
                    loadUtils.loadSpriteFrame(commonUtils.getAssignmentIconUrl(iconStr), icon.getComponent(cc.Sprite));
                    score.getComponent(cc.Label).string = `${cfg.vitality}`;

                    if (complete && !recv) {
                        v.node.getComponent(cc.Animation).play("ap_miniicon");
                    } else {
                        let ani = v.node.getComponent(cc.Animation);
                        if (ani) {
                            ani.setCurrentTime(0);
                            ani.stop("ap_miniicon");
                        }
                        v.node.y = 0;
                    }
                }
            }
        });
    }

    private freshTaskTimeStamp() {
        this._dailyTs = (assignmentLogic._dailyTs - gm.getCurrentTimestamp()) / 1000;
        this._weekTs = (assignmentLogic._weekTs - gm.getCurrentTimestamp()) / 1000;
        this._dailyTs = this._dailyTs > 0 ? this._dailyTs : 0;
        this._weekTs = this._weekTs > 0 ? this._weekTs : 0;
        this.dailyTimeStamp.getComponent(cc.Label).string = stringUtils.formatTimeWithHour(this._dailyTs);
        this.weekTimeStamp.getComponent(cc.Label).string = stringUtils.formatTimeWithHour(this._weekTs);
        this.schedule(this.freshTaskPerSecond, 1);
    }

    freshTaskPerSecond() {
        if (this._dailyTs <= 0 || this._weekTs <= 0) {
            //this.unschedule(this.freshTaskPerSecond);
            //this.refreshDaily();
            //return 
        }
        this._dailyTs -= 1;
        this._weekTs -= 1;

        this._dailyTs = this._dailyTs > 0 ? this._dailyTs : 0;
        this._weekTs = this._weekTs > 0 ? this._weekTs : 0;

        if (this._currentTab == 1) {
            this.dailyTimeStamp.getComponent(cc.Label).string = stringUtils.formatTimeWithHour(this._dailyTs);
        } else { this._currentTab == 2 } {
            this.weekTimeStamp.getComponent(cc.Label).string = stringUtils.formatTimeWithHour(this._weekTs);
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await assignmentLogic.mainTaskReq(0);
        await assignmentLogic.tasksReq(0);
    }
}
