import BasePanel, { PopupPanel } from "../BasePanel";
import cm from "../../../manager/ConfigManager";
import gm from "../../../manager/GameManager";
import guideTaskLogic from "../../../logics/GuideTaskLogic";
import EManager, { EName } from "../../../manager/EventManager";
import gotoUtils, { GotoModule } from "../../../utils/GotoUtils";
import { MainView } from "../../../utils/DefineUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/assignment/GuideTaskPanel")
export default class GuideTaskPanel extends PopupPanel {

    @property(cc.Node)
    rewards: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    title: cc.Node = null;

    @property(cc.Node)
    desc: cc.Node = null;

    @property(cc.Node)
    proNum: cc.Node = null;

    protected guideTaskId: number = 1001;
    onInit(data: any) {
        if (data) {
            this.guideTaskId = data;
        }
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        EManager.emit(EName.onFreshGuideTask);
        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();

        this.freshUI();
    }

    freshUI() {
        let guideTask = guideTaskLogic.getGuideTask(this.guideTaskId);
        let cfg = cm.getGuideTaskConfig(this.guideTaskId);
        this.title.getComponent(cc.Label).string = cfg.tasktitle;
        this.desc.getComponent(cc.Label).string = cfg.describe;

        this.proNum.getComponent(cc.Label).string = guideTask.getShowPro();
        //this.proNum.color=cc.Color.RED;

        let btnText = cc.find("bg/ok/label", this.node);
        if (btnText) {
            let str = guideTask.isComplete() ? "领取奖励" : "前 往";
            btnText.getComponent(cc.Label).string = str;
        }

        // reward
        this.rewards.destroyAllChildren();
        let rewards: number[][] = cfg.reward;
        rewards.forEach((v, i, a) => {
            gm.showGoodItem(v, {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem
            }, this.rewards);
        });
    }

    async onClickGoto(sender: cc.Event.EventTouch, index: string) {
        let cfg = cm.getGuideTaskConfig(this.guideTaskId);
        let guideTask = guideTaskLogic.getGuideTask(this.guideTaskId);
        let complete: boolean = guideTask.isComplete();
        if (complete) {
            try {
                await guideTaskLogic.guideTaskRewardReq(cfg.ID);
                this.guideTaskId = cfg.nexttask;
                let nextTask = guideTaskLogic.getGuideTask(this.guideTaskId);
                if (nextTask) {
                    if (!nextTask.hasLocalPro() && guideTaskLogic.getGuideTaskPro(nextTask.getId()) < 0) {
                        await guideTaskLogic.guideTaskProgressCommit(nextTask.getCfg().tasktype, 0);
                    }
                    this.freshUI();
                } else {
                    this.closePanel();
                }


            } catch (e) {
                if (e.name == "ToastError") {
                    gm.toast(e.message);
                }
                else {
                    throw e;
                }
            }
        } else {
            this.gotoTask(cfg.ID);
        }
    }

    private gotoTask(id: number) {
        let cfg = cm.getGuideTaskConfig(id);
        switch (cfg.tasktype) {
            case 3006:
                break;
            case 5002:
                // 穿装备
                gotoUtils.gotoView(MainView.Hero);
                break;
            case 5003:
                // 3个英雄10级
                gotoUtils.gotoView(MainView.Hero);
                break;
            case 5007:
                // 挂机奖励
                break;
            case 3015:
                //改名
                gotoUtils.gotoPanel(GotoModule.ChangeName);
                break;
            case 5006:
                //智慧树战斗
                gotoUtils.gotoView(MainView.Base);
                break;
            case 1007:
                // 快速挂机
                break;
            case 3014:
                // 获得紫色英雄
                gotoUtils.gotoPanel(GotoModule.ChouKa);
                break;
            case 5005:
                // 升级紫色英雄到10级
                gotoUtils.gotoView(MainView.Hero);
                break;
            case 3003:
                // 摩天楼层数
                gotoUtils.gotoPanel(GotoModule.Tower);
                break;
            case 5001:
                // 海草升级
                gotoUtils.gotoView(MainView.Hero);
                break;
            case 5004:
                //20级
                gotoUtils.gotoView(MainView.Hero);
                break;

            default:
                break;
        }

        this.closePanel();
    }
}
