import { PopupPanel } from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import PopBg from "../../component/PopBg";
import HeroCard from "../../component/Hero/HeroCard";
import heroLogic from "../../../logics/HeroLogic";
import gm from "../../../manager/GameManager";
import PlayerHero from "../../../data/card/PlayerHero";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/共享花坛/ShareLevelConfirmDialog")
export default class ShareLevelConfirmDialog extends PopupPanel {
    @property(CommonLoader)
    dialog: CommonLoader = null;

    @property(CommonLoader)
    currentHeroItem: CommonLoader = null;

    @property(CommonLoader)
    nextHeroItem: CommonLoader = null;

    @property(cc.Label)
    currentHeroLevel: cc.Label = null;

    @property(cc.Label)
    nextHeroLevel: cc.Label = null;

    protected _hero: PlayerHero = null;
    protected _confirm: Function = null;

    onInit(data: { hero: PlayerHero, confirm: Function }) {
        super.onInit(data);
        this._hero = data.hero;
        this._confirm = data.confirm;
    }

    start() {
        super.start();

        let comp = this.dialog.loaderNode.getComponent(PopBg);
        comp.closeCallback = () => { this.closePanel() };

        let card = this.currentHeroItem.loaderNode.getComponent(HeroCard);
        card.refresh(this._hero);
        card.heroLevel.node.active = false;

        this.currentHeroLevel.string = "Lv." + this._hero.getLevel();

        let nextHero = this._hero.clone();
        nextHero.setSharePosition(0);

        card = this.nextHeroItem.loaderNode.getComponent(HeroCard);
        card.refresh(nextHero);
        card.heroLevel.node.active = false;

        this.nextHeroLevel.string = "Lv." + this._hero.getLevel(true);
    }

    async onConfirm() {
        try {
            await heroLogic.doUpdateShareHeroes({
                hero: this._hero,
                position: 0
            });
            if (this._confirm) { this._confirm(); }
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}
