import { PopupPanel } from "../BasePanel";
import Hero from "../../../data/card/Hero";
import heroLogic from "../../../logics/HeroLogic";
import HeroSelectItem, { HeroSelect } from "../../widget/hero/HeroSelectItem";
import gm from "../../../manager/GameManager";
import List from "../../common/List";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/共享花坛/ShareLevelSelectHeroPanel")
export default class ShareLevelSelectHeroPanel extends PopupPanel {
    @property(List)
    heroList: List = null;

    @property(cc.Node)
    emptyNode: cc.Node = null;

    protected _unshareHeroes: Hero[] = [];
    protected _success: Function = null;
    protected _heroSelect: HeroSelect = null;
    protected _position: number = 0;

    onInit(data: { success: Function, position: number }) {
        super.onInit(data);
        this._success = data.success;
        this._position = data.position;
    }

    start() {
        super.start();

        this._unshareHeroes = [];
        let heroes = heroLogic.getShareHeroes();
        for (let i = heroLogic.getPriestsCount(); i < heroes.length; i++) {
            let hero = heroes[i];
            if (hero.getSharePosition() <= 0) { this._unshareHeroes.push(hero); }
        }

        this._unshareHeroes.sort((a: Hero, b: Hero) => {
            let aRank = a.getRank();
            let bRank = b.getRank();
            if (aRank != bRank) return bRank - aRank;

            let aLevel = a.getLevel();
            let bLevel = b.getLevel();
            if (aLevel != bLevel) return bLevel - aLevel;

            return b.getIndex() - a.getIndex();
        });

        this.heroList.getComponent(cc.Widget).updateAlignment();
        this.heroList.numItems = this._unshareHeroes.length;
        this.emptyNode.active = this.heroList.numItems == 0;
    }

    onHeroRender(item: cc.Node, index: number) {
        let hero = this._unshareHeroes[index];
        let isSelect = this._heroSelect && this._heroSelect.hero == hero;
        let comp = item.getComponent(HeroSelectItem);
        comp.init(hero, isSelect);

        let func = HeroSelectItem.prototype.onToggleSelect;
        comp.onToggleSelect = () => {
            if (comp.heroSelect != this._heroSelect) {
                if (this._heroSelect) this._heroSelect.isSelect = false;
            }
            func.call(comp);
            if (comp.heroSelect.isSelect) {
                this._heroSelect = comp.heroSelect;
            }
            else {
                this._heroSelect = null;
            }
        }
    }

    async onConfirm() {
        try {
            if (this._heroSelect && this._heroSelect.isSelect) {
                await heroLogic.doUpdateShareHeroes({ hero: this._heroSelect.hero, position: this._position });
                if (this._success) { this._success(this._heroSelect.hero, this._position); }
            }
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}
