import { defaultConfigMap } from './../../../configs/defaultConfig';
import { stringConfigMap } from './../../../configs/stringConfig';
import { FlowerPlaceInfoVO } from './../../../proxy/GameProxy';
import { FullscreenPanel } from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import heroLogic from '../../../logics/HeroLogic';
import Hero from '../../../data/card/Hero';
import loadUtils from '../../../utils/LoadUtils';
import HeroCard from '../../component/Hero/HeroCard';
import commonUtils from "../../../utils/CommonUtils";
import List from "../../common/List";
import mathUtils from "../../../utils/MathUtils";
import gm from "../../../manager/GameManager";
import am from "../../../manager/AudioManager";
import GameProxy from "../../../proxy/GameProxy";
import stringUtils from '../../../utils/StringUtils';
import cm from '../../../manager/ConfigManager';
import bagLogic from '../../../logics/BagLogic';
import Good from '../../../data/card/Good';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/共享花坛/ShareLevelPanel")
export default class ShareLevelPanel extends FullscreenPanel {
    @property(cc.Node)
    nodePresists: cc.Node[] = [];

    @property(List)
    slotList: List = null;

    @property(cc.Widget)
    sharePanel: cc.Widget = null;

    @property(cc.Animation)
    shareEffect: cc.Animation = null;

    @property(cc.Node)
    shareEffectLight: cc.Node = null;

    @property(cc.Node)
    shareEffectBlast: cc.Node = null;

    @property(cc.SpriteFrame)
    slotFrames: cc.SpriteFrame[] = [];

    protected _slotHeroes: Hero[] = [];
    protected _priests: Hero[] = [];

    onLoad() {
        super.onLoad();
        this.sharePanel.top = cc.director.getWinSize().height / 2 + 170;
        this.sharePanel.updateAlignment();
    }

    start() {
        super.start();

        let heroes = heroLogic.getShareHeroes();
        let count = Math.min(heroes.length, heroLogic.getPriestsCount());
        for (let i = 0; i < count; i++) {
            this._priests.push(heroes[i]);
            this._updateSpine(i);
            let labelNode = this.nodePresists[i].getChildByName("label");
            let label = labelNode.getComponent(cc.Label);
            label.string = `Lv.${heroes[i].getLevel()}`;
        }

        this._updateSlotList();
    }

    onSlotRender(item: cc.Node, index: number) {
        item.off("click");
        item.opacity = 255;
        let sprite = item.getComponent(cc.Sprite);
        let heroItem = item.getChildByName("hero");
        let lockItem = item.getChildByName("rect");
        let hero = this._slotHeroes[index];
        if (hero) {
            sprite.spriteFrame = this.slotFrames[0];
            lockItem.active = false;
            heroItem.active = true;

            let loader = heroItem.getComponent(CommonLoader);
            let heroCard = loader.loaderNode.getComponent(HeroCard);
            heroCard.refresh(hero);
            heroCard.registerClickEvent(() => {
                gcc.core.showLayer("prefabs/panel/share_level/ShareLevelConfirmDialog",
                    {
                        data: {
                            hero: hero,
                            confirm: async () => {
                                this._slotHeroes[index] = null;
                                this.onSlotRender(item, index);
                            }
                        }
                    });
            });
        }
        else {
            let isUnlock = index < heroLogic.unlockSlotCount;
            sprite.spriteFrame = isUnlock ? this.slotFrames[0] : this.slotFrames[1];
            lockItem.active = !isUnlock;
            heroItem.active = false;

            let levelBg = lockItem.getChildByName("level_bg");
            if (index > heroLogic.unlockSlotCount) {
                item.opacity = 255 * 0.3;
                levelBg.active = false;
            }
            else if (lockItem.active) {
                levelBg.active = true;
                let labelNode = levelBg.getChildByName("label");
                let label = labelNode.getComponent(cc.Label);
                label.string = stringUtils.getString(stringConfigMap.key_player_level_unlock.Value, {
                    level: (index - heroLogic.buySlotCount) * defaultConfigMap.flowernumber2.value + defaultConfigMap.flowernumber1.value
                });
            }

            item.on("click", () => {
                if (isUnlock) {
                    gcc.core.showLayer("prefabs/panel/share_level/ShareLevelSelectHeroPanel",
                        {
                            data: {
                                success: (hero: Hero, position: number) => {
                                    this._showShareEffect(hero, index);
                                },
                                position: index + 1
                            }
                        });
                }
                else {
                    if (index == heroLogic.unlockSlotCount) {
                        let diamonds = cm.defaultFlowerUnlockDiamond;
                        gm.dialog({
                            content: stringUtils.getString(stringConfigMap.key_unlock_flower_slot.Value,
                                { count: diamonds[Math.min(heroLogic.buySlotCount, diamonds.length - 1)] }),
                            confirm: this._buySlot.bind(this, item, index)
                        });
                    }
                    else {
                        gm.toast(stringConfigMap.key_please_unlock_slot.Value);
                    }
                }
            });
        }
    }

    onShowInfo() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "sharelevel" } });
    }

    protected _updateSlotList() {
        let heroes = heroLogic.getShareHeroes();

        this._slotHeroes.length = (Math.ceil(heroLogic.unlockSlotCount / 5) + 1) * 5;
        for (let i = heroLogic.getPriestsCount(); i < heroes.length; i++) {
            let hero = heroes[i];
            if (hero.getSharePosition() > 0) {
                if (hero.getSharePosition() > this._slotHeroes.length) {
                    this._slotHeroes.length = hero.getSharePosition();
                }
                this._slotHeroes[hero.getSharePosition() - 1] = hero;
            }
        }
        let count = Math.ceil(this._slotHeroes.length / 5) * 5;
        this._slotHeroes.length = count;

        this.slotList.getComponent(cc.Widget).updateAlignment();
        this.slotList.numItems = this._slotHeroes.length;
    }

    protected async _buySlot(item: cc.Node, index: number) {
        try {
            await heroLogic.doBuyFlowerSlot();
            this._updateSlotList();
        } catch (e) {
            if (e.name == "ToastError") {
                let good = bagLogic.getGood(Good.GoodId.Diamond);
                if (e.message == stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })) {
                    gm.diamondLessToast();
                }
                else {
                    gm.toast(e.message);
                }
            }
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();

        let proto = await gm.request<FlowerPlaceInfoVO>(GameProxy.apiherogetFlowerPlaceInfo);
        heroLogic.unlockSlotCount = proto.nowCount;
        heroLogic.buySlotCount = proto.nowBuy;

        let heroes = heroLogic.getShareHeroes();
        let count = Math.min(heroes.length, heroLogic.getPriestsCount());
        for (let i = 0; i < count; i++) {
            let url = commonUtils.getHeroSpineUrl(heroes[i].getSpineFile());
            await loadUtils.loadRes(url, sp.SkeletonData);
            this._unloadInfos.push({ url: url, type: sp.SkeletonData });
        }

        this._unloadInfos.push({ url: commonUtils.getBgUrl("share_level_bg"), type: cc.SpriteFrame });
    }

    protected _updateSpine(index: number) {
        let skeletonNode = this.nodePresists[index].getChildByName("sprite");
        skeletonNode.scale = 1.5;
        let skeleton = skeletonNode.getComponent(sp.Skeleton);
        skeleton.skeletonData = cc.loader.getRes(commonUtils.getHeroSpineUrl(this._priests[index].getSpineFile()), sp.SkeletonData);
        skeleton.animation = "idle";
        if (this._priests[index].getSpineSkin()) {
            skeleton.setSkin(this._priests[index].getSpineSkin());
        }
    }

    protected async _showShareEffect(hero: Hero, index: number) {
        gm.showIndicator(2);
        am.playEffect("share_hero");

        let item = this.slotList.getItemByListId(index);
        let rect = item.getBoundingBoxToWorld();
        if (rect.intersects(this.slotList.node.getBoundingBoxToWorld())) {
            this.slotList.scrollTo(index, 0.2);
            await commonUtils.sleep(0.2, this);
        }

        this._slotHeroes[index] = hero;
        this.onSlotRender(item, index);
        let heroNode = item.getChildByName("hero");
        heroNode.active = false;

        this.shareEffect.node.active = true;

        let targetPosition = item.convertToWorldSpaceAR(cc.v2());
        let originPosition = this.shareEffect.node.convertToWorldSpaceAR(cc.v2());
        let deltaPosition = targetPosition.sub(originPosition);
        let angle = deltaPosition.normalize().signAngle(cc.v2(0, -1));
        let rotation = mathUtils.deg(angle);
        this.shareEffectLight.rotation = rotation;
        this.shareEffectLight.scaleY = deltaPosition.mag() / (this.shareEffectLight.height * 0.85);

        let position = this.shareEffect.node.convertToNodeSpaceAR(targetPosition);
        this.shareEffectBlast.position = position;

        this.shareEffect.off("finished");
        this.shareEffect.on("finished", () => {
            this.shareEffect.node.active = false;
            gm.hideIndicator()
        }, this);
        this.shareEffect.play();

        this.node.runAction(cc.sequence(cc.delayTime(0.2), cc.callFunc(() => {
            heroNode.active = true;
            let animation = heroNode.getComponent(cc.Animation);
            animation.play();
        }, this)));
    }
}
