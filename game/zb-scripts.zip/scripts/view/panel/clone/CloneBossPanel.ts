import {FullscreenPanel} from "../BasePanel";
import Skill from "../../../data/card/Skill";
import CommonLoader from "../../common/CommonLoader";
import UnionSkill from "../../component/Skill/UnionSkill";
import loadUtils from "../../../utils/LoadUtils";
import gm from "../../../manager/GameManager";
import EManager, {EName} from "../../../manager/EventManager";
import CloneMonster from "../../../data/card/CloneMonster";
import clonebattleconfig from "../../../configs/clonebattleconfig";
import CloneWaveItem from "../../component/Clone/CloneWaveItem";
import cMissionLogic from "../../../logics/CMissionLogic";
import CloneBattleData from "../../../data/clone/CloneBattleData";
import {defaultConfigMap} from "../../../configs/defaultConfig";
import {BattleType} from "../../../utils/DefineUtils";
import {RefreshLabel} from "../../../decorator/RefreshDecorator";
import Good from "../../../data/card/Good";
import bagLogic from "../../../logics/BagLogic";
import {ResType} from "../help/ResGotoPanel";
import activityLogic, {ActivityType} from "../../../logics/ActivityLogic";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/clone/CloneBossPanel")
export default class CloneBossPanel extends FullscreenPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Label)
    monsterName: cc.Label = null;

    @property(cc.Button)
    challengeBtn: cc.Button = null;

    @property(sp.Skeleton)
    heroHead: sp.Skeleton = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    waveItem: cc.Node = null;

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => {
            return bagLogic.getGood(Good.GoodId.CloneTicket)
        },
        getValue: (good: Good) => {
            let amount = slib.BigNumberHelper.convertNumStr2UnitStr(good.getAmount().toString(), 0, 2);
            return amount;
        }
    })
    @property(cc.Label)
    ticketLabel: cc.Label = null;

    @property(cc.Node)
    ticketIcon: cc.Node = null;

    @property(cc.Label)
    cnt: cc.Label = null;

    protected _lastSkeletonData: sp.SkeletonData = null;
    protected _monsterId: number;
    protected _monster: CloneMonster = null;

    onInit(data: number) {
        super.onInit(data);
        this._monsterId = data;
    }

    onLoad() {
        super.onLoad();
        let listener = EManager.addEvent(EName.onTouch, () => {
            EManager.emit(EName.onClosePanel, "SkillGetDetailPanel");
        });
        this._eventListeners.push(listener);
        listener = EManager.addEvent(EName.onGameExit, (data: any) => {
            if (data && data.type == BattleType.Clone) {
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);
        this.waveItem.parent = null;
    }

    start() {
        super.start();
        this.loadBg(this.bg);
        this._refreshTicket();
        this.showMonster();
    }

    protected _refreshTicket() {
        let lastCount = cMissionLogic.cloneInfo().getLastCount();
        if (lastCount <= 0) {
            this.ticketIcon.active = true;
            this.cnt.string = "1";
        } else {
            this.ticketIcon.active = false;
            this.cnt.string = `${lastCount}/${defaultConfigMap.clonefreetime.value}`;
        }
    }

    onDestroy() {
        super.onDestroy();
        UnionSkill.lastUnionSkill = null;
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await this._preloadBg(`clone_bg_1`);
    }

    async showMonster() {
        this._monster = new CloneMonster(this._monsterId, 0);
        this.monsterName.string = this._monster.getName();
        await gm.createHeroSpine(this._monster, this.heroHead);
        this._lastSkeletonData = this.heroHead.skeletonData;
        this.heroHead.skeletonData.lock();
        for (let i = 0; i < 4; i++) {
            let skillNode = cc.find(`skillNode/skill${i + 1}`, this.node);
            skillNode.active = false;
        }
        let skills: Skill[] = this._monster.getSkills();
        for (let i = 0; i < skills.length; i++) {
            if (!skills[i].isShow()) continue;
            if (i < 4) {
                let skillNode = cc.find(`skillNode/skill${i + 1}`, this.node);
                skillNode.active = true;
                let loader = skillNode.getComponent(CommonLoader);
                loader.loaderNode.getComponent(UnionSkill).refresh({ skill: skills[i], hero: this._monster });
            }
        }
        for (let cfg of clonebattleconfig) {
            if (cfg.reward > 0) {
                let node = cc.instantiate(this.waveItem);
                node.parent = this.content;
                node.getComponent(CloneWaveItem).refresh({monsterId: this._monsterId, config: cfg});
            }
        }
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);

        this.heroHead.skeletonData.unlock();
        loadUtils.releaseAssetRecursively(this.heroHead.skeletonData);
    }

    onChallenge() {
        if (cMissionLogic.cloneInfo().getDayCount() >= defaultConfigMap.clonefreetime.value) {
            if (bagLogic.getGood(Good.GoodId.CloneTicket).getAmount() <= 0) {
                if (!activityLogic.isActivityValid(ActivityType.MonthOrder)) {
                    gm.toast(stringConfigMap.key_auto_571.Value);
                } else {
                    gm.lackResGotoPanel(ResType.clone_ticket);
                }
                return;
            }
        }
        cMissionLogic.currentMonsterId = this._monsterId;
        let battleData = new CloneBattleData(this._monsterId, cMissionLogic.cloneInfo().getMaxWave(this._monsterId));
        gcc.core.showLayer("prefabs/panel/battle/BattlePreparePanel", { data: battleData });
    }

}
