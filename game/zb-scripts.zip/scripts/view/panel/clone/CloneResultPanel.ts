import {PopupPanel} from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import clonebattleconfig from "../../../configs/clonebattleconfig";
import {defaultConfigMap} from "../../../configs/defaultConfig";
import {GoodVO} from "../../../proxy/GameProxy";
import cMissionLogic from "../../../logics/CMissionLogic";
import Good, {GoodId} from "../../../data/card/Good";
import gm from "../../../manager/GameManager";
import cm from "../../../manager/ConfigManager";
import bagLogic from "../../../logics/BagLogic";
import GoodCard from "../../component/Good/GoodCard";
import EManager, {EName} from "../../../manager/EventManager";
import {BattleType} from "../../../utils/DefineUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/clone/CloneResultPanel")
export default class CloneResultPanel extends PopupPanel {

    @property(cc.Label)
    success_text: cc.Label = null;

    @property(cc.Label)
    cost: cc.Label = null;

    @property(CommonLoader)
    good_card: CommonLoader = null;

    protected _wave: number = 0;
    protected _heroPiece: number = 0;
    protected _cost: number = 0;

    onInit(data: {
        wave: number,
        statistics: rpgfight.HeroContributionStatistic[]
    }) {
        super.onInit(data);
        this._wave = data.wave;
    }

    start() {
        super.start();
        this.success_text.string = `本次成功挑战${this._wave}/${clonebattleconfig.length}波`;
        let goodCfg = cm.getHeroPiece(cMissionLogic.currentMonsterId);
        this._heroPiece = this._getHeroPieceCnt(this._wave);
        this._cost = Math.floor(goodCfg.value * this._heroPiece);
        this.cost.string = `×${this._cost}`;
        let goodVo = new GoodVO();
        goodVo.propId = goodCfg.parameterid;
        goodVo.amt = this._heroPiece;
        this.good_card.loaderNode.getComponent(GoodCard).refresh(new Good(goodVo));
        this.good_card.loaderNode.getComponent(GoodCard).registerOnGoodInfo();
    }

    protected _getHeroPieceCnt(wave: number) {
        let piece = defaultConfigMap.clonezero.value;
        for (let cfg of clonebattleconfig) {
            if (cfg.reward > 0 && wave >= cfg.ID) {
                piece += cfg.reward;
            }
        }
        return piece;
    }

    onGet() {
        this._doGetReward(false);
    }

    onDouble() {
        this._doGetReward(true);
    }

    protected async _doGetReward(double: boolean) {
        if (double && bagLogic.getGood(GoodId.Diamond).getAmount() < this._cost) {
            gm.diamondLessToast();
            return;
        }
        try {
            await cMissionLogic.doPassClone(double, cMissionLogic.currentMonsterId, this._wave, this._cost);
            this.closePanel();
            EManager.emit(EName.onGameExit, { type: BattleType.Clone });
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

}
