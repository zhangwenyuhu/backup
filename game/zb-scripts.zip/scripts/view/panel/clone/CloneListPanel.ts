import {FullscreenPanel} from "../BasePanel";
import cMission, {CloneInfo} from "../../../logics/CMissionLogic";
import cMissionLogic from "../../../logics/CMissionLogic";
import CloneListItem from "../../component/Clone/CloneListItem";
import List from "../../common/List";
import gm from "../../../manager/GameManager";
import timeUtils from "../../../utils/TimeUtils";
import {defaultConfigMap} from "../../../configs/defaultConfig";
import bagLogic from "../../../logics/BagLogic";
import {GoodId} from "../../../data/card/Good";
import EManager, {EName} from "../../../manager/EventManager";
import cm from "../../../manager/ConfigManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/clone/CloneListPanel")
export default class CloneListPanel extends FullscreenPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(List)
    list: List = null;

    @property(cc.Label)
    lastTime: cc.Label = null;

    @property(cc.Label)
    amount: cc.Label = null;

    @property(cc.Button)
    refreshBtn: cc.Button = null;

    protected _cloneInfo: CloneInfo = null;

    onLoad() {
        super.onLoad();
        let listener = EManager.addEvent(EName.onUpdateCloneList, () => {
            this._cloneInfo = cMissionLogic.cloneInfo();
            this.list.numItems = this._cloneInfo.getConfIds().length;
        });
        this._eventListeners.push(listener);
    }

    async start() {
        super.start();
        this.loadBg(this.bg);
        await this._showCloneList(false);
        this.unschedule(this.onShowTime);
        this.onShowTime();
        this.schedule(this.onShowTime, 1);
    }

    protected _refreshAmount() {
        this.amount.string = this._getRefreshAmount().toString();
    }

    protected _getRefreshAmount() {
        let cloneResetCost = cm.cloneResetCost;
        let refreshCount = cMissionLogic.cloneInfo().getRefreshCount();
        if (refreshCount > cloneResetCost.length) {
            refreshCount = cloneResetCost.length - 1;
        }
        return cloneResetCost[refreshCount];
    }

    protected async _showCloneList(flag: boolean = true) {
        if (flag) {
            await cMissionLogic.doGetCloneInfo();
        }
        this._refreshAmount();
        this._cloneInfo = cMissionLogic.cloneInfo();
        this.list.numItems = this._cloneInfo.getConfIds().length;
        this.refreshBtn.interactable = cMissionLogic.cloneInfo().getRefreshCount() < defaultConfigMap.cloneresettime.value;
    }

    onShowTime() {
        let time = this._cloneInfo.getLastTime();
        let currentTime = gm.getCurrentTimestamp();
        if (time >= currentTime) {
            this.lastTime.string = "自动刷新倒计时 " + timeUtils.formatDay(this._cloneInfo.getRemainTime(), true);
            if (Math.floor((time - gm.getCurrentTimestamp()) / 1000) == 0) {
                this._showCloneList();
            }
        } else {
            this.lastTime.string = "自动刷新倒计时 00:00:00";
            this._showCloneList();
        }
    }

    onCloneItemRender(item: cc.Node, index: number) {
        let comp = item.getComponent(CloneListItem);
        comp.refresh(this._cloneInfo.getConfIds()[index]);
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await this._preloadBg(`clone_bg_3`);
    }

    onHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "clone" } });
    }

    onBag() {
        gcc.core.showLayer("prefabs/panel/bag/BagPanel", { data: 3 });
    }

    async onRefresh() {
        if (bagLogic.getGood(GoodId.Diamond).getAmount() < this._getRefreshAmount()) {
            gm.diamondLessToast();
            return;
        }
        if (cMissionLogic.cloneInfo().getRefreshCount() >= this._getRefreshAmount()) {
            return;
        }
        gcc.core.showLayer("prefabs/panel/store/StoreRefreshAlert", {
            data: {
                needDiamond: this._getRefreshAmount(),
                desc: "刷新克隆大作战，是否刷新？",
                confirmFunc: () => {
                    this._doRefresh();
                }
            }
        });
    }

    protected async _doRefresh() {
        try {
            await cMissionLogic.doFreshClone(this._getRefreshAmount());
            this._showCloneList(false);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

}
