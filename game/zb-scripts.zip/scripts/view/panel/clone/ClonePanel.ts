import { Storage } from './../../../utils/DefineUtils';
import { FullscreenPanel } from "../BasePanel";
import UnlockWrapper from "../../widget/unlock/UnlockWrapper";
import { unlockConfigMap } from "../../../configs/unlockConfig";
import gm from "../../../manager/GameManager";
import storageUtils from "../../../utils/StorageUtils";
import guideLogic from '../../../logics/GuideLogic';
import cMissionLogic from "../../../logics/CMissionLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/clone/ClonePanel")
export default class ClonePanel extends FullscreenPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    start() {
        super.start();

        this.loadBg(this.bg);

        if (UnlockWrapper.isUnlock(unlockConfigMap.克隆大作战)) {
            if (!storageUtils.getBoolean(Storage.CloneGuide)) {
                storageUtils.setBoolean(Storage.CloneGuide.Key, true, true);
                guideLogic.guideId = 230003;
            }
            cMissionLogic.doGetCloneInfo();
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await this._preloadBg(`clone_bg_2`);
    }

    onClone() {
        if (!UnlockWrapper.isUnlock(unlockConfigMap.克隆大作战)) {
            gm.toast(unlockConfigMap.克隆大作战.tips);
            return;
        }
        if (!cMissionLogic.cloneInfo()) {
            return;
        }
        gcc.core.showLayer("prefabs/panel/clone/CloneListPanel");
    }

    onMaterial() {
        if (!UnlockWrapper.isUnlock(unlockConfigMap.资源副本)) {
            gm.toast(unlockConfigMap.资源副本.tips);
            return;
        }
        gcc.core.showLayer("prefabs/panel/material/MaterialPanel");
    }

}
