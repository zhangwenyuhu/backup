import { unlockConfigMap } from './../../../configs/unlockConfig';
import { EName } from './../../../manager/EventManager';
import { ChatGroup, ChatExtra, ChatType, ChatTab, ChatData } from './../../../socket/ChatUserData';
import { PopupPanel } from './../BasePanel';
import playerLogic from '../../../logics/PlayerLogic';
import ChatUserData from '../../../socket/ChatUserData';
import Info from '../../../Info';
import xScrollView from '../../xScrollView';
import EManager from '../../../manager/EventManager';
import chatSocket from '../../../socket/ChatSocket';
import gm from '../../../manager/GameManager';
import UnlockWrapper from '../../widget/unlock/UnlockWrapper';
import promptLogic, { PromptType } from '../../../logics/PromptLogic';
import friendLogic from '../../../logics/FriendLogic';
import timeUtils from '../../../utils/TimeUtils';
import ChatMsg from '../../component/Chat/ChatMsg';
import ChatTime from '../../component/Chat/ChatTime';
import chatHistoryData from '../../../socket/ChatHistoryData';
import commonUtils from '../../../utils/CommonUtils';
import ChatPrivateTopic from '../../component/Chat/ChatPrivateTopic';
import ListItem from '../../common/ListItem';
import List from '../../common/List';
import GuideBaseStep from '../../widget/guide/GuideBaseStep';
import arenaSeniorLogic from '../../../logics/ArenaSeniorLogic';
import {stringConfigMap} from "../../../configs/stringConfig";
import stringUtils from "../../../utils/StringUtils";

const { ccclass, property, menu } = cc._decorator;

enum TabState {
    Focus,
    Unfocus
}

@ccclass
@menu("view/panel/chat/ChatPanel")
export default class ChatPanel extends PopupPanel {
    @property(cc.Label)
    chatTitle: cc.Label = null;

    @property(cc.Node)
    contentAreas: cc.Node[] = [];

    @property(xScrollView)
    chatScrollViews: xScrollView[] = [];

    @property(cc.Node)
    privateList: cc.Node = null;

    @property(cc.Node)
    editArea: cc.Node = null;

    @property(cc.Node)
    btnTip: cc.Node = null;

    @property(cc.EditBox)
    editBox: cc.EditBox = null;

    @property(cc.Sprite)
    tabSprites: cc.Sprite[] = [];

    @property(cc.Label)
    tabRedPointCounts: cc.Label[] = [];

    @property(cc.Node)
    tabRedPoints: cc.Node[] = [];

    @property(cc.SpriteFrame)
    tabFrames: cc.SpriteFrame[] = [];

    @property(cc.Color)
    tabColors: cc.Color[] = [];

    protected _tabIndex: number = -1;
    protected _scrollLock: boolean = false;
    protected _privateGroups: ChatGroup[] = [];

    static LastChatGroup: ChatGroup = null;
    static NextChatTime: number = 0;

    onLoad() {
        super.onLoad();

        this._registerEvents();
    }

    onDestroy() {
        this._unregisterEvents();

        super.onDestroy();
    }

    start() {
        super.start();

        this.btnTip.active = !UnlockWrapper.isUnlock(unlockConfigMap.世界频道发言权限);
        this.editBox.enabled = !this.btnTip.active;

        for (let scrollView of this.chatScrollViews) {
            scrollView.registerScrollEvent(this._scrollEvent.bind(this));
        }

        if (playerLogic.getPlayer().isInUnion()) {
            let unionTopic = new ChatGroup();
            unionTopic.groupId = Info.appId + "_union_" + playerLogic.getPlayer().getUnionId();
            unionTopic.groupName = playerLogic.getPlayer().getUnionName();
            unionTopic.chatType = ChatType.Public;
            unionTopic.tabIndex = ChatTab.Union;
            ChatUserData.saved.addTopic(unionTopic);
        } else {
            let unionTopic = ChatUserData.saved.allChatTopics.find(a => a.tabIndex == ChatTab.Union);
            if (unionTopic) {
                ChatUserData.saved.deleteTopic(unionTopic);
                if (ChatPanel.LastChatGroup == unionTopic) {
                    let publicTopics = ChatUserData.saved.publicChatTopics;
                    ChatPanel.LastChatGroup = publicTopics[0];
                }
            }
            this.tabSprites[ChatTab.Union].node.active = false;
        }

        let privateTopics = ChatUserData.saved.privateChatTopics;
        this.tabSprites[ChatTab.Private].node.active = privateTopics.length > 0;

        if (!ChatPanel.LastChatGroup) {
            let publicTopics = ChatUserData.saved.publicChatTopics;
            ChatPanel.LastChatGroup = publicTopics[0];
        }
        this.onTab(null, ChatPanel.LastChatGroup.tabIndex.toString(), ChatPanel.LastChatGroup);
    }

    update(dt: number) {
        super.update(dt);
        if (GuideBaseStep.isGuiding) {
            this.closePanel();
        }
    }

    onTips() {
        gm.toast(unlockConfigMap.世界频道发言权限.tips);
    }

    onSend() {
        if (!UnlockWrapper.isUnlock(unlockConfigMap.世界频道发言权限)) {
            gm.toast(unlockConfigMap.世界频道发言权限.tips);
            return;
        }
        if (ChatPanel.LastChatGroup.tabIndex == ChatTab.Union) {
            if (!playerLogic.getPlayer().isInUnion()) {
                gm.toast(stringConfigMap.key_auto_560.Value);
                return;
            }
        }
        else if (ChatPanel.LastChatGroup.tabIndex == ChatTab.System) {
            return;
        }
        if (this.editBox.string == "") {
            gm.toast(stringConfigMap.key_auto_561.Value);
            return;
        }
        if (chatSocket.isChatTimeLimit && ChatPanel.NextChatTime > 0) {
            let diffTime = ChatPanel.NextChatTime - gm.getCurrentTimestamp();
            if (diffTime > 0) {
                gm.toast(stringUtils.getString(stringConfigMap.key_auto_634.Value, {p1: Math.ceil(diffTime / 1000)}));
                return;
            }
        }

        let data = new ChatData();
        data.from = commonUtils.getPrivateId();
        data.to = ChatPanel.LastChatGroup.privateId != "" ? ChatPanel.LastChatGroup.privateId : "";
        data.chatType = ChatPanel.LastChatGroup.privateId != "" ? ChatType.Private : ChatType.Public;
        data.group_id = ChatPanel.LastChatGroup.groupId;
        data.createTime = chatSocket.getCurrentTimestamp();
        data.content = this.editBox.string;
        let extra = new ChatExtra();
        extra.roleId = playerLogic.getPlayer().getRoleId().toString();
        extra.head = playerLogic.getPlayer().getAvatar();
        extra.frame = playerLogic.getPlayer().getAvatarRect();
        extra.name = playerLogic.getPlayer().getNickname();
        extra.union = playerLogic.getPlayer().getUnionName();
        extra.vip = playerLogic.getPlayer().getVipExp().toString();
        extra.rank = arenaSeniorLogic.myRank.no;
        extra.sId = gm.districtId.toString();
        data.extras = extra;
        if (data.chatType == ChatType.Public) {
            chatSocket.sendPublicMsg(data);
        } else if (data.chatType == ChatType.Private) {
            chatSocket.sendPrivateMsg(data);
        }
        this.editBox.string = "";
        ChatPanel.NextChatTime = gm.getCurrentTimestamp() + 5000;
        this._startHandler();

        //本地添加历史记录
        if (data.chatType == ChatType.Private) {
            ChatUserData.saved.addChatHistory(data);
            // this._onMessageReceive(JSON.stringify(data), true);
        }
    }

    onTab(event: cc.Event.EventTouch, index: string, group?: ChatGroup) {
        if (this._tabIndex.toString() == index) {
            return;
        }

        let sprite = this.tabSprites[this._tabIndex];
        if (sprite) {
            sprite.spriteFrame = this.tabFrames[TabState.Unfocus];
            let labelNode = sprite.node.getChildByName("label");
            labelNode.color = this.tabColors[TabState.Unfocus];

            this.contentAreas[this._tabIndex].active = false;
        }

        this._tabIndex = Number(index);
        sprite = this.tabSprites[this._tabIndex];
        sprite.spriteFrame = this.tabFrames[TabState.Focus];
        let labelNode = sprite.node.getChildByName("label");
        labelNode.color = this.tabColors[TabState.Focus];
        this.contentAreas[this._tabIndex].active = true;

        this.editArea.active = this._tabIndex != ChatTab.System;

        if (this._tabIndex == ChatTab.Private) {
            if (!group) {
                let privateTopics = ChatUserData.saved.privateChatTopics;
                group = privateTopics[0];
            }
            else {
                group.createTime = gm.getCurrentTimestamp();
            }
            this._refreshPrivateArea(group);
        }
        else {
            if (!group) {
                let publicTopics = ChatUserData.saved.publicChatTopics;
                group = publicTopics.find(a => a.tabIndex == this._tabIndex);
            }
            this._showMsg(group);
        }
    }

    onMsgHide() {
        gcc.core.showLayer("prefabs/panel/chat/ChatShieldPanel");
    }

    onPrivateItemClick(event: cc.Event.EventTouch) {
        let item = event.target as cc.Node;
        let listItem = item.getComponent(ListItem);
        this.privateList.getComponent(List).selectedId = listItem.listId;
        if (listItem.listId > 0) {
            let group = this._privateGroups[listItem.listId];
            group.createTime = gm.getCurrentTimestamp();
        }
    }

    onPrivateItemRender(item: cc.Node, index: number) {
        let comp = item.getComponent(ChatPrivateTopic);
        comp.refresh(this._privateGroups[index], (group: ChatGroup) => {
            ChatUserData.saved.deleteTopic(group);
            this._refreshPrivateArea();
        });

        let listItem = item.getComponent(ListItem);
        if (listItem.selected) {
            comp.focus();
        }
        else {
            comp.unfocus();
        }
    }

    onPrivateItemSelected(item: cc.Node, index: number, lastIndex: number) {
        let comp = item.getComponent(ChatPrivateTopic);
        comp.focus();

        this._showMsg(this._privateGroups[index]);

        let lastItem = this.privateList.getComponent(List).getItemByListId(lastIndex);
        if (lastItem) {
            comp = lastItem.getComponent(ChatPrivateTopic);
            comp.unfocus();
        }
    }

    protected _refreshPrivateArea(group?: ChatGroup) {
        this._privateGroups = ChatUserData.saved.privateChatTopics;

        if (this._privateGroups.length == 0) {
            this.tabSprites[ChatTab.Private].node.active = false;
            this.onTab(null, ChatTab.World.toString());
            return;
        }

        let selectId = 0;
        let userList = this.privateList.getComponent(List);
        userList.numItems = this._privateGroups.length;
        if (userList.selectedId == selectId) {
            (userList as any)._selectedId = -1;
        }
        userList.selectedId = selectId;
        userList.scrollTo(selectId, 0.2);
    }

    protected _startHandler() {
        this.unschedule(this._showPlaceHolder);
        this._showPlaceHolder();
        this.schedule(this._showPlaceHolder, 1);
    }

    protected _showPlaceHolder() {
        let diffTime = ChatPanel.NextChatTime - gm.getCurrentTimestamp();
        this.editBox.placeholder = "";
        if (diffTime > 0) {
            let time = Math.ceil(diffTime / 1000);
            if (time > 0) {
                this.editBox.placeholder = `${time}s后可再次发言`;
            } else {
                this.unschedule(this._showPlaceHolder);
            }
        } else {
            this.unschedule(this._showPlaceHolder);
        }
    }

    protected _showMsg(group: ChatGroup) {
        ChatPanel.LastChatGroup = group;

        group.unReadCnt = 0;
        promptLogic.setLocalPromptStatus(PromptType.CHAT, ChatUserData.saved.chatRedPointCnt > 0);
        ChatUserData.saveChatData();
        let chat = ChatUserData.saved.getChatHistoryByGroup(group);
        chat = chat.filter((v, i, a) => {
            // 过滤掉黑名单人员消息
            let fromId = (v && v.extras && v.extras.roleId) ? v.extras.roleId : "0";
            return !friendLogic.isInBlackList(fromId);
        });
        let list = [];
        for (let i = 0; i < chat.length; i++) {
            let _data = {};
            //下一条数据距离现在超过2分钟，显示间隔时间
            let diffTime = 0;
            if (i < chat.length - 1) {
                let nextData = chat[i + 1];
                diffTime = (nextData.createTime - chat[i].createTime) / 1000;
                if (diffTime > 120) {
                    diffTime = (chatSocket.getCurrentTimestamp() - chat[i].createTime) / 1000;
                }
            } else {
                diffTime = (chatSocket.getCurrentTimestamp() - chat[i].createTime) / 1000;
            }
            let dataStr = timeUtils.formatToBetweenString(chat[i].createTime, diffTime, 120);
            if (dataStr != "") {
                let _data2 = {};
                _data2["prefabIndex"] = 1;
                _data2["data"] = dataStr;
                list.push(_data2);
            }
            _data["prefabIndex"] = 0;
            _data["data"] = chat[i];
            list.push(_data);
        }
        let start = list.length - 7;
        if (start < 0) {
            start = 0;
        }

        this.chatScrollViews[this._tabIndex].refresh(list, (item: cc.Node, i: number, dt: any) => {
            if (dt.prefabIndex == 0) {
                if (dt.data.extras["systemExtras"]) {
                    return 200;
                } else {
                    item.getComponent(ChatMsg).refresh(dt.data);
                    return item.getComponent(ChatMsg).itemHeight();
                }
            } else {
                item.getComponent(ChatTime).refresh(dt.data);
                return item.getComponent(ChatTime).itemHeight();
            }
        }, (item: cc.Node, i: number, dt: any) => {
            if (dt.prefabIndex == 0) {
                item.getComponent(ChatMsg).refresh(dt.data);
                return item.getComponent(ChatMsg).itemHeight();
            } else {
                item.getComponent(ChatTime).refresh(dt.data);
                return item.getComponent(ChatTime).itemHeight();
            }
        }, start, false);

        if (group.groupId != "") {
            this.chatTitle.string = group.groupName;
        } else {
            this.chatTitle.string = group.privateExtras["name"];
        }

        this._updateRedPoints();
    }

    protected _registerEvents() {
        let listener = EManager.addEvent(EName.onChooseTopic, (group: ChatGroup) => {
            this.onTab(null, group.tabIndex.toString(), group);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onOpenPrivate, (data: any) => {
            this._onOpenPrivate(data);
        });
        this._eventListeners.push(listener);

        gssdk.gevent.on(gssdk.ChatEvent.ChatOnMessage, this._onMessageReceive.bind(this));

        chatSocket.connectGroup();
    }

    protected _unregisterEvents() {
        gssdk.gevent.off(gssdk.ChatEvent.ChatOnMessage, this._onMessageReceive);
    }

    protected _scrollEvent() {
        if (!this._scrollLock && this.chatScrollViews[this._tabIndex].topIndex == 0) {
            this._scrollLock = true;
            gm.showIndicator(1);
            this.scheduleOnce(() => { gm.hideIndicator(); }, 2);
            if (ChatPanel.LastChatGroup.chatType == ChatType.Public && chatHistoryData.chatHistory.length > 0) {
                chatSocket.getPublicHistory(ChatPanel.LastChatGroup.groupId, chatHistoryData.chatHistory[chatHistoryData.chatHistory.length - 1].createTime);
            }
        }
    }

    protected _onOpenPrivate(data: { extra: ChatExtra, select?: boolean }) {
        let fromId = data.extra.roleId;
        if (friendLogic.isInBlackList(fromId)) { return; }

        let chatGroup = ChatUserData.saved.openPrivateTopic(data.extra);
        this.tabSprites[ChatTab.Private].node.active = true;
        this.onTab(null, ChatTab.Private.toString(), chatGroup);
    }

    protected _onMessageReceive(data: any, self: boolean = false) {
        let chatData: ChatData = data;
        let str = data.split('@@@');
        if (str.length == 2) {
            chatData = JSON.parse(str[1]) as ChatData;
        } else {
            chatData = JSON.parse(data) as ChatData;
        }

        let topic = ChatUserData.saved.getTopic(chatData);
        if (topic == ChatPanel.LastChatGroup) {
            ChatUserData.saved.updateRedPoint(chatData, 0);
            this.chatScrollViews[this._tabIndex].addBottom({ prefabIndex: 0, data: chatData });
        }

        this._updateRedPoints();
    }

    protected _updateRedPoints() {
        let redPoints: { [key: number]: number } = {};
        let topics = ChatUserData.saved.allChatTopics;
        for (let topic of topics) {
            if (redPoints[topic.tabIndex] === undefined) {
                redPoints[topic.tabIndex] = 0;
            }
            redPoints[topic.tabIndex] += topic.unReadCnt;
        }
        for (let i = 0; i < this.tabSprites.length; i++) {
            this.tabRedPoints[i].active = redPoints[i] ? true : false;
            this.tabRedPointCounts[i].string = redPoints[i] ? redPoints[i].toString() : "0";
        }

        if (this._tabIndex == ChatTab.Private) {
            this.privateList.getComponent(List).numItems = this._privateGroups.length;
        }
    }
}
