import {Storage} from '../../../utils/DefineUtils';
import {PopupPanel} from "../BasePanel";
import storageUtils from "../../../utils/StorageUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/chat/ChatShieldPanel")
export default class ChatShieldPanel extends PopupPanel {

    @property(cc.Toggle)
    toggle1: cc.Toggle = null;

    @property(cc.Toggle)
    toggle2: cc.Toggle = null;

    start() {
        super.start();
        this.toggle1.isChecked = storageUtils.getBoolean(Storage.ChatMsgCard);
        this.toggle2.isChecked = storageUtils.getBoolean(Storage.ChatMsgHero);
    }

    onOk() {
        storageUtils.setBoolean(Storage.ChatMsgCard.Key, this.toggle1.isChecked, true);
        storageUtils.setBoolean(Storage.ChatMsgHero.Key, this.toggle2.isChecked, true);
        this.closePanel();
    }

}
