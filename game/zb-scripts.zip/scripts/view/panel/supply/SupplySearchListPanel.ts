import { SupplyStation } from './../../../logics/SupplyLogic';
import List from '../../common/List';
import Good from '../../../data/card/Good';
import SupplySearchListItem from '../../component/Supply/SupplySearchListItem';
import SupplyBasePanel from './SupplyBasePanel';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/supply/SupplySearchListPanel")
export default class SupplySearchListPanel extends SupplyBasePanel {
    @property(List)
    searchList: List = null;

    protected _datas: { good: Good, station: SupplyStation, needAmt: number }[] = [];

    onInit(datas: { good: Good, station: SupplyStation, needAmt: number }[]) {
        this._datas = datas;
    }

    start() {
        super.start();

        this.searchList.numItems = this._datas.length;
    }

    onItemRender(item: cc.Node, index: number) {
        item.name = `item${index}`;

        let comp = item.getComponent(SupplySearchListItem);
        comp.refresh(this._datas[index], index);
    }
}
