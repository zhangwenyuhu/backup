import { defaultConfigMap } from './../../../configs/defaultConfig';
import { stringConfigMap } from './../../../configs/stringConfig';
import supplyLogic, { SupplyStation, SupplyType } from './../../../logics/SupplyLogic';
import CommonLoader from '../../common/CommonLoader';
import GoodCard from '../../component/Good/GoodCard';
import gm from '../../../manager/GameManager';
import SupplyBasePanel from './SupplyBasePanel';
import stringUtils from '../../../utils/StringUtils';
import EManager from '../../../manager/EventManager';
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/supply/SupplyStationPanel")
export default class SupplyStationPanel extends SupplyBasePanel {
    @property(cc.Label)
    labelTitle: cc.Label = null;

    @property(cc.Label)
    labelTimes: cc.Label = null;

    @property(cc.Node)
    tipNode: cc.Node = null;

    @property(cc.Node)
    addNode: cc.Node = null;

    @property(cc.Label)
    labelSearchTimes: cc.Label = null;

    @property(cc.Label)
    labelSearchOnceCost: cc.Label = null;

    @property(cc.Label)
    labelSearchTimesCost: cc.Label = null;

    @property(cc.Node)
    goodTemplate: cc.Node = null;

    @property(cc.Node)
    goodContainer: cc.Node = null;

    protected _station: SupplyStation = null;
    protected _times: number = 0;

    onInit(station: SupplyStation) {
        this._station = station;
    }

    onLoad() {
        super.onLoad();

        this.goodTemplate.parent = null;
    }

    onDestroy() {
        this.goodTemplate.destroy();

        super.onDestroy();
    }

    start() {
        super.start();

        if (this._station.type == SupplyType.Normal) {
            this._times = defaultConfigMap.normalfindtime.value;
            this.labelSearchOnceCost.string = `${defaultConfigMap.normalsupply.value}`;
            this.labelSearchTimesCost.string = `${this._times * defaultConfigMap.normalsupply.value}`;
            this.tipNode.active = false;
        }
        else {
            this._times = defaultConfigMap.supplybasictime.value;
            this.labelSearchOnceCost.string = `${defaultConfigMap.advancedsupply.value}`;
            this.labelSearchTimesCost.string = `${this._times * defaultConfigMap.advancedsupply.value}`;
            this.tipNode.active = true;
            this.labelSearchTimes.string = `${supplyLogic.seniorSearchLimit - supplyLogic.seniorSearchTimes}/${supplyLogic.seniorSearchLimit}`;
            this.addNode.active = supplyLogic.seniorSearchTimes >= supplyLogic.seniorSearchLimit;
        }
        this.labelTimes.string = stringUtils.getString(stringConfigMap.key_supply_search_count.Value, { time: this._times });

        this.labelTitle.string = this._station.name;
        for (let good of this._station.rewards) {
            let item = cc.instantiate(this.goodTemplate);
            item.parent = this.goodContainer;

            let loader = item.getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(GoodCard);
            comp.refresh(good);
            comp.registerOnGoodInfo();
        }

        let listener = EManager.addEvent(supplyLogic.Events.SupplyInfoDirty, () => {
            this.labelSearchTimes.string = `${supplyLogic.seniorSearchLimit - supplyLogic.seniorSearchTimes}/${supplyLogic.seniorSearchLimit}`;
            this.addNode.active = supplyLogic.seniorSearchTimes >= supplyLogic.seniorSearchLimit;
        });
        this._eventListeners.push(listener);
    }

    onAddTimes() {
        gcc.core.showLayer("prefabs/panel/supply/SupplyResetPanel");
    }

    async onSearch(event: cc.Event.EventTouch, times: string) {
        try {
            let ret = await supplyLogic.doSearchTimesEx(this._station, times ? Number(times) : this._times);
            gcc.core.showLayer("prefabs/panel/supply/SupplySearchResultPanel", {
                data: {
                    rewards: ret.goods,
                    details: ret.details,
                    station: this._station
                }
            });
        } catch (error) {
            if (error.name == "ToastError") {
                if (error.message == stringConfigMap.key_no_enough_senior_search_time.Value) {
                    gcc.core.showLayer("prefabs/panel/supply/SupplyResetPanel");
                }
                else if (error.message == stringConfigMap.key_wait_power_recovery.Value) {
                    if (supplyLogic.buyCount < supplyLogic.buyTiliLimit) {
                        gcc.core.showLayer("prefabs/panel/supply/SupplyPowerConfirmPanel");
                    }
                    else {
                        gm.toast(error.message);
                    }
                }
                else {
                    gm.toast(error.message);
                }
            }
            else {
                throw error;
            }
        }
    }
}
