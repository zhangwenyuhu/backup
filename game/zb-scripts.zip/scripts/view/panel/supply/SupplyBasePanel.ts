import { stringConfigMap } from './../../../configs/stringConfig';
import { defaultConfigMap } from '../../../configs/defaultConfig';
import supplyLogic from '../../../logics/SupplyLogic';
import { PopupPanel } from '../BasePanel';
import EManager from '../../../manager/EventManager';
import gm from '../../../manager/GameManager';
import tipUtils from '../../../utils/TipUtils';

const { ccclass, property, menu } = cc._decorator;

@ccclass
export default class SupplyBasePanel extends PopupPanel {
    @property(cc.Label)
    labelPower: cc.Label = null;

    start() {
        super.start();

        this._refreshSupplyInfo();

        let listener = EManager.addEvent(supplyLogic.Events.SupplyInfoDirty, () => {
            this._refreshSupplyInfo();
        });
        this._eventListeners.push(listener);
    }

    onAddPower() {
        gcc.core.showLayer("prefabs/panel/supply/SupplyPowerConfirmPanel");
    }

    onPowerTip(event: cc.Event.EventTouch) {
        tipUtils.showTip(event.target, stringConfigMap.key_supply_power_tip.Value);
    }

    protected _refreshSupplyInfo() {
        this.labelPower.string = `${supplyLogic.power}/${defaultConfigMap.tiliuplimit.value}`;
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await supplyLogic.doGetSupplyInfo();
    }
}
