import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from './../BasePanel';
import supplyLogic from '../../../logics/SupplyLogic';
import gm from '../../../manager/GameManager';
import stringUtils from '../../../utils/StringUtils';
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/supply/SupplyResetPanel")
export default class SupplyResetPanel extends PopupPanel {
    @property(cc.Label)
    labelTimes: cc.Label = null;

    @property(cc.Label)
    labelDiamond: cc.Label = null;

    start() {
        super.start();

        this.labelTimes.string = stringUtils.getString(stringConfigMap.key_times.Value, { count: supplyLogic.seniorSearchResetLimit - supplyLogic.seniorSearchResetTimes });
        this.labelDiamond.string = supplyLogic.seniorSearchResetPrice.toString();
    }

    async onReset() {
        try {
            await supplyLogic.doResetCount();
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}
