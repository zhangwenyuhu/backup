import { defaultConfigMap } from './../../../configs/defaultConfig';
import { Storage } from './../../../utils/DefineUtils';
import supplyLogic, { SupplyStation } from './../../../logics/SupplyLogic';
import { PopupPanel } from '../BasePanel';
import { PromptRecycleBtn } from '../../../data/prompt/recycle/PromptRecycleBtn';
import { SupplyType } from '../../../logics/SupplyLogic';
import CommonLoader from '../../common/CommonLoader';
import SupplyStationItem from '../../component/Supply/SupplyStationItem';
import storageUtils from '../../../utils/StorageUtils';
import guideLogic from '../../../logics/GuideLogic';
import loadUtils from '../../../utils/LoadUtils';
const { ccclass, property, menu } = cc._decorator;

enum TabState {
    Focus,
    Unfocus
}

@ccclass
@menu("view/panel/supply/SupplyMapPanel")
export default class SupplyMapPanel extends PopupPanel {
    @property(cc.Node)
    tabNodes: cc.Node[] = [];

    @property(cc.SpriteFrame)
    tabFrames: cc.SpriteFrame[] = [];

    @property(cc.Color)
    tabColors: cc.Color[] = [];

    @property(cc.Node)
    normalScrollView: cc.Node = null;

    @property(cc.Node)
    seniorScrollView: cc.Node = null;

    @property(cc.Node)
    goodTemplate: cc.Node = null;

    @property(cc.ProgressBar)
    progressBar: cc.ProgressBar = null;

    @property(cc.Label)
    labelProgress: cc.Label = null;

    protected _tabIndex: number = 0;
    protected _defaultTab: number = 0;

    onInit(defaultTab?: number) {
        if (defaultTab) {
            this._defaultTab = defaultTab;
        }
        else {
            this._defaultTab = SupplyType.Normal;
        }
    }

    onLoad() {
        super.onLoad();

        this.goodTemplate.parent = null;
    }

    onDestroy() {
        this.goodTemplate.destroy();

        super.onDestroy();
    }

    start() {
        super.start();

        this.onTab(null, this._defaultTab.toString());
    }

    onTab(event: cc.Event.EventTouch, tabIndex: string) {
        if (this._tabIndex.toString() == tabIndex) {
            return;
        }

        let tab = this.tabNodes[this._tabIndex - 1];
        if (tab) {
            tab.getComponent(cc.Sprite).spriteFrame = this.tabFrames[TabState.Unfocus];
            tab.getChildByName("label").color = this.tabColors[TabState.Unfocus];
        }

        this._tabIndex = Number(tabIndex);
        tab = this.tabNodes[this._tabIndex - 1];
        tab.getComponent(cc.Sprite).spriteFrame = this.tabFrames[TabState.Focus];
        tab.getChildByName("label").color = this.tabColors[TabState.Focus];

        let stations: SupplyStation[] = [];
        let parent: cc.Node = null;
        if (this._tabIndex == SupplyType.Normal) {
            this.normalScrollView.active = true;
            this.seniorScrollView.active = false;
            parent = this.normalScrollView.getComponent(cc.ScrollView).content;
            stations = supplyLogic.stations;
        }
        else {
            this.normalScrollView.active = false;
            this.seniorScrollView.active = true;
            parent = this.seniorScrollView.getComponent(cc.ScrollView).content;
            stations = supplyLogic.seniorStations;
        }

        let children: cc.Node[] = [];
        while (true) {
            let child = parent.getChildByName(`station${children.length + 1}`);
            if (!child) {
                break;
            }
            children.push(child);
        }

        let count = Math.min(children.length, stations.length);
        for (let i = 0; i < count; i++) {
            let child = children[i];
            let station = stations[i];
            let loader = child.getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(SupplyStationItem);
            comp.refresh(station, this.goodTemplate);
        }
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);

        let bg = this.normalScrollView.getComponent(cc.ScrollView).content.getComponent(cc.Sprite);
        loadUtils.releaseAssetRecursively(bg.spriteFrame);

        bg = this.seniorScrollView.getComponent(cc.ScrollView).content.getComponent(cc.Sprite);
        loadUtils.releaseAssetRecursively(bg.spriteFrame);
    }
}
