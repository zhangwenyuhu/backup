import { stringConfigMap } from './../../../configs/stringConfig';
import { defaultConfigMap } from './../../../configs/defaultConfig';
import { PopupPanel } from './../BasePanel';
import supplyLogic from '../../../logics/SupplyLogic';
import cm from '../../../manager/ConfigManager';
import bagLogic from '../../../logics/BagLogic';
import { GoodId } from '../../../data/card/Good';
import EManager from '../../../manager/EventManager';
import gm from '../../../manager/GameManager';
import stringUtils from '../../../utils/StringUtils';
import rechargeLogic, { RightType } from '../../../logics/RechargeLogic';
import playerLogic from '../../../logics/PlayerLogic';
import vipconfig from '../../../configs/vipconfig';
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/supply/SupplyPowerConfirmPanel")
export default class SupplyPowerConfirmPanel extends PopupPanel {
    @property(cc.Label)
    labelPower: cc.Label = null;

    @property(cc.Label)
    labelTimes: cc.Label = null;

    @property(cc.Label)
    labelDiamond: cc.Label = null;

    @property(cc.Label)
    labelCost: cc.Label = null;

    @property(cc.Label)
    labelRemainTimes: cc.Label = null;

    @property(cc.RichText)
    labelTip: cc.RichText = null;

    protected _selectTimes: number = 0;
    protected _remainTimes: number = 0;

    start() {
        super.start();

        this.labelPower.string = `x${defaultConfigMap.tilibuy.value}`;
        this.labelTip.string = '<b><color=#37504B>'
            + stringUtils.getString(stringConfigMap.key_no_enough_buy_tili_times.Value,
                { minute: defaultConfigMap.tiliautoadd.value / 60 })
            + '</c></b>';
        let level = playerLogic.getPlayer().getVipLevel();
        let value = rechargeLogic.getVipBuffValue(RightType.TiliBuyLimit, level);
        for (let i = level + 1; i <= vipconfig.length; i++) {
            let newValue = rechargeLogic.getVipBuffValue(RightType.TiliBuyLimit, i);
            if (newValue > value) {
                this.labelTip.string = stringUtils.getString(stringConfigMap.key_buy_tili_tip.Value, { vip: i, count: newValue - value });
                break;
            }
        }

        this._remainTimes = supplyLogic.buyTiliLimit - supplyLogic.buyCount;
        this._selectTimes = Math.min(1, this._remainTimes);
        this._refresh();

        let listener = EManager.addEvent(supplyLogic.Events.SupplyInfoDirty, () => {
            this._remainTimes = supplyLogic.buyTiliLimit - supplyLogic.buyCount;
            this._refresh();
        });
        this._eventListeners.push(listener);
    }

    onAdd() {
        let remainTimes = supplyLogic.buyTiliLimit - supplyLogic.buyCount;
        if (remainTimes <= 0) {
            gm.toast(stringConfigMap.key_no_enough_buy_tili_times2.Value);
            return;
        }

        if (this._selectTimes == this._remainTimes) {
            return;
        }
        this._selectTimes++;
        this._refresh();
    }

    onReduce() {
        if (this._selectTimes == 0) {
            return;
        }
        this._selectTimes--;
        this._refresh();
    }

    async onConfirm() {
        try {
            await supplyLogic.doBuyTili(this._selectTimes);
            this.closePanel();
            gm.toast(stringConfigMap.key_buy_tili_success.Value);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    protected _refresh() {
        this.labelTimes.string = `${this._selectTimes}`;
        this.labelRemainTimes.string = `${this._remainTimes}`;

        let cost = 0;
        let prices = cm.tilibuyprice;
        for (let i = supplyLogic.buyCount; i < this._selectTimes + supplyLogic.buyCount; i++) {
            cost += prices[Math.min(i, prices.length - 1)];
        }
        this.labelCost.string = `/${stringUtils.formatAmount(cost)}`;

        let diamond = bagLogic.getGood(GoodId.Diamond).getAmount();
        this.labelDiamond.string = stringUtils.formatAmount(diamond);
        this.labelDiamond.node.color = diamond >= cost ? cc.Color.WHITE.fromHEX("#126670") : cc.Color.RED;
    }
}
