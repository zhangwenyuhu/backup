import { SupplyStation } from './../../../logics/SupplyLogic';
import { stringConfigMap } from './../../../configs/stringConfig';
import BasePanel, { PopupPanel } from '../BasePanel';
import List from '../../common/List';
import Good from '../../../data/card/Good';
import commonUtils from '../../../utils/CommonUtils';
import CommonLoader from '../../common/CommonLoader';
import GoodCard from '../../component/Good/GoodCard';
import SupplySearchListItem from '../../component/Supply/SupplySearchListItem';
import SupplySearchResultItem from '../../component/Supply/SupplySearchResultItem';
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/supply/SupplyResultListPanel")
export default class SupplyResultListPanel extends PopupPanel {
    @property(cc.Label)
    labelTitle: cc.Label = null;

    @property(List)
    searchList: List = null;

    @property(List)
    resultList: List = null;

    @property(cc.Node)
    touchNode: cc.Node = null;

    @property(cc.Node)
    totalResultContainer: cc.Node = null;

    @property(cc.Node)
    totalResultList: cc.Node = null;

    @property(cc.Node)
    goodTemplate: cc.Node = null;

    @property(cc.Node)
    itemTemplate: cc.Node = null;

    protected _rewards: Good[] = [];
    protected _details: Good[][] = [];
    protected _station: SupplyStation = null;
    protected _isSearching: boolean = false;

    onInit(data: {
        rewards: Good[],
        details: Good[][]
        station: SupplyStation
    }) {
        this._rewards = data.rewards;
        this._details = data.details;
        this._station = data.station;
    }

    onLoad() {
        super.onLoad();

        let modalBg = this.node.getChildByName("modalBg");
        if (modalBg) {
            modalBg.getComponent(cc.Sprite).spriteFrame = null;
        }

        this.goodTemplate.parent = null;
        this.itemTemplate.parent = null;
    }

    onDestroy() {
        this.goodTemplate.destroy();
        this.itemTemplate.destroy();

        super.onDestroy();
    }

    start() {
        super.start();

        this._refreshProcess();
    }

    onItemRender(item: cc.Node, index: number) {
        let comp = item.getComponent(SupplySearchResultItem);
        comp.refresh(this._details[index], index, this._station, this.goodTemplate);

        let child = item.getChildByName("item");
        if (this.touchNode.active) {
            if (index == this.searchList.numItems - 1) {
                child.x = -590;
                child.runAction(cc.moveTo(0.2, 0, child.y));
            }
            else {
                child.x = 0;
            }
        }
        else {
            child.x = 0;
        }
    }

    onTouchScreen() {
        this.unscheduleAllCallbacks();
        this._refreshResult();
    }

    closePanel() {
        super.closePanel();
        BasePanel.closePanel("SupplySearchListPanel");
    }

    protected async _refreshProcess() {
        this.labelTitle.string = stringConfigMap.key_searching.Value;

        this.totalResultContainer.active = false;
        this.resultList.node.active = false;
        this.searchList.node.active = true;

        for (let i = 0; i < this._details.length; i++) {
            this.searchList.numItems = i + 1;
            this.searchList.scrollTo(i, 0.2);
            await commonUtils.sleep(0.5, this);
        }

        this._isSearching = false;
        this._refreshResult();
    }

    protected _refreshResult() {
        this.labelTitle.string = stringConfigMap.key_search_result.Value;

        this.touchNode.active = false;
        this.totalResultContainer.active = true;
        this.resultList.node.active = true;
        this.searchList.node.active = false;

        this.resultList.numItems = this._details.length;
        for (let good of this._rewards) {
            let item = cc.instantiate(this.goodTemplate);
            let loader = item.getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(GoodCard);
            comp.refresh(good);
            comp.registerOnGoodInfo();

            item.y = 0;
            item.parent = this.totalResultList;
        }
    }
}
