import { PopupPanel } from "../BasePanel";
import Hero from "../../../data/card/Hero";
import HeroCard from "../../component/Hero/HeroCard";
import commitLogic from "../../../logics/CommitLogic";
import assignmentLogic from "../../../logics/AssignmentLogic";
import {WeekType} from "../../../utils/DefineUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/evolution/AllEvolutionSuccessPanel")
export default class AllEvolutionSuccessPanel extends PopupPanel {

    @property(cc.Prefab)
    hero_card: cc.Prefab = null;

    @property(cc.Node)
    heroLayout: cc.Node = null;

    @property(cc.Node)
    heroNode: cc.Node = null;

    onInit(data: {
        heros: Hero[]
    }) {

    }

    onLoad() {
        super.onLoad();

        let animation = this.node.getComponent(cc.Animation);
        animation.play("yijianjinhua_ruchang", 0);
        animation.on("finished", () => {
            animation.off("finished");
            animation.play("yijianjinhua_loop", 0);
        }, this);
    }

    start() {
        super.start();

        this.heroNode.active = false;
        let row = Math.ceil(this.data.heros.length / 4);
        for (let i: number = 0; i < row; i++) {
            let start = i * 4;
            let end = (i + 1) * 4 - 1;
            if (end > this.data.heros.length - 1) {
                end = this.data.heros.length - 1;
            }
            let list: Hero[] = [];
            for (let index = start; index <= end; index++) {
                list.push(this.data.heros[index]);
            }
            let node = cc.instantiate(this.heroNode);
            node.active = true;
            for (let j = 0; j < list.length; j++) {
                let card = cc.instantiate(this.hero_card);
                node.addChild(card);
                card.getComponent(HeroCard).refresh(list[j]);
            }
            this.heroLayout.addChild(node);
        }

        for (let i = 0; i < this.data.heros.length; i++) {
            let hero = this.data.heros[i] as Hero;
            commitLogic.upgradeRank(hero.getIndex(), hero.getRank());
        }
        commitLogic.haveHeros();

        assignmentLogic.weekTaskProCommit(WeekType.evolution_hero, this.data.heros.length);
    }

}