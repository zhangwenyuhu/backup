import {PopupPanel} from "../BasePanel";
import EvolutionChooseItem from "../../component/Evolution/EvolutionChooseItem";
import Hero from "../../../data/card/Hero";
import CommonLoader from "../../common/CommonLoader";
import gm from "../../../manager/GameManager";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/evolution/EvolutionChoosePanel")
export default class EvolutionChoosePanel extends PopupPanel {

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    chooseItem: cc.Node = null;

    onInit(data: {
        heroes: Hero[],
        chooseFunc: Function
    }) {
        super.onInit(data);
    }

    onLoad() {
        super.onLoad();
        this.chooseItem.parent = null;
    }

    start() {
        super.start();
        for (let hero of this.data.heroes) {
            let chooseNode = cc.instantiate(this.chooseItem);
            chooseNode.parent = this.content;
            chooseNode.getComponent(CommonLoader).loaderNode.getComponent(EvolutionChooseItem).refresh(hero);
        }
        let spaceX = this.content.getComponent(cc.Layout).spacingX;
        let spaceY = this.content.getComponent(cc.Layout).spacingY;
        let top = this.content.getComponent(cc.Layout).paddingTop;
        let left = this.content.getComponent(cc.Layout).paddingLeft;
        let row = Math.floor((this.content.width - left) / (this.chooseItem.width + spaceX));
        let addRow = Math.ceil(this.data.heroes.length / row);
        this.content.height = addRow * this.chooseItem.width + addRow * spaceY + top + spaceY;
    }

    onDestroy() {
        EvolutionChooseItem.lastChooseItem = null;
        super.onDestroy();
    }

    onConfirm() {
        if (EvolutionChooseItem.lastChooseItem == null) {
            gm.toast(stringConfigMap.key_auto_572.Value);
            return;
        }
        if (this.data.chooseFunc) {
            this.data.chooseFunc(EvolutionChooseItem.lastChooseItem.getHero());
        }
        this.closePanel();
    }

}
