import EvolutionPanel from "./EvolutionPanel";
import Hero from "../../../data/card/Hero";
import { PopupPanel } from "../BasePanel";
import heroLogic from "../../../logics/HeroLogic";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import HeroEvolutionInfoItem from "../../component/Hero/HeroEvolutionInfoItem";
import HeroCardEvolution from "../../component/Hero/HeroCardEvolution";
import EManager from "../../../manager/EventManager";
import gm from "../../../manager/GameManager";
import assignmentLogic from "../../../logics/AssignmentLogic";
import { WeekType } from "../../../utils/DefineUtils";
import PlayerHero from "../../../data/card/PlayerHero";
import {HeroMaterial} from "../../../utils/HeroUtils";

const { ccclass, property, menu } = cc._decorator;

export class EvolutionHeros {
    evolutionHero: Hero = null;
    consumeHeros: Hero[] = [];
    check: boolean = true;
}

@ccclass
@menu("view/panel/evolution/AllEvolutionPanel")
export default class AllEvolutionPanel extends PopupPanel {

    @property(cc.Node)
    evolutionScrollView: cc.Node = null;

    @property(cc.Button)
    allEvolutionBtn: cc.Button = null;

    protected _canEvolutionHeros: EvolutionHeros[] = [];

    onInit(data: any) {

    }

    start() {
        super.start();

        let heros = heroLogic.getEvolutionHeroes();
        this.getEvolutionHeros(heros);
        this.sortEvolutionHeroes();
        HeroEvolutionInfoItem.evolutionHeros = this._canEvolutionHeros;
        this.evolutionScrollView.getComponent(ScrollViewLoader).refresh(this._canEvolutionHeros);
    }

    onDestroy() {
        HeroEvolutionInfoItem.resetData();
        super.onDestroy();
    }

    getAllEvolutionHero() {
        let heros = [];
        for (let hero of this._canEvolutionHeros) {
            heros.push(hero.evolutionHero);
            if (hero.consumeHeros.length > 0) {
                for (let _hero of hero.consumeHeros) {
                    heros.push(_hero);
                }
            }
        }
        return heros;
    }

    sortEvolutionHeroes() {
        this._canEvolutionHeros.sort((a, b) => {
            let aHero = a.evolutionHero;
            let bHero = b.evolutionHero;
            if (aHero.getRank(true) != bHero.getRank(true)) {
                return bHero.getRank(true) - aHero.getRank(true);
            }
            return bHero.getIndex() - aHero.getIndex();
        });
    }

    /**
     * 获取最小等级的英雄
     */
    getMinEvolutionHeros(heros: Hero[], cnt) {
        let minHeros = [];
        let _heros = [];
        for (let _h of heros) {
            _heros.push(_h);
        }
        for (let i = 0; i < cnt; i++) {
            let h = _heros.min(a => a.getLevel());
            _heros.remove(h);
            if (minHeros.indexOf(h) == -1) {
                minHeros.push(h);
            }
        }
        return minHeros;
    }

    getEvolutionHeros(heros: Hero[]) {
        for (let i: number = 0; i < heros.length; i++) {
            let hero = heros[i];
            //去重
            if (!this.existInConsumeHeros(hero)) {
                let evolutionHero = heroLogic.canEvolution(hero as PlayerHero, this.getAllEvolutionHero(), [], false, false);
                if (evolutionHero.result && hero.getRank(true) < 5 && this._checkQuality(evolutionHero.consumeHeroes)) {
                    let _evolutionHero = new EvolutionHeros();
                    _evolutionHero.evolutionHero = hero;
                    // let consumeHeros = Object.values(evolutionHero.consumeHeroes);
                    let consumeHeros = this._getConsumeHeroes(evolutionHero.consumeHeroes);
                    //获取等级最小的英雄
                    _evolutionHero.consumeHeros = this.getMinEvolutionHeros(consumeHeros, this._getCnts(evolutionHero.heroMaterial));
                    let _hasSameHero = _evolutionHero.consumeHeros.where(a => a.getIndex() == hero.getIndex() && a.getRank(true) == hero.getRank(true));
                    if (_hasSameHero.length > 0) {
                        let maxLevelHero = _hasSameHero.max(a => a.getLevel());
                        if (maxLevelHero && maxLevelHero.getLevel() > hero.getLevel()) {
                            let tempHero = hero;
                            _evolutionHero.evolutionHero = maxLevelHero;
                            _evolutionHero.consumeHeros.remove(maxLevelHero);
                            _evolutionHero.consumeHeros.push(tempHero);
                        }
                    }
                    if (_evolutionHero.consumeHeros.length == this._getCnts(evolutionHero.heroMaterial) && this._canEvolutionHeros.find(a => a.evolutionHero == hero) == null) {
                        this._canEvolutionHeros.push(_evolutionHero);
                    }
                }
            }
        }
    }

    protected _getConsumeHeroes(consumeHeroes) {
        let _heroes = [];
        for (let heroes of consumeHeroes) {
            _heroes.pushList(heroes);
        }
        return _heroes;
    }

    protected _getCnts(heroMaterial: HeroMaterial[]) {
        let cnt = 0;
        for (let material of heroMaterial) {
            cnt += material.cnt;
        }
        return cnt;
    }

    protected _checkQuality(heroes: any[]): boolean {
        for (let hero of heroes) {
            for (let _hero of hero) {
                if (_hero.getRank(true) >= 4) {
                    return false;
                }
            }
        }
        return true;
    }

    existInConsumeHeros(hero) {
        for (let heros of this._canEvolutionHeros) {
            if (heros.evolutionHero == hero) {
                return true;
            }
            for (let consumeHero of heros.consumeHeros) {
                if (consumeHero == hero) {
                    return true;
                }
            }
        }
        return false;
    }

    async onAllEvolution() {
        this.allEvolutionBtn.interactable = false;
        if (HeroEvolutionInfoItem.evolutionHeros.length == 0) {
            return;
        }
        let heros = [];
        let consumeHeros = [];
        let nums: number = HeroEvolutionInfoItem.evolutionHeros.length;
        for (let evolutionItem of HeroEvolutionInfoItem.evolutionHeros) {
            if (evolutionItem.check) {
                heros.push(evolutionItem.evolutionHero);
                consumeHeros.pushList(evolutionItem.consumeHeros);
            }
        }
        let cards = heroLogic.getSplitAllCards(consumeHeros, false);
        let evolutionHeroes = [];
        for (let evolutionItem of HeroEvolutionInfoItem.evolutionHeros) {
            if (evolutionItem.check) {
                let hero = {};
                hero["hero"] = evolutionItem.evolutionHero;
                hero["consumeHeros"] = evolutionItem.consumeHeros;
                evolutionHeroes.push(hero);
            }
        }
        if (evolutionHeroes.length <= 0) {
            gm.toast('请选择要进化的英雄');
            this.allEvolutionBtn.interactable = true;
            return;
        }
        try {
            // await heroLogic.doAllEvolution(evolutionHeroes);
            await this._splitEvolutionHeroes(evolutionHeroes);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
        heroLogic.doRevertCards(cards);
        heroLogic.doClearHerosEquip(consumeHeros);
        HeroEvolutionInfoItem.resetData();
        HeroCardEvolution.resetData();
        EManager.emit(EvolutionPanel.Event.onEvolutionRefresh);
        gcc.core.showLayer("prefabs/panel/evolution/AllEvolutionSuccessPanel", {
            data: { heros: heros }, modalTouch: true, callback: () => {
                if (cards.length > 0) {
                    gcc.core.showLayer("prefabs/panel/reward/RewardPanel", { data: { cards: cards }, modalTouch: true });
                }
            }
        });
        assignmentLogic.weekTaskProCommit(WeekType.advance_hero, nums);
        this.closePanel();
    }

    protected _allEvolutionCnt: number = 10;
    protected _allEvolutionIndex: number = 0;
    //分批进化
    protected async _splitEvolutionHeroes(evolutionHeroes: any[]) {
        if (evolutionHeroes.length > this._allEvolutionIndex) {
            let maxIndex: number = Math.min(this._allEvolutionCnt, evolutionHeroes.length - this._allEvolutionIndex);
            let newHeroes = [];
            for (let i = this._allEvolutionIndex; i < this._allEvolutionIndex + maxIndex; i++) {
                newHeroes.push(evolutionHeroes[i]);
            }
            this._allEvolutionIndex = this._allEvolutionIndex + maxIndex;
            await heroLogic.doAllEvolution(newHeroes);
            await this._splitEvolutionHeroes(evolutionHeroes);
        }
    }

}
