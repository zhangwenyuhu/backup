import { PopupPanel } from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import Hero from "../../../data/card/Hero";
import HeroCard from "../../component/Hero/HeroCard";
import HeroEvolutionInfoPreview from "../../component/Hero/HeroEvolutionInfoPreview";
import gm from "../../../manager/GameManager";
import commitLogic from "../../../logics/CommitLogic";
import { EvolutionType, WeekType } from "../../../utils/DefineUtils";
import assignmentLogic from "../../../logics/AssignmentLogic";
import cm from "../../../manager/ConfigManager";
import loadUtils from "../../../utils/LoadUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/evolution/EvolutionSuccessPanel")
export default class EvolutionSuccessPanel extends PopupPanel {

    @property(sp.Skeleton)
    hero_head: sp.Skeleton = null;

    @property(CommonLoader)
    evolution_info: CommonLoader = null;

    @property(CommonLoader)
    evolution_before: CommonLoader = null;

    @property(CommonLoader)
    evolution_after: CommonLoader = null;

    @property(cc.Node)
    arrowNode1: cc.Node = null;

    @property(cc.Node)
    arrowNode2: cc.Node = null;

    @property(cc.Node)
    arrowNode3: cc.Node = null;

    @property(cc.Sprite)
    textSprite: cc.Sprite = null;

    @property({
        type: cc.SpriteFrame
    })
    textFrames: cc.SpriteFrame[] = [];

    @property(cc.Node)
    skillNode: cc.Node = null;

    @property(cc.Sprite)
    skill_icon: cc.Sprite = null;

    @property(cc.Node)
    skill_unlock: cc.Node = null;

    @property(cc.Label)
    level1: cc.Label = null;

    @property(cc.Label)
    level2: cc.Label = null;

    protected _pos = [-374, -493];
    protected _evolutionAfter = null;

    onInit(data: {
        hero: Hero
        evolutionType: EvolutionType
        clickEvent: Function
    }) {

    }

    onLoad() {
        super.onLoad();

        let animation = this.node.getComponent(cc.Animation);
        animation.play("jinhuachenggong_ruchang", 0);
        animation.on("finished", () => {
            animation.off("finished");
            //animation.play("jinhuachenggong_loop", 0);
        }, this);
    }

    async start() {
        super.start();

        this.textSprite.spriteFrame = this.textFrames[this.data.evolutionType - 1];
        let evolutionBefore = this.data.hero.clone() as Hero;
        this._evolutionAfter = this.data.hero.clone() as Hero;
        if (this.data.evolutionType == EvolutionType.Evolution) {
            this._evolutionAfter.setRank(evolutionBefore.getRank(true) + 1);
            commitLogic.upgradeRank(this.data.hero.getIndex(), this.data.hero.getRank(true));
            commitLogic.haveHeros();
            assignmentLogic.weekTaskProCommit(WeekType.advance_hero);
        } else if (this.data.evolutionType == EvolutionType.Star) {
            this._evolutionAfter.setStar(evolutionBefore.getStar() + 1);
            assignmentLogic.weekTaskProCommit(WeekType.evolution_hero);
        } else {
            this._evolutionAfter = null;
        }
        this.evolution_before.loaderNode.getComponent(HeroCard).refresh(evolutionBefore);
        if (this.data.evolutionType != EvolutionType.Merge) {
            this.evolution_after.loaderNode.getComponent(HeroCard).refresh(this._evolutionAfter);
        } else {
            this.evolution_after.node.active = false;
            this.evolution_before.node.x = 0;
            this.arrowNode1.active = false;
            this.arrowNode2.active = false;
            this.arrowNode3.active = false;
        }
        this.evolution_info.loaderNode.getComponent(HeroEvolutionInfoPreview).refresh({
            hero: evolutionBefore,
            evolutionHero: this._evolutionAfter
        });

        this.evolution_info.node.y = this._pos[0];
        this.skillNode.active = false;
        if (this.data.evolutionType == EvolutionType.Star) {
            let heroCfg = cm.getHeroConfig(this._evolutionAfter.getIndex());
            if (heroCfg.HeroSkill && heroCfg.HeroSkill > 0 && this._evolutionAfter.getStar() > 1 && this._evolutionAfter.getStarUpperLimit() > 1) {
                this.evolution_info.node.y = this._pos[1];
                this.skillNode.active = true;
                this.skill_unlock.active = this._evolutionAfter.getStar() == 1;
                let heroSkillCfg = cm.getHeroSkillConfig(this._evolutionAfter.getUniqueSkillId());
                loadUtils.loadSpriteFrame(`textures/icon/skill/${heroSkillCfg.skillicon}`, this.skill_icon);
                let level = this._evolutionAfter.getHeroSkillLevel();
                this.level1.string = `Lv.${level == 0 ? 0 : level - 1}`;
                this.level2.string = `Lv.${level == 0 ? 1 : level}`;
            }
        }

        await gm.createHeroSpine(this.data.hero, this.hero_head);
    }

    onExclusiveSkill() {
        gcc.core.showLayer("prefabs/panel/skill/HeroSkillPanel", {
            data: { hero: this._evolutionAfter, offsetY: -200 }, modalWindow: false, modalTouch: true
        });
    }

    onClickSplit() {
        if (this.data.clickEvent) {
            this.data.clickEvent();
        }
        this.closePanel();
    }

}
