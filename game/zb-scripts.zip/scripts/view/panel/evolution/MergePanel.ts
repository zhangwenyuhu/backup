import equipLevelConfig from "../../../configs/equipLevelConfig";
import Card from "../../../data/card/Card";
import Equip from "../../../data/card/Equip";
import { GoodId } from "../../../data/card/Good";
import PlayerEquip from "../../../data/card/PlayerEquip";
import bagLogic from "../../../logics/BagLogic";
import heroLogic from "../../../logics/HeroLogic";
import towerLogic from "../../../logics/TowerLogic";
import gm from "../../../manager/GameManager";
import { ResourceVO } from "../../../proxy/GameProxy";
import commonUtils from "../../../utils/CommonUtils";
import loadUtils from "../../../utils/LoadUtils";
import CommonLoader from "../../common/CommonLoader";
import List from "../../common/List";
import EquipCard from "../../component/Equip/EquipCard";
import EquipFilter from "../../component/Equip/EquipFilter";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/evolution/MergePanel")
export default class MergePanel extends cc.Component {

    @property(cc.Node)
    equipFlag: cc.Node = null;

    @property(cc.Node)
    equipInfo: cc.Node = null;

    @property(cc.Node)
    equipStar: cc.Node = null;

    @property(cc.Sprite)
    equipIcon: cc.Sprite = null;

    @property(cc.Node)
    equipMat: cc.Node = null;

    @property(List)
    equips: List = null;

    @property(cc.Node)
    equip_filter: cc.Node = null;

    @property(cc.Node)
    btnEquipMerge: cc.Node = null;

    @property(cc.Node)
    btnAutoEquipMerge: cc.Node = null;

    @property(cc.Label)
    labelEquipMergeCost: cc.Label = null;

    @property(cc.Node)
    topTitle: cc.Node = null;

    @property(cc.Node)
    effect: cc.Node = null;

    @property(cc.Node)
    touch: cc.Node = null;

    @property(cc.Material)
    normalMaterial: cc.Material = null;

    @property(cc.Material)
    grayMaterial: cc.Material = null;

    @property(cc.Label)
    mergeLimitTip: cc.Label = null;

    @property(cc.Node)
    equipDizuo: cc.Node = null;

    protected _selectEquip: Equip = null;
    protected _matEquip: Equip[] = [null, null];
    protected _listEquips: Equip[] = [];
    protected _career: number = 0;
    protected _place: number = 0;

    start() {
        this.touch.active = false;
    }

    onLoad() {
        this.equipStar.parent = null;
    }
    onDestroy() {
        this.equipStar.destroy();
    }

    protected onClickHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: 'equip_merge' } });
    }

    public refresh(param?: Equip) {
        if (param) { this._selectEquip = param; }
        let loader = this.equip_filter.getComponent(CommonLoader).loaderNode;
        let comp = loader.getComponent(EquipFilter);
        comp.registerEquipFilter(this.onSelectCareer.bind(this), this.onSelectPlace.bind(this));

        this.showEquipMergeView();
        this._updateMergeCostGold();
    }

    protected showEquipMergeView() {
        let bSelectEquip: boolean = this._selectEquip ? true : false;
        this.equipFlag.active = !bSelectEquip;
        this.equipInfo.active = bSelectEquip;
        this.equipIcon.node.active = bSelectEquip;
        this.equipMat.active = bSelectEquip;
        this.mergeLimitTip.node.active = bSelectEquip;
        if (bSelectEquip) {
            this.mergeLimitTip.node.active = !this.isMergeUnlock(this._selectEquip.getRank());
            if (this.mergeLimitTip.node.active) {
                let config = equipLevelConfig[Math.min(this._selectEquip.getRank(), equipLevelConfig.length - 1)];
                this.mergeLimitTip.string = `通关摩天楼${config.EqComLimit}层可合成`;
            }
        }

        this.updateEquipList();
        this.updateEquipBtn();
        if (bSelectEquip) {
            this.updateEquipInfo(this._selectEquip);
            this.updateEquipMat(this._matEquip);
        }
        this.updateEquipDizuo();
    }

    protected isMergeUnlock(rank: number) {
        let config = equipLevelConfig[Math.min(rank, equipLevelConfig.length - 1)];
        let tower = towerLogic.getCurrentTower();
        return tower > config.EqComLimit;
    }

    protected onClickEquipMerge() {
        let mat = this._matEquip.filter((v, i, a) => { return v ? true : false; })
        let ret = bagLogic.canMergeEquip(this._selectEquip as PlayerEquip, mat as PlayerEquip[]);
        if (!ret.result) { gm.toast(ret.message); return; }

        let goMerge = () => {
            this.touch.active = true;
            this.playEquipMergeAnimation(async () => {
                await this.doEquipMerge();
                this.touch.active = false;
            })
        }

        let result = bagLogic.checkMatEquip(mat);
        if (result.ret) {
            goMerge();
        } else {
            gm.dialog({
                content: result.msg,
                okText: '继续',
                confirm: () => {
                    goMerge();
                }
            })
        }
    }

    protected async doEquipMerge() {
        try {
            let mat = this._matEquip.filter((v, i, a) => { return v ? true : false; })
            let ret = await bagLogic.doMergeEquip(this._selectEquip as PlayerEquip, mat as PlayerEquip[]);
            if (ret.ret) {
                this.popMergeReward(this._selectEquip, ret.proto);
                if (this._selectEquip.getRank() >= equipLevelConfig.length) {
                    this._selectEquip = null;
                }
                this._matEquip = [null, null];
                this.showEquipMergeView();
                this._updateMergeCostGold();
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    protected playEquipMergeAnimation(callback: Function) {
        let effect = this.effect.getComponent(cc.Animation);
        effect.play('MergeItem', 0);
        effect.off("finished");
        effect.on("finished", (e) => { if (callback) { callback(); } })
    }

    protected onClickEquipAutoMerge() {
        gcc.core.showLayer("prefabs/panel/equip/EquipMergePanel", {
            data: {
                callback: () => {
                    this.showEquipMergeView();
                }
            }
        });
    }

    protected onSelectCareer(career: number) {
        if (this._career == career) { return; }
        this._career = career;
        this.showEquipMergeView();
    }

    protected onSelectPlace(place: number) {
        if (this._place == place) { return; }
        this._place = place;
        this.showEquipMergeView();
    }

    protected updateEquipDizuo() {
        this.equipDizuo.active = this._selectEquip ? true : false;
        if (this.equipDizuo.active) {
            let rank = this._selectEquip.getRank();
            let cof = equipLevelConfig[rank - 1];
            if (cof.RankHead == '0') { this.equipDizuo.active = false; return; }
            let name: string = `MergePanelQuality${cof.RankHead}`;
            let ani = this.equipDizuo.getComponent(cc.Animation);
            ani.play(name, 0);
        } else {
            let ani = this.equipDizuo.getComponent(cc.Animation);
            ani.stop();
        }
    }
    // 主材料信息
    protected updateEquipInfo(equip: Equip) {
        if (!equip) { return; }
        let name = this.equipInfo.getChildByName('name');
        name.active = equip.heroId && equip.heroId.length > 0;
        if (name.active) {
            let hero = heroLogic.getHero(equip.heroId);
            name.getComponent(cc.Label).string = hero ? hero.getName() : '';
        }

        let icon = this.equipInfo.getChildByName('icon');
        let url: string = commonUtils.getEquipIconUrl(equip.getIndex());
        loadUtils.loadSpriteFrame(url, icon.getComponent(cc.Sprite));

        let rank = this.equipInfo.getChildByName('rank');
        rank.active = false; // 不显示品阶
        //rank.getComponent(cc.Label).string = equip.getLevelConfig().RankName;

        let star = this.equipInfo.getChildByName('stars');
        star.destroyAllChildren();
        let num: number = equip.getRealStarCount();
        for (let i = 0; i < num; i++) {
            let tmp = cc.instantiate(this.equipStar);
            tmp.parent = star;
        }
        star.active = star.childrenCount > 0;

        let info = this.equipInfo.getChildByName('layout');
        let tag = info.getChildByName('tag');
        tag.active = equip.hasCampBonus();

        let equipName = info.getChildByName('name');
        equipName.getComponent(cc.Label).string = equip.getName();
        equipName.color = cc.Color.WHITE.fromHEX(equip.getLevelConfig().RankColor);

        let level = info.getChildByName('level');
        level.getComponent(cc.Label).string = `Lv.${equip.getLevel()}`;
    }
    // 消耗材料信息
    protected updateEquipMat(mat: Equip[]) {
        let matNum: number = 2;
        for (let i = 0; i < matNum; i++) {
            let node = this.equipMat.getChildByName(`item${i + 1}`);

            let mater = this.hasMat(i) ? this.normalMaterial : this.grayMaterial;
            let def = node.getChildByName('default');
            def.getChildByName('add').getComponent(cc.Sprite).setMaterial(0, mater);
            let place = def.getChildByName('place').getComponent(cc.Sprite);
            place.node.active = this._selectEquip ? true : false;
            if (place.node.active) {
                place.node.opacity = 100;
                let url = commonUtils.getEquipIconUrl(this._selectEquip.getIndex());
                loadUtils.loadSpriteFrame(url, place);
            }

            let card = node.getChildByName('equip');
            card.active = mat[i] ? true : false;
            if (card.active) {
                let loader = card.getComponent(CommonLoader).loaderNode;
                loader.getComponent(EquipCard).refresh({ equip: mat[i] });
            }

            let btn = node.getChildByName('btn');
            btn.off('click');
            btn.on('click', () => {
                this._clickEquipMat(i);
            })
        }
    }
    protected _clickEquipMat(index: number) {
        if (!this._selectEquip) { return; }
        if (this._matEquip[index]) {
            this.removeMat(this._matEquip[index]);
            this.showEquipMergeView();
            this._updateMergeCostGold();
        } else {
            let rank = this._selectEquip.config.Rank;
            let tip = `需要 ${equipLevelConfig[rank - 1].RankName} 的${this._selectEquip.config.Name}`;
            gm.toast(tip);
        }
    }
    protected updateEquipBtn() {
        let bSelectEquip: boolean = this._selectEquip ? true : false;
        this.btnAutoEquipMerge.active = !bSelectEquip;
        this.btnEquipMerge.getComponent(cc.Button).interactable = bSelectEquip;
        this.btnEquipMerge.active = true;
        if (bSelectEquip && this._selectEquip) {
            this.btnEquipMerge.active = this.isMergeUnlock(this._selectEquip.getRank());
        }

        this.equip_filter.active = !bSelectEquip;
        if (this.equip_filter.active) {
            let width = this.equip_filter.parent.width - 20;
            let loader = this.equip_filter.getComponent(CommonLoader).loaderNode;
            loader.getComponent(EquipFilter).setBgWidth(width);
        }
    }
    // 待选装备列表
    protected updateEquipList() {
        this.equips.getComponent(cc.Widget).updateAlignment();
        this._listEquips = [];

        // 位置和职业筛选
        let bagEquips: Equip[] = bagLogic.getEquips((equip) => {
            let result: boolean = equip.getRank() > 0 && equip.getRank() < equipLevelConfig.length;
            if (!result) { return result; }

            if (this._career > 0) { result = equip.config.Career == this._career; }
            if (!result) { return result; }

            if (this._place > 0) { result = equip.config.Place == this._place; }
            return result;
        });

        if (this._selectEquip) {
            // 已选择主材料
            for (let i = 0; i < bagEquips.length; i++) {
                let equip = bagEquips[i];
                if (equip.config.Id == this._selectEquip.config.Id && !equip.getHero()) {
                    this._listEquips.push(equip);
                }
            }
            if (this._selectEquip.getHero()) {
                this._listEquips.unshift(this._selectEquip);
            }
            this._listEquips.sort((a, b) => {
                let e_a: boolean = a.getHero() ? true : false;
                let e_b: boolean = b.getHero() ? true : false;
                if (e_a || e_b) {
                    if (!e_a) { return 1; }
                    if (!e_b) { return -1; }
                    //return 0;
                }
                let s_a: boolean = a.getId() == this._selectEquip.getId();
                let s_b: boolean = b.getId() == this._selectEquip.getId();
                if (s_a || s_b) {
                    if (!s_a) { return 1; }
                    if (!s_b) { return -1; }
                }
                if (a.getLevel() == b.getLevel()) {
                    if (a.getStar() == b.getStar()) {
                        if (a.getChargingLv() == b.getChargingLv()) {
                            return a.getCamp() - b.getCamp();
                        } else {
                            return a.getChargingLv() - b.getChargingLv();
                        }
                    } else {
                        return a.getStar() - b.getStar();
                    }
                } else {
                    return a.getLevel() - b.getLevel();
                }
            })
        } else {
            // 未选择主材料
            this._listEquips = this._listEquips.concat(bagEquips);
            this._listEquips.sort((a, b) => {
                let e_a: boolean = a.getHero() ? true : false;
                let e_b: boolean = b.getHero() ? true : false;
                if (e_a || e_b) {
                    if (!e_a) { return 1; }
                    if (!e_b) { return -1; }
                    //return 0;
                }
                if (a.getIndex() == b.getIndex()) {
                    if (a.getLevel() == b.getLevel()) {
                        if (a.getStar() == b.getStar()) {
                            if (a.getChargingLv() == b.getChargingLv()) {
                                return b.getCamp() - a.getCamp();
                            } else {
                                return b.getChargingLv() - a.getChargingLv();
                            }
                        } else {
                            return b.getStar() - a.getStar();
                        }
                    } else {
                        return b.getLevel() - a.getLevel();
                    }
                } else {
                    return b.getIndex() - a.getIndex();
                }
            })
        }

        this.equips.numItems = this._listEquips.length;
    }

    protected onRenderEquipItem(item: cc.Node, index: number) {
        let data = this._listEquips[index];

        let bSelectEquip: boolean = this._selectEquip && data.getId() == this._selectEquip.getId();
        let bMat: boolean = this.isInMat(data);

        let card = item.getChildByName('equip');
        let comp = card.getComponent(CommonLoader).loaderNode.getComponent(EquipCard);
        comp.refresh({ equip: data });
        comp.showMask(bSelectEquip || bMat);

        item.getChildByName('select_green').active = bSelectEquip;
        item.getChildByName('select_yellow').active = bMat;

        let hero = data.getHero();
        let flag = item.getChildByName('flag');
        let name = item.getChildByName('name');
        flag.active = hero ? true : false;
        name.active = hero ? true : false;
        if (flag.active) { flag.opacity = (bSelectEquip || bMat) ? 80 : 255; }
        if (name.active) {
            name.getComponent(cc.Label).string = hero.getName();
            name.opacity = (bSelectEquip || bMat) ? 80 : 255;
        }

        let btn = item.getChildByName('btn');
        btn.off('click');
        btn.on('click', () => {
            if (this._selectEquip) {
                if (bSelectEquip) {
                    this._selectEquip = null;
                    this._matEquip = [null, null];
                    this.showEquipMergeView();
                } else {
                    if (bMat) {
                        this.removeMat(data);
                    } else {
                        this.addMat(data);
                    }
                    this.showEquipMergeView();
                }
            } else {
                this._selectEquip = data;
                this.showEquipMergeView();
            }
            this._updateMergeCostGold();
        });
    }

    protected _updateMergeCostGold() {
        this.labelEquipMergeCost.node.parent.active = this._selectEquip ? true : false;
        if (this._selectEquip) {
            this.labelEquipMergeCost.node.parent.active = this.isMergeUnlock(this._selectEquip.getRank());
        }
        if (!this.labelEquipMergeCost.node.parent.active) { return; }

        let rank = this._selectEquip.getRank();
        let gold: number = equipLevelConfig[rank].EqComCost;
        this.labelEquipMergeCost.string = `${gold}`;
        let enough = gold <= bagLogic.getGood(GoodId.Gold).getAmount();
        this.labelEquipMergeCost.node.color = enough ? cc.Color.WHITE : cc.Color.RED;
    }

    protected isInMat(equip: Equip): boolean {
        if (!this._matEquip || this._matEquip.length <= 0) { return false; }

        return (this._matEquip[0] && this._matEquip[0].getId() == equip.getId()) ||
            (this._matEquip[1] && this._matEquip[1].getId() == equip.getId());
    }
    protected removeMat(equip: Equip) {
        for (let i = 0; i < this._matEquip.length; i++) {
            let tmp = this._matEquip[i];
            if (tmp && tmp.getId() == equip.getId()) {
                this._matEquip[i] = null;
                break;
            }
        }
    }
    protected addMat(equip: Equip) {
        for (let i = 0; i < this._matEquip.length; i++) {
            let tmp = this._matEquip[i];
            if (!tmp) {
                this._matEquip[i] = equip;
                break;
            }
        }
    }
    protected hasMat(index: number) {
        if (this._listEquips.length <= 1) { return false; }
        if (this._listEquips.length >= 3) { return true; }

        if (this._matEquip[index]) { return true; }
        let otherIndex = index == 0 ? 1 : 0;
        if (this._matEquip[otherIndex]) { return false; }
        return true;
    }

    protected popMergeReward(equip: Equip, proto: ResourceVO) {
        let reward: Card[] = gm.getReward(proto, false);
        if (!reward) { reward = []; }
        reward.push(equip);
        gcc.core.showLayer("prefabs/panel/reward/RewardPanel", { data: { cards: reward }, modalTouch: true });
    }
}
