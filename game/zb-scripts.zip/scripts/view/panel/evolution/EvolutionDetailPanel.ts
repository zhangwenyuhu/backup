import { PopupPanel } from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import HeroCard from "../../component/Hero/HeroCard";
import HeroEvolutionInfoPreview from "../../component/Hero/HeroEvolutionInfoPreview";
import heroLogic from "../../../logics/HeroLogic";
import HeroCardEvolution from "../../component/Hero/HeroCardEvolution";
import EManager, { EName } from "../../../manager/EventManager";
import EvolutionPanel from "./EvolutionPanel";
import gm from "../../../manager/GameManager";
import assignmentLogic from "../../../logics/AssignmentLogic";
import { EvolutionType, WeekType } from "../../../utils/DefineUtils";
import Hero from "../../../data/card/Hero";
import cm from "../../../manager/ConfigManager";
import { GoodVO, HeroVO } from "../../../proxy/GameProxy";
import heroUtils from "../../../utils/HeroUtils";
import loadUtils from "../../../utils/LoadUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import timeUtils from "../../../utils/TimeUtils";
import commonUtils from "../../../utils/CommonUtils";
import heroRankConfig from "../../../configs/heroRankConfig";
import GoodCard from "../../component/Good/GoodCard";
import Good from "../../../data/card/Good";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/evolution/EvolutionDetailPanel")
export default class EvolutionDetailPanel extends PopupPanel {

    @property(cc.Node)
    bg: cc.Node = null;

    @property(cc.Label)
    title: cc.Label = null;

    @property(cc.Label)
    title2: cc.Label = null;

    @property(CommonLoader)
    evolution_before: CommonLoader = null;

    @property(CommonLoader)
    evolution_after: CommonLoader = null;

    @property(CommonLoader)
    evolution_preview: CommonLoader = null;

    @property(cc.Node)
    arrowNode: cc.Node = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    consume_hero: cc.Node = null;

    @property(cc.Node)
    consume_good: cc.Node = null;

    @property(cc.Node)
    skillNode: cc.Node = null;

    @property(cc.Sprite)
    skill_icon: cc.Sprite = null;

    @property(cc.Node)
    skill_unlock: cc.Node = null;

    @property(cc.Label)
    level1: cc.Label = null;

    @property(cc.Label)
    level2: cc.Label = null;

    protected _evolutionHero = null;
    protected _evolutionHeroAfter = null;
    protected _height = [880, 994];

    onInit(data: {
        evolutionHero,
        consumeHeros,
        evolutionType: EvolutionType
    }) {
        super.onInit(data);
    }

    onLoad() {
        super.onLoad();
        this.consume_hero.parent = this.consume_good.parent = null;
    }

    start() {
        super.start();

        let titleStr = stringConfigMap[`key_evolution_type${this.data.evolutionType}`].Value;
        this.title.string = titleStr + "详情";
        this.title2.string = titleStr + "消耗";
        this.evolution_before.loaderNode.getComponent(HeroCard).showHeroRankName();
        this._evolutionHero = this.data.evolutionHero.clone() as Hero;
        if (this.data.evolutionType == EvolutionType.Merge) {
            let heroVO = new HeroVO();
            let hConfig = cm.getHeroConfig(this._evolutionHero.getIndex());
            heroVO.equips = [];
            heroVO.atkValue = hConfig.Atk;
            heroVO.defValue = hConfig.Def;
            heroVO.hp = hConfig.Hp;
            heroVO.exp = 0;
            heroVO.lv = 1;
            heroVO.rank = hConfig.DefaultRank;
            let starLimit = heroRankConfig[hConfig.DefaultRank - 1].starlimit;
            heroVO.star = starLimit;
            heroVO.heroCofId = this._evolutionHero.getIndex();
            heroVO.heroId = this._evolutionHero.getId();
            heroVO.criticalPct = hConfig.CritRate;
            heroVO.criticalAtkValue = hConfig.CritValue;
            heroVO.dodgeValue = hConfig.DodgeRate;
            heroVO.hitValue = hConfig.HitRate;
            heroVO.liftLeechValue = hConfig.HarmAbsorbLv;
            heroVO.magicResistPct = hConfig.M_DeHarmRate;
            heroVO.phyResistPct = hConfig.P_DeHarmRate;
            heroVO.skillSpeed = hConfig.SkillSpeed;
            heroVO.recoverSec = hConfig.Recovery;
            heroVO.hitEnergy = hConfig.HitEnergy;
            heroVO.beHitEnergy = hConfig.BeHitEnergy;
            heroVO.heroAddInfos = heroUtils.getHeroAddInfos(heroVO.equips);
            this._evolutionHero = new Hero(heroVO);
            this._evolutionHero.calcProperties();
        }
        this.evolution_before.loaderNode.getComponent(HeroCard).refresh(this._evolutionHero);
        this._evolutionHeroAfter = this._evolutionHero.clone() as Hero;
        if (this.data.evolutionType == EvolutionType.Evolution) {
            this._evolutionHeroAfter.setRank(this._evolutionHeroAfter.getRank(true) + 1);
        } else if (this.data.evolutionType == EvolutionType.Star) {
            this._evolutionHeroAfter.setStar(this._evolutionHeroAfter.getStar() + 1);
        } else {
            this._evolutionHeroAfter = null;
        }
        if (this.data.evolutionType != EvolutionType.Merge) {
            this.evolution_after.loaderNode.getComponent(HeroCard).showHeroRankName();
            this.evolution_after.loaderNode.getComponent(HeroCard).refresh(this._evolutionHeroAfter);
        } else {
            this.evolution_after.node.active = false;
            this.evolution_before.node.x = 0;
            this.arrowNode.active = false;
        }
        for (let i: number = 0; i < this.data.consumeHeros.length; i++) {
            let consumeHero = this.data.consumeHeros[i];
            let heroNode = cc.instantiate(this.consume_hero);
            heroNode.parent = this.content;
            heroNode.getComponent(CommonLoader).loaderNode.getComponent(HeroCard).refresh(consumeHero.clone());
        }
        if (this.data.evolutionType == EvolutionType.Star) {
            let config = this.data.evolutionHero.getStarConfig(true);
            if (config && config.goodsnumber != null) {
                let goodNode = cc.instantiate(this.consume_good);
                goodNode.parent = this.content;
                let goodVo = new GoodVO();
                goodVo.propId = config.goodsnumber[0];
                goodVo.amt = config.goodsnumber[1];
                goodNode.getComponent(CommonLoader).loaderNode.getComponent(GoodCard).refresh(new Good(goodVo));
            }
        }
        this.evolution_preview.loaderNode.getComponent(HeroEvolutionInfoPreview).refresh({
            hero: this._evolutionHero,
            evolutionHero: this._evolutionHeroAfter
        });
        this.bg.height = this._height[0];
        this.skillNode.active = false;
        if (this.data.evolutionType == EvolutionType.Star) {
            let heroCfg = cm.getHeroConfig(this._evolutionHeroAfter.getIndex());
            if (heroCfg.HeroSkill && heroCfg.HeroSkill > 0 && this._evolutionHeroAfter.getStar() > 1 && this._evolutionHeroAfter.getStarUpperLimit() > 1) {
                this.bg.height = this._height[1];
                this.skillNode.active = true;
                this.skill_unlock.active = this._evolutionHeroAfter.getStar() == 1;
                let heroSkillCfg = cm.getHeroSkillConfig(this._evolutionHeroAfter.getUniqueSkillId());
                loadUtils.loadSpriteFrame(`textures/icon/skill/${heroSkillCfg.skillicon}`, this.skill_icon);
                let level = this._evolutionHeroAfter.getHeroSkillLevel();
                this.level1.string = `Lv.${level == 0 ? 0 : level - 1}`;
                this.level2.string = `Lv.${level == 0 ? 1 : level}`;
            }
        }
    }

    onExclusiveSkill() {
        gcc.core.showLayer("prefabs/panel/skill/HeroSkillPanel", {
            data: { hero: this._evolutionHero }, modalWindow: false, modalTouch: true
        });
    }

    async onEvolution() {
        if (this.data.evolutionType == EvolutionType.Evolution) {
            let nameStr = heroLogic.checkConsumeHeroes(this.data.consumeHeros);
            if (this._getMythHero() != "") {
                gm.dialog({
                    title: "提示", content: `进化材料中含SSR/UR级英雄 ${this._getMythHero()}，是否消耗？`, okText: "确认", confirm: () => {
                        this._doEvolution();
                    }
                });
            } else if (nameStr != "") {
                gm.dialog({
                    content: `消耗材料中的${nameStr}在共享花坛中，确认消耗会自动将材料从共享花坛中去除`, confirm: () => {
                        this._doEvolution();
                    }
                });
            } else {
                this._doEvolution();
            }
        } else {
            this._doEvolution();
        }
    }

    protected _getMythHero() {
        let heroNames: string = "";
        for (let i = 0; i < this.data.consumeHeros.length; i++) {
            let hero = this.data.consumeHeros[i];
            if (hero.getIndex() != this.data.evolutionHero.getIndex() && hero.getQuality() == 3) {
                if (heroNames == "") {
                    heroNames += hero.getName();
                } else {
                    heroNames += `、${hero.getName()}`;
                }
            }
        }
        return heroNames;
    }

    protected _getMainHero() {
        let config = cm.getHeroCompoundConfig(this.data.evolutionHero.getIndex());
        let mainHeroId = this.data.consumeHeros.find(a => a.getIndex() == config.HeroSpend[0][0]).getId();
        for (let h of this.data.consumeHeros) {
            if (h.getId() == mainHeroId) {
                return h;
            }
        }
        return null;
    }

    protected async _doEvolution() {
        try {
            let consumeHeros = this.data.consumeHeros;
            let cards = heroLogic.getSplitAllCards(consumeHeros, false);
            if (this.data.evolutionType == EvolutionType.Evolution) {
                await heroLogic.doEvolution(this.data.evolutionHero, this.data.consumeHeros);
                assignmentLogic.weekTaskProCommit(WeekType.advance_hero);
            } else if (this.data.evolutionType == EvolutionType.Star) {
                await heroLogic.doStar(this.data.evolutionHero, this.data.consumeHeros);
            } else if (this.data.evolutionType == EvolutionType.Merge) {
                await heroLogic.doMerge(this.data.evolutionHero, this.data.consumeHeros);
            }
            heroLogic.doClearHerosEquip(this.data.consumeHeros);

            if (this.data.evolutionType == EvolutionType.Merge) {
                EManager.emit(EName.onStartMerge);
                this.node.active = false;
                await commonUtils.sleep(2, this);
            }

            let selectHero = HeroCardEvolution.resetData();
            if (selectHero) {
                // EManager.emit(HeroCardEvolution.Event.onEvolutionSelect, selectHero);
                HeroCardEvolution.forceSelectHeroCard(selectHero);
            }
            EManager.emit(EvolutionPanel.Event.onEvolutionRefresh);
            EManager.emit(EName.onRefreshHeroList);
            gcc.core.showLayer("prefabs/panel/evolution/EvolutionSuccessPanel", {
                data: {
                    hero: this._evolutionHero,
                    evolutionType: this.data.evolutionType,
                    clickEvent: () => {
                        if (cards.length > 0) {
                            this.scheduleOnce(() => {
                                gcc.core.showLayer("prefabs/panel/reward/RewardPanel", {
                                    data: {
                                        cards: cards,
                                        refund: true
                                    }, modalTouch: true
                                });
                            });
                        }
                    }
                }
            });
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

}
