import { stringConfigMap } from "../../../configs/stringConfig";
import Equip from '../../../data/card/Equip';
import Hero from "../../../data/card/Hero";
import PlayerHero from "../../../data/card/PlayerHero";
import { PromptType } from '../../../data/prompt/PromptModal';
import guideLogic from '../../../logics/GuideLogic';
import heroLogic from "../../../logics/HeroLogic";
import cm from "../../../manager/ConfigManager";
import EManager, { EName } from "../../../manager/EventManager";
import gm from "../../../manager/GameManager";
import { HeroVO } from "../../../proxy/GameProxy";
import commonUtils from "../../../utils/CommonUtils";
import loadUtils from "../../../utils/LoadUtils";
import storageUtils from "../../../utils/StorageUtils";
import stringUtils from "../../../utils/StringUtils";
import CommonLoader from "../../common/CommonLoader";
import List from '../../common/List';
import TabLoader from "../../common/loader/TabLoader";
import EvolutionMergeHero from "../../component/Evolution/EvolutionMergeHero";
import HeroCard from "../../component/Hero/HeroCard";
import HeroCardEvolution, { HeroEvolutionSelected } from "../../component/Hero/HeroCardEvolution";
import HeroCardEvolutionTip from "../../component/Hero/HeroCardEvolutionTip";
import HeroQuality from "../../component/Hero/HeroQuality";
import UnlockWrapper from '../../widget/unlock/UnlockWrapper';
import { FullscreenPanel } from "../BasePanel";
import { unlockConfigMap } from './../../../configs/unlockConfig';
import { EvolutionType, Storage } from './../../../utils/DefineUtils';
import MergePanel from './MergePanel';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/evolution/EvolutionPanel")
export default class EvolutionPanel extends FullscreenPanel {

    static Event = {
        onEvolutionRefresh: "on evolution refresh"
    };

    @property(cc.Label)
    title: cc.Label = null;

    @property(sp.Skeleton)
    hero_head: sp.Skeleton = null;

    @property(CommonLoader)
    hero_quality: CommonLoader = null;

    @property(cc.Node)
    evolutionBtn: cc.Node = null;

    @property(cc.Node)
    allEvolutionBtn: cc.Node = null;

    @property(cc.Node)
    allEvolutionBtn2: cc.Node = null;

    @property(cc.Node)
    evolution_hero1: cc.Node = null;

    @property(cc.Node)
    evolution_hero2: cc.Node = null;

    @property(cc.Node)
    evolution_hero3: cc.Node = null;

    @property(cc.Node)
    heroTip1: cc.Node = null;

    @property(cc.Node)
    heroTip2: cc.Node = null;

    @property(cc.Node)
    heroTip3: cc.Node = null;

    @property(cc.Node)
    bottomNode: cc.Node = null;

    @property(cc.Node)
    heroTab: cc.Node = null;

    @property(cc.Node)
    contentBg: cc.Node = null;

    @property(cc.Node)
    evolution_mark: cc.Node = null;

    @property(cc.Node)
    evolution_merge: cc.Node = null;

    @property(cc.Node)
    evoHeroesNode: cc.Node = null;

    @property(cc.Node)
    mergeHeroesNode: cc.Node = null;

    @property(cc.Node)
    mergeTip: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    heroTipItem: cc.Node = null;

    @property(cc.Node)
    mergeHeroItem: cc.Node = null;

    @property(List)
    heroScrollView: List = null;

    @property(cc.Node)
    evolutionTemplate: cc.Node = null;

    @property(cc.Label)
    evolutionTip: cc.Label = null;

    @property(cc.Node)
    mergeBtn: cc.Node = null;

    @property(cc.Node)
    tapNode: cc.Node = null;

    @property(cc.Node)
    skillNode: cc.Node = null;

    @property(cc.Label)
    skillTitle: cc.Label = null;

    @property(cc.Label)
    skillDesc: cc.Label = null;

    @property(cc.Sprite)
    skillIcon: cc.Sprite = null;

    @property(cc.Node)
    equipMergeLock: cc.Node = null;

    @property(cc.Node)
    mergeLock: cc.Node = null;

    @property(cc.Node)
    module: cc.Node = null;

    @property(cc.Node)
    rootNode: cc.Node = null;

    protected _index: string = "1";
    protected _evolutionTab: EvolutionType = EvolutionType.Evolution;
    protected _lastSkeletonData: sp.SkeletonData = null;
    protected _lastEvolutionHero: Hero = null;

    protected _heroes: { hero: Hero, evolutable: boolean, evolutionType: EvolutionType }[] = [];
    protected _filterHeroes: { hero: Hero, evolutable: boolean, evolutionType: EvolutionType }[] = [];
    protected _mergeHeroes: Hero[] = [];

    protected _tab: number = 0;
    protected _param: any = null;
    onLoad() {
        super.onLoad();

        this.heroItem.parent = null;
        this.heroTipItem.parent = null;
        this.mergeHeroItem.parent = null;
        this.evolutionTemplate.parent = null;
        this.registerEvents();
        this.bottomNode.height = cc.winSize.height / 2 + this.bottomNode.y - 97;
    }

    onInit(data: any) {
        super.onInit(data);

        if (data) {
            if (typeof data == "number") {
                this._tab = data;
            } else {
                this._tab = data.tab ? data.tab : this._tab;
                this._param = data.param;
            }

        }
    }

    onDestroy() {
        this.evolutionTemplate.destroy();
        HeroCardEvolution.resetData(true);

        super.onDestroy();
    }

    start() {
        super.start();

        this.equipMergeLock.active = !UnlockWrapper.isUnlock(unlockConfigMap.装备合成);
        this.mergeLock.active = !UnlockWrapper.isUnlock(unlockConfigMap.合成);

        if (!storageUtils.getBoolean(Storage.EvolutionGuide)) {
            storageUtils.setBoolean(Storage.EvolutionGuide.Key, true, true);
            EManager.emit(EName.onRedDirty, PromptType.EvolutionBtn);
        }

        if (!storageUtils.getBoolean(Storage.HeChengGuide)) {
            if (UnlockWrapper.isUnlock(unlockConfigMap.合成)) {
                storageUtils.setBoolean(Storage.HeChengGuide.Key, true, true);
                this._tab = EvolutionType.Merge;
                guideLogic.guideId = 220001;
            }
        }
        else if (!storageUtils.getBoolean(Storage.GuideMergeEquip)) {
            if (UnlockWrapper.isUnlock(unlockConfigMap.装备合成)) {
                storageUtils.setBoolean(Storage.GuideMergeEquip.Key, true, true);
                this._tab = EvolutionType.EquipMerge;
                guideLogic.guideId = 260001;
            }
        }


        this._mergeHeroes = heroLogic.getMergeHeroes();
        let canMerge: boolean = false;
        for (let hero of this._mergeHeroes) {
            if (heroLogic.canMerge(hero as PlayerHero).result) {
                canMerge = true;
                gm.lastMergeHeroIndex = hero.getIndex();
                break;
            }
        }
        // 没有可选且没有选过，默认选择第一个
        if (!canMerge && gm.lastMergeHeroIndex == 0) {
            gm.lastMergeHeroIndex = this._mergeHeroes[0].getIndex();
        }
        let tab = 1;
        if (this._tab && typeof this._tab == "number") {
            tab = this._tab;
        }
        this.tapNode.getComponent(TabLoader).switchTab(tab - 1);
        this.scheduleOnce(() => {
            this.onTabClick(null, tab.toString());
        });
    }

    onClickEquipMergeLock() {
        gm.toast(unlockConfigMap.装备合成.tips);
    }

    onClickMergeLock() {
        gm.toast(unlockConfigMap.装备合成.tips);
    }

    onHeroItemRender(item: cc.Node, index: number) {
        let evolution = item.getChildByName("evolution");
        let comp = evolution.getComponent(HeroCardEvolution);
        comp.refresh(this._filterHeroes[index]);

        item.name = comp.hero.getRName();
    }

    sortEvolutionHeros(heros: { hero: Hero, evolutable: boolean, evolutionType: EvolutionType }[]) {
        heros.sort((a, b) => {
            let aRankTop = a.hero.isRankable() ? 1 : 0;
            let bRankTop = b.hero.isRankable() ? 1 : 0;
            if (aRankTop != bRankTop) return bRankTop - aRankTop;
            let aResult = a.evolutable ? 1 : 0;
            let bResult = b.evolutable ? 1 : 0;
            if (aResult != bResult) return bResult - aResult;

            let aRank = a.hero.getRank(true);
            let bRank = b.hero.getRank(true);
            if (aRank != bRank) return bRank - aRank;

            let aLevel = a.hero.getLevel();
            let bLevel = b.hero.getLevel();
            if (aLevel != bLevel) return bLevel - aLevel;

            let aPower = a.hero.getPower();
            let bPower = b.hero.getPower();
            if (aPower != bPower) return bPower - aPower;

            return a.hero.getIndex() - b.hero.getIndex();
        });
        return heros;
    }

    sortStarHeroes(heros: { hero: Hero, evolutable: boolean, evolutionType: EvolutionType }[]) {
        heros.sort((a, b) => {
            let aResult = a.hero.getStar() < a.hero.getStarUpperLimit() ? 1 : 0;
            let bResult = b.hero.getStar() < b.hero.getStarUpperLimit() ? 1 : 0;
            if (aResult != bResult) return bResult - aResult;

            let aRank = a.hero.getRank(true);
            let bRank = b.hero.getRank(true);
            if (aRank != bRank) return bRank - aRank;

            let aPower = a.hero.getPower();
            let bPower = b.hero.getPower();
            if (aPower != bPower) return bPower - aPower;

            return b.hero.getIndex() - a.hero.getIndex();
        });
        return heros;
    }

    checkCanAllEvolution() {
        let list = [];
        let heros = heroLogic.getEvolutionHeroes();
        heros.foreach(a => {
            let evolutionResult = heroLogic.canEvolution(a, [], [], false, false);
            if (evolutionResult.result && a.getRank(true) < 5 && this._checkQuality(evolutionResult.consumeHeroes)) {
                if (list.indexOf(a) == -1) {
                    list.push(a);
                }
            }
        });
        return list.length >= 6;
    }

    protected _checkQuality(heroes: any[]): boolean {
        for (let hero of heroes) {
            for (let _hero of hero) {
                if (_hero.getRank(true) >= 4) {
                    return false;
                }
            }
        }
        return true;
    }

    registerEvents() {
        let listener = EManager.addEventArray([HeroCardEvolution.Event.onEvolutionCheck, EvolutionPanel.Event.onEvolutionRefresh], () => {
            if (this._evolutionTab == EvolutionType.Merge && HeroCardEvolution.evolutionHero) {
                gm.lastMergeHeroIndex = HeroCardEvolution.evolutionHero.getIndex();
            }
            this.refreshHero();
            this.onFilterClick(null, this._index, true);
        });
        this._eventListeners.pushList(listener);

        let listener2 = EManager.addEvent(EName.onStartMerge, () => {
            this.node.getComponent(cc.Animation).play("EvolutionPanel_cp", 0);
        });
        this._eventListeners.push(listener2);
    }

    onFilterClick(event: cc.Event.EventTouch, index: string, isForce: boolean = false) {
        if (this._index == index && !isForce) {
            return;
        }

        let heros = null;
        this._index = index;
        if (index == "1") {
            heros = this._heroes;
        } else {
            heros = this._heroes.filter(a => a.hero.getFaction() == parseInt(index) - 1);
        }
        this._filterHeroes = heros;
        this.heroScrollView.numItems = this._filterHeroes.length;
    }

    resetUI() {
        this.evolutionBtn.active = false;
        this.hero_quality.node.active = false;
        this.hero_head.node.active = false;
        if (this._evolutionTab == EvolutionType.Merge) {
            this.evolution_mark.active = false;
        } else {
            this.evolution_mark.active = true;
        }
        this.evolution_merge.active = false;
        this.evolution_hero1.active = false;
        this.evolution_hero2.active = false;
        this.evolution_hero3.active = false;
        this.heroTip1.active = false;
        this.heroTip2.active = false;
        this.heroTip3.active = false;
        this.evolutionBtn.active = false;
        this.allEvolutionBtn.active = false;
        this.allEvolutionBtn2.active = false;
        this.evolutionTip.node.active = false;
        this.mergeBtn.active = false;
        this.evoHeroesNode.active = false;
        this.mergeHeroesNode.active = false;
        this.mergeTip.active = false;
        this.skillNode.active = false;
    }

    async refreshHero() {
        this.resetUI();
        this.title.string = stringConfigMap[`key_evolution_type${this._evolutionTab}`].Value;
        this._refreshHeroScrollView();
        if (this._evolutionTab == EvolutionType.Evolution) {
            this._showEvolutionView();
        } else if (this._evolutionTab == EvolutionType.Merge) {
            this._showMergeView();
        }
    }

    protected _refreshHeroQuality() {
        if (HeroCardEvolution.evolutionHero != null) {
            let hero = HeroCardEvolution.evolutionHero;
            if (this._evolutionTab == EvolutionType.Merge) {
                let config = cm.getHeroCompoundConfig(hero.getIndex());
                let mergeHero = HeroCardEvolution.evolutionHero.clone();
                mergeHero.setRank(config.HeroSpend[0][2]);
                hero = mergeHero;
            }
            this.hero_quality.loaderNode.getComponent(HeroQuality).refresh({ hero: hero, showQuality: true });
        } else {
            this.hero_quality.node.active = false;
        }
    }

    protected _refreshHeroScrollView() {
        this._filterHeroes = [];
        if (this._evolutionTab == EvolutionType.Evolution) {
            let heroes = heroLogic.getEvolutionHeroes();
            for (let hero of heroes) {
                this._filterHeroes.push({
                    hero: hero,
                    evolutable: heroLogic.canEvolution(hero, [], [], false, false).result,
                    evolutionType: EvolutionType.Evolution
                });
            }
        } else if (this._evolutionTab == EvolutionType.Merge) {
            for (let hero of this._mergeHeroes) {
                this._filterHeroes.push({
                    hero: hero,
                    evolutable: heroLogic.canMerge(hero as PlayerHero).result,
                    evolutionType: EvolutionType.Merge
                });
            }
        }
        this._filterHeroes = this.sortEvolutionHeros(this._filterHeroes);
        this._heroes = this._filterHeroes;
        this.heroScrollView.numItems = this._filterHeroes.length;
    }

    protected async _showMergeView() {
        this.mergeHeroesNode.active = true;
        this.mergeTip.active = true;
        this.evolution_merge.active = true;
        if (HeroCardEvolution.evolutionHero == null) {
            this.mergeBtn.active = false;
            return;
        } else {
            this.mergeBtn.active = true;
            this.hero_quality.node.active = true;
            this._refreshHeroQuality();
            let evolutionHero = HeroCardEvolution.evolutionHero;
            let config = cm.getHeroCompoundConfig(evolutionHero.getIndex());
            let material = [];
            for (let i = 1; i < config.HeroSpend.length; i++) {
                material.push(config.HeroSpend[i]);
                if (i == 2) {
                    material.push(config.HeroSpend[0]);
                }
            }
            for (let i = 0; i < material.length; i++) {
                let spend = material[i];
                let heroId = spend[0];
                let heroLevel = spend[1];
                let heroRank = spend[2];
                let heroStar = spend[3] || 0;
                let heroVo = new HeroVO();
                heroVo.equips = [];
                heroVo.exp = 0;
                heroVo.heroAddInfos = [];
                heroVo.heroCofId = heroId;
                heroVo.heroId = stringUtils.generateUUID();
                heroVo.lv = heroLevel;
                heroVo.rank = heroRank;
                heroVo.star = heroStar;
                let nodeParent = this.mergeHeroesNode.getChildByName(`item${i + 1}`);
                let heroNode = nodeParent.getChildByName("mergeHeroItem");
                let loaderNode = heroNode.getComponent(CommonLoader).loaderNode;
                loaderNode.getComponent(EvolutionMergeHero).refresh(heroVo);
            }
            await this._refreshHeroSpine();
        }
    }

    protected _getSelectedHeroes(): { [key: number]: HeroEvolutionSelected } {
        return HeroCardEvolution.selectedHero;
        // let heros: HeroEvolutionSelected[] = HeroCardEvolution.selectedHero.where(a => a.selected == true);
        // if (heros.length < HeroCardEvolution.upgradeCnt) {
        //     let lastCnt = HeroCardEvolution.upgradeCnt - heros.length;
        //     for (let i: number = 0; i < lastCnt; i++) {
        //         let hero = HeroCardEvolution.selectedHero.find(a => a.selected == true && heros.indexOf(a) == -1);
        //         if (hero) {
        //             heros.push(hero);
        //         }
        //     }
        // }
        // return heros;
    }

    protected async _showEvolutionView() {
        this.evoHeroesNode.active = true;
        let canAllEvolution = this.checkCanAllEvolution();
        this.allEvolutionBtn.active = canAllEvolution;
        if (HeroCardEvolution.evolutionHero == null) {
            this.evolutionBtn.active = false;
            this.allEvolutionBtn.active = false;
            this.allEvolutionBtn2.active = canAllEvolution;
            this.evolutionTip.node.active = false;
            return;
        } else {
            this.hero_quality.node.active = true;
            this._refreshHeroQuality();
            this.evolutionBtn.active = true;
            this.evolution_mark.active = false;
            this.allEvolutionBtn2.active = false;
            let heros = this._getSelectedHeroes();
            let evolutionHero = HeroCardEvolution.evolutionHero;
            let add = HeroCardEvolution.canSelectedHero.length >= HeroCardEvolution.upgradeCnt;
            for (let i: number = 0; i < HeroCardEvolution.upgradeCnt; i++) {
                if (i <= 0) {
                    this._showHeroTip(this.heroTip1, evolutionHero, add, i);
                } else if (i <= 1) {
                    this._showHeroTip(this.heroTip2, evolutionHero, add, i);
                } else if (i <= 2) {
                    this._showHeroTip(this.heroTip3, evolutionHero, add, i);
                }
            }
            for (let i: number = 0; i < HeroCardEvolution.upgradeCnt; i++) {
                if (i == 0 && heros[i]) {
                    this._showEvolutionHero(this.heroTip1, heros[i], this.evolution_hero1);
                } else if (i == 1 && heros[i]) {
                    this._showEvolutionHero(this.heroTip2, heros[i], this.evolution_hero2);
                } else if (i == 2 && heros[i]) {
                    this._showEvolutionHero(this.heroTip3, heros[i], this.evolution_hero3);
                }
            }
            if (evolutionHero.getStarLimit() && evolutionHero.getStarRequire() > 0 && evolutionHero.getStarUpperLimit() > 0) {
                this.evolutionBtn.active = false;
                this.allEvolutionBtn.active = false;
                this.evolutionTip.node.active = true;
                this.evolutionTip.string = stringUtils.getString(stringConfigMap.key_evolution_reach_star.Value, { level: evolutionHero.getStarRequire() });
            } else {
                this.evolutionTip.node.active = false;
            }
            await this._refreshHeroSpine();
        }
    }

    protected _showHeroTip(heroTip, evolutionHero: Hero, add, index) {
        heroTip.active = true;
        let heroCardTip = heroTip.getComponent(CommonLoader).loaderNode.getComponent(HeroCardEvolutionTip);
        heroCardTip.enableAnim = false;
        heroCardTip.showOpacity(150);
        heroCardTip.refresh({
            hero: evolutionHero,
            evolutionType: this._evolutionTab,
            index: index,
            add: add
        });
    }

    protected _showEvolutionHero(heroTip, hero, evolutionHeroNode) {
        heroTip.active = false;
        evolutionHeroNode.active = true;
        evolutionHeroNode.opacity = hero.selected ? 255 : 180;
        let loaderNode = evolutionHeroNode.getComponent(CommonLoader).loaderNode;
        let heroCard = loaderNode.getComponent(HeroCard);
        heroCard.enableAnim = false;
        heroCard.refresh(hero.hero);
        heroCard.refreshHeroInfo(true);
        if (loaderNode.getComponent(cc.Button)) {
            loaderNode.getComponent(cc.Button).destroy();
        }
        evolutionHeroNode.on(cc.Node.EventType.TOUCH_END, () => {
            let hero = Object.values(HeroCardEvolution.selectedHero).find(a => a && a.hero && a.hero.getId() == heroCard.getHero().getId());
            if (hero) {
                hero.selected = false;
                // HeroCardEvolution.selectedHero.remove(hero);
                HeroCardEvolution.removeSelectedHero(hero.hero);
                EManager.emit(HeroCardEvolution.Event.onEvolutionCheck);
            }
        }, this);

    }

    protected async _refreshHeroSpine() {
        this.hero_head.node.active = true;

        if (this._lastEvolutionHero != HeroCardEvolution.evolutionHero) {
            this._lastEvolutionHero = HeroCardEvolution.evolutionHero;
            await gm.createHeroSpine(this._lastEvolutionHero, this.hero_head);
        }
        if (this._lastSkeletonData != this.hero_head.skeletonData) {
            loadUtils.releaseAssetRecursively(this._lastSkeletonData);
            this._lastSkeletonData = this.hero_head.skeletonData;
        }
    }

    onExclusiveSkill() {
        gcc.core.showLayer("prefabs/panel/skill/HeroSkillPanel", {
            data: { hero: HeroCardEvolution.evolutionHero }, modalWindow: false, modalTouch: true
        });
    }

    async onEvolution() {
        if (HeroCardEvolution.evolutionHero == null) {
            return;
        }
        let consumeHeros = this._getConsumeHeroes();
        if (consumeHeros.length < HeroCardEvolution.upgradeCnt) {
            gm.toast(stringConfigMap.key_choose_evo_material.Value);
            return;
        }
        gcc.core.showLayer("prefabs/panel/evolution/EvolutionDetailPanel", {
            data: {
                evolutionHero: HeroCardEvolution.evolutionHero,
                consumeHeros: consumeHeros,
                evolutionType: this._evolutionTab
            }
        });
    }

    onAllEvolution() {
        gcc.core.showLayer("prefabs/panel/evolution/AllEvolutionPanel");
    }

    onHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "evolution" } });
    }

    onHeroHead() {
        if (this._evolutionTab != EvolutionType.Merge) {
            HeroCardEvolution.evolutionHero = null;
            EManager.emit(HeroCardEvolution.Event.onEvolutionCheck);
        }
    }

    async onTabClick(event: cc.Event.EventTouch, index: string) {
        let type = parseInt(index);
        let result = await this._showModuleView(type);
        if (result) { return; }

        this._index = "1";
        this.heroTab.getComponent(TabLoader).switchTab(0);
        HeroCardEvolution.resetData(true);
        this._evolutionTab = parseInt(index);
        if (this._evolutionTab == EvolutionType.Merge && gm.lastMergeHeroIndex != 0) {
            HeroCardEvolution.evolutionHero = this._mergeHeroes.find(a => a.getIndex() == gm.lastMergeHeroIndex);
        }
        this.refreshHero();
    }

    protected _getConsumeHeroes() {
        let consumeHeros = [];
        let keys = Object.keys(HeroCardEvolution.selectedHero);
        for (let key of keys) {
            let selectedHero = HeroCardEvolution.selectedHero[parseInt(key)];
            if (selectedHero.selected) {
                consumeHeros.push(selectedHero.hero);
            }
        }
        return consumeHeros;
    }

    protected async _showModuleView(type: EvolutionType) {
        let moduleValid: boolean = type == EvolutionType.EquipMerge
        this.module.active = moduleValid;
        this.rootNode.active = !moduleValid;

        if (this.module.active) {
            let node: cc.Node = this.module.childrenCount == 0 ? null : this.module.children[0];
            if (!node) {
                let url: string = 'prefabs/panel/evolution/MergePanel';
                let prefab = cc.loader.getRes(url, cc.Prefab);
                if (!prefab) { prefab = await loadUtils.loadRes(url, cc.Prefab) as cc.Prefab; }
                this.module.getComponent(cc.Widget).updateAlignment();

                node = cc.instantiate(prefab) as cc.Node;
                node.setContentSize(this.module.getContentSize());
                node.position = cc.v2();
                node.parent = this.module;
            }
            let comp = node.getComponent(MergePanel);
            if (this._param instanceof Equip) {
                comp.refresh(this._param);
                this._param = null;
            } else {
                comp.refresh();
            }
        }
        return moduleValid;
    }

    onStar() {
        if (HeroCardEvolution.evolutionHero == null) {
            return;
        }
        let consumeHeros = this._getConsumeHeroes();
        if (consumeHeros.length < HeroCardEvolution.upgradeCnt) {
            gm.toast(stringConfigMap.key_choose_star_material.Value);
            return;
        }
        gcc.core.showLayer("prefabs/panel/evolution/EvolutionDetailPanel", {
            data: {
                evolutionHero: HeroCardEvolution.evolutionHero,
                consumeHeros: consumeHeros,
                evolutionType: this._evolutionTab
            }
        });
    }

    async onMerge() {
        if (HeroCardEvolution.evolutionHero == null) {
            return;
        }
        let consumeHeros: Hero[] = [];
        for (let i = 1; i <= 5; i++) {
            let node = this.mergeHeroesNode.getChildByName(`item${i}`).children[0];
            let mergeHero = node.getComponent(CommonLoader).loaderNode.getComponent(EvolutionMergeHero);
            if (mergeHero && mergeHero.getHero()) {
                consumeHeros.push(mergeHero.getHero());
            }
        }
        if (consumeHeros.length < 3) {
            gm.toast(stringConfigMap.key_choose_merge_material.Value);
            return;
        }
        gcc.core.showLayer("prefabs/panel/evolution/EvolutionDetailPanel", {
            data: {
                evolutionHero: HeroCardEvolution.evolutionHero,
                consumeHeros: consumeHeros,
                evolutionType: this._evolutionTab
            }
        });
    }

    protected async _preloadRes() {
        await super._preloadRes();

        await loadUtils.loadRes("prefabs/panel/evolution/MergePanel", cc.Prefab);
        this._unloadInfos.push({ url: commonUtils.getBgUrl("evolution_bg"), type: cc.SpriteFrame });
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);

        if (this._lastSkeletonData) {
            loadUtils.releaseAssetRecursively(this._lastSkeletonData);
            this._lastSkeletonData = null;
        }
    }
}
