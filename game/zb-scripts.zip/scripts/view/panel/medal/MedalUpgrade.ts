import MedalModule from "./MedalModule";
import playerLogic from "../../../logics/PlayerLogic";
import medalLogic from "../../../logics/MedalLogic";
import medalconfig, { medalconfigRow } from "../../../configs/medalconfig";
import CommonLoader from "../../common/CommonLoader";
import GoodCard from "../../component/Good/GoodCard";
import gm from "../../../manager/GameManager";
import { GoodVO } from "../../../proxy/GameProxy";
import Good from "../../../data/card/Good";
import bagLogic from "../../../logics/BagLogic";
import commonUtils from "../../../utils/CommonUtils";
import loadUtils from "../../../utils/LoadUtils";
import cm from "../../../manager/ConfigManager";
import ResGotoPanel, { ResType } from "../help/ResGotoPanel";
import EManager, { EName } from "../../../manager/EventManager";
const { ccclass, property, menu } = cc._decorator;

let mUpgradeColor = {
    buff_normal: 'd28000',
    buff_max: 'ff7200',
    buff_next: '37901b',
    cond_now_max: 'd28000',
    cond_less: 'b62424',
    cond_next: '9f746a',
    label_green: '37901B'
}

@ccclass
@menu("view/panel/medal/MedalUpgrade")
export default abstract class MedalUpgrade extends MedalModule {

    @property(cc.Node)
    btnUpgrade: cc.Node = null;

    @property(cc.Node)
    labelUpgradeMax: cc.Node = null;

    @property(cc.Node)
    nowLv: cc.Node = null;

    @property(cc.Node)
    lvArrow: cc.Node = null;

    @property(cc.Node)
    nextLv: cc.Node = null;

    @property(cc.Node)
    propBuff1: cc.Node = null;

    @property(cc.Node)
    propBuff2: cc.Node = null;

    @property(cc.Node)
    techNum: cc.Node = null;

    @property(cc.Node)
    condition1: cc.Node = null;

    @property(cc.Node)
    condition2: cc.Node = null;

    @property(cc.Node)
    upgradeMat: cc.Node = null;

    @property(cc.Node)
    matItem: cc.Node = null;

    @property(cc.Node)
    matTip: cc.Node = null;

    protected _nowLv: number = 1;
    protected _bMax: boolean = false;
    protected _nowCof: medalconfigRow = null;
    protected _nextCof: medalconfigRow = null;
    onLoad() {
        this.matItem.parent = null;
    }
    onDestroy() {
        this.matItem.destroy();
    }
    onEnable() { }
    onDisable() { }
    start() { }

    public refresh() {
        this._nowLv = playerLogic.getPlayer().getMedalLevel();
        this._bMax = this._nowLv >= medalLogic.getMaxMedalLv();
        this._nowCof = medalconfig[this._nowLv - 1];
        if (!this._bMax) { this._nextCof = medalconfig[this._nowLv]; }

        this.labelUpgradeMax.active = this._bMax;
        this.btnUpgrade.active = !this._bMax;

        this._updateLv();
        this._updateBuff();
        this._updateCondition();
        this._updateMat();

        this.techNum.parent.active = !this._bMax;
        if (this.techNum.parent.active) {
            this.techNum.getComponent(cc.Label).string = `${this._nowCof.point[1]}`;
        }
    }

    protected onClickLvup() {
        if (this._bMax) { return; }
        let ret = bagLogic.checkGoodCostResult(this._nowCof.cost);
        if (!ret.ret) {
            gm.lackResGotoPanel(ResType.medal);
            //gm.toast(ret.msg); 
            return;
        }

        let result = this._checkLvupLimit();
        if (!result.ret) { gm.toast(result.msg); return; }

        let effect2 = this.propBuff2.parent.getChildByName('effect2');
        commonUtils.playAnimation(this.propBuff1.parent.getChildByName('effect1'), 'ItemlevelupGlow');
        commonUtils.playAnimation(effect2, 'ItemlevelupGlow', () => {
            commonUtils.playAnimation(this.nextLv.getChildByName('effect'), 'MedalUpgradeNext', () => {
                this._doLvup();
            });
        });
    }

    protected _checkLvupLimit() {
        let userLv: number = playerLogic.getPlayer().getLevel();
        let power: number = playerLogic.getPlayer().getPower();
        let msg: string = '';
        let result: boolean = true;
        if (power < this._nowCof.battlenumber) { msg = '战力不足'; result = false; }
        if (userLv < this._nowCof.playerlevel) { msg = '玩家等级不足'; result = false; }
        return { ret: result, msg: msg };
    }

    protected async _doLvup() {
        try {
            await medalLogic.medalLvupReq();
            bagLogic.costGood(this._nowCof.cost);
            this.refresh();
            EManager.emit(EName.onMedalLevelUp);
            playerLogic.getPlayer().setPowerDirty();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    // 勋章等级信息
    protected _updateLv() {
        this.lvArrow.active = !this._bMax;
        this.nextLv.active = !this._bMax;
        this._renderLvItem(this.nowLv, this._nowCof);
        if (this.nextLv.active) { this._renderLvItem(this.nextLv, this._nextCof); }
    }

    protected _renderLvItem(node: cc.Node, cof: medalconfigRow) {
        // label
        node.getChildByName('name').getComponent(cc.Label).string = cof.name;
        // icon
        let url: string = commonUtils.getPanelIconUrl('medal', cof.icon);
        loadUtils.loadSpriteFrame(url, node.getChildByName('icon').getComponent(cc.Sprite));
    }

    // 勋章加成
    protected _updateBuff() {
        this._renderMedalBuff(this.propBuff1, true);
        this._renderMedalBuff(this.propBuff2, false);
    }

    protected _renderMedalBuff(node: cc.Node, bFirst: boolean) {
        let now = bFirst ? this._nowCof.prop1 : this._nowCof.prop2;
        let nowProp = cm.getPropertyConfig(now[0]);

        node.getChildByName('desc').getComponent(cc.Label).string = nowProp.ProName;
        let value: string = nowProp.ProType > 0 ? `${now[1] * 100}%` : `${now[1]}`;
        node.getChildByName('now').getComponent(cc.Label).string = value;

        node.getChildByName('arrow').active = !this._bMax;
        let next = node.getChildByName('next');
        next.color = this._bMax ? this._getColor(mUpgradeColor.buff_max) : this._getColor(mUpgradeColor.buff_next);
        if (!this._bMax) {
            let nextProp = bFirst ? this._nextCof.prop1 : this._nextCof.prop2;
            let nextPropCof = cm.getPropertyConfig(nextProp[0])
            value = nextPropCof.ProType > 0 ? `${nextProp[1] * 100}%` : `${nextProp[1]}`;
            next.getComponent(cc.Label).string = value;
        } else {
            next.getComponent(cc.Label).string = 'MAX';
        }
    }

    protected _getColor(color: string) { return cc.Color.WHITE.fromHEX(color); }

    // 勋章晋升条件
    protected _updateCondition() {
        let user = playerLogic.getPlayer();
        this._renderConditonItem(this.condition1, user.getLevel(), this._nowCof.playerlevel, 'Lv.');
        this._renderConditonItem(this.condition2, user.getPower(), this._nowCof.battlenumber);
    }

    protected _renderConditonItem(node: cc.Node, now: number, next: number, ex: string = '') {
        let nowValue = node.getChildByName('now');
        let nextValue = node.getChildByName('next');

        nowValue.getComponent(cc.Label).string = ex + slib.BigNumberHelper.convertNumStr2UnitStr(now.toString(), 0, 0);
        if (this._bMax) {
            nextValue.getComponent(cc.Label).string = '---';
        } else {
            nextValue.getComponent(cc.Label).string = ex + slib.BigNumberHelper.convertNumStr2UnitStr(next.toString(), 0, 0);
        }

        let nowCol = now < next ? cc.Color.WHITE.fromHEX(mUpgradeColor.cond_less) : cc.Color.WHITE.fromHEX(mUpgradeColor.label_green);
        nowCol = this._bMax ? cc.Color.WHITE.fromHEX(mUpgradeColor.cond_now_max) : nowCol;
        nowValue.color = nowCol;
        nextValue.color = cc.Color.WHITE.fromHEX(mUpgradeColor.cond_next);
    }

    // 勋章晋升材料
    protected _updateMat() {

        this.upgradeMat.active = !this._bMax;
        this.matTip.active = !this._bMax && this._nowCof.cost;
        if (!this.upgradeMat.active) { return; }

        let refresh: boolean = false;
        let mat: number[][] = this._nowCof.cost || [];
        if (this.upgradeMat.childrenCount != mat.length) {
            this.upgradeMat.destroyAllChildren();
        } else {
            refresh = true;
        }

        for (let i = 0; i < mat.length; i++) {
            let tmp: cc.Node = null;
            if (refresh) {
                tmp = this.upgradeMat.children[i];
            } else {
                tmp = cc.instantiate(this.matItem);
                tmp.parent = this.upgradeMat;
            }

            this._renderMatItem(tmp, mat[i]);
        }
    }

    protected _renderMatItem(node: cc.Node, cost: number[]) {
        let good = node.getChildByName('good');
        let comp = good.getComponent(CommonLoader).loaderNode.getComponent(GoodCard);
        let vo = new GoodVO();
        vo.amt = 0;
        vo.propId = cost[0];
        let data = new Good(vo);
        comp.refresh(data);
        comp.registerOnGoodInfo();

        let has = node.getChildByName('layout').getChildByName('has');
        let num: number = bagLogic.getGood(cost[0]).getAmount();
        has.getComponent(cc.Label).string = slib.BigNumberHelper.convertNumStr2UnitStr(num.toString(), 0, 0);
        has.color = num < cost[1] ? cc.Color.RED : cc.Color.WHITE.fromHEX('ffffff');

        let need = node.getChildByName('layout').getChildByName('need');
        need.getComponent(cc.Label).string = '/' + slib.BigNumberHelper.convertNumStr2UnitStr(cost[1].toString(), 0, 0);
    }
}
