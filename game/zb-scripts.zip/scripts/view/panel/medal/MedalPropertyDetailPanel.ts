import loadUtils from "../../../utils/LoadUtils";
import commonUtils from "../../../utils/CommonUtils";
import bagLogic from "../../../logics/BagLogic";
import gm from "../../../manager/GameManager";
import MedalTechData from "../../../data/medal/MedalTechData";
import { PopupPanel } from "../BasePanel";
import cm from "../../../manager/ConfigManager";
import medalLogic from "../../../logics/MedalLogic";
import medalconfig from "../../../configs/medalconfig";

const { ccclass, property, menu } = cc._decorator;

let medalColor = {
    name: 'f9cf16',
    lock: 'ff4200',
    gray: '737d84',
    desc: 'cbbf7c',
    green: '38c531',
    max: 'ff8a00',
}

@ccclass
@menu("view/panel/medal/MedalPropertyDetailPanel")
export default class MedalPropertyDetailPanel extends PopupPanel {

    @property(cc.Node)
    prop_Bg: cc.Node = null;

    @property(cc.Node)
    prop_detail: cc.Node = null;

    @property(cc.Label)
    prop_title: cc.Label = null;

    @property(cc.Label)
    prop_lock: cc.Label = null;

    @property(cc.Sprite)
    prop_icon: cc.Sprite = null;

    @property(cc.Label)
    prop_nowValue: cc.Label = null;

    @property(cc.Label)
    prop_nextValue: cc.Label = null;

    @property(cc.Node)
    prop_buff: cc.Node = null;

    @property(cc.Node)
    prop_buff_item: cc.Node = null;

    @property(cc.Node)
    prop_cost: cc.Node = null;

    @property(cc.Material)
    normalMaterial: cc.Material = null;

    @property(cc.Material)
    grayMaterial: cc.Material = null;

    @property(cc.Label)
    upgradeLabel: cc.Label = null;

    @property(cc.Label)
    lockTip: cc.Label = null;

    @property(cc.Node)
    lockNode: cc.Node = null;

    @property(cc.Node)
    upgradeNode: cc.Node = null;

    @property(cc.Label)
    buffType: cc.Label = null;

    protected _tech: MedalTechData = null;
    protected _callback: Function = null;
    onInit(data: any) {
        super.onInit(data);
        if (data) {
            this._tech = data.medal;
            this._callback = data.callback;
        }
    }
    start() {
        super.start();
        this.refresh();
    }

    onLoad() {
        super.onLoad();
        this.prop_buff_item.parent = null;
    }
    onDestroy() {
        super.onDestroy();
        this.prop_buff_item.destroy();
    }

    protected refresh(action: boolean = false) {
        if (!this._tech) { return; }

        this._updatePropertyDetail(action);
        this._updatePropertyBuff(action);

        let canLvUp = this._tech.unlcokLvUp();
        this.upgradeNode.active = canLvUp && !this._tech.isComplete();
        this.lockNode.active = !canLvUp;
        if (canLvUp) {
            this._updatePropertyMat();
        } else {
            this.lockTip.string = this._tech.getLockTip();
        }

        let comp = this.prop_detail.getComponent(cc.Layout);
        if (comp) { comp.updateLayout(); }

        this.scheduleOnce(() => {
            this.prop_Bg.height = this.prop_detail.height + 25;
        }, 1 / 30);
    }

    protected onClickLvUp() {
        let mat = this._tech.getLevelUpMat();
        let ret = bagLogic.checkGoodCostResult([mat]);
        if (!ret.ret) { gm.toast(ret.msg); return; }



        this._doTechLvup();
    }

    protected async _doTechLvup() {
        try {
            await medalLogic.medalTreeNodeLvupReq(this._tech.id);
            let mat = this._tech.getLevelUpMat();
            bagLogic.costGood([mat]);
            this.refresh(true);
            if (this._callback) { this._callback(); }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    protected _getColor(colo: string) { return cc.Color.WHITE.fromHEX(colo); }

    // 科技属性信息
    protected _updatePropertyDetail(action: boolean = false) {

        let unlock = this._tech.isUnlock();
        let level: number = this._tech.level
        let max: number = this._tech.getMaxLv();

        this.prop_title.string = `${this._tech.getName()}`;
        this.prop_title.node.color = this._getColor(medalColor.name);
        this.prop_lock.node.active = !this._tech.unlcokLvUp() || level == max;
        if (this.prop_lock.node.active) {
            this.prop_lock.string = unlock ? '已满级' : '未解锁';
            this.prop_lock.node.color = unlock ? this._getColor(medalColor.max) : this._getColor(medalColor.lock);
            if (!medalLogic.isTreeUnlock(this._tech.getCof().type)) {
                this.prop_lock.string = '未解锁';
                this.prop_lock.node.color = this._getColor(medalColor.lock);
            }
        }

        let color = this._getColor(medalColor.gray);
        //color = unlock ? color : this._getColor(medalColor.gray);
        color = level >= max ? this._getColor(medalColor.green) : color;
        this.prop_nowValue.node.color = color;

        this.prop_nextValue.node.active = unlock && level < max;
        if (this.prop_nextValue.node.active) {
            this.prop_nextValue.string = `Lv.${level + 1}`;
            this.prop_nextValue.node.color = this._getColor(medalColor.green);

            this.prop_nowValue.string = `Lv.${level}>`;
        } else {
            this.prop_nowValue.string = `Lv.${level}`;
        }

        loadUtils.loadSpriteFrame(this._tech.getPropIconUrl(), this.prop_icon);
        let mat = (unlock && medalLogic.isTreeUnlock(this._tech.getCof().type)) ? this.normalMaterial : this.grayMaterial;
        this.prop_icon.setMaterial(0, mat);
        if (action) { commonUtils.playAnimation(this.prop_icon.node.getChildByName('effecticon'), 'Detaleffecticon'); }

        this.buffType.string = this._tech.getCof().desc;
        this.buffType.node.active = true;
    }

    // 科技属性的加成信息
    protected _updatePropertyBuff(action: boolean = false) {
        this.prop_buff.destroyAllChildren();

        let buffs: number[][] = [];
        buffs.push(this._tech.getProp1Buff());
        buffs.push(this._tech.getProp2Buff());

        for (let i = 0; i < buffs.length; i++) {
            let data = buffs[i];
            if (data && data.length == 3) {
                let tmp = cc.instantiate(this.prop_buff_item);
                tmp.parent = this.prop_buff;
                this._renderBuffItem(tmp, data);
                if (action) { commonUtils.playAnimation(tmp.getChildByName('effectinfo'), 'ItemlevelupGlow'); }
            }
        }
    }

    protected _renderBuffItem(node: cc.Node, data: number[]) {
        let propCof = cm.getPropertyConfig(data[0]);
        let url: string = commonUtils.getPropIconUrl(data[0]);
        loadUtils.loadSpriteFrame(url, node.getChildByName('icon').getComponent(cc.Sprite));

        node.getChildByName('name').getComponent(cc.Label).string = propCof.ProName;

        let layout = node.getChildByName('layout')

        let value: string = propCof.ProType > 0 ? `${data[1]}%` : `${data[1]}`;
        layout.getChildByName('now').getComponent(cc.Label).string = '+' + value;

        value = propCof.ProType > 0 ? `${data[2]}%` : `${data[2]}`;
        value = this._tech.isComplete() ? 'Max' : '+' + value;
        layout.getChildByName('next').getComponent(cc.Label).string = value;
        layout.getChildByName('next').active = this._tech.unlcokLvUp() && this._tech.isUnlock();
        layout.getChildByName('arrow').active = this._tech.unlcokLvUp() && this._tech.isUnlock();
    }

    // 科技属性升级消耗的材料
    protected _updatePropertyMat() {
        if (this._tech.isComplete()) { return; }
        let str = (!this._tech.isUnlock() && this._tech.unlcokLvUp()) ? '学 习' : '升 级';
        this.upgradeLabel.string = str;

        let data = this._tech.getLevelUpMat();
        let has = this.prop_cost.getChildByName('has').getComponent(cc.Label);
        let good = bagLogic.getGood(data[0]);
        has.string = slib.BigNumberHelper.convertNumStr2UnitStr(good.getAmount().toString(), 0, 0);
        let enough = good.getAmount() >= data[1];
        has.node.color = enough ? this._getColor('eafffe') : cc.Color.RED;

        let need = this.prop_cost.getChildByName('need').getComponent(cc.Label);
        need.string = '/' + slib.BigNumberHelper.convertNumStr2UnitStr(data[1].toString(), 0, 0);
    }
}