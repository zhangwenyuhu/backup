import MedalTechData from "../../../data/medal/MedalTechData";
import { PopupPanel } from "../BasePanel";
import cm from "../../../manager/ConfigManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/medal/MedalResetPanel")
export default class MedalResetPanel extends PopupPanel {

    @property(cc.Label)
    medalTreeName: cc.Label = null;

    protected _type: number = 1;
    protected _callback: Function = null;
    onInit(data: any) {
        super.onInit(data);
        if (data) {
            this._type = data.type;
            this._callback = data.callback;
        }
    }
    start() {
        super.start();

        let cof = cm.getMedalTechInfoConfig(this._type);
        this.medalTreeName.string = cof.name;
    }

    protected onClickOk() {
        if (this._callback) { this._callback(); }
        this.closePanel();
    }

}