import MedalModule from "./MedalModule";
import { MedalTechTab } from "../../../utils/DefineUtils";
import commonUtils from "../../../utils/CommonUtils";
import loadUtils from "../../../utils/LoadUtils";
import medalLogic, { MedalResNode } from "../../../logics/MedalLogic";
import MedalTechData from "../../../data/medal/MedalTechData";
import CommonLoader from "../../common/CommonLoader";
import MedalProperTy from "../../component/Medal/MedalProperty";
import cm from "../../../manager/ConfigManager";
import gm from "../../../manager/GameManager";
import List from "../../common/List";
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/medal/MedalTech")
export default abstract class MedalTech extends MedalModule {

    @property(cc.Node)
    medalTab: cc.Node = null;

    @property(cc.Node)
    propertyView: cc.Node = null;

    @property(cc.Node)
    totalTech: cc.Node = null;

    @property(cc.Node)
    techResearch: cc.Node = null;

    @property(cc.Node)
    btnChange: cc.Node = null;

    @property(cc.Node)
    studyLayer: cc.Node = null;

    @property(cc.Label)
    btnMoreBuff: cc.Label = null;

    @property(cc.Node)
    medalBuff: cc.Node = null;

    @property(cc.Node)
    medalPropItem: cc.Node = null;

    @property(cc.Label)
    medalCostTech: cc.Label = null;

    @property(cc.Node)
    lockNode: cc.Node = null;

    @property(cc.Node)
    unlockNextNode: cc.Node = null;

    @property(cc.Node)
    btnReset: cc.Node = null;

    @property(cc.Vec2)
    child1Pos: cc.Vec2[] = [];

    @property(cc.Vec2)
    child2Pos: cc.Vec2[] = [];

    @property(cc.Vec2)
    child3Pos: cc.Vec2[] = [];

    @property(cc.Vec2)
    child4Pos: cc.Vec2[] = [];

    protected _medalTab: MedalTechTab = MedalTechTab.Total;
    protected _medalDetail: boolean = true;
    protected _techTree: { node: cc.Node, data: MedalTechData }[] = [];
    protected _treeBuffs: number[][] = [];

    private _disY: number = 140;
    private _wid: number = 120;
    onLoad() {
        this.medalPropItem.parent = null;
    }
    onDestroy() {
        this.medalPropItem.destroy();
    }
    onEnable() { }
    onDisable() { }
    start() { }

    public refresh() {
        this._updateTab();
        this._updateTechResearch();
        this._updateTotalView();
        this._updateDesc();
    }

    protected _showPropertyDetail(id: number) {
        let data = medalLogic.getMedalTechData(id);
        if (!data) { return; }

        gcc.core.showLayer('prefabs/panel/medal/MedalPropertyDetailPanel', {
            data: {
                medal: data,
                callback: () => {
                    this._updateTab();
                    this._refreshTechTree();
                    this._updateDesc();
                }
            }
        })
    }

    // 战略研习
    protected _updateTechResearch() {
        this.techResearch.active = this._medalTab > MedalTechTab.Total;
        if (this.techResearch.active) {
            this._initTechTree();
            this._refreshTechTree();
        }
    }

    // 初始化战略树节点
    protected _initTechTree() {
        this._techTree = [];
        this.studyLayer.destroyAllChildren();

        let data = medalLogic.getMedalTechTree(this._medalTab);
        for (let i = 0; i < data.length; i++) {
            let pos = this._getOriginPos();

            let temp = cc.instantiate(this.medalPropItem);
            temp.parent = this.studyLayer;
            temp.position = pos;

            let techId = data[i].techId;
            let techData = medalLogic.getMedalTechData(techId);
            this._techTree.push({ node: temp, data: techData });

            temp.name = techData.getName();
            temp.off('click');
            temp.on('click', () => { this._showPropertyDetail(data[i].techId); })

            this._initTechChildItem(temp, medalLogic.getMedalTechTreeNode(data[i].techId), pos);
        }
    }

    // 刷新战略树节点
    protected _refreshTechTree() {
        let bottom = this._getOriginPos();
        this.studyLayer.height = Math.abs(bottom.y);
        for (let i = 0; i < this._techTree.length; i++) {
            let data = this._techTree[i];
            let comp = data.node.getComponent(CommonLoader).loaderNode.getComponent(MedalProperTy);
            comp.refresh(data.data);
        }
    }

    protected _getOriginPos() {
        if (this._techTree.length <= 0) { return cc.v2(0, -100); }

        let minY: number = -100;
        for (let i = 0; i < this._techTree.length; i++) {
            let data = this._techTree[i];
            if (data && data.node && cc.isValid(data.node)) {
                if (minY > data.node.y) {
                    minY = data.node.y;
                }
            }
        }
        return cc.v2(0, minY - this._disY);
    }

    // 创建战略树的子节点
    protected _initTechChildItem(node: cc.Node, data: MedalResNode, parentPos: cc.Vec2) {
        if (!data.child) { return; }
        let num: number = data.child.length;
        if (num <= 0) { return; }

        let posArr = this._getChildPos(num, parentPos);
        for (let i = 0; i < num; i++) {
            if (posArr[i]) {
                let temp = cc.instantiate(this.medalPropItem);
                temp.parent = this.studyLayer;
                temp.position = posArr[i];

                let techId = data.child[i].techId;
                let techData = medalLogic.getMedalTechData(techId);
                this._techTree.push({ node: temp, data: techData });

                temp.name = techData.getName();
                temp.off('click');
                temp.on('click', () => { this._showPropertyDetail(techId); })
                this._initTechChildItem(temp, data.child[i], temp.position);
            }
        }
    }

    protected _getChildPos(num: number, pos: cc.Vec2) {
        if (num == 1) {
            //return [cc.v2(pos.x, pos.y - this._disY)]
            let posArr = this.child1Pos.map((v, i, a) => { return cc.v2(v.x + pos.x, v.y + pos.y) });
            return posArr;
        } else if (num == 2) {
            /*return [
                cc.v2(pos.x - this._wid / 2, pos.y - this._disY),
                cc.v2(pos.x + this._wid / 2, pos.y - this._disY)
            ];*/
            let posArr = this.child2Pos.map((v, i, a) => { return cc.v2(v.x + pos.x, v.y + pos.y) });
            return posArr;
        } else if (num == 3) {
            /*return [
                cc.v2(pos.x - this._wid, pos.y - this._disY),
                cc.v2(pos.x, pos.y - this._disY),
                cc.v2(pos.x + this._wid, pos.y - this._disY)
            ];*/
            let posArr = this.child3Pos.map((v, i, a) => { return cc.v2(v.x + pos.x, v.y + pos.y) });
            return posArr;
        } else if (num == 4) {
            /*return [
                cc.v2(pos.x - this._wid * (3 / 2), pos.y - this._disY),
                cc.v2(pos.x - this._wid / 2, pos.y - this._disY),
                cc.v2(pos.x + this._wid / 2, pos.y - this._disY),
                cc.v2(pos.x + this._wid * (3 / 2), pos.y - this._disY)
            ];*/
            let posArr = this.child4Pos.map((v, i, a) => { return cc.v2(v.x + pos.x, v.y + pos.y) });
            return posArr;
        }
        return [];
    }

    // 研习总览
    protected _updateTotalView() {
        let showTotal: boolean = this._medalTab == MedalTechTab.Total;
        this.propertyView.active = showTotal;
        this.totalTech.active = showTotal;
        if (showTotal) {
            let buffs = medalLogic.getMedalTreeBuff();
            this.btnChange.active = true;
            if (buffs.length <= 3) {
                this._medalDetail = true;
                this.btnChange.active = false;
            }

            this.totalTech.active = this._medalDetail;
            let comp = this.propertyView.getComponent(cc.Widget);
            comp.top = this._medalDetail ? 450 : 70;
            comp.updateAlignment();

            for (let i = 0; i < this.propertyView.childrenCount; i++) {
                let child = this.propertyView.children[i];
                let comp = child.getComponent(cc.Widget);
                if (comp) { comp.updateAlignment(); }
            }
        }

        this._updateTreeBuff();
        if (this.totalTech.active) {
            this._updateTotalMedalTech();
        }
        this.btnMoreBuff.string = this._medalDetail ? '更多' : '返回';

    }

    // 更新总览中不同研习数据
    protected _updateTotalMedalTech() {
        for (let i = MedalTechTab.Base; i <= MedalTechTab.Master; i++) {
            let child = this.totalTech.getChildByName(`item${i}`);
            if (child) {
                this._renderMedalTechItem(child, i);
            }
        }
    }

    // 战略树总览信息
    protected _renderMedalTechItem(node: cc.Node, type: MedalTechTab) {
        let lv: number = medalLogic.getMedalTreeCostTech(type);
        let total: number = medalLogic.getMedalTreeMaxTech(type);

        let cof = cm.getMedalTechInfoConfig(type);
        node.getChildByName('name').getComponent(cc.Label).string = cof.name;

        let url = commonUtils.getPanelIconUrl('medal', `medal_circle_icon${type - 1}`);
        loadUtils.loadSpriteFrame(url, node.getChildByName('icon').getComponent(cc.Sprite));

        let prog = node.getChildByName('prog').getComponent(cc.ProgressBar);
        prog.progress = lv / total;

        let lvNode = node.getChildByName('value').getChildByName('now');
        lvNode.getComponent(cc.Label).string = `${lv}/`;

        let totalNode = node.getChildByName('value').getChildByName('need');
        totalNode.getComponent(cc.Label).string = `${total}`;
    }

    protected _changeTab(tab: MedalTechTab) {
        if (this._medalTab == tab) { return; }
        this._medalTab = tab;
        //this.studyLayer.y = 0;
        this.studyLayer.parent.parent.getComponent(cc.ScrollView).scrollToTop();
        this.refresh();
    }

    protected _updateTab() {
        for (let i = MedalTechTab.Total; i <= MedalTechTab.Master; i++) {
            let child = this.medalTab.getChildByName(`item${i + 1}`);
            this._renderTabItem(child, i, i == this._medalTab);

            child.off('click');
            child.on('click', () => { this._changeTab(i); })
        }
    }

    protected _renderTabItem(node: cc.Node, type: number, focus: boolean) {

        let lock: boolean = false;
        if (type > MedalTechTab.Total) { lock = !medalLogic.isTreeUnlock(type); }
        let iconName: string = 'medal_tab_0';
        iconName = lock ? 'medal_tab_2' : iconName;
        iconName = focus ? 'medal_tab_1' : iconName;
        let url: string = commonUtils.getPanelIconUrl('medal', iconName);
        loadUtils.loadSpriteFrame(url, node.getComponent(cc.Sprite));

        node.getChildByName('lock').active = lock;
        let cof = medalLogic.getTechInfoCof(type);
        let name = cof ? cof.name : '研习总览';
        node.getChildByName('name').getComponent(cc.Label).string = name;

        let color = focus ? '6a4806' : 'f2e3dd';
        color = lock ? '71706f' : color;
        color = focus ? '6a4806' : color;
        node.getChildByName('name').color = cc.Color.WHITE.fromHEX(color);
    }

    protected onClickChange() {
        this._medalDetail = !this._medalDetail;
        this._updateTotalView();
    }

    protected onClickReset() {
        gcc.core.showLayer('prefabs/panel/medal/MedalResetPanel', {
            data: {
                type: this._medalTab,
                callback: () => {
                    this._doResetMedal();
                }
            }
        })
    }

    protected async _doResetMedal() {
        try {
            await medalLogic.resetMedalTree(this._medalTab);
            this.refresh();
            this._refreshTechTree();
            this._updateDesc();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    protected _updateDesc() {
        if (this._medalTab > MedalTechTab.Total) {
            let num: number = medalLogic.getMedalTreeCostTech(this._medalTab);
            this.medalCostTech.string = `${num}`;
            this.btnReset.active = num > 0;

            let unlock = medalLogic.isTreeUnlock(this._medalTab);
            let nextUnlock = medalLogic.isTreeUnlock(this._medalTab + 1);
            this.lockNode.active = !unlock;
            this.unlockNextNode.active = unlock && !nextUnlock;
            if (this.lockNode.active) {
                let data = medalLogic.getMedalTreeUnlockData(this._medalTab);
                let cof = cm.getMedalTechInfoConfig(data[0]);

                this.lockNode.getChildByName('name').getComponent(cc.Label).string = cof.name;
                this.lockNode.getChildByName('num').getComponent(cc.Label).string = `${data[1]}`;
            }
            if (this.unlockNextNode.active) {
                let data = medalLogic.getMedalTreeUnlockData(this._medalTab + 1);

                let nextCof = cm.getMedalTechInfoConfig(this._medalTab + 1)
                this.unlockNextNode.getChildByName('name').getComponent(cc.Label).string = nextCof.name;
                this.unlockNextNode.getChildByName('num').getComponent(cc.Label).string = `${data[1]}`;
            }
        }
    }

    // 更新战略树的加成信息
    protected _updateTreeBuff() {
        this._treeBuffs = medalLogic.getMedalTreeBuff();
        let num: number = this._medalDetail ? 3 : this._treeBuffs.length;
        num = num > this._treeBuffs.length ? this._treeBuffs.length : num;
        this.medalBuff.getComponent(List).getComponent(cc.Widget).updateAlignment();
        this.medalBuff.getComponent(List).numItems = num;
    }

    protected onRenderItem(node: cc.Node, index: number) {
        let data = this._treeBuffs[index];
        let propId: number = data[0];
        let cof = cm.getPropertyConfig(propId);
        let techCof = cm.getMedalTechConfig(data[3]);
        node.getChildByName('name').getComponent(cc.Label).string = techCof.desc + cof.ProName;

        let value: string = cof.ProType > 0 ? `${Math.floor(data[1] * 100)}%` : `${data[1]}`;
        node.getChildByName('value').getComponent(cc.Label).string = value;
    }
}
