import MedalModule from "./MedalModule";
import List from "../../common/List";
import medalstagerewardconfig, { medalstagerewardconfigRow } from "../../../configs/medalstagerewardconfig";
import cm from "../../../manager/ConfigManager";
import medalLogic from "../../../logics/MedalLogic";
import missionLogic from "../../../logics/MissionLogic";
import gm from "../../../manager/GameManager";
import gotoUtils from "../../../utils/GotoUtils";
import { NavigateTabIndex } from "../../common/NavigateButton";
import BasePanel from "../BasePanel";
import loadUtils from "../../../utils/LoadUtils";
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/medal/MedalReward")
export default abstract class MedalReward extends MedalModule {

    @property(List)
    medalPassRewardView: List = null;

    protected _passRewardInfo: { id: number, recv: boolean }[] = [];
    onLoad() {

    }
    onDestroy() {

    }
    onEnable() { }
    onDisable() { }
    start() { }

    public refresh() {
        this._updateListData();
        this.medalPassRewardView.numItems = this._passRewardInfo.length;
    }

    protected _updateListData() {
        this._passRewardInfo = [];
        for (let i = 0; i < medalstagerewardconfig.length; i++) {
            let cof = medalstagerewardconfig[i];
            this._passRewardInfo.push({ id: cof.ID, recv: medalLogic.isMedalTaskRecv(cof.ID) });
        }
        this._passRewardInfo.sort((a, b) => {
            let aRecv = a.recv ? 1 : 0;
            let bRecv = b.recv ? 1 : 0;
            if (aRecv == bRecv) {
                return a.id - b.id;
            } else {
                return aRecv - bRecv;
            }
        })
    }

    protected onItemRender(node: cc.Node, index: string) {
        let name = node.getChildByName('layout').getChildByName('name');
        let num = node.getChildByName('reward').getChildByName('num');

        let data = this._passRewardInfo[index];
        let cof: medalstagerewardconfigRow = medalstagerewardconfig[data.id - 1];
        let stageCof = cm.getStageConfig(cof.stage);
        num.getComponent(cc.Label).string = `${cof.reward[1]}`;
        name.getComponent(cc.Label).string = stageCof.HouseName;

        let recvied: boolean = medalLogic.isMedalTaskRecv(cof.ID);
        let canRecv: boolean = missionLogic.getCurrentMission().getStageId() > cof.stage;
        let btnRecv = node.getChildByName('btnRecv');
        let btnGo = node.getChildByName('btnGo');
        btnGo.active = !canRecv;
        btnRecv.active = canRecv;
        btnRecv.getComponent(cc.Button).interactable = !recvied;
        let label: string = recvied ? '已领取' : '领 取';
        btnRecv.getComponentInChildren(cc.Label).string = label;
        if (btnGo.active) {
            btnGo.off('click');
            btnGo.on('click', () => { this._gogogo(); })
        }
        if (btnRecv.active) {
            btnRecv.off('click');
            btnRecv.on('click', async () => { this._recvMedalPassReward(cof.ID); })
        }

        let icon = node.getChildByName('icon').getComponent(cc.Sprite);
        let iconName: string = `build_icon_${stageCof.CityID}`;
        let url: string = `textures/ui/panel/purify/purifybuild/` + iconName;
        loadUtils.loadSpriteFrame(url, icon);
    }

    protected _gogogo() {
        BasePanel.closePanel('MedalMainPanel');
        gotoUtils.gotoView(NavigateTabIndex.Battle);
    }

    protected async _recvMedalPassReward(id: number) {
        try {
            await medalLogic.recvMedalTaskReq(id);
            this.refresh();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}
