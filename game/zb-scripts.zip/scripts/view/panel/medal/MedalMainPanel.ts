import { PopupPanel } from "../BasePanel";
import MedalModule from "./MedalModule";
import loadUtils from "../../../utils/LoadUtils";
import medalLogic from "../../../logics/MedalLogic";
import { RefreshLabel } from "../../../decorator/RefreshDecorator";
import Good from "../../../data/card/Good";
import bagLogic from "../../../logics/BagLogic";
import goodsConfig from "../../../configs/goodsConfig";
import tipUtils from "../../../utils/TipUtils";

const { ccclass, property, menu } = cc._decorator;

export enum MedalTab {
    Upgrade = 1,
    Tech = 2,
    Reward = 3,
}

export type MedalModel = {
    name: string,
    prefab: string,
    type: number,
}

let medals: { [key: number]: MedalModel } = {
    1: {
        name: '净化勋章',
        prefab: 'MedalUpgrade',
        type: MedalTab.Upgrade,
    },
    2: {
        name: '净化战略',
        prefab: 'MedalTech',
        type: MedalTab.Tech,
    },
    3: {
        name: '净化奖励',
        prefab: 'MedalReward',
        type: MedalTab.Reward,
    }
}

@ccclass
@menu("view/panel/medal/MedalMainPanel")
export default class MedalMainPanel extends PopupPanel {

    @property(cc.Node)
    medalButtons: cc.Node = null;

    @property(cc.Node)
    medalTitle: cc.Node = null;

    @property(cc.Node)
    module: cc.Node = null;

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => {
            return bagLogic.getGood(Good.GoodId.MedalTech)
        },
        getValue: (good: Good) => {
            let amount = slib.BigNumberHelper.convertNumStr2UnitStr(good.getAmount().toString(), 0, 0);
            return amount;
        }
    })
    @property(cc.Label)
    medalTechNum: cc.Label = null;

    @property(cc.Node)
    tabBg: cc.Node = null;

    @property(cc.Prefab)
    prefabs: cc.Prefab[] = [];

    protected _medalTab: MedalTab = MedalTab.Upgrade;
    protected _prefabUrl: string = '';
    protected async _preloadRes() {
        await super._preloadRes();

        await medalLogic.medalTechReq();
        await medalLogic.medalTaskReq();
    }

    onLoad() {
        super.onLoad();

    }

    onDestroy() {
        super.onDestroy();

    }

    start() {
        super.start();

        this.changeTab(this._medalTab, true);
    }

    onClickTip(event: cc.Event.EventTouch, index: string) {
        let config = goodsConfig.find(a => a.parameterid == Number(index));
        if (config) {
            tipUtils.showTip(event.target, config.des);
        }
    }

    protected changeTab(tab: MedalTab, force: boolean = false) {
        if (this._medalTab == tab && !force) { return; }

        this._medalTab = tab;
        this.updateMedalButtons();
        this.medalTitle.getComponent(cc.Label).string = medals[tab].name;
        this._showMedalView(this._medalTab)
        this.tabBg.active = tab == MedalTab.Tech;
    }

    protected updateMedalButtons() {
        for (let i = MedalTab.Upgrade; i <= MedalTab.Reward; i++) {
            let child = this.medalButtons.getChildByName(`medal${i}`);
            if (!child) { continue; }

            this._renderMedalButton(child, i == this._medalTab);
            child.off('click');
            child.on('click', () => {
                this.changeTab(i);
            })
        }
    }

    protected _renderMedalButton(node: cc.Node, focus: boolean) {
        node.getChildByName('mask').active = !focus;
        node.width = focus ? 150 : 125;
        node.x = focus ? -15 : 0;
    }

    protected async _showMedalView(type: MedalTab) {
        let advance: cc.Node;
        let module = medals[type]
        if (!module.prefab) { return; }
        if (this._prefabUrl == module.prefab) {
            advance = this.module.children[0];
        } else {
            let url: string = this._getModulePrefabUrl(type);
            let prefab = cc.instantiate(this.prefabs[type - 1]);
            //let prefab = cc.loader.getRes(url, cc.Prefab);
            //if (!prefab) { prefab = await loadUtils.loadRes(url, cc.Prefab) as cc.Prefab; }

            this.module.active = true;
            this.module.getComponent(cc.Widget).updateAlignment();
            this.module.destroyAllChildren();

            advance = cc.instantiate(prefab) as cc.Node;
            advance.setContentSize(this.module.getContentSize());
            advance.position = cc.v2();
            advance.parent = this.module;
            this._prefabUrl = module.prefab;
        }
        let comp = advance.getComponent(MedalModule);
        comp.init(type);
        comp.refresh();
    }

    protected _getModulePrefabUrl(type: MedalTab) {
        return `prefabs/panel/medal/module/${medals[type].prefab}`;
    }
}
