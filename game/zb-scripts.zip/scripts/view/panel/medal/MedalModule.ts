
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/medal/MedalModule")
export default abstract class MedalModule extends cc.Component {

    protected _index: number = 0;
    onLoad() { }
    onDestroy() { }
    onEnable() { }
    onDisable() { }
    start() { }

    public init(index: number) {
        this._index = index;
    }
    public refresh() { }
}
