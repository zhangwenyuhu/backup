import {PopupPanel} from "../BasePanel";
import List from "../../common/List";
import {ExchangeItem} from "../../../data/activity/actconfig/ExchangeActConfig";
import EManager, {EName} from "../../../manager/EventManager";
import CommonLoader from "../../common/CommonLoader";
import ActivityExchangePanel from "../activity/ActivityExchangePanel";
import gm from "../../../manager/GameManager";
import Equip from "../../../data/card/Equip";
import ActivityEquipChoose from "../../component/Activity/ActivityEquipChoose";
import CardChooseLockItem from "../../widget/card/CardChooseLockItem";
import {CardSelect} from "../../widget/card/CardSelectItem";
import equipLevelConfig from "../../../configs/equipLevelConfig";
import cm from "../../../manager/ConfigManager";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/exchange/ExchangeChooseEquipPanel")
export default class ExchangeChooseEquipPanel extends PopupPanel {

    @property(CommonLoader)
    equipChoose: CommonLoader = null;

    @property(cc.RichText)
    tip: cc.RichText = null;

    @property(List)
    list: List = null;

    protected _exchangeItem: ExchangeItem = null;
    protected _chooseFunc: Function = null;
    protected _equipList: Equip[] = [];
    protected _originEquip: Equip = null;
    protected _selectedEquip: Equip = null;
    protected _unSelectEquip: Equip = null;

    protected _originColor = "#2A3D36";
    protected _textTemplate = "<b><color=Color>Text</color></b>";
    protected _textTemplate2 = "<b><color=Color><outline color=#013956 width=2>Text</outline></color></b>";

    onInit(data: {
        exchangeItem: ExchangeItem,
        selectedEquip: Equip,
        chooseFunc: Function
    }) {
        super.onInit(data);
        this._exchangeItem = data.exchangeItem;
        this._originEquip = data.selectedEquip;
        this._selectedEquip = data.selectedEquip;
        this._chooseFunc = data.chooseFunc;
    }

    start() {
        super.start();
        this._equipList = this.getEquips();
        this._showSelectEquip();
        this.tip.string = this._getText();
        this.scheduleOnce(() => {
            this.list.numItems = this._equipList.length;
        });
    }

    protected _getText() {
        let text = "";
        if (this._exchangeItem.getId() == 30) {
            if (this._exchangeItem.getRank() == 0) {
                text += this._getRichTextContent(this._originColor, "可放入所有装备");
            } else {
                text += this._getRichTextContent(this._originColor, "可放入");
                let equipCfg = equipLevelConfig.find(a => a.Id == this._exchangeItem.getRank());
                text += this._getRichTextContent(equipCfg.RankColor, equipCfg.RankName, true);
                text += this._getRichTextContent(this._originColor, "装备");
            }
        } else if (this._exchangeItem.getId() > 30000) {
            let equipCfg = cm.getEquipConfig(this._exchangeItem.getId());
            text += this._getRichTextContent(this._originColor, `可放入${equipCfg.Name}`);
        }

        return text;
    }

    protected _getRichTextContent(color: string, text, useTemplate2: boolean = false) {
        let template = useTemplate2 ? this._textTemplate2 : this._textTemplate;
        let content = template.replace('Color', color);
        content = content.replace('Text', text);
        return content;
    }

    getEquips() {
        let equips = this._exchangeItem.getEquips();
        equips.sort(this._sortEquip.bind(this));
        return equips;
    }

    protected _sortEquip(a: Equip, b: Equip) {
        let aUsed = a != this._originEquip && ActivityExchangePanel.selectedEquips.indexOf(a) != -1 ? 1 : 0;
        let bUsed = b != this._originEquip && ActivityExchangePanel.selectedEquips.indexOf(b) != -1 ? 1 : 0;
        if (aUsed != bUsed) {
            return aUsed - bUsed;
        }
        let aRank = a.getRank();
        let bRank = b.getRank();
        if (aRank != bRank) {
            return aRank - bRank;
        }
        let aStar = a.getStar();
        let bStar = b.getStar();
        if (aStar != bStar) {
            return aStar - bStar;
        }

        return a.getIndex() - b.getIndex();
    }

    protected _showSelectEquip() {
        this.equipChoose.loaderNode.getComponent(ActivityEquipChoose).refresh({exchangeItem: this._exchangeItem, add: true});
        if (this._selectedEquip) {
            this.equipChoose.loaderNode.getComponent(ActivityEquipChoose).showEquip(this._selectedEquip);
        }
    }

    onLoad() {
        super.onLoad();
        let listener = EManager.addEvent(EName.onExchangeChooseCard, (equip: Equip) => {
            this._showSelectEquip();
        });
        this._eventListeners.push(listener);
    }

    onHeroRender(item: cc.Node, index: number) {
        let equip = this._equipList[index];
        let comp = item.getComponent(CardChooseLockItem);
        comp.checkLockOrUsedCallback = (cardSelect: CardSelect) => {
            if (!this._originEquip || this._originEquip != cardSelect.card) {
                if (ActivityExchangePanel.selectedEquips.indexOf((cardSelect.card as Equip)) != -1) {
                    return { result: 2, message: stringConfigMap.key_exchange_has_equip.Value };
                }
            }
            if (this._selectedEquip && cardSelect.card != this._selectedEquip) {
                return { result: 1, message: stringConfigMap.key_exchange_has_choose_equip.Value };
            }
            return { result: 0, message: null };
        };
        comp.init(equip, this._selectedEquip && this._selectedEquip == equip );

        let func = CardChooseLockItem.prototype.onToggleSelect;
        comp.onToggleSelect = () => {
            if (!comp.cardSelect.isSelect) {
                if (!this._selectedEquip) {
                    if (this._originEquip == comp.cardSelect.card || ActivityExchangePanel.selectedEquips.indexOf((comp.cardSelect.card as Equip)) == -1) {
                        this._selectedEquip = comp.cardSelect.card as Equip;
                        EManager.emit(EName.onExchangeChooseCard, this._selectedEquip);
                    }
                }
            } else {
                if (this._selectedEquip == comp.cardSelect.card) {
                    this._unSelectEquip = this._selectedEquip;
                    this._selectedEquip = null;
                    EManager.emit(EName.onExchangeChooseCard, null);
                }
            }
            func.call(comp);
            EManager.emit(EName.onUpdateTroopCard);
        }
    }

    onChoose() {
        if (!this._selectedEquip) {
            gm.dialog({
                content: stringConfigMap.key_exchange_no_equip_put.Value, confirm: () => {
                    this._doChoose();
                }
            });
        } else {
            this._doChoose();
        }
    }

    protected _doChoose() {
        if (this._chooseFunc) {
            this._chooseFunc(this._selectedEquip);
        }
        if (this._selectedEquip) {
            if (ActivityExchangePanel.selectedEquips.indexOf(this._selectedEquip) == -1) {
                ActivityExchangePanel.selectedEquips.push(this._selectedEquip);
            }
        } else if (this._unSelectEquip) {
            ActivityExchangePanel.selectedEquips.remove(this._unSelectEquip);
        }
        this.closePanel();
    }

}
