import {PopupPanel} from "../BasePanel";
import List from "../../common/List";
import {ExchangeItem} from "../../../data/activity/actconfig/ExchangeActConfig";
import Hero from "../../../data/card/Hero";
import {stringConfigMap} from "../../../configs/stringConfig";
import EManager, {EName} from "../../../manager/EventManager";
import CommonLoader from "../../common/CommonLoader";
import ActivityHeroChoose from "../../component/Activity/ActivityHeroChoose";
import ActivityExchangePanel from "../activity/ActivityExchangePanel";
import heroConfig from "../../../configs/heroConfig";
import heroRankConfig from "../../../configs/heroRankConfig";
import gm from "../../../manager/GameManager";
import CardChooseLockItem from "../../widget/card/CardChooseLockItem";
import {CardSelect} from "../../widget/card/CardSelectItem";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/exchange/ExchangeChoosePanel")
export default class ExchangeChoosePanel extends PopupPanel {

    @property(CommonLoader)
    heroChoose: CommonLoader = null;

    @property(cc.RichText)
    tip: cc.RichText = null;

    @property(List)
    list: List = null;

    protected _exchangeItem: ExchangeItem = null;
    protected _chooseFunc: Function = null;
    protected _heroList: Hero[] = [];
    protected _originHero: Hero = null;
    protected _selectedHero: Hero = null;
    protected _filterIndex = Hero.Faction.All;
    protected _unSelectHero: Hero = null;

    protected _originColor = "#2A3D36";
    protected _textTemplate = "<b><color=Color>Text</color></b>";
    protected _textTemplate2 = "<b><color=Color><outline color=#013956 width=2>Text</outline></color></b>";

    onInit(data: {
        exchangeItem: ExchangeItem,
        selectedHero: Hero,
        chooseFunc: Function
    }) {
        super.onInit(data);
        this._exchangeItem = data.exchangeItem;
        this._originHero = data.selectedHero;
        this._selectedHero = data.selectedHero;
        this._chooseFunc = data.chooseFunc;
    }

    start() {
        super.start();
        this._heroList = this.getHeroes();
        this._showSelectHero();
        this.tip.string = this._getText();
        this.scheduleOnce(() => {
            this.list.numItems = this._heroList.length;
        });
    }

    protected _getText() {
        let text = "";
        if (this._exchangeItem.getId() <= 6) {
            if (this._exchangeItem.getId() == 0) {
                text += this._getRichTextContent(this._originColor, "可放入所有联盟");
            } else {
                let faction = stringConfigMap[`key_faction_${this._exchangeItem.getId()}`].Value;
                text += this._getRichTextContent(this._originColor, `可放入${faction}联盟`);
            }
        } else if (this._exchangeItem.getId() > 20000 && this._exchangeItem.getId() < 30000) {
            let heroCfg = heroConfig.find(a => a.Id == this._exchangeItem.getId());
            let faction = stringConfigMap[`key_faction_${heroCfg.Faction}`].Value;
            text += this._getRichTextContent(this._originColor, `可放入${faction}联盟`);
        }
        if (this._exchangeItem.getRank() == 0) {
            text += this._getRichTextContent(this._originColor, "所有英雄");
        } else {
            let rankCfg = heroRankConfig[this._exchangeItem.getRank() - 1];
            text += this._getRichTextContent(rankCfg.RankColor, rankCfg.RankName, true);
            text += this._getRichTextContent(this._originColor, "英雄");
        }

        return text;
    }

    protected _getRichTextContent(color: string, text, useTemplate2: boolean = false) {
        let template = useTemplate2 ? this._textTemplate2 : this._textTemplate;
        let content = template.replace('Color', color);
        content = content.replace('Text', text);
        return content;
    }

    getHeroes() {
        let heroes = this._exchangeItem.getHeroes();
        heroes.sort(this._sortHero.bind(this));
        return heroes;
    }

    protected _sortHero(a: Hero, b: Hero) {
        let aUsed = a != this._originHero && ActivityExchangePanel.selectedHeroes.indexOf(a) != -1 ? 1 : 0;
        let bUsed = b != this._originHero && ActivityExchangePanel.selectedHeroes.indexOf(b) != -1 ? 1 : 0;
        if (aUsed != bUsed) {
            return aUsed - bUsed;
        }
        let aRank = a.getRank();
        let bRank = b.getRank();
        if (aRank != bRank) {
            return aRank - bRank;
        }
        let aLevel = a.getLevel();
        let bLevel = b.getLevel();
        if (aLevel != bLevel) {
            return aLevel - bLevel;
        }
        return a.getQuality() - b.getQuality();
    }

    protected _showSelectHero() {
        this.heroChoose.loaderNode.getComponent(ActivityHeroChoose).refresh({exchangeItem: this._exchangeItem, add: true});
        if (this._selectedHero) {
            this.heroChoose.loaderNode.getComponent(ActivityHeroChoose).showHero(this._selectedHero);
        }
    }

    onLoad() {
        super.onLoad();
        let listener = EManager.addEvent(EName.onExchangeChooseCard, (hero: Hero) => {
            this._showSelectHero();
        });
        this._eventListeners.push(listener);
    }

    onHeroRender(item: cc.Node, index: number) {
        let hero = this._heroList[index];
        let comp = item.getComponent(CardChooseLockItem);
        comp.checkLockOrUsedCallback = (cardSelect: CardSelect) => {
            if ((cardSelect.card as Hero).isLock()) {
                return { result: 1, message: stringConfigMap.key_hero_locked.Value };
            }
            if (!this._originHero || this._originHero != (cardSelect.card as Hero)) {
                if (ActivityExchangePanel.selectedHeroes.indexOf((cardSelect.card as Hero)) != -1) {
                    return { result: 2, message: stringConfigMap.key_exchange_has_hero.Value };
                }
            }
            if (this._selectedHero && (cardSelect.card as Hero) != this._selectedHero) {
                return { result: 1, message: stringConfigMap.key_exchange_has_choose_hero.Value };
            }
            return { result: 0, message: null };
        };
        comp.init(hero, this._selectedHero && this._selectedHero == hero );

        let func = CardChooseLockItem.prototype.onToggleSelect;
        comp.onToggleSelect = () => {
            if (!comp.cardSelect.isSelect) {
                if (!this._selectedHero) {
                    if (this._originHero == comp.cardSelect.card || ActivityExchangePanel.selectedHeroes.indexOf((comp.cardSelect.card as Hero)) == -1) {
                        this._selectedHero = (comp.cardSelect.card as Hero);
                        EManager.emit(EName.onExchangeChooseCard, this._selectedHero);
                    }
                }
            } else {
                if (this._selectedHero == comp.cardSelect.card) {
                    this._unSelectHero = this._selectedHero;
                    this._selectedHero = null;
                    EManager.emit(EName.onExchangeChooseCard, null);
                }
            }
            func.call(comp);
            EManager.emit(EName.onUpdateTroopCard);
        }
    }

    onTabFilter(event: cc.Event.EventTouch, index: string) {
        if (Number(index) == this._filterIndex) {
            return;
        }
        this._filterIndex = Number(index);
        this._heroList = this.getHeroes();
        if (this._filterIndex != Hero.Faction.All) {
            this._heroList = this._heroList.where(a => a.getFaction() == this._filterIndex);
        }
        this.list.numItems = this._heroList.length;
    }

    onChoose() {
        if (!this._selectedHero) {
            gm.dialog({
                content: stringConfigMap.key_exchange_no_hero_put.Value, confirm: () => {
                    this._doChoose();
                }
            });
        } else {
            this._doChoose();
        }
    }

    protected _doChoose() {
        if (this._chooseFunc) {
            this._chooseFunc(this._selectedHero);
        }
        if (this._selectedHero) {
            if (ActivityExchangePanel.selectedHeroes.indexOf(this._selectedHero) == -1) {
                ActivityExchangePanel.selectedHeroes.push(this._selectedHero);
            }
        } else if (this._unSelectHero) {
            ActivityExchangePanel.selectedHeroes.remove(this._unSelectHero);
        }
        this.closePanel();
    }

}
