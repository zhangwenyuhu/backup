import { PopupPanel } from "../BasePanel";
import cm from '../../../manager/ConfigManager';
import gm from "../../../manager/GameManager";
import benefitLogic from "../../../logics/BenefitLogic";
import rechargeLogic from "../../../logics/RechargeLogic";
import EManager, { EName } from "../../../manager/EventManager";
import loadUtils from "../../../utils/LoadUtils";
import HeroCard from "../../component/Hero/HeroCard";
import commitLogic from "../../../logics/CommitLogic";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/newplayer/NewPlayerGiftPanel")
export default class NewPlayerGiftPanel extends PopupPanel {

    @property(cc.Node)
    rewards: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    title: cc.Node = null;

    @property(cc.Node)
    icon: cc.Node = null;

    @property(cc.Node)
    priceLabel: cc.Node = null;

    private _storeCfgId: number = 0;
    onInit(data: any) {
        super.onInit(data);
        this._storeCfgId = data.Id;
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        EManager.emit(EName.onFreshPanel, "NewPlayerGiftListPanel");
        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();

        this.initReward();

        let storeCfg = cm.getStoreConfig(this._storeCfgId);
        this.icon.scale = storeCfg.Id == 14 ? 1 : this.icon.scale;
        let giftCfg = cm.getGiftConfig(cm.getGoodConfig(storeCfg.item).effect);

        let urlPre: string = `textures/ui/panel/newplayer/`;
        loadUtils.loadSpriteFrame(urlPre + `benefit_title_name_${giftCfg.Id}`, this.title.getComponent(cc.Sprite));
        loadUtils.loadSpriteFrame(urlPre + `benefit_new_${giftCfg.Id}`, this.icon.getComponent(cc.Sprite));
        this.priceLabel.getComponent(cc.Label).string = rechargeLogic.getMoneyUnit() + storeCfg.money;

        commitLogic.payPanelShow('', this._storeCfgId);
    }

    initReward() {
        this.rewards.destroyAllChildren();
        let storeCfg = cm.getStoreConfig(this._storeCfgId);
        if (storeCfg) {
            let giftCfg = cm.getGiftConfig(cm.getGoodConfig(storeCfg.item).effect);
            let goods: number[][] = giftCfg.Item;
            for (let i = 0; i < goods.length; i++) {
                let card = gm.showGoodItem(goods[i], {
                    goodItem: this.goodItem,
                    equipItem: this.equipItem,
                    heroItem: this.heroItem
                }, this.rewards);
                if (card instanceof HeroCard) {
                    card.enableEffect();
                }
            }
        }
    }

    async onClickBuy() {
        if (!benefitLogic.isNewPlayerValid()) {
            gm.toast(stringConfigMap.key_auto_559.Value);
            return;
        }
        try {
            await rechargeLogic.iap(this._storeCfgId);
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }

    }
}
