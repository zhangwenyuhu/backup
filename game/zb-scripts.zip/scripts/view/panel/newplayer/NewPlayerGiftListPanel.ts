import { RefreshLabel } from './../../../decorator/RefreshDecorator';
import { stringConfigMap } from './../../../configs/stringConfig';
import { FullscreenPanel } from "../BasePanel";
import commonUtils from '../../../utils/CommonUtils';
import loadUtils from "../../../utils/LoadUtils";
import List from "../../common/List";
import benefitLogic, { BenefitStoreType } from "../../../logics/BenefitLogic";
import cm from "../../../manager/ConfigManager";
import gm from "../../../manager/GameManager";
import { storeConfigRow } from "../../../configs/storeConfig";
import EManager, { EName } from "../../../manager/EventManager";
import rechargeLogic from "../../../logics/RechargeLogic";
import timeUtils from "../../../utils/TimeUtils";
import Good from '../../../data/card/Good';
import bagLogic from '../../../logics/BagLogic';
import stringUtils from '../../../utils/StringUtils';
import HeroCard from '../../component/Hero/HeroCard';
import commitLogic, { PayPanel } from '../../../logics/CommitLogic';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/newplayer/NewPlayerGiftListPanel")
export default class NewPlayerGiftListPanel extends FullscreenPanel {
    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => {
            return bagLogic.getGood(Good.GoodId.Diamond)
        },
        getValue: (good: Good) => {
            let amount = stringUtils.formatAmount(good.getAmount());
            return amount;
        }
    })
    @property(cc.Label)
    labelDiamond: cc.Label = null;

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => {
            return bagLogic.getGood(Good.GoodId.Gold)
        },
        getValue: (good: Good) => {
            return stringUtils.formatAmount(good.getAmount());
        }
    })
    @property(cc.Label)
    labelGold: cc.Label = null;

    @property(List)
    itemList: List = null;

    @property(cc.Label)
    labelTimestamp: cc.Label = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Material)
    normalMaterial: cc.Material = null;

    @property(cc.Node)
    bestGiftNode: cc.Node = null;

    @property(cc.Material)
    grayMaterial: cc.Material = null;

    protected _datas: storeConfigRow[] = [];

    protected async _preloadRes() {
        await super._preloadRes();
        await rechargeLogic.storeBuyInfoReq();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("newplayer_gift_bg"), type: cc.SpriteFrame });
        //this._unloadInfos.push({ url: commonUtils.getBgUrl("newplayer_gift_bg1"), type: cc.SpriteFrame });
    }

    protected _refreshList() {
        this._datas = benefitLogic.getBenefitStoreCfgs(BenefitStoreType.NewPlayer);
        this._datas.sort((a, b) => { return a.order - b.order; })
        this.itemList.getComponent(cc.Widget).updateAlignment();
        this.itemList.numItems = this._datas.length;
    }

    protected _refreshTimestamp() {
        let sec = benefitLogic.newPlayerRemaintime;
        let str: string = timeUtils.formatDay(sec * 1000, true) + `后结束`;
        str = sec == 0 ? "已结束" : str;
        this.labelTimestamp.string = str;
    }

    protected _refresh() {

        let bg = this.node.getChildByName('bg');
        let bgName = 'newplayer_gift_bg1';
        let url = commonUtils.getBgUrl(bgName);
        loadUtils.loadSpriteFrame(url, bg.getComponent(cc.Sprite));

        this._refreshList();
        this._refreshTimestamp();
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;

        this.registerEvents();
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();
        this._refresh();
        commitLogic.payPanelShow(PayPanel.NewPlayer, 0);
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data === "NewPlayerGiftListPanel") {
                this._refresh();
            }
        })
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onApplyOrder, (data: any) => {
            if (data) {
                let id: number = data.storeConfigId;
                if (id) {
                    let cfg = cm.getStoreConfig(id);
                    if (cfg.type == BenefitStoreType.NewPlayer) {
                        this._refresh();
                    }
                }
            }
        })
        this._eventListeners.push(listener);
    }

    async onItemRender(item: cc.Node, index: number) {
        let MieBaCfgId: number = 14;
        let storeCfg = this._datas[index];
        if (!storeCfg && index == -1) { storeCfg = cm.getStoreConfig(MieBaCfgId); }
        if (!storeCfg) { return; }
        let bMieBa: boolean = index == -1;
        if (storeCfg.Id == MieBaCfgId && index != -1) {
            item.active = false;
            this.onItemRender(this.bestGiftNode, -1);
            return;
        }
        if (storeCfg) {
            let bGot: boolean = rechargeLogic.getBuyCount(storeCfg.Id) > 0;
            let ani = item.getComponent(cc.Animation);
            let aniName: string = 'xinshoulibao_effect';
            let bPlay: boolean = storeCfg.money > 68;
            if (ani) {
                if (bPlay && !bGot) { ani.play(aniName, 0); } else {
                    ani.stop(aniName);
                    ani.setCurrentTime(0, aniName);
                }
            }

            item.getChildByName("no").active = bGot;
            let sprites = item.getComponentsInChildren(cc.Sprite);
            for (let i = 0; i < sprites.length; i++) {
                if (sprites[i].node.name == 'no') { continue; }
                sprites[i].sharedMaterials = [bGot ? this.grayMaterial : this.normalMaterial];
            }
            item.getComponent(cc.Button).interactable = !bGot;
            item.getComponent(cc.Button).clickEvents[0].customEventData = storeCfg.Id.toString();

            let labelCost = item.getChildByName("layout").getChildByName("label");
            labelCost.getComponent(cc.Label).string = stringConfigMap.key_currency.Value + `${storeCfg.money}`;

            let oldPrice = item.getChildByName("layout").getChildByName("oldPrice");
            oldPrice.getComponent(cc.Label).string = stringConfigMap.key_currency.Value + `${storeCfg.price}`;

            item.getChildByName("layout").opacity = bGot ? 130 : 255;
            item.getChildByName("desc").opacity = bGot ? 130 : 255;

            let rewards = item.getChildByName("rewards");
            item.getChildByName('heroTip').active = false;
            rewards.destroyAllChildren();
            let giftCfg = cm.getGiftConfig(cm.getGoodConfig(storeCfg.item).effect);
            let goods: number[][] = giftCfg.Item;
            let scale: number = bMieBa ? 1.3 : 0.7;
            for (let i = 0; i < goods.length; i++) {
                let card = gm.showGoodItem(goods[i], {
                    goodItem: this.goodItem,
                    equipItem: this.equipItem,
                    heroItem: this.heroItem
                }, rewards, scale, undefined, bGot, false, { quality: 3 });
                if (card instanceof HeroCard && !bGot) {
                    card.enableEffect();
                }

                if (bGot) {
                    card.showGray(true);
                }
            }
            rewards.getComponent(cc.BlockInputEvents).enabled = !bGot;

            let urlPre: string = `textures/ui/panel/newplayer/`;
            let node = item.getChildByName("name");

            node.active = false;
            let frame = node.getComponent(cc.Sprite);
            cc.loader.loadRes(urlPre + `newplayer_type_${giftCfg.Id}`, cc.SpriteFrame, (error: Error, res: cc.Asset) => {
                frame.node.active = !error && bMieBa;
                if (frame.node.active) { frame.spriteFrame = res as cc.SpriteFrame; }
            });

            node = item.getChildByName("icon");
            loadUtils.loadSpriteFrame(urlPre + `benefit_new_${giftCfg.Id}`, node.getComponent(cc.Sprite));

            node = item.getChildByName("tip");
            loadUtils.loadSpriteFrame(urlPre + `newplayer_tag_${giftCfg.Id}`, node.getComponent(cc.Sprite));
        }
    }

    onItemClick(sender: cc.Event.EventTouch, index: string) {
        let storeCfgId: number = parseInt(index);
        if (benefitLogic.isNewPlayerValid()) {
            gcc.core.showLayer("prefabs/panel/newplayer/NewPlayerGiftPanel", { data: { Id: storeCfgId } });
        } else {
            this._refreshTimestamp();
            gm.toast(stringConfigMap.key_no_buy_gift.Value);
        }

    }
}