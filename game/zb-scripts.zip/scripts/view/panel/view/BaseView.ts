import { InternalView } from './../BasePanel';
import gm from "../../../manager/GameManager";
import { unlockConfigRow } from "../../../configs/unlockConfig";
import guideLogic from "../../../logics/GuideLogic";
import UnlockWrapper from "../../widget/unlock/UnlockWrapper";
import am from "../../../manager/AudioManager";

const { ccclass, property } = cc._decorator;

@ccclass
export default abstract class BaseView extends InternalView {
    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Material)
    bgMaterials: cc.Material[] = [];

    @property(cc.Material)
    unlockMaterial: cc.Material = null;

    @property(cc.ScrollView)
    scrollView: cc.ScrollView = null;

    static isFirstIn: boolean = true;

    onLoad() {
        this.node.position = cc.v2();
        super.onLoad();
    }

    reload() {
        this.scrollView.content.y = 0;

        super.reload();

        if (guideLogic.noGuide) return;

        if (gm.isNewUnlock && UnlockWrapper.isNewUnlock(this.config)) {
            let obj = { param: 0 };
            let material = this.unlockMaterial as any;
            material.setProperty("param", obj.param);
            this.bg.setMaterial(0, material);

            gm.showIndicator(1.5);
            cc.tween(obj).to(1.5, { param: 1 }, {
                progress: (start: number, end: number, current: number, ratio: number) => {
                    material.setProperty("param", start + (end - start) * ratio);
                    this.bg.setMaterial(0, material);
                }
            }).call(() => { gm.hideIndicator() }).start();
        }
        else {
            this.bg.setMaterial(0, UnlockWrapper.isUnlock(this.config) ? this.bgMaterials[0] : this.bgMaterials[1]);
        }
        gm.isNewUnlock = false;
    }

    onEnable() {
        super.onEnable();
        this.playBGM();
    }

    onDisable() {
        am.stopMusic();
        this.unschedule(this._playBGMLoop);
        super.onDisable();
    }

    playBGM() {
        if (gm.isBattled) {
            gm.isBattled = false;
            am.playMusic("BGM_home_enter");
        }
        else if (BaseView.isFirstIn) {
            BaseView.isFirstIn = false;
            am.playMusic("BGM_home_enter");
        }
        else {
            am.playMusic(this.musicName);
        }
        this.schedule(this._playBGMLoop, 30);
    }

    protected _playBGMLoop() {
        am.playMusic(Math.random() > 0.5 ? "BGM_home_loop" : "BGM_field_loop")
    }

    public abstract get config(): unlockConfigRow;
    public abstract get musicName(): string;
}
