import { InternalView } from './../BasePanel';
import { EName } from './../../../manager/EventManager';
import missionLogic from "../../../logics/MissionLogic";
import CommonLoader from "../../common/CommonLoader";
import BuildingItem from "../../component/Mission/BuildingItem";
import EManager from "../../../manager/EventManager";
import Chapter from "../../../data/mission/Chapter";
import loadUtils from '../../../utils/LoadUtils';
import cm from '../../../manager/ConfigManager';
import playerLogic from '../../../logics/PlayerLogic';
import gm from '../../../manager/GameManager';
import BgMixer from '../../component/BgMixer';
import am from '../../../manager/AudioManager';
import { stringConfigMap } from '../../../configs/stringConfig';
import guideTaskLogic from '../../../logics/GuideTaskLogic';
import towerLogic from '../../../logics/TowerLogic';
import GuideBaseStep from '../../widget/guide/GuideBaseStep';
import UnlockWrapper from '../../widget/unlock/UnlockWrapper';
import { unlockConfigMap } from '../../../configs/unlockConfig';
import MoveTips from '../../component/MoveTips';
import guideLogic from '../../../logics/GuideLogic';
import BgMixerEx from '../../component/BgMixerEx';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/view/InstanceView")
export default class InstanceView extends InternalView {
    @property(cc.ScrollView)
    chapterList: cc.ScrollView = null;

    @property(cc.Layout)
    chapterContent: cc.Layout = null;

    @property(cc.Node)
    btnFastHangup: cc.Node = null;

    @property(cc.Sprite)
    rewardBox: cc.Sprite = null;

    @property(cc.SpriteFrame)
    rewardBoxFrames: cc.SpriteFrame[] = [];

    @property(cc.Sprite)
    hangupSprite: cc.Sprite = null;

    @property(cc.SpriteFrame)
    hangupFrames: cc.SpriteFrame[] = [];

    @property(cc.Node)
    rewardArea: cc.Node = null;

    @property(cc.Node)
    guideTaskNode: cc.Node = null;

    @property(cc.Widget)
    buttonsWidget: cc.Widget = null;

    @property(cc.Widget)
    rewardWidget: cc.Widget = null;

    protected _chapterInfos: { chapterNode: cc.Node, buildingNodes: cc.Node[], chapter: Chapter }[] = [];
    protected tipCount: number = 0;
    protected _canShowRewardBox: boolean = false;

    onLoad() {
        this.node.position = cc.v2();

        super.onLoad();

        let country = missionLogic.getCurrentCountry();
        if (!country) {
            country = missionLogic.getLastCountry();
        }

        this._chapterInfos = [];
        let chapters = country.getChapters();
        let building: cc.Node = null;
        for (let chapter of chapters) {
            if (chapter.isUnlock()) {
                building = this._addChapter(chapter);
            }
            else {
                break;
            }
        }
        this.chapterContent.updateLayout();
        this.scheduleOnce(() => { this.showZoombieTip(); }, 3);

        let widget = this.chapterList.getComponent(cc.Widget);
        widget.updateAlignment();
        this.chapterList.scrollToBottom();
        this._moveToTarget(building);

        this.buttonsWidget.updateAlignment();
        this.rewardWidget.updateAlignment();

        this.registerEvents();
    }

    start() {
        super.start();
        this.mix();
    }

    onEnable() {
        super.onEnable();
        am.playMusic("BGM_map");
        // this.checkGuideTask();

        this.btnFastHangup.active = UnlockWrapper.isUnlock(unlockConfigMap.快速挂机);
        let mission = missionLogic.getCurrentMission();
        this._canShowRewardBox = !mission || mission.getStageId() > 2;

        gm.showVipPanel();

        if (!gm.appReview) {
            if (gm.popFirstPay) {
                gcc.core.showLayer("prefabs/panel/benefit/FirstPayPanel", { layer: gcc.LayerType.INFO });
                gm.popFirstPay = false;
            }
        }
    }

    mix() {
        if (gm.usePerformance) {
            return;
        }

        for (let info of this._chapterInfos) {
            let currentBuilding: cc.Node = null;
            for (let node of info.buildingNodes) {
                let loader = node.getComponent(CommonLoader);
                let comp = loader.loaderNode.getComponent(BuildingItem);
                if (comp.building.isUnlock() && !comp.building.isPassed()) {
                    currentBuilding = node;
                    break;
                }
            }
            let mixer = info.chapterNode.getChildByName("fg").getComponent(BgMixerEx);
            mixer.refresh(currentBuilding);
        }
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onNextChapter, () => {
            this._onNextChapter(0.5);
            this.mix();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onNextCountry, () => {
            this._onNextCountry();
            this.mix();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onNextBuilding, (buildingNode: cc.Node) => {
            this._moveToTarget(buildingNode, 0.5);
            this.mix();
        });
        this._eventListeners.push(listener);

        // listener = EManager.addEvent(EName.onFreshGuideTask, () => {
        //     this.checkGuideTask(false);
        // });
        // this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onBattleChallenge, () => {
            this.onChallenge();
        });
        this._eventListeners.push(listener);
    }

    update(dt: number) {
        super.update(dt);
        this._updateRewardBoxFrame();

        if (gm.reCountdown) {
            this.tipCount = 0;
            gm.reCountdown = false;
        } else {
            this.tipCount += dt;
            if (this.tipCount > 10) {
                //console.warn("10s到达,显示气泡")
                this.tipCount = 0;
                this.showZoombieTip();
            }
        }
    }

    showZoombieTip() {
        if (gm.tipNode && gm.tipNode.length > 0) {
            let len: number = gm.tipNode.length;
            let tmp: cc.Node[] = [];
            for (let i = 0; i < len; i++) {
                if (gm.tipNode[i] && cc.isValid(gm.tipNode[i])) {
                    tmp.push(gm.tipNode[i]);
                } else {
                    gm.tipNode.splice(i, 1);
                }
            }
            if (tmp.length > 0) {
                let index: number = Math.floor(Math.random() * tmp.length);
                let node = tmp[index];
                node.getComponent(MoveTips).clickShowTip();
            }
        }
    }

    protected _onNextCountry() {
        let country = missionLogic.getCurrentCountry();
        if (country) {
            let children = this.chapterContent.node.children;
            this.chapterContent.node.destroyAllChildren();
            for (let child of children) {
                let sprite = child.getComponent(cc.Sprite);
                loadUtils.releaseAssetRecursively(sprite.spriteFrame);
                let fg = child.getChildByName("fg");
                if (fg) {
                    sprite = fg.getComponent(cc.Sprite);
                    loadUtils.releaseAssetRecursively(sprite.spriteFrame);
                }
                cc.loader.releaseAsset((child as any).prefab);
            }
            this._chapterInfos = [];
            this._onNextChapter();
        }
    }

    protected _onNextChapter(duration?: number) {
        let chapter = missionLogic.getCurrentChapter();
        if (chapter) {
            let building = this._addChapter(chapter);
            this.chapterContent.updateLayout();
            this._moveToTarget(building, duration);
        }
    }

    protected _moveToTarget(target: cc.Node, duration?: number) {
        if (target) {
            let worldPos = target.convertToWorldSpace(cc.v2(0, -180));
            let nodePos = this.chapterList.node.convertToNodeSpaceAR(worldPos);
            let deltaY = -nodePos.y;
            let targetY = this.chapterContent.node.y + deltaY;
            let startY = -this.chapterList.node.height / 2;
            let endY = this.chapterList.node.height / 2 - this.chapterContent.node.height;
            let percent = (targetY - startY) / (endY - startY);
            percent = Math.max(0, percent);
            percent = Math.min(1, percent);
            this.chapterList.scrollToPercentVertical(percent, duration);
        }
        else {
            this.chapterList.scrollToTop(duration);
        }
    }

    protected _addChapter(chapter: Chapter): cc.Node {
        let prefab = cc.loader.getRes(`prefabs/chapter/chapter${chapter.getId()}`, cc.Prefab) as cc.Prefab;
        let node = prefab.data;
        (node as any)._onBatchRestored();
        (node as any).prefab = prefab;
        node.parent = this.chapterContent.node;

        let buildingNodes: cc.Node[] = [];
        let buildingNode: cc.Node = null;
        let buildings = chapter.getBuildings();
        for (let i = 0; i < buildings.length; i++) {
            let building = buildings[i];
            let child = node.getChildByName(`building${i + 1}`);
            if (!child) continue;
            buildingNodes.push(child);

            let loader = child.getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(BuildingItem);
            comp.init(building, node.getChildByName(`fight${i + 1}`));

            if (building.isUnlock() && !building.isPassed()) {
                buildingNode = child;
            }
        }

        this._chapterInfos.push({ chapterNode: node, buildingNodes: buildingNodes, chapter: chapter });

        return buildingNode;
    }

    protected _updateRewardBoxFrame() {
        let minutes = playerLogic.getHangupMinutes();

        let times = cm.goldshow;
        for (let i = times.length - 1; i >= 0; i--) {
            let time = times[i];
            if (minutes >= time) {
                if (this.hangupSprite.spriteFrame != this.hangupFrames[i]) {
                    this.hangupSprite.spriteFrame = this.hangupFrames[i];
                }
                break;
            }
        }

        if (this._canShowRewardBox) {
            let playRewardAnimation = (i: number) => {
                this.rewardArea.active = true;

                let root_animation = this.getComponent(cc.Animation);
                let root_clips = root_animation.getClips();
                if (root_clips[i]) {
                    if (root_animation.currentClip && root_clips[i].name == root_animation.currentClip.name) { return; }
                    root_animation.play(root_clips[i].name);
                    console.warn("root播放动画: " + root_clips[i].name);
                }


                let animation = this.rewardArea.getComponent(cc.Animation);
                let clips = animation.getClips();
                if (clips[i]) {
                    if (animation.currentClip && clips[i].name == animation.currentClip.name) { return; }
                    animation.play(clips[i].name);
                    console.warn("播放动画: " + clips[i].name);
                }
            }

            times = cm.goldshoweffect;
            for (let i = times.length - 1; i >= 0; i--) {
                let time = times[i];
                if (minutes >= time) {
                    playRewardAnimation(i);
                    return;
                }
            }

            if (guideLogic.guideId == 10160 || guideLogic.guideId == 60010) {
                playRewardAnimation(0);
                return;
            }
        }

        this.rewardArea.active = false;
    }

    onChallenge() {
        let building = missionLogic.getCurrentBuilding();
        if (building) {
            if (building.getMissions().length > 1) {
                gcc.core.showLayer("prefabs/panel/mission/BuildingInfoPanel", { data: building });
            }
            else {
                gcc.core.showLayer("prefabs/panel/battle/BattlePreparePanel", {
                    data: building.getCurrentMission()
                });
            }
        }
        else {
            gm.toast(stringConfigMap.key_all_mission_passed.Value);
        }
    }

    async onHangUpReward() {
        try {
            let timestamp = playerLogic.startHangupTS;
            let resource = await playerLogic.doClaimHangupReward();
            let delta = (gm.getCurrentTimestamp() - timestamp) / 1000;
            gcc.core.showLayer("prefabs/panel/hangup/HangupRewardPanel", { data: { resource: resource, dt: delta }, modalTouch: true });
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    onClickFastHangup() {
        gcc.core.showLayer("prefabs/panel/hangup/HangupFastPanel");
    }

    onClickGuideTask() {
        gcc.core.showLayer("prefabs/panel/assignment/GuideTaskPanel", { data: guideTaskLogic.getNowGuideTask().getId() });
    }

    freshGuideTask() {
        this.guideTaskNode.active = !guideTaskLogic.guideTaskComplete;
        if (CC_PREVIEW) {
            this.guideTaskNode.active = true;
        }

        if (!this.guideTaskNode.active) { return; }
        //ui fresh
        let nowTask = guideTaskLogic.getNowGuideTask();
        if (!nowTask) {
            this.guideTaskNode.active = false;
            return;
        }
        let complete: boolean = nowTask.isComplete();
        let cfg = nowTask.getCfg();

        this.guideTaskNode.getChildByName("statu1").active = !complete;
        this.guideTaskNode.getChildByName("statu2").active = complete;

        let desc = this.guideTaskNode.getChildByName("desc");
        let pro = this.guideTaskNode.getChildByName("pro");
        desc.getComponent(cc.Label).string = cfg.tasktitle;
        pro.getComponent(cc.Label).string = "进度 " + nowTask.getShowPro();
    }

    async checkGuideTask(req: boolean = true) {
        if (!req) {
            this.freshGuideTask();
            return;
        }

        if (!guideTaskLogic.bInited) {
            await guideTaskLogic.guideTaskStatuReq(0);
        }

        if (guideTaskLogic.guideTaskComplete) {
            this.freshGuideTask();
            return;
        }

        // req
        let nowTask = guideTaskLogic.getNowGuideTask();
        if (nowTask) {
            if (!nowTask.hasLocalPro() && guideTaskLogic.getGuideTaskPro(nowTask.getId()) <= 0) {
                await guideTaskLogic.guideTaskProgressCommit(nowTask.getCfg().tasktype, 0);
            } else {
                if (nowTask.getCfg().tasktype == 3003 && nowTask.getNowPro() <= 0) {
                    await towerLogic.towerProcessReq();
                }
            }
        }

        // fresh
        this.freshGuideTask();
    }

    async onHeroFlyAway(step: GuideBaseStep) {
        step.delay = 1;

        let node = new cc.Node("chaoren");
        node.parent = this.node;
        let skeleton = node.addComponent(sp.Skeleton);
        let heroUrl = 'spine/hero/chaoren_yinqindonhua';
        let skeletonData = await loadUtils.loadRes(heroUrl, sp.SkeletonData) as sp.SkeletonData;
        if (!cc.isValid(this.node)) return;
        skeleton.skeletonData = skeletonData;
        skeleton.animation = 'feizou';
        skeleton.loop = false;
        skeleton.setCompleteListener(() => {
            node.destroy();
            loadUtils.releaseAssetRecursively(skeletonData);
        });
    }
}
