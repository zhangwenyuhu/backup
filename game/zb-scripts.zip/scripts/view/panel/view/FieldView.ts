import { Storage } from './../../../utils/DefineUtils';
import { unlockConfigMap, unlockConfigRow } from './../../../configs/unlockConfig';
import gm from "../../../manager/GameManager";
import towerLogic from "../../../logics/TowerLogic";
import xsLogic from '../../../logics/XuanshangLogic';
import wisdomTreeLogic from "../../../logics/WisdomTreeLogic";
import redPointLogic, { RedPointType } from '../../../logics/RedPointLogic';
import EManager, { EName } from '../../../manager/EventManager';
import BaseView from './BaseView';
import dungeonLogic from '../../../logics/DungeonLogic';
import UnlockWrapper from "../../widget/unlock/UnlockWrapper";
import storageUtils from '../../../utils/StorageUtils';
import { PromptType } from '../../../data/prompt/PromptModal';
import am from '../../../manager/AudioManager';
import rMissionLogic from "../../../logics/RMissionLogic";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/view/FieldView")
export default class FieldView extends BaseView {
    get config(): unlockConfigRow {
        return unlockConfigMap.挑战;
    }

    get musicName(): string {
        return "BGM_field_environment";
    }

    reload() {
        super.reload();

        if (gm.isBattled) {
            gm.isBattled = false;
            am.playMusic("BGM_field_enter");
        }
    }

    onEnable() {
        super.onEnable();

        this.checkXsRed();
        xsLogic.updateMyHeros();
        EManager.emit(EName.onFreshRed, RedPointType.Town_XuanShang);
        gm.showVipPanel();
        //console.warn(`onEnable FieldView`);
    }

    scrollToBottom() {
        this.scrollView.scrollToBottom(0.5);
    }

    checkXsRed() {
        let isUnlock = xsLogic.isXsUnlock();
        redPointLogic.setRedPointIgnore(RedPointType.Town_XuanShang, !isUnlock);
    }

    /**
     * 智慧树考验
     */
    async onZhiHuiShu() {
        gcc.core.showLayer("prefabs/panel/wisdomtree/WisdomTreePanel");
    }

    /**
     * 竞技场
     */
    onPvp() {
        gcc.core.showLayer("prefabs/panel/arena/ArenaPanel");
    }

    /**
     * 禅境花园
     */
    onChanJing() {
        gm.toast(stringConfigMap.key_auto_574.Value);
    }

    /**
     * 超级摩天楼
     */
    onMoTianLou() {
        this.showTower();
    }

    async showTower() {
        await towerLogic.towerProcessReq();
        if (towerLogic.isRaceUnlock()) {
            gcc.core.showLayer("prefabs/panel/tower/TowerRacePanel");
        } else {
            gcc.core.showLayer("prefabs/panel/tower/SimpleRaceTowerPanel", { data: 0 });
        }
    }

    /**
     * 奇妙时空
     */
    onQiMiaoShiKong() {
        gcc.core.showLayer("prefabs/panel/wonderspace/WonderSpaceListPanel");
    }

    /**
     * 秘境花园
     */
    onMiJingHuaYuan() {
        gm.toast(stringConfigMap.key_auto_574.Value);
    }

    /**
     * 悬赏
     */
    onXuanShang() {
        this.showXuanshang();
    }

    /**
     * 地牢
     */
    async onDilao() {
        try {
            await dungeonLogic.request();
            if (dungeonLogic.battleHero) {
                gcc.core.showLayer("prefabs/panel/dungeon/DungeonMapPanel");
            }
            else {
                gcc.core.showLayer("prefabs/panel/dungeon/DungeonSelectPanel");
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }

        storageUtils.setNumber(Storage.LastDungeonIn.Key, gm.getCurrentTimestamp(), true);
        EManager.emit(EName.onRedDirty, PromptType.DungeonBtn);
    }

    async showXuanshang() {
        let blvUp = await xsLogic.xsTaskReq();
        gcc.core.showLayer("prefabs/panel/xs/XuanshangPanel", { data: { lvUp: blvUp } });
    }

    onMaterial() {
        gcc.core.showLayer("prefabs/panel/clone/ClonePanel");
    }
}