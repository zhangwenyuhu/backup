import { EName } from './../../../manager/EventManager';
import { InternalView } from './../BasePanel';
import missionLogic from '../../../logics/MissionLogic';
import EManager from '../../../manager/EventManager';
import Hero from '../../../data/card/Hero';
import UnlockWrapper from '../../widget/unlock/UnlockWrapper';
import { unlockConfigMap } from '../../../configs/unlockConfig';
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/view/RootView")
export default class RootView extends InternalView {
    public currentStageId: number = 0;

    protected _isDungeonUnlock: boolean = false;
    protected _isDungeonNewUnlock: boolean = false;
    protected _unlockCallback: Function = null;

    init(unlockCallback: Function) {
        this._unlockCallback = unlockCallback;
    }

    reload() {
        // undo
    }

    onLoad() {
        super.onLoad();

        let listener = EManager.addEvent(EName.onAddHeroes, (heroes: Hero[]) => {
            if (!this._isDungeonUnlock) {
                this._isDungeonNewUnlock = UnlockWrapper.isUnlock(unlockConfigMap.地牢);
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onBeforeAddHeroes, (heroes: Hero[]) => {
            if (!this._isDungeonUnlock) {
                this._isDungeonUnlock = UnlockWrapper.isUnlock(unlockConfigMap.地牢);
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onEvoluteHeroes, (heroes: Hero[]) => {
            if (!this._isDungeonUnlock) {
                this._isDungeonNewUnlock = UnlockWrapper.isUnlock(unlockConfigMap.地牢);
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onBeforeEvoluteHeroes, (heroes: Hero[]) => {
            if (!this._isDungeonUnlock) {
                this._isDungeonUnlock = UnlockWrapper.isUnlock(unlockConfigMap.地牢);
            }
        });
        this._eventListeners.push(listener);
    }

    onEnable() {
        super.onEnable();

        let curMission = missionLogic.getCurrentMission();
        if (curMission) {
            this.currentStageId = curMission.getStageId();
        }
    }

    update(dt: number) {
        super.update(dt);

        if (this._isDungeonNewUnlock && this.noPopup) {
            this._isDungeonNewUnlock = false;
            if (this._unlockCallback) {
                this._unlockCallback(unlockConfigMap.地牢);
            }
        }
    }
}