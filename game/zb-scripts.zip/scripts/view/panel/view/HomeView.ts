import { stringConfigMap } from './../../../configs/stringConfig';
import { GuildVO } from './../../../proxy/GameProxy';
import gm from "../../../manager/GameManager";
import playerLogic from "../../../logics/PlayerLogic";
import unionLogic from "../../../logics/UnionLogic";
import GameProxy from "../../../proxy/GameProxy";
import honorLogic from '../../../logics/HonorLogic';
import missionLogic from '../../../logics/MissionLogic';
import libraryLogic from '../../../logics/LibraryLogic';
import heroLogic from '../../../logics/HeroLogic';
import stringUtils from '../../../utils/StringUtils';
import { unlockConfigMap, unlockConfigRow } from '../../../configs/unlockConfig';
import BaseView from './BaseView';
import RankData from '../../../data/record/RankData';
import loadUtils from '../../../utils/LoadUtils';
import UnlockWrapper from '../../widget/unlock/UnlockWrapper';
import EManager, { EName } from '../../../manager/EventManager';
import GuideBaseStep from '../../widget/guide/GuideBaseStep';
import { PromptType } from '../../../data/prompt/PromptModal';
import zpLogic from '../../../logics/ZhuanPanLogic';
import CommonLoader from '../../common/CommonLoader';
import PlayerAvatar from '../../component/Player/PlayerAvatar';
import zhuanpanTip from '../../component/zhuanpanTip';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/view/HomeView")
export default class HomeView extends BaseView {
    @property(sp.Skeleton)
    birdSkeleton: sp.Skeleton = null;

    @property(cc.Node)
    honorTop: cc.Node = null;

    @property(cc.Node)
    zpTip: cc.Node = null;

    get config(): unlockConfigRow {
        return unlockConfigMap.家园;
    }

    get musicName(): string {
        return "BGM_home_environment";
    }

    onLoad() {
        super.onLoad();

        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data == "HomeView") {
                this.checkHonorTop();
            }
        });
        this._eventListeners.push(listener);
        listener = EManager.addEvent(EName.onUpdateZhuanPan, (data) => {
            this.checkZhuanPanTip();
        });
        this._eventListeners.push(listener);

        zpLogic.zhuanPanReq();
    }

    reload() {
        super.reload();

        let country = missionLogic.getCurrentCountry();
        if (country && country.getId() == 1) {
            this.birdSkeleton.animation = "0_yewan";
        }
        else {
            this.birdSkeleton.animation = "0_baitian";
        }
        this.checkHonorTop();
        this.checkZhuanPanTip();
    }

    onEnable() {
        super.onEnable();
        EManager.emit(EName.onRedDirty, PromptType.ZhuanPanBtn);
        EManager.emit(EName.onUseVideoLottery);
        gm.showVipPanel();
        this.checkZhuanPanTip();
    }

    scrollToTop() {
        this.scrollView.scrollToTop(0.5);
    }

    scrollToPercent(step: GuideBaseStep, customData: string) {
        this.scrollView.scrollToPercentVertical(Number(customData), 0.5);
    }

    clearGuideObstruct(step: GuideBaseStep) {
        EManager.emit(EName.onClearGuideObstruct, step);
    }

    /**
     * 卡片机
     */
    async onCardMachine() {
        gcc.core.showLayer("prefabs/panel/lottery/LotteryPanel");
    }

    /**
     * 仓库
     */
    onBag() {
        gcc.core.showLayer("prefabs/panel/bag/BagPanel");
    }

    /**
     * 邮件
     */
    onEmail() {
        gcc.core.showLayer("prefabs/panel/mail/MailPanel");
    }

    /**
     * 转盘选择
     */
    onZhuanPan() {
        zpLogic.heroTipValid = false;
        this.checkZhuanPanTip();
        gcc.core.showLayer("prefabs/panel/union/ZhuanPanSelectPanel");
    }

    checkZhuanPanTip() {
        //let zpRead: boolean = storageUtils.getBoolean(Storage.ZhuanPanRead);
        this.zpTip.active = zpLogic.heroTipValid && UnlockWrapper.isUnlock(unlockConfigMap.寻宝);
        if (this.zpTip.active) {
            let loader = this.zpTip.getComponent(CommonLoader).loaderNode;
            loader.getComponent(zhuanpanTip).refresh(zpLogic.getZpHeroId());
        }
    }

    /**
     * 图书馆
     */
    async onLibrary() {
        return;
        await libraryLogic.fettersReq();
        gcc.core.showLayer("prefabs/panel/record/LibraryPanel");
    }

    /**
     * 共享花坛
     */
    onFlowerBed() {
        if (heroLogic.getHeroesCount() < heroLogic.getPriestsCount()) {
            gm.toast(stringUtils.getString(stringConfigMap.key_hero_less_than.Value, { count: heroLogic.getPriestsCount() }));
            return;
        }
        gcc.core.showLayer("prefabs/panel/share_level/ShareLevelPanel");
    }

    /**
     * 荣耀场
     */
    async onHonor() {
        await honorLogic.myRankReq();
        await honorLogic.allRankTop1Req();
        gcc.core.showLayer("prefabs/panel/honor/HonorPanel");
    }

    async checkHonorTop() {
        let unlock = UnlockWrapper.isUnlock(unlockConfigMap.荣誉榜);
        if (unlock) {
            let data = honorLogic.getRandomTop1();
            if (!data) {
                await honorLogic.allRankTop1Req();
                data = honorLogic.getRandomTop1();
            }
            this.freshHonorTop(data);
        } else {
            this.freshHonorTop(null);
        }
    }
    // 刷新荣耀榜玩家显示
    freshHonorTop(data: RankData) {
        this.honorTop.active = data ? true : false;
        if (this.honorTop.active) {
            let name = this.honorTop.getChildByName("name");
            let avatarLoader = this.honorTop.getChildByName("avatar").getComponent(CommonLoader)
            let comp = avatarLoader.loaderNode.getComponent(PlayerAvatar);
            comp.refresh(data.getRole().getAvatar());
            name.getComponent(cc.Label).string = data.getRole().getNickname();
        }
    }

    /**
     * 实验室
     */
    onLaboratory() {
        gcc.core.showLayer("prefabs/panel/evolution/EvolutionPanel");
        //gcc.core.showLayer("prefabs/panel/evolution/MergePanel", { data: MergeType.Equip });
    }

    /**
     * 回收器
     */
    onRecycle() {
        gcc.core.showLayer("prefabs/panel/recycle/HeroRecyclePanel");
    }

    /**
     * 商店
     */
    onStore() {
        gcc.core.showLayer("prefabs/panel/store/StorePanel");
    }

    /**
     * 工会
     */
    async onUnion() {
        if (!playerLogic.getPlayer().isInUnion()) {
            unionLogic.init(null, gm);
            gcc.core.showLayer("prefabs/panel/union/UnionListPanel");
        }
        else {
            let protos = await gm.request<GuildVO[]>(GameProxy.apiguildfindGuild, playerLogic.getPlayer().getUnionId().toString());
            unionLogic.init(protos[0], gm);
            gcc.core.showLayer("prefabs/panel/union/UnionHallNewPanel");
        }
    }
}