import { guideconfigRow } from './../../../configs/guideconfig';
import { EName } from './../../../manager/EventManager';
import heroLogic from "../../../logics/HeroLogic";
import Hero from "../../../data/card/Hero";
import HeroLayout from "../../component/Hero/HeroLayout";
import HeroCard from "../../component/Hero/HeroCard";
import playerLogic from "../../../logics/PlayerLogic";
import gm from "../../../manager/GameManager";
import { RefreshLabel } from "../../../decorator/RefreshDecorator";
import Player from "../../../data/user/Player";
import EManager from "../../../manager/EventManager";
import HeroInfoPanel from '../hero/HeroInfoPanel';
import { PopupPanel } from '../BasePanel';
import List from '../../common/List';
import CommonLoader from '../../common/CommonLoader';
import commonUtils from '../../../utils/CommonUtils';
import PromptPoint from '../../component/PromptPoint';
import heroUtils from '../../../utils/HeroUtils';
import guideLogic from '../../../logics/GuideLogic';
import ListItem from '../../common/ListItem';
import GuideBaseStep from '../../widget/guide/GuideBaseStep';
import HeroIllustration from '../../../data/card/HeroIllustration';
import TabLoader from "../../common/loader/TabLoader";
import UnlockWrapper from "../../widget/unlock/UnlockWrapper";
import { unlockConfigMap } from "../../../configs/unlockConfig";
import xScrollView from "../../xScrollView";
import HeroTitle from "../../component/Hero/HeroTitle";
import bagLogic from "../../../logics/BagLogic";
import ArtifactLvup from "../../component/Artifact/ArtifactLvup";
import PlayerHero from "../../../data/card/PlayerHero";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

enum TabIndex {
    /**
     * 英雄
     */
    Hero = 1,

    /**
     * 图鉴
     */
    Book,

    /**
     * 神器
     */
    Artifact,
}

@ccclass
@menu("view/panel/view/MyHeroView")
export default class MyHeroView extends PopupPanel {

    @property(cc.Node)
    heroBg: cc.Node = null;

    @property(cc.Node)
    bg2: cc.Node = null;

    @property(cc.Node)
    artifactBg: cc.Node = null;

    @property(List)
    heroList: List = null;

    @property(CommonLoader)
    hero_item: CommonLoader = null;

    @property(cc.Node)
    heroScrollView: cc.Node = null;

    @property(cc.Node)
    scrollContent: cc.Node = null;

    @property(cc.Node)
    heroBigScrollView: cc.Node = null;

    @property(cc.Node)
    heroBigNode: cc.Node = null;

    @property(cc.Prefab)
    heroLayoutPrefab: cc.Prefab = null;

    @property(cc.Node)
    artifactNode: cc.Node = null;

    @property(cc.Prefab)
    heroPrefab: cc.Prefab = null;

    @property(cc.Node)
    noHero: cc.Node = null;

    @property(cc.Node)
    redPoint: cc.Node = null;

    @property(CommonLoader)
    tabNode: CommonLoader = null;

    @property(cc.Node)
    artifactLock: cc.Node = null;

    @property(cc.Node)
    artifactLvNode: cc.Node = null;

    @RefreshLabel({
        eventName: Player.PlayerEvent.onHeroCapacityDirty,
        getData: () => {
            return playerLogic.getPlayer();
        },
        getValue: (player: Player) => {
            return player.getHeroCapacity();
        },
        getString: (cnt: string) => {
            return `${heroLogic.getHeroesCount()}/${cnt}`;
        }
    })
    @property(cc.Label)
    bagCnt: cc.Label = null;

    @property(cc.Node)
    heroSchoolBtn: cc.Node = null;

    @property(sp.Skeleton)
    shenqi: sp.Skeleton = null;

    @property(sp.Skeleton)
    shenqiLv: sp.Skeleton = null;

    protected _selectFactionindex: number = Hero.Faction.All;
    protected _heroIllustrationList: Hero[] = [];
    protected _showBig: boolean = false;
    protected _showArtifact: boolean = false;
    protected _tabIndex: number = -1;
    protected _evolutionUnlock: boolean = false;
    protected _shenqiSkeletonData: sp.SkeletonData = null;
    protected _shenqiLvSkeletonData: sp.SkeletonData = null;

    public guideListId: number = -1;

    static firstAnimation: boolean = true;
    static evolutionClick: boolean = false;

    onLoad() {
        super.onLoad();

        this.registerEvents();
        this.node.position = cc.v2();
    }

    async start() {
        super.start();

        this.showArtifact();
        this._evolutionUnlock = UnlockWrapper.isUnlock(unlockConfigMap.花房);
        this.heroSchoolBtn.active = UnlockWrapper.isUnlock(unlockConfigMap.新手学堂);
        this.heroList.getComponent(cc.Widget).updateAlignment();
        this.changeView(gm.heroTab.toString());
        this._tabIndex = gm.heroTab;
        this.tabNode.getComponent(TabLoader).switchTab(gm.heroTab - 1);

        if (MyHeroView.firstAnimation && this.heroList.scrollView.enabled) {
            this.heroList.scrollView.enabled = false;
            let children = this.heroList.content.children.slice(0);
            for (let child of children) {
                let loader = child.getChildByName("hero").getComponent(CommonLoader);
                loader.loaderNode.pauseAllActions();
            }
            for (let child of children) {
                await commonUtils.sleep(0.02, this);
                if (!cc.isValid(child)) break;
                let loader = child.getChildByName("hero").getComponent(CommonLoader);
                loader.loaderNode.resumeAllActions();
            }
            this.heroList.scrollView.enabled = true;
            MyHeroView.firstAnimation = false;
        }
        if (!UnlockWrapper.isUnlock(unlockConfigMap.神器)) {
            this.tabNode.getComponent(TabLoader).setTabDisable([2]);
        }
        this.artifactLock.active = !UnlockWrapper.isUnlock(unlockConfigMap.神器);
        this._refreshArtifactLvNode();
    }

    protected _refreshArtifactLvNode() {
        if (bagLogic.getArtifacts().length > 0) {
            this.artifactLvNode.getComponent(ArtifactLvup).refresh(null);
            this.artifactNode.y = 132;
        } else {
            this.artifactNode.y = 14;
        }
        this.artifactLvNode.active = bagLogic.getArtifacts().length > 0 && this._tabIndex == 3;
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onRefreshHeroList, () => {
            // if (this._tabIndex == TabIndex.Hero) {
            this.filterHeroes(this._selectFactionindex, true);
            // }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onUpdateArtifact, () => {
            this._showArtifact = false;
            this.showArtifact(false);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onUpdateArtifact, () => {
            this._refreshArtifactLvNode();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onStartingGuideStep, (data: { target: GuideBaseStep, step: guideconfigRow }) => {
            if (data.target.node.name == "hero_item") {
                this.onStartGuide(data.target);
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onArtifactLevelUp, () => {
            this._showLevelUp();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onChangeToArtifact, () => {
            this.tabNode.getComponent(TabLoader).switchTab(2);
            this.changeView("3");
        });
        this._eventListeners.push(listener);
    }

    onHeroRender(item: cc.Node, index: number) {
        let hero = HeroInfoPanel.heroList[index];
        item.name = hero.getName();
        item.off("click");
        item.on("click", () => { this.onHeroCardClick(hero) }, this);

        let listItem = item.getComponent(ListItem);
        listItem.isGuideTarget = listItem.listId == this.guideListId;

        let loader = item.getChildByName("hero").getComponent(CommonLoader);
        loader.loaderNode.removeComponent(cc.Button);
        let heroCard = loader.loaderNode.getComponent(HeroCard);
        heroCard.enableAnim = MyHeroView.firstAnimation;
        heroCard.refresh(hero);

        let prompt = item.getComponent(PromptPoint);
        prompt.refresh(hero);
    }

    async showBig() {
        if (this._showBig) {
            return;
        }
        this._showBig = true;
        this._heroIllustrationList = [];

        let sort = function (a: HeroIllustration, b: HeroIllustration) {
            let orderA = a.getFaction();
            if (orderA == Hero.Faction.Super) { orderA = -1; }
            else if (orderA == Hero.Faction.Destroy) { orderA = 0; }

            let orderB = b.getFaction();
            if (orderB == Hero.Faction.Super) { orderB = -1; }
            else if (orderB == Hero.Faction.Destroy) { orderB = 0; }

            return orderA - orderB;
        };

        let list = [];

        let heros = heroLogic.getIllustrations();
        let eternalHeros = heros.where(a => a.getQuality() == Hero.Quality.Eternal);
        if (eternalHeros && eternalHeros.length > 0) {
            eternalHeros.sort(sort);
            this._addHero(4, list, eternalHeros);
            this._heroIllustrationList.pushList(eternalHeros);
        }
        let mythHeros = heros.where(a => a.getQuality() == Hero.Quality.Myth);
        if (mythHeros) {
            mythHeros.sort(sort);
            this._addHero(3, list, mythHeros);
            this._heroIllustrationList.pushList(mythHeros);
        }
        let epicHeros = heros.where(a => a.getQuality() == Hero.Quality.Epic);
        if (epicHeros) {
            epicHeros.sort(sort);
            this._addHero(2, list, epicHeros);
            this._heroIllustrationList.pushList(epicHeros);
        }
        let normalHeros = heros.where(a => a.getQuality() == Hero.Quality.Normal);
        if (normalHeros) {
            normalHeros.sort(sort);
            this._addHero(1, list, normalHeros);
            this._heroIllustrationList.pushList(normalHeros);
        }
        this.heroBigScrollView.getComponent(xScrollView).refresh(list, null, (item, i, dt) => {
            if (dt.prefabIndex == 0) {
                item.getComponent(HeroTitle).refresh(dt.data);
                return 80;
            } else if (dt.prefabIndex == 1) {
                item.getComponent(HeroLayout).init(dt.data);
                return 260;
            }
        });
    }

    protected _addHero(title, list, heros) {
        let data = {};
        data["prefabIndex"] = 0;
        data["data"] = title;
        list.push(data);
        for (let i = 0, len = Math.ceil(heros.length / 4); i < len; i++) {
            let list2 = [];
            for (let index = i * 4, maxIndex = Math.min((i + 1) * 4, heros.length); index < maxIndex; index++) {
                list2.push(heros[index]);
            }
            let data2 = {};
            data2["prefabIndex"] = 1;
            data2["data"] = list2;
            list.push(data2);
        }
    }

    async changeView(index: string) {
        if (this._tabIndex.toString() == index) return;
        this._tabIndex = Number(index);

        this.heroScrollView.active = false;
        this.heroBigNode.active = false;
        this.artifactNode.active = false;
        this.bg2.active = false;
        this.heroBg.active = this.artifactBg.active = false;
        if (index == TabIndex.Hero.toString()) {
            this.heroScrollView.active = true;
            this.heroBg.active = true;
            this.bg2.active = true;
            this.filterHeroes(this._selectFactionindex, true);
        } else if (index == TabIndex.Book.toString()) {
            this.heroBigNode.active = true;
            this.noHero.active = false;
            this.heroBg.active = true;
            this.bg2.active = true;
            this.showBig();
            HeroInfoPanel.heroList = this._heroIllustrationList;
        } else if (index == TabIndex.Artifact.toString()) {
            // this.showArtifact();
            this.artifactNode.active = true;
            this.artifactBg.active = true;
            this.bg2.active = false;
        }
        this.artifactLvNode.active = bagLogic.getArtifacts().length > 0 && this._tabIndex == 3;
        if (this._shenqiSkeletonData == null) {
            await gm.createCommonSpine(`spine/ui/shenqi/Shengqi`, this.shenqi, "animation", true);
            if (!cc.isValid(this.shenqi)) return;
            this._shenqiSkeletonData = this.shenqi.skeletonData;
        }

        if (this._shenqiLvSkeletonData == null) {
            await gm.createCommonSpine(`spine/ui/shenqi/ShengqiLvup`, this.shenqiLv, "Levelup", false);
            if (!cc.isValid(this.shenqiLv)) return;
            this._shenqiLvSkeletonData = this.shenqiLv.skeletonData;
        }
        this.shenqiLv.node.active = false;
    }

    protected async _showLevelUp() {
        if (this._shenqiLvSkeletonData == null) {
            await gm.createCommonSpine(`spine/ui/shenqi/ShengqiLvup`, this.shenqiLv, "Levelup", false);
            if (!cc.isValid(this.shenqiLv)) return;
            this._shenqiLvSkeletonData = this.shenqiLv.skeletonData;
        }
        this.shenqiLv.node.active = true;
        this.shenqiLv.setAnimation(0, "Levelup", false);
    }

    async showArtifact(flag: boolean = true) {
        if (this._showArtifact) {
            return;
        }
        if (flag) {
            await heroLogic.doGetArtifactUnlockInfo();
        }
        this._showArtifact = true;
        for (let i = 1; i <= 7; i++) {
            let artifactNode = cc.find(`artifact${i}`, this.artifactNode).getComponent(CommonLoader);
            if (artifactNode) {
                artifactNode.refreshComponent(i);
            }
        }
    }

    onTabClick(event: cc.Event.EventTouch, index: string) {
        this.changeView(index);
    }

    onFilterClick(event: cc.Event.EventTouch, index: string) {
        let idx = Number(index);
        this.filterHeroes(idx);
    }

    filterHeroes(index: number, isForce: boolean = false) {
        // if (this._tabIndex != TabIndex.Hero) {
        //     return;
        // }
        if (this._selectFactionindex == index && !isForce) {
            return;
        }
        this._selectFactionindex = index;

        if (!isForce) {
            //gm.toast(stringConfigMap[`key_faction_filter_${index}`].Value);
        }

        let heros: PlayerHero[] = [];
        if (index == Hero.Faction.All) {
            heros = heroLogic.getHeroes({ sort: true });
            EManager.emit(EName.onSortedHeroes, heros);
        } else {
            heros = heroLogic.getHeroes({
                filter: (hero: Hero) => { return hero.getFaction() == index },
                sort: true
            });
        }

        this.guideListId = -1;
        if (guideLogic.guideId == 2002) {
            this.guideListId = 0;
            for (let i = 0; i < heros.length; i++) {
                let hero = heros[i];
                if (hero.getName() == '海草') {
                    this.guideListId = i;
                    break;
                }
            }
        }
        else if (guideLogic.guideId == 4007) {
            for (let i = 0; i < heros.length; i++) {
                let hero = heros[i];
                let info = heroUtils.getHeroQualityInfo(hero.getRank());
                if (info.qualityHead == '3') {
                    this.guideListId = i;
                    break;
                }
            }
        }
        else if (guideLogic.guideId == 6002) {
            this.guideListId = 0;
            for (let i = 0; i < heros.length; i++) {
                let hero = heros[i];
                if (hero.getName() == "玉米") {
                    this.guideListId = i;
                    break;
                }
            }
        }
        else if (guideLogic.guideId == 9001) {
            for (let i = 0; i < heros.length; i++) {
                let hero = heros[i];
                let equips = hero.getEquips();
                for (let equip of equips) {
                    if (equip.getRank() > 2 && equip.getStar() < equip.getMaxStar()) {
                        this.guideListId = i;
                        break;
                    }
                }
                if (this.guideListId >= 0) {
                    break;
                }
            }
        }

        HeroInfoPanel.heroList = heros;
        this.heroList.numItems = heros.length;
        this.noHero.active = heros.length == 0;
    }

    onHeroCardClick(hero: Hero) {
        gcc.core.showLayer("prefabs/panel/hero/HeroInfoPanel", { data: { hero: hero, viewType: HeroInfoPanel.ViewType.MyHero, showArrow: true } });
    }

    onStartGuide(step: GuideBaseStep) {
        this.heroList.scrollTo(this.guideListId, 0.02);
        step.delay += 0.02;
    }

    async onAddBag() {
        gm.toast(stringConfigMap.key_auto_573.Value);
    }

    onArtifactLock() {
        if (!UnlockWrapper.isUnlock(unlockConfigMap.神器)) {
            gm.toast(unlockConfigMap.神器.tips);
        }
    }

    onHeroSchool() {
        if (UnlockWrapper.isUnlock(unlockConfigMap.新手学堂)) {
            gcc.core.showLayer("prefabs/panel/hero/HeroSchoolPanel");
        }
    }

    protected async _buyBag() {
        try {
            await playerLogic.doExpandHeroCapacity();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }
}