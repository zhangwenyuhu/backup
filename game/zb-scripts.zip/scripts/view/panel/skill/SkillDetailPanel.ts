import { PopupPanel } from "../BasePanel";
import Skill from "../../../data/card/Skill";
import EManager, { EName } from "../../../manager/EventManager";
import Hero from "../../../data/card/Hero";
import Artifact from "../../../data/card/Artifact";
import stringUtils from "../../../utils/StringUtils";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/skill/SkillDetailPanel")
export default class SkillDetailPanel extends PopupPanel {

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Label)
    skill_name: cc.Label = null;

    @property(cc.RichText)
    skill_desc: cc.RichText = null;

    @property(cc.Node)
    skillNode: cc.Node = null;

    @property(cc.Node)
    skill_level_desc: cc.Node = null;

    colorTemplate: string[] = [
        "<b><color=#BBA74C>Text</color></b>", //yellow
        "<b><color=#C8BD8B>Text</color></b>", //light yellow
        "<b><color=#808080>Text</color></b>", //light grey
        "<b><color=#C43737>Text</color></b>", //解锁等级
        "<b><color=#5BC3C4>Text</color></b>"  //dark grey
    ];

    onInit(data: {
        skill: Skill,
        hero?: Hero,
        artifact?: Artifact,
        offsetY?: number
    }) {
        super.onInit(data);
    }

    onLoad() {
        super.onLoad();

        this.skill_level_desc.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.skill_level_desc.destroy();
    }

    start() {
        super.start();

        this.skill_level_desc.active = false;
        this.skillNode.destroyAllChildren();
        if (this.data.skill) {
            let heroSkillLevels = this.data.skill.getHeroLevels();
            this.skill_name.string = this.data.skill.getName();
            let once: boolean = false;
            if (this.data.skill.isUnlock()) {
                this.skill_name.string += `(Lv.${this.data.skill.getLevel()})`;
                once = true;
            }
            if (this.data.skill.isUnlock()) {
                this.skill_desc.string = this.getColorText(1, this.data.skill.getSkillDesc(1));
            } else {
                this.skill_desc.string = this.getColorText(1, this.data.skill.getSkillDesc(1)) + this.getColorText(3, `(解锁等级:${heroSkillLevels[0]})`);
            }
            if (this.data.artifact) {
                this._addArtifactSkillDesc(this.skillNode, heroSkillLevels, once);
            } else {
                this._addSkillDesc(this.skillNode, heroSkillLevels, once);
            }
        }
        this.content.getComponent(cc.Layout).updateLayout();
        this.node.on(cc.Node.EventType.TOUCH_END, () => {
            EManager.emit(EName.onClosePanel, "SkillDetailPanel");
            this.closePanel();
        }, this);
    }

    protected _addSkillDesc(node, heroSkillLevels, once) {
        for (let i = 0; i < Math.min(4, heroSkillLevels.length); i++) {
            if (i > 0) {
                let descNode = cc.instantiate(this.skill_level_desc);
                descNode.active = true;
                node.addChild(descNode);
                if (heroSkillLevels[i] <= this.data.hero.getLevel()) {
                    //已解锁
                    descNode.getComponent(cc.RichText).string = this.getColorText(4, `Lv.${i + 1}:` + this.data.skill.getSkillDesc(i + 1));
                } else {
                    //未解锁
                    if (this.data.skill.getSkillDesc(i + 1) != "") {
                        descNode.getComponent(cc.RichText).string = this.getColorText(2, `Lv.${i + 1}:` + this.data.skill.getSkillDesc(i + 1));
                        if (once) {
                            once = false;
                            descNode.getComponent(cc.RichText).string += this.getColorText(3, `(解锁等级:${heroSkillLevels[i]})`);
                        }
                    } else {
                        descNode.active = false;
                    }
                }
            }
        }
    }

    protected _addArtifactSkillDesc(node, heroSkillLevels, once) {
        let index = this.data.artifact.getSkills().indexOf(this.data.skill);
        let levels = Array.from(new Set(heroSkillLevels));
        for (let i = 0; i < levels.length; i++) {
            if (i > 0) {
                let descNode = cc.instantiate(this.skill_level_desc);
                descNode.active = true;
                node.addChild(descNode);
                if (levels[i] <= heroSkillLevels[this.data.artifact.getStar()]) {
                    //已解锁
                    descNode.getComponent(cc.RichText).string = this.getColorText(4, `Lv.${i + 1}:` + this.data.skill.getSkillDesc(i + 1));
                } else {
                    //未解锁
                    if (this.data.skill.getSkillDesc(i + 1) != "") {
                        let unlockLabel = "(" + stringUtils.getString(stringConfigMap.key_artifact_skill_unlock.Value, { count: this.data.artifact.getStarByUnlockSkillLevel(i + 1, index == 1) }) + ")";
                        descNode.getComponent(cc.RichText).string = this.getColorText(2, `Lv.${i + 1}:` + this.data.skill.getSkillDesc(i + 1) + unlockLabel);
                        // if (once) {
                        //     once = false;
                        //     descNode.getComponent(cc.RichText).string += this.getColorText(2,
                        // }
                    } else {
                        descNode.active = false;
                    }
                }
            }
        }
    }

    getColorText(index: number, text) {
        let color = this.colorTemplate[index];
        return color.replace("Text", text);
    }

}
