import {PopupPanel} from "../BasePanel";
import Skill from "../../../data/card/Skill";
import EManager, {EName} from "../../../manager/EventManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/skill/SkillGetDetailPanel")
export default class SkillGetDetailPanel extends PopupPanel {

    @property(cc.Node)
    bg: cc.Node = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Label)
    skill_name: cc.Label = null;

    @property(cc.Label)
    skill_desc: cc.Label = null;

    onInit(data: {
        skill: Skill,
        y?: number
    }) {

    }

    onLoad() {
        super.onLoad();
        let listener = EManager.addEvent(EName.onClosePanel, (data) => {
            if (data == "SkillGetDetailPanel") {
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);
    }

    start() {
        super.start();

        if (this.data.y) {
            this.bg.y = this.data.y;
        }
        this.skill_name.string = this.data.skill.getName();
        this.skill_desc.string = this.data.skill.getSkillDesc(1);
        (this.skill_desc as any)._updateRenderData(true);
        this.content.getComponent(cc.Layout).updateLayout();
    }

}