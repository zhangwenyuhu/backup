import { PopupPanel } from "../BasePanel";
import EManager, { EName } from "../../../manager/EventManager";
import Hero from "../../../data/card/Hero";
import { skillspecialconfigRow } from "../../../configs/skillspecialconfig";
import cm from "../../../manager/ConfigManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/skill/HeroSkillPanel")
export default class HeroSkillPanel extends PopupPanel {

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Label)
    skill_name: cc.Label = null;

    @property(cc.RichText)
    skill_desc: cc.RichText = null;

    @property(cc.Node)
    skillNode: cc.Node = null;

    @property(cc.Node)
    skill_level_desc: cc.Node = null;

    colorTemplate: string[] = [
        "<b><color=#BBA74C>Text</color></b>", //yellow
        "<b><color=#C8BD8B>Text</color></b>", //light yellow
        "<b><color=#808080>Text</color></b>", //light grey
        "<b><color=#C43737>Text</color></b>", //解锁等级
        "<b><color=#5BC3C4>Text</color></b>"  //dark grey
    ];

    protected _hero: Hero = null;
    protected _cfg: skillspecialconfigRow = null;
    onInit(data: {
        hero: Hero,
        offsetY?: number
    }) {
        super.onInit(data);
        this._hero = data.hero;
        this._cfg = cm.getHeroSkillConfig(this._hero.getUniqueSkillId());
    }

    onLoad() {
        super.onLoad();

        this.skill_level_desc.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.skill_level_desc.destroy();
    }

    start() {
        super.start();

        if (this.data.offsetY) {
            this.node.children[0].y += this.data.offsetY;
        }
        this.skill_level_desc.active = false;
        this.skillNode.destroyAllChildren();
        //this.skill_desc.node.active = false;
        if (this._hero) {
            let skillLevel: number = this._hero.getHeroSkillLevel();
            let levelStr: string = skillLevel > 0 ? `Lv.${skillLevel}` : '';
            this.skill_name.string = '专属技能' + levelStr;
            for (let i = 1; i <= 9; i++) {
                let desc = this._cfg[`Desc${i}`];
                if (desc && desc != "") {
                    this._addHeroSkillDesc(this.skillNode, i, desc);
                }
            }
        }
        this.content.getComponent(cc.Layout).updateLayout();
        this.node.on(cc.Node.EventType.TOUCH_END, () => {
            EManager.emit(EName.onClosePanel, "HeroSkillPanel");
            this.closePanel();
        }, this);
    }

    protected _addHeroSkillDesc(node: cc.Node, lv: number, desc: string) {
        let star: number = this._hero.getHeroSkillUnlockStar(lv);
        let text: string = '';
        if (lv == 1) {
            if (lv <= this._hero.getHeroSkillLevel()) {
                this.skill_desc.string = this.getColorText(1, desc);
            } else {
                this.skill_desc.string = this.getColorText(1, desc) + this.getColorText(3, `  (升至${star}星激活)`);
            }

        } else {
            let descNode = cc.instantiate(this.skill_level_desc);
            descNode.active = true;
            node.addChild(descNode);
            if (lv <= this._hero.getHeroSkillLevel()) {
                text = this.getColorText(4, `Lv.${lv}:${desc}`);
            } else {
                text = this.getColorText(2, `Lv.${lv}:${desc}`) + this.getColorText(3, `  (升至${star}星解锁)`);
            }
            descNode.getComponent(cc.RichText).string = text;
        }
    }

    getColorText(index: number, text) {
        let color = this.colorTemplate[index];
        return color.replace("Text", text);
    }

}
