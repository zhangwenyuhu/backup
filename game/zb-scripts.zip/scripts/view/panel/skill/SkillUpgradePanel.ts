import { defaultConfigMap } from './../../../configs/defaultConfig';
import { GoodVO } from './../../../proxy/GameProxy';
import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from "../BasePanel";
import Hero from "../../../data/card/Hero";
import heroLevelConfig from "../../../configs/heroLevelConfig";
import bagLogic from "../../../logics/BagLogic";
import Good, { GoodId, GoodType } from "../../../data/card/Good";
import CommonLoader from "../../common/CommonLoader";
import SkillInfo from "../../component/Skill/SkillInfo";
import Skill from "../../../data/card/Skill";
import GoodCard from '../../component/Good/GoodCard';
import EManager from '../../../manager/EventManager';
import gm from '../../../manager/GameManager';
import stringUtils from '../../../utils/StringUtils';
import { ResType } from '../help/ResGotoPanel';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/skill/SkillUpgradePanel")
export default class SkillUpgradePanel extends PopupPanel {
    @property(cc.Label)
    labelTitle: cc.Label = null;

    @property(CommonLoader)
    currentSkill: CommonLoader = null;

    @property(CommonLoader)
    nextSkill: CommonLoader = null;

    @property(cc.Node)
    nodeNew: cc.Node = null;

    @property(cc.Node)
    currentNode: cc.Node = null;

    @property(cc.Node)
    arrowNode: cc.Node = null;

    @property(cc.Node)
    costContainer: cc.Node = null;

    @property(cc.Node)
    costItem: cc.Node = null;

    @property(cc.Color)
    costColors: cc.Color[] = [];

    hero: Hero = null;
    callback: Function = null;
    needGoods: { [key: number]: Good } = {};

    protected _skill: Skill = null;
    protected _needLabels: { [key: number]: cc.Label } = {};
    protected _btnAdds: { [key: number]: cc.Node } = {};

    onInit(data: {
        hero: Hero,
        callback: Function,
        needGoods: { [key: number]: Good }
    }) {
        this.hero = data.hero;
        this.callback = data.callback;
        this.needGoods = data.needGoods;
    }

    onLoad() {
        super.onLoad();
        this.nodeNew.active = false;
        this.costItem.parent = null;

        let listener = EManager.addEvent(Good.Event.onAmountDirty, (data: { target: Good }) => {
            let good = this.needGoods[data.target.getIndex()];
            if (good) { this._updateGoodHas(good.getIndex()); }
        });
        this._eventListeners.push(listener);
    }

    onDestroy() {
        this.costItem.destroy();
        super.onDestroy();
    }

    start() {
        super.start();

        for (let key in this.needGoods) {
            let good = this.needGoods[key];

            let item = cc.instantiate(this.costItem);
            item.parent = this.costContainer;

            let vo = new GoodVO();
            vo.propId = good.getIndex();
            vo.amt = 0;
            let loader = item.getChildByName("good").getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(GoodCard);
            comp.refresh(new Good(vo));
            comp.registerOnGoodInfo();

            let clickCallback = () => {
                if (good.getGoodType() == GoodType.Dust) {
                    gm.lackResGotoPanel(ResType.dust);
                }
                else if (good.getGoodType() == GoodType.Gold) {
                    gm.lackResGotoPanel(ResType.gold);
                }
                else if (good.getGoodType() == GoodType.Exp) {
                    gm.lackResGotoPanel(ResType.exp);
                }
            }

            let costBg = item.getChildByName("cost_bg");
            costBg.on("click", clickCallback, this);
            let btnAdd = costBg.getChildByName("btn_add")
            btnAdd.on("click", clickCallback, this);
            this._btnAdds[key] = btnAdd;

            let values = costBg.getChildByName("values");
            let needLabel = values.getChildByName("need").getComponent(cc.Label);
            needLabel.string = "/" + this._convertNum2Str(good.getAmount());
            let hasLabel = values.getChildByName("has").getComponent(cc.Label);
            this._needLabels[key] = hasLabel;
            this._updateGoodHas(good.getIndex());
        }

        for (let key in this._btnAdds) {
            if (this.needGoods[key].getIndex() != GoodId.Dust) {
                if (this._btnAdds[key].active) {
                    this._btnAdds[key].name = "guideTarget";
                    break;
                }
            }
        }

        let configSkill = heroLevelConfig[this.hero.getLevel()];
        let currentSkill = this.hero.getSkill(configSkill);
        let nextHero = this.hero.clone();
        nextHero.setLevel(nextHero.getLevel(true) + 1);
        let nextSkill = nextHero.getSkill(configSkill);

        if (currentSkill.getLevel() > 0) {
            let currentSkillInfo = this.currentSkill.loaderNode.getComponent(SkillInfo);
            currentSkillInfo.refresh(currentSkill);
        }
        else {
            this.nodeNew.active = true;
            this.currentNode.active = false;
            this.arrowNode.active = false;
            this.labelTitle.string = stringConfigMap.key_unlock_skill.Value;
        }

        let nextSkillInfo = this.nextSkill.loaderNode.getComponent(SkillInfo);
        nextSkillInfo.refresh(nextSkill);

        this._skill = nextSkill;
    }
    /*
    protected _onSearchGood(needGood: Good) {
        let stations = supplyLogic.stations.concat(supplyLogic.seniorStations);
        let datas: { good: Good, station: SupplyStation, needAmt: number }[] = [];
        for (let station of stations) {
            for (let reward of station.rewards) {
                if (needGood.getIndex() == reward.getIndex()) {
                    let amt = Math.max(0, needGood.getAmount() - bagLogic.getGood(reward.getIndex()).getAmount());
                    datas.push({ good: reward, station: station, needAmt: amt });
                    break;
                }
            }
        }
        gcc.core.showLayer("prefabs/panel/supply/SupplySearchListPanel", {
            data: datas
        });
    }*/

    protected _convertNum2Str(amount: number): string {
        if (amount < 10000) {
            return amount.toString();
        }
        return slib.BigNumberHelper.convertNumStr2UnitStr(amount.toString(), 0, 0);
    }

    protected _updateGoodHas(goodId: number) {
        let good = bagLogic.getGood(goodId);
        let label = this._needLabels[goodId];
        label.string = this._convertNum2Str(good.getAmount());
        (label as any)._updateRenderData(true);
        label.node.color = good.getAmount() < this.needGoods[goodId].getAmount() ? this.costColors[1] : this.costColors[0];
        let layout = label.node.parent.getComponent(cc.Layout);
        layout.updateLayout();

        this._btnAdds[goodId].active = good.getAmount() < this.needGoods[goodId].getAmount();
        label.node.parent.x = this._btnAdds[goodId].active ? -19 : 0;
    }

    onSkill() {
        gcc.core.showLayer("prefabs/panel/skill/SkillDetailPanel", {
            data: {
                skill: this._skill,
                hero: this.hero
            },
            modalWindow: false,
            modalTouch: true
        });
    }

    onUpgrade() {
        for (let key in this.needGoods) {
            let needGood = this.needGoods[key];
            let hasGood = bagLogic.getGood(needGood.getIndex());
            if (hasGood.getAmount() < needGood.getAmount()) {
                gm.toast(stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: hasGood.getName() }));
                return;
            }
        }

        if (this.callback) { this.callback(this._skill); }
        this.closePanel();
    }
}
