import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import Hero from "../../../data/card/Hero";
import SkillInfo from "../../component/Skill/SkillInfo";
import Skill from "../../../data/card/Skill";
import loadUtils from '../../../utils/LoadUtils';
import commonUtils from '../../../utils/CommonUtils';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/skill/SkillUpgradeSuccessPanel")
export default class SkillUpgradeSuccessPanel extends PopupPanel {
    @property(CommonLoader)
    skillIcon: CommonLoader = null;

    @property(cc.Node)
    contentBg: cc.Node = null;

    @property(cc.Node)
    propertyItem: cc.Node = null;

    @property(cc.Label)
    labelUnlock: cc.Label = null;

    protected _oldHero: Hero = null;
    protected _newHero: Hero = null;
    protected _skill: Skill = null;

    onInit(data: { oldHero: Hero, newHero: Hero, skill: Skill }) {
        super.onInit(data);
        this._oldHero = data.oldHero
        this._newHero = data.newHero
        this._skill = data.skill;
    }

    onLoad() {
        super.onLoad();
        this.propertyItem.parent = null;
    }

    start() {
        super.start();

        let loader = this.skillIcon.getComponent(CommonLoader);
        loader.loaderNode.getComponent(SkillInfo).refresh(this._skill);

        if (this._skill.getLevel() > 1) {
            this.labelUnlock.string = stringConfigMap.key_skill_upgrade.Value;
        }

        let params = [
            {
                icon: 'property_icon_power',
                label: stringConfigMap.key_power.Value,
                prevValue: this._oldHero.getPower(),
                nextValue: this._newHero.getPower()
            },
            {
                icon: 'property_icon_lv',
                label: stringConfigMap.key_level.Value,
                prevValue: this._oldHero.getLevel(),
                nextValue: this._newHero.getLevel()
            },
            {
                icon: 'property_icon_atk',
                label: stringConfigMap.key_atk.Value,
                prevValue: this._oldHero.getAtk(),
                nextValue: this._newHero.getAtk()
            },
            {
                icon: 'property_icon_def',
                label: stringConfigMap.key_def.Value,
                prevValue: this._oldHero.getDef(),
                nextValue: this._newHero.getDef()
            },
            {
                icon: 'property_icon_hp',
                label: stringConfigMap.key_hp.Value,
                prevValue: this._oldHero.getHp(),
                nextValue: this._newHero.getHp()
            }
        ];
        for (let param of params) {
            let item = cc.instantiate(this.propertyItem);
            item.parent = this.contentBg;

            let sprite = item.getChildByName("icon").getComponent(cc.Sprite);
            loadUtils.loadSpriteFrame(commonUtils.getPropertyIconUrl(param.icon), sprite);

            item.getChildByName("label").getComponent(cc.Label).string = param.label;
            item.getChildByName("prev_value").getComponent(cc.Label).string = `${param.prevValue}`;
            item.getChildByName("next_value").getComponent(cc.Label).string = `${param.nextValue}`;
        }
    }
}
