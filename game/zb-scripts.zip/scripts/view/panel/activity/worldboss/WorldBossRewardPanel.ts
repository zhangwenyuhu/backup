import { WorldBossHurt } from './../../../../data/activity/actconfig/WorldBossActConfig';
import { PopupPanel } from './../../BasePanel';
import List from '../../../common/List';
import activityLogic, { ActivityType } from '../../../../logics/ActivityLogic';
import WorldBossActConfig from '../../../../data/activity/actconfig/WorldBossActConfig';
import ActivityWorldBossRewardItem from '../../../component/Activity/ActivityWorldBossRewardItem';
const { ccclass, property, menu } = cc._decorator;

/**
 * 世界Boss奖励面板
 */
@ccclass
@menu("view/panel/activity/worldboss/WorldBossRewardPanel")
export default class WorldBossRewardPanel extends PopupPanel {
    @property(List)
    listView: List = null;

    protected _hurtDatas: WorldBossHurt[] = [];

    start() {
        super.start();

        let modal = activityLogic.getActivityConfigs(ActivityType.WorldBoss);
        let config = modal.actConfig as WorldBossActConfig;
        this._hurtDatas = config.hurtDatas;
        this.listView.numItems = this._hurtDatas.length;
    }

    onItemRender(item: cc.Node, index: number) {
        let comp = item.getComponent(ActivityWorldBossRewardItem);
        comp.refresh(this._hurtDatas[index]);
    }
}
