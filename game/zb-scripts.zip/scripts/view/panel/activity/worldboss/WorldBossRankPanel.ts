import WorldBossActConfig, { WorldBossRank } from './../../../../data/activity/actconfig/WorldBossActConfig';
import { stringConfigMap } from './../../../../configs/stringConfig';
import activityLogic, { ActivityModal, ActivityType } from './../../../../logics/ActivityLogic';
import GameProxy, { RankListReq, RankListVO } from './../../../../proxy/GameProxy';
import { PopupPanel } from './../../BasePanel';
import List from '../../../common/List';
import RankData from '../../../../data/record/RankData';
import gm from '../../../../manager/GameManager';
import ActivityWorldBossRankItem from '../../../component/Activity/ActivityWorldBossRankItem';
const { ccclass, property, menu } = cc._decorator;

enum TabIndex {
    Rank,
    Bonus
}

/**
 * 世界Boss排名面板
 */
@ccclass
@menu("view/panel/activity/worldboss/WorldBossRankPanel")
export default class WorldBossRankPanel extends PopupPanel {
    @property(List)
    listView: List = null;

    @property(cc.ScrollView)
    scrollView: cc.ScrollView = null;

    @property(ActivityWorldBossRankItem)
    myRank: ActivityWorldBossRankItem = null;

    @property(cc.SpriteFrame)
    itemFrame: cc.SpriteFrame = null;

    @property(cc.Sprite)
    tabSprites: cc.Sprite[] = [];

    @property(cc.Label)
    tabLabels: cc.Label[] = [];

    @property(cc.SpriteFrame)
    tabFrames: cc.SpriteFrame[] = [];

    @property(cc.Widget)
    contentWidget: cc.Widget = null;

    @property(cc.Node)
    titleNodes: cc.Node[] = [];

    @property(cc.Node)
    bottomNodes: cc.Node[] = [];

    @property(cc.Node)
    heroTemplate: cc.Node = null;

    @property(cc.Node)
    equipTemplate: cc.Node = null;

    @property(cc.Node)
    goodTemplate: cc.Node = null;

    protected _modal: ActivityModal = null;
    protected _isRequesting: boolean = false;
    protected _myRankData: RankData = null;
    protected _rankDatas: RankData[] = [];
    protected _rankConfigs: WorldBossRank[] = [];
    protected _callback: Function = null;
    protected _isAllLoad: boolean = false;
    protected _tabIndex: number = -1;

    onInit(callback: Function) {
        super.onInit(callback);
        this._callback = callback;
    }

    onLoad() {
        super.onLoad();

        this.heroTemplate.parent = null;
        this.equipTemplate.parent = null;
        this.goodTemplate.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.heroTemplate.destroy();
        this.equipTemplate.destroy();
        this.goodTemplate.destroy();
    }

    async start() {
        super.start();

        this._modal = activityLogic.getActivityConfigs(ActivityType.WorldBoss);
        let config = this._modal.actConfig as WorldBossActConfig;
        this._rankConfigs = config.rankDatas;

        this._reqRankList();
        this.onTab(null, TabIndex.Rank.toString());
    }

    onItemRender(item: cc.Node, index: number) {
        let comp = item.getComponent(ActivityWorldBossRankItem);
        if (this._tabIndex == TabIndex.Rank) {
            comp.refreshRank(this._rankDatas[index]);
        }
        else {
            comp.refreshBonus(this._rankConfigs[index], {
                hero: this.heroTemplate,
                equip: this.equipTemplate,
                good: this.goodTemplate
            });
        }
        let sprite = item.getComponent(cc.Sprite);
        sprite.spriteFrame = index % 2 == 1 ? null : this.itemFrame;
    }

    onScrollEvents(target: cc.ScrollView, eventType: cc.ScrollView.EventType) {
        if (eventType == cc.ScrollView.EventType.SCROLL_TO_BOTTOM) {
            if (this._isAllLoad) {
                gm.toast(stringConfigMap.key_scroll_to_bottom.Value);
                return;
            }
            if (this._tabIndex == TabIndex.Rank) {
                this._reqRankList();
            }
        }
    }

    onTab(event: cc.Event.EventTouch, index: string) {
        if (this._tabIndex == Number(index)) {
            return;
        }

        let sprite = this.tabSprites[this._tabIndex];
        let label = this.tabLabels[this._tabIndex];
        if (sprite) {
            sprite.spriteFrame = this.tabFrames[0];
            label.node.color = cc.Color.GRAY;
            label.node.y = 34;
            label.fontSize = 28;
        }
        this._tabIndex = Number(index);
        sprite = this.tabSprites[this._tabIndex];
        label = this.tabLabels[this._tabIndex];
        sprite.spriteFrame = this.tabFrames[1];
        label.node.color = cc.Color.WHITE;
        label.node.y = 40;
        label.fontSize = 36;

        for (let i = 0; i < this.titleNodes.length; i++) {
            this.titleNodes[i].active = this._tabIndex == i;
        }
        for (let i = 0; i < this.bottomNodes.length; i++) {
            this.bottomNodes[i].active = this._tabIndex == i;
        }

        if (this._tabIndex == TabIndex.Rank) {
            this.contentWidget.bottom = 142;
            this.contentWidget.updateAlignment();

            if (this._myRankData) {
                this.myRank.node.active = true;
                this.myRank.refreshRank(this._myRankData, true);
            }
            else {
                this.myRank.node.active = false;
            }
            this.listView.getComponent(cc.Widget).updateAlignment();
            this.listView.numItems = this._rankDatas.length;
        }
        else {
            this.contentWidget.bottom = 60;
            this.contentWidget.updateAlignment();
            this.listView.getComponent(cc.Widget).updateAlignment();
            this.listView.numItems = this._rankConfigs.length;
        }
    }

    closePanel() {
        if (this._callback) this._callback(this._rankDatas.slice(0, 3));
        super.closePanel();
    }

    protected async _reqRankList() {
        if (this._isRequesting) return;
        this._isRequesting = true;

        let req = new RankListReq();
        req.customKey = this._modal.id;
        req.start = this._rankDatas.length;
        req.end = this._rankDatas.length + 9;
        let proto = await gm.request<RankListVO>(GameProxy.apirankmyGameRank, req);
        this._myRankData = new RankData(proto.myRank);
        for (let vo of proto.rankDetail) {
            this._rankDatas.push(new RankData(vo));
        }

        if (this._tabIndex != TabIndex.Rank) {
            return;
        }

        this.myRank.node.active = true;
        this.myRank.refreshRank(this._myRankData, true);
        this.listView.numItems = this._rankDatas.length;
        if (proto.rankDetail.length == 0 || this.listView.numItems >= 500) {
            this._isAllLoad = true;
            gm.toast(stringConfigMap.key_scroll_to_bottom.Value);
        }

        this._isRequesting = false;
    }
}
