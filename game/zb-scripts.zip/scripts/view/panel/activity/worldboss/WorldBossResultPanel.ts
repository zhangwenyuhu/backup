import { Storage, BattleType } from './../../../../utils/DefineUtils';
import { EName } from './../../../../manager/EventManager';
import { PopupPanel } from './../../BasePanel';
import EManager from '../../../../manager/EventManager';
import activityLogic, { ActivityType } from '../../../../logics/ActivityLogic';
import WorldBossActConfig from '../../../../data/activity/actconfig/WorldBossActConfig';
import gm from '../../../../manager/GameManager';
import battleLogic from '../../../../logics/BattleLogic';
import storageUtils from '../../../../utils/StorageUtils';
import stringUtils from '../../../../utils/StringUtils';
const { ccclass, property, menu } = cc._decorator;

/**
 * 世界Boss结算面板
 */
@ccclass
@menu("view/panel/activity/worldboss/WorldBossResultPanel")
export default class WorldBossResultPanel extends PopupPanel {
    @property(sp.Skeleton)
    skeleton: sp.Skeleton = null;

    @property(cc.Label)
    labelTotalHurt: cc.Label = null;

    @property(cc.Node)
    nodeNewRecord: cc.Node = null;

    protected _totalHurt: number = 0;
    protected _statistics: rpgfight.HeroContributionStatistic[] = [];
    protected _canExit: boolean = false;

    onInit(data: { totalHurt: number, statistics: rpgfight.HeroContributionStatistic[] }) {
        this._totalHurt = data.totalHurt;
        this._statistics = data.statistics;
    }

    onExit() {
        if (!this._canExit) return;

        this.closePanel();
        EManager.emit(EName.onGameExit, { type: BattleType.WorldBoss });
    }

    async start() {
        super.start();

        let modal = activityLogic.getActivityConfigs(ActivityType.WorldBoss);
        let config = modal.actConfig as WorldBossActConfig;
        gm.createHeroSpine(config.boss, this.skeleton, "");

        this.labelTotalHurt.string = stringUtils.formatValueByWan(this._totalHurt, true);

        let hurt = storageUtils.getNumber({
            Key: Storage.WorldBossHurt.Key + modal.id,
            Default: Storage.WorldBossHurt.Default
        });
        if (this._totalHurt > hurt) {
            storageUtils.setNumber(Storage.WorldBossHurt.Key + modal.id, this._totalHurt, true);
            this.nodeNewRecord.active = true;
        }
        else {
            this.nodeNewRecord.active = false;
        }

        try {
            let report = {
                heroList: battleLogic.getHeroList(),
                result: this._statistics,
                scene: battleLogic.battleData.sceneConfig
            };
            await activityLogic.doCommitWorldBossHurt(this._totalHurt, report);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
        }
        this._canExit = true;
    }
}
