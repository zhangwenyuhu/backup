import { EName } from './../../../manager/EventManager';
import { FullscreenPanel } from './../BasePanel';
import List from '../../common/List';
import commonUtils from '../../../utils/CommonUtils';
import EManager from '../../../manager/EventManager';
import gm from '../../../manager/GameManager';
import loadUtils from '../../../utils/LoadUtils';
import activityLogic, { ActivityType } from '../../../logics/ActivityLogic';
import MonthOrderActConfig from '../../../data/activity/actconfig/MonthOrderActConfig';
import MonthOrderActivityDatas from '../../../data/activity/roleactivitydatas/MonthOrderActivityDatas';
import rechargeLogic from '../../../logics/RechargeLogic';
import { StoreId } from '../../../utils/DefineUtils';
import stringUtils from '../../../utils/StringUtils';
import timeUtils from '../../../utils/TimeUtils';
import cm from '../../../manager/ConfigManager';
import { stringConfigMap } from '../../../configs/stringConfig';
import bagLogic from '../../../logics/BagLogic';
import Good, { GoodId } from '../../../data/card/Good';
import { GoodVO } from '../../../proxy/GameProxy';
const { ccclass, property, menu } = cc._decorator;

enum ProgState {
    Focus,
    Unfocus
}

/**
 * 活动月令面板
 */
@ccclass
@menu("view/panel/activity/ActivityMonthOrderPanel")
export default class ActivityMonthOrderPanel extends FullscreenPanel {

    @property(cc.Label)
    actTs: cc.Label = null;

    @property(List)
    monthOrderList: List = null;

    @property(cc.Node)
    rewardItem: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    progArea: cc.Node = null;

    @property(cc.ProgressBar)
    progBar: cc.ProgressBar = null;

    @property(cc.Node)
    progPoints: cc.Node = null;

    @property(cc.Node)
    progPoint: cc.Node = null;

    @property(cc.Node)
    nowPoint: cc.Node = null;

    @property(cc.SpriteFrame)
    pointFrames: cc.SpriteFrame[] = [];

    @property(cc.SpriteFrame)
    bgFrames: cc.SpriteFrame[] = [];

    @property(cc.Color)
    valueColors: cc.Color[] = [];

    @property(cc.Label)
    nowValue: cc.Label = null;

    @property(cc.Node)
    btnBuy: cc.Node = null;

    @property(cc.Sprite)
    btnDailyReward: cc.Sprite = null;

    @property(cc.Label)
    labelDailyReward: cc.Label = null;

    protected _actLeftTs: number = 0;
    protected _actEnd: boolean = false;

    onLoad() {
        super.onLoad();
        this.heroItem.parent = null;
        this.equipItem.parent = null;
        this.goodItem.parent = null;
        this.rewardItem.parent = null;
        this.progPoint.parent = null;

        this.registerEvents();
    }

    onDestroy() {
        super.onDestroy();

        this.heroItem.destroy();
        this.equipItem.destroy();
        this.goodItem.destroy();
        this.rewardItem.destroy();
        this.progPoint.destroy();
    }

    start() {
        super.start();
        this._refreshList();
        this._refreshNowPoint();
        this._refreshProgressPoints();
        this.schedule(() => { this.freshActivityTime(); }, 1);

        let cfg = cm.getStoreConfig(StoreId.MonthOrder);
        let cost: string = rechargeLogic.getMoneyUnit() + `${cfg.money} 激活月令`;
        this.btnBuy.getComponentInChildren(cc.Label).string = cost;

        let goodId: number = this.moCfg().getDailyRewardId();
        loadUtils.loadSpriteFrame(commonUtils.getGoodSIconUrl(goodId), this.btnDailyReward);

        this.labelDailyReward.string = 'x' + this.moCfg().getDailyRewardNum();
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onApplyOrder, async (data) => {
            if (data && data.storeConfigId == StoreId.MonthOrder) {
                this.moData().setPayed();
                this._refreshList();
                EManager.emit(EName.onUpdateActivityDatas, ActivityType.MonthOrder);
            }
        });
        this._eventListeners.push(listener);
    }

    protected _refreshList() {
        this.btnBuy.active = !this.moData().isPayed();

        this.monthOrderList.getComponent(cc.Widget).updateAlignment();
        this.monthOrderList.numItems = this.moCfg().getMonthOrderData().length;
    }

    onScrollEvent(target: cc.ScrollView, event: cc.ScrollView.EventType) {
        if (event == cc.ScrollView.EventType.SCROLLING) {
            this.progArea.y = target.content.y;
        }
    }

    protected onItemRender(node: cc.Node, index: number) {
        let icon_select: string = 'textures/ui/common/common_select';
        let icon_lock: string = 'textures/ui/common/common_lock';
        let data = this.moCfg().getMonthOrderData()[index];

        let freeRewards: number[][] = this.moCfg().getFreeReward(data.count);
        let freeGot: boolean = this.moData().isRecvFree(`${data.count}`);
        let free = node.getChildByName('free');
        free.destroyAllChildren();
        for (let i = 0; i < freeRewards.length; i++) {
            let tmp = cc.instantiate(this.rewardItem);
            tmp.parent = free;

            let card = gm.showGoodItem(freeRewards[i], {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem
            }, tmp.getChildByName('good'), 0.65);
            if (card) { card.showMask(freeGot); }
            if (freeGot) {
                loadUtils.loadSpriteFrame(icon_select, tmp.getChildByName('lock').getComponent(cc.Sprite));
            }
        }

        let payRewards: number[][] = this.moCfg().getPayReward(data.count);
        let payUnlock: boolean = this.moData().isPayed();
        let payGot: boolean = this.moData().isRecvPay(`${data.count}`);
        let payNode = node.getChildByName('pay');
        payNode.destroyAllChildren();
        for (let i = 0; i < payRewards.length; i++) {
            let tmp = cc.instantiate(this.rewardItem);
            tmp.parent = payNode;

            let card = gm.showGoodItem(payRewards[i], {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem
            }, tmp.getChildByName('good'), 0.65);
            if (card) { card.showMask(payGot || !payUnlock); }
            if (!payUnlock) {
                loadUtils.loadSpriteFrame(icon_lock, tmp.getChildByName('lock').getComponent(cc.Sprite));
            } else {
                if (payGot) {
                    loadUtils.loadSpriteFrame(icon_select, tmp.getChildByName('lock').getComponent(cc.Sprite));
                }
            }
        }

        let reachRecv: boolean = this._getCurrentValue() >= data.count;
        let btnFree = node.getChildByName('btnFree').getComponent(cc.Button);
        let btnPay = node.getChildByName('btnPay').getComponent(cc.Button);

        btnFree.interactable = reachRecv;
        btnFree.node.active = !freeGot;
        btnPay.node.active = freeGot && !payGot && reachRecv;
        btnFree.clickEvents[0].customEventData = `${data.count}`;
        btnPay.clickEvents[0].customEventData = `${data.count}`;
        node.getChildByName('recved').active = reachRecv && freeGot && payGot;
    }

    async onClickGetFree(sender: cc.Event.EventTouch, customData: string) {
        if (this.moData().isRecvFree(customData)) { return; }
        try {
            await activityLogic.recvMonthOrderReward(customData, this.moModal().id);
            this.moData().setRecved(customData);
            this._refreshList();
            this._refreshNowPoint();
            this._refreshProgressPoints();
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.MonthOrder);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
    async onClickGetPay(sender: cc.Event.EventTouch, customData: string) {
        if (this.moData().isRecvPay(customData)) { return; }
        if (!this.moData().isPayed()) {
            gm.dialog({
                title: '活动月令',
                content: '购买活动月令可激活额外奖励,是否前往激活?',
                okText: '前往',
                noCancel: false,
                confirm: () => {
                    gcc.core.showLayer("prefabs/panel/activity/MonthOrderPanel");
                }
            })
            return;
        }

        try {
            await activityLogic.recvMonthOrderReward(customData, this.moModal().id);

            this.moData().setRecved(customData);
            this._refreshList();
            this._refreshNowPoint();
            this._refreshProgressPoints();
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.MonthOrder);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
    async onClickBuy(sender: cc.Event.EventTouch, customData: string) {
        if (this.moData().isPayed()) { return; }
        gcc.core.showLayer("prefabs/panel/activity/MonthOrderPanel");
    }

    onClickGoShop() {
        gcc.core.showLayer("prefabs/panel/activity/MonthOrderShopPanel");
    }

    onClickDailyReward() {
        let goodId: number = this.moCfg().getDailyRewardId();
        let num: number = this.moCfg().getDailyRewardNum();
        let vo = new GoodVO();
        vo.amt = num;
        vo.propId = goodId;
        let good = new Good(vo);
        gcc.core.showLayer("prefabs/panel/bag/BagInfoPanel", {
            modalTouch: true,
            data: { good: good, noUse: true },
        });
    }

    protected freshActivityTime() {
        // 活动持续时间
        let endTs: number = this.moModal().closeAt;
        let leftSec: number = (endTs - gm.getCurrentTimestamp()) / 1000;
        this.checkActTime();

        let title: string = "";
        if (this._actEnd) {
            let ex: string = leftSec > 0 ? timeUtils.formatTime(leftSec) : "00:00:00";
            title = `活动已结束 `;
        } else {
            title = stringUtils.getString(stringConfigMap.key_activity_remain_time.Value, {
                time: timeUtils.formatDay(leftSec * 1000, true)
            });
        }
        this.actTs.string = title;
    }

    protected checkActTime() {
        let endTs: number = this.moModal().closeAt;
        let leftSec: number = (endTs - gm.getCurrentTimestamp()) / 1000;
        this._actEnd = leftSec <= 0;
    }

    protected _refreshNowPoint() {
        let layout = this.monthOrderList.content.getComponent(cc.Layout);
        let len = (this.monthOrderList.tmpNode.height + layout.spacingY) * (this.monthOrderList.numItems - 1);
        this.progBar.node.height = len;
        this.progBar.totalLength = len;
        this.progBar.progress = this._getCompletePercent();

        let worldPosition = this.progBar.barSprite.node.convertToWorldSpaceAR(cc.p(0, this.progBar.barSprite.node.height));
        let position = this.nowPoint.parent.convertToNodeSpaceAR(worldPosition);
        this.nowPoint.position = position;
        this.nowValue.string = this._getCurrentValue().toString();

        let infos = this.moData().getRecvInfo();
        let nowInfo = infos.find((a) => { return a.tag == `${this._getCurrentValue()}`; })
        this.nowValue.node.parent.active = nowInfo ? false : true;
    }

    protected _refreshProgressPoints() {
        let listLayout = this.monthOrderList.content.getComponent(cc.Layout);
        let layout = this.progPoints.getComponent(cc.Layout);
        layout.spacingY = this.monthOrderList.tmpNode.height + listLayout.spacingY;

        if (this.progPoints.childrenCount == 0) {
            for (let i = 0; i < this.monthOrderList.numItems; i++) {
                let progressPoint = cc.instantiate(this.progPoint);
                progressPoint.parent = this.progPoints;
            }
        }
        for (let i = 0; i < this.progPoints.childrenCount; i++) {
            let child = this.progPoints.children[i];
            let condition = this.moCfg().getMonthOrderData()[i].count;
            let isComplete = this._getCurrentValue() >= condition;

            let pointNode = child.getChildByName("point");
            let sprite = pointNode.getComponent(cc.Sprite);
            sprite.spriteFrame = this.pointFrames[isComplete ? ProgState.Focus : ProgState.Unfocus];

            let bgNode = child.getChildByName("bg");
            bgNode.active = !isComplete || this._getCurrentValue() == condition;
            if (this._getCurrentValue() < condition) {
                sprite = bgNode.getComponent(cc.Sprite);
                sprite.spriteFrame = this.bgFrames[ProgState.Unfocus];

                let valueNode = bgNode.getChildByName("value");
                valueNode.color = this.valueColors[ProgState.Unfocus];
                let labelValue = valueNode.getComponent(cc.Label);
                labelValue.string = condition.toString();
            } else if (this._getCurrentValue() == condition) {
                sprite = bgNode.getComponent(cc.Sprite);
                sprite.spriteFrame = this.bgFrames[ProgState.Focus];

                let valueNode = bgNode.getChildByName("value");
                valueNode.color = this.valueColors[ProgState.Focus];
                let labelValue = valueNode.getComponent(cc.Label);
                labelValue.string = condition.toString();
            }
        }
    }

    protected _getCompletePercent(): number {
        if (!this.moCfg().getMonthOrderData() || this.moCfg().getMonthOrderData().length <= 0) { return 0; }

        let completeNum: number = 0;
        let total: number = (this.moCfg().getMonthOrderData().length - 1) * 2;
        let data = this.moCfg().getMonthOrderData()
        for (let i = 0; i < data.length; i++) {
            if (data[i].count <= this._getCurrentValue()) { completeNum += 1; }
        }
        completeNum -= 1;
        completeNum = completeNum < 0 ? 0 : completeNum;

        let recvs = this.moData().getRecvInfo();
        let lastTag: number = 0;
        let preTag: number = 0;
        for (let i = 0; i < recvs.length; i++) {
            let tag = parseInt(recvs[i].tag);
            if (this._getCurrentValue() < tag) {
                lastTag = tag;
                break;
            }
            preTag = tag;
            lastTag = tag;
        }
        if (preTag >= lastTag) { return 1; }
        let exScore: number = this._getCurrentValue() - preTag;
        exScore = exScore <= 0 ? 0 : exScore;
        let perEx: number = 2 * (exScore / (lastTag - preTag)) / total

        return completeNum * 2 / total + perEx;
    }
    protected _getCurrentValue(): number {
        return this.moData().getNowValue();
    }
    protected moModal() {
        return activityLogic.getActivityConfigs(ActivityType.MonthOrder);
    }
    protected moData(): MonthOrderActivityDatas {
        return this.moModal().roleActivityDatas as MonthOrderActivityDatas;
    }
    protected moCfg(): MonthOrderActConfig {
        return this.moModal().actConfig as MonthOrderActConfig;
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("act_monthorder_bg"), type: cc.SpriteFrame });

        try {
            await activityLogic.activityReq(ActivityType.MonthOrder);
        } catch (e) {
            console.error(e);
        }
    }
}
