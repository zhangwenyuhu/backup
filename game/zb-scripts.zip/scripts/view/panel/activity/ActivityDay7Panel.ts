import { ActivityAccumDayData } from './../../../data/activity/ActivityAccumData';
import { stringConfigMap } from './../../../configs/stringConfig';
import { EName } from './../../../manager/EventManager';
import { RefreshLabel } from './../../../decorator/RefreshDecorator';
import { FullscreenPanel } from './../BasePanel';
import List from '../../common/List';
import Good from '../../../data/card/Good';
import bagLogic from '../../../logics/BagLogic';
import commonUtils from '../../../utils/CommonUtils';
import activityLogic, { ActivityType } from '../../../logics/ActivityLogic';
import EManager from '../../../manager/EventManager';
import stringUtils from '../../../utils/StringUtils';
import timeUtils from '../../../utils/TimeUtils';
import ActivityAccumDayItem from '../../component/Activity/ActivityAccumDayItem';
import ActivityPromotionItem from '../../component/Activity/ActivityPromotionItem';
import gm from '../../../manager/GameManager';
import Card from '../../../data/card/Card';
import CommonLoader from '../../common/CommonLoader';
import HeroCard from '../../component/Hero/HeroCard';
import EquipCard from '../../component/Equip/EquipCard';
import Equip from '../../../data/card/Equip';
import GoodCard from '../../component/Good/GoodCard';
import Hero from '../../../data/card/Hero';
import loadUtils from '../../../utils/LoadUtils';
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityDay7Panel")
export default class ActivityDay7Panel extends FullscreenPanel {
    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => {
            return bagLogic.getGood(Good.GoodId.Gold)
        },
        getValue: (good: Good) => {
            let amount = stringUtils.formatAmount(good.getAmount());
            return amount;
        }
    })
    @property(cc.Label)
    goldLabel: cc.Label = null;

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => {
            return bagLogic.getGood(Good.GoodId.Diamond)
        },
        getValue: (good: Good) => {
            return stringUtils.formatAmount(good.getAmount());
        }
    })
    @property(cc.Label)
    diamondLabel: cc.Label = null;

    @property(cc.Node)
    heroTemplate: cc.Node = null;

    @property(cc.Node)
    equipTemplate: cc.Node = null;

    @property(cc.Node)
    goodTemplate: cc.Node = null;

    @property(cc.Label)
    labelTimestamp: cc.Label = null;

    @property(List)
    listView: List = null;

    @property(List)
    listTab: List = null;

    @property(cc.SpriteFrame)
    tabFrames: cc.SpriteFrame[] = [];

    @property(cc.Color)
    tabColors: cc.Color[] = [];

    @property(ActivityPromotionItem)
    promotionItem: ActivityPromotionItem = null;

    @property(cc.Node)
    infoLayer: cc.Node = null;

    @property(cc.Node)
    btnGift: cc.Node = null;

    @property(cc.Node)
    giftClaimed: cc.Node = null;

    @property(cc.Node)
    pro: cc.Node = null;

    @property(cc.Node)
    days: cc.Node = null;

    @property(cc.Node)
    day: cc.Node = null;

    @property(cc.Node)
    topBarNode: cc.Node = null;

    protected _currentDay: number = 1;
    protected _lastDay: number = 0;
    protected _dayConfigs: any[] = [];
    protected _daysInfo: { node: cc.Node, index: number }[] = [];

    onLoad() {
        super.onLoad();
        this.heroTemplate.parent = null;
        this.equipTemplate.parent = null;
        this.goodTemplate.parent = null;
        this.day.parent = null;

        this.promotionItem.heroTemplate = this.heroTemplate;
        this.promotionItem.equipTemplate = this.equipTemplate;
        this.promotionItem.goodTemplate = this.goodTemplate;

        this.registerEvents();
    }

    onDestroy() {
        super.onDestroy();

        this.heroTemplate.destroy();
        this.equipTemplate.destroy();
        this.goodTemplate.destroy();
        this.day.destroy();
    }

    start() {
        super.start();

        this._updateTimestamp();
        this._focusCurrentDay();
        this._updateGift();
        //this.listTab.numItems = 7;
        if (this._currentDay >= 1 && this._currentDay <= 7) {
            //this.listTab.scrollTo(this._currentDay - 1, 0.2);
        }
        this.freshDays();
        this.checkTopBar();
    }

    checkTopBar() {
        let topBar = this.topBarNode.getComponent(cc.Widget);
        if (topBar) {
            let maxTop = 80;
            topBar.top = topBar.top > maxTop ? maxTop : topBar.top;
        }
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onApplyOrder, async () => {
            try {
                await activityLogic.activityReq(ActivityType.Day7);
                await activityLogic.activityReq(ActivityType.Promotion);
                this._updateTimestamp();
                this._focusCurrentDay();
                this._updateGift();
            } catch (e) {
                console.error(e);
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onTouch, () => {
            if (this.infoLayer.active) {
                this.infoLayer.active = false;
            }
        });
        this._eventListeners.push(listener);
    }

    async freshDays() {
        if (this._daysInfo.length <= 0) {
            this.days.destroyAllChildren();
            for (let i = 0; i < 7; i++) {
                let tmp = cc.instantiate(this.day);
                tmp.parent = this.days;
                let index: number = i + 1;
                tmp.getComponent(cc.Button).clickEvents[0].customEventData = `${index}`;
                tmp.getChildByName("label").getComponent(cc.Label).string = `${index}`;

                this._daysInfo.push({ node: tmp, index: index });
            }
            this.pro.getComponent(cc.ProgressBar).progress = this._currentDay / 7;
        }
        for (let j = 0; j < this._daysInfo.length; j++) {
            let data = this._daysInfo[j];
            let iconName: string = "common_flag_a3";

            iconName = data.index > this._currentDay ? "common_flag_a1" : iconName;
            iconName = data.index == this._lastDay ? "common_flag_a2" : iconName;
            let spr = data.node.getChildByName("icon").getComponent(cc.Sprite);
            await loadUtils.loadSpriteFrame(commonUtils.getCommonUrl(iconName), spr);

            let fonSize: number = data.index == this._lastDay ? 39 : 28;
            let color = data.index == this._lastDay ? cc.Color.WHITE : cc.Color.WHITE.fromHEX("c6c8f3");
            let label = data.node.getChildByName("label");
            label.getComponent(cc.Label).fontSize = fonSize;
            label.color = color;
        }
    }

    onClickDay(sender: cc.Event.EventTouch, index: string) {
        let day = parseInt(index);
        this._onTab(day);
        this.freshDays();
    }

    async onClickGift() {
        let modal = activityLogic.getActivityConfigs(ActivityType.Day7);
        if (modal) {
            let data = modal.getData(`${-1}-${5}`);
            if (data && data.claimable) {
                try {
                    await activityLogic.doClaimBonus(data, modal.id, modal.type);
                    data.markClaimed();
                    EManager.emit(EName.onUpdateActivityDatas, modal.type);
                } catch (e) {
                    if (e.name == "ToastError") {
                        gm.toast(e.message);
                    }
                    else {
                        throw e;
                    }
                }
            }
            else {
                if (this.infoLayer.active) {
                    this.infoLayer.active = false;
                    return;
                }

                this.infoLayer.active = true;
                this.infoLayer.destroyAllChildren();

                let cards = modal.getRewards();
                for (let card of cards) {
                    let node: cc.Node = null;
                    if (card.getType() == Card.Type.Equip) {
                        node = cc.instantiate(this.equipTemplate);

                        let loader = node.getComponent(CommonLoader);
                        let comp = loader.loaderNode.getComponent(EquipCard);
                        comp.refresh({ equip: card as Equip });
                    }
                    else if (card.getType() == Card.Type.Good) {
                        node = cc.instantiate(this.goodTemplate);

                        let loader = node.getComponent(CommonLoader);
                        let comp = loader.loaderNode.getComponent(GoodCard);
                        comp.refresh(card as Good);
                    }
                    else if (card.getType() == Card.Type.Hero) {
                        node = cc.instantiate(this.heroTemplate);

                        let loader = node.getComponent(CommonLoader);
                        let comp = loader.loaderNode.getComponent(HeroCard);
                        comp.refresh(card as Hero);
                    }
                    if (node) {
                        node.scale = 0.75;
                        node.parent = this.infoLayer;
                    }
                }
            }
        }
    }

    onAccumItemRender(item: cc.Node, index: number) {
        let modal = activityLogic.getActivityConfigs(ActivityType.Day7);
        if (modal) {
            let comp = item.getComponent(ActivityAccumDayItem);
            comp.heroTemplate = this.heroTemplate;
            comp.equipTemplate = this.equipTemplate;
            comp.goodTemplate = this.goodTemplate;
            comp.isExpired = this._lastDay != this._currentDay;
            comp.refresh(this._dayConfigs[index], modal.id, modal.type, modal.isValid);
        }
    }

    onTabItemRender(item: cc.Node, index: number) {
        let labelNode = item.getChildByName("label");
        labelNode.color = (index + 1) == this._lastDay ? this.tabColors[0] : this.tabColors[1];

        let label = labelNode.getComponent(cc.Label);
        label.string = stringUtils.getString(stringConfigMap.key_day.Value, { day: index + 1 });

        let sprite = item.getComponent(cc.Sprite);
        sprite.spriteFrame = (index + 1) == this._lastDay ? this.tabFrames[0] : this.tabFrames[1];

        item.off("click");
        item.on("click", this._onTab.bind(this, index + 1), this);
    }

    protected _updateTimestamp() {
        let modal = activityLogic.getActivityConfigs(ActivityType.Day7);
        if (modal && modal.isValid) {
            this.labelTimestamp.string = stringUtils.getString(stringConfigMap.key_activity_remain_time.Value,
                { time: timeUtils.formatDay(modal.remainTime, true) });
        }
        else {
            this.labelTimestamp.string = stringConfigMap.key_activity_finished.Value;
        }
    }

    protected _focusCurrentDay() {
        this._currentDay = 1;

        let modal = activityLogic.getActivityConfigs(ActivityType.Day7);
        for (let config of modal.configs) {
            let data = modal.getData(`${config.dayEffect}-${config.count * 100}`) as ActivityAccumDayData;
            if (data) {
                this._currentDay = Math.max(data.day, this._currentDay);
            }
        }
        this._onTab(this._currentDay, true);
    }

    protected _updateGift() {
        let modal = activityLogic.getActivityConfigs(ActivityType.Day7);
        let data = modal.getData(`${-1}-${5}`);
        if (data && data.claimed) {
            this.btnGift.color = cc.Color.GRAY;
            this.giftClaimed.active = true;
        }
        else {
            this.btnGift.color = cc.Color.WHITE;
            this.giftClaimed.active = false;
        }
    }

    protected _onTab(day: number, isForce: boolean = false) {
        if (this._lastDay == day && !isForce) {
            return;
        }
        if (day > this._currentDay) {
            gm.toast(stringUtils.getString(stringConfigMap.key_day_lock.Value, { day: day }));
            return;
        }

        let lastDay = this._lastDay;
        this._lastDay = day;
        //this.listTab.updateItem(lastDay - 1);
        //this.listTab.updateItem(day - 1);

        let modal = activityLogic.getActivityConfigs(ActivityType.Day7);
        let configs = modal.configs.filter((a: any) => { return a.dayEffect == this._lastDay })
        configs.sort((a: any, b: any) => { return a.count - b.count });
        this._dayConfigs = configs;
        this.listView.numItems = this._dayConfigs.length;

        modal = activityLogic.getActivityConfigs(ActivityType.Promotion);
        if (modal) {
            this.promotionItem.node.active = true;
            this.promotionItem.refresh(modal.configs[day - 1], modal.id, modal.type, modal.isValid);
        }
        else {
            this.promotionItem.node.active = false;
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("activity_bg_day7"), type: cc.SpriteFrame });

        try {
            await activityLogic.activityReq(ActivityType.Day7);
            await activityLogic.activityReq(ActivityType.Promotion);
        } catch (e) {
            console.error(e);
        }
    }
}
