import {PopupPanel} from "../BasePanel";
import activityLogic, {ActivityType} from "../../../logics/ActivityLogic";
import {RankVO} from "../../../proxy/GameProxy";
import CommonLoader from "../../common/CommonLoader";
import ActivityRankTop from "../../component/Activity/ActivityRankTop";
import ActivityLastRankItem from "../../component/Activity/ActivityLastRankItem";
import cm from "../../../manager/ConfigManager";
import ActiveListconfig from "../../../configs/ActiveListconfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityLastRankPanel")
export default class ActivityLastRankPanel extends PopupPanel {

    @property(cc.Node)
    emptyNode: cc.Node = null;

    @property(cc.Label)
    text: cc.Label = null;

    protected _activityType;

    onInit(data: ActivityType) {
        super.onInit(data);
        this._activityType = data;
    }

    start() {
        super.start();
        let ranks: RankVO[] = activityLogic.cycleLastRank;
        for (let i = 1; i <= 3; i++) {
            let rankHead = cc.find(`bg/rank${i}`, this.node);
            let item = cc.find(`bg/item${i}`, this.node);
            if (ranks[i - 1]) {
                rankHead.getComponent(CommonLoader).loaderNode.getComponent(ActivityRankTop).refresh(ranks[i - 1]);
                item.getComponent(CommonLoader).loaderNode.getComponent(ActivityLastRankItem).refresh(ranks[i - 1]);
                item.active = true;
            } else {
                let rankVo = new RankVO();
                rankVo.no = i;
                rankHead.getComponent(CommonLoader).loaderNode.getComponent(ActivityRankTop).refresh(rankVo);
                item.active = false;
            }
        }
        this.emptyNode.active = ranks.length == 0;
        let config = cm.getGoodConfig(ActiveListconfig.find(a => a.Activeid == this._activityType).GoodId);
        this.text.string = config.name;
    }

}
