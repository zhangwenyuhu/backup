import { sevenDaysNewConfigRow } from './../../../configs/sevenDaysNewConfig';
import { FullscreenPanel } from "../BasePanel";
import activityLogic, { ActivityType } from "../../../logics/ActivityLogic";
import gm from "../../../manager/GameManager";
import timeUtils from "../../../utils/TimeUtils";
import playerLogic from "../../../logics/PlayerLogic";
import CommonLoader from "../../common/CommonLoader";
import ActivityTab from "../../component/Activity/ActivityTab";
import EManager, { EName } from "../../../manager/EventManager";
import loadUtils from "../../../utils/LoadUtils";
import commonUtils from "../../../utils/CommonUtils";
import { PromptType } from "../../../data/prompt/PromptModal";
import ActivityTab2 from "../../component/Activity/ActivityTab2";
import sevenDaysNewConfig from "../../../configs/sevenDaysNewConfig";
import TabLoader from "../../common/loader/TabLoader";
import Tab from "../../component/Tab";
import promptLogic from "../../../logics/PromptLogic";
import ActivityTask3Item from "../../component/Activity/ActivityTask3Item";
import List from "../../common/List";
import ActivityTask4Item from '../../component/Activity/ActivityTask4Item';
import { MainTaskInfoVO } from '../../../proxy/GameProxy';

const { ccclass, property, menu } = cc._decorator;

/**
 * 新兵任务面板
 */
@ccclass
@menu("view/panel/activity/ActivityNew2Panel")
export default class ActivityNew2Panel extends FullscreenPanel {

    @property(CommonLoader)
    topBar: CommonLoader = null;

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Label)
    finishTime: cc.Label = null;

    @property(List)
    taskList: List = null;

    @property(cc.Node)
    tabNode: cc.Node = null;

    @property(cc.Node)
    tab2Node: cc.Node = null;

    @property(cc.Node)
    itemNode: cc.Node = null;

    @property(cc.Node)
    itemTemplate: cc.Node = null;

    @property(cc.Node)
    stageNode: cc.Node = null;

    @property(cc.Node)
    messageBg: cc.Node = null;

    protected _day: number = 1;
    protected _tab2: number = 1;
    protected _tasks: { config: sevenDaysNewConfigRow, data: MainTaskInfoVO }[] = [];
    protected _tabName = ["今日福利", "我要变强", "副本挑战", "收集"];
    protected _isToday: boolean = false;
    protected _dayOffset: number = 0;

    onLoad() {
        super.onLoad();

        this.messageBg.parent = null;
        this.itemTemplate.parent = null;
        this.stageNode.active = false;

        let listener = EManager.addEvent(EName.onClosePanel, (data) => {
            if (data == "ActivityNew2Panel") {
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.PromptRefresh, () => {
            this._showTabRed();
        });
        this._eventListeners.push(listener);
    }

    onDestroy() {
        super.onDestroy();

        this.itemTemplate.destroy();

        ActivityTab.lastSelectTab = null;
        EManager.emit(EName.onUpdateActivityDatas, ActivityType.NewPlayerTask);
        EManager.emit(EName.onUpdateActivityDatas, ActivityType.NewPlayer2Task);
        EManager.emit(EName.onRedDirty, PromptType.LeftMenuBtn);
    }

    start() {
        super.start();

        this.topBar.loaderNode;
        this._updateView();
    }

    protected getDefaultTab() {
        let nowDay = activityLogic.whichDay();
        let showDay: number = nowDay;
        for (let i = 1 + this._dayOffset; i <= 5 + this._dayOffset; i++) {
            if (i <= nowDay) {
                let hasReward: boolean = activityLogic.sevenNew.hasUnRecvTaskRewardByDay(i);
                showDay = hasReward ? i : showDay;
            }
        }
        return showDay;
    }

    protected getDefaultSubTab(day: number) {
        let subTab: number = 1;
        for (let i = 1 + this._dayOffset; i < 5 + this._dayOffset; i++) {
            if (activityLogic.sevenNew.hasUnRecvTaskRewardByDay(day, i)) {
                subTab = i;
                break;
            }
        }
        return subTab;
    }

    protected _showTaskTop() {
        this.itemNode.destroyAllChildren();

        let index = this.stageNode.active ? -2 : -1;
        let tasks = activityLogic.sevenNew.taskInfo.where(a => sevenDaysNewConfig[a.taskId - 1].days == index);
        for (let i = 0; i < tasks.length; i++) {
            let item = cc.instantiate(this.itemTemplate);
            item.parent = this.itemNode;

            let loader = item.getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(ActivityTask3Item);
            comp.refresh(tasks[i]);
            if (i == tasks.length - 1) {
                comp.showBg();
            }
        }
    }

    protected _showTabRed() {
        this.scheduleOnce(() => {
            let children = this.tab2Node.children.where(a => cc.isValid(a, true));
            for (let i = 0; i < children.length; i++) {
                let tabNode = children[i];
                let index = this._tabName.indexOf(tabNode.getComponent(Tab).geTabName());
                tabNode.getComponent(Tab).refreshRedPoint(activityLogic.sevenNew.hasUnRecvTaskRewardByDay(this._day, index + 1));
            }
        });
    }

    protected _showTask(day: number) {
        this._tasks = [];

        let taskData = activityLogic.sevenNew.getTaskByDay(day);
        taskData = taskData.where(a => a.type2 == this._tab2);
        for (let data of taskData) {
            let vo = activityLogic.sevenNew.taskInfo.find(a => a.taskId == data.Id);
            if (vo) { this._tasks.push({ config: data, data: vo }); }
        }
        this._tasks.sort((a, b) => {
            let aRecv = a.data.recv ? 1 : 0;
            let bRecv = b.data.recv ? 1 : 0;
            if (aRecv == bRecv) return a.config.Id - b.config.Id;
            return aRecv - bRecv;
        });

        this._day = day;
        this._isToday = this._day == activityLogic.whichDay();
        this.taskList.numItems = this._tasks.length;
    }

    protected _getCompByDay(index: string) {
        let node = cc.find(`tab${Number(index) - this._dayOffset}`, this.tabNode);
        let tabComp = node.getComponent(CommonLoader).loaderNode.getComponent(ActivityTab2);
        return tabComp;
    }

    protected _lockTab(index: string) {
        this._getCompByDay(index).lockTab();
        let node = cc.find(`tab${index}`, this.tabNode);
        node.getComponent(cc.Button).enableAutoGrayEffect = true;
        node.getComponent(cc.Button).interactable = false;
    }

    protected _unLockTab(index: string) {
        this._getCompByDay(index).unLockTab();
        let node = cc.find(`tab${index}`, this.tabNode);
        node.getComponent(cc.Button).enableAutoGrayEffect = true;
        node.getComponent(cc.Button).interactable = true;
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);
        loadUtils.releaseAssetRecursively(this.bg.spriteFrame);
    }

    protected async _updateView(day?: number) {
        await activityLogic.doGetSevenNewTaskInfo();

        let finish = playerLogic.getPlayer().getCreateTs() + 14 * 24 * 3600 * 1000;
        if (gm.getCurrentTimestamp() > finish) {
            this.finishTime.string = "活动已结束";
            this.stageNode.active = true;
            this._dayOffset = 7;
        } else {
            finish = playerLogic.getPlayer().getCreateTs() + 7 * 24 * 3600 * 1000;
            if (gm.getCurrentTimestamp() > finish) {
                this.stageNode.active = true;
                this._dayOffset = 7;
            }
            else {
                this.stageNode.active = false;
                this._dayOffset = 0;
            }
            let diffTime = finish - gm.getCurrentTimestamp();
            this.finishTime.string = "活动剩余时间：" + timeUtils.formatDay(diffTime, true);
        }

        let today = activityLogic.whichDay();
        for (let i = 1 + this._dayOffset; i <= 5 + this._dayOffset; i++) {
            this._getCompByDay(i.toString()).refresh(i.toString());

            let selectUrl: string = commonUtils.getPanelIconUrl(`activity_common`, `common_tab_2`);
            let unSelectUrl: string = commonUtils.getPanelIconUrl(`activity_common`, `common_tab_1`);
            let tab = this.tabNode.getChildByName(`tab${i - this._dayOffset}`);
            if (i == today) {
                this.messageBg.parent = tab;
                if (i == 5 + this._dayOffset) {
                    this.messageBg.scaleX = -1;
                    this.messageBg.getChildByName("label").scaleX = -1;
                }
                else {
                    this.messageBg.scaleX = 1;
                    this.messageBg.getChildByName("label").scaleX = 1;
                }
            }

            let child = tab.getComponent(CommonLoader).loaderNode;
            child.getComponent(ActivityTab2).freshImage(selectUrl, unSelectUrl);
            if (i <= today) {
                this._unLockTab(i.toString());
            } else {
                this._lockTab(i.toString());
            }
        }

        let showDay: number = day ? day : this.getDefaultTab();
        this._tab2 = this.getDefaultSubTab(showDay);
        this._getCompByDay(showDay.toString()).selectTab();
        this._showTask(showDay);
        this._showTaskTop();
        this._showTabRed();
        this.tab2Node.getComponent(TabLoader).switchTab(this._tab2 - 1);

        if (!activityLogic.sevenNew.hasUnRecvTaskReward) {
            promptLogic.setPromptRead([15]);
        }
    }

    onTaskItemRender(item: cc.Node, index: number) {
        let task = this._tasks[index];
        let comp = item.getComponent(ActivityTask4Item);
        comp.refresh(task, this.stageNode.active ? ActivityType.NewPlayer2Task : ActivityType.NewPlayerTask);
        comp.flagDouble.active = this._isToday;
        comp.rewardCallback = () => { this._updateView(this._day); }
    }

    onDay(event: cc.Event.EventTouch, index: string) {
        this._tab2 = this.getDefaultSubTab(parseInt(index));
        this._getCompByDay(index).selectTab();
        this._showTask(parseInt(index));
        this.tab2Node.getComponent(TabLoader).switchTab(this._tab2 - 1);
        this._showTabRed();
    }

    onTab(event: cc.Event.EventTouch, index: string) {
        this._tab2 = Number(index);
        this._showTask(this._day);
    }

    onBack() {
        EManager.emit(EName.onActivityBtnFresh, "activity");
        this.closePanel();
    }

}