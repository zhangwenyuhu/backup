import { FullscreenPanel } from "../BasePanel";
import List from "../../common/List";
import activityLogic, { ActivityModal, ActivityType } from "../../../logics/ActivityLogic";
import ExchangeActConfig from "../../../data/activity/actconfig/ExchangeActConfig";
import ActivityExchangeItem from "../../component/Activity/ActivityExchangeItem";
import gm from "../../../manager/GameManager";
import timeUtils from "../../../utils/TimeUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import Hero from "../../../data/card/Hero";
import EManager, { EName } from "../../../manager/EventManager";
import loadUtils from "../../../utils/LoadUtils";
import commonUtils from "../../../utils/CommonUtils";
import Equip from "../../../data/card/Equip";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityExchangePanel")
export default class ActivityExchangePanel extends FullscreenPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Sprite)
    title: cc.Sprite = null;

    @property(cc.Label)
    lastTime: cc.Label = null;

    @property(List)
    list: List = null;

    protected _activityType: ActivityType;
    protected _actConfig: ExchangeActConfig = null;
    protected _bgFrame: cc.SpriteFrame[] = [];

    static selectedHeroes: Hero[] = [];
    static selectedEquips: Equip[] = [];

    onInit(data: ActivityType) {
        super.onInit(data);
        this._activityType = data;
    }

    public reloadPanel(data: ActivityType) {
        this.data = data;
        this._activityType = data;
        this.start();
        this.loadBgImg();
    }
    protected addSpriteFrame(frame: cc.SpriteFrame) {
        if (!frame) { return; }
        let index: number = this._bgFrame.findIndex((v, i, a) => { return v == frame; })
        if (index >= 0) { return; }

        this._bgFrame.push(frame);
    }
    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);
        for (let i = 0; i < this._bgFrame.length; i++) {
            loadUtils.releaseAssetRecursively(this._bgFrame[i]);
        }
    }
    protected loadBgImg() {
        let url: string = commonUtils.getBgUrl(`activity_bg_exchange${this._getImgId()}`);
        loadUtils.loadSpriteFrame(url, this.bg, (data, err) => {
            this.addSpriteFrame(data);
        });
    }

    onLoad() {
        super.onLoad();
        let listener = EManager.addEvent(EName.onExchangeHeroSucc, () => {
            this.list.numItems = this._actConfig.exchangeData.length;
        });
        this._eventListeners.push(listener);
    }

    start() {
        super.start();
        //this.loadBg(this.bg);
        this.loadBgImg();

        loadUtils.loadSpriteFrame(`textures/ui/panel/activity_exchange/text${this._getImgId()}`, this.title);

        let data = activityLogic.getActivityConfigs(this._activityType);
        this._actConfig = data.actConfig as ExchangeActConfig;
        this.list.numItems = this._actConfig.exchangeData.length;

        this.unschedule(this.onShowTime);
        this.onShowTime();
        this.schedule(this.onShowTime, 1);
    }

    onDestroy() {
        super.onDestroy();
        ActivityExchangePanel.selectedHeroes = [];
        ActivityExchangePanel.selectedEquips = [];
    }

    onShowTime() {
        let data: ActivityModal = activityLogic.getActivityConfigs(this._activityType);
        let time = data.closeAt;
        if (time >= gm.getCurrentTimestamp()) {
            this.lastTime.string = "剩余时间 " + timeUtils.formatDay(data.remainTime, true);
            if (Math.floor((time - gm.getCurrentTimestamp()) / 1000) == 0) {
                this.unschedule(this.onShowTime);
                this.lastTime.string = stringConfigMap.key_activity_finished.Value;
            }
        } else {
            this.lastTime.string = stringConfigMap.key_activity_finished.Value;
        }
    }

    onExchangeRender(item: cc.Node, index: number) {
        let comp = item.getComponent(ActivityExchangeItem);
        comp.refresh({ activityType: this._activityType, exchangeData: this._actConfig.exchangeData[index] });
    }

    protected _getImgId() {
        let id = 1;
        if (this._activityType == ActivityType.HeroCome) {
            id = 1;
        } else if (this._activityType == ActivityType.FurnaceGift) {
            id = 2
        } else if (this._activityType == ActivityType.MysteryTreasure) {
            id = 3;
        }
        return id;
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await this._preloadBg(`activity_bg_exchange${this._getImgId()}`);

        //this._unloadInfos.push({ url: commonUtils.getBgUrl(`activity_exchange`), type: cc.SpriteFrame });
    }

}
