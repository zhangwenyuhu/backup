import { FullscreenPanel } from "../BasePanel";
import EManager, { EName } from "../../../manager/EventManager";
import List from "../../common/List";
import SignNewActivityDatas from "../../../data/activity/roleactivitydatas/SignNewActivityDatas";
import activityLogic, { ActivityType } from "../../../logics/ActivityLogic";
import SignNewActConfig from "../../../data/activity/actconfig/SignNewActConfig";
import gm from "../../../manager/GameManager";
import bagLogic from "../../../logics/BagLogic";
import { GoodId } from "../../../data/card/Good";
import stringUtils from "../../../utils/StringUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import timeUtils from "../../../utils/TimeUtils";
import commitLogic, { DiamondCost } from "../../../logics/CommitLogic";
import commonUtils from "../../../utils/CommonUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivitySignNewPanel")
export default class ActivitySignNewPanel extends FullscreenPanel {

    @property(List)
    list: List = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Label)
    leftTime: cc.Label = null;

    @property(cc.Material)
    normalMaterial: cc.Material = null;

    @property(cc.Material)
    grayMaterial: cc.Material = null;

    protected _signDays: number[] = [];
    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("activity_bg_signnew"), type: cc.SpriteFrame });

        await activityLogic.activityReq(ActivityType.SignNew);
    }

    get signNewModal() {
        return activityLogic.getActivityConfigs(ActivityType.SignNew);
    }

    get signNewActivityData(): SignNewActivityDatas {
        if (!this.signNewModal) { return null; }
        return this.signNewModal.roleActivityDatas as SignNewActivityDatas;
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();
        this.registerEvents();
        this.freshUI();
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data === "ActivitySignNewPanel") {

            }
        })
        this._eventListeners.push(listener);
    }

    freshUI() {
        this._signDays = this.signNewActivityData ? this.signNewActivityData.getSignDays() : [];
        this.list.getComponent(cc.Widget).updateAlignment();
        this.list.numItems = this._signDays.length;

        let remainTime = activityLogic.getActivityRemainTime(ActivityType.SignNew);
        this.leftTime.string = stringUtils.getString(stringConfigMap.key_activity_remain_time.Value, {
            time: timeUtils.formatDay(remainTime, true)
        });
    }

    onItemRender(item: cc.Node, index: number) {
        let day: number = this._signDays[index];
        item.getChildByName("layout").getChildByName("num").getComponent(cc.Label).string = `${day}`;

        let btnRecv = item.getChildByName("btnRecv").getComponent(cc.Button);
        let btnResign = item.getChildByName("btnReSign").getComponent(cc.Button);
        let lbRecv = item.getChildByName("claimed").getComponent(cc.Label);
        lbRecv.node.active = this.signNewActivityData.isRecv(day);
        btnResign.node.active = this.signNewActivityData.canReSign(day);
        btnRecv.node.active = !btnResign.node.active && !lbRecv.node.active;

        if (btnRecv.node.active) {
            let canRecv: boolean = this.signNewActivityData.canRecv(day);
            let mat = canRecv ? this.normalMaterial : this.grayMaterial;
            btnRecv.interactable = canRecv;
            btnRecv.node.getComponent(cc.Sprite).setMaterial(0, mat);
            btnRecv.clickEvents[0].customEventData = `${day}`;
        }
        if (btnResign.node.active) {
            btnResign.clickEvents[0].customEventData = `${day}`;
            let cost = btnResign.node.getChildByName("layout").getChildByName("icon").getChildByName("num");
            let num = (this.signNewModal.actConfig as SignNewActConfig).getReSignCost(day)
            cost.getComponent(cc.Label).string = `${num}`;
        }

        // 奖励
        let rewards = item.getChildByName("rewards");
        rewards.destroyAllChildren();
        let cfg = this.signNewModal.actConfig as SignNewActConfig;
        let reward = cfg.getRewards(day);
        for (let i = 0; i < reward.length; i++) {
            gm.showGoodItem(reward[i], {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem
            }, rewards, 0.8);
        }

    }

    onClickReSign(event: cc.Event.EventTouch, index: string) {
        let day = parseInt(index);
        let cost = (this.signNewModal.actConfig as SignNewActConfig).getReSignCost(day);
        gcc.core.showLayer("prefabs/panel/help/DiamondConfirmDialog", {
            data: {
                cost: cost,
                video: false,
                desc: `补签获得签到奖励?`,
                btnOkText: "确定",
                btnCancelText: "取消",
                success: () => {
                    //
                    this.doSign(day, true);
                }
            }
        });
    }

    onClickRecv(event: cc.Event.EventTouch, index: string) {
        let day = parseInt(index);
        this.doSign(day, false);
    }

    async doSign(day: number, reSign: boolean) {
        try {
            let data = this.signNewActivityData.getData(day);
            await activityLogic.signNewRewardReq(day, this.signNewModal.id, data.needProgress, data.tag);
            this.signNewActivityData.setRecv(day, true);
            this.freshUI();
            if (reSign) {
                let cost = (this.signNewModal.actConfig as SignNewActConfig).getReSignCost(day);
                bagLogic.getGood(GoodId.Diamond).changeAmount(-cost);
                commitLogic.costDiamond(cost, DiamondCost.reSign);
            }
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.SignNew);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}
