import {PopupPanel} from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import activityLogic from "../../../logics/ActivityLogic";
import {RankVO} from "../../../proxy/GameProxy";
import ActivityRankTop from "../../component/Activity/ActivityRankTop";
import UnlockWrapper from "../../widget/unlock/UnlockWrapper";
import {unlockConfigMap} from "../../../configs/unlockConfig";
import ArenaTopRank from "../../component/Arena/ArenaTopRank";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityReportPanel")
export default class ActivityReportPanel extends PopupPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Sprite)
    text: cc.Sprite = null;

    @property({
        type: cc.SpriteFrame
    })
    bgs: cc.SpriteFrame[] = [];

    @property({
        type: cc.SpriteFrame
    })
    texts: cc.SpriteFrame[] = [];

    @property({
        type: cc.Node
    })
    titles: cc.Node[] = [];

    @property(cc.Node)
    pageNode: cc.Node = null;

    @property(cc.Node)
    indicateNode: cc.Node = null;

    @property(cc.Node)
    indicate: cc.Node = null;

    protected _nowPage: number = 1;
    protected _allPage: number = 1;
    protected _ranks = [];
    protected _indicateNodes: cc.Node[] = [];
    protected _lastIndicateIndex: number = -1;

    onLoad() {
        super.onLoad();
        this.indicate.parent = null;
    }

    start() {
        super.start();
        let arenaJuniorRank = activityLogic.getRankLastListByType(7);
        let arenaSeniorRank = activityLogic.getRankLastListByType(8);
        if (arenaJuniorRank.length > 0) {
            this._ranks.push(arenaJuniorRank);
        }
        if (this.data) {
            if (arenaSeniorRank.length > 0 && UnlockWrapper.isUnlock(unlockConfigMap.高阶竞技场)) {
                this._ranks.push(arenaSeniorRank);
            }
        }
        this._allPage = this._ranks.length;
        this.pageNode.active = this._allPage > 1;
        this._showRank();
        this._showIndicate();
    }

    protected _types: number[] = [7, 8];

    protected _showRank() {
        let ranks = this._ranks[this._nowPage - 1];
        if (ranks.length == 0) {
            return;
        }
        this.titles[0].active = this.titles[1].active = false;
        let rankType = ranks[0].rankType;
        let index = this._types.indexOf(rankType);
        this.titles[index].active = true;
        this.bg.spriteFrame = this.bgs[index];
        this.text.spriteFrame = this.texts[index];
        for (let i = 1; i <= 3; i++) {
            let rankNode = cc.find(`bg/rank${i}`, this.node);
            let scoreNode = cc.find(`bg/score${i}`, this.node);
            let levelNode = cc.find(`bg/level${i}`, this.node);
            if (i <= ranks.length) {
                rankNode.active = true;
                scoreNode.active = ranks[i - 1].rankType == 7;
                levelNode.active = ranks[i - 1].rankType == 8;
                rankNode.getComponent(CommonLoader).loaderNode.getComponent(ActivityRankTop).refresh(ranks[i - 1]);
                let score = ranks[i - 1].score;
                if (score > 0) {
                    scoreNode.getComponent(cc.Label).string = "积分 " + score.toString();
                } else {
                    scoreNode.getComponent(cc.Label).string = "积分 0";
                }
                if (ranks[i - 1].no > 0) {
                    levelNode.getComponent(CommonLoader).loaderNode.getComponent(ArenaTopRank).refresh(ranks[i - 1].no);
                }
            } else {
                rankNode.active = false;
                scoreNode.active = false;
                levelNode.active = false;
            }
        }
    }

    protected _showIndicate() {
        for (let i = 0; i < this._allPage; i++) {
            let node = cc.instantiate(this.indicate);
            node.parent = this.indicateNode;
            this._indicateNodes.push(node);
        }
        this._switchIndicate();
    }

    protected _switchIndicate() {
        if (this._lastIndicateIndex != -1) {
            this._switchCurrent(this._lastIndicateIndex, false);
        }
        this._switchCurrent(this._nowPage, true);
    }

    protected _switchCurrent(page, flag) {
        let node = this._indicateNodes[page - 1];
        let point1 = cc.find("point1", node);
        let point2 = cc.find("point2", node);
        point1.active = flag;
        point2.active = !flag;
        if (flag) {
            this._lastIndicateIndex = page;
        }
    }

    onPrevious() {
        if (this._nowPage > 1) {
            this._nowPage--;
        } else {
            this._nowPage = this._allPage;
        }
        this._showRank();
        this._switchIndicate();
    }

    onNext() {
        if (this._nowPage < this._allPage) {
            this._nowPage++;
        } else {
            this._nowPage = 1;
        }
        this._showRank();
        this._switchIndicate();
    }

}
