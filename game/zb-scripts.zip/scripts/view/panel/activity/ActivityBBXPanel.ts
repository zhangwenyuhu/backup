import { FullscreenPanel } from "../BasePanel";
import baibaodaiconfig from "../../../configs/baibaodaiconfig";
import CommonLoader from "../../common/CommonLoader";
import ActivityBBXItem from "../../component/Activity/ActivityBBXItem";
import commonUtils from "../../../utils/CommonUtils";
import activityLogic from "../../../logics/ActivityLogic";
import gm from "../../../manager/GameManager";
import EManager, { EName } from "../../../manager/EventManager";
import { stringConfigMap } from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityBBXPanel")
export default class ActivityBBXPanel extends FullscreenPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Label)
    lastCnt: cc.Label = null;

    @property(cc.Node)
    redPoint: cc.Node = null;

    @property(cc.Node)
    big_bonus_node: cc.Node = null;

    @property(cc.Node)
    itemNode: cc.Node = null;

    async start() {
        super.start();
        this.loadBg(this.bg);
        this._showInfo();
    }

    onLoad() {
        super.onLoad();
        let listener = EManager.addEvent(EName.onApplyOrder, () => {
            this._showInfo();
        });
        this._eventListeners.push(listener);
        listener = EManager.addEvent(EName.onBBXLottery, (id) => {
            this.onTestLottery(id);
        });
        this._eventListeners.push(listener);
    }

    protected async _showInfo() {
        await activityLogic.doGetTreaBoxInfo();
        this._refreshItems();
        this._refreshAmount();
        this.unschedule(this.onShowTime);
        this.onShowTime();
        this.schedule(this.onShowTime, 1);
    }

    onShowTime() {
        let time = activityLogic.treaBoxInfo.refreshTs;
        if (time >= gm.getCurrentTimestamp()) {
            if (Math.floor((time - gm.getCurrentTimestamp()) / 1000) == 0) {
                this.unschedule(this.onShowTime);
                this._showInfo();
            }
        } else {
            this._showInfo();
        }
    }

    protected _refreshAmount() {
        this.lastCnt.string = `剩余开启次数:${activityLogic.treaBoxInfo.lastCount}/1`;
        this.redPoint.active = activityLogic.treaBoxInfo.lastCount > 0;
    }

    protected _refreshItems() {
        for (let i = 0; i < baibaodaiconfig.length; i++) {
            this._refreshOneItem(i + 1);
        }
    }

    protected _refreshOneItem(id: number) {
        //大奖
        if (id == baibaodaiconfig.length) {
            this.big_bonus_node.getComponent(ActivityBBXItem).refresh(id);
        } else {
            let node = cc.find(`item${id}`, this.itemNode);
            node.getComponent(CommonLoader).loaderNode.getComponent(ActivityBBXItem).refresh(id);
        }
    }

    async onTestLottery(id) {
        await this._doLotteryAnim(id);
        activityLogic.treaBoxInfo.doLottery(id);
        this._refreshOneItem(id);
    }

    async onLottery() {
        if (this._isAnim) {
            return;
        }
        if (activityLogic.treaBoxInfo.lastCount <= 0) {
            if (activityLogic.treaBoxInfo.dayPay == 0) {
                gm.dialog({
                    content: "今日首次充值任意金额可以获得1次开启机会，是否前往充值?", confirm: () => {
                        gm.gotoBuy();
                    }
                });
            } else {
                gm.toast(stringConfigMap.key_auto_568.Value);
            }
            return;
        }
        try {
            let proto = await activityLogic.doGoTreaBox();
            if (proto && proto.extra) {
                let id: number = proto.extra[0] as any;
                await this._doLotteryAnim(id);
                activityLogic.treaBoxInfo.doLottery(id);
                this._refreshOneItem(id);
            }
            gm.getReward(proto);
            let canLotteryIds = this._getCanLotteryIds();
            if (canLotteryIds.length == 0) {
                await this._showInfo();
            }
            this._refreshAmount();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    onCloseBBX() {
        if (this._isAnim) {
            return;
        }
        this.closePanel();
    }

    protected async _doLotteryAnim(id) {
        let canLotteryIds = this._getCanLotteryIds();
        if (canLotteryIds.length == 0) {
            return;
        }
        if (canLotteryIds.length > 1) {
            if (canLotteryIds.length == 2 && canLotteryIds.indexOf(baibaodaiconfig[baibaodaiconfig.length - 1].ID) != -1) {
                this._refreshOneItem(id);
            } else {
                await this._startAnim(id, activityLogic.treaBoxInfo.lotteryIds);
            }
        }
    }

    protected _circle = 6;
    protected _min: number = 0.05;   //最快速度间隔
    protected _max: number = 0.4;    //最慢速度间隔
    protected _isAnim: boolean = false;
    protected async _startAnim(id: number, ids: number[]) {
        this._isAnim = true;
        let sleepTime: number = 0.2;
        let newIds = this._generateIds(id, ids);
        let centerIndex = Math.floor(newIds.length / 2);
        let speedDownIndex = Math.floor(newIds.length * 5 / 6);
        for (let i = 0; i < newIds.length; i++) {
            let _id = newIds[i];
            if (i <= speedDownIndex && _id == ids[ids.length - 1]) {
                this.big_bonus_node.getComponent(ActivityBBXItem).inLight();
            }
            if (_id != baibaodaiconfig[baibaodaiconfig.length - 1].ID) {
                let node = cc.find(`item${_id}`, this.itemNode);
                node.getComponent(CommonLoader).loaderNode.getComponent(ActivityBBXItem).inLight();
            } else {
                this.big_bonus_node.getComponent(ActivityBBXItem).inLight();
            }
            await commonUtils.sleep(sleepTime, this);
            if (i <= centerIndex) {
                if (sleepTime > this._min) {
                    sleepTime -= this._min;
                }
            } else if (i > speedDownIndex) {
                if (sleepTime < this._max) {
                    sleepTime += this._min;
                }
            }
        }
        this._isAnim = false;
    }

    protected _generateIds(id: number, ids: number[]) {
        let newIds = [];
        for (let i = 0; i < this._circle; i++) {
            newIds.pushList(ids);
        }
        for (let i = 0; i < id; i++) {
            if (!activityLogic.treaBoxInfo.isLottery(i + 1)) {
                newIds.push(i + 1);
            }
        }
        return newIds;
    }

    protected _getCanLotteryIds(): number[] {
        let canLotteryIds: number[] = [];
        for (let cfg of baibaodaiconfig) {
            if (!activityLogic.treaBoxInfo.isLottery(cfg.ID)) {
                canLotteryIds.push(cfg.ID);
            }
        }
        return canLotteryIds;
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await this._preloadBg(`activity_bg_bbx`);

        this._unloadInfos.push({ url: commonUtils.getBgUrl(`activity_bbx`), type: cc.SpriteFrame });
    }

}
