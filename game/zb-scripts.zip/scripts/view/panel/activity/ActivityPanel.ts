import { FullscreenPanel } from "../BasePanel";
import commonUtils from "../../../utils/CommonUtils";
import List from "../../common/List";
import activityLogic, { ActivityType } from "../../../logics/ActivityLogic";
import loadUtils from "../../../utils/LoadUtils";
import ActivityLogoItem from "../../component/Activity/ActivityLogoItem";
import ActivityBannerItem from "../../component/Activity/ActivityBannerItem";
import EManager, { EName } from "../../../manager/EventManager";
import gm from "../../../manager/GameManager";
import giftLogic from "../../../logics/GiftLogic";

const { ccclass, property, menu } = cc._decorator;

type ActivityIcon = {
    type: ActivityType,
    img: string,
    isValid: Function,
    remainTime: Function
}

let ActivityList: ActivityIcon[] = [
    {
        type: ActivityType.NewServer,
        img: "activity_icon_newserver",
        isValid: () => { return false; },
        remainTime: () => { return 0; }
    },
    {
        type: ActivityType.LeiChong,
        img: "activity_icon_leichong",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.LeiChong) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.LeiChong) }
    },
    {
        type: ActivityType.LeiXiao,
        img: "activity_icon_leixiao",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.LeiXiao) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.LeiXiao) }
    },
    {
        type: ActivityType.Day7,
        img: "activity_icon_day7",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.Day7) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.Day7) }
    },
    {
        type: ActivityType.Treasure,
        img: "activity_icon_treasure",
        isValid: () => { return false; },
        remainTime: () => { return 0; }
    },
    {
        type: ActivityType.SurpriseShop,
        img: "activity_icon_surpriseshop",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.SurpriseShop) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.SurpriseShop) }
    },
    {
        type: ActivityType.WorldBoss,
        img: "activity_icon_worldboss",
        isValid: () => { return false; },
        remainTime: () => { return 0; }
    },
    {
        type: ActivityType.CheckerBoard,
        img: "activity_icon_chess",
        isValid: () => { return false; },
        remainTime: () => { return 0; }
    },
    {
        type: ActivityType.XiaoFeiDaRen,
        img: "activity_icon_xiaofeidaren",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.XiaoFeiDaRen) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.XiaoFeiDaRen) }
    },
    {
        type: ActivityType.SignNew,
        img: "activity_icon_signnew",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.SignNew) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.SignNew) }
    },
    {
        type: ActivityType.Explore,
        img: "activity_icon_explore",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.Explore) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.Explore) }
    },
    {
        type: ActivityType.Day7Sign,
        img: "activity_icon_7daysign",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.Day7Sign) },
        remainTime: () => { return 24 * 3600 * 1000; }
    },
    {
        type: ActivityType.NewPlayerTask,
        img: "activity_icon_newplayer",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.NewPlayerTask); },
        remainTime: () => { return activityLogic.getNewPlayerTaskTs(); }
    },
    {
        type: ActivityType.NewPlayer2Task,
        img: "activity_icon_newplayer2",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.NewPlayer2Task); },
        remainTime: () => { return activityLogic.getNewPlayer2TaskTs(); }
    },
    {
        type: ActivityType.DailyLight,
        img: "activity_icon_dailylight",
        isValid: () => { return giftLogic.dailyLightModal && giftLogic.dailyLightModal.isDailyLightValid },
        remainTime: () => { return giftLogic.dailyLightModal ? giftLogic.dailyLightModal.remainTime : 0 }
    },
    {
        type: ActivityType.Lottery,
        img: "activity_icon_task1",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.Lottery); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.Lottery); }
    },
    {
        type: ActivityType.HappyTreasure,
        img: "activity_icon_task2",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.HappyTreasure); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.HappyTreasure); }
    },
    {
        type: ActivityType.HeroCultivate,
        img: "activity_icon_task3",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.HeroCultivate); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.HeroCultivate); }
    },
    {
        type: ActivityType.CrazyArena,
        img: "activity_icon_task4",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.CrazyArena); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.CrazyArena); }
    },
    {
        type: ActivityType.WisdomStorm,
        img: "activity_icon_task5",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.WisdomStorm); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.WisdomStorm); }
    },
    {
        type: ActivityType.RewardSeason,
        img: "activity_icon_task6",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.RewardSeason); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.RewardSeason); }
    },
    {
        type: ActivityType.UnionRally,
        img: "activity_icon_task7",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.UnionRally); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.UnionRally); }
    },
    {
        type: ActivityType.UnionLottery,
        img: "activity_icon_task8",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.UnionLottery); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.UnionLottery); }
    },
    {
        type: ActivityType.HeroCome,
        img: "activity_icon_exchange1",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.HeroCome); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.HeroCome); }
    },
    {
        type: ActivityType.FurnaceGift,
        img: "activity_icon_exchange2",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.FurnaceGift); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.FurnaceGift); }
    },
    {
        type: ActivityType.MysteryTreasure,
        img: "activity_icon_exchange3",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.MysteryTreasure); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.MysteryTreasure); }
    },
    {
        type: ActivityType.MonthOrder,
        img: "activity_icon_monthorder",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.MonthOrder); },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.MonthOrder); }
    },
]

let actNewList: ActivityIcon[] = [
    {
        type: ActivityType.Day7Sign,
        img: "activity_icon_7daysign",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.Day7Sign) },
        remainTime: () => { return 24 * 3600 * 1000; }
    },
    {
        type: ActivityType.NewPlayerTask,
        img: "activity_icon_newplayer",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.NewPlayerTask); },
        remainTime: () => { return activityLogic.getNewPlayerTaskTs(); }
    },
    {
        type: ActivityType.NewPlayer2Task,
        img: "activity_icon_newplayer2",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.NewPlayer2Task); },
        remainTime: () => { return activityLogic.getNewPlayer2TaskTs(); }
    },
    {
        type: ActivityType.SignNew,
        img: "activity_icon_signnew",
        isValid: () => { return activityLogic.isActivityValid(ActivityType.SignNew) },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.SignNew) }
    },
]

let bannerList: ActivityIcon[] = [
    {
        type: ActivityType.Treasure,
        img: "act_banner_treasure",
        isValid: () => { return false },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.Treasure) }
    },
    {
        type: ActivityType.WorldBoss,
        img: "act_banner_worldboss",
        isValid: () => { return false },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.WorldBoss) }
    },
    {
        type: ActivityType.CheckerBoard,
        img: "act_banner_chess",
        isValid: () => { return false; },
        remainTime: () => { return activityLogic.getActivityRemainTime(ActivityType.CheckerBoard) }
    },
]

/**
 * 活动列表面板
 */
@ccclass
@menu("view/panel/activity/ActivityPanel")
export default class ActivityPanel extends FullscreenPanel {
    @property(List)
    listView: List = null;

    @property(cc.PageView)
    bannerView: cc.PageView = null;

    @property(cc.Node)
    pageItem: cc.Node = null;

    @property(cc.Node)
    bannerTab: cc.Node = null;

    @property(cc.Node)
    tabItem: cc.Node = null;

    protected _activityIcons: ActivityIcon[] = [];
    protected _bannerIcons: ActivityIcon[] = [];
    protected _rightRun: boolean = true;
    protected _runSec: number = 5;

    onLoad() {
        super.onLoad();

        this.pageItem.parent = null;
        this.tabItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.pageItem.destroy();
        this.tabItem.destroy();
    }

    async start() {
        super.start();

        this.bannerView.node.active = false;

        await giftLogic.doGetDailyLightDetail();
        await activityLogic.activityReq(ActivityType.All);

        if (!cc.isValid(this.node)) return;

        this.freshUI();

        this.unschedule(this.runBanner.bind(this));
        this.schedule(this.runBanner.bind(this), this._runSec);

        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data === "ActivityPanel") {
                this.initActivityData();
                this.freshUI();
            }
        })
        this._eventListeners.push(listener);
    }

    initActivityData() {
        this._activityIcons = [];
        this._bannerIcons = [];
        for (let icon of actNewList) {
            if (icon.isValid()) {
                this._activityIcons.push(icon);
            }
        }

        for (let icon of bannerList) {
            if (icon.isValid()) {
                this._bannerIcons.push(icon);
            }
        }
    }

    freshUI() {
        this.initBanner();

        let top = this._bannerIcons.length <= 0 ? 192 : 592;
        top += gm.safeArea.top;
        this.listView.getComponent(cc.Widget).top = top;
        this.listView.getComponent(cc.Widget).updateAlignment();

        this._activityIcons.sort((a, b) => {
            return a.remainTime() - b.remainTime();
        });
        this.listView.numItems = this._activityIcons.length;
    }

    initBanner() {
        this.bannerView.removeAllPages();
        this.bannerTab.destroyAllChildren();
        for (let i = 0; i < this._bannerIcons.length; i++) {
            let page = cc.instantiate(this.pageItem);
            this.bannerView.addPage(page);
            this.freshBanner(page, i);

            let tmp = cc.instantiate(this.tabItem);
            tmp.parent = this.bannerTab;
        }
        if (this._bannerIcons.length > 0) {
            this.bannerView.node.active = true;
            this.bannerView.setCurrentPageIndex(0);
            this.freshBannerTab(0);
        }
    }

    runBanner() {
        let pageIndex: number = this.bannerView.getCurrentPageIndex();
        let maxIndex: number = this._bannerIcons.length;
        if (maxIndex <= 0) { return; }

        let nextIndex: number = pageIndex;
        if (this._rightRun) {
            this._rightRun = pageIndex + 1 >= maxIndex ? false : true;
            nextIndex = this._rightRun ? pageIndex + 1 : pageIndex - 1;
        } else {
            this._rightRun = pageIndex <= 0 ? true : false;
            nextIndex = this._rightRun ? pageIndex + 1 : pageIndex - 1;
        }

        this.bannerView.setCurrentPageIndex(nextIndex);
        this.freshBannerTab(nextIndex);
    }

    freshBannerTab(select: number) {
        for (let i = 0; i < this.bannerTab.childrenCount; i++) {
            let bSelect: boolean = select == i;
            let name: string = bSelect ? "activity_banner_select" : "activity_banner_normal";
            let url: string = commonUtils.getPanelIconUrl("activity", name);
            loadUtils.loadSpriteFrame(url, this.bannerTab.children[i].getComponent(cc.Sprite));
        }

        let bg = this.bannerTab.parent.getChildByName("bg");
        bg.active = this.bannerTab.childrenCount > 0;
        this.scheduleOnce(() => {
            bg.width = this.bannerTab.width + 15;
        })
    }

    bannerChange(event: cc.Event.EventTouch, index: string) {
        let pageIndex = this.bannerView.getCurrentPageIndex();
        this.freshBannerTab(pageIndex);
    }

    freshBanner(item: cc.Node, index: number) {
        let icon = this._bannerIcons[index];
        let comp = item.getComponent(ActivityBannerItem);
        comp.refresh(icon.type, icon.img, icon.remainTime());
    }

    closeActivity() {
        this.closePanel();
    }

    onActivityItemRender(item: cc.Node, index: number) {
        let icon = this._activityIcons[index];
        let comp = item.getComponent(ActivityLogoItem);
        comp.refresh(icon.type, icon.img, icon.remainTime());
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("arena_bg"), type: cc.SpriteFrame });

        for (let icon of actNewList) {
            if (icon.isValid()) {
                this._activityIcons.push(icon);
                let url = commonUtils.getBgUrl(icon.img);
                this._unloadInfos.push({ url: url, type: cc.SpriteFrame });
            }
        }

        for (let icon of bannerList) {
            if (icon.isValid()) {
                this._bannerIcons.push(icon);
                let url = commonUtils.getBgUrl(icon.img);
                this._unloadInfos.push({ url: url, type: cc.SpriteFrame });
            }
        }
    }
}