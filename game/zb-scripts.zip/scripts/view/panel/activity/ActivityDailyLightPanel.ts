import { FullscreenPanel } from "../BasePanel";
import giftLogic from "../../../logics/GiftLogic";
import newplayerchargeconfig from "../../../configs/newplayerchargeconfig";
import ActivityDailyLightTab from "../../component/Activity/ActivityDailyLightTab";
import gm from "../../../manager/GameManager";
import ActivityDailyLightItem from "../../component/Activity/ActivityDailyLightItem";
import CommonLoader from "../../common/CommonLoader";
import EManager, { EName } from "../../../manager/EventManager";
import timeUtils from "../../../utils/TimeUtils";
import commonUtils from "../../../utils/CommonUtils";
import loadUtils from "../../../utils/LoadUtils";
import artifactConfig from "../../../configs/artifactConfig";
import newplayertimespendconfig from "../../../configs/newplayertimespendconfig";
import { stringConfigMap } from "../../../configs/stringConfig";
import stringUtils from "../../../utils/StringUtils";
import { ArtifactBO } from "../../../proxy/GameProxy";
import Artifact from "../../../data/card/Artifact";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityDailyLightPanel")
export default class ActivityDailyLightPanel extends FullscreenPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Label)
    lastTime: cc.Label = null;

    @property(cc.Label)
    chargeDays: cc.Label = null;

    @property(sp.Skeleton)
    artifact: sp.Skeleton = null;

    @property(sp.Skeleton)
    hero: sp.Skeleton = null;

    @property(cc.Node)
    bigItemNode: cc.Node = null;

    @property(cc.Node)
    tabNode: cc.Node = null;

    @property(cc.Node)
    itemNode: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Label)
    dailyCharge: cc.Label = null;

    @property(cc.Button)
    recvBtn: cc.Button = null;

    @property(cc.Label)
    recvLabel: cc.Label = null;

    @property(cc.Label)
    rewardTime: cc.Label = null;

    @property(cc.Node)
    tips: cc.Node = null;

    protected _nowId: number = 1;
    protected _artifactSkeletonData: sp.SkeletonData = null;

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;

        let listener = EManager.addEvent(EName.onUpdateDailyLight, (id: number) => {
            this._nowId = id;
            this._refreshItem();
            this._refreshRecvBtn(id);
        });
        this._eventListeners.push(listener);
    }

    onDestroy() {
        super.onDestroy();

        ActivityDailyLightTab._lastDailyLightTab = null;

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    async start() {
        super.start();
        let url = commonUtils.getBgUrl(`activity_dailylight_bg`);
        loadUtils.loadSpriteFrame(url, this.bg);
        await this._refreshAll();

        let artifactCfg = artifactConfig.find(a => a.Id == newplayertimespendconfig[2].reward[0][0]);
        url = `spine/ui/shenqi/${artifactCfg.Spine}`;
        this._artifactSkeletonData = await loadUtils.loadRes(url, sp.SkeletonData) as sp.SkeletonData;
        this.artifact.skeletonData = this._artifactSkeletonData;
        this.artifact.animation = "animation";
        this.artifact.loop = true;
    }

    protected async _refreshAll(flag: boolean = true) {
        await giftLogic.doGetDailyLightDetail();
        let activityEnd = giftLogic.dailyLightModal.nowDay > newplayerchargeconfig[newplayerchargeconfig.length - 1].days;
        this.chargeDays.string = giftLogic.dailyLightModal.continuityChargeDays + "/7";
        this._refreshItem(true);
        this._refreshBigItem();
        if (flag) {
            this._refreshTime();
        }
        this.tips.active = !activityEnd;
        if (activityEnd) {
            console.log("活动已结束");
            return;
        }
        this.unscheduleAllCallbacks();
        this.schedule(this._refreshTime, 1);
    }

    protected _refreshTime() {
        let diffTime = giftLogic.dailyLightModal.remainTime;
        if (Math.floor(diffTime) > 0) {
            this.lastTime.string = stringConfigMap.key_activity_end.Value + " " + timeUtils.formatDay(Math.floor(diffTime), true);
        } else {
            this.lastTime.string = stringConfigMap.key_activity_finished.Value;
            this.rewardTime.string = stringConfigMap.key_activity_finished.Value;
            this.unscheduleAllCallbacks();
            return;
        }
        let time = gm.getCurrentTimestamp();
        let date = new Date(time);
        date.setMilliseconds(0);
        date.setSeconds(0);
        date.setMinutes(0);
        // date.setHours(24);
        date.setUTCHours(24);
        diffTime = Math.floor((date.getTime() - gm.getCurrentTimestamp()) / 1000);
        if (diffTime > 0) {
            this.rewardTime.string = timeUtils.formatDaySecond(diffTime * 1000);
        } else if (diffTime == 0) {
            this._refreshAll(false);
        } else {
            this.rewardTime.string = "";
        }
    }

    protected _refreshItem(showTab: boolean = false) {
        let day = giftLogic.dailyLightModal.nowDay;
        if (day > 7) {
            day = 7;
        }
        let chargeCfgs = newplayerchargeconfig.where(a => a.days == day);
        let whichTotal = giftLogic.dailyLightModal.canReceive(day);
        if (whichTotal == -1) {
            whichTotal = 0;
        }
        for (let charge of chargeCfgs) {
            if (this._nowId == charge.ID) {
                this._showItemById(charge.ID);
            }
            if (showTab) {
                if (chargeCfgs.indexOf(charge) == (whichTotal == 0 ? 0 : whichTotal - 1)) {
                    this._nowId = charge.ID;
                    this._showItemById(charge.ID);
                    this._refreshRecvBtn(charge.ID);
                }
                this._showItemTab(charge.ID, chargeCfgs.indexOf(charge) == (whichTotal == 0 ? 0 : whichTotal - 1));
            }
        }
    }

    protected _refreshBigItem() {
        for (let i = 1; i <= 3; i++) {
            this._showBigItemById(i);
        }
    }

    protected _showItemTab(id: number, check: boolean = false) {
        let chargeCfg = newplayerchargeconfig[id - 1];
        let chargeCfgs = newplayerchargeconfig.where(a => a.days == chargeCfg.days);
        let index = chargeCfgs.indexOf(chargeCfg) + 1;
        let tab = cc.find(`tab${index}`, this.tabNode);
        if (tab) {
            tab.getComponent(ActivityDailyLightTab).refresh(id);
            if (check) {
                tab.getComponent(ActivityDailyLightTab).doTab(false);
            }
        }
    }

    protected _showItemById(id: number) {
        let chargeCfg = newplayerchargeconfig[id - 1];
        this.itemNode.destroyAllChildren();
        for (let reward of chargeCfg.reward) {
            gm.showGoodItem(reward, {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem
            }, this.itemNode);
        }
    }

    protected _refreshRecvBtn(id) {
        let dayCharge = 0;
        if (giftLogic.dailyLightModal.nowDay > 7) {
            this.recvBtn.interactable = false;
            this.recvLabel.string = stringConfigMap.key_desc_21.Value;
            this.dailyCharge.node.active = false;
        } else {
            this.recvBtn.interactable = !giftLogic.dailyLightModal.isReceived(id);
            this.recvLabel.string = giftLogic.dailyLightModal.isReceived(id) ? stringConfigMap.key_claimed.Value : stringConfigMap.key_desc_21.Value;
            this.dailyCharge.node.active = true;
            dayCharge = giftLogic.dailyLightModal.dayCharge(id);
            this.dailyCharge.string = stringUtils.getString(stringConfigMap.key_today_charge.Value, { amount: dayCharge });
        }
    }

    protected _showBigItemById(id: number) {
        let item = cc.find(`item${id}`, this.bigItemNode);
        if (item) {
            let loaderNode = item.getComponent(CommonLoader).loaderNode;
            loaderNode.getComponent(ActivityDailyLightItem).refresh(id);
        }
    }

    async onRecvReward() {
        if (giftLogic.dailyLightModal.remainTime <= 0) {
            if (giftLogic.dailyLightModal.canReceive(this._nowId) != -1) {
                gm.toast(stringConfigMap.key_activity_finish_tip.Value);
            } else {
                gm.toast(stringConfigMap.key_activity_finished.Value);
            }
            return;
        }
        if (giftLogic.dailyLightModal.canReceive(this._nowId) == -1) {
            let needChargeAmt = newplayerchargeconfig[this._nowId - 1].chargenumber;
            let nowChargeAmt = giftLogic.dailyLightModal.nowDayCharge;
            let needCharge = needChargeAmt - nowChargeAmt;
            gm.toast(stringUtils.getString(stringConfigMap.key_charge_more.Value, { amount: needCharge }));
            return;
        }
        try {
            if (this._nowId > 0) {
                await giftLogic.doGetNewSevenReward(this._nowId);
                this._refreshRecvBtn(this._nowId);
                EManager.emit(EName.onUpdateDailyTab);
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    onArtifact() {
        let artifactBo = new ArtifactBO();
        artifactBo.artifactCofId = 40001;
        artifactBo.rank = 0;
        artifactBo.forgeLv = 0;
        let artifact = new Artifact(artifactBo);
        gcc.core.showLayer("prefabs/panel/equip/ArtifactInfoPanel", {
            data: { equip: artifact, wearType: 6, nobtn: true },
            modalTouch: true,
        });
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("activity_dailylight_bg"), type: cc.SpriteFrame });
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);

        if (this._artifactSkeletonData) {
            loadUtils.releaseAssetRecursively(this._artifactSkeletonData);
            this._artifactSkeletonData = null;
        }
    }

}
