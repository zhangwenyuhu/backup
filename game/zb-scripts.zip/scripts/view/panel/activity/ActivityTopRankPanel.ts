import { FullscreenPanel } from "../BasePanel";
import { RefreshLabel } from "../../../decorator/RefreshDecorator";
import Good from "../../../data/card/Good";
import bagLogic from "../../../logics/BagLogic";
import List from "../../common/List";
import ActivityNewServerItem from "../../component/Activity/ActivityNewServerItem";
import stringUtils from "../../../utils/StringUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import timeUtils from "../../../utils/TimeUtils";
import activityLogic from "../../../logics/ActivityLogic";
import gm from "../../../manager/GameManager";
import GameProxy, {RankListReq, RankListVO, RankVO} from "../../../proxy/GameProxy";
import RankData from "../../../data/record/RankData";
import commonUtils from "../../../utils/CommonUtils";
import loadUtils from "../../../utils/LoadUtils";
import friendLogic from "../../../logics/FriendLogic";
import CommonLoader from "../../common/CommonLoader";
import PlayerAvatar from "../../component/Player/PlayerAvatar";
import ActivityTopRankItem from "../../component/Activity/ActivityTopRankItem";
import ActiveListconfig from "../../../configs/ActiveListconfig";
import cm from "../../../manager/ConfigManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityTopRankPanel")
export default class ActivityTopRankPanel extends FullscreenPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Sprite)
    title: cc.Sprite = null;

    @property(cc.Label)
    labelPower: cc.Label = null;

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => {
            return bagLogic.getGood(Good.GoodId.Diamond)
        },
        getValue: (good: Good) => {
            return stringUtils.formatAmount(good.getAmount());
        }
    })
    @property(cc.Label)
    labelDiamond: cc.Label = null;

    @property(cc.Label)
    labelRemainTime: cc.Label = null;

    @property(List)
    rankList: List = null;

    @property(cc.ScrollView)
    scrollView: cc.ScrollView = null;

    @property(ActivityTopRankItem)
    myRank: ActivityTopRankItem = null;

    @property(cc.Node)
    top3: cc.Node = null;

    @property(cc.Label)
    leftSupportTimes: cc.Label = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    emptyNode: cc.Node = null;

    @property(cc.Node)
    leftSupportNode: cc.Node = null;

    protected _myRankData: RankData = null;
    protected _rankDatas: RankData[] = [];
    protected _isRequesting: boolean = false;

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;

        let list = this.rankList.node.parent;
        list.getComponent(cc.Widget).top += (cc.winSize.height - 1334) / 2;
        list.getComponent(cc.Widget).updateAlignment();

        let widget = this.rankList.getComponent(cc.Widget);
        widget.updateAlignment();
    }

    async start() {
        super.start();

        this.loadBg(this.bg);
        loadUtils.loadSpriteFrame(`textures/ui/panel/activity_toprank/text${this._getId()}`, this.title);
        this.labelRemainTime.string = stringUtils.getString(stringConfigMap.key_activity_remain_time.Value,
            { time: timeUtils.formatDay(activityLogic.cycleRankRemainTime, true) });
        this.myRank.node.active = false;
        this.labelPower.string = "";
        this.leftSupportNode.active = false;

        await this._reqRankList();
        this.freshTop3();
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    onEnable() {
        super.onEnable();
        this.schedule(this._updateRemainTime, 10);
    }

    onDisable() {
        this.unschedule(this._updateRemainTime);
        super.onDisable();
    }

    onRankItemRender(item: cc.Node, index: number) {
        let rankData = this._rankDatas[index];
        let comp = item.getComponent(ActivityTopRankItem);
        comp.refresh(rankData, false, { good: this.goodItem, hero: this.heroItem, equip: this.equipItem });
    }

    onScrollEvents(target: cc.ScrollView, eventType: cc.ScrollView.EventType) {
        if (eventType == cc.ScrollView.EventType.SCROLL_TO_BOTTOM) {
            this._reqRankList();
        }
    }

    onRewardPreview() {
        let confs = ActiveListconfig.where(a => a.Activeid == this._myRankData.getCoins());
        gcc.core.showLayer("prefabs/panel/activity/NewServerBonusPanel", {data: confs, modalTouch: true});
    }

    onLastHonor() {
        let ranks: RankVO[] = activityLogic.cycleLastRank;
        if (ranks.length == 0) {
            gm.toast(stringConfigMap.key_auto_567.Value);
            return;
        }
        gcc.core.showLayer("prefabs/panel/activity/ActivityLastRankPanel", {modalTouch: true, data: ranks[0].conins});
    }

    async onSupport(sender: cc.Event.EventTouch, customData: string) {
        if (this._myRankData.getLeftSupportCount() <= 0) {
            gm.toast('今日点赞次数已用尽');
            return;
        }
        try {
            let data = await activityLogic.supportPlayer(customData, 1);
            console.log('support extra: ' + data);
            if (data && data[0]) {
                let num: number = parseInt(data[0] as any);
                for (let i = 0; i < 3; i++) {
                    let data = this._rankDatas[i];
                    if (data && data.getRole().getRoleId() == customData) {
                        data.setSupportCount(num);
                    }
                }
            }
            this._myRankData.setCanSupportCountAdd();
            this.leftSupportTimes.string = `${this._myRankData.getLeftSupportCount()}`;

            this.freshTop3();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    protected freshTop3() {
        for (let i = 0; i < 3; i++) {
            let rank: number = i + 1;
            let node = this.top3.getChildByName(`rank${rank}`);
            let rankData = this._rankDatas[i];

            let avatarLoader = node.getChildByName('avatar').getComponent(CommonLoader);
            let supportBtn = this.top3.getChildByName(`support${rank}`).getComponent(cc.Button);
            let support = this.top3.getChildByName(`num${rank}`);
            if (this._rankDatas[i]) {
                let player = rankData.getRole();
                let comp = avatarLoader.loaderNode.getComponent(PlayerAvatar);
                comp.refresh(player.getAvatar());

                let name = node.getChildByName('name').getComponent(cc.Label);
                name.string = player.getNickname();

                let btn = node.getComponent(cc.Button);
                btn.clickEvents[0].customEventData = player.getRoleId();

                supportBtn.clickEvents[0].customEventData = player.getRoleId();
                support.getComponent(cc.Label).string = `${rankData.getSupportCount()}`;
            } else {
                supportBtn.node.active = false;
                support.active = false;
                avatarLoader.node.active = false;
            }
        }

        this.leftSupportTimes.string = `${this._myRankData.getLeftSupportCount()}`;
        this.leftSupportNode.active = this._rankDatas.length > 0;
    }

    async onTop3User(sender: cc.Event.EventTouch, customData: string) {
        if (customData && customData != "") {
            await friendLogic.playerShow(customData, true);
            let userInfo = friendLogic.getPlayerInfo(customData);
            gcc.core.showLayer("prefabs/panel/player/UserPanel", { data: { user: userInfo } });
        }
    }

    protected async _reqRankList() {
        if (this._isRequesting) return;
        this._isRequesting = true;

        let proto = await activityLogic.doGetCycleActRank(this._rankDatas.length, this._rankDatas.length + 9);
        this._myRankData = new RankData(proto.myRank);
        for (let vo of proto.rankDetail) {
            this._rankDatas.push(new RankData(vo));
        }
        this.myRank.node.active = true;
        this.myRank.refresh(this._myRankData, true, { good: this.goodItem, hero: this.heroItem, equip: this.equipItem });
        this.rankList.numItems = this._rankDatas.length;
        this.emptyNode.active = this._rankDatas.length == 0;

        let power = this._myRankData.getRole().getPower()
        this.labelPower.string = stringUtils.formatPower(power);

        if (proto.rankDetail.length == 0 || this.rankList.numItems >= 500) {
            this.scrollView.scrollEvents = [];
        }

        this._isRequesting = false;
    }

    protected _updateRemainTime(dt: number) {
        this.labelRemainTime.string = stringUtils.getString(stringConfigMap.key_activity_remain_time.Value,
            { time: timeUtils.formatDay(activityLogic.cycleRankRemainTime, true) });
    }

    protected async _preloadRes() {
        await super._preloadRes();

        let proto = await activityLogic.doGetCycleActRank(0, 9);
        this._myRankData = new RankData(proto.myRank);
        if (this._myRankData.getType() == 15) {
            //周期排行
            await this._preloadBg(`activity_bg_toprank${this._getId()}`);
        }
    }

    protected _getId() {
        let rankType = this._myRankData.getCoins();
        let id = cm.activeList.indexOf(rankType) + 1;
        return id;
    }

}