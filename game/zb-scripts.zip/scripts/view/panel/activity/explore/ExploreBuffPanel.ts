import { PopupPanel } from "../../BasePanel";
import gm from "../../../../manager/GameManager";
import exploreLogic, { KEY_TYPE } from "../../../../logics/ExploreLogic";
import xunbaoluckyConfig from "../../../../configs/xunbaoluckyConfig";
import { GoodId } from "../../../../data/card/Good";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/explore/ExploreBuffPanel")
export default class ExploreBuffPanel extends PopupPanel {

    @property(cc.Node)
    buff: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    finalChange: cc.Node = null;

    @property(cc.Node)
    finalDouble: cc.Node = null;

    @property(cc.Label)
    desc: cc.Label = null;

    protected _buffId: number = 0;
    protected _callback: Function = null;
    onInit(data: any) {
        super.onInit(data);
        this._buffId = data.buffId;
        this._callback = data.callback;
    }

    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();

        this.finalChange.active = this._buffId == KEY_TYPE.ChangeFinal;
        this.finalDouble.active = this._buffId == KEY_TYPE.Double;
        let cfg = xunbaoluckyConfig.find((a) => { return a.ID == this._buffId; });
        this.desc.string = cfg ? cfg.description : "";
        this.initBuff();
    }

    initBuff() {
        let final: number = exploreLogic.getFinalId();
        let ids: number[] = [];
        if (this._buffId == KEY_TYPE.ChangeFinal || this._buffId == KEY_TYPE.Double) {
            ids = exploreLogic.getFinalRewardCfg(final).finalreward;
        } else {
            let cfg = xunbaoluckyConfig.find((a) => { return a.ID == this._buffId; });
            let num = cfg ? cfg.number : 1;
            ids = [GoodId.ExploreKey, num];
        }
        this.buff.destroyAllChildren();
        gm.showGoodItem(ids, {
            goodItem: this.goodItem,
            equipItem: this.equipItem,
            heroItem: this.heroItem
        }, this.buff);
    }

    async onClickOK() {
        this.closePanel();
        if (this._callback) { this._callback(); }
    }
}
