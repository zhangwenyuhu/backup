import { PopupPanel } from "../../BasePanel";
import List from "../../../common/List";
import gm from "../../../../manager/GameManager";
import exploreLogic from "../../../../logics/ExploreLogic";
import commonUtils from "../../../../utils/CommonUtils";
import {stringConfigMap} from "../../../../configs/stringConfig";
import stringUtils from "../../../../utils/StringUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/explore/ExploreFinalReward")
export default class ExploreFinalReward extends PopupPanel {

    @property(List)
    finalRewards: List = null;

    @property(cc.Node)
    finalSelect: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    protected _finals: { id: number, rewards: number[], left: number, total: number }[] = [];
    protected _select: number = 0;
    protected _callback: Function = null;
    onInit(data: any) {
        super.onInit(data);
        this._callback = data ? data.callback : null;
    }

    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();
        this._select = exploreLogic.getFinalId();
        this.initFinalInfo();

        this.freshRewards();
        this.freshSelectFinal();
    }

    // 终极奖励领取信息
    initFinalInfo() {
        this._finals = [];
        let cfg = exploreLogic.getFinalCfg(true);
        // 终极奖励
        for (let i = 0; i < cfg.length; i++) {
            let leftCount: number = cfg[i].getlimit - exploreLogic.getFinalRecvCount(cfg[i].ID);
            this._finals.push({
                id: cfg[i].ID,
                rewards: cfg[i].finalreward,
                left: leftCount,
                total: cfg[i].getlimit,
            })
        }
    }

    freshRewards() {
        this.finalRewards.getComponent(cc.Widget).updateAlignment();
        this.finalRewards.numItems = this._finals.length;
    }

    freshSelectFinal() {
        this.finalSelect.destroyAllChildren();
        let select: boolean = this._select > 0;
        this.finalSelect.active = select;

        if (!select) { return; }
        let cfg = exploreLogic.getFinalCfg().find((a) => { return a.ID == this._select; })
        gm.showGoodItem(cfg.finalreward, {
            goodItem: this.goodItem,
            equipItem: this.equipItem,
            heroItem: this.heroItem
        }, this.finalSelect);
    }

    onRenderItem(item: cc.Node, index: number) {
        let data = this._finals[index];

        let num = item.getChildByName("bg").getChildByName("num")
        num.getComponent(cc.Label).string = `${data.left}/${data.total}`;

        let reward = item.getChildByName("reward");
        reward.destroyAllChildren();
        gm.showGoodItem(data.rewards, {
            goodItem: this.goodItem,
            equipItem: this.equipItem,
            heroItem: this.heroItem
        }, reward);

        let select: boolean = data.id === this._select;
        item.getChildByName("select").active = select;
        let color = cc.color(255, 255, 255, 255);
        if (select) { color = cc.color(100, 100, 100, 255); }
        commonUtils.setColor(reward, color);

        let btn = item.getChildByName("btn").getComponent(cc.Button);
        btn.clickEvents[0].customEventData = `${data.id}`;
    }

    onClickSelectFinalReward(event: cc.Event.EventTouch, index: string) {
        let finalId = parseInt(index);
        let data = this._finals.find((a) => { return a.id == finalId; });
        if (!data) { return; }
        if (this._select == data.id) { return; }
        if (data.left <= 0) {
            gm.toast(stringUtils.getString(stringConfigMap.key_auto_637.Value, {}));
            return;
        }
        this._select = data.id;

        this.freshRewards();
        this.freshSelectFinal();
    }

    onClickSave() {
        this._select = this._select == exploreLogic.getFinalId() ? 0 : this._select;
        if (this._callback) { this._callback(this._select); }
        this.closePanel();
    }
    onClickCancel() {
        if (this._callback) { this._callback(0); }
        this.closePanel();
    }
}
