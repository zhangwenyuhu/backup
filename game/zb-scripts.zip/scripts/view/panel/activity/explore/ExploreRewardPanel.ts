import { PopupPanel } from "../../BasePanel";
import List from "../../../common/List";
import gm from "../../../../manager/GameManager";
import exploreLogic from "../../../../logics/ExploreLogic";
import EManager, { EName } from "../../../../manager/EventManager";
import activityLogic, { ActivityType } from "../../../../logics/ActivityLogic";
import xunbaocengrewardconfig, { xunbaocengrewardconfigRow } from "../../../../configs/xunbaocengrewardconfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/explore/ExploreRewardPanel")
export default class ExploreRewardPanel extends PopupPanel {
    @property(List)
    rewardList: List = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    protected _cfg: xunbaocengrewardconfigRow[] = [];
    protected _reward: { tag: string, needProgress: number, progress: number, recv: boolean }[] = [];
    protected async _preloadRes() {
        await super._preloadRes();
        await activityLogic.activityReq(ActivityType.Explore);
    }

    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();
        if (!cc.isValid(this.node)) return;

        this._cfg = xunbaocengrewardconfig;
        this._reward = exploreLogic.getExploreData().getLayerReward();
        this.freshUI();
    }

    isComplete(circle: number): boolean {
        let tag: string = `${circle}`;
        let data = this._reward.find((a) => { return a.tag == tag; })
        return data ? data.progress >= data.needProgress : false;
    }

    isRecv(circle: number): boolean {
        let tag: string = `${circle}`;
        let data = this._reward.find((a) => { return a.tag == tag; })
        return data ? data.recv : false;
    }

    freshUI() {
        this.rewardList.getComponent(cc.Widget).updateAlignment();
        this.rewardList.numItems = this._cfg.length;
    }

    onRewardItemRender(node: cc.Node, index: number) {
        let data = this._cfg[index];
        node.active = data ? true : false;
        if (!data) { return; }
        let circle: number = data.numberofplies
        if (data) {
            let title: string = `累计完成 ${circle} 层`;
            cc.find("bg1/title", node).getComponent(cc.Label).string = title;
            cc.find("bg2/title", node).getComponent(cc.Label).string = title;
            let bComplete: boolean = this.isComplete(circle);
            let recv: boolean = this.isRecv(circle);

            node.getChildByName("bg1").active = !bComplete;
            node.getChildByName("bg2").active = bComplete;
            node.getChildByName("flag").active = bComplete && recv;
            node.getChildByName("btnGet").active = bComplete && !recv;
            node.getChildByName("btnGoto").active = !bComplete;

            let btn = node.getChildByName("btnGet").getComponent(cc.Button);
            btn.clickEvents[0].customEventData = `${data.numberofplies}`;

            let rewardNode = node.getChildByName("rewards");
            rewardNode.destroyAllChildren();
            let rewards: number[][] = data.reward
            for (let i = 0; i < rewards.length; i++) {
                gm.showGoodItem(rewards[i], {
                    goodItem: this.goodItem,
                    equipItem: this.equipItem,
                    heroItem: this.heroItem
                }, rewardNode, 0.85);
            }
        }
    }

    async onClickGetReward(sender: cc.Event.EventTouch, data: string) {
        try {
            await exploreLogic.recvExploreLevelRewardReq(data);
            exploreLogic.getExploreData().setRecvReward(data);

            this.rewardList.numItems = this._cfg.length;
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.Explore);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}