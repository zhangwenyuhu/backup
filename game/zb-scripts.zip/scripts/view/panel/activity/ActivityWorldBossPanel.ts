import { Storage, BattleType } from './../../../utils/DefineUtils';
import { ActivityModal, ActivityWorldBossModal } from './../../../logics/ActivityLogic';
import { EName } from './../../../manager/EventManager';
import GameProxy, { RankListReq, RankListVO } from './../../../proxy/GameProxy';
import { stringConfigMap } from './../../../configs/stringConfig';
import { FullscreenPanel } from './../BasePanel';
import activityLogic, { ActivityType } from '../../../logics/ActivityLogic';
import commonUtils from '../../../utils/CommonUtils';
import loadUtils from '../../../utils/LoadUtils';
import timeUtils from '../../../utils/TimeUtils';
import stringUtils from '../../../utils/StringUtils';
import gm from '../../../manager/GameManager';
import RankData from '../../../data/record/RankData';
import UnionSkill from '../../component/Skill/UnionSkill';
import EManager from '../../../manager/EventManager';
import WorldBossActConfig from '../../../data/activity/actconfig/WorldBossActConfig';
import WorldBossActivityDatas from '../../../data/activity/roleactivitydatas/WorldBossActivityDatas';
import bagLogic from '../../../logics/BagLogic';
import Good from '../../../data/card/Good';
import ActivityWorldBossRankIcon from '../../component/Activity/ActivityWorldBossRankIcon';
import storageUtils from '../../../utils/StorageUtils';
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityWorldBossPanel")
export default class ActivityWorldBossPanel extends FullscreenPanel {
    @property(cc.Sprite)
    spriteBg: cc.Sprite = null;

    @property(cc.Label)
    labelRemainTime: cc.Label = null;

    @property(cc.Node)
    top3AvatarTemplate: cc.Node = null;

    @property(cc.Node)
    skillTemplate: cc.Node = null;

    @property(cc.Node)
    top3Node: cc.Node = null;

    @property(cc.Node)
    skillsNode: cc.Node = null;

    @property(sp.Skeleton)
    bossSkeleton: sp.Skeleton = null;

    @property(cc.Label)
    labelBossName: cc.Label = null;

    @property(cc.ProgressBar)
    progressBar: cc.ProgressBar = null;

    @property(cc.Label)
    labelProgress: cc.Label = null;

    @property(cc.Label)
    labelPercentage: cc.Label = null;

    @property(cc.Label)
    labelRemainCount: cc.Label = null;

    @property(cc.Button)
    btnChallenge: cc.Button = null;

    @property(cc.Node)
    bossArea: cc.Node = null;

    @property(cc.Node)
    icoKilled: cc.Node = null;

    @property(cc.Label)
    labelCost: cc.Label = null;

    @property(cc.Node)
    nodeCost: cc.Node = null;

    @property(cc.SpriteFrame)
    rankFrames: cc.SpriteFrame[] = [];

    @property(cc.Material)
    spineMaterials: cc.Material[] = [];

    protected _modal: ActivityModal = null;
    protected _top3: RankData[] = [];

    onLoad() {
        super.onLoad();
        this.skillTemplate.parent = null;
        this.top3AvatarTemplate.parent = null;

        this.registerEvents();
    }

    onDestroy() {
        super.onDestroy();
        UnionSkill.lastUnionSkill = null;
        this.skillTemplate.destroy();
        this.top3AvatarTemplate.destroy();
    }

    start() {
        super.start();
        this._updateView();
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onTouch, () => {
            EManager.emit(EName.onClosePanel, "SkillGetDetailPanel");
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onGameExit, async (data: { type: BattleType }) => {
            if (data.type == BattleType.Record || data.type == BattleType.PVP_PlayBack)
                return;

            this.unschedule(this._updateTimestamp);
            await this._activityReq();
            this._updateView();
        });
        this._eventListeners.push(listener);
    }

    onChallenge() {
        let modal = this._modal as ActivityWorldBossModal;
        let ret = modal.canChallenge();
        if (ret.result) {
            let config = modal.actConfig as WorldBossActConfig;
            let data = modal.roleActivityDatas as WorldBossActivityDatas;
            if (data.challengeCount >= config.freeCount) {
                let cost = modal.diamondCost;
                gm.dialog({
                    content: stringUtils.getString(stringConfigMap.key_sure_to_cost_diamond.Value, { count: cost }),
                    confirm: () => {
                        gcc.core.showLayer("prefabs/panel/battle/BattlePreparePanel", {
                            data: modal
                        });
                    }
                })
            }
            else {
                gcc.core.showLayer("prefabs/panel/battle/BattlePreparePanel", {
                    data: modal
                });
            }
        }
        else {
            let good = bagLogic.getGood(Good.GoodId.Diamond);
            if (ret.message == stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })) {
                gm.diamondLessToast();
            }
            else {
                gm.toast(ret.message);
                if (ret.message == stringConfigMap.key_activity_finished.Value) {
                    this.closePanel();
                }
            }
        }
    }

    onHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "worldboss" } });
    }

    onRank() {
        gcc.core.showLayer("prefabs/panel/activity/worldboss/WorldBossRankPanel", {
            data: (top3: RankData[]) => {
                this._top3 = top3;
                this._updateRankArea();
            }
        });
    }

    onReward() {
        gcc.core.showLayer("prefabs/panel/activity/worldboss/WorldBossRewardPanel");
    }

    protected _updateView() {
        if (this._modal) {
            let modal = this._modal as ActivityWorldBossModal;
            let config = this._modal.actConfig as WorldBossActConfig;
            let data = this._modal.roleActivityDatas as WorldBossActivityDatas;
            if (this._modal.remainTime > 0) {
                this.labelRemainTime.string = timeUtils.formatDay(this._modal.remainTime, true);
                this.btnChallenge.interactable = data.challengeCount < config.limitCount;
            }
            else {
                this.labelRemainTime.string = stringConfigMap.key_activity_finished.Value;
                this.btnChallenge.interactable = false;
            }
            this.labelRemainCount.string = stringUtils.getString(stringConfigMap.key_remain_count.Value, {
                cur: config.limitCount - data.challengeCount,
                total: config.limitCount
            });
            if (data.challengeCount >= config.freeCount && data.challengeCount < config.limitCount) {
                this.nodeCost.active = true;
                this.labelCost.string = modal.diamondCost.toString();
            }
            else {
                this.nodeCost.active = false;
            }

            this._updateRankArea();
            this._updateBossArea();
        }
        else {
            this.labelRemainTime.string = stringConfigMap.key_activity_finished.Value;
            this.labelRemainCount.node.active = false;
            this.btnChallenge.interactable = false;
            this.top3Node.active = false;
            this.bossArea.active = false;
        }
    }

    protected _updateRankArea() {
        if (this._top3.length > 0) {
            this.top3Node.active = true;
            let content = this.top3Node.getChildByName("content");
            for (let child of content.children) {
                child.active = false;
            }
            for (let data of this._top3) {
                let parent = content.getChildByName(`no${data.getRank()}`);
                parent.active = true;

                let avatar = parent.getChildByName("avatar");
                if (!avatar) {
                    avatar = cc.instantiate(this.top3AvatarTemplate);
                }
                avatar.scale = data.getRank() == 1 ? 1 : 0.75;
                avatar.parent = parent;

                let icon = avatar.getComponent(ActivityWorldBossRankIcon);
                icon.refresh(data);
            }
        }
        else {
            this.top3Node.active = false;
        }
    }

    protected _updateBossArea() {
        let config = this._modal.actConfig as WorldBossActConfig;
        let data = this._modal.roleActivityDatas as WorldBossActivityDatas;
        let boss = config.boss;

        gm.createHeroSpine(boss, this.bossSkeleton);
        this.labelBossName.string = boss.getName();

        let skills = boss.getSkills();
        this.skillsNode.destroyAllChildren();
        for (let skill of skills) {
            if (!skill.isShow()) continue;

            let item = cc.instantiate(this.skillTemplate);
            item.parent = this.skillsNode;

            let comp = item.getComponent(UnionSkill);
            comp.refresh({ skill: skill, hero: boss });

            item.on("click", comp.onCellClick, comp);
        }

        this.icoKilled.active = data.rebornTimestamp >= 0;
        this.bossSkeleton.setMaterial(0, data.rebornTimestamp == -1 ? this.spineMaterials[0] : this.spineMaterials[1]);

        let delta = data.rebornTimestamp - gm.getCurrentTimestamp();
        if (delta >= 0) {
            this.labelPercentage.node.active = false;
            this.progressBar.progress = 0;
            this.labelProgress.string = timeUtils.formatTime(delta / 1000);
            this.unschedule(this._updateTimestamp);
            this.schedule(this._updateTimestamp, 0.2);
        }
        else {
            this.progressBar.progress = data.hpNow / config.hp;
            this.labelPercentage.node.active = true;
            this.labelPercentage.string = `${Math.floor(this.progressBar.progress * 100)}%`;
            this.labelProgress.string = `${stringUtils.formatValueByWan(data.hpNow)}/${stringUtils.formatValueByWan(config.hp)}`;
        }
    }

    protected async _updateTimestamp() {
        let data = this._modal.roleActivityDatas as WorldBossActivityDatas;
        let delta = data.rebornTimestamp - gm.getCurrentTimestamp();
        if (delta > 0) {
            this.labelProgress.string = stringUtils.getString(stringConfigMap.key_after_reborn.Value, { time: timeUtils.formatTime(delta / 1000) });
        }
        else {
            this.unschedule(this._updateTimestamp);
            await this._activityReq();
            this._updateView();
        }
    }

    protected async _activityReq() {
        try {
            await activityLogic.activityReq(ActivityType.WorldBoss);
            this._modal = activityLogic.getActivityConfigs(ActivityType.WorldBoss);

            let req = new RankListReq();
            req.customKey = this._modal.id;
            req.start = 0;
            req.end = req.start + 2;
            let proto = await gm.request<RankListVO>(GameProxy.apirankmyGameRank, req);
            for (let vo of proto.rankDetail) {
                this._top3.push(new RankData(vo));
            }
            this._top3.sort((a: RankData, b: RankData) => { return a.getRank() - b.getRank() });

            await storageUtils.request(Storage.WorldBossHurt.Key + this._modal.id);

            let config = this._modal.actConfig as WorldBossActConfig;
            let url = commonUtils.getHeroSpineUrl(config.boss.getSpineFile());
            if (!cc.loader.getRes(url, sp.SkeletonData)) {
                let skeletonData = await loadUtils.loadRes(url, sp.SkeletonData);
                skeletonData.lock();
                this._unloadInfos.push({ url: url, type: sp.SkeletonData });
            }
        } catch (e) {
            console.error(e);
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();

        await this._activityReq();
    }

    protected _unloadRes(prefab: cc.Prefab) {
        for (let info of this._unloadInfos) {
            if (info.type == sp.SkeletonData) {
                let res = cc.loader.getRes(info.url, info.type) as sp.SkeletonData;
                if (res) { res.unlock() }
            }
        }
        super._unloadRes(prefab);
        loadUtils.releaseAssetRecursively(this.spriteBg.spriteFrame);
    }
}
