import { PopupPanel } from "../BasePanel";
import cm from '../../../manager/ConfigManager';
import gm from "../../../manager/GameManager";
import benefitLogic from "../../../logics/BenefitLogic";
import rechargeLogic from "../../../logics/RechargeLogic";
import EManager, { EName } from "../../../manager/EventManager";
import timeUtils from "../../../utils/TimeUtils";
import Good, { GoodId } from "../../../data/card/Good";
import GuideBaseStep from "../../widget/guide/GuideBaseStep";
import commitLogic from "../../../logics/CommitLogic";
import { StoreId } from "../../../utils/DefineUtils";
import activityLogic, { ActivityType } from "../../../logics/ActivityLogic";
import MonthOrderActConfig from "../../../data/activity/actconfig/MonthOrderActConfig";
import MonthOrderActivityDatas from "../../../data/activity/roleactivitydatas/MonthOrderActivityDatas";
import stringUtils from "../../../utils/StringUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import bagLogic from "../../../logics/BagLogic";
import loadUtils from "../../../utils/LoadUtils";
import commonUtils from "../../../utils/CommonUtils";
import { GoodVO } from "../../../proxy/GameProxy";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/MonthOrderPanel")
export default class MonthOrderPanel extends PopupPanel {

    @property(cc.Node)
    unlockRewards: cc.Node = null;

    @property(cc.Node)
    unlockItems: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    priceLabel: cc.Node = null;

    @property(cc.Node)
    time: cc.Node = null;

    @property(cc.Sprite)
    btnDailyReward: cc.Sprite = null;

    @property(cc.Label)
    labelDailyReward: cc.Label = null;

    onInit(data: any) {
        super.onInit(data);
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
        this.unlockItems.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
        this.unlockItems.destroy();
    }

    start() {
        super.start();
        this.initReward();

        let cfg = cm.getStoreConfig(StoreId.MonthOrder);
        this.priceLabel.getComponent(cc.Label).string = rechargeLogic.getMoneyUnit() + `${cfg.money}`;

        let endTs: number = this.moModal().closeAt;
        let leftSec: number = (endTs - gm.getCurrentTimestamp()) / 1000;
        let str = `活动已结束`;
        if (leftSec > 0) {
            str = stringUtils.getString(stringConfigMap.key_activity_remain_time.Value, {
                time: timeUtils.formatDay(leftSec * 1000, true)
            });
        }
        this.time.getComponent(cc.Label).string = str;

        let goodId: number = this.moCfg().getDailyRewardId();
        loadUtils.loadSpriteFrame(commonUtils.getGoodSIconUrl(goodId), this.btnDailyReward);

        this.labelDailyReward.string = 'x' + this.moCfg().getDailyRewardNum();

        commitLogic.payPanelShow('', StoreId.MonthOrder);
    }

    update(dt: number) {
        super.update(dt);
    }

    protected initReward() {
        let data = this.moCfg().getAllPayReward();

        this.unlockRewards.destroyAllChildren();
        let row = Math.ceil(data.length / 4);
        for (let i = 0; i < row; i++) {
            let tmp = cc.instantiate(this.unlockItems);
            tmp.parent = this.unlockRewards;
            for (let j = 0; j < 4; j++) {
                let index: number = i * 4 + j;
                if (index < data.length) {
                    gm.showGoodItem(data[index], {
                        goodItem: this.goodItem,
                        equipItem: this.equipItem,
                        heroItem: this.heroItem,
                    }, tmp.getChildByName('rewards'))
                }
            }
        }
    }

    protected moModal() {
        return activityLogic.getActivityConfigs(ActivityType.MonthOrder);
    }
    protected moData(): MonthOrderActivityDatas {
        return this.moModal().roleActivityDatas as MonthOrderActivityDatas;
    }
    protected moCfg(): MonthOrderActConfig {
        return this.moModal().actConfig as MonthOrderActConfig;
    }

    async onClickBuy() {
        await rechargeLogic.iap(StoreId.MonthOrder);
        await rechargeLogic.storeBuyInfoReq();
        this.closePanel();
    }

    onClickDailyReward() {
        let goodId: number = this.moCfg().getDailyRewardId();
        let num: number = this.moCfg().getDailyRewardNum();
        let vo = new GoodVO();
        vo.amt = num;
        vo.propId = goodId;
        let good = new Good(vo);
        gcc.core.showLayer("prefabs/panel/bag/BagInfoPanel", {
            modalTouch: true,
            data: { good: good, noUse: true },
        });
    }
}
