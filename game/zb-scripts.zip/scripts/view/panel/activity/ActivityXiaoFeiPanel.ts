import { FullscreenPanel } from "../BasePanel";
import EManager, { EName } from "../../../manager/EventManager";
import activityLogic, { ActivityType } from "../../../logics/ActivityLogic";
import gm from "../../../manager/GameManager";
import commonUtils from "../../../utils/CommonUtils";
import loadUtils from "../../../utils/LoadUtils";
import XiaoFeiDaRen from "../../component/Activity/XiaoFeiDaRen";
import XiaoFeiDaRenActivityDatas from "../../../data/activity/roleactivitydatas/XiaoFeiDaRenActivityDatas";
import stringUtils from "../../../utils/StringUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import timeUtils from "../../../utils/TimeUtils";
import gotoUtils, { GotoModule } from "../../../utils/GotoUtils";
import CustomScrollView from "../../../gleecomponent/CustomScrollView";
import XiaoFeiDaRenActConfig from "../../../data/activity/actconfig/XiaoFeiDaRenActConfig";
import actTabLogic from "../../../logics/ActTabLogic";

const { ccclass, property, menu } = cc._decorator;

type ActivityTab = {
    type: ActivityType,
    bg: string,
    img: string,
    name: string,
    prefab: string,
    isValid: Function,
    remainTime: Function
}

let activityList: ActivityTab[] = [
    {

        type: ActivityType.XiaoFeiDaRen,
        bg: "activity_bg_xiaofeidaren",
        img: "tab_xiaofeidaren",
        name: "消费达人",
        prefab: "XiaoFeiDaRen",
        isValid: () => { return true; },
        remainTime: () => { return 0; }
    },
]

@ccclass
@menu("view/panel/activity/ActivityXiaoFeiPanel")
export default class ActivityXiaoFeiPanel extends FullscreenPanel {

    @property(cc.Node)
    titleBg: cc.Node = null;

    @property(cc.Node)
    prefabNode: cc.Node = null;

    @property(cc.Node)
    list: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Label)
    leftTime: cc.Label = null;

    protected _tags: string[] = [];

    protected _activitys: ActivityTab[] = [];
    protected _currentTabPageIndex: number = -1;
    protected _showActivityType: number = 0;
    protected _prefabs: { [key: string]: cc.Node } = {};

    protected async _preloadRes() {
        await super._preloadRes();
        let url: string = "";
        for (let tab of activityList) {
            this._unloadInfos.push({ url: commonUtils.getBgUrl(tab.bg), type: cc.SpriteFrame });
            url = url.length > 0 ? url : commonUtils.getBgUrl(tab.bg);
        }
        await loadUtils.loadRes(url, cc.SpriteFrame);
        loadUtils.loadSpriteFrame(url, this.titleBg.getComponent(cc.Sprite));
        this.reqActivityData();
    }

    async reqActivityData(force?: boolean) {
        await activityLogic.activityReq(ActivityType.XiaoFeiDaRen);
    }

    onInit(data: any) {
        super.onInit(data);
    }

    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    start() {
        super.start();
        this._activitys = activityList.filter((v, i, a) => { return v.isValid(); });
        this.registerEvents();
        this.updateView();
    }

    get xiaofeiModal() {
        return activityLogic.getActivityConfigs(ActivityType.XiaoFeiDaRen);
    }

    get xiaofeiActivityData(): XiaoFeiDaRenActivityDatas {
        if (!this.xiaofeiModal) { return null; }
        return this.xiaofeiModal.roleActivityDatas as XiaoFeiDaRenActivityDatas;
    }

    protected updateView() {
        this._tags = this.xiaofeiActivityData ? this.xiaofeiActivityData.getXiaoFeiTags() : [];
        this.list.getComponent(CustomScrollView).setData(this._tags, this.onItemRender.bind(this))

        let remainTime = activityLogic.getActivityRemainTime(ActivityType.XiaoFeiDaRen);
        this.leftTime.string = stringUtils.getString(stringConfigMap.key_activity_remain_time.Value, {
            time: timeUtils.formatDay(remainTime, true)
        });
    }

    protected onItem(data: any, data1: any, data2: any) {
        console.log('item');
    }

    protected onItemRender(item: cc.Node, index: number, data: any) {
        //console.log('item index: ' + index);
        let tag: string = this._tags[index];

        let btnRecv = item.getChildByName("btnRecv").getComponent(cc.Button);
        let btnGo = item.getChildByName("btnPay").getComponent(cc.Button);
        let lbRecv = item.getChildByName("claimed").getComponent(cc.Label);
        lbRecv.node.active = this.xiaofeiActivityData.isRecv(tag);
        btnRecv.node.active = !this.xiaofeiActivityData.isRecv(tag) && this.xiaofeiActivityData.canRecv(tag);
        btnGo.node.active = this.xiaofeiActivityData.waitRecv(tag);
        btnRecv.clickEvents[0].customEventData = tag;

        let costDesc = item.getChildByName("layout").getChildByName("num");
        costDesc.getComponent(cc.Label).string = this.xiaofeiActivityData.getCostDesc(tag);
        costDesc.color = this.xiaofeiActivityData.waitRecv(tag) ? cc.Color.WHITE : cc.Color.GREEN;

        // 奖励
        let rewards = item.getChildByName("rewards");

        rewards.destroyAllChildren();
        let cfg = this.xiaofeiModal.actConfig as XiaoFeiDaRenActConfig;
        let reward = cfg.getRewards(this.xiaofeiActivityData.getData(tag).needProgress);
        for (let i = 0; i < reward.length; i++) {
            gm.showGoodItem(reward[i], {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem
            }, rewards, 0.8);
        }
    }

    onClickGotoPay() {
        actTabLogic.closeNowActPanel();
        gotoUtils.gotoPanel(GotoModule.Store, false, null, true);
    }

    onClickRecv(event: cc.Event.EventTouch, index: string) {
        let data = this.xiaofeiActivityData.getData(index);
        this.doRecv(this.xiaofeiModal.id, data.tag);
    }

    async doRecv(id: string, tag: string) {
        try {
            await activityLogic.xiaofeiDarenRewardReq(id, tag);
            this.xiaofeiActivityData.setRecv(tag, true);
            this.updateView();
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.XiaoFeiDaRen);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
                this.updateView();
            }
            else {
                throw e;
            }
        }
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onFreshPanel, async (data) => {
            if (data === "ActivityXiaoFeiPanel") {
                await this.reqActivityData(true);
                this.updateView();
            }
        })
        this._eventListeners.push(listener);
    }

    update(dt: number) {

    }

    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }
}
