import { FullscreenPanel } from "../BasePanel";
import ActivityDailyLightTab from "../../component/Activity/ActivityDailyLightTab";
import gm from "../../../manager/GameManager";
import CommonLoader from "../../common/CommonLoader";
import EManager, { EName } from "../../../manager/EventManager";
import timeUtils from "../../../utils/TimeUtils";
import commonUtils from "../../../utils/CommonUtils";
import loadUtils from "../../../utils/LoadUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import stringUtils from "../../../utils/StringUtils";
import activityLogic, { ActivityType } from "../../../logics/ActivityLogic";
import { SevenInfoModal } from "../../../data/activity/SevenInfoModal";
import Activechargeconfig from "../../../configs/Activechargeconfig";
import ActivityChargeDailyLightItem from "../../component/Activity/ActivityChargeDailyLightItem";
import cm from "../../../manager/ConfigManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityChargePanel")
export default class ActivityChargePanel extends FullscreenPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Sprite)
    title: cc.Sprite = null;

    @property(cc.Label)
    lastTime: cc.Label = null;

    @property(cc.Label)
    chargeDays: cc.Label = null;

    @property(cc.Node)
    bigItemNode: cc.Node = null;

    @property(cc.Node)
    tabNode: cc.Node = null;

    @property(cc.Node)
    itemNode: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Label)
    dailyCharge: cc.Label = null;

    @property(cc.Button)
    recvBtn: cc.Button = null;

    @property(cc.Label)
    recvLabel: cc.Label = null;

    @property(cc.Label)
    rewardTime: cc.Label = null;

    @property(cc.Node)
    tips: cc.Node = null;

    protected _activeType: ActivityType = ActivityType.None;
    protected _sevenInfo: SevenInfoModal = null;
    protected _nowId: number = 1;

    onInit(data: ActivityType) {
        super.onInit(data);
        this._activeType = data - 2000;
        if (activityLogic.getActivityConfigs(this._activeType)) {
            this._sevenInfo = activityLogic.getActivityConfigs(this._activeType).sevenInfo;
        }
    }

    public reloadPanel(data: ActivityType) {
        this.data = data;
        this._activeType = data - 2000;
        if (activityLogic.getActivityConfigs(this._activeType)) {
            this._sevenInfo = activityLogic.getActivityConfigs(this._activeType).sevenInfo;
        }

        this.start();
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;

        let listener = EManager.addEvent(EName.onUpdateDailyLight, (id: number) => {
            this._nowId = id;
            this._refreshItem();
            this._refreshRecvBtn(id);
        });
        this._eventListeners.push(listener);
    }

    onDestroy() {
        super.onDestroy();

        ActivityDailyLightTab._lastDailyLightTab = null;

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    async start() {
        super.start();
        let url = commonUtils.getBgUrl(`activity_act_light`);
        loadUtils.loadSpriteFrame(url, this.bg);
        loadUtils.loadSpriteFrame(`textures/ui/panel/activity_dailylight/text_charge${cm.activeList.indexOf(this._activeType) + 1}`, this.title);
        await this._refreshAll();
    }

    protected async _refreshAll(flag: boolean = true) {
        if (!this._sevenInfo) {
            return;
        }
        let activityEnd = this._sevenInfo.nowDay > 7;
        this.chargeDays.string = this._sevenInfo.continuityChargeDays + "/7";
        this._refreshItem(true);
        this._refreshBigItem();
        if (flag) {
            this._refreshTime();
        }
        this.tips.active = !activityEnd;
        if (activityEnd) {
            console.log("活动已结束");
            return;
        }
        this.unscheduleAllCallbacks();
        this.schedule(this._refreshTime, 1);
    }

    protected _refreshTime() {
        let diffTime = this._sevenInfo.remainTime;
        if (Math.floor(diffTime) > 0) {
            this.lastTime.string = stringConfigMap.key_activity_end.Value + " " + timeUtils.formatDay(Math.floor(diffTime), true);
        } else {
            this.lastTime.string = stringConfigMap.key_activity_finished.Value;
            this.rewardTime.string = stringConfigMap.key_activity_finished.Value;
            this.unscheduleAllCallbacks();
            return;
        }
        let time = gm.getCurrentTimestamp();
        let date = new Date(time);
        date.setMilliseconds(0);
        date.setSeconds(0);
        date.setMinutes(0);
        // date.setHours(24);
        date.setUTCHours(24);
        diffTime = Math.floor((date.getTime() - gm.getCurrentTimestamp()) / 1000);
        if (diffTime > 0) {
            this.rewardTime.string = timeUtils.formatDaySecond(diffTime * 1000);
        } else if (diffTime == 0) {
            this._refreshAll(false);
        } else {
            this.rewardTime.string = "";
        }
    }

    protected _refreshItem(showTab: boolean = false) {
        let day = this._sevenInfo.nowDay;
        if (day > 7) {
            day = 7;
        }
        let chargeCfgs = Activechargeconfig.where(a => a.days == day && a.Activeid == this._activeType);
        let whichTotal = this._sevenInfo.canReceive(day);
        if (whichTotal == -1) {
            whichTotal = 0;
        }
        for (let charge of chargeCfgs) {
            if (this._nowId == charge.ID) {
                this._showItemById(charge.ID);
            }
            if (showTab) {
                if (chargeCfgs.indexOf(charge) == (whichTotal == 0 ? 0 : whichTotal - 1)) {
                    this._nowId = charge.ID;
                    this._showItemById(charge.ID);
                    this._refreshRecvBtn(charge.ID);
                }
                this._showItemTab(charge.ID, chargeCfgs.indexOf(charge) == (whichTotal == 0 ? 0 : whichTotal - 1));
            }
        }
    }

    protected _refreshBigItem() {
        for (let i = 1; i <= 3; i++) {
            this._showBigItemById(i);
        }
    }

    protected _showItemTab(id: number, check: boolean = false) {
        let chargeCfg = Activechargeconfig[id - 1];
        let chargeCfgs = Activechargeconfig.where(a => a.days == chargeCfg.days && a.Activeid == this._activeType);
        let index = chargeCfgs.indexOf(chargeCfg) + 1;
        let tab = cc.find(`tab${index}`, this.tabNode);
        if (tab) {
            tab.getComponent(ActivityDailyLightTab).refresh(id);
            if (check) {
                tab.getComponent(ActivityDailyLightTab).doTab(false);
            }
        }
    }

    protected _showItemById(id: number) {
        let chargeCfg = Activechargeconfig[id - 1];
        this.itemNode.destroyAllChildren();
        for (let reward of chargeCfg.reward) {
            gm.showGoodItem(reward, {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem
            }, this.itemNode);
        }
    }

    protected _refreshRecvBtn(id) {
        let dayCharge = 0;
        if (this._sevenInfo.nowDay > 7) {
            this.recvBtn.interactable = false;
            this.recvLabel.string = stringConfigMap.key_desc_21.Value;
            this.dailyCharge.node.active = false;
        } else {
            this.recvBtn.interactable = !this._sevenInfo.isReceived(id);
            this.recvLabel.string = this._sevenInfo.isReceived(id) ? stringConfigMap.key_claimed.Value : stringConfigMap.key_desc_21.Value;
            this.dailyCharge.node.active = true;
            dayCharge = this._sevenInfo.dayCharge(id);
            this.dailyCharge.string = stringUtils.getString(stringConfigMap.key_today_charge.Value, { amount: dayCharge });
        }
    }

    protected _showBigItemById(id: number) {
        let item = cc.find(`item${id}`, this.bigItemNode);
        if (item) {
            let loaderNode = item.getComponent(CommonLoader).loaderNode;
            let configs = Activechargeconfig.where(a => a.Activeid == this._activeType && a.chargenumber < 0);
            loaderNode.getComponent(ActivityChargeDailyLightItem).refresh(configs[id - 1].ID);
        }
    }

    async onRecvReward() {
        if (this._sevenInfo.remainTime <= 0) {
            if (this._sevenInfo.canReceive(this._nowId) != -1) {
                gm.toast(stringConfigMap.key_activity_finish_tip.Value);
            } else {
                gm.toast(stringConfigMap.key_activity_finished.Value);
            }
            return;
        }
        if (this._sevenInfo.canReceive(this._nowId) == -1) {
            let needChargeAmt = Activechargeconfig[this._nowId - 1].chargenumber;
            let nowChargeAmt = this._sevenInfo.nowDayCharge;
            let needCharge = needChargeAmt - nowChargeAmt;
            gm.toast(stringUtils.getString(stringConfigMap.key_charge_more.Value, { amount: needCharge }));
            return;
        }
        try {
            if (this._nowId > 0) {
                await activityLogic.doGetActSevenReward(this._activeType, this._nowId);
                this._refreshRecvBtn(this._nowId);
                EManager.emit(EName.onUpdateDailyTab);
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("activity_act_light"), type: cc.SpriteFrame });
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);

    }

}
