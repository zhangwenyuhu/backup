import { PopupPanel } from "../BasePanel";
import activityLogic, { ActivityType } from "../../../logics/ActivityLogic";
import sevenDaysSignConfig, { sevenDaysSignConfigRow } from "../../../configs/sevenDaysSignConfig";
import GuideBaseStep from "../../widget/guide/GuideBaseStep";
import List from "../../common/List";
import ActivitySignItem from "../../component/Activity/ActivitySignItem";
import { SevenDaySignInfoVO } from "../../../proxy/GameProxy";
import gm from "../../../manager/GameManager";
import EManager, { EName } from "../../../manager/EventManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivitySignPanel")
export default class ActivitySignPanel extends PopupPanel {
    @property(List)
    signList: List = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
        this.goodItem.y = 0;
        this.equipItem.y = 0;
        this.heroItem.y = 0;
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();

        if (!GuideBaseStep.isGuiding) {
            if (gm.needCheckPopFirstPay && gm.checkPopFirstPay(true)) {
                gm.checkPopFirstPay();
            } else {
                gm.needCheckPopFirstPay = false;
                gm.checkArenaReport();
            }
        }
        EManager.emit(EName.onUpdateActivityDatas, ActivityType.Day7Sign);
    }

    async start() {
        super.start();

        await activityLogic.doGetSevenDaySignInfo();
        if (!cc.isValid(this.node)) return;

        this.signList.getComponent(cc.Widget).updateAlignment();
        this.signList.numItems = sevenDaysSignConfig.length;

        let listId = 0;
        let infos = activityLogic.sevenDaySignInfo;
        infos.sort((a: SevenDaySignInfoVO, b: SevenDaySignInfoVO) => { return a.day - b.day });
        for (let i = 0; i < infos.length; i++) {
            let info = infos[i];
            if (info.recv) listId++;
        }
        this.signList.scrollTo(listId, 0.2);
    }

    update(dt: number) {
        super.update(dt);
        if (GuideBaseStep.isGuiding) {
            this.closePanel();
        }
    }

    onActivitySignItemRender(item: cc.Node, index: number) {
        let comp = item.getComponent(ActivitySignItem);
        comp.refresh({
            config: sevenDaysSignConfig[index],
            goodTemplate: this.goodItem,
            equipTemplate: this.equipItem,
            heroTemplate: this.heroItem
        });
    }
}