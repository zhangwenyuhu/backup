import { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import battlescoreconfig, { battlescoreconfigRow } from "../../../configs/battlescoreconfig";
import NewServerBonusItem from "../../component/Activity/NewServerBonusItem";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/NewServerBonusPanel")
export default class NewServerBonusPanel extends PopupPanel {
    @property(List)
    bonusList: List = null;

    protected _bonuses: any[] = [];

    onInit(data: any[]) {
        super.onInit(data);
        this._bonuses = data;
    }

    start() {
        super.start();

        this.bonusList.numItems = this._bonuses.length;
    }

    onBonusItemRender(item: cc.Node, index: number) {
        let comp = item.getComponent(NewServerBonusItem);
        comp.refresh(this._bonuses[index], index);
    }
}
