import { PopupPanel } from "../BasePanel";
import bagLogic from "../../../logics/BagLogic";
import Good from "../../../data/card/Good";
import gm from "../../../manager/GameManager";
import CommonLoader from "../../common/CommonLoader";
import { GoodVO } from "../../../proxy/GameProxy";
import GoodCard from "../../component/Good/GoodCard";
import goodsConfig from "../../../configs/goodsConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityTicketBuyPanel")
export default class ActivityTicketBuyPanel extends PopupPanel {

    @property(cc.Label)
    ticketCnt: cc.Label = null;

    @property(cc.Label)
    now: cc.Label = null;

    @property(cc.Label)
    need: cc.Label = null;

    @property(CommonLoader)
    good_card: CommonLoader = null;

    @property(cc.Label)
    prop_name: cc.Label = null;

    protected _cnt: number = 1;

    onInit(data: {
        goodId: number,
        limitCount: number,
        price: number,
        buyFunc: Function
    }) {
        super.onInit(data);
    }

    start() {
        super.start();
        this.ticketCnt.string = `1/${this.data.limitCount}`;
        let goodVO = new GoodVO();
        goodVO.amt = 0;
        goodVO.propId = this.data.goodId;
        goodVO.objId = "goods";
        this.good_card.loaderNode.getComponent(GoodCard).refresh(new Good(goodVO));
        let goodCfg = goodsConfig.find(a => a.parameterid == this.data.goodId);
        this.prop_name.string = goodCfg.name;
        this._refresh();
    }

    async onBuy() {
        if (this._cnt * this.data.price > bagLogic.getGood(Good.GoodId.Diamond).getAmount()) {
            gm.diamondLessToast();
            return;
        }
        try {
            await this.data.buyFunc(this._cnt);
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    onMinus() {
        if (this._cnt > 1) {
            this._cnt--;
        }
        this._refresh();
    }

    onAdd() {
        if (this._cnt < this.data.limitCount) {
            this._cnt++;
        }
        this._refresh();
    }

    protected _refresh() {
        this.ticketCnt.string = `${this._cnt}/${this.data.limitCount}`;
        let amount = slib.BigNumberHelper.convertNumStr2UnitStr(bagLogic.getGood(Good.GoodId.Diamond).getAmount().toString(), 0, 0);
        this.now.string = `/${amount}`;
        this.need.string = `${this._cnt * this.data.price}`;
        if (this._cnt * this.data.price > bagLogic.getGood(Good.GoodId.Diamond).getAmount()) {
            this.now.node.color = cc.Color.RED;
        } else {
            this.now.node.color = cc.Color.WHITE;
        }
    }

}