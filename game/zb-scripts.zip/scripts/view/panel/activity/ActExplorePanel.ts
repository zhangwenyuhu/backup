import EManager, { EName } from './../../../manager/EventManager';
import { FullscreenPanel } from "../BasePanel";
import gm from '../../../manager/GameManager';
import { MarketTab } from '../market/MarketPanel';
import { MarketLimitTab } from '../../component/Market/LimitMarketModule';
import exploreLogic, { KEY_TYPE } from '../../../logics/ExploreLogic';
import timeUtils from '../../../utils/TimeUtils';
import stringUtils from '../../../utils/StringUtils';
import activityLogic, { ActivityType } from '../../../logics/ActivityLogic';
import bagLogic from '../../../logics/BagLogic';
import { GoodId } from '../../../data/card/Good';
import { stringConfigMap } from '../../../configs/stringConfig';
import commonUtils from '../../../utils/CommonUtils';
import localLogic, { localIndex } from '../../../logics/LocalLogic';
import commitLogic, { DiamondSource } from '../../../logics/CommitLogic';

const { ccclass, property, menu } = cc._decorator;

const exploreItemNum: number = 36;
class ExploreItem {
    node: cc.Node;
    tag: number;
    pos: cc.Vec2;
}

const turnToUp: string = `ActExplorePanelIcon01`;
const turnToDown: string = `ActExplorePanelIcon02`;
const turnToRight: string = `ActExplorePanelIcon03`;
const turnToLeft: string = `ActExplorePanelIcon04`;

@ccclass
@menu("view/panel/activity/ActExplorePanel")
export default class ActExplorePanel extends FullscreenPanel {

    @property(cc.Label)
    exploreTs: cc.Label = null;

    @property(cc.Label)
    exploreKey: cc.Label = null;

    @property(cc.Label)
    exploreLevel: cc.Label = null;

    @property(cc.Node)
    finalReward: cc.Node = null;

    @property(cc.Node)
    exploreGate: cc.Node = null;

    @property(cc.Node)
    finalChange: cc.Node = null;

    @property(cc.Node)
    finalDouble: cc.Node = null;

    @property(cc.Node)
    rewards: cc.Node = null;

    @property(cc.Node)
    exploreItem: cc.Node = null;

    @property(cc.Node)
    inputBlock: cc.Node = null;

    @property(cc.Node)
    guideEffect: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    protected _explorePool: ExploreItem[] = [];
    protected _exploreEnd: boolean = false;
    protected _rewards: number[][] = [];
    protected _canExplore: boolean = false;
    protected _validFinalEffect: boolean = false;
    protected _effecting: boolean = false;
    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("activity_bg_explore"), type: cc.SpriteFrame });

        await activityLogic.activityReq(ActivityType.Explore);
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
        this.exploreItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        EManager.emit(EName.onUpdateActivityDatas, ActivityType.Explore);

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
        this.exploreItem.destroy();
    }

    async resetExplore() {
        await activityLogic.activityReq(ActivityType.Explore);
        this.freshUI();
        this.freshAllExploreItem();
    }

    async start() {
        super.start();
        this.inputBlock.active = false;
        this._canExplore = exploreLogic.getFinalId() > 0;
        this.freshGate(false, cc.v2());
        this.initExplore();
        this.freshUI();

        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data == "ActExplorePanel") {
                this.exploreKey.string = `${exploreLogic.getKeyAmt()}`;
            }
        });
        this._eventListeners.push(listener);
        this.schedule(() => { this.freshActivityTime(); }, 1);
        this.finalSettingGuide();
        localLogic.setData(localIndex.exploreRead, true);
    }

    // 未设置终极奖励时提示玩家设置终极奖励
    finalSettingGuide() {
        if (!this._canExplore) {
            this.changeFinal()
            this.freshAllExploreItem(true);
        }
    }

    update(dt: number) {
        super.update(dt);
    }

    freshUI() {
        this.exploreKey.string = `${exploreLogic.getKeyAmt()}`;
        this.exploreLevel.string = `第${exploreLogic.getExploreLevel()}层`;
        this.freshFinalReward();
        this.freshActivityTime();

        this.finalChange.active = exploreLogic.isBuffValid(KEY_TYPE.ChangeFinal);
        this.finalDouble.active = exploreLogic.isBuffValid(KEY_TYPE.Double);
        this._canExplore = exploreLogic.getFinalId() > 0;
        this.validFinalSettingEffect(!this._canExplore);
    }

    freshGate(valid: boolean, pos: cc.Vec2) {
        this.exploreGate.active = valid;
        this.exploreGate.position = pos;
    }

    freshActivityTime() {
        // 活动持续时间
        let endTs: number = exploreLogic.getExploreModal().closeAt;
        let leftSec: number = (endTs - gm.getCurrentTimestamp()) / 1000;
        this.checkExploreTime();
        //console.warn(`探趣寻宝活动剩余时间: ${leftSec} s`);
        let title: string = "";
        if (this._exploreEnd) {
            let ex: string = leftSec > 0 ? timeUtils.formatTime(leftSec) : "00:00:00";
            title = `活动已结束 ` + ex;
        } else {
            title = `活动倒计时 ` + stringUtils.formatTimeWithHour(leftSec);
        }
        this.exploreTs.string = title;
    }

    checkExploreTime() {
        let endTs: number = exploreLogic.getExploreModal().closeAt;
        let leftSec: number = (endTs - gm.getCurrentTimestamp()) / 1000;
        this._exploreEnd = leftSec <= 0;
    }

    freshFinalReward() {
        this.finalReward.destroyAllChildren();
        let final: number[] = [];
        let finalId: number = exploreLogic.getFinalId();
        if (finalId > 0) {
            let cfg = exploreLogic.getFinalCfg().find((a) => { return a.ID == finalId; })
            if (cfg) {
                final = cfg.finalreward;
            }
        }
        gm.showGoodItem(final, {
            goodItem: this.goodItem,
            equipItem: this.equipItem,
            heroItem: this.heroItem
        }, this.finalReward);
    }

    initExplore() {
        this.rewards.destroyAllChildren();
        this._explorePool = [];
        for (let i = 0; i < exploreItemNum; i++) {

            let node = cc.instantiate(this.exploreItem);
            node.parent = this.rewards;

            let tmp = new ExploreItem;
            tmp.tag = i;
            tmp.node = node;
            tmp.pos = null;
            this._explorePool.push(tmp);

            this.freshExploreItem(tmp);
        }
        this.scheduleOnce(() => {
            for (let i = 0; i < exploreItemNum; i++) {
                this._explorePool[i].pos = this._explorePool[i].node.position;
            }
        }, 3 / 30);
    }

    freshAllExploreItem(reward?: boolean) {
        this.freshGate(false, cc.v2());
        if (reward) { this.makeAllExploreReward(); }
        for (let i = 0; i < this._explorePool.length; i++) {
            this.freshExploreItem(this._explorePool[i], reward);
            if (this._explorePool[i].pos) {
                this._explorePool[i].node.position = this._explorePool[i].pos;
            }
        }
    }

    protected freshExploreItem(data: ExploreItem, reward?: boolean) {
        if (!data) { return; }
        let node = data.node;
        if (!node || !cc.isValid(node)) { return; }

        let btn = node.getChildByName("btn").getComponent(cc.Button);
        btn.clickEvents[0].customEventData = `${data.tag}`;

        let rewardNode = node.getChildByName("reward");
        let rect = node.getChildByName("rect");
        let mask = node.getChildByName("mask");
        let icon = node.getChildByName("icon");
        let addEffect = node.getChildByName("add");
        addEffect.active = false;
        rewardNode.active = false;
        if (reward) {
            icon.active = false;
            mask.active = false;
            rect.active = false;
            rewardNode.destroyAllChildren();
            rewardNode.active = true;
            let ids = this._rewards[data.tag]
            if (ids && ids[0] > 0) {
                gm.showGoodItem(ids, {
                    goodItem: this.goodItem,
                    equipItem: this.equipItem,
                    heroItem: this.heroItem
                }, rewardNode, 0.8);
            } else {
                addEffect.active = true;
            }
            return;
        }

        let recv: boolean = exploreLogic.isBlockExplored(data.tag);
        rect.active = recv;
        mask.active = !recv;
        icon.active = false;

        let gate: boolean = exploreLogic.getFinalIndex() === data.tag;
        if (gate) {
            this.scheduleOnce(() => {
                this.freshGate(gate, node.position);
            }, 3 / 30);
        }
    }

    protected exploreItemAnimation(name: string, node: cc.Node, callback?: Function) {
        if (!node) { return; }
        let icon = node.getChildByName("icon");
        if (!icon) { return; }
        icon.active = true;

        let effect = icon.getComponent(cc.Animation);
        //console.warn("寻宝动画: " + name);
        effect.play(name, 0);
        effect.off("finished");
        effect.on("finished", (e) => {
            //this.resetAnimation(node);
            this.scheduleOnce(() => {
                //this.resetAnimation(node);
                if (callback) { callback(); }
            }, 3 / 30);
        })
    }

    protected resetAnimation(node: cc.Node) {
        if (!node) { return; }
        let icon = node.getChildByName("icon");
        if (!icon) { return; }
        icon.active = true;
        icon.getChildByName("maskbk").active = false;
        icon.getChildByName("mask").active = true;
    }

    // 探索一格
    async doExploreBlock(index: number) {
        try {
            let reward = await exploreLogic.exploreBlockReq(index);
            let buff: number = reward.extra[0] as any;

            let getBuff: boolean = buff >= KEY_TYPE.Double && buff <= KEY_TYPE.ChangeFinal;
            if (getBuff) {
                gcc.core.showLayer("prefabs/panel/activity/explore/ExploreBuffPanel", {
                    data: {
                        buffId: buff,
                        callback: () => {
                            gm.getReward(reward);
                            this.freshUI();
                        }
                    }
                });
            } else {
                gm.getReward(reward);
                this.freshUI();
                commitLogic.commitReward(reward, DiamondSource.actExplore);
            }
            //await activityLogic.activityReq(ActivityType.Explore);
            let finalGoodCfg = exploreLogic.getFinalRewardCfg(exploreLogic.getFinalId());
            let bFinal = gm.hasGood(finalGoodCfg.finalreward[0], finalGoodCfg.finalreward[1], reward);
            let goodId = gm.getGoodId(reward, [GoodId.ExploreKey]);
            let id: number = 0;
            if (bFinal) {
                let cfg = exploreLogic.getFinalCfg().find((a) => { return a.finalreward[0] == goodId[0] && a.finalreward[1] == goodId[1]; })
                id = cfg ? cfg.ID : 0;
            } else {
                let cfg = exploreLogic.getNormalCfg().find((a) => { return a.reward[0] == goodId[0] && a.reward[1] == goodId[1]; })
                id = cfg ? cfg.ID : 0;
            }
            exploreLogic.getExploreData().doExploreResult(index, bFinal, id, buff);

            bagLogic.getGood(GoodId.ExploreKey).changeAmount(-1);
            this.freshExploreItem(this._explorePool[index]);
            this.freshUI();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
                this.resetExplore();
            }
            else {
                throw e;
            }
        }
    }

    async doExploreNextLayer() {
        try {
            await exploreLogic.exploreNextLayerReq();
            await activityLogic.activityReq(ActivityType.Explore);

            this.freshAllExploreItem();
            this.freshUI();
            this.finalSettingGuide();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    // 更换终极奖励
    async doChangeFinalReward(select: number, buff: boolean = false) {
        try {
            await exploreLogic.changeFinalReq(select, buff);
            if (buff) { exploreLogic.getExploreData().useBuff(KEY_TYPE.ChangeFinal); }
            this.freshUI();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    onClickExploreNextLayer() {
        if (this.checkExploreEndTip(true)) { return; }
        gm.dialog({
            content: "确定前往下一层寻宝吗?",
            confirm: () => {
                this.doExploreNextLayer();
            }
        })
    }
    onClickExplore(event: cc.Event.EventTouch, index: string) {
        if (bagLogic.getGood(GoodId.ExploreKey).getAmount() <= 0) {
            gm.toast(stringConfigMap.key_auto_564.Value);
            return;
        }
        if (this.checkExploreEndTip(true)) { return; }
        let blockIndex = parseInt(index);
        if (exploreLogic.isBlockExplored(blockIndex)) { return; }
        if (exploreLogic.getFinalId() <= 0) {
            gm.toast(stringConfigMap.key_auto_565.Value)
            return;
        }
        this.doExploreBlock(blockIndex);
    }
    onClickHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "explore" } });
    }
    onClickRank() {
        gcc.core.showLayer("prefabs/panel/activity/explore/ExploreRankPanel");
    }
    onClickReward() {
        gcc.core.showLayer("prefabs/panel/activity/explore/ExploreRewardPanel");
    }
    onClickPreReward() {
        let data: {}[] = this.makeExploreRewardInfo();
        gcc.core.showLayer("prefabs/panel/help/PreRewardsPanel", { data: data });
    }
    onClickGo() {
        gcc.core.showLayer("prefabs/panel/market/MarketPanel", { data: { tabIndex: MarketTab.Limit, tabChildIndex: MarketLimitTab.Explore } });
    }
    onClickChangeFinal() {
        if (this.checkExploreEndTip(true)) { return; }
        if (exploreLogic.getFinalIndex() >= 0) {
            gm.toast(stringConfigMap.key_auto_566.Value);
            return;
        }
        this.changeFinal();
    }
    onClickStartExploreAnimation() {
        if (this._effecting) { return; }
        this._effecting = true;
        this.initExploreAreaAnimation(() => {
            this.inputBlock.active = false;
            this._effecting = false;
        })
    }
    protected changeFinal() {
        gcc.core.showLayer("prefabs/panel/activity/explore/ExploreFinalRewardPanel", {
            data: {
                callback: async (select: number) => {
                    let finalId: number = exploreLogic.getFinalId();
                    let buff: boolean = exploreLogic.isBuffValid(KEY_TYPE.ChangeFinal);
                    let effect: boolean = finalId <= 0;
                    if (select > 0) {
                        if (finalId > 0) {
                            await this.doChangeFinalReward(select, buff);
                        } else {
                            await this.doChangeFinalReward(select);
                        }
                    }
                    if (effect) {
                        this._canExplore = exploreLogic.getFinalId() > 0;
                        if (this._canExplore) {
                            this.inputBlock.active = true;
                            this.makeAllExploreReward();
                            this.freshAllExploreItem(true);
                        };
                    }
                    this.freshUI();
                }
            }
        });
    }

    protected initExploreAreaAnimation(callback: Function) {
        this.circleAnimation(() => { callback(); });
        return;
        // a1 up a2 left a3 down a4 left a5 right a6 down a7 up
        let a1 = this._explorePool.filter((v, i, a) => { return v.tag % 6 == 4 || v.tag % 6 == 5; })
        let a2 = this._explorePool.filter((v, i, a) => { return Math.floor(v.tag / 6) == 2 || Math.floor(v.tag / 6) == 3; })
        let a3 = this._explorePool.filter((v, i, a) => { return v.tag % 6 == 0 || v.tag % 6 == 1; })
        let a4 = this._explorePool.filter((v, i, a) => { return Math.floor(v.tag / 6) >= 0 || Math.floor(v.tag / 6) <= 2; })
        let a5 = this._explorePool.filter((v, i, a) => { return Math.floor(v.tag / 6) >= 3 || Math.floor(v.tag / 6) <= 5; })
        let a6 = this._explorePool.filter((v, i, a) => { return v.tag % 6 >= 0 || v.tag % 6 <= 2; })
        let a7 = this._explorePool.filter((v, i, a) => { return v.tag % 6 >= 3 || v.tag % 6 <= 5; })
        this.batchAnimation(a1, turnToUp, () => {
            this.batchAnimation(a2, turnToLeft, () => {
                this.batchAnimation(a3, turnToDown, () => {
                    this.batchAnimation(a4, turnToLeft);
                    this.batchAnimation(a5, turnToRight, () => {
                        this.batchAnimation(a6, turnToDown);
                        this.batchAnimation(a7, turnToUp, () => {
                            this.circleAnimation(() => {
                                this.batchAnimation(this._explorePool, turnToLeft, () => {
                                    callback();
                                })
                            })
                        })
                    })
                })
            })
        });
    }
    // 格子批量播放动画
    protected batchAnimation(arr: ExploreItem[], name: string, callback?: Function) {
        for (let i = 0; i < arr.length - 1; i++) {
            this.exploreItemAnimation(name, arr[i].node);
        }
        this.exploreItemAnimation(name, arr[arr.length - 1].node, callback);
    }
    // 旋转动画
    protected circleAnimation(callback?: Function) {
        let actionTime: number = 0.5;
        let angle: number = 360;
        let scale: number = 0;
        let a1 = cc.spawn(cc.rotateBy(actionTime, angle), cc.scaleTo(actionTime, scale));
        let a2 = cc.spawn(cc.rotateBy(actionTime, -angle), cc.scaleTo(actionTime, 1));
        this.rewards.runAction(cc.sequence(a1, cc.callFunc(() => {
            this.freshAllExploreItem();
        }), cc.delayTime(0.1), a2, cc.callFunc(() => {
            this.rewards.rotation = 0;
            if (callback) { callback(); }
        })).easing(cc.easeInOut(actionTime * 2)));
    }
    // 交换动画
    protected exchangeAnimation(callback?: Function) {
        this.rewards.getComponent(cc.Layout).enabled = false;
        let actPosPool: number[] = [];
        let max = this._explorePool.length
        for (let i = 0; i < max; i++) {
            actPosPool.push(i);
        }
        for (let i = max; i > 0; i--) {
            let random: number = Math.floor(Math.random() * i);
            let tmp = actPosPool[i - 1];
            actPosPool[i - 1] = actPosPool[random];
            actPosPool[random] = tmp;
        }

        let d1: number[][] = [];
        let pre = Math.floor(max / 2);
        for (let i = 0; i < pre; i++) {
            d1.push([actPosPool[i], actPosPool[i + pre]]);
        }
        let d2: number[][] = d1.map((v, i, a) => { return [v[1], v[0]]; });

        this.batchMoveAnimation(d1, () => {
            this.batchMoveAnimation(d2, () => {
                this.freshAllExploreItem();
                this.rewards.getComponent(cc.Layout).enabled = true;
                if (callback) { callback(); }
            })
        })
    }
    // 批量格子移动动画
    protected batchMoveAnimation(arr: number[][], callback?: Function) {
        let sec: number = 0.5;
        for (let i = 0; i < arr.length - 1; i++) {
            let start: number = arr[i][0];
            let end: number = arr[i][1];

            let pos = this._explorePool[end].pos;
            this._explorePool[start].node.runAction(cc.moveTo(sec, pos));
        }
        let data = arr[arr.length - 1];
        let endPos = this._explorePool[data[1]].pos;
        this._explorePool[data[0]].node.runAction(cc.sequence(cc.moveTo(sec, endPos), cc.callFunc(() => {
            if (callback) { callback(); }
        })));
    }

    // 探索奖励数据
    protected makeExploreRewardInfo() {
        let data: { rewards: number[], left: number, total: number }[] = [];
        let cfg = exploreLogic.getNormalCfg();
        // 普通奖励
        for (let i = 0; i < cfg.length; i++) {
            let leftCount: number = cfg[i].number - exploreLogic.getRecvCount(cfg[i].ID);
            leftCount = leftCount < 0 ? 0 : leftCount;
            data.push({
                rewards: cfg[i].reward,
                left: leftCount,
                total: cfg[i].number,
            })
        }
        // 终极奖励
        let finalId: number = exploreLogic.getFinalId();
        if (finalId > 0) {
            let cfg = exploreLogic.getFinalCfg().find((a) => { return a.ID == finalId; })
            if (cfg) {
                let recvFinal: boolean = exploreLogic.getFinalIndex() >= 0;
                let leftCount = recvFinal ? 0 : 1;
                leftCount = leftCount > 0 ? leftCount : 0;
                data.unshift({
                    rewards: cfg.finalreward,
                    left: leftCount,
                    total: 1,
                });
            }
        }
        return data;
    }
    protected makeAllExploreReward() {
        this._rewards = [];
        // 普通奖励
        let cfg = exploreLogic.getNormalCfg();
        for (let i = 0; i < cfg.length; i++) {
            for (let j = 0; j < cfg[i].number; j++) {
                this._rewards.push(cfg[i].reward);
            }
        }

        // 终极奖励
        let finalId: number = exploreLogic.getFinalId();
        if (finalId > 0) {
            let cfg = exploreLogic.getFinalCfg().find((a) => { return a.ID == finalId; })
            if (cfg) {
                this._rewards.unshift(cfg.finalreward);
            } else {
                this._rewards.unshift([0, 0]);
            }
        } else {
            this._rewards.unshift([0, 0]);
        }
    }
    protected checkExploreEndTip(toast: boolean): boolean {
        if (this._exploreEnd) {
            gm.toast(stringConfigMap.key_activity_finished.Value);
            this.closePanel();
        }
        return this._exploreEnd;
    }
    // 指引设置终极奖励
    protected validFinalSettingEffect(valid: boolean) {
        this.guideEffect.active = valid;
    }
}
