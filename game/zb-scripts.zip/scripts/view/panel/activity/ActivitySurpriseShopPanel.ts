import { FullscreenPanel } from "../BasePanel";
import List from "../../common/List";
import ActivitySurpriseShopItem from "../../component/Activity/ActivitySurpriseShopItem";
import activityLogic, { ActivityModal, ActivityType } from "../../../logics/ActivityLogic";
import SurpriseShopActConfig from "../../../data/activity/actconfig/SurpriseShopActConfig";
import loadUtils from "../../../utils/LoadUtils";
import commonUtils from "../../../utils/CommonUtils";
import bagLogic from "../../../logics/BagLogic";
import { RefreshLabel } from "../../../decorator/RefreshDecorator";
import Good from "../../../data/card/Good";
import EManager, { EName } from "../../../manager/EventManager";
import gm from "../../../manager/GameManager";
import timeUtils from "../../../utils/TimeUtils";
import goodsConfig from "../../../configs/goodsConfig";
import tipUtils from "../../../utils/TipUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import rechargeLogic from "../../../logics/RechargeLogic";
import { MarketTab } from "../market/MarketPanel";
import { MarketLimitTab } from "../../component/Market/LimitMarketModule";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivitySurpriseShopPanel")
export default class ActivitySurpriseShopPanel extends FullscreenPanel {

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => {
            return bagLogic.getGood(10146)
        },
        getValue: (good: Good) => {
            return good.getAmount();
        }
    })
    @property(cc.Label)
    rewardLabel: cc.Label = null;

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Label)
    lastTime: cc.Label = null;

    @property(List)
    surpriseList: List = null;

    onLoad() {
        super.onLoad();
        let listener = EManager.addEvent(EName.onUpdateSurpriseShop, () => {
            let data: ActivityModal = activityLogic.getActivityConfigs(ActivityType.SurpriseShop);
            let actConfig = data.actConfig as SurpriseShopActConfig;
            this.surpriseList.numItems = actConfig.shopData.length;
        });
        this._eventListeners.push(listener);
    }

    start() {
        super.start();
        let url = commonUtils.getBgUrl(`raider_bg2`);
        loadUtils.loadSpriteFrame(url, this.bg);
        if (!cc.isValid(this.node)) return;
        let data: ActivityModal = activityLogic.getActivityConfigs(ActivityType.SurpriseShop);
        let actConfig = data.actConfig as SurpriseShopActConfig;
        this.surpriseList.getComponent(cc.Widget).updateAlignment();
        this.surpriseList.numItems = actConfig.shopData.length;
        this.unschedule(this.onShowTime);
        this.onShowTime();
        this.schedule(this.onShowTime, 1);
    }

    onShowTime() {
        let data: ActivityModal = activityLogic.getActivityConfigs(ActivityType.SurpriseShop);
        let time = data.closeAt;
        if (time >= gm.getCurrentTimestamp()) {
            this.lastTime.string = timeUtils.formatDay(data.remainTime, true);
            if (Math.floor((time - gm.getCurrentTimestamp()) / 1000) == 0) {
                this.unschedule(this.onShowTime);
                this.lastTime.string = stringConfigMap.key_activity_finished.Value;
            }
        } else {
            this.lastTime.string = stringConfigMap.key_activity_finished.Value;
        }
    }

    onClickTip(event: cc.Event.EventTouch, index: string) {
        let config = goodsConfig.find(a => a.parameterid == Number(index));
        if (config) {
            tipUtils.showTip(event.target, config.des);
        }
    }

    onActivitySurpriseItemRender(item: cc.Node, index: number) {
        let data: ActivityModal = activityLogic.getActivityConfigs(ActivityType.SurpriseShop);
        let actConfig = data.actConfig as SurpriseShopActConfig;
        let comp = item.getComponent(ActivitySurpriseShopItem);
        comp.refresh(actConfig.shopData[index]);
    }

    onTicket() {
        gcc.core.showLayer("prefabs/panel/market/MarketPanel", { data: { tabIndex: MarketTab.Limit, tabChildIndex: MarketLimitTab.Superise } });
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await loadUtils.loadRes(commonUtils.getBgUrl(`raider_bg2`), cc.SpriteFrame);
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);

        if (this.bg.spriteFrame) {
            loadUtils.releaseAssetRecursively(this.bg.spriteFrame);
        }
    }

}
