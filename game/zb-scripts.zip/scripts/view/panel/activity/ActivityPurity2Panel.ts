import { PopupPanel } from "../BasePanel";
import activityLogic from "../../../logics/ActivityLogic";
import pioneer2config, { pioneer2configRow } from "../../../configs/pioneer2config";
import ActivityPurity2Item from "../../component/Activity/ActivityPurity2Item";
import CommonLoader from "../../common/CommonLoader";
import gm from "../../../manager/GameManager";
import EManager, { EName } from "../../../manager/EventManager";
import commonUtils from "../../../utils/CommonUtils";
import rechargeLogic from "../../../logics/RechargeLogic";
import { stringConfigMap } from "../../../configs/stringConfig";
import stringUtils from "../../../utils/StringUtils";

const { ccclass, property, menu } = cc._decorator;

enum GetStatus {
    None,
    Adv_Get,
    Twice_Get
}

@ccclass
@menu("view/panel/activity/ActivityPurity2Panel")
export default class ActivityPurity2Panel extends PopupPanel {

    @property(cc.Label)
    purity_cnt: cc.Label = null;

    @property(cc.ScrollView)
    scrollView: cc.ScrollView = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    purity_item: cc.Node = null;

    @property(cc.Node)
    ticketProgress: cc.Node = null;

    @property(cc.Node)
    water: cc.Node = null;

    @property(cc.Node)
    btnGetAdv: cc.Node = null;

    @property(cc.Node)
    btnGetDouble: cc.Node = null;

    @property(cc.Node)
    clickLabel: cc.Node = null;

    @property(cc.Node)
    waterNode: cc.Node = null;

    @property(cc.Node)
    destNode: cc.Node = null;

    protected _purityItems: cc.Node[] = [];
    protected _currentConf: pioneer2configRow = null;

    onLoad() {
        super.onLoad();
        let listener = EManager.addEvent(EName.onUpdatePioneer, () => {
            this._refreshCnt();
            this._showInfo();
        });
        this._eventListeners.push(listener);
        listener = EManager.addEvent(EName.onPioneerGetWater, (worldPos: cc.Vec2) => {
            this._flyWater(worldPos);
        });
        this._eventListeners.push(listener);
        listener = EManager.addEvent(EName.onPioneerAdvGet, () => {
            this._refreshCnt();
            this._showInfo();
        });
        this._eventListeners.push(listener);
        listener = EManager.addEvent(EName.onApplyOrder, (data) => {
            if (data && data.storeConfigId == 302) {
                this._onBuyFinish(data);
            }
        });
        this._eventListeners.push(listener);

        this.purity_item.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        EManager.emit(EName.onActivityBtnFresh, "activity");
        this.purity_item.destroy();
    }

    start() {
        super.start();
        this._refreshCnt();
        this._showInfo();
        this._refreshBtns();
    }

    protected _refreshBtns() {
        this.btnGetDouble.active = this.btnGetAdv.active = false;
        let canRecv = activityLogic.pioneer2Info.reaminCount >= activityLogic.pioneer2Info.recvLimit;
        this.btnGetDouble.active = canRecv;
        this.clickLabel.active = canRecv;
        this.btnGetAdv.active = activityLogic.pioneer2ShowAdv();
    }

    protected _flyWater(worldPos: cc.Vec2) {
        let water = cc.instantiate(this.waterNode);
        water.position = this.node.convertToNodeSpaceAR(worldPos);
        water.active = true;
        this.node.addChild(water);
        let destWorldPos = this.destNode.convertToWorldSpaceAR(cc.p(0, 0));
        let action = cc.sequence(
            cc.moveTo(0.3, this.node.convertToNodeSpaceAR(destWorldPos)),
            cc.callFunc(() => {
                water.destroy();
            })
        );
        water.runAction(action);
    }

    protected async _onPioneerAdvGet() {
        for (let item of this._purityItems) {
            let index = item.getComponent(ActivityPurity2Item).index;
            if (this._unRecvList.indexOf(index) != -1) {
                item.getComponent(ActivityPurity2Item).doGetWaterAnim();
                this.scrollView.scrollToOffset(cc.p(150 * index, 0), 0.2);
                // let pioneerCfg = pioneer2config.find(a => a.ID == index);
                // this._addCnt(pioneerCfg.reward);
                await commonUtils.sleep(1, this);
            }
        }
        this._unRecvList = [];
    }

    protected _nowCnt = 0;
    protected _refreshCnt() {
        this._nowCnt = activityLogic.pioneer2Info.reaminCount * 10;
        this.purity_cnt.string = `${activityLogic.pioneer2Info.reaminCount * 10}/${activityLogic.pioneer2Info.recvLimit * 10}`;
        let percent = activityLogic.pioneer2Info.reaminCount / activityLogic.pioneer2Info.recvLimit;
        this._showPercent(percent);
    }

    protected _addCnt(cnt: number) {
        this._nowCnt += cnt;
        this.purity_cnt.string = `${this._nowCnt}/${activityLogic.pioneer2Info.recvLimit * 10}`;
        let percent = this._nowCnt / activityLogic.pioneer2Info.recvLimit;
        this._showPercent(percent);
    }

    protected _showPercent(percent) {
        percent = Math.min(1, percent);
        this.ticketProgress.height = 302 * percent;
        this.water.y = -150 + 382 * percent;
    }

    protected _showInfo() {
        this.content.destroyAllChildren();
        this._purityItems = [];
        let firstCanRecvIndex = -1;
        this._currentConf = pioneer2config[pioneer2config.length - 1];
        for (let info of pioneer2config) {
            if (!activityLogic.pioneer2Info.enterDetail[info.ID]) {
                this._currentConf = info;
                break;
            }
        }
        let index: number = 0;
        for (let info of pioneer2config) {
            if (info.circle == this._currentConf.circle) {
                if (!activityLogic.pioneer2Info.enterDetail[info.ID] && firstCanRecvIndex == -1) {
                    firstCanRecvIndex = index;
                }
                let node = cc.instantiate(this.purity_item);
                node.y = -100;
                node.active = true;
                this.content.addChild(node);
                node.getComponent(CommonLoader).loaderNode.getComponent(ActivityPurity2Item).refresh(info.ID);
                index++;
                this._purityItems.push(node.getComponent(CommonLoader).loaderNode);
            }
        }
        if (firstCanRecvIndex != -1) {
            this.scheduleOnce(() => {
                this.scrollView.scrollToOffset(cc.p(150 * firstCanRecvIndex, 0), 0.2);
            }, 0);
        }
        this._refreshBtns();
    }

    protected _getStatus(circle: number): GetStatus {
        let cfgs = pioneer2config.where(a => a.circle == circle);
        let lastCfg = cfgs[cfgs.length - 1];
        if (activityLogic.pioneer2Info.stageId >= lastCfg.stagenode && activityLogic.pioneer2Info.reaminCount < activityLogic.pioneer2Info.recvLimit) {
            return GetStatus.None;
        }
        return activityLogic.pioneer2Info.reaminCount >= activityLogic.pioneer2Info.recvLimit ? GetStatus.Twice_Get : GetStatus.Adv_Get;
    }

    async onRecvPioneer() {
        if (activityLogic.pioneer2Info.reaminCount < activityLogic.pioneer2Info.recvLimit) {
            let lastCount = activityLogic.pioneer2Info.recvLimit * 10 - activityLogic.pioneer2Info.reaminCount * 10;
            gm.toast(stringUtils.getString(stringConfigMap.key_auto_636.Value, { p1: lastCount }));
            return;
        }
        gcc.core.showLayer("prefabs/panel/activity/ActivityPurityBuyPanel", { modalTouch: true });
    }

    onAdvGet() {
        this._getUnRecvItems();
        gcc.core.showLayer("prefabs/panel/activity/ActivityPurityBuyPanel", { modalTouch: true, data: activityLogic.pioneer2Info.reaminCount < activityLogic.pioneer2Info.recvLimit });
    }

    protected _unRecvList = [];
    protected _getUnRecvItems() {
        this._unRecvList = [];
        let currentConf = pioneer2config[pioneer2config.length - 1];
        for (let info of pioneer2config) {
            if (!activityLogic.pioneer2Info.enterDetail[info.ID]) {
                currentConf = info;
                break;
            }
        }
        let cfg = pioneer2config.where(a => a.circle == currentConf.circle);
        for (let _cfg of cfg) {
            if (!activityLogic.pioneer2Info.enterDetail[_cfg.ID]) {
                this._unRecvList.push(_cfg.ID);
            }
        }
    }

    protected async _onBuyFinish(data) {
        let resourceVO = data.resourceVO;
        try {
            gm.getReward(resourceVO);
            rechargeLogic.pioneerReward = false;
            await activityLogic.doGetPioneer2Info();
            EManager.emit(EName.onPioneerAdvGet);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await activityLogic.doGetPioneer2Info();
    }
}
