import { PopupPanel } from "../BasePanel";
import gm from "../../../manager/GameManager";
import GameProxy, { ShopVO } from "../../../proxy/GameProxy";
import shopLogic from "../../../logics/ShopLogic";
import Shop from "../../../data/card/Shop";
import StoreLayout from "../../component/Store/StoreLayout";
import cm from "../../../manager/ConfigManager";
import { StoreId } from "../../../utils/DefineUtils";
import timeUtils from "../../../utils/TimeUtils";
import activityLogic, { ActivityType } from "../../../logics/ActivityLogic";
import stringUtils from "../../../utils/StringUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/MonthOrderShopPanel")
export default class MonthOrderShopPanel extends PopupPanel {

    @property(cc.Node)
    shopView: cc.Node = null;

    @property(cc.Prefab)
    shopLayout: cc.Prefab = null;

    @property(cc.Label)
    actTs: cc.Label = null;

    onInit(data: any) {
    }

    onLoad() {
        super.onLoad();
    }

    onDestroy() {
        super.onDestroy();
    }

    start() {
        super.start();

        this.showStore('MonthKsShop_Act');

        let endTs: number = this.moModal().closeAt;
        let leftSec: number = (endTs - gm.getCurrentTimestamp()) / 1000;
        let str = `活动已结束`;
        if (leftSec > 0) {
            str = stringUtils.getString(stringConfigMap.key_activity_remain_time.Value, {
                time: timeUtils.formatDay(leftSec * 1000, true)
            });
        }
        this.actTs.getComponent(cc.Label).string = str;
    }

    update(dt: number) {
        super.update(dt);
    }

    async showStore(shopType: string) {
        this.shopView.destroyAllChildren();
        let reqType: string = shopType;
        let shopProto = await gm.request<ShopVO>(GameProxy.apiShopgetShopDetail, reqType);
        shopLogic.init(shopProto, gm);

        let goods = shopLogic.getShopGoods();
        let list: Shop[] = [];
        let scale: number = 0.9;
        for (let good of goods) {
            if (list.length == 4) {
                let node = cc.instantiate(this.shopLayout);
                node.getComponent(StoreLayout).refresh(list);
                node.scale = scale;
                node.height = 175;
                this.shopView.addChild(node);

                list = [];
            }
            list.push(good);
        }
        if (list.length > 0) {
            let node = cc.instantiate(this.shopLayout);
            node.getComponent(StoreLayout).refresh(list);
            node.scale = scale;
            node.height = 175;
            this.shopView.addChild(node);
        }

        let row = Math.ceil(goods.length / 4);
        let maxFloor = 3;
        let height: number = this.shopLayout.data.height * scale;
        this.shopView.height = Math.max(row * height, maxFloor * height);
    }

    protected moModal() {
        return activityLogic.getActivityConfigs(ActivityType.MonthOrder);
    }
}
