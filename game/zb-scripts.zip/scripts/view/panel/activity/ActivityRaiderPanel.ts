import { FullscreenPanel } from "../BasePanel";
import activityLogic, { ActivityModal, ActivityType } from "../../../logics/ActivityLogic";
import Monster from "../../../data/card/Monster";
import loadUtils from "../../../utils/LoadUtils";
import gm from "../../../manager/GameManager";
import Skill from "../../../data/card/Skill";
import CommonLoader from "../../common/CommonLoader";
import UnionSkill from "../../component/Skill/UnionSkill";
import EManager, { EName } from "../../../manager/EventManager";
import { GoodVO } from "../../../proxy/GameProxy";
import Good from "../../../data/card/Good";
import GoodCard from "../../component/Good/GoodCard";
import commonUtils from "../../../utils/CommonUtils";
import TreasureActConfig from "../../../data/activity/actconfig/TreasureActConfig";
import TreasureRoleActivityDatas from "../../../data/activity/roleactivitydatas/TreasureRoleActivityDatas";
import bagLogic from "../../../logics/BagLogic";
import timeUtils from "../../../utils/TimeUtils";
import { RefreshLabel } from "../../../decorator/RefreshDecorator";
import TreasureBattle from "../../../data/activity/TreasureBattle";
import goodsConfig from "../../../configs/goodsConfig";
import tipUtils from "../../../utils/TipUtils";
import { defaultConfigMap } from "../../../configs/defaultConfig";
import { MarketTab } from "../market/MarketPanel";
import { MarketLimitTab } from "../../component/Market/LimitMarketModule";
import { stringConfigMap } from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityRaiderPanel")
export default class ActivityRaiderPanel extends FullscreenPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => {
            return bagLogic.getGood(10146)
        },
        getValue: (good: Good) => {
            return good.getAmount();
        }
    })
    @property(cc.Label)
    ticketLabel: cc.Label = null;

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => {
            return bagLogic.getGood(10147)
        },
        getValue: (good: Good) => {
            return good.getAmount();
        }
    })
    @property(cc.Label)
    rewardLabel: cc.Label = null;

    @property(cc.Label)
    monsterName: cc.Label = null;

    @property(cc.Label)
    timeLabel: cc.Label = null;

    @property(cc.Label)
    lastCnt: cc.Label = null;

    @property(cc.Label)
    xiaohao: cc.Label = null;

    @property(cc.Button)
    challengeBtn: cc.Button = null;

    @property(sp.Skeleton)
    heroHead: sp.Skeleton = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    goodPrefab: cc.Node = null;

    @property(cc.Node)
    equipPrefab: cc.Node = null;

    protected _lastSkeletonData: sp.SkeletonData = null;
    protected _monster: Monster = null;

    onLoad() {
        super.onLoad();

        let listener = EManager.addEvent(EName.onTouch, () => {
            EManager.emit(EName.onClosePanel, "SkillGetDetailPanel");
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onReChallenge, () => {
            this.onChallange();
        });
        this._eventListeners.push(listener);

        this.goodPrefab.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.goodPrefab.destroy();
    }

    start() {
        super.start();

        let url = commonUtils.getBgUrl(`raider_bg`);
        loadUtils.loadSpriteFrame(url, this.bg);
        this.showMonster();
    }

    onEnable() {
        super.onEnable();

        this.showMonster();
    }

    async showMonster() {
        let data: ActivityModal = activityLogic.getActivityConfigs(ActivityType.Treasure);
        let actConfig = data.actConfig as TreasureActConfig;
        let roleActivityDatas = data.roleActivityDatas as TreasureRoleActivityDatas;

        this.lastCnt.node.active = false;
        this.xiaohao.node.active = false;
        this.challengeBtn.interactable = true;
        if (actConfig.freeCount > roleActivityDatas.count) {
            this.lastCnt.node.active = true;
            this.lastCnt.string = `今日剩余次数: ${actConfig.freeCount - roleActivityDatas.count}/${actConfig.freeCount}`;
        } else {
            this.xiaohao.node.active = true;
        }
        this.unschedule(this.onShowTime);
        this.onShowTime();
        let time = data.closeAt - gm.getCurrentTimestamp();
        let day = time / 1000 / 3600;
        if (day > 24) {
            this.timeLabel.string = timeUtils.formatDay(time, true)
        } else {
            this.schedule(this.onShowTime, 1);
        }
        this._monster = new Monster(actConfig.monsterId);
        this.monsterName.string = this._monster.getName();
        if (this._lastSkeletonData) {
            loadUtils.releaseAssetRecursively(this._lastSkeletonData);
            this._lastSkeletonData = null;
        }
        await gm.createHeroSpine(this._monster, this.heroHead);
        // this.heroHead.node.scale = this._monster.getMonsterScale();
        this._lastSkeletonData = this.heroHead.skeletonData;

        this.content.destroyAllChildren();
        let goodCard = cc.instantiate(this.goodPrefab);
        goodCard.active = true;
        this.content.addChild(goodCard);
        let goodVo = new GoodVO();
        goodVo.propId = actConfig.rewardId;
        goodVo.amt = 0;
        let prop = new Good(goodVo);
        goodCard.getComponent(CommonLoader).loaderNode.getComponent(GoodCard).refresh(prop);
        goodCard.on(cc.Node.EventType.TOUCH_END, () => {
            gcc.core.showLayer("prefabs/panel/bag/BagInfoPanel", { data: { good: prop, noUse: true }, modalTouch: true });
        }, this);

        for (let i = 0; i < 3; i++) {
            let skillNode = cc.find(`skillNode/skill${i + 1}`, this.node);
            skillNode.active = false;
        }
        let skills: Skill[] = this._monster.getSkills();
        for (let i = 0; i < skills.length; i++) {
            if (!skills[i].isShow()) continue;

            if (i < 3) {
                let skillNode = cc.find(`skillNode/skill${i + 1}`, this.node);
                skillNode.active = true;
                let loader = skillNode.getComponent(CommonLoader);
                loader.loaderNode.getComponent(UnionSkill).refresh({ skill: skills[i], hero: this._monster });
            }
        }
    }

    onShowTime() {
        let data: ActivityModal = activityLogic.getActivityConfigs(ActivityType.Treasure);
        let time = data.closeAt;
        if (time >= gm.getCurrentTimestamp()) {
            this.timeLabel.string = timeUtils.formatTime((time - gm.getCurrentTimestamp()) / 1000);
            if (Math.floor((time - gm.getCurrentTimestamp()) / 1000) == 0) {
                this.unschedule(this.onShowTime);
                this.timeLabel.string = "活动已结束";
            }
        } else {
            this.timeLabel.string = "活动已结束";
        }
    }

    onChallange() {
        let data: ActivityModal = activityLogic.getActivityConfigs(ActivityType.Treasure);
        if (!data.isValid) {
            gm.toast(stringConfigMap.key_activity_finished.Value);
            return;
        }
        let actConfig = data.actConfig as TreasureActConfig;
        let roleActivityDatas = data.roleActivityDatas as TreasureRoleActivityDatas;
        if (actConfig.freeCount <= roleActivityDatas.count) {
            let ticket = bagLogic.getGood(actConfig.ticketId).getAmount();
            if (ticket < 1) {
                gm.toast(stringConfigMap.key_auto_562.Value);
                return;
            }
        }
        actConfig.treasureRewardCnt = 0;
        actConfig.treasureTotalHurt = 0;
        let treasureBattle = new TreasureBattle(actConfig.monsterId);
        gcc.core.showLayer("prefabs/panel/battle/BattlePreparePanel", { data: treasureBattle });
    }

    async onBuyChallenge() {
        let data: ActivityModal = activityLogic.getActivityConfigs(ActivityType.Treasure);
        let actConfig = data.actConfig as TreasureActConfig;
        let roleActivityDatas = data.roleActivityDatas as TreasureRoleActivityDatas;
        let lastLimitCount: number = actConfig.limitCount - roleActivityDatas.ticketBuyCount;
        if (lastLimitCount <= 0) {
            gm.toast(stringConfigMap.key_auto_563.Value);
            return;
        }
        gcc.core.showLayer("prefabs/panel/activity/ActivityTicketBuyPanel", {
            data: {
                goodId: actConfig.ticketId,
                limitCount: lastLimitCount,
                price: defaultConfigMap.challengeticket.value,
                buyFunc: async (cnt: number) => {
                    await activityLogic.doBuyTreaRaider(cnt);
                }
            }
        });
    }

    onClickTip(event: cc.Event.EventTouch, index: string) {
        let config = goodsConfig.find(a => a.parameterid == Number(index));
        if (config) {
            tipUtils.showTip(event.target, config.des);
        }
    }

    onHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "treasure" } });
    }

    onShop() {
        if (activityLogic.isActivityValid(ActivityType.SurpriseShop)) {
            gcc.core.showLayer("prefabs/panel/activity/ActivitySurpriseShopPanel");
        } else {
            gm.toast('奇兵商店活动尚未开启');
        }

    }

    onTicket() {
        gcc.core.showLayer("prefabs/panel/market/MarketPanel", { data: { tabIndex: MarketTab.Limit, tabChildIndex: MarketLimitTab.Superise } });
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await loadUtils.loadRes(commonUtils.getBgUrl(`raider_bg`), cc.SpriteFrame);
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);

        if (this.bg.spriteFrame) {
            loadUtils.releaseAssetRecursively(this.bg.spriteFrame);
        }
        if (this._lastSkeletonData) {
            loadUtils.releaseAssetRecursively(this._lastSkeletonData);
            this._lastSkeletonData = null;
        }
    }

}
