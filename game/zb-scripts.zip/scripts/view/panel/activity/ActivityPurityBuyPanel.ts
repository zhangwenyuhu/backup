import { PopupPanel } from "../BasePanel";
import activityLogic from "../../../logics/ActivityLogic";
import EManager, { EName } from "../../../manager/EventManager";
import rechargeLogic from "../../../logics/RechargeLogic";
import gm from "../../../manager/GameManager";
import cm from "../../../manager/ConfigManager";
import commitLogic from "../../../logics/CommitLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityPurityBuyPanel")
export default class ActivityPurityBuyPanel extends PopupPanel {

    @property(cc.Node)
    text1: cc.Node = null;

    @property(cc.Node)
    text2: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    content2: cc.Node = null;

    @property(cc.Label)
    btnText: cc.Label = null;

    // 提前领取
    protected _advGet: boolean = false;

    onInit(data: boolean) {
        this._advGet = data;
        super.onInit(data);
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;

        let listener = EManager.addEvent(EName.onApplyOrder, (data) => {
            if (data && data.storeConfigId == 302) {
                this._touchProtected = false;
                this.unscheduleAllCallbacks();
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);
    }

    onDestroy() {
        super.onDestroy();
        rechargeLogic.pioneerReward = false;
        EManager.emit(EName.onActivityBtnFresh, "activity");
        this.goodItem.destroy();
    }

    start() {
        super.start();
        this.text1.active = !this._advGet;
        this.text2.active = this._advGet;
        this.btnText.string = this._advGet ? "放弃优惠" : "领十连";
        let cfg = cm.getStoreConfig(302);
        let giftCfg = cm.getGiftConfig(cm.getGoodConfig(cfg.item).effect);
        let reward_data: number[][] = giftCfg.Item;
        if (reward_data) {
            this.content.destroyAllChildren();
            let data: number[] = [];
            data[0] = reward_data[1][0];
            data[1] = reward_data[1][1] / 2;
            gm.showGoodItem(data, {
                goodItem: this.goodItem,
                equipItem: null,
                heroItem: null
            }, this.content);
            gm.showGoodItem(reward_data[0], {
                goodItem: this.goodItem,
                equipItem: null,
                heroItem: null,
            }, this.content2);
            gm.showGoodItem(data, {
                goodItem: this.goodItem,
                equipItem: null,
                heroItem: null
            }, this.content2);

            commitLogic.payPanelShow('', 302);
        }
    }

    async onGet() {
        if (this._advGet) {
            this.closePanel();
        } else {
            gm.dialog({
                content: "确认放弃双倍奖励，只领取10连么？", confirm: () => {
                    this._confirmGet();
                }
            });
        }
    }

    protected async _confirmGet() {
        await activityLogic.doRecvPioneer2();
        EManager.emit(EName.onUpdatePioneer);
        this.closePanel();
    }

    protected _touchProtected: boolean = false;
    async onBuy() {
        if (this._touchProtected) {
            return;
        }
        rechargeLogic.pioneerReward = true;
        this._touchProtected = true;
        await rechargeLogic.iap(302);
        this.scheduleOnce(() => {
            this._touchProtected = false;
        }, 10);
    }
}
