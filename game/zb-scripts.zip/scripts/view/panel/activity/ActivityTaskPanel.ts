import { FullscreenPanel } from "../BasePanel";
import activityLogic, { ActivityModal, ActivityType } from "../../../logics/ActivityLogic";
import TaskActConfig, { TaskCfg } from "../../../data/activity/actconfig/TaskActConfig";
import List from "../../common/List";
import ActivityTask5Item from "../../component/Activity/ActivityTask5Item";
import playerLogic from "../../../logics/PlayerLogic";
import gm from "../../../manager/GameManager";
import timeUtils from "../../../utils/TimeUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import EManager, { EName } from "../../../manager/EventManager";
import loadUtils from "../../../utils/LoadUtils";
import Activetypeconfig from "../../../configs/Activetypeconfig";
import commonUtils from "../../../utils/CommonUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/activity/ActivityTaskPanel")
export default class ActivityTaskPanel extends FullscreenPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Sprite)
    title: cc.Sprite = null;

    @property(cc.Label)
    lastTime: cc.Label = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    rewardNode: cc.Node = null;

    @property(cc.Node)
    bigReward: cc.Node = null;

    @property(List)
    taskList: List = null;

    @property(cc.Node)
    btnHelp: cc.Node = null;

    @property(cc.Node)
    bgEffect: cc.Node = null;

    @property(cc.Node)
    cardEffect: cc.Node = null;

    @property(cc.Node)
    light: cc.Node = null;

    @property(cc.Node)
    light2: cc.Node = null;

    @property(cc.Node)
    iconRecv: cc.Node = null;

    @property(cc.Node)
    iconCanRecv: cc.Node = null;

    @property(cc.Node)
    actMonthTag: cc.Node = null;

    protected _actConfig: TaskActConfig = null;
    protected _roleActivityDatas = null;
    protected _taskCfg: TaskCfg[] = [];
    protected _bgFrame: cc.SpriteFrame[] = [];

    onInit(data: ActivityType) {
        super.onInit(data);
    }

    public reloadPanel(data: ActivityType) {
        this.data = data;
        this.start();
    }
    protected addSpriteFrame(frame: cc.SpriteFrame) {
        if (!frame) { return; }
        let index: number = this._bgFrame.findIndex((v, i, a) => { return v == frame; })
        if (index >= 0) { return; }

        this._bgFrame.push(frame);
    }
    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);
        for (let i = 0; i < this._bgFrame.length; i++) {
            loadUtils.releaseAssetRecursively(this._bgFrame[i]);
        }
    }
    protected loadBgImg() {
        let url: string = commonUtils.getBgUrl(`activity_bg_task${this._getBgId()}`);
        loadUtils.loadSpriteFrame(url, this.bg, (data, err) => {
            this.addSpriteFrame(data);
        });
    }

    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
        this.cardEffect.parent = null;
        let listener = EManager.addEvent(EName.onUpdateTaskActivity, () => {
            this.taskList.numItems = this._taskCfg.length;
        });
        this._eventListeners.push(listener);
    }

    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
        this.equipItem.destroy();
    }

    start() {
        super.start();
        //this.loadBg(this.bg);
        this.loadBgImg();
        loadUtils.loadSpriteFrame(`textures/ui/panel/activity_task/text${this._getBgId()}`, this.title);
        this.btnHelp.active = this.data == ActivityType.Lottery || this.data == ActivityType.UnionLottery;
        this._refreshBigReward();

        this.unschedule(this.onShowTime);
        this.onShowTime();
        this.schedule(this.onShowTime, 1);

        let tag: boolean = this.data == ActivityType.HeroCultivate || this.data == ActivityType.WisdomStorm;
        this.actMonthTag.active = tag;
    }

    protected _refreshBigReward() {
        this.bgEffect.active = false;
        this.iconRecv.active = false;
        this.iconCanRecv.active = false;
        this.light.active = false;
        this.light2.active = false;
        let data: ActivityModal = activityLogic.getActivityConfigs(this.data as ActivityType);
        if (data) {
            this._actConfig = data.actConfig as TaskActConfig;
            this._roleActivityDatas = data.roleActivityDatas;
            this._taskCfg = this._actConfig.getTaskCfg();
            let activityData = activityLogic.getActivityData(this.data, "-1");
            let claimed = activityData && activityData.claimed;
            this.rewardNode.destroyAllChildren();
            if (this._actConfig.getRewards()) {
                let cards = playerLogic.getCardsByReward(this._actConfig.getRewards());
                gm.createRewards(cards, {
                    goodItem: this.goodItem,
                    equipItem: this.equipItem,
                    heroItem: this.heroItem
                }, this.rewardNode, 2, true);
                if (claimed) {
                    this.rewardNode.opacity = 200;
                }
                this.iconRecv.active = claimed;
            }
            this.scheduleOnce(() => {
                this.taskList.numItems = this._taskCfg.length;
            });
            let claimable = activityData && activityData.claimable;
            this.bigReward.active = claimable;
            if (claimable) {
                this.iconCanRecv.active = true;
                this.light.active = true;
                this.light2.active = true;
                this.bgEffect.active = this.bigReward.active = true;
                for (let child of this.rewardNode.children) {
                    let effect = cc.instantiate(this.cardEffect);
                    effect.x = effect.y = 0;
                    effect.parent = child;
                }
            }
        }
    }

    onActivityTaskItemRender(item: cc.Node, index: number) {
        let comp = item.getComponent(ActivityTask5Item);
        comp.refresh({ taskCfg: this._taskCfg[index], activityType: this.data });
    }

    onShowTime() {
        let data: ActivityModal = activityLogic.getActivityConfigs(this.data);
        let time = data.closeAt;
        if (time >= gm.getCurrentTimestamp()) {
            this.lastTime.string = "剩余时间 " + timeUtils.formatDay(data.remainTime, true);
            if (Math.floor((time - gm.getCurrentTimestamp()) / 1000) == 0) {
                this.unschedule(this.onShowTime);
                this.lastTime.string = stringConfigMap.key_activity_finished.Value;
            }
        } else {
            this.lastTime.string = stringConfigMap.key_activity_finished.Value;
        }
    }

    async onBigReward() {
        try {
            await activityLogic.doRecvTaskActReward(this.data, "-1");
            this._refreshBigReward();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    onHelp() {
        let type = "";
        if (this.data == ActivityType.Lottery) {
            type = "lottery";
        } else if (this.data == ActivityType.UnionLottery) {
            type = "unionlottery";
        }
        if (type != "") {
            gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: type } });
        }
    }

    protected _getBgId() {
        let id = 1;
        if (this.data == ActivityType.UnionLottery) {
            id = 8;
        } else {
            id = this.data - 12;
        }
        return id;
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await this._preloadBg(`activity_bg_task${this._getBgId()}`);

        //this._unloadInfos.push({ url: commonUtils.getBgUrl(`activity_task`), type: cc.SpriteFrame });
    }

}
