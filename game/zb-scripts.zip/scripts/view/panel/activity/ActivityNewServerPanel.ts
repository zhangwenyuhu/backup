import { FullscreenPanel } from "../BasePanel";
import { RefreshLabel } from "../../../decorator/RefreshDecorator";
import Good from "../../../data/card/Good";
import bagLogic from "../../../logics/BagLogic";
import List from "../../common/List";
import ActivityNewServerItem from "../../component/Activity/ActivityNewServerItem";
import stringUtils from "../../../utils/StringUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import timeUtils from "../../../utils/TimeUtils";
import activityLogic from "../../../logics/ActivityLogic";
import gm from "../../../manager/GameManager";
import GameProxy, { RankListReq, RankListVO } from "../../../proxy/GameProxy";
import RankData from "../../../data/record/RankData";
import commonUtils from "../../../utils/CommonUtils";
import friendLogic from "../../../logics/FriendLogic";
import CommonLoader from "../../common/CommonLoader";
import PlayerAvatar from "../../component/Player/PlayerAvatar";
import battlescoreconfig from "../../../configs/battlescoreconfig";

const { ccclass, property, menu } = cc._decorator;

/**
 * 新服活动面板
 */
@ccclass
@menu("view/panel/activity/ActivityNewServerPanel")
export default class ActivityNewServerPanel extends FullscreenPanel {
    @property(cc.Label)
    labelPower: cc.Label = null;

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => {
            return bagLogic.getGood(Good.GoodId.Diamond)
        },
        getValue: (good: Good) => {
            return stringUtils.formatAmount(good.getAmount());
        }
    })
    @property(cc.Label)
    labelDiamond: cc.Label = null;

    @property(cc.Label)
    labelRemainTime: cc.Label = null;

    @property(List)
    rankList: List = null;

    @property(cc.ScrollView)
    scrollView: cc.ScrollView = null;

    @property(ActivityNewServerItem)
    myRank: ActivityNewServerItem = null;

    @property(cc.Node)
    top3: cc.Node = null;

    @property(cc.Label)
    leftSupportTimes: cc.Label = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    protected _myRankData: RankData = null;
    protected _rankDatas: RankData[] = [];
    protected _isRequesting: boolean = false;

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;

        let list = this.rankList.node.parent;
        list.getComponent(cc.Widget).top += (cc.winSize.height - 1334) / 2;
        list.getComponent(cc.Widget).updateAlignment();

        let widget = this.rankList.getComponent(cc.Widget);
        widget.updateAlignment();
    }

    async start() {
        super.start();

        this.labelRemainTime.string = stringUtils.getString(stringConfigMap.key_activity_remain_time.Value,
            { time: timeUtils.formatDay(activityLogic.newServerRemainTime, true) });
        this.myRank.node.active = false;
        this.labelPower.string = "";

        await this._reqRankList();
        this.freshTop3();
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    onEnable() {
        super.onEnable();
        this.schedule(this._updateRemainTime, 10);
    }

    onDisable() {
        this.unschedule(this._updateRemainTime);
        super.onDisable();
    }

    onRankItemRender(item: cc.Node, index: number) {
        let rankData = this._rankDatas[index];
        let comp = item.getComponent(ActivityNewServerItem);
        comp.refresh(rankData, false, { good: this.goodItem, hero: this.heroItem, equip: this.equipItem });
    }

    onScrollEvents(target: cc.ScrollView, eventType: cc.ScrollView.EventType) {
        if (eventType == cc.ScrollView.EventType.SCROLL_TO_BOTTOM) {
            this._reqRankList();
        }
    }

    onRewardPreview() {
        gcc.core.showLayer("prefabs/panel/activity/NewServerBonusPanel", { data: battlescoreconfig })
    }

    async onSupport(sender: cc.Event.EventTouch, customData: string) {
        if (this._myRankData.getLeftSupportCount() <= 0) {
            gm.toast('今日点赞次数已用尽');
            return;
        }
        try {
            let data = await activityLogic.supportPlayer(customData);
            console.log('support extra: ' + data);
            if (data && data[0]) {
                let num: number = parseInt(data[0] as any);
                for (let i = 0; i < 3; i++) {
                    let data = this._rankDatas[i];
                    if (data && data.getRole().getRoleId() == customData) {
                        data.getRole().setLikeCount(num);
                    }
                }
            }
            this._myRankData.setCanSupportCountAdd();

            this.freshTop3();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    protected freshTop3() {
        for (let i = 0; i < 3; i++) {
            let rank: number = i + 1;
            let node = this.top3.getChildByName(`rank${rank}`);
            let rankData = this._rankDatas[i];
            if (!rankData) { continue; }
            let player = rankData.getRole();
            if (!player) { continue; }

            node.active = this._rankDatas[i] ? true : false;
            if (node.active) {
                let avatarLoader = node.getChildByName('avatar').getComponent(CommonLoader);
                let comp = avatarLoader.loaderNode.getComponent(PlayerAvatar);
                comp.refresh(player.getAvatar());

                let name = node.getChildByName('name').getComponent(cc.Label);
                name.string = player.getNickname();

                let btn = node.getComponent(cc.Button);
                btn.clickEvents[0].customEventData = player.getRoleId();
            }
            let supportBtn = this.top3.getChildByName(`support${rank}`).getComponent(cc.Button);
            supportBtn.clickEvents[0].customEventData = player.getRoleId();
            let support = this.top3.getChildByName(`num${rank}`);
            support.getComponent(cc.Label).string = `${player.getLikeCount()}`;
        }

        this.leftSupportTimes.string = `${this._myRankData.getLeftSupportCount()}`;
    }

    async onTop3User(sender: cc.Event.EventTouch, customData: string) {
        if (customData) {
            await friendLogic.playerShow(customData, true);
            let userInfo = friendLogic.getPlayerInfo(customData);
            gcc.core.showLayer("prefabs/panel/player/UserPanel", { data: { user: userInfo } });
        }
    }

    protected async _reqRankList() {
        if (this._isRequesting) return;
        this._isRequesting = true;

        let req = new RankListReq();
        req.rankType = 9;
        req.start = this._rankDatas.length;
        req.end = this._rankDatas.length + 9;
        let proto = await gm.request<RankListVO>(GameProxy.apirankmyGameRank, req);
        this._myRankData = new RankData(proto.myRank);
        for (let vo of proto.rankDetail) {
            this._rankDatas.push(new RankData(vo));
        }
        this.myRank.node.active = true;
        this.myRank.refresh(this._myRankData, true, { good: this.goodItem, hero: this.heroItem, equip: this.equipItem });
        this.rankList.numItems = this._rankDatas.length;

        let power = this._myRankData.getRole().getPower()
        this.labelPower.string = stringUtils.formatPower(power);

        if (proto.rankDetail.length == 0 || this.rankList.numItems >= 500) {
            this.scrollView.scrollEvents = [];
        }

        this._isRequesting = false;
    }

    protected _updateRemainTime(dt: number) {
        this.labelRemainTime.string = stringUtils.getString(stringConfigMap.key_activity_remain_time.Value,
            { time: timeUtils.formatDay(activityLogic.newServerRemainTime, true) });
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("activity_bg_newserver"), type: cc.SpriteFrame });
    }
}