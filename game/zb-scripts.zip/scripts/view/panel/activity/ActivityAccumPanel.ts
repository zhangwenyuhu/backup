import { EName } from './../../../manager/EventManager';
import { ActivityModal } from './../../../logics/ActivityLogic';
import { stringConfigMap } from './../../../configs/stringConfig';
import { FullscreenPanel } from "../BasePanel";
import loadUtils from "../../../utils/LoadUtils";
import stringUtils from "../../../utils/StringUtils";
import timeUtils from '../../../utils/TimeUtils';
import List from '../../common/List';
import activityLogic, { ActivityType } from '../../../logics/ActivityLogic';
import EManager from '../../../manager/EventManager';
import { RefreshLabel } from '../../../decorator/RefreshDecorator';
import Good from '../../../data/card/Good';
import bagLogic from '../../../logics/BagLogic';
import ActivityAccumItem from '../../component/Activity/ActivityAccumItem';

const { ccclass, property, menu } = cc._decorator;

/**
 * 累充累消面板
 */
@ccclass
@menu("view/panel/activity/ActivityAccumPanel")
export default class ActivityAccumPanel extends FullscreenPanel {
    @property(cc.Sprite)
    spriteBg: cc.Sprite = null;

    @property(cc.Sprite)
    actTitle: cc.Sprite = null;

    @property(cc.Label)
    labelTimestamp: cc.Label = null;

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: () => { return bagLogic.getGood(Good.GoodId.Diamond) },
        getValue: (good: Good) => {
            return stringUtils.formatAmount(good.getAmount());
        }
    })
    @property(cc.Label)
    labelDiamond: cc.Label = null;

    @property(List)
    listView: List = null;

    protected _type: ActivityType = ActivityType.None;
    protected _modal: ActivityModal = null;
    protected _bgFrame: cc.SpriteFrame[] = [];

    get activityType(): ActivityType {
        return this._type;
    }

    onInit(type: ActivityType) {
        super.onInit(type);
        this._type = type;
    }

    public async reloadPanel(data: ActivityType) {
        this.data = data;
        this._type = data;

        await activityLogic.activityReq(this._type);
        this._modal = activityLogic.getActivityConfigs(this._type);

        this.start();
    }
    protected addSpriteFrame(frame: cc.SpriteFrame) {
        if (!frame) { return; }
        let index: number = this._bgFrame.findIndex((v, i, a) => { return v == frame; })
        if (index >= 0) { return; }

        this._bgFrame.push(frame);
    }
    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);
        for (let i = 0; i < this._bgFrame.length; i++) {
            loadUtils.releaseAssetRecursively(this._bgFrame[i]);
        }
    }
    protected loadBgImg() {
        let url: string = `textures/bg/activity_bg_${this._type}`;
        loadUtils.loadSpriteFrame(url, this.spriteBg, (data, err) => {
            this.addSpriteFrame(data);
        });
    }

    onLoad() {
        super.onLoad();
        this.registerEvents();
    }

    start() {
        super.start();

        this.loadBgImg();
        this.listView.getComponent(cc.Widget).updateAlignment();
        this._updateLabelTimestamp();
        this._updateListView();

        let url: string = this._type == ActivityType.LeiChong ? 'text_leichong' : 'text_leixiao';
        url = 'textures/ui/panel/activity_common/' + url;
        loadUtils.loadSpriteFrame(url, this.actTitle);
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onApplyOrder, async () => {
            if (this._type == ActivityType.LeiChong) {
                try {
                    await activityLogic.activityReq(this._type);
                    this._modal = activityLogic.getActivityConfigs(this._type);
                    this._updateLabelTimestamp();
                    this._updateListView();
                } catch (e) {
                    console.error(e);
                }
            }
        });
        this._eventListeners.push(listener);
    }

    onAccumItemRender(item: cc.Node, index: number) {
        if (this._modal) {
            let comp = item.getComponent(ActivityAccumItem);
            comp.refresh(this._modal.configs[index], this._modal.id, this._modal.type, this._modal.isValid);
        }
    }

    protected _updateLabelTimestamp() {
        if (this._modal && this._modal.isValid) {
            this.labelTimestamp.string = stringUtils.getString(stringConfigMap.key_activity_remain_time.Value,
                { time: timeUtils.formatDay(this._modal.remainTime, true) });
        }
        else {
            this.labelTimestamp.string = stringConfigMap.key_activity_finished.Value;
        }
    }

    protected async _updateListView() {
        if (this._modal) {
            this.listView.numItems = this._modal.configs.length;

            let listId = 0;
            let configs = this._modal.configs;
            for (let i = 0; i < configs.length; i++) {
                let config = configs[i];
                let tag = `${Math.floor(config.count * 100)}`;
                let activityData = this._modal.getData(tag);
                if (activityData && activityData.claimed) {
                    listId++;
                }
            }
            this.listView.scrollTo(listId, 0.2);
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();

        //let spriteFrame = await loadUtils.loadRes(`textures/bg/activity_bg_${this._type}`, cc.SpriteFrame) as cc.SpriteFrame;
        //this.spriteBg.spriteFrame = spriteFrame;

        try {
            await activityLogic.activityReq(this._type);
            this._modal = activityLogic.getActivityConfigs(this._type);
        } catch (e) {
            console.error(e);
        }
    }
    /*
        protected _unloadRes(prefab: cc.Prefab) {
            super._unloadRes(prefab);
            loadUtils.releaseAssetRecursively(this.spriteBg.spriteFrame);
        }*/
}
