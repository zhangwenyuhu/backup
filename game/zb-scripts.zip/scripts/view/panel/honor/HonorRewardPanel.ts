import BasePanel, { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import { HonorRankType } from "../../../utils/DefineUtils";
import { RankingScoreconfigRow } from "../../../configs/RankingScoreconfig";
import honorLogic from "../../../logics/HonorLogic";
import gm from "../../../manager/GameManager";
import CommonLoader from "../../common/CommonLoader";
import PlayerHead from "../../component/Player/PlayerHead";
import EManager, { EName } from "../../../manager/EventManager";
import promptLogic, { PromptType } from "../../../logics/PromptLogic";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/honor/HonorRewardPanel")
export default class HonorRewardPanel extends PopupPanel {

    @property(List)
    scoreList: List = null;

    @property(cc.Node)
    title: cc.Node = null;

    private _type: HonorRankType = 0;
    private _cfgs: RankingScoreconfigRow[] = [];
    onInit(data: any) {
        this._type = data;
        this._cfgs = honorLogic.getHonorCfgs(this._type);
    }

    start() {
        super.start();

        this.title.getComponent(cc.Label).string = honorLogic.getHonorRankTitle(this._type);

        this.scoreList.getComponent(cc.Widget).updateAlignment();
        this.scoreList.numItems = this._cfgs.length;

        let toIndex:number=0;
        for(let i=0;i<this._cfgs.length;i++){
            let id=this._cfgs[i].ID;
            if(honorLogic.isOpen(this._type,id) && !honorLogic.isGotReward(this._type,id)){
                toIndex=i;
                break;
            }
        }
        this.scheduleOnce(()=>{
            this.scoreList.scrollTo(toIndex-1,1/30);
        },0.1);
        
    }

    onDestroy() {
        EManager.emit(EName.onFreshPanel,"HonorRankPanel");
        super.onDestroy();
    }

    onItemRender(item: cc.Node, index: number) {
        if (item) {
            this.freshItem(item, this._cfgs[index]);
        }
    }

    freshItem(node: cc.Node, data: RankingScoreconfigRow) {
        let user = node.getChildByName("user");
        let flag = node.getChildByName("flag");
        let desc = node.getChildByName("desc");
        let btnGet = node.getChildByName("btnGet").getComponent(cc.Button);
        let btnNo = node.getChildByName("btnNo").getComponent(cc.Button);
        let btnUser = user.getChildByName("btn").getComponent(cc.Button);

        let bOpen = honorLogic.isOpen(this._type, data.ID);
        let bGot = honorLogic.isGotReward(this._type, data.ID);
        btnGet.node.active = !bGot && bOpen;
        btnGet.clickEvents[0].customEventData = `${data.ID}`;
        btnUser.clickEvents[0].customEventData = `${data.ID}`;

        btnNo.node.active = !bOpen;
        node.getChildByName("completed").active = bGot;

        user.active = bOpen;
        flag.active = !bOpen;
        if (user.active) {
            let player = honorLogic.getFirstReachPlayer(this._type, data.ID);
            if (player) {
                let userHead = user.getChildByName("player_head").getComponent(CommonLoader);
                userHead.loaderNode.getComponent(PlayerHead).refresh(player);

                user.getChildByName("name").getComponent(cc.Label).string = player.getNickname();
            }
        }

        let str: string = honorLogic.getHonorRewardDesc(this._type, data);
        desc.getComponent(cc.Label).string = str;

        cc.find("reward/num", node).getComponent(cc.Label).string = `${data.diamond}`;
        node.getChildByName("reward").opacity=bGot?150:255;
        node.getChildByName("desc").color=bOpen?cc.color(106,253,254):cc.color(175,237,255);
    }

    async onClickUser(sender: cc.Event.EventTouch, index: string) {
        let id: number = parseInt(index)
        await honorLogic.rankRewardTop5Req(this._type, id);
        gcc.core.showLayer("prefabs/panel/honor/HonorUserPanel", { data: { type: this._type, id: id } });
    }

    async onClickGetReward(sender: cc.Event.EventTouch, index: string) {
        try {
            let id: number = parseInt(index);
            await honorLogic.getRankRewardReq(this._type, id);

            let listIndex = this.getIndex(id);
            if (listIndex < 0) {
                this.scoreList.updateAll();
            } else {
                this.scoreList.updateItem(listIndex);
            }
            EManager.emit(EName.onRedDirty,honorLogic.getPromptType(this._type));
            this.syncServerRed();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    async syncServerRed(){
        if(honorLogic.hasHonorRankReward(this._type)){return;}

        if(this._type==HonorRankType.race_wuzhuang){
            await promptLogic.setPromptRead([PromptType.RACE_WUZHANG]);
        }else if(this._type==HonorRankType.race_jixie){
            await promptLogic.setPromptRead([PromptType.RACE_JIXIE]);
        }else if(this._type==HonorRankType.race_bianzhong){
            await promptLogic.setPromptRead([PromptType.RACE_BIANZHONG]);
        }else if(this._type==HonorRankType.race_chaoneng){
            await promptLogic.setPromptRead([PromptType.RACE_CHAONENG]);
        }else if(this._type==HonorRankType.mission){
            await promptLogic.setPromptRead([PromptType.RACE_MISSION]);
        }else if(this._type==HonorRankType.tower){
            await promptLogic.setPromptRead([PromptType.RACE_TOWER]);
        }
    }

    onClickNoComplete(sender: cc.Event.EventTouch, index: string) {
        gm.toast(stringConfigMap.key_desc_61.Value);
    }

    private getIndex(id: number): number {
        let len = this._cfgs.length;
        for (let i = 0; i < len; i++) {
            if (this._cfgs[i].ID == id) {
                return i;
            }
        }
        return -1;
    }
}
