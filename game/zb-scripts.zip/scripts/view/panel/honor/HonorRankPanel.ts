import { FullscreenPanel } from "../BasePanel";
import commonUtils from "../../../utils/CommonUtils";
import List from "../../common/List";
import { HonorRankType } from "../../../utils/DefineUtils";
import honorLogic from "../../../logics/HonorLogic";
import User from "../../../data/user/User";
import playerLogic from "../../../logics/PlayerLogic";
import CommonLoader from "../../common/CommonLoader";
import PlayerHead from "../../component/Player/PlayerHead";
import PlayerName from "../../component/Player/PlayerName";
import RankData from "../../../data/record/RankData";
import loadUtils from "../../../utils/LoadUtils";
import EManager, { EName } from "../../../manager/EventManager";
import promptLogic, { PromptType } from "../../../logics/PromptLogic";
import friendLogic from "../../../logics/FriendLogic";
import gm from "../../../manager/GameManager";
import activityLogic from "../../../logics/ActivityLogic";
import stringUtils from "../../../utils/StringUtils";
import PlayerAvatar from "../../component/Player/PlayerAvatar";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/honor/HonorRankPanel")
export default class HonorRankPanel extends FullscreenPanel {

    @property(List)
    rankList: List = null;

    @property(cc.Node)
    rankItem: cc.Node = null;

    @property(cc.Node)
    myRank: cc.Node = null;

    @property(cc.Node)
    title: cc.Node = null;

    @property(cc.Node)
    typeLabel: cc.Node = null;

    @property(cc.Node)
    rewardRed: cc.Node = null;

    @property(cc.Node)
    powerNode: cc.Node = null;

    @property(cc.Node)
    rankTitleNode: cc.Node = null;

    @property(cc.Node)
    rankListNode: cc.Node = null;

    @property(cc.Node)
    btnReward: cc.Node = null;

    @property(cc.Label)
    leftSupportTimes: cc.Label = null;

    private _type: HonorRankType = 0;
    onInit(data: any) {
        this._type = data;
    }

    onLoad() {
        super.onLoad();

        this.rankItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.rankItem.destroy();
    }

    start() {
        super.start();

        let widget = this.rankListNode.getComponent(cc.Widget);
        if (this._type == HonorRankType.power) {
            this.powerNode.active = true;
            this.rankTitleNode.y = -310;
            this.btnReward.active = false;
            widget.top = 350;
        } else {
            this.powerNode.active = false;
            this.rankTitleNode.y = -40;
            this.btnReward.active = true;
            widget.top = 90;
        }
        widget.updateAlignment();

        //this.title.getComponent(cc.Label).string = honorLogic.getHonorRankTitle(this._type);
        loadUtils.loadSpriteFrame(honorLogic.getHonorRankTitleUrl(this._type), this.title.getComponent(cc.Sprite));
        this.typeLabel.getComponent(cc.Label).string = honorLogic.getHonorType(this._type);

        this.rankList.numItems = honorLogic.getRankCount(this._type);
        this.initMyRank();
        this.freshUi();
        this.freshTop3();

        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data === "HonorRankPanel") {
                this.freshUi();
            }
        })
        this._eventListeners.push(listener);
    }

    freshUi() {
        let valid = promptLogic.getPrompt(this.getServerRedStr());
        this.rewardRed.active = valid || honorLogic.hasHonorRankReward(this._type);
        promptLogic.setLocalPromptStatus(this.getServerRedStr(), this.rewardRed.active);
    }

    getServerRedStr(): PromptType {
        if (this._type == HonorRankType.race_wuzhuang) {
            return PromptType.RACE_WUZHANG;
        } else if (this._type == HonorRankType.race_jixie) {
            return PromptType.RACE_JIXIE;
        } else if (this._type == HonorRankType.race_bianzhong) {
            return PromptType.RACE_BIANZHONG;
        } else if (this._type == HonorRankType.race_chaoneng) {
            return PromptType.RACE_CHAONENG;
        } else if (this._type == HonorRankType.mission) {
            return PromptType.RACE_MISSION;
        } else if (this._type == HonorRankType.tower) {
            return PromptType.RACE_TOWER;
        }
        return PromptType.NONE;
    }

    private initMyRank() {
        this.myRank.destroyAllChildren();

        let item = cc.instantiate(this.rankItem);
        item.parent = this.myRank;
        item.x = -11.5;
        item.y = 0;
        item.anchorX = 0.5;
        item.anchorY = 0.5;

        this.freshRankItem(item, honorLogic.getMyRank(this._type), false);
    }

    private freshRankItem(node: cc.Node, data: RankData, inList: boolean = true) {
        if (!data) { return; }

        let head = node.getChildByName("player_head");
        let name = node.getChildByName("player_name");
        let user: User = null;
        if (inList) {
            user = data.getRole();
            node.getChildByName("bg2").active = false;
            node.getChildByName("bg1").active = data.getRank() % 2 > 0;
        } else {
            user = playerLogic.getPlayer();
            node.getChildByName("bg2").active = true;
            node.getChildByName("bg1").active = false;
        }
        head.getComponent(CommonLoader).loaderNode.getComponent(PlayerHead).refresh(user);
        name.getComponent(CommonLoader).loaderNode.getComponent(PlayerName).refresh(user);

        // rank
        let num = data.getRank();
        for (let i = 1; i < 4; i++) {
            node.getChildByName(`rank${i}`).active = (i == num);
        }

        let str = (num > 50 || num <= 0) ? "未上榜" : `${num}`;
        node.getChildByName("rank").getComponent(cc.Label).string = str;
        node.getChildByName("rank").active = num > 3 || num <= 0;

        // flag and score
        let flag: boolean = false;
        if (data.getType() == HonorRankType.mission) {
            flag = false;
            str = `${honorLogic.getChapter(data.getScore())}`;
        } else if (data.getType() == HonorRankType.tower) {
            flag = false;
            str = `第${data.getScore()}层`
        } else if (data.getType() == HonorRankType.power) {
            flag = true;
            str = stringUtils.formatAmount(data.getScore());
        } else {
            flag = true;
            str = `${data.getScore()}`;
        }
        let tag = cc.find("score/layout/icon", node)
        tag.active = flag;
        if (tag.active) {
            let url = commonUtils.getHeroFactionUrl(honorLogic.getHonorFaction(this._type));
            if (data.getType() == HonorRankType.power) { url = 'textures/ui/main/main_icon_fight'; }
            loadUtils.loadSpriteFrame(url, tag.getComponent(cc.Sprite));
        }
        cc.find("score/layout/text", node).getComponent(cc.Label).string = str;
        cc.find("score/layout", node).active = flag;
        cc.find("score/text", node).active = !flag;
        cc.find("score/text", node).getComponent(cc.Label).string = str;
    }

    onItemRender(item: cc.Node, index: number) {
        if (item) {
            let rankData = honorLogic.getRankData(this._type, index);
            this.freshRankItem(item, rankData);
        }
    }

    async onClickReward() {
        if (this._type == HonorRankType.power) { return; }
        await honorLogic.rankRewardFirstReachReq(this._type);
        await honorLogic.rankRewardsReq(this._type);
        gcc.core.showLayer("prefabs/panel/honor/HonorRewardPanel", { data: this._type });
    }

    protected freshTop3() {
        if (this._type !== HonorRankType.power) { return; }
        let top3: cc.Node = this.powerNode.getChildByName('rank');
        for (let i = 0; i < 3; i++) {
            let rank: number = i + 1;
            let node = top3.getChildByName(`rank${rank}`);
            let rankData = honorLogic.getRankData(this._type, i);
            if (!rankData) { continue; }
            let player = rankData.getRole();
            if (!player) { continue; }

            node.active = rankData ? true : false;
            if (node.active) {
                let avatarLoader = node.getChildByName('avatar').getComponent(CommonLoader);
                let comp = avatarLoader.loaderNode.getComponent(PlayerAvatar);
                comp.refresh(player.getAvatar());

                let name = node.getChildByName('name').getComponent(cc.Label);
                name.string = player.getNickname();

                let btn = node.getComponent(cc.Button);
                btn.clickEvents[0].customEventData = player.getRoleId();
            }
            let supportBtn = top3.getChildByName(`support${rank}`).getComponent(cc.Button);
            supportBtn.clickEvents[0].customEventData = player.getRoleId();
            let support = top3.getChildByName(`num${rank}`);
            support.getComponent(cc.Label).string = `${player.getLikeCount()}`;
        }

        this.leftSupportTimes.string = `${honorLogic.getMyRank(this._type).getLeftSupportCount()}`;
    }

    async onTop3User(sender: cc.Event.EventTouch, customData: string) {
        if (customData) {
            await friendLogic.playerShow(customData, true);
            let userInfo = friendLogic.getPlayerInfo(customData);
            gcc.core.showLayer("prefabs/panel/player/UserPanel", { data: { user: userInfo } });
        }
    }

    async onSupport(sender: cc.Event.EventTouch, customData: string) {
        let myRankInfo = honorLogic.getMyRank(this._type);
        if (myRankInfo.getLeftSupportCount() <= 0) {
            gm.toast('今日点赞次数已用尽');
            return;
        }
        try {
            let data = await activityLogic.supportPlayer(customData);
            console.log('support extra: ' + data);
            if (data && data[0]) {
                let num: number = parseInt(data[0] as any);
                for (let i = 0; i < 3; i++) {
                    let data = honorLogic.getRankData(this._type, i);
                    if (data && data.getRole().getRoleId() == customData) {
                        data.getRole().setLikeCount(num);
                    }
                }
            }
            myRankInfo.setCanSupportCountAdd();

            this.freshTop3();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

}
