import { FullscreenPanel } from "../BasePanel";
import commonUtils from "../../../utils/CommonUtils";
import { HonorRankType } from "../../../utils/DefineUtils";
import honorLogic from "../../../logics/HonorLogic";
import HonorScoreItem from "../../component/Honor/HonorScoreItem";
import EManager, { EName } from "../../../manager/EventManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/honor/HonorPanel")
export default class HonorPanel extends FullscreenPanel {
    @property(cc.Node)
    rankItems: cc.Node[] = [];

    onInit(data: any) {
        this.freshTop();
    }

    async freshTop() {
        //await honorLogic.allRankReq();
        for (let i = 0; i < this.rankItems.length; i++) {
            let type: HonorRankType = (i + 1 == this.rankItems.length) ? HonorRankType.power : i + 1;
            let rank = honorLogic.getTop1(type);
            this.rankItems[i].getComponent(HonorScoreItem).refresh(rank);
        }
    }

    async onClickRank(sender: cc.Event.EventTouch, index: string) {
        let type = parseInt(index);
        await honorLogic.rankReq(type);
        gcc.core.showLayer("prefabs/panel/honor/HonorRankPanel", { data: type });
    }

    onClickHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "honor" } });
    }

    onDestroy() {
        super.onDestroy();
        EManager.emit(EName.onFreshPanel, "HomeView");
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("honor_bg"), type: cc.SpriteFrame });
    }
}
