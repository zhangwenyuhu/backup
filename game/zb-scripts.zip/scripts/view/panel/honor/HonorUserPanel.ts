import BasePanel, { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import RankData from "../../../data/record/RankData";
import honorLogic from "../../../logics/HonorLogic";
import CommonLoader from "../../common/CommonLoader";
import PlayerHead from "../../component/Player/PlayerHead";
import PlayerName from "../../component/Player/PlayerName";
import timeUtils from "../../../utils/TimeUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/honor/HonorUserPanel")
export default class HonorUserPanel extends PopupPanel {

    @property(List)
    userList: List = null;

    private _players: RankData[] = [];
    onInit(data: any) {
        this._data = data;
    }

    start() {
        super.start();

        this._players = honorLogic.getTop5(this._data.type, this._data.id);
        this.userList.getComponent(cc.Widget).updateAlignment();
        this.userList.numItems = this._players.length;
    }

    onDestroy() {

        super.onDestroy();
    }

    onItemRender(item: cc.Node, index: number) {
        if (item) {
            let bg = index % 2 == 0;
            item.getChildByName("bg").active = !bg;

            let data = this._players[index];
            if (data) {
                let num = data.getRank();
                for (let i = 1; i < 4; i++) {
                    item.getChildByName(`rank${i}`).active = i == num;
                }
                item.getChildByName("rank").active = num > 3;
                item.getChildByName("rank").getComponent(cc.Label).string = `${num}`;

                let head = item.getChildByName("player_head").getComponent(CommonLoader);
                let name = item.getChildByName("player_name").getComponent(CommonLoader);
                head.loaderNode.getComponent(PlayerHead).refresh(data.getRole());
                name.loaderNode.getComponent(PlayerName).refresh(data.getRole());

                let time = item.getChildByName("time").getComponent(cc.Label)
                time.string = timeUtils.formatTimeToStr(data.getPassTime());
            }
        }
    }
}
