import { stringConfigMap } from './../../../configs/stringConfig';
import dungeonLogic, { DungeonFruitEvent, DungeonEvent } from './../../../logics/DungeonLogic';
import { PopupPanel } from './../BasePanel';
import CommonLoader from '../../common/CommonLoader';
import WisdomChooseItem from '../../component/WisdomTree/WisdomChooseItem';
import gm from '../../../manager/GameManager';
import ToastError from '../../../error/ToastError';
import stringUtils from '../../../utils/StringUtils';
import EManager from '../../../manager/EventManager';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/dungeon/DungeonFruitPanel")
export default class DungeonFruitPanel extends PopupPanel {
    @property(cc.Node)
    fruitTemplate1: cc.Node = null;

    @property(cc.Node)
    fruitContainer1: cc.Node = null;

    @property(cc.Node)
    fruitTemplate2: cc.Node = null;

    @property(cc.Node)
    fruitContainer2: cc.Node = null;

    @property(cc.RichText)
    richText: cc.RichText = null;

    @property(cc.SpriteFrame)
    selectFrames: cc.SpriteFrame[] = [];

    protected _event: DungeonFruitEvent = null;
    protected _items: WisdomChooseItem[] = [];
    protected _buttons: cc.Node[] = [];
    protected _selects: cc.Node[] = [];
    protected _masks: cc.Node[] = [];
    protected _fruitIds: number[] = [];

    onInit(event: DungeonFruitEvent) {
        this._event = event;
    }

    onLoad() {
        super.onLoad();

        this.fruitTemplate1.parent = null;
        this.fruitTemplate2.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        WisdomChooseItem.lastChooseItem = null;
    }

    start() {
        super.start();

        let fruitInfos: {
            id: number,
            selected: boolean,
            isNew: boolean
        }[] = [];
        let fruitTemplate: cc.Node = null;
        let fruitContainer: cc.Node = null;

        for (let i = 0; i < this._event.fruitIds.length; i++) {
            let fruitId = this._event.fruitIds[i];
            fruitInfos.push({ id: fruitId, selected: false, isNew: true });
            this._fruitIds.push(fruitId);
        }

        if (dungeonLogic.fruitIds.length > 0) {
            this.fruitContainer1.active = false;
            this.fruitContainer2.active = true;
            fruitTemplate = this.fruitTemplate2;
            fruitContainer = this.fruitContainer2.getChildByName("content");

            for (let fruitId of dungeonLogic.fruitIds) {
                fruitInfos.push({ id: fruitId, selected: false, isNew: false });
                this._fruitIds.push(fruitId);
            }

            this.richText.string = stringUtils.getString(stringConfigMap.key_fruit_tip2.Value, { count: dungeonLogic.maxFruitCount });
        }
        else {
            this.fruitContainer1.active = true;
            this.fruitContainer2.active = false;
            fruitTemplate = this.fruitTemplate1;
            fruitContainer = this.fruitContainer1;

            this.richText.string = stringUtils.getString(stringConfigMap.key_fruit_tip1.Value, { count: dungeonLogic.maxFruitCount });
        }

        for (let i = 0; i < fruitInfos.length; i++) {
            let info = fruitInfos[i];
            let item = cc.instantiate(fruitTemplate);
            item.parent = fruitContainer;

            let card = item.getChildByName('card');
            let loader = card.getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(WisdomChooseItem);
            comp.refresh(info.id);

            // let btnRefresh = item.getChildByName("btn_refresh");
            // btnRefresh.active = info.canRefresh;
            // btnRefresh.on("click", () => { this.onRefresh(i); }, this);
            // this._buttons.push(btnRefresh);

            let mask = item.getChildByName("mask");
            if (mask) {
                mask.active = !info.selected;
                this._masks.push(mask);
            }

            let selectBg = item.getChildByName("select");
            if (selectBg) {
                selectBg.getComponent(cc.Sprite).spriteFrame = this.selectFrames[comp.fruitConfig.rarity - 1];

                let select = selectBg.getChildByName("select");
                select.active = info.selected;
                comp.enableLight(select.active);
                this._selects.push(select);
            }

            let newNode = item.getChildByName("new");
            if (newNode) {
                newNode.active = info.isNew;
            }

            if (dungeonLogic.fruitIds.length > 0) {
                comp.onChoose = this._chooseFruit.bind(this, item, comp);
            }
            else {
                comp.onChoose = () => { }
            }
            this._items.push(comp);
        }
    }

    protected _chooseFruit(item: cc.Node, comp: WisdomChooseItem) {
        let selectBg = item.getChildByName("select");
        let mask = item.getChildByName("mask");
        if (selectBg && mask) {
            let select = selectBg.getChildByName("select");
            let selects = this._selects.filter(a => a.active);
            if (selects.length >= dungeonLogic.maxFruitCount && !select.active) {
                gm.toast(stringUtils.getString(stringConfigMap.key_select_max_fruit.Value, { count: dungeonLogic.maxFruitCount }));
                return;
            }
            select.active = !select.active;
            mask.active = !select.active
            comp.enableLight(select.active);
        }
    }

    async onConfirm() {
        try {
            if (dungeonLogic.fruitIds.length > 0) {
                let fruitIds = [];
                for (let i = 0; i < this._selects.length; i++) {
                    if (this._selects[i].active) {
                        fruitIds.push(this._fruitIds[i]);
                    }
                }
                if (fruitIds.length != dungeonLogic.maxFruitCount) {
                    throw new ToastError(stringUtils.getString(stringConfigMap.key_need_select_fruit.Value, { count: dungeonLogic.maxFruitCount }));
                }
                await this._event.trigger(fruitIds);
            }
            else {
                await this._event.trigger();
            }
            this.closePanel();

            EManager.emit(DungeonEvent.Event.onSelectFruits);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    async onRefresh(index: number) {
        try {
            let fruitId = await this._event.refresh(index - dungeonLogic.fruitIds.length);
            this._items[index].refresh(fruitId);
            this._buttons[index].active = false;
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}
