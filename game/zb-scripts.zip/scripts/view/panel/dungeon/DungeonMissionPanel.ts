import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from "../BasePanel";
import dungeonLogic, { DungeonEvent } from "../../../logics/DungeonLogic";
import CommonLoader from "../../common/CommonLoader";
import HeroCard from "../../component/Hero/HeroCard";
import GoodCard from "../../component/Good/GoodCard";
import EManager, { EName } from "../../../manager/EventManager";
import { BattleType } from "../../../utils/DefineUtils";
import gm from "../../../manager/GameManager";
import Hero from '../../../data/card/Hero';
import { defaultConfigMap } from '../../../configs/defaultConfig';
import commitLogic from '../../../logics/CommitLogic';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/dungeon/DungeonMissionPanel")
export default class DungeonMissionPanel extends PopupPanel {
    @property(cc.Label)
    labelName: cc.Label = null;

    @property(cc.Label)
    labelDesc: cc.Label = null;

    @property(cc.Node)
    monsterList: cc.Node = null;

    @property(cc.Node)
    monsterTemplate: cc.Node = null;

    @property(cc.Node)
    rewardList: cc.Node = null;

    @property(cc.Node)
    goodTemplate: cc.Node = null;

    @property(cc.Label)
    btnDesc: cc.Label = null;

    onLoad() {
        super.onLoad();
        this.monsterTemplate.parent = null;
        this.goodTemplate.parent = null;

        let listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType }) => {
            if (data.type != BattleType.Dungeon)
                return;
            this.closePanel();
        });
        this._eventListeners.push(listener);
    }

    onEnable() {
        super.onEnable();
        EManager.emit(DungeonEvent.Event.onShowMonster);
    }

    start() {
        super.start();

        let monsters = dungeonLogic.battleData.getMonsters();
        for (let monster of monsters) {
            let node = cc.instantiate(this.monsterTemplate);
            node.parent = this.monsterList;

            let heroNode = node.getChildByName("hero_card");
            let loader = heroNode.getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(HeroCard);
            comp.refresh(monster);
            comp.registerOnHeroInfo();
        }

        let rewards = dungeonLogic.battleData.getRewards();
        for (let reward of rewards) {
            let node = cc.instantiate(this.goodTemplate);
            node.parent = this.rewardList;

            let loader = node.getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(GoodCard);
            comp.refresh(reward);
            comp.registerOnGoodInfo();
        }

        this.btnDesc.string = this.canWipe() ? '扫 荡' : '战 斗';
    }

    protected canWipe(): boolean {
        let npcPower: number = dungeonLogic.battleData.getMonstersPower();
        let myPower = dungeonLogic.battleHero.getPower();
        let assistHeroPowers: number[] = dungeonLogic.assistHeroes.map((v, i, a) => { return v.getPower(); });
        assistHeroPowers.sort((a, b) => { return b - a; });
        for (let i = 0; i < 2; i++) {
            if (assistHeroPowers[i]) { myPower += assistHeroPowers[i]; }
        }
        console.log(`地牢助力: ${myPower} 地牢怪物: ${npcPower}`);
        let num: number = defaultConfigMap.skybuildbattlenumber.value;
        return myPower > npcPower * num;
    }

    onFight() {
        if (dungeonLogic.assistHeroes.length < dungeonLogic.maxAssistSelectCount) {
            gm.toast(stringConfigMap.key_dungeon_assist_less_than.Value);
            return;
        }

        if (this.canWipe()) {
            this.doWipeDungeon();
        } else {
            gcc.core.showLayer("prefabs/panel/dungeon/DungeonPreparePanel", { data: dungeonLogic.battleData })
        }
    }

    async doWipeDungeon() {
        console.log(`跳过地牢战斗`);
        let id: number = dungeonLogic.battleData.id;
        let cards = await dungeonLogic.doClaimMissionRewards();
        gcc.core.showLayer("prefabs/panel/reward/RewardPanel", {
            data: { cards: cards },
            modalTouch: true
        });
        commitLogic.dungeonBattle(id, true);
        this.closePanel();
        EManager.emit(DungeonEvent.Event.onWipeDungeon);
        EManager.emit(EName.onGameExit, { type: dungeonLogic.battleData.getBattleType() });
    }
}   
