import { guideconfigRow } from './../../../configs/guideconfig';
import { Storage } from './../../../utils/DefineUtils';
import { defaultConfigMap } from './../../../configs/defaultConfig';
import { stringConfigMap } from './../../../configs/stringConfig';
import { HeroSelect } from './../../widget/hero/HeroSelectItem';
import { FullscreenPanel } from './../BasePanel';
import List from '../../common/List';
import Hero from '../../../data/card/Hero';
import heroLogic from '../../../logics/HeroLogic';
import gm from '../../../manager/GameManager';
import HeroSelectLockItem from '../../widget/hero/HeroSelectLockItem';
import loadUtils from '../../../utils/LoadUtils';
import commonUtils from '../../../utils/CommonUtils';
import dungeonLogic from '../../../logics/DungeonLogic';
import cm from '../../../manager/ConfigManager';
import stringUtils from '../../../utils/StringUtils';
import DungeonHeroStation from '../../component/Dungeon/DungeonHeroStation';
import EManager, { EName } from '../../../manager/EventManager';
import storageUtils from '../../../utils/StorageUtils';
import guideLogic from '../../../logics/GuideLogic';
import ToastError from '../../../error/ToastError';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/dungeon/DungeonSelectPanel")
export default class DungeonSelectPanel extends FullscreenPanel {
    @property(List)
    heroList: List = null;

    @property(cc.Widget)
    heroWidget: cc.Widget = null;

    @property(cc.Node)
    selectHeroBg: cc.Node = null;

    @property(cc.Node)
    heroContainer: cc.Node = null;

    @property(cc.Node)
    heroArea: cc.Node = null;

    @property(cc.Node)
    emptyNode: cc.Node = null;

    @property(cc.Label)
    labelEmpty: cc.Label = null;

    @property(sp.Skeleton)
    bgSkeleton: sp.Skeleton = null;

    protected _filterIndex = Hero.Faction.All;
    protected _totalSelects: { hero: Hero, isSelect: boolean, passed: boolean }[] = [];
    protected _currentSelects: { hero: Hero, isSelect: boolean, passed: boolean }[] = [];
    protected _selectHeroStation: DungeonHeroStation = null;
    protected _needUnlockRes: boolean = true;
    protected _guideListId: number = -1;
    protected _skeletonUrl: string = "";

    onLoad() {
        super.onLoad();

        this.heroArea.parent = null;

        let worldPoint = this.selectHeroBg.convertToWorldSpaceAR(cc.v2(0, -this.selectHeroBg.height / 2));
        let localPoint = this.node.convertToNodeSpace(worldPoint);
        this.heroWidget.top = cc.winSize.height - localPoint.y;
        this.heroWidget.updateAlignment();
    }

    start() {
        super.start();

        for (let i = 0; i < dungeonLogic.maxHeroCount; i++) {
            let area = cc.instantiate(this.heroArea);
            area.parent = this.heroContainer;

            let station = area.getComponent(DungeonHeroStation);
            station.init(this._onSelect.bind(this));
        }

        let heroMap: { [key: number]: Hero[] } = [];
        let allHeroes = heroLogic.getHeroes();
        for (let hero of allHeroes) {
            if (hero.getRank() < defaultConfigMap.dilaoherorank.value) {
                continue;
            }

            let heroes = heroMap[hero.getIndex()];
            if (!heroes) {
                heroes = [];
                heroMap[hero.getIndex()] = heroes;
            }
            heroes.push(hero);
        }

        allHeroes = [];
        for (let key in heroMap) {
            let heroes = heroMap[key];
            heroes.sort(dungeonLogic.sortHeroes.bind(dungeonLogic));
            allHeroes.push(heroes[0]);
        }

        this.emptyNode.active = allHeroes.length == 0;
        this.labelEmpty.string = stringUtils.getString(stringConfigMap.key_no_valid_hero_for_dungeon.Value, { level: defaultConfigMap.dilaolvlimit.value });
        if (this.emptyNode.active) {
            gm.toast(this.labelEmpty.string);
            return;
        }

        heroLogic.sortHeroes(allHeroes, { sortPower: true });

        let indexes = new Set<number>(dungeonLogic.lastHeroSelectIndexes);
        let selectHeroes: Hero[] = [];
        this._totalSelects = [];
        for (let hero of allHeroes) {
            let select = { hero: hero, isSelect: indexes.has(hero.getIndex()), passed: false };
            let process = dungeonLogic.getHeroProcess(hero.getIndex());
            if (process) {
                let limitLevel = dungeonLogic.getLimitLevel(hero);
                select.passed = process >= limitLevel + 1000;
                if (select.passed) { select.isSelect = false; }
            }
            this._totalSelects.push(select);
            if (select.isSelect) { selectHeroes.push(select.hero); }
        }
        for (let i = 0; i < this.heroContainer.childrenCount; i++) {
            let child = this.heroContainer.children[i];
            let station = child.getComponent(DungeonHeroStation);
            station.refresh(selectHeroes[i]);
            if (i == 0) {
                station.focus();
            }
            else {
                station.unfocus();
            }
        }
        this.updateHeroListByFaction(this._filterIndex, true);

        if (!storageUtils.getBoolean(Storage.DungeonGuide)) {
            if (this._totalSelects.length > 0) {
                let count = Math.min(this._totalSelects.length, dungeonLogic.maxHeroCount);
                for (let i = 0; i < count; i++) {
                    let item = this.heroList.content.children[0].getComponent(HeroSelectLockItem);
                    if (item.heroSelect.isSelect) {
                        return;
                    }
                    if (item.nodeLock.active) {
                        return;
                    }
                }
                guideLogic.guideId = 110001;
            }
        }
    }

    updateHeroListByFaction(faction: number, force: boolean = false): boolean {
        if (this._filterIndex == faction && !force) {
            return false;
        }
        this._filterIndex = faction;

        if (faction == Hero.Faction.All) {
            this._currentSelects = this._totalSelects;
        }
        else {
            this._currentSelects = this._totalSelects.filter((select: { hero: Hero, isSelect: boolean }) => { return select.hero.getFaction() == faction; });
        }
        this.heroList.numItems = this._currentSelects.length;
        return true;
    }

    get heroStations(): DungeonHeroStation[] {
        let stations = [];
        for (let child of this.heroContainer.children) {
            let station = child.getComponent(DungeonHeroStation);
            if (station.hero) { stations.push(station); }
        }
        return stations;
    }

    onHeroItemRender(item: cc.Node, index: number) {
        let heroSelect = this._currentSelects[index];
        let comp = item.getComponent(HeroSelectLockItem);
        comp.checkLockCallback = (heroSelect: HeroSelect) => {
            if (!heroSelect.isSelect) {
                if (this.heroStations.length == dungeonLogic.maxHeroCount) {
                    return { result: false, message: stringUtils.getString(stringConfigMap.key_dungeon_fight_hero_limit.Value, { count: dungeonLogic.maxHeroCount }) };
                }

                let processBg = item.getChildByName("bg");
                if (processBg.active) {
                    let label = processBg.getChildByName("label").getComponent(cc.Label);
                    if (label.string == stringConfigMap.key_passed.Value) {
                        return { result: false, message: stringConfigMap.key_dungeon_hero_passed.Value }
                    }
                }
            }
            return { result: true }
        }

        let processBg = item.getChildByName("bg");
        let process = dungeonLogic.getHeroProcess(heroSelect.hero.getIndex());
        if (process) {
            processBg.active = true;

            let label = processBg.getChildByName("label").getComponent(cc.Label);
            if (!heroSelect.passed) {
                label.string = stringUtils.getString(stringConfigMap.key_dungeon_process.Value, { level: (process + 1) % 1000 });
            }
            else {
                label.string = stringConfigMap.key_passed.Value;
            }
        }
        else {
            processBg.active = false;
        }

        comp.init(heroSelect.hero, heroSelect.isSelect);

        let func = HeroSelectLockItem.prototype.onToggleSelect;
        comp.onToggleSelect = () => {
            func.call(comp);
            this._currentSelects[index].isSelect = comp.heroSelect.isSelect;
            if (comp.heroSelect.isSelect) {
                for (let i = 0; i < this.heroContainer.childrenCount; i++) {
                    let child = this.heroContainer.children[i];
                    let station = child.getComponent(DungeonHeroStation);
                    if (!station.hero) {
                        station.refresh(comp.heroSelect.hero);
                        this._onSelect(station);
                        break;
                    }
                }
            }
            else {
                for (let i = 0; i < this.heroContainer.childrenCount; i++) {
                    let child = this.heroContainer.children[i];
                    let station = child.getComponent(DungeonHeroStation);
                    if (station.hero == comp.heroSelect.hero) {
                        station.refresh(null);
                        this._onSelect(null);
                        break;
                    }
                }
            }
            EManager.emit(EName.onUpdateTroopHero);
        }
    }

    onFilterHero(event: cc.Event.EventTouch, faction: string) {
        if (this.updateHeroListByFaction(Number(faction))) {
            //gm.toast(stringConfigMap[`key_faction_filter_${faction}`].Value);
        }
    }

    onConfirm() {
        let stations = this.heroStations;
        let heroes: Hero[] = [];
        let selectIndex = 0;
        for (let i = 0; i < stations.length; i++) {
            heroes.push(stations[i].hero);
            if (stations[i].isFocus) {
                selectIndex = i;
            }
        }

        if (heroes.length == 1) {
            let selects = this._totalSelects.filter((a: { hero: Hero, isSelect: boolean, passed: boolean }) => { return !a.passed });
            if (selects.length >= dungeonLogic.maxHeroCount) {
                gm.dialog({
                    content: stringConfigMap.key_dungeon_select_tip.Value,
                    confirm: () => { this.onStart(heroes, selectIndex) }
                });
                return;
            }
        }

        this.onStart(heroes, selectIndex);
    }

    async onStart(heroes: Hero[], selectIndex: number) {
        try {
            if (heroes.length == 1) { selectIndex = 0; }
            await dungeonLogic.doSelectBattleHero(heroes, selectIndex);

            gcc.core.showLayer("prefabs/panel/dungeon/DungeonMapPanel", {
                callback: () => {
                    this._needUnlockRes = false;
                    this.closePanel();
                }
            });
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    onHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "dungeon" } });
    }

    onRank() {
        gm.toast(stringConfigMap.key_developing.Value);
    }

    onFinishGuide(step: guideconfigRow) {
        if (this._totalSelects.length == 1) {
            guideLogic.guideId = 110002;
        }
    }

    protected _onSelect(station: DungeonHeroStation) {
        let stations = this.heroStations;
        if (stations.length == 1) {
            stations[0].focus();
            return;
        }

        for (let i = 0; i < stations.length; i++) {
            if (stations[i] == station) {
                stations[i].focus();
            }
            else {
                stations[i].unfocus();
            }
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this._skeletonUrl = dungeonLogic.getSkeletonUrl(dungeonLogic.lastHeroSelectIndexes[0] || 0);
        let skeletonData = cc.loader.getRes(this._skeletonUrl, sp.SkeletonData);
        if (!skeletonData) {
            skeletonData = await loadUtils.loadRes(this._skeletonUrl, sp.SkeletonData) as sp.SkeletonData;
        }
        this.bgSkeleton.skeletonData = skeletonData;
        this.bgSkeleton.animation = "idle";
        this.bgSkeleton.loop = true;
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);

        if (this._needUnlockRes) {
            let res = cc.loader.getRes(this._skeletonUrl, sp.SkeletonData);
            if (res) { loadUtils.releaseAssetRecursively(res); }

            for (let child of this.heroContainer.children) {
                let node = cc.find('area/area/skeleton', child);
                let skeleton = node.getComponent(sp.Skeleton);
                if (skeleton.skeletonData) {
                    loadUtils.releaseAssetRecursively(skeleton.skeletonData);
                }
            }
        }
    }
}