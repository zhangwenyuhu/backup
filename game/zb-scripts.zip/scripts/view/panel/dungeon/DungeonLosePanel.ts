import BattleLosePanel from '../battle/BattleLosePanel';
import dungeonLogic from '../../../logics/DungeonLogic';
import commonUtils from '../../../utils/CommonUtils';
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/dungeon/DungeonLosePanel")
export default class DungeonLosePanel extends BattleLosePanel {
    @property(cc.Sprite)
    spriteHero: cc.Sprite = null;

    @property(cc.Node)
    heartNode: cc.Node = null;

    @property(cc.Node)
    heartContent: cc.Node = null;

    @property(cc.SpriteFrame)
    heartFrames: cc.SpriteFrame[] = [];

    onLoad() {
        super.onLoad();
        this.heartNode.parent = null;
    }

    start() {
        super.start();

        for (let i = 0; i < dungeonLogic.totalTime; i++) {
            let node = cc.instantiate(this.heartNode);
            node.parent = this.heartContent;

            let sprite = node.getComponent(cc.Sprite);
            if (i < dungeonLogic.remainCount) {
                sprite.spriteFrame = this.heartFrames[0];
            }
            else {
                sprite.spriteFrame = this.heartFrames[1];
            }
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();

        await dungeonLogic.doFailMission();

        let url = commonUtils.getHeroBigUrl(dungeonLogic.battleHero.getIndex());
        let res = cc.loader.getRes(url, cc.SpriteFrame);
        this.spriteHero.spriteFrame = res;
    }
}
