import { PopupPanel } from './../BasePanel';
import dungeonLogic from '../../../logics/DungeonLogic';
import CommonLoader from '../../common/CommonLoader';
import WisdomChooseItem from '../../component/WisdomTree/WisdomChooseItem';
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/dungeon/DungeonBagPanel")
export default class DungeonBagPanel extends PopupPanel {
    @property(cc.Node)
    itemTemplate: cc.Node = null;

    @property(cc.Node)
    fruitContainer: cc.Node = null;

    onLoad() {
        super.onLoad();

        this.itemTemplate.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        WisdomChooseItem.lastChooseItem = null;
    }

    start() {
        super.start();

        let fruitIds = dungeonLogic.fruitIds;
        for (let i = 0; i < fruitIds.length; i++) {
            let fruitId = fruitIds[i];
            let item = cc.instantiate(this.itemTemplate);
            item.parent = this.fruitContainer;
            let loader = item.getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(WisdomChooseItem);
            comp.refresh(fruitId);

            let onChoose = comp.onChoose;
            comp.onChoose = () => {
                onChoose.call(comp);
                comp.node.scale = 1;
                comp.chooseBtn.active = false;
            }
        }
    }
}
