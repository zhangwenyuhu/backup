import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from './../BasePanel';
import dungeonLogic, { DungeonBattleData } from '../../../logics/DungeonLogic';
import loadUtils from '../../../utils/LoadUtils';
import commonUtils from '../../../utils/CommonUtils';
import stringUtils from '../../../utils/StringUtils';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/dungeon/DungeonPassedPanel")
export default class DungeonPassedPanel extends PopupPanel {
    @property(cc.Sprite)
    spriteIco: cc.Sprite = null;

    @property(cc.Label)
    labelTip: cc.Label = null;

    protected async _preloadRes() {
        await super._preloadRes();

        this.spriteIco.spriteFrame = cc.loader.getRes(commonUtils.getHeroBigUrl(dungeonLogic.battleHero.getIndex()), cc.SpriteFrame);
        this.labelTip.string = stringUtils.getString(stringConfigMap.key_dungeon_all_passed.Value, { name: dungeonLogic.battleHero.getName() });
    }
}
