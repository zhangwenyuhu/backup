import { DungeonAssistHero } from './../../../logics/DungeonLogic';
import { PopupPanel } from './../BasePanel';
import List from '../../common/List';
import Hero from '../../../data/card/Hero';
import dungeonLogic from '../../../logics/DungeonLogic';
import CommonLoader from '../../common/CommonLoader';
import HeroCard from '../../component/Hero/HeroCard';
const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/dungeon/DungeonHeroPanel")
export default class DungeonHeroPanel extends PopupPanel {
    @property(List)
    heroList: List = null;

    protected _heroes: Hero[] = [];

    start() {
        super.start();
        this._heroes = [dungeonLogic.battleHero];
        this._heroes.pushList(dungeonLogic.assistHeroes);
        this.heroList.numItems = this._heroes.length;
    }

    onHeroItemRender(item: cc.Node, index: number) {
        let hero = this._heroes[index];
        let flag = item.getChildByName("flag");
        if (hero instanceof DungeonAssistHero) {
            flag.active = true;
        }
        else {
            flag.active = false;
        }

        let loader = item.getChildByName("hero").getComponent(CommonLoader);
        let comp = loader.loaderNode.getComponent(HeroCard);
        comp.refresh(hero);
    }
}
