import BattlePreparePanel from "../battle/BattlePreparePanel";
import Hero from "../../../data/card/Hero";
import dungeonLogic, { DungeonBattleData } from "../../../logics/DungeonLogic";
import playerLogic from "../../../logics/PlayerLogic";
import loadUtils from "../../../utils/LoadUtils";
import commonUtils from "../../../utils/CommonUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/dungeon/DungeonPreparePanel")
export default class DungeonPreparePanel extends BattlePreparePanel {
    @property({
        type: cc.Node,
        override: true,
        visible: false
    })
    missionInfo: cc.Node = null;

    @property({
        type: cc.Label,
        override: true,
        visible: false
    })
    labelMission: cc.Label = null;

    @property({
        type: cc.Material,
        override: true,
        visible: false
    })
    normalMaterial: cc.Material = null;

    @property({
        type: cc.Material,
        override: true,
        visible: false
    })
    grayMaterial: cc.Material = null;

    @property({
        type: cc.Node,
        override: true,
        visible: false
    })
    speakNode: cc.Node = null;

    @property({
        type: cc.Label,
        override: true,
        visible: false
    })
    speakLabel: cc.Label = null;

    @property({
        type: cc.Node,
        override: true,
        visible: false
    })
    factionNode: cc.Node = null;

    protected _heroes: Hero[] = [];
    protected _heroesMap: { [key: string]: Hero } = {};

    onInit(battleData: DungeonBattleData) {
        super.onInit(battleData);

        let heroes: Hero[] = [dungeonLogic.battleHero];
        heroes.pushList(dungeonLogic.assistHeroes);
        this._heroes = heroes;

        for (let hero of heroes) {
            this._heroesMap[hero.getId()] = hero;
        }
    }

    async start() {
        this.createAllStations();
        this.updateAllStations();
        this.updateHeroListByFaction(Hero.Faction.All);
    }

    createAllStations() {
        super.createAllStations();
        for (let i = 0; i < this.selfStations.length; i++) {
            let station = this.selfStations[i];
            station.y -= (cc.winSize.height - 1334) / 2;
        }
        for (let i = 0; i < this.enemyStations.length; i++) {
            let station = this.enemyStations[i];
            station.y -= (cc.winSize.height - 1334) / 2;
        }
    }

    updateHeroListByFaction(faction: number, force: boolean = false): boolean {
        if (this._filterIndex == faction && !force) {
            return false;
        }
        this._filterIndex = faction;

        let heroes: Hero[] = this._heroes.slice(0);
        if (faction != Hero.Faction.All) {
            heroes = heroes.filter((a: Hero) => { return a.getFaction() == faction })
        }

        this.troopPicker.updateTroop(heroes, this._selectHeroes);
        this.updateSelfStations();

        return true;
    }

    async updateTroop() {
        await dungeonLogic.doUpdateTroop(this._selectHeroes);
    }

    protected async _getTroop(): Promise<Hero[]> {
        let heroes: Hero[] = [];
        let troop = dungeonLogic.troop;
        for (let i = 1; i <= playerLogic.getMaxInstanceTroopCount(); i++) {
            if (troop[i]) {
                heroes.push(this._heroesMap[troop[i]]);
            }
            else {
                heroes.push(null);
            }
        }
        return heroes;
    }

    protected _unloadSpine() {
        let troop = this.getTroops();
        for (let hero of troop.selfTroop) {
            if (!hero) continue;
            if (hero.getIndex() == dungeonLogic.battleHero.getIndex()) continue;
            let skeletonData = cc.loader.getRes(commonUtils.getHeroSpineUrl(hero.getSpineFile()), sp.SkeletonData) as sp.SkeletonData;
            loadUtils.releaseAssetRecursively(skeletonData);
        }
        for (let hero of troop.enemyTroop) {
            if (!hero) continue;
            if (hero.getIndex() == dungeonLogic.battleHero.getIndex()) continue;
            let skeletonData = cc.loader.getRes(commonUtils.getHeroSpineUrl(hero.getSpineFile()), sp.SkeletonData) as sp.SkeletonData;
            loadUtils.releaseAssetRecursively(skeletonData);
        }
    }
}
