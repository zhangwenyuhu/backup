import { EName } from './../../../manager/EventManager';
import { Storage, BattleType } from './../../../utils/DefineUtils';
import { FullscreenPanel } from './../BasePanel';
import DungeonMap from '../../component/Dungeon/DungeonMap';
import commonUtils from '../../../utils/CommonUtils';
import loadUtils from '../../../utils/LoadUtils';
import dungeonLogic, { DungeonEvent, DungeonEventId } from '../../../logics/DungeonLogic';
import EManager from '../../../manager/EventManager';
import gm from '../../../manager/GameManager';
import { stringConfigMap } from '../../../configs/stringConfig';
import stringUtils from '../../../utils/StringUtils';
import storageUtils from '../../../utils/StorageUtils';
import guideLogic from '../../../logics/GuideLogic';
import StoryComponent, { StoryWhere } from '../../widget/story/StoryComponent';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/dungeon/DungeonMapPanel")
export default class DungeonMapPanel extends FullscreenPanel {
    @property(DungeonMap)
    map: DungeonMap = null;

    @property(cc.Label)
    labelLayer: cc.Label = null;

    @property(cc.Label)
    labelSavePoint: cc.Label = null;

    @property(cc.ProgressBar)
    progressSave: cc.ProgressBar = null;

    @property(cc.Animation)
    cloud: cc.Animation = null;

    @property(sp.Skeleton)
    npcSkeleton: sp.Skeleton = null;

    @property(sp.Skeleton)
    bgSkeleton: sp.Skeleton = null;

    @property(cc.Node)
    nodeIco: cc.Node = null;

    @property(cc.Sprite)
    spriteIco: cc.Sprite = null;

    @property(cc.Node)
    flyEffect: cc.Node = null;

    @property(cc.Node)
    btnHero: cc.Node = null;

    @property(cc.Node)
    btnFruit: cc.Node = null;

    @property(cc.Widget)
    buttons: cc.Widget = null;

    protected _loadedHeroSkeletonData: sp.SkeletonData = null;
    protected _loadedMonsterSkeletonData: sp.SkeletonData = null;

    protected _skeletonUrl: string = "";
    protected _progressTween: cc.Tween = null;

    onInit(skeletonData: sp.SkeletonData) {
        this._loadedHeroSkeletonData = skeletonData;
    }

    onLoad() {
        super.onLoad();

        this.progressSave.node.active = false;
        this.cloud.node.active = false;
        this.flyEffect.parent = null;

        let listener = EManager.addEvent(DungeonEvent.Event.onNextMission, (needSave: boolean) => {
            this.cloud.node.active = true;
            this.cloud.off("finished");
            this.cloud.on("finished", async () => {
                if (this.cloud.currentClip.name == "Dungeon_map_ICloud1") {
                    this.cloud.node.active = false;
                }
                else {
                    await this._onNextMission(needSave);
                    this.cloud.play("Dungeon_map_ICloud1");
                }
            });
            this.cloud.play("Dungeon_map_ICloud2");
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType }) => {
            if (data.type != BattleType.Dungeon)
                return;
            let events = dungeonLogic.events;
            for (let event of events) {
                if (event.id == DungeonEventId.Monster && !event.valid) {
                    if (dungeonLogic.battleData.id == dungeonLogic.getLimitLevel()) {
                        gcc.core.showLayer("prefabs/panel/dungeon/DungeonPassedPanel");
                    }
                    break;
                }
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(DungeonEvent.Event.onSelectAssistHeroes, () => {
            let effect = cc.instantiate(this.flyEffect);
            effect.parent = this.node;
            let animation = effect.getComponent(cc.Animation);
            animation.play("Fly_icon_effect1");
            animation.on("finished", () => { effect.destroy(); }, this);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(DungeonEvent.Event.onSelectFruits, () => {
            let effect = cc.instantiate(this.flyEffect);
            effect.parent = this.node;
            let animation = effect.getComponent(cc.Animation);
            animation.play("Fly_icon_effect2");
            animation.on("finished", () => { effect.destroy(); }, this);
        });
        this._eventListeners.push(listener);
    }

    onDestroy() {
        super.onDestroy();

        if (this._progressTween) {
            this._progressTween.stop();
        }
    }

    start() {
        super.start();
        this._updateLayerInfo();

        if (!storageUtils.getBoolean(Storage.DungeonGuide)) {
            let events = dungeonLogic.events.filter((e: DungeonEvent) => { return e.id == DungeonEventId.Assist && e.canTrigger });
            if (events.length > 0) {
                guideLogic.guideId = 110003;
            }
            else {
                guideLogic.guideId = 110004;
            }
        }

        this.buttons.updateAlignment();
        let positions = [
            this.node.convertToNodeSpaceAR(this.btnHero.convertToWorldSpaceAR(cc.v2())),
            this.node.convertToNodeSpaceAR(this.btnFruit.convertToWorldSpaceAR(cc.v2()))
        ];

        let animation = this.flyEffect.getComponent(cc.Animation);
        let clips = animation.getClips();
        for (let i = 0; i < clips.length; i++) {
            let clip = clips[i];
            let paths = clip.curveData.paths;
            for (let key in paths) {
                let path = paths[key];
                if (path.props.position) {
                    let frame = path.props.position[path.props.position.length - 1];
                    frame.value[0] = positions[i].x;
                    frame.value[1] = positions[i].y;
                }
            }
        }
    }

    onBag() {
        if (dungeonLogic.fruitIds.length == 0) {
            gm.toast(stringConfigMap.key_empty_bag.Value);
            return;
        }
        gcc.core.showLayer("prefabs/panel/dungeon/DungeonBagPanel", { modalTouch: true });
    }

    onHero() {
        gcc.core.showLayer("prefabs/panel/dungeon/DungeonHeroPanel");
    }

    onHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "dungeon" } });
    }

    onRank() {
        gm.toast(stringConfigMap.key_developing.Value);
    }

    onSwitch() {
        this.map.stopMove();

        this.cloud.node.active = true;
        this.cloud.off("finished");
        this.cloud.on("finished", async () => {
            if (this.cloud.currentClip.name == "Dungeon_map_ICloud1") {
                this.cloud.node.active = false;
            }
            else {
                try {
                    await dungeonLogic.doSwitchBattleHero();
                    await this._onNextMission(false);
                } catch (e) {
                    if (e.name == "ToastError") {
                        gm.toast(e.message);
                    }
                    else {
                        throw e;
                    }
                }
                this.cloud.play("Dungeon_map_ICloud1");
            }
        });
        this.cloud.play("Dungeon_map_ICloud2");
    }

    protected _updateLayerInfo() {
        this.labelLayer.string = stringUtils.getString(stringConfigMap.key_layer_no.Value, { count: dungeonLogic.battleData.levelId % 1000 });

        let config = dungeonLogic.nextSaveConfig;
        if (config && config.ID < dungeonLogic.getLimitLevel()) {
            this.labelSavePoint.node.active = true;
            this.labelSavePoint.string = stringUtils.getString(stringConfigMap.key_next_save_point.Value, { level: config.ID + 1 });
        }
        else {
            this.labelSavePoint.node.active = false;
        }

        for (let hero of dungeonLogic.battleHeroes) {
            if (hero != dungeonLogic.battleHero) {
                this.nodeIco.active = true;
                this.spriteIco.spriteFrame = cc.loader.getRes(commonUtils.getHeroIconUrl(hero.getIndex()), cc.SpriteFrame);
                return;
            }
        }
        this.nodeIco.active = false;
    }

    protected async _onNextMission(needSave: boolean) {
        let url = dungeonLogic.getSkeletonUrl(dungeonLogic.battleHero.getIndex());
        if (this._skeletonUrl != url) {
            let lastSkeletonData = this.bgSkeleton.skeletonData;
            let skeletonData = await loadUtils.loadRes(url, sp.SkeletonData) as sp.SkeletonData;
            this.bgSkeleton.skeletonData = skeletonData;
            this.bgSkeleton.animation = "idle";
            this.bgSkeleton.loop = true;
            this._skeletonUrl = url;

            loadUtils.releaseAssetRecursively(lastSkeletonData);
        }

        this._updateLayerInfo();

        this.progressSave.node.active = needSave;
        if (needSave) {
            this.progressSave.progress = 0;
            if (this._progressTween) { this._progressTween.stop() }
            this._progressTween = cc.tween(this.progressSave).to(4, { progress: 1 }).call(() => {
                this.progressSave.node.active = false;
            }).start();

            let comp = this.getComponent(StoryComponent);
            if (!comp) { comp = this.addComponent(StoryComponent); }
            comp.init(1000, StoryWhere.DungeonSave);
            comp.startStory();
        }

        let monster = dungeonLogic.battleData.getLeader();
        url = commonUtils.getHeroSpineUrl(monster.getSpineFile());
        let monsterSkeletonData = cc.loader.getRes(url, sp.SkeletonData);
        if (!monsterSkeletonData) {
            monsterSkeletonData = await loadUtils.loadRes(url, sp.SkeletonData) as sp.SkeletonData;
            monsterSkeletonData.lock();
        }
        if (monsterSkeletonData != this._loadedMonsterSkeletonData && this._loadedMonsterSkeletonData != this._loadedHeroSkeletonData) {
            this._loadedMonsterSkeletonData.unlock();
            loadUtils.releaseAssetRecursively(this._loadedMonsterSkeletonData);
        }
        this._loadedMonsterSkeletonData = monsterSkeletonData;

        url = commonUtils.getHeroSpineUrl(dungeonLogic.battleHero.getSpineFile());
        let heroSkeletonData = cc.loader.getRes(url, sp.SkeletonData);
        if (!heroSkeletonData) {
            heroSkeletonData = await loadUtils.loadRes(url, sp.SkeletonData) as sp.SkeletonData;
            heroSkeletonData.lock();
        }
        if (heroSkeletonData != this._loadedHeroSkeletonData && this._loadedMonsterSkeletonData != this._loadedHeroSkeletonData) {
            this._loadedHeroSkeletonData.unlock();
            loadUtils.releaseAssetRecursively(this._loadedHeroSkeletonData);
        }
        this._loadedHeroSkeletonData = heroSkeletonData;

        if (!this._loadedHeroSkeletonData.isLock()) { this._loadedHeroSkeletonData.lock(); }
        if (!this._loadedMonsterSkeletonData.isLock()) { this._loadedMonsterSkeletonData.lock(); }
        this.map.init(this._loadedHeroSkeletonData, this._loadedMonsterSkeletonData);
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this.npcSkeleton.skeletonData.lock();

        let url = dungeonLogic.getSkeletonUrl(dungeonLogic.battleHero.getIndex());
        let skeletonData = cc.loader.getRes(url, sp.SkeletonData);
        if (!skeletonData) {
            skeletonData = await loadUtils.loadRes(url, sp.SkeletonData) as sp.SkeletonData;
        }
        this.bgSkeleton.skeletonData = skeletonData;
        this.bgSkeleton.animation = "idle";
        this.bgSkeleton.loop = true;
        this._skeletonUrl = url;

        let monster = dungeonLogic.battleData.getLeader();
        url = commonUtils.getHeroSpineUrl(monster.getSpineFile());
        let monsterSkeletonData = cc.loader.getRes(url, sp.SkeletonData);
        if (!monsterSkeletonData) {
            monsterSkeletonData = await loadUtils.loadRes(url, sp.SkeletonData) as sp.SkeletonData;
        }
        this._loadedMonsterSkeletonData = monsterSkeletonData;

        let heroSkeletonData = this._loadedHeroSkeletonData;
        if (!heroSkeletonData) {
            let hero = dungeonLogic.battleHero;
            let url = commonUtils.getHeroSpineUrl(hero.getSpineFile());
            heroSkeletonData = cc.loader.getRes(url, sp.SkeletonData);
            if (!heroSkeletonData) {
                heroSkeletonData = await loadUtils.loadRes(url, sp.SkeletonData) as sp.SkeletonData;
            }
        }
        this._loadedHeroSkeletonData = heroSkeletonData;

        this._loadedHeroSkeletonData.lock();
        this._loadedMonsterSkeletonData.lock();
        this.map.init(heroSkeletonData, monsterSkeletonData);
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);

        if (this._loadedHeroSkeletonData) {
            this._loadedHeroSkeletonData.unlock();
            loadUtils.releaseAssetRecursively(this._loadedHeroSkeletonData);
            this._loadedHeroSkeletonData = null;
        }

        if (this._loadedMonsterSkeletonData) {
            this._loadedMonsterSkeletonData.unlock();
            loadUtils.releaseAssetRecursively(this._loadedMonsterSkeletonData);
            this._loadedMonsterSkeletonData = null;
        }

        this.npcSkeleton.skeletonData.unlock();
        loadUtils.releaseAssetRecursively(this.npcSkeleton.skeletonData);
        loadUtils.releaseAssetRecursively(this.bgSkeleton.skeletonData);
    }
}
