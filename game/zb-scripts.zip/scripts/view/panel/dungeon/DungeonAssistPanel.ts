import { DungeonAssistHero, DungeonEvent } from './../../../logics/DungeonLogic';
import { stringConfigMap } from './../../../configs/stringConfig';
import { HeroSelect } from './../../widget/hero/HeroSelectItem';
import { PopupPanel } from "../BasePanel";
import dungeonLogic, { DungeonAssistEvent } from "../../../logics/DungeonLogic";
import DungeonAssistSelectItem from "../../component/Dungeon/DungeonAssistSelectItem";
import stringUtils from '../../../utils/StringUtils';
import DungeonAssistSlotItem from '../../component/Dungeon/DungeonAssistSlotItem';
import gm from '../../../manager/GameManager';
import cm from '../../../manager/ConfigManager';
import EManager from '../../../manager/EventManager';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/dungeon/DungeonAssistPanel")
export default class DungeonAssistPanel extends PopupPanel {
    @property(cc.Node)
    assistHeroContent: cc.Node = null;

    @property(cc.Node)
    assistSlotContent: cc.Node = null;

    @property(cc.Node)
    assistHeroTemplate: cc.Node = null;

    @property(cc.Node)
    assistSlotTemplate: cc.Node = null;

    @property(cc.Label)
    labelRefreshCost: cc.Label = null;

    protected _event: DungeonAssistEvent = null;
    protected _callback: Function = null;

    onInit(data: { event: DungeonAssistEvent, callback: () => void }) {
        this._event = data.event;
        this._callback = data.callback;
    }

    onLoad() {
        super.onLoad();
        this.assistHeroTemplate.parent = null;
        this.assistSlotTemplate.parent = null;
    }

    onEnable() {
        super.onEnable();
        EManager.emit(DungeonEvent.Event.onShowAssist);
    }

    start() {
        super.start();

        this._updateRefreshCost();

        let heroes = this._event.heroes;
        for (let hero of heroes) {
            let item = cc.instantiate(this.assistHeroTemplate);

            let comp = item.getComponent(DungeonAssistSelectItem);
            comp.init(hero, false);
            comp.checkLockCallback = this._checkSelectItemLock.bind(this);

            let onToggleSelect = comp.onToggleSelect;
            comp.onToggleSelect = () => {
                onToggleSelect.call(comp);
                for (let child of this.assistSlotContent.children) {
                    let item = child.getComponent(DungeonAssistSlotItem);
                    if (comp.heroSelect.isSelect) {
                        if (!item.selectHero) {
                            item.selectHero = comp.heroSelect.hero as DungeonAssistHero;
                            break;
                        }
                    }
                    else {
                        if (item.selectHero == comp.heroSelect.hero) {
                            item.selectHero = null;
                            break;
                        }
                    }
                }
            }

            item.parent = this.assistHeroContent;
        }

        for (let i = 0; i < dungeonLogic.maxAssistSelectCount; i++) {
            let item = cc.instantiate(this.assistSlotTemplate);
            item.parent = this.assistSlotContent;
        }
    }

    async onRefresh() {
        let costs = cm.dungeonRefreshCost;
        let cost = costs[Math.min(dungeonLogic.refreshCount, costs.length - 1)];
        gm.dialog({
            content: stringUtils.getString(stringConfigMap.key_dungeon_refresh_hero_confirm.Value, { count: cost }),
            confirm: async () => {
                try {
                    await dungeonLogic.doRefreshAssistHero();
                    this._updateRefreshCost();

                    for (let child of this.assistSlotContent.children) {
                        let item = child.getComponent(DungeonAssistSlotItem);
                        item.selectHero = null;
                    }

                    let heroes = this._event.heroes;
                    let count = Math.min(heroes.length, this.assistHeroContent.childrenCount);
                    for (let i = 0; i < count; i++) {
                        let child = this.assistHeroContent.children[i];
                        let hero = heroes[i];
                        let item = child.getComponent(DungeonAssistSelectItem);
                        item.init(hero, false);
                    }
                } catch (e) {
                    if (e.name == "ToastError") {
                        gm.toast(e.message);
                    }
                    else {
                        throw e;
                    }
                }
            }
        });
    }

    async onConfirm() {
        try {
            let heroes: DungeonAssistHero[] = [];
            for (let child of this.assistSlotContent.children) {
                let item = child.getComponent(DungeonAssistSlotItem);
                if (item.selectHero) {
                    heroes.push(item.selectHero);
                }
            }
            if (heroes.length < dungeonLogic.maxAssistSelectCount) {
                gm.toast(stringUtils.getString(stringConfigMap.key_please_select_assist_hero.Value, { count: dungeonLogic.maxAssistSelectCount }));
                return;
            }
            dungeonLogic.addAssistHeroes(heroes);
            await this._event.trigger();
            this.closePanel();
            if (this._callback) this._callback();

            EManager.emit(DungeonEvent.Event.onSelectAssistHeroes);

        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    protected _updateRefreshCost() {
        let costs = cm.dungeonRefreshCost;
        let cost = costs[Math.min(dungeonLogic.refreshCount, costs.length - 1)];
        this.labelRefreshCost.string = cost.toString();
    }

    protected _checkSelectItemLock(heroSelect: HeroSelect): { result: boolean, message?: string } {
        if (heroSelect.isSelect) {
            return { result: true }
        }

        let selectCount: number = 0;
        for (let child of this.assistHeroContent.children) {
            let item = child.getComponent(DungeonAssistSelectItem);
            if (item.heroSelect.isSelect) selectCount++;
        }
        if (selectCount >= dungeonLogic.maxAssistSelectCount) {
            return {
                result: false,
                message: stringUtils.getString(stringConfigMap.key_assist_hero_limit.Value, { count: dungeonLogic.maxAssistSelectCount })
            }
        }
        else {
            return { result: true }
        }
    }
}
