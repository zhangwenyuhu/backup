import { DungeonBattleData } from './../../../logics/DungeonLogic';
import BattleWinPanel from "../battle/BattleWinPanel";
import IBattleData from '../../../data/IBattleData';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/dungeon/DungeonWinPanel")
export default class DungeonWinPanel extends BattleWinPanel {
    @property({
        override: true,
        visible: false,
        type: cc.Node
    })
    btnNext: cc.Node = null;

    @property({
        override: true,
        visible: false,
        type: cc.Node
    })
    btnClaim: cc.Node = null;

    @property({
        override: true,
        visible: false,
        type: cc.Node
    })
    assignment: cc.Node = null;

    @property({
        override: true,
        visible: false,
        type: cc.Node
    })
    fightHistory: cc.Node = null;

    @property({
        override: true,
        visible: false,
        type: cc.Node
    })
    targetList: cc.Node = null;

    @property({
        override: true,
        visible: false,
        type: cc.Node
    })
    targetTemplate: cc.Node = null;

    @property(cc.Node)
    titleArea: cc.Node = null;

    @property(cc.Node)
    mvpArea: cc.Node = null;

    @property(cc.Node)
    rewardTitle: cc.Node = null;

    @property(cc.Node)
    geniusTitle: cc.Node = null;

    @property(cc.Node)
    geniusList: cc.Node = null;

    @property(cc.Node)
    geniusTemplate: cc.Node = null;

    @property(cc.SpriteFrame)
    geniusFrames: cc.SpriteFrame[] = [];

    onInit(data: {
        battleData: IBattleData,
        skills: any,
        contribution?: rpgfight.HeroContributionStatistic[]
    }) {
        this._battleData = data.battleData;
    }

    onLoad() {
        super.onLoad();
        this.geniusTemplate.parent = null;
    }

    async start() {
        await super.start();

        if (this.rewardList.childrenCount > 0) {
            let battleData = this._battleData as DungeonBattleData;
            for (let i = 0; i < battleData.geniusPoints.length; i++) {
                if (battleData.geniusPoints[i] > 0) {
                    let item = cc.instantiate(this.geniusTemplate);
                    item.parent = this.geniusList;

                    let ico = item.getChildByName("ico");
                    ico.getComponent(cc.Sprite).spriteFrame = this.geniusFrames[i];
                    let label = item.getChildByName("label");
                    label.getComponent(cc.Label).string = `+${battleData.geniusPoints[i]}`;
                }
            }
        }
        else {
            this.titleArea.y -= 90;
            this.mvpArea.y -= 90;
            this.geniusTitle.active = false;
            this.geniusList.active = false;
            this.rewardTitle.active = false;
            this.rewardList.active = false;
        }
    }
}
