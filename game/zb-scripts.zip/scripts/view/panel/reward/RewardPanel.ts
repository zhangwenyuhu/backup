import { PopupPanel } from "../BasePanel";
import Card from "../../../data/card/Card";
import CommonLoader from "../../common/CommonLoader";
import EquipCard from "../../component/Equip/EquipCard";
import Equip from "../../../data/card/Equip";
import HeroCard from "../../component/Hero/HeroCard";
import Hero from "../../../data/card/Hero";
import GoodCard from "../../component/Good/GoodCard";
import Good from "../../../data/card/Good";
import EManager, { EName } from "../../../manager/EventManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/reward/RewardPanel")
export default class RewardPanel extends PopupPanel {

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    item: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    labelAutoSplit: cc.Node = null;

    @property(cc.Node)
    text1: cc.Node = null;

    @property(cc.Node)
    text2: cc.Node = null;

    protected _cards: Card[] = [];
    protected _callback: Function = null;

    onInit(data: { cards: Card[], autoSplit?: boolean, callback?: Function, refund?: boolean }) {
        super.onInit(data);
        this._cards = data.cards;
        this._cards.sort((a: Card, b: Card) => { return a.getRenderOrder() - b.getRenderOrder() });
        this.labelAutoSplit.active = data.autoSplit ? true : false;
        this.text1.active = !data.refund;
        this.text2.active = data.refund;
        this._callback = data.callback;
    }

    onLoad() {
        super.onLoad();
        this.heroItem.parent = null;
        this.equipItem.parent = null;
        this.goodItem.parent = null;
        this.item.parent = null;
        let bg = this.node.getChildByName("modalBg");
        bg.once(cc.Node.EventType.TOUCH_END, this.onExit, this);
    }

    start() {
        super.start();

        let item = cc.instantiate(this.item);
        for (let card of this._cards) {
            if (item.childrenCount == 4) {
                item.parent = this.content;
                item = cc.instantiate(this.item);
            }

            let node: cc.Node = null;
            if (card.getType() == Card.Type.Equip
                || card.getType() == Card.Type.Artifact) {
                node = cc.instantiate(this.equipItem);
                let loader = node.getComponent(CommonLoader);
                let comp = loader.loaderNode.getComponent(EquipCard);
                comp.refresh({ equip: card as Equip });
            }
            else if (card.getType() == Card.Type.Hero) {
                node = cc.instantiate(this.heroItem);
                let loader = node.getComponent(CommonLoader);
                let comp = loader.loaderNode.getComponent(HeroCard);
                comp.refresh(card as Hero);
            }
            else if (card.getType() == Card.Type.Good) {
                node = cc.instantiate(this.goodItem);
                let loader = node.getComponent(CommonLoader);
                let comp = loader.loaderNode.getComponent(GoodCard);
                comp.refresh(card as Good);
            }
            if (node) { node.parent = item; }
        }
        if (item.childrenCount > 0) {
            item.parent = this.content;
        }
    }

    onExit() {
        EManager.emit(EName.onClosePanel, "RewardPanel");
        this.closePanel();
    }

    closePanel() {
        super.closePanel();
        if (this._callback) this._callback();
    }
}
