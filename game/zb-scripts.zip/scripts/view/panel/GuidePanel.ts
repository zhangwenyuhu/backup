const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/GuidePanel")
export default class GuidePanel extends cc.Component {
    @property(cc.Button)
    layer: cc.Button = null;

    @property(cc.Sprite)
    arrow: cc.Sprite = null;

    @property(cc.Mask)
    mask: cc.Mask = null;

    @property(cc.Node)
    circle: cc.Node = null;

    @property(cc.Node)
    finger: cc.Node = null;

    @property(cc.Node)
    dialog: cc.Node = null;

    @property(cc.Node)
    hero: cc.Node = null;

    @property(cc.RichText)
    label: cc.RichText = null;

    @property(cc.Vec2)
    fingerOffset: cc.Vec2 = cc.v2();

    clickCallback: Function = null;

    onLoad() {
        this.layer.node.zIndex = 10;
    }

    onClick() {
        if (this.clickCallback) {
            this.clickCallback();
            this.clickCallback = null;
        }
    }
}
