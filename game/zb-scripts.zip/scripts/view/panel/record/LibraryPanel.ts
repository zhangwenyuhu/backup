import BasePanel from "../BasePanel";
import EManager, { EName } from "../../../manager/EventManager";
import List from "../../common/List";
import libraryLogic from "../../../logics/LibraryLogic";
import loadUtils from "../../../utils/LoadUtils";
import commonUtils from "../../../utils/CommonUtils";
import { PromptType } from "../../../data/prompt/PromptModal";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/record/LibraryPanel")
export default class LibraryPanel extends BasePanel {

    @property(List)
    fetterList: List = null;

    onInit(data: any) {

    }

    async start() {
        super.start();

        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data === "LibraryPanel") {
                this.fetterList.numItems = libraryLogic.getFetterCount();
            }
        })
        this._eventListeners.push(listener);
        //await libraryLogic.fettersReq();
        this.fetterList.getComponent(cc.Widget).updateAlignment();
        this.fetterList.numItems = libraryLogic.getFetterCount();
        EManager.emit(EName.onRedDirty, PromptType.LibraryBtn);
    }

    onDestroy() {
        EManager.emit(EName.onRedDirty, PromptType.LibraryBtn);
        super.onDestroy();
    }

    onItemRender(item: cc.Node, index: number) {
        if (item) {
            item.getChildByName("bg").active = index % 2 == 0;

            let btn = item.getComponent(cc.Button);
            let type = index + 1
            btn.clickEvents[0].customEventData = `${type}`;

            item.getChildByName("tip").active = libraryLogic.fetterRed(type);
            let urlPre = `textures/ui/panel/record/`;
            let fact = libraryLogic.getFetterData(type).getFetterFaction();
            let url = urlPre + `camp_${fact}`;
            loadUtils.loadSpriteFrame(url, item.getChildByName("camp").getComponent(cc.Sprite));
            url = urlPre + `fetter_name_${type}`;
            loadUtils.loadSpriteFrame(url, item.getChildByName("name").getComponent(cc.Sprite));
            url = urlPre + `fetter_icon_${type}`;
            loadUtils.loadSpriteFrame(url, item.getChildByName("icon").getComponent(cc.Sprite));
        }
    }

    onClickFetter(sender: cc.Event.EventTouch, index: string) {
        let type = parseInt(index);
        let cfgs = libraryLogic.getFetterCfgs(type);
        if (cfgs.length != 0) {
            gcc.core.showLayer("prefabs/panel/record/FetterPanel", { data: { type: type } });
        }
    }

    onClickHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "library" } });
    }

    onClickMyMercHero() {
        gcc.core.showLayer("prefabs/panel/xs/HelpHeroPanel");
    }

    async _preloadRes() {
        super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("lib_bg1"), type: cc.SpriteFrame });
    }
}
