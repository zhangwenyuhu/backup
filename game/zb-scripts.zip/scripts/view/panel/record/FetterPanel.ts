import BasePanel from "../BasePanel";
import libraryLogic from "../../../logics/LibraryLogic";
import { libraryconfigRow } from "../../../configs/libraryconfig";
import loadUtils from "../../../utils/LoadUtils";
import heroUtils from "../../../utils/HeroUtils";
import cm from "../../../manager/ConfigManager";
import CommonLoader from "../../common/CommonLoader";
import HeroCard from "../../component/Hero/HeroCard";
import FetterData from "../../../data/record/FetterData";
import commonUtils from "../../../utils/CommonUtils";
import gm from "../../../manager/GameManager";
import EManager, { EName } from "../../../manager/EventManager";
import { PromptType } from "../../../data/prompt/PromptModal";
import heroLogic from "../../../logics/HeroLogic";
import List from "../../common/List";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/record/FetterPanel")
export default class FetterPanel extends BasePanel {

    @property(cc.Node)
    title: cc.Node = null;

    @property(List)
    fetterList: List = null;

    @property(cc.Node)
    star: cc.Node = null;

    @property(cc.Node)
    buffLabel: cc.Node = null;

    @property(cc.Node)
    heroModels: cc.Node[] = [];

    @property(cc.Node)
    modelBg: cc.Node = null;

    @property(cc.Node)
    modelTip: cc.Node = null;

    @property(cc.Node)
    modelTip1: cc.Node = null;

    @property(cc.Material)
    normalMaterial: cc.Material = null;

    @property(cc.Material)
    grayMaterial: cc.Material = null;

    private _type: number = 0;
    private _fetterInfo: FetterData = null;

    // 正常 绿色 灰色
    private _fetterColors: string[] = ['#8D9BB5', '##5DDA37', '#46526A'];
    onInit(data: any) {
        this._type = data.type;
        this._fetterInfo = libraryLogic.getFetterData(this._type);
    }

    start() {
        super.start();

        this.freshHeroModel();
        this.freshFetterDetail();
    }

    onLoad() {
        super.onLoad();

        this.star.parent = null;
        this.buffLabel.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        EManager.emit(EName.onFreshPanel, "LibraryPanel");
        this.star.destroy();
        this.buffLabel.destroy();
    }

    // 中间羁绊英雄形象和位置
    private freshHeroModel() {
        let cfg = this._fetterInfo.getCfg();
        let heros = cfg.hero;
        this.heroModels.forEach((v, i, a) => {
            if (heros[i]) {
                let url = commonUtils.getHeroBigUrl(heros[i]);
                let sprite = v.getComponent(cc.Sprite);
                sprite.spriteFrame = cc.loader.getRes(url, cc.SpriteFrame);

                v.position = cc.v2(cfg.Pos[i][0], cfg.Pos[i][1]);
                v.zIndex += cfg.Pos[i][2];
                v.scaleX = cfg.Scale;
                v.scaleY = cfg.Scale;
                if (cfg.Pos[i][3] == 1) {
                    v.scaleX = -1 * v.scaleX;
                }

                let bottomBg = v.parent.getChildByName(`fetter_yinying${i + 1}`);
                if (bottomBg) {
                    bottomBg.position = cc.v2(cfg.Pos[i][0], cfg.Pos[i][1] - 10);
                    bottomBg.active = true;
                }

                if (this._fetterInfo.isFetterHeroActive()) {
                    sprite.setMaterial(0, this.normalMaterial);
                } else {
                    sprite.setMaterial(0, this.grayMaterial);
                }

            }
        })

        let urlPre = `textures/bg/fetter_bg_`
        let bgUrl: string = urlPre + this._fetterInfo.getFetterFaction();
        loadUtils.loadSpriteFrame(bgUrl, this.modelBg.getComponent(cc.Sprite));

        this.modelTip.active = this._type == 6;
        this.modelTip1.active = this._type == 7;
    }

    // 底部羁绊激活项信息
    private freshFetterDetail() {

        this.fetterList.getComponent(cc.Widget).updateAlignment();
        this.fetterList.numItems = this._fetterInfo.getCfgs().length;
    }

    // 单项羁绊信息内容
    protected onItemRender(node: cc.Node, index: number) {
        let data = this._fetterInfo.getCfgs()[index];
        let upNode = node.getChildByName('up');
        let isActive: boolean = libraryLogic.isFetterActive(data.jibanID);

        let flag = isActive ? 2 : 1;
        let url = `textures/ui/panel/record/fetter_${flag}`;
        loadUtils.loadSpriteFrame(url, upNode.getChildByName("flag").getComponent(cc.Sprite));
        // 羁绊描述
        let desc = upNode.getChildByName('desc1').getComponent(cc.Label);
        desc.string = this._fetterInfo.getDesc(data.jibanID);
        let color = isActive ? cc.color(93, 218, 55) : cc.color(141, 151, 181);
        desc.node.color = color;
        upNode.getChildByName('desc2').color = color;
        // 激活需要星级
        let star = upNode.getChildByName('star');
        star.destroyAllChildren();
        for (let i = 0; i < data.star; i++) {
            let tmp = cc.instantiate(this.star);
            tmp.parent = star;
        }
        // 羁绊buff内容
        let buff = node.getChildByName('down');
        buff.destroyAllChildren();
        let buffs = libraryLogic.getFetterAddStr(data);
        for (let j = 0; j < buffs.length; j++) {
            let temp = cc.instantiate(this.buffLabel);
            temp.parent = buff;
            temp.getComponent(cc.Label).string = buffs[j];
            let color = isActive ? cc.color(93, 218, 55) : cc.color(70, 82, 106);
            temp.color = color;
        }
        // 激活按钮
        let btn = node.getChildByName('btnActive');
        btn.active = this._fetterInfo.canFetterActive(data.jibanID);
        if (btn.active) {
            //btn.getComponent(cc.Button).clickEvents[0].customEventData = `${data.jibanID}`;
            btn.off('click');
            btn.on('click', () => {
                let effect = node.getChildByName("guangxiao");
                effect.getComponent(cc.Animation).play("jibanshuxingjihuo", 0);

                this.onClickActiveFetter(null, `${data.jibanID}`);
            })
        }
    }

    protected onClickActiveFetter(sender: cc.Event.EventTouch, custom: string) {
        let fetterId: number = parseInt(custom);
        this.doActiveFetter(fetterId);
    }

    protected async doActiveFetter(fetterId: number) {
        try {
            let needRefreshModal = !this._fetterInfo.isFetterHeroActive();

            await libraryLogic.activeFetterReq(fetterId);
            this.freshFetterDetail();
            if (needRefreshModal) { this.freshHeroModel(); }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }

    }

    async _preloadRes() {
        await super._preloadRes();

        let urlPre = `textures/bg/fetter_bg_`
        let bgUrl: string = urlPre + this._fetterInfo.getFetterFaction();
        await loadUtils.loadRes(bgUrl, cc.SpriteFrame);
        this._unloadInfos.push({ url: bgUrl, type: cc.SpriteFrame });
    }
}
