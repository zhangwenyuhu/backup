import BasePanel from "../BasePanel";
import List from "../../common/List";
import Hero from "../../../data/card/Hero";
import libraryLogic from "../../../logics/LibraryLogic";
import CommonLoader from "../../common/CommonLoader";
import HeroCard from "../../component/Hero/HeroCard";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/record/FetterHeroSetPanel")
export default class FetterHeroSetPanel extends BasePanel {

    @property(List)
    heroList: List = null;

    protected _cfgId: number = 0;
    protected _heros: Hero[] = [];
    protected _callback: Function = null;
    protected _selectHeroId: string = "";
    onInit(data: any) {
        this._cfgId = data.cfgId;
        this._callback = data.callback;
        this._selectHeroId = data.selectHeroId;
    }

    start() {
        super.start();

        let tmp = libraryLogic.getUsefullFetterHeros(this._cfgId);
        this._heros = tmp.sort((a,b)=>{ return b.getRank()-a.getRank();})
        this.heroList.getComponent(cc.Widget).updateAlignment();
        this.heroList.numItems = this._heros.length;
    }

    onDestroy() {

        super.onDestroy();
    }

    onItemRender(item: cc.Node, index: number) {
        if (item) {
            let data = this._heros[index];

            let select = this._selectHeroId == data.getId()
            item.getChildByName("flag").active = select;

            let hero = item.getChildByName("hero").getComponent(CommonLoader);
            hero.loaderNode.getComponent(HeroCard).refresh(data);
            hero.loaderNode.getComponent(HeroCard).showMask(select);
            hero.loaderNode.getComponent(HeroCard).hideLevel();

            item.getChildByName("name").getComponent(cc.Label).string = libraryLogic.getOwerUsefullHeroName(data.getId());
            let btn = item.getChildByName("btn").getComponent(cc.Button);
            btn.clickEvents[0].customEventData = `${data.getId()}`;

        }
    }

    onClickSelect(sender: cc.Event.EventTouch, index: string) {
        this._selectHeroId = index;
        this.heroList.updateAll();
    }

    onClickSet() {
        this.closePanel();

        if (this._selectHeroId && this._selectHeroId != "") {
            if (this._callback) {
                this._callback(this._selectHeroId);
            }
        }
    }
}
