import { PopupPanel } from "../BasePanel";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/mail/MailDeletePanel")
export default class MailDeletePanel extends PopupPanel {

    @property(cc.Label)
    title: cc.Label = null;

    @property(cc.Label)
    content: cc.Label = null;

    onInit(data: {
        confirmFunc: () => {}
    }) {

    }

    onConfirm() {
        this.data.confirmFunc && this.data.confirmFunc();
        this.closePanel();
    }

}
