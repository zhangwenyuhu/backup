import { PopupPanel } from "../BasePanel";
import Mail from "../../../data/card/Mail";
import mailLogic from "../../../logics/MailLogic";
import gm from "../../../manager/GameManager";
import EManager from "../../../manager/EventManager";
import { RewardBO } from "../../../proxy/GameProxy";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/mail/MailDetailPanel")
export default class MailDetailPanel extends PopupPanel {

    @property(cc.Label)
    title: cc.Label = null;

    @property(cc.Node)
    scrollView: cc.Node = null;

    @property(cc.RichText)
    content: cc.RichText = null;

    @property(cc.Label)
    from: cc.Label = null;

    @property(cc.Node)
    reward_bg: cc.Node = null;

    @property(cc.Node)
    mail_good: cc.Node = null;

    @property(cc.Node)
    mail_hero: cc.Node = null;

    @property(cc.Node)
    mail_equip: cc.Node = null;

    @property(cc.Node)
    confirm_text1: cc.Node = null;

    @property(cc.Node)
    confirm_text2: cc.Node = null;

    @property(cc.Button)
    confirmBtn: cc.Button = null;

    @property(cc.Node)
    rewardScrollView: cc.Node = null;

    onLoad() {
        super.onLoad();
        this.mail_good.parent = null;
        this.mail_hero.parent = null;
        this.mail_equip.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        this.mail_good.destroy();
        this.mail_hero.destroy();
        this.mail_equip.destroy();
    }

    start() {
        super.start();

        this.title.string = this.data.mail.getTitle();
        this.content.string = this.data.mail.getContent();
        this.from.string = this.data.mail.getFrom();
        if (this.data.mail.hasReward() && !this.data.mail.getRewardGot()) {
            this.confirm_text1.active = true;
            this.confirm_text2.active = false;
            this.confirmBtn.interactable = true;
        } else {
            this.confirm_text1.active = false;
            if (this.data.mail.hasReward()) {
                this.confirm_text2.active = true;
            } else {
                this.confirm_text2.parent.active = false;
            }
            this.confirmBtn.interactable = false;
        }

        this.rewardScrollView.active = this.data.mail.hasReward();
        if (this.data.mail.hasReward()) {
            for (let i = 0; i < this.data.mail.getReward().length; i++) {
                this._addNodeByType(this.data.mail.getReward()[i]);
            }
        }
        else {
            let widget = this.scrollView.getComponent(cc.Widget);
            widget.bottom = 130;
            widget.updateAlignment();

            widget = this.from.getComponent(cc.Widget);
            widget.bottom = 58;
            widget.updateAlignment();
        }

        if (this.from.string.length == 0) {
            let widget = this.scrollView.getComponent(cc.Widget);
            widget.bottom -= 45;
            widget.updateAlignment();
        }

        let rewardBg = this.rewardScrollView.parent.getChildByName("mail_receive_bg");
        if (rewardBg) { rewardBg.active = this.rewardScrollView.active; }
    }

    protected _addNodeByType(reward: RewardBO) {
        let item = [];
        item.push(reward.propId);
        item.push(reward.amt);
        gm.showGoodItem(item, { goodItem: this.mail_good, heroItem: this.mail_hero, equipItem: this.mail_equip }, this.reward_bg);
    }

    async onReceive() {
        if (this.data.mail.getReward().length > 0 && !this.data.mail.getRewardGot()) {
            try {
                await mailLogic.doReceive(this.data.mail.getId());
                EManager.emit(Mail.Event.onRead);
                this.closePanel();
            } catch (e) {
                if (e.name == "ToastError") {
                    gm.toast(e.message);
                } else {
                    throw e;
                }
            }
        } else {
            this.onDetailClose();
        }
    }

    async onDetailClose() {
        if (!this.data.mail.getRead() && !this.data.mail.hasReward()) {
            try {
                await mailLogic.doSetRead(this.data.mail.getId());
                EManager.emit(Mail.Event.onRead);
                this.closePanel();
            } catch (e) {
                if (e.name == "ToastError") {
                    gm.toast(e.message);
                } else {
                    throw e;
                }
            }
        } else {
            this.closePanel();
        }
    }

}
