import { PopupPanel } from "../BasePanel";
import GameProxy, { MailVO } from "../../../proxy/GameProxy";
import gm from "../../../manager/GameManager";
import mailLogic from "../../../logics/MailLogic";
import EManager from "../../../manager/EventManager";
import Mail from "../../../data/card/Mail";
import List from "../../common/List";
import MailInfoItem from "../../component/Mail/MailInfoItem";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/mail/MailPanel")
export default class MailPanel extends PopupPanel {

    @property(List)
    mailList: List = null;

    @property(cc.Node)
    nomail: cc.Node = null;

    @property(cc.Button)
    deleteBtn: cc.Button = null;

    @property(cc.Button)
    receiveBtn: cc.Button = null;

    protected _mails: Mail[] = [];

    onInit(data: any) {

    }

    onLoad() {
        super.onLoad();
        this.registerEvents();
    }

    start() {
        super.start();
        this.showMailList();
    }

    registerEvents() {
        let listener = EManager.addEvent(Mail.Event.onRead, () => {
            this.refreshScroll();
        });
        this._eventListeners.push(listener);
    }

    async showMailList() {
        let mailProto = await gm.request<MailVO[]>(GameProxy.apimaillist);
        mailLogic.init(mailProto, gm);
        this.refreshScroll();
        mailLogic.setRedPoint();
    }

    refreshScroll() {
        this._mails = mailLogic.getMails();
        this.nomail.active = this._mails.length == 0;
        this.deleteBtn.interactable = this._mails.length > 0;
        this.receiveBtn.interactable = this._mails.length > 0;
        this.mailList.numItems = this._mails.length;
    }

    onItemRender(item: cc.Node, index: number) {
        let comp = item.getComponent(MailInfoItem);
        comp.refresh(this._mails[index]);
    }

    onDeleteAll() {
        gcc.core.showLayer("prefabs/panel/mail/MailDeletePanel", {
            data: {
                confirmFunc: () => {
                    this._deleteAllRead();
                }
            }
        });
    }

    protected async _deleteAllRead() {
        try {
            await mailLogic.doDeleteAll();
            this.refreshScroll();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    async onReceiveAll() {
        try {
            await mailLogic.doReceiveAll();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

}
