import { PopupPanel } from "../BasePanel";
import PopBg from "../../component/PopBg";
import CommonLoader from "../../common/CommonLoader";
import { stringConfigMap } from "../../../configs/stringConfig";
import VideoBtn from "../../../gleecomponent/VideoBtn";
import { VideoKey } from "../../../utils/DefineUtils";
import unionLogic from "../../../logics/UnionLogic";
import videoAdLogic, { AD_TYPE } from "../../../logics/VideoAdLogic";

const { ccclass, property, menu } = cc._decorator;
// 雕像视频铸造窗口
@ccclass
@menu("view/panel/union/PartVideoPanel")
export default class PartVideoPanel extends PopupPanel {

    @property(CommonLoader)
    dialog: CommonLoader = null;

    @property(cc.Node)
    buffValue: cc.Node = null;

    @property(cc.Node)
    btnVideo: cc.Node = null;

    success: Function = null;
    part:number = 0;

    onInit(data: { part: number, success: Function }) {
        super.onInit(data);

        this.success = data.success;
        this.part = data.part;

        let buff:number=unionLogic.getUnion().statue.getPartVideoBuff(this.part);
        this.buffValue.getComponent(cc.Label).string=`${buff}%`;
    }

    start() {
        super.start();

        let comp = this.dialog.loaderNode.getComponent(PopBg);
        comp.closeCallback = () => { this.closePanel() };

        this.btnVideo.active = true;
        if (this.btnVideo.active) {
            let videoNode = this.btnVideo.getComponent(CommonLoader).loaderNode;

            videoNode.getComponent(VideoBtn).videoText = "观看";
            videoNode.getComponent(VideoBtn).eventName = VideoKey.StatuePart;
            videoNode.getComponent(VideoBtn).onSuccessFunc = () => {
                if (this.success) {
                    this.success(true);
                    this.closePanel();
                    videoAdLogic.videoPlayTimesCount(AD_TYPE.ZhuanPan+this.part);
                }
            }
        }
    }

    onReset() {

        if (this.success) this.success();
        this.closePanel();
    }
}
