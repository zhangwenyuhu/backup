import { stringConfigMap } from './../../../configs/stringConfig';
import { UnionPermission } from './../../../logics/UnionLogic';
import { FullscreenPanel } from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import loadUtils from "../../../utils/LoadUtils";
import gm from "../../../manager/GameManager";
import Monster from "../../../data/card/Monster";
import { defaultConfigMap } from "../../../configs/defaultConfig";
import { EquipBO, GoodVO } from "../../../proxy/GameProxy";
import Good, {GoodId} from "../../../data/card/Good";
import GoodCard from "../../component/Good/GoodCard";
import Equip from "../../../data/card/Equip";
import EquipCard from "../../component/Equip/EquipCard";
import Skill from "../../../data/card/Skill";
import UnionSkill from "../../component/Skill/UnionSkill";
import UnionHunt from "../../../data/union/UnionHunt";
import unionLogic from "../../../logics/UnionLogic";
import EManager, { EName } from "../../../manager/EventManager";
import timeUtils from "../../../utils/TimeUtils";
import promptLogic, { PromptType } from "../../../logics/PromptLogic";
import playerLogic from '../../../logics/PlayerLogic';
import cm from '../../../manager/ConfigManager';
import stringUtils from '../../../utils/StringUtils';
import rechargeLogic, { RightType } from '../../../logics/RechargeLogic';
import commonUtils from '../../../utils/CommonUtils';
import huntaddupconfig from "../../../configs/huntaddupconfig";
import bagLogic from "../../../logics/BagLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/UnionHuntPanel")
export default class UnionHuntPanel extends FullscreenPanel {

    @property(cc.Label)
    huntMonster: cc.Label = null;

    @property(cc.Node)
    timeNode: cc.Node = null;

    @property(cc.Label)
    timeLabel: cc.Label = null;

    @property(sp.Skeleton)
    heroHead: sp.Skeleton = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    goodPrefab: cc.Node = null;

    @property(cc.Node)
    equipPrefab: cc.Node = null;

    @property(cc.Node)
    cupIcon: cc.Node = null;

    @property(cc.Label)
    cupCost: cc.Label = null;

    @property(cc.Label)
    lastCnt: cc.Label = null;

    @property(cc.Button)
    challengeBtn: cc.Button = null;

    @property(cc.Label)
    btnChallengeText: cc.Label = null;

    @property(cc.Button)
    openBtn: cc.Button = null;

    @property(cc.Label)
    btnOpenText: cc.Label = null;

    @property(cc.Node)
    nextBtn: cc.Node = null;

    @property(cc.Node)
    previousBtn: cc.Node = null;

    @property(cc.Node)
    challengeNode: cc.Node = null;

    @property(cc.Node)
    wipeNode: cc.Node = null;

    @property(cc.Button)
    challengeBtn2: cc.Button = null;

    @property(cc.Button)
    wipeBtn: cc.Button = null;

    @property(cc.Node)
    wipEffect: cc.Node = null;

    @property({
        type: cc.SpriteFrame
    })
    weakFrames: cc.SpriteFrame[] = [];

    @property(cc.Sprite)
    weakUnion: cc.Sprite = null;

    @property(cc.ProgressBar)
    hurtProgress: cc.ProgressBar = null;

    @property(cc.Label)
    hurtLabel: cc.Label = null;

    @property(cc.Node)
    challengeDiamondNode: cc.Node = null;

    @property(cc.Label)
    challengeDiamondLabel: cc.Label = null;

    @property(cc.Node)
    wipeDiamondNode: cc.Node = null;

    @property(cc.Label)
    wipeDiamondLabel: cc.Label = null;

    protected _lastSkeletonData: sp.SkeletonData = null;
    protected _monster: Monster = null;
    protected _monsterIndex: number = 0;
    protected _monsterList: number[] = [99001, 99002];
    protected _isGetBossInfo: boolean = false;

    onLoad() {
        super.onLoad();

        this.goodPrefab.parent = null;
        this.equipPrefab.parent = null;

        let listener = EManager.addEvent(EName.onTouch, () => {
            EManager.emit(EName.onClosePanel, "SkillGetDetailPanel");
        });
        this._eventListeners.push(listener);
    }

    onDestroy() {
        super.onDestroy();

        UnionSkill.lastUnionSkill = null;
        this.goodPrefab.destroy();
        this.equipPrefab.destroy();
    }

    async start() {
        super.start();
        this._monsterList = defaultConfigMap.huntboss.value.split(';');
        this.goodPrefab.active = this.equipPrefab.active = false;
        this._getBossInfo();

        let level = rechargeLogic.getUnlockVipLevel(RightType.AutoTeamBattle);
        if (playerLogic.getPlayer().getVipLevel() < level) {
            this.showSkipBattleTip();
        }
    }

    protected async _getBossInfo() {
        this._isGetBossInfo = false;
        await unionLogic.doGetBossInfo();
        this._isGetBossInfo = true;
        this._refreshBtn();
        this._showMonster();
    }

    onEnable() {
        super.onEnable();
        let listener = EManager.addEvent(EName.onUpdateHunt, () => {
            this._updateHunt();
        });
        this._eventListeners.push(listener);
        if (this._isGetBossInfo) {
            this._showMonster();
        }
    }

    protected async _updateHunt() {
        await this._getBossInfo();
        this._showMonster();
    }

    protected async _showMonster() {
        this._monster = new Monster(this._monsterList[this._monsterIndex]);
        this.huntMonster.string = this._monster.getName();
        unionLogic.unionHuntMonster = this._monster;
        unionLogic.unionHuntMonsterType = this._monsterIndex + 1;
        let huntBoss = unionLogic.getUnionHuntBoss(this._monsterIndex + 1);
        if (huntBoss != null && huntBoss.endTs > gm.getCurrentTimestamp()) {
            this.weakUnion.node.active = true;
            this.weakUnion.spriteFrame = this.weakFrames[huntBoss.flawFac - 1];
            this.challengeBtn.node.active = true;
            this.openBtn.node.active = false;
            this.cupIcon.active = false;
            this.cupCost.node.active = false;
            this.timeNode.active = this.timeLabel.node.active = true;
            this.unschedule(this.onShowTime);
            this.onShowTime();
            let time = huntBoss.endTs - gm.getCurrentTimestamp();
            let day = time / 1000 / 3600;
            if (day > 24) {
                this.timeLabel.string = `${Math.floor(day / 24)}天${Math.floor(day % 24)}小时`;
            } else {
                this.schedule(this.onShowTime, 1);
            }

            this.challengeDiamondNode.active = this.wipeDiamondNode.active = false;
            let timeFinished = false;
            if (huntBoss.type == 1) {
                if (huntBoss.hitCountRemain == 0 && huntBoss.buyCount < defaultConfigMap.bajiaocitimebuy.value) {
                    this.challengeDiamondNode.active = this.wipeDiamondNode.active = true;
                    this.challengeDiamondLabel.string = this.wipeDiamondLabel.string = cm.bajiaociBuyPrice[huntBoss.buyCount].toString();
                }
                timeFinished = huntBoss.hitCountRemain == 0 && huntBoss.buyCount == defaultConfigMap.bajiaocitimebuy.value;
            } else if (huntBoss.type == 2) {
                if (huntBoss.hitCountRemain == 0 && huntBoss.buyCount < defaultConfigMap.dujianmutimebuy.value) {
                    this.challengeDiamondNode.active = this.wipeDiamondNode.active = true;
                    this.challengeDiamondLabel.string = this.wipeDiamondLabel.string = cm.dujianmuBuyPrice[huntBoss.buyCount].toString();
                }
                timeFinished = huntBoss.hitCountRemain == 0 && huntBoss.buyCount == defaultConfigMap.dujianmutimebuy.value;
            }
            if (timeFinished) {
                this.wipeNode.active = false;
                this.challengeNode.active = true;
                this.challengeBtn.interactable = false;
                this.challengeBtn2.interactable = false;
                this.wipeBtn.interactable = false;
                this.btnChallengeText.string = "今日次数已用完";
                this.btnChallengeText.fontSize = 36;
                this.lastCnt.node.active = false;
                if (this._monsterIndex == 0) {
                    promptLogic.setPromptRead([PromptType.UNION_HUNT_NORMAL]);
                } else {
                    promptLogic.setPromptRead([PromptType.UNION_HUNT_ADVANCE]);
                }
            } else {
                this.challengeBtn.interactable = true;
                this.btnChallengeText.string = "挑 战";
                this.btnChallengeText.fontSize = 40;
                this.lastCnt.node.active = true;
                this.lastCnt.string = `剩余次数:${huntBoss.hitCountRemain}/${unionLogic.getUnionHuntCnt() + huntBoss.buyCount}`;
                this.wipeNode.active = huntBoss.hitCountRemain < unionLogic.getUnionHuntCnt();
                //this.wipeNode.active = true;
                this.challengeNode.active = !this.wipeNode.active;
                this.wipeBtn.interactable = true;
                this.challengeBtn2.interactable = true;
                if (huntBoss.hitCountRemain == 0) {
                    if (this._monsterIndex == 0) {
                        promptLogic.setPromptRead([PromptType.UNION_HUNT_NORMAL]);
                    } else {
                        promptLogic.setPromptRead([PromptType.UNION_HUNT_ADVANCE]);
                    }
                }
            }
        } else {
            //未开启
            this.weakUnion.node.active = false;
            this.challengeNode.active = true;
            this.wipeNode.active = false;
            this.unschedule(this.onShowTime);
            this.timeNode.active = this.timeLabel.node.active = false;
            this.challengeBtn.node.active = false;
            this.openBtn.node.active = true;
            this.btnOpenText.string = "未开启";
            this.lastCnt.node.active = false;
            this.cupIcon.active = true;
            this.cupCost.node.active = true;
            this.cupCost.string = unionLogic.getUnion().getCurActiveScore() + "/" + defaultConfigMap.huntbossopen.value;
            if (unionLogic.getUnion().getCurActiveScore() < defaultConfigMap.huntbossopen.value) {
                this.cupCost.node.color = cc.Color.RED;
            }
            promptLogic.setPromptRead([PromptType.UNION_HUNT_ADVANCE]);
        }
        this._refreshTotalHurt();
        if (this._lastSkeletonData) {
            loadUtils.releaseAssetRecursively(this._lastSkeletonData);
            this._lastSkeletonData = null;
        }
        await gm.createHeroSpine(this._monster, this.heroHead);
        this.heroHead.node.scale = this._monster.getMonsterScale();
        this._lastSkeletonData = this.heroHead.skeletonData;
        this.content.destroyAllChildren();
        let goods = this._monsterIndex == 0 ? defaultConfigMap.boss1goodsshow.value.split(';') : defaultConfigMap.boss2goodsshow.value.split(';');
        for (let good of goods) {
            let goodId = parseInt(good);
            if (goodId >= 10000 && goodId <= 19999) {
                let goodCard = cc.instantiate(this.goodPrefab);
                goodCard.active = true;
                this.content.addChild(goodCard);
                let goodVo = new GoodVO();
                goodVo.propId = goodId;
                goodVo.amt = 0;
                let prop = new Good(goodVo);
                goodCard.getComponent(CommonLoader).loaderNode.getComponent(GoodCard).refresh(prop);
                goodCard.on(cc.Node.EventType.TOUCH_END, () => {
                    gcc.core.showLayer("prefabs/panel/bag/BagInfoPanel", { data: { good: prop, noUse: true }, modalTouch: true });
                }, this);
            } else if (goodId >= 30000 && goodId <= 39999) {
                let equipCard = cc.instantiate(this.equipPrefab);
                equipCard.active = true;
                this.content.addChild(equipCard);
                let equipBo = new EquipBO();
                equipBo.equipCofId = goodId;
                equipBo.career = 0;
                equipBo.campBonus = 0;
                let prop = new Equip(equipBo);
                equipCard.getComponent(CommonLoader).loaderNode.getComponent(EquipCard).refresh({ equip: prop });
                equipCard.on(cc.Node.EventType.TOUCH_END, () => {
                    gcc.core.showLayer("prefabs/panel/equip/EquipInfoPanel", { data: { equip: prop, nobtn: true }, modalTouch: true });
                }, this);
            }
        }
        for (let i = 0; i < 3; i++) {
            let skillNode = cc.find(`skillNode/skill${i + 1}`, this.node);
            skillNode.active = false;
        }
        let skills: Skill[] = this._monster.getSkills();
        for (let i = 0; i < skills.length; i++) {
            if (!skills[i].isShow()) {
                continue;
            }
            if (i < 3) {
                let skillNode = cc.find(`skillNode/skill${i + 1}`, this.node);
                skillNode.active = true;
                let loader = skillNode.getComponent(CommonLoader);
                loader.loaderNode.getComponent(UnionSkill).refresh({ skill: skills[i], hero: this._monster });
            }
        }
    }

    protected _refreshTotalHurt() {
        let huntBoss = unionLogic.getUnionHuntBoss(this._monsterIndex + 1);
        let totalHurtStr = huntBoss ? huntBoss.totalHurt : 0;
        let totalHurt = new BigNumber(totalHurtStr);
        let cfgs = huntaddupconfig.where(a => a.type == (this._monsterIndex + 1));
        let nowCfg = cfgs[cfgs.length - 1];
        for (let cfg of cfgs) {
            let hurt = new BigNumber(cfg.hurt.toString());
            if (totalHurt.isLessThan(hurt)) {
                nowCfg = cfg;
                break;
            }
        }
        this.hurtLabel.string = `${totalHurtStr}/${nowCfg.hurt}`;
        this.hurtProgress.progress = totalHurt.dividedBy(nowCfg.hurt).toNumber();
    }

    protected showSkipBattleTip() {
        if (!this.wipeBtn.node.active) { return; }
        let tipNode = this.wipEffect;
        if (tipNode.active) { return; }
        if (tipNode) {
            tipNode.active = true;

            let effect = tipNode.getComponent(cc.Animation);
            effect.play("guide_qipao", 0);
            this.scheduleOnce(() => {
                effect.stop();
                tipNode.active = false;
            }, 3.5)
        }
    }

    onShowTime() {
        let huntBoss = unionLogic.getUnionHuntBoss(this._monsterIndex + 1);
        let time = huntBoss.endTs;
        if (time >= gm.getCurrentTimestamp()) {
            this.timeLabel.string = timeUtils.formatTime((time - gm.getCurrentTimestamp()) / 1000);
            if (Math.floor((time - gm.getCurrentTimestamp()) / 1000) == 0) {
                this.unschedule(this.onShowTime);
                this._getBossInfo();
            }
        } else {
            this.timeLabel.string = timeUtils.formatTime((time - gm.getCurrentTimestamp() + 24 * 3600 * 1000) / 1000);
        }
    }

    onNext() {
        if (this._monsterIndex < this._monsterList.length - 1) {
            this._monsterIndex++;
            this._showMonster();
        }
        this._refreshBtn();
    }

    onPrevious() {
        if (this._monsterIndex > 0) {
            this._monsterIndex--;
            this._showMonster();
        }
        this._refreshBtn();
    }

    protected _refreshBtn() {
        this.previousBtn.active = true;
        this.nextBtn.active = true;
        if (this._monsterIndex == 0) {
            this.previousBtn.active = false;
        } else if (this._monsterIndex == this._monsterList.length - 1) {
            this.nextBtn.active = false;
        }
    }

    onReward() {
        let bossInfo = unionLogic.getUnionHuntBoss(unionLogic.unionHuntMonsterType);
        if (bossInfo && bossInfo.topRecord) {
            gcc.core.showLayer("prefabs/panel/union/UnionHuntRewardPanel");
        } else {
            gm.toast(stringConfigMap.key_auto_577.Value);
        }
    }

    onTip() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "hunt" } });
    }

    onRecord() {
        gcc.core.showLayer("prefabs/panel/union/UnionHuntRecordPanel");
    }

    async onChallenge() {
        if (!playerLogic.getPlayer().isInUnion()) {
            gm.toast(stringConfigMap.key_not_in_union.Value);
            return;
        }

        let delta = gm.getCurrentTimestamp() - unionLogic.unionJoinTimestamp;
        if (delta < 24 * 3600 * 1000) {
            gm.toast(stringUtils.getString(stringConfigMap.key_guild_join_cd.Value, { time: stringUtils.formatTime(Math.floor((24 * 3600 * 1000 - delta) / 1000)) }));
            return;
        }

        let battleDiamond = this._checkCanBattle();
        if (battleDiamond == 0) {
            gm.toast(stringConfigMap.key_auto_578.Value);
            return;
        } else if (battleDiamond > 0) {
            if (bagLogic.getGood(GoodId.Diamond).getAmount() < battleDiamond) {
                gm.diamondLessToast();
                return;
            } else {
                gm.dialog({
                    content: `花费${battleDiamond}钻石立即进入挑战?`, confirm: () => {
                        unionLogic.doBuyBossCount(this._monsterIndex + 1, battleDiamond).then(() => {
                            this._doChallenge();
                        })
                    }
                });
                return;
            }
        }
        this._doChallenge();
    }

    protected _doChallenge() {
        let unionHunt = new UnionHunt(this._monsterList[this._monsterIndex]);
        gcc.core.showLayer("prefabs/panel/battle/BattlePreparePanel", { data: unionHunt });
    }

    protected _checkCanBattle() {
        let bossInfo = unionLogic.getUnionHuntBoss(this._monsterIndex + 1);
        if (bossInfo.type == 1) {
            if (bossInfo.hitCountRemain == 0) {
                if (bossInfo.buyCount == defaultConfigMap.bajiaocitimebuy.value) {
                    return 0;
                } else {
                    return cm.bajiaociBuyPrice[bossInfo.buyCount];
                }
            }
        } else if (bossInfo.type == 2) {
            if (bossInfo.hitCountRemain == 0) {
                if (bossInfo.buyCount == defaultConfigMap.dujianmutimebuy.value) {
                    return 0;
                } else {
                    return cm.dujianmuBuyPrice[bossInfo.buyCount];
                }
            }
        }
        return -1;
    }

    async onWipe() {
        let level = rechargeLogic.getUnlockVipLevel(RightType.AutoTeamBattle);
        if (playerLogic.getPlayer().getVipLevel() < level) {
            this.showSkipBattleTip();
            return;
        }
        let battleDiamond = this._checkCanBattle();
        if (battleDiamond == 0) {
            gm.toast(stringConfigMap.key_auto_578.Value);
            return;
        } else if (battleDiamond > 0) {
            if (bagLogic.getGood(GoodId.Diamond).getAmount() < battleDiamond) {
                gm.diamondLessToast();
                return;
            } else {
                gm.dialog({
                    content: `花费${battleDiamond}钻石扫荡一次?`, confirm: () => {
                        unionLogic.doBuyBossCount(this._monsterIndex + 1, battleDiamond).then(() => {
                            this._doWipe();
                        })
                    }
                });
                return;
            }
        }
        this._doWipe();
    }

    protected _doWipe() {
        let level = rechargeLogic.getUnlockVipLevel(RightType.AutoTeamBattle);
        if (playerLogic.getPlayer().getVipLevel() >= level) {
            gcc.core.showLayer("prefabs/panel/union/UnionHuntWipePanel");
        } else {
            this.showSkipBattleTip();
        }
    }

    onOpen() {
        if (!unionLogic.hasPermission(UnionPermission.OpenHunt)) {
            let ids = cm.defaultHuntBoss;
            let monsterId = ids[ids.length - 1];
            let monster = new Monster(monsterId);
            gm.toast(stringUtils.getString(stringConfigMap.key_no_permission_openhunt.Value, { name: monster.getName() }));
            return;
        }
        if (unionLogic.getUnion().getCurActiveScore() < defaultConfigMap.huntbossopen.value) {
            gm.toast(stringConfigMap.key_no_enough_union_point.Value);
            return;
        }
        gcc.core.showLayer("prefabs/panel/union/UnionHuntOpenPanel");
    }

    onHurtReward() {
        gcc.core.showLayer("prefabs/panel/union/UnionHuntHurtRewardPanel", {data: this._monsterIndex + 1})
    }

    onHurtFaction() {
        let huntBoss = unionLogic.getUnionHuntBoss(this._monsterIndex + 1);
        if (huntBoss) {
            let faction = stringConfigMap[`key_faction_${huntBoss.flawFac}`].Value;
            gm.toast(stringUtils.getString(stringConfigMap.key_auto_642.Value, {p1: faction}));
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("union_hunt_bg"), type: cc.SpriteFrame });
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);

        if (this._lastSkeletonData) {
            loadUtils.releaseAssetRecursively(this._lastSkeletonData);
            this._lastSkeletonData = null;
        }
    }

}