import {PopupPanel} from "../BasePanel";
import unionLogic from "../../../logics/UnionLogic";
import assignmentLogic from "../../../logics/AssignmentLogic";
import { DailyType } from "../../../utils/DefineUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/UnionHuntWipePanel")
export default class UnionHuntWipePanel extends PopupPanel {

    @property(cc.Label)
    totalHurt: cc.Label = null;

    @property(cc.Label)
    totalCnt: cc.Label = null;

    async start() {
        await unionLogic.doGetHuntWipe();
        let unionHuntWipeData = unionLogic.getUnionHuntWipeData();
        if (unionHuntWipeData) {
            this.totalHurt.string = `${unionHuntWipeData["totalHurt"]}`;
            this.totalCnt.string = `${unionHuntWipeData["totalCnt"]}`;
        }
    }

    async onWipe() {
        await unionLogic.doCheckHunt(unionLogic.unionHuntMonsterType);
        gcc.core.showLayer("prefabs/panel/union/UnionHuntResultPanel", {
            data: {
                contribution: null,
                wipe: true
            },
            callback: () => {
                this.closePanel();
            }
        });
        // 日常提交
        assignmentLogic.dailyTaskProCommit(DailyType.fight_union);
    }

}