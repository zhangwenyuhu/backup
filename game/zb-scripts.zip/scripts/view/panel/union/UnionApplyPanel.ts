import { RoleVO } from './../../../proxy/GameProxy';
import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from "../BasePanel";
import { RefreshLabel } from "../../../decorator/RefreshDecorator";
import unionLogic from "../../../logics/UnionLogic";
import Union from "../../../data/union/Union";
import stringUtils from "../../../utils/StringUtils";
import List from '../../common/List';
import gm from '../../../manager/GameManager';
import GameProxy from '../../../proxy/GameProxy';
import User from '../../../data/user/User';
import UnionApplyItem from '../../widget/union/UnionApplyItem';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/UnionApplyPanel")
export default class UnionApplyPanel extends PopupPanel {
    @RefreshLabel({
        eventName: Union.Event.onMemberDirty,
        getData: () => { return unionLogic.getUnion() },
        getValue: (union: Union) => { return stringUtils.getString(stringConfigMap.key_union_member_count.Value, { count: `${union.getMembers().length}/${union.getMaxMembers()}` }) }
    })
    @property(cc.Label)
    labelMember: cc.Label = null;

    @property(cc.Label)
    labelApply: cc.Label = null;

    @property(List)
    applyList: List = null;

    protected _users: User[] = [];

    async start() {
        super.start();

        this.labelApply.string = "";
        let protos = await gm.request<RoleVO[]>(GameProxy.apiguildgetApplyList);
        for (let proto of protos) {
            let user = new User(proto);
            this._users.push(user);
        }
        this._updateList();
    }

    update(dt: number) {
        super.update(dt);
        this.labelMember.node.y = this.applyList.content.y - 30;
    }

    updateApplyItem(node: cc.Node, index: number) {
        let item = node.getComponent(UnionApplyItem);
        item.updateView(this._users[index], async (user: User) => {
            try {
                let data = await unionLogic.doOperateApply([user], true);
                this._users = data.newList;
                this._updateList();
                if (data.ignoreList.length > 0) {
                    gm.toast(stringConfigMap.key_in_other_union.Value);
                }
            } catch (e) {
                if (e.name == "ToastError") {
                    gm.toast(e.message);
                    unionLogic.doRefreshUnion();
                    this.closePanel();
                }
                else {
                    throw e;
                }
            }

        }, async (user: User) => {
            try {
                let data = await unionLogic.doOperateApply([user], false);
                this._users = data.newList;
                this._updateList();
                if (data.ignoreList.length > 0) {
                    gm.toast(stringConfigMap.key_in_other_union.Value);
                }
            } catch (e) {
                if (e.name == "ToastError") {
                    gm.toast(e.message);
                    unionLogic.doRefreshUnion();
                    this.closePanel();
                }
                else {
                    throw e;
                }
            }
        });
    }

    async onAllAgree() {
        if (unionLogic.getUnion().getMembers().length == unionLogic.getUnion().getMaxMembers()) {
            gm.toast(stringConfigMap.key_auto_579.Value);
            return;
        }
        if (this._users.length > 0) {
            try {
                let data = await unionLogic.doOperateApply(this._users, true);
                this._users = data.newList;
                this._updateList();
            } catch (e) {
                if (e.name == "ToastError") {
                    gm.toast(e.message);
                    unionLogic.doRefreshUnion();
                    this.closePanel();
                }
            }
        }
    }

    async onAllRefuse() {
        if (this._users.length > 0) {
            try {
                let data = await unionLogic.doOperateApply(this._users, false);
                this._users = data.newList;
                this._updateList();
            } catch (e) {
                if (e.name == "ToastError") {
                    gm.toast(e.message);
                    unionLogic.doRefreshUnion();
                    this.closePanel();
                }
            }
        }
    }

    protected _updateList() {
        this.applyList.getComponent(cc.Widget).updateAlignment();
        this.applyList.numItems = this._users.length;
        this.labelApply.string = stringUtils.getString(stringConfigMap.key_union_apply_count.Value, { count: this._users.length });
    }
}
