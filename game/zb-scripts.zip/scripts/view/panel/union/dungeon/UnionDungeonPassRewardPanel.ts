import { PopupPanel } from "../../BasePanel";
import List from "../../../common/List";
import EManager, { EName } from "../../../../manager/EventManager";
import factiongamescoreconfig from "../../../../configs/factiongamescoreconfig";
import gm from "../../../../manager/GameManager";
import udgLogic from "../../../../logics/UnionDungeonLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/dungeon/UnionDungeonPassRewardPanel")
export default class UnionDungeonPassRewardPanel extends PopupPanel {

    @property(List)
    rewardView: List = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    protected _levels: string[] = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'];
    onInit(data: any) {

    }

    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
        this.heroItem.parent = null;
        this.equipItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
        this.heroItem.destroy();
        this.equipItem.destroy();
    }

    start() {
        super.start();

        this.registerEvent();
        this.refreshRewardView();
    }

    protected registerEvent() {
        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data === "UnionDungeonRankPanel") {
                this.refreshRewardView();
            }
        })
        this._eventListeners.push(listener);
    }

    protected onItemRender(item: cc.Node, index: number) {
        let data = factiongamescoreconfig[index];

        let bRecv: boolean = udgLogic.isUdgPassRewardRecv(data.stage);
        let complete: boolean = udgLogic.canRecvUdgPassReward(data.stage);
        item.getChildByName('recvied').active = bRecv;
        let btnNo = item.getChildByName('btnNo')
        btnNo.active = !complete && !bRecv;
        if (btnNo.active) {
            btnNo.off('click');
            btnNo.on('click', () => { gm.toast('副本未通过'); })
        }

        let btnRecv = item.getChildByName('btnGet');
        btnRecv.active = complete && !bRecv;
        if (btnRecv.active) {
            btnRecv.off('click');
            btnRecv.on('click', () => {
                this.doRecvPassReward(data.stage);
            })
        }

        // rewards
        let node = item.getChildByName('rewards');
        node.destroyAllChildren();
        let reward: number[][] = data.stagereward;
        for (let i = 0; i < reward.length; i++) {
            gm.showGoodItem(reward[i], {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem,
            }, node, 0.8);
        }

        let stageNode = item.getChildByName('layout').getChildByName('lv');
        stageNode.getComponent(cc.Label).string = this._levels[data.stage - 1] ? this._levels[data.stage - 1] : this._levels[0]
    }

    protected async doRecvPassReward(level: number) {
        try {
            let reward = await udgLogic.recvPassRewardReq(level);
            gm.getReward(reward);
            this.refreshRewardView();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    protected refreshRewardView() {
        this.rewardView.getComponent(cc.Widget).updateAlignment();
        this.rewardView.numItems = factiongamescoreconfig.length;
    }
}
