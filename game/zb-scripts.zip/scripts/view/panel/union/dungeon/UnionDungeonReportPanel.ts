import { PopupPanel } from "../../BasePanel";
import { UnionSimple } from "../../../../data/union/Union";
import udgLogic from "../../../../logics/UnionDungeonLogic";
import unionLogic from "../../../../logics/UnionLogic";
import loadUtils from "../../../../utils/LoadUtils";
import RankData from "../../../../data/record/RankData";
import CommonLoader from "../../../common/CommonLoader";
import commonUtils from "../../../../utils/CommonUtils";
import DungeonReportItem from "../../../component/Union/DungeonReportItem";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/dungeon/UnionDungeonReportRewardPanel")
export default class UnionDungeonReportRewardPanel extends PopupPanel {

    @property(cc.Node)
    myUnion: cc.Node = null;

    @property(cc.Node)
    enemyUnion: cc.Node = null;

    @property(cc.Node)
    resultFlag: cc.Node = null;

    @property(cc.Node)
    top3View: cc.Node = null;

    @property(cc.Node)
    rankItem: cc.Node = null;

    @property(cc.Node)
    rankEmptyFlag: cc.Node = null;

    protected _enemy: UnionSimple = null;
    protected async _preloadRes() {
        await super._preloadRes();

        let enemyId = udgLogic.getLastEnemyId();
        if (enemyId > 0) {
            this._enemy = await unionLogic.getUnionSimple(enemyId);
        }
        await udgLogic.lastUdgTop3Req();
    }

    onLoad() {
        super.onLoad();
        this.rankItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        this.rankItem.destroy();
    }

    start() {
        super.start();
        let isTied: boolean = udgLogic.lastMyUnionScore() == udgLogic.lastEnemyScore();

        let avatar: string = '' + unionLogic.getUnion().getAvatar();
        let icon = commonUtils.getUnionIconUrl(avatar);
        let name = unionLogic.getUnion().getName();
        let score = udgLogic.lastMyUnionScore();
        this._updateUnionInfo(this.myUnion, {
            icon: icon,
            name: name,
            score: score,
            win: udgLogic.lastUdgFightWin() && !isTied
        })

        avatar = this._enemy ? this._enemy.icon : '_monster';
        icon = commonUtils.getUnionIconUrl(avatar);
        name = this._enemy ? this._enemy.name : '怪物军团';
        score = udgLogic.lastEnemyScore();
        this._updateUnionInfo(this.enemyUnion, {
            icon: icon,
            name: name,
            score: score,
            win: !udgLogic.lastUdgFightWin() && !isTied
        })

        this.resultFlag.active = isTied;
        this._updateTop3();
    }

    protected _updateUnionInfo(node: cc.Node, data: { icon: string, name: string, score: number, win: boolean }) {
        let name = node.getChildByName('name').getComponent(cc.Label);
        name.string = data.name;

        let score = node.getChildByName('score').getComponent(cc.Label);
        score.string = '' + data.score;

        node.getChildByName('win').active = data.win;
        let icon = node.getChildByName('icon').getComponent(cc.Sprite);
        loadUtils.loadSpriteFrame(data.icon, icon);
    }

    protected _updateTop3() {
        this.top3View.destroyAllChildren();
        let data: RankData[] = udgLogic.getLastTop3();
        for (let i = 0; i < data.length; i++) {
            let tmp = cc.instantiate(this.rankItem);
            tmp.parent = this.top3View;

            let rank = tmp.getChildByName('rank');
            let comp = rank.getComponent(CommonLoader).loaderNode.getComponent(DungeonReportItem);
            comp.refresh(data[i]);
            comp.showUnionName();
        }
        this.rankEmptyFlag.active = data.length <= 0;
    }
}
