import BasePanel, { PopupPanel } from "../../BasePanel";
import IBattleData from "../../../../data/IBattleData";
import UdgMonster from "../../../../data/union/UdgMonster";
import udgLogic from "../../../../logics/UnionDungeonLogic";
import gm from "../../../../manager/GameManager";
import EManager, { EName } from "../../../../manager/EventManager";
import CommonLoader from "../../../common/CommonLoader";
import HeroCard from "../../../component/Hero/HeroCard";
import Hero from "../../../../data/card/Hero";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/dungeon/UnionDungeonResultPanel")
export default class UnionDungeonResultPanel extends PopupPanel {

    @property(cc.Node)
    udgNpc: cc.Node = null;

    @property(cc.Node)
    npcItem: cc.Node = null;

    @property(cc.Label)
    udgProg: cc.Label = null;

    @property(cc.Label)
    udgScore: cc.Label = null;

    @property(cc.Node)
    udgFightReward: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    btnCancel: cc.Node = null;

    protected _udgData: UdgMonster = null;
    protected _fightContribution: rpgfight.HeroContributionStatistic[] = [];
    protected _leftfightHero: rpgfight.Hero[] = [];
    onInit(data: {
        battleData: IBattleData,
        skills: any,
        contribution?: rpgfight.HeroContributionStatistic[],
        heroList?: rpgfight.Hero[]
    }) {
        super.onInit(data.battleData);
        this._udgData = data.battleData as UdgMonster;
        this._fightContribution = data.contribution;
        this._leftfightHero = data.heroList;
    }

    start() {
        super.start();

        this.updateUdgNpc();
        this.updateUdgReward();
        this.updateButtons();
    }

    protected updateButtons() {
        let monsters = this._udgData.getMonsters();
        let hasLive: boolean = monsters.some((v, i, a) => {
            let cb = this._fightContribution.find((b) => { return b.heroId == v.getId(); })
            return !cb || !cb.isDead;
        })
        this.btnCancel.active = hasLive;
    }

    // 公会副本怪物挑战情况
    protected updateUdgNpc() {

        let udgMonster = this._udgData.getMonsters();
        this.udgNpc.destroyAllChildren();
        for (let i = 0; i < udgMonster.length; i++) {
            let data = this._fightContribution.find((a) => { return a.heroId == udgMonster[i].getId(); })
            let heroInfo = this._leftfightHero.find((a) => { return a && a.heroData.heroId == udgMonster[i].getId(); })
            let tmp = cc.instantiate(this.npcItem);
            tmp.parent = this.udgNpc;

            let npc = tmp.getChildByName('npc');
            npc.destroyAllChildren();
            let hero = cc.instantiate(this.heroItem);
            hero.parent = npc;
            hero.position = cc.v2(0, 0);
            let comp = hero.getComponent(CommonLoader).loaderNode.getComponent(HeroCard);
            comp.refresh(udgMonster[i]);
            comp.showGray(data.isDead);

            let hpProg: number = 1;
            let powerProg: number = 1;
            hpProg = data.isDead ? 0 : hpProg;
            powerProg = data.isDead ? 0 : powerProg;
            if (heroInfo) {
                hpProg = heroInfo.heroData.hp / heroInfo.heroData.hpMax;
                powerProg = heroInfo.heroData.power / heroInfo.heroData.powerMax;
            }

            let hpNode = tmp.getChildByName('hp').getChildByName('prog');
            hpNode.getComponent(cc.ProgressBar).progress = hpProg;

            let powerNode = tmp.getChildByName('power').getComponent(cc.ProgressBar);
            powerNode.progress = powerProg;
        }
    }

    // 可获得奖励
    protected updateUdgReward() {
        let num: number = this._getKillNum();
        let boss = this._udgData.isBoss() ? num : 0;
        let normal = this._udgData.isBoss() ? 0 : num;
        //let index = this._udgData.getIndex();
        let diff = this._udgData.getDiff();

        let score: number = udgLogic.getKillScore(diff, boss, normal);
        let max: number = udgLogic.udgScoreCof.totalscore;
        let udgProg = Math.floor(score * 100 / max);
        udgProg = udgProg > 100 ? 100 : udgProg;
        this.udgScore.string = `${score}`;
        this.udgProg.string = `${udgProg}%`;

        let reward = udgLogic.getUdgFightReward(diff, boss, normal);
        this.udgFightReward.destroyAllChildren();
        for (let i = 0; i < reward.length; i++) {
            gm.showGoodItem(reward[i], {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem,
            }, this.udgFightReward, 1);
        }
    }

    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
        this.heroItem.parent = null;
        this.equipItem.parent = null;
        this.npcItem.parent = null;
        BasePanel.closePanel("BattlePausePanel");
    }
    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
        this.heroItem.destroy();
        this.equipItem.destroy();
        this.npcItem.destroy();
    }

    protected onClickOK() {
        this.doCommitUdgFight();
    }
    protected onClickRetry() {
        EManager.emit(EName.onGameExit, { type: this._udgData.getBattleType() });
        EManager.emit(EName.onFreshPanel, 'UnionDungeonMonsterPanel');
        this.closePanel();
    }

    protected _getKillNum() {
        let num: number = 0;
        for (let i = 0; i < this._fightContribution.length; i++) {
            let data = this._fightContribution[i];
            let index = this._udgData.getMonsters().findIndex((a) => { return a.getId() == data.heroId; })
            if (index >= 0) { num += (data.isDead ? 1 : 0); }
        }
        return num;
    }

    protected async doCommitUdgFight() {
        let num: number = this._getKillNum();
        let boss = this._udgData.isBoss() ? num : 0;
        let normal = this._udgData.isBoss() ? 0 : num;

        let index = this._udgData.getIndex();
        let diff = this._udgData.getDiff();
        try {
            let proto = await udgLogic.commitDungeonBattleResult(index, diff, boss, normal);
            gm.getReward(proto);

            udgLogic.commitUdgClearResult(index, diff, boss, normal);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }

        EManager.emit(EName.onGameExit, { type: this._udgData.getBattleType() });
        EManager.emit(EName.onFreshPanel, 'UnionDungeonMonsterPanel');
        EManager.emit(EName.onFreshPanel, 'UnionDungeonMainPanel');
        this.closePanel();
    }
}
