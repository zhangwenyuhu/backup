import { PopupPanel } from "../../BasePanel";
import List from "../../../common/List";
import EManager, { EName } from "../../../../manager/EventManager";
import udgLogic from "../../../../logics/UnionDungeonLogic";
import unionLogic from "../../../../logics/UnionLogic";
import friendMerLogic from "../../../../logics/FriendMerLogic";
import cm from "../../../../manager/ConfigManager";
import gm from "../../../../manager/GameManager";
import CommonLoader from "../../../common/CommonLoader";
import DungeonNpc from "../../../component/Union/DungeonNpc";
import playerLogic from "../../../../logics/PlayerLogic";
import commonUtils from "../../../../utils/CommonUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/dungeon/UnionDungeonBoxPanel")
export default class UnionDungeonBoxPanel extends PopupPanel {

    @property(List)
    boxView: List = null;

    @property(cc.Label)
    themeTitle: cc.Label = null;

    @property(cc.Label)
    themeMonsterName: cc.Label = null;

    @property(cc.Label)
    themeTimes: cc.Label = null;

    @property(cc.Node)
    btnChange: cc.Node = null;

    @property(cc.Node)
    btnNormal: cc.Node = null;

    @property(cc.Node)
    btnMore: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    udgNpc: cc.Node = null;

    @property(cc.SpriteFrame)
    btnFrame: cc.SpriteFrame[] = [];

    protected _index: number = 1;
    protected _boxData: { index: number, boxId: number, roleId: string }[] = [];
    protected _effectName: string = '';
    onInit(data: any) {

    }

    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
        this.heroItem.parent = null;
        this.equipItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
        this.heroItem.destroy();
        this.equipItem.destroy();
    }

    start() {
        super.start();
        this.registerEvent();

        this.updateButtons();
        this.refreshBoxView();
        this.updateNpcIcon();
    }

    protected updateNpcIcon() {
        let npc = udgLogic.getDungeonMonster(this._index);
        let comp = this.udgNpc.getComponent(CommonLoader).loaderNode.getComponent(DungeonNpc);
        comp.refresh(npc);
        comp.showNpcType(false);
    }

    protected registerEvent() {
        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data === "UnionDungeonBoxRewardPanel") {
                this.refreshBoxView();
                this.updateNpcIcon();
            }
        })
        this._eventListeners.push(listener);
    }

    protected onClickMoreTheme() {
        this.btnNormal.active = !this.btnNormal.active;
        this.btnMore.active = !this.btnMore.active;

        let nameArr: string[] = ['UDBP_n3tom2', 'UDBP_m2ton3'];
        if (!this._effectName) { this._effectName = this._index <= 3 ? nameArr[0] : nameArr[1]; }
        let ani = this.btnMore.parent.getComponent(cc.Animation);
        ani.play(this._effectName, 0);

        this._effectName = this._effectName === nameArr[0] ? nameArr[1] : nameArr[0];
        let flag = this.btnChange.getChildByName('arrow');
        flag.scaleX = -flag.scaleX;
    }

    protected async onItemRender(item: cc.Node, index: number) {
        let data = this._boxData[index]

        let defatul = item.getChildByName('chest');
        let reward = item.getChildByName('good');

        let opened: boolean = data.boxId > 0;

        defatul.active = opened ? false : true;
        reward.active = opened ? true : false;
        if (reward.active) {
            let nick = await this.getUnionMemberName(data.roleId);
            let name = reward.getChildByName('name');
            name.getComponentInChildren(cc.Label).string = nick;

            let cof = cm.getUdgBoxConfig(data.boxId);
            if (!cof) { console.error(`宝箱配置未找到:${data.boxId}`); return; }
            let rewardNode = reward.getChildByName('reward');
            rewardNode.destroyAllChildren();

            gm.showGoodItem(cof.smallBox, {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem,
            }, rewardNode, 0.9);

            commonUtils.playAnimation(item, 'icon_libao01');
        }

        let btn = item.getChildByName('btn');
        btn.off('click');
        if (!opened) {
            btn.on('click', (sender) => {
                let ret = this._checkOpenUdgBox(data.index);
                if (!ret.ret) { gm.toast(ret.msg); return; }

                commonUtils.playAnimation(btn.parent, 'icon_libao02', () => {
                    this.doOpenUdgBox(data.index);
                });
            })
        }
    }

    protected async doOpenUdgBox(pos: number) {
        let ret = this._checkOpenUdgBox(pos);
        if (!ret.ret) { gm.toast(ret.msg); return; }
        try {
            await udgLogic.recvUdgBoxReq(this._index, pos);
            this.refreshBoxView();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    protected _checkOpenUdgBox(pos: number) {
        let ret: { ret: boolean, msg: string } = { ret: true, msg: '' };
        let data = udgLogic.getDungeonMonster(this._index)
        if (data.getNpcProg() < 100) { ret.ret = false; ret.msg = '您暂无开启机会,努力讨伐怪物吧'; }
        if (data.giftRecvied) { ret.ret = false; ret.msg = '您已领取过当前怪物宝箱'; }
        return ret;
    }

    protected async getUnionMemberName(roleId: string) {
        if (roleId == playerLogic.getPlayer().getRoleId()) { return '自己'; }
        let name: string = '';
        let union = unionLogic.getUnion();
        if (union) {
            let data = union.getMember(roleId);
            if (data) {
                name = data.getNickname();
            } else {
                await friendMerLogic.userDataReq(roleId);
                let info = friendMerLogic.getUserDataByRoleId(this._data.role);
                name = info ? info.getNickname() : '';
            }
        }
        return name;
    }

    protected changeTheme(index: number) {
        if (this._index == index) { return; }

        this._index = index;
        this.updateButtons();
        this.refreshBoxView();
        this.updateNpcIcon();
    }

    protected updateButtons() {
        let bNormal: boolean = this._index <= 3;
        this.btnNormal.active = bNormal;
        this.btnMore.active = !bNormal;

        //let node = bNormal ? this.btnNormal : this.btnMore;
        for (let i = 1; i <= 5; i++) {
            let child = this.btnNormal.getChildByName(`${i}`);
            if (!child) { child = this.btnMore.getChildByName(`${i}`); }
            if (child) {
                let data = udgLogic.getDungeonMonster(i);
                this._renderThemeButton(child, i == this._index, data.getNpcName());

                child.off('click');
                child.on('click', () => {
                    this.changeTheme(data.index);
                })
            }
        }
    }

    protected _renderThemeButton(node: cc.Node, focus: boolean, name: string) {
        node.getComponentInChildren(cc.Label).string = name;
        //node.getComponentInChildren(cc.Label).node.color = focus ? cc.color(255, 255, 255, 255) : cc.color(156, 156, 156, 255);
        node.getComponentInChildren(cc.Label).fontSize = focus ? 34 : 28;
        let frameIndex: number = focus ? 1 : 0;
        node.getComponent(cc.Sprite).spriteFrame = this.btnFrame[frameIndex];
    }

    protected refreshBoxView() {

        let num = udgLogic.getUdgBoxMaxCount();
        this._boxData = [];
        for (let i = 1; i <= num; i++) {
            let pos = udgLogic.getUdgBoxPos(this._index, i - 1);
            let data = udgLogic.getUdgBox(this._index, pos);
            if (!data) { data = { index: pos, boxId: 0, roleId: '' } }
            this._boxData.push(data);
        }
        //this._boxData.sort((a, b) => { return a.index - b.index; })

        this.boxView.getComponent(cc.Widget).updateAlignment();
        this.boxView.numItems = num;


        let udgInfo = udgLogic.getDungeonMonster(this._index);
        this.themeTitle.string = udgInfo.getMonster(1).getTitle();
        this.themeMonsterName.string = udgInfo.getNpcName();
        let left: number = udgInfo.giftRecvied ? 0 : 1;
        this.themeTimes.string = `${left}/1`;
    }
}
