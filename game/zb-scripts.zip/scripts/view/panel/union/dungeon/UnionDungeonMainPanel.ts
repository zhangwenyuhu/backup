import { FullscreenPanel } from "../../BasePanel";
import EManager, { EName } from "../../../../manager/EventManager";
import CommonLoader from "../../../common/CommonLoader";
import DungeonMonster from "../../../component/Union/DungeonMonster";
import udgLogic from "../../../../logics/UnionDungeonLogic";
import stringUtils from "../../../../utils/StringUtils";
import unionLogic from "../../../../logics/UnionLogic";
import commonUtils from "../../../../utils/CommonUtils";
import loadUtils from "../../../../utils/LoadUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/dungeon/UnionDungeonMainPanel")
export default class UnionDungeonMainPanel extends FullscreenPanel {

    @property(cc.Node)
    monsterNode: cc.Node = null;

    @property(cc.Label)
    theme: cc.Label = null;

    @property(cc.Label)
    battleTimes: cc.Label = null;

    @property(cc.Node)
    myUnionBattleInfo: cc.Node = null;

    @property(cc.Node)
    enemyUnionBattleInfo: cc.Node = null;

    @property(cc.Node)
    dungeonSort: cc.Node = null;

    @property(cc.Label)
    dungeonSortTs: cc.Label = null;

    @property(cc.Node)
    udgScoreProg: cc.Node = null;

    @property(cc.Node)
    udgScoreProgLight: cc.Node = null;

    @property(cc.Node)
    btnLastUdg: cc.Node = null;

    @property(cc.Node)
    btnBox: cc.Node = null;

    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("union_dungeon_bg"), type: cc.SpriteFrame });
        await udgLogic.unionDungeonReq();
        await udgLogic.getUdgReportStateReq();
    }

    onInit(data: any) {
        super.onInit(data);
    }

    async start() {
        super.start();
        this.registerEvent();

        await this.updateUdgInfo();
        this.schedule(this.updateDungeonSort.bind(this), 1);
        this.btnLastUdg.active = udgLogic.lastEndTs() > 0;

        if (this.btnLastUdg.active && !udgLogic.isReported()) {
            udgLogic.updateUdgReportStateReq(true);
            this.scheduleOnce(() => {
                gcc.core.showLayer("prefabs/panel/union/dungeon/UnionDungeonReportPanel");
            }, 0.2)
        }
    }

    onLoad() { super.onLoad(); }
    onDestroy() { super.onDestroy() }

    protected registerEvent() {
        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data == "UnionDungeonMainPanel") {
                this.updateUdgInfo();
            }
        });
        this._eventListeners.push(listener);
    }

    protected async updateUdgInfo() {
        // 主题
        this.theme.string = udgLogic.udgThemeCof.theme + ` ${udgLogic.getUdgLvTitle(udgLogic.getUdgLv())}`;
        // 次数
        let leftTimes = udgLogic.getUdgFightMaxTimes() - udgLogic.getTodayFightTimes();
        this.battleTimes.string = `${leftTimes}/${udgLogic.getUdgFightMaxTimes()}`;
        // 怪物信息
        this.updateMonsterInfo();
        // 公会积分信息
        this.updateUdgScoreInfo(this.myUnionBattleInfo, false);
        await this.updateUdgScoreInfo(this.enemyUnionBattleInfo, true);

        let myScore: number = udgLogic.getUdgTotalScore(false);
        let enemyScore: number = udgLogic.getUdgTotalScore(true);
        let prog: number = 0.5;
        if (myScore > 0 || enemyScore > 0) { prog = myScore / (myScore + enemyScore); }
        this.udgScoreProg.getComponent(cc.ProgressBar).progress = prog;
        this.udgScoreProgLight.x = this.udgScoreProg.width * prog;
        // 是否结算中
        this.updateDungeonSort();

        this.updateBoxActionStatu();
    }

    protected updateBoxActionStatu() {
        let ani = this.btnBox.getComponent(cc.Animation);
        if (udgLogic.hasBoxCanOpen()) {
            ani.play('icon_libao03');
        } else {
            ani.stop();
        }
    }

    // 更新副本怪物信息
    protected updateMonsterInfo() {
        for (let i = 1; i <= 5; i++) {
            let node = this.monsterNode.getChildByName(`m${i}`);
            let comp = node.getComponent(CommonLoader).loaderNode.getComponent(DungeonMonster);
            comp.refresh(udgLogic.getDungeonMonster(i));
        }
    }
    protected async updateUdgScoreInfo(node: cc.Node, enemy: boolean) {
        let name = node.getChildByName('name').getComponent(cc.Label);
        let unionName: string = '公会名';
        let avatar: string = '';
        if (enemy) {
            let enemyId: number = udgLogic.getEnemyId()
            if (enemyId > 0) {
                let simple = await unionLogic.getUnionSimple(enemyId);
                unionName = simple.name;
                avatar = simple.icon;
            } else {
                unionName = '怪物军团';
                avatar = '_monster';
            }
        } else {
            let data = unionLogic.getUnion();
            unionName = data ? data.getName() : unionName;
            avatar = '' + data.getAvatar();
        }
        name.string = unionName;

        let score = node.getChildByName('layout').getChildByName('score').getComponent(cc.Label);
        score.string = '' + udgLogic.getUdgTotalScore(enemy);

        let icon = node.getChildByName('icon');
        let url = commonUtils.getUnionIconUrl(avatar);
        loadUtils.loadSpriteFrame(url, icon.getComponent(cc.Sprite));
    }

    protected updateDungeonSort() {
        this.dungeonSort.active = udgLogic.isDungeonSort();
        if (this.dungeonSort.active) {
            let sec: number = udgLogic.getLeftSec();
            this.dungeonSortTs.string = stringUtils.formatTime(sec / 1000);
        }
    }

    // 帮助
    protected onClickHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "union_dungeon" } });
    }
    // 公会副本排行榜
    protected onClickRank() {
        gcc.core.showLayer("prefabs/panel/union/dungeon/UnionDungeonRankPanel");
    }
    // 公会竞争上周战报
    protected onClickPreFightResult() {
        gcc.core.showLayer("prefabs/panel/union/dungeon/UnionDungeonReportPanel");
    }
    // 副本通关奖励
    protected onClickPassReward() {
        gcc.core.showLayer("prefabs/panel/union/dungeon/UnionDungeonPassRewardPanel");
    }
    // 公会竞争奖励
    protected onClickFightReward() {
        gcc.core.showLayer("prefabs/panel/union/dungeon/UnionDungeonWinRewardPanel");
    }
    // 公会讨伐宝箱
    protected async onClickDungeonBox() {
        await udgLogic.unionDungeonReq();
        gcc.core.showLayer("prefabs/panel/union/dungeon/UnionDungeonBoxPanel");
    }
}
