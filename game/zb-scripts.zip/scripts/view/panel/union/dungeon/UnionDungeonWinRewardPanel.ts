import { PopupPanel } from "../../BasePanel";
import udgLogic from "../../../../logics/UnionDungeonLogic";
import gm from "../../../../manager/GameManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/dungeon/UnionDungeonWinRewardPanel")
export default class UnionDungeonWinRewardPanel extends PopupPanel {

    @property(cc.Node)
    winReward: cc.Node = null;

    @property(cc.Node)
    failReward: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
        this.heroItem.parent = null;
        this.equipItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
        this.heroItem.destroy();
        this.equipItem.destroy();
    }

    start() {
        super.start();

        this.updateReward(this.winReward, udgLogic.udgScoreCof.winreward);
        this.updateReward(this.failReward, udgLogic.udgScoreCof.failreward);
    }

    protected updateReward(node: cc.Node, data: number[][]) {
        node.destroyAllChildren();
        for (let i = 0; i < data.length; i++) {
            gm.showGoodItem(data[i], {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem,
            }, node, 0.88);
        }
    }
}
