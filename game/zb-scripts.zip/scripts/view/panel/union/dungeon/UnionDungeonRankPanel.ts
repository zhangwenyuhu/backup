import { PopupPanel } from "../../BasePanel";
import List from "../../../common/List";
import RankData from "../../../../data/record/RankData";
import EManager, { EName } from "../../../../manager/EventManager";
import CommonLoader from "../../../common/CommonLoader";
import DungeonRankItem from "../../../component/Union/DungeonRankItem";
import { DunRankType } from "../../../../utils/DefineUtils";
import udgLogic from "../../../../logics/UnionDungeonLogic";


const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/dungeon/UnionDungeonRankPanel")
export default class UnionDungeonRankPanel extends PopupPanel {

    @property(List)
    rankList: List = null;

    @property(cc.Node)
    myRank: cc.Node = null;

    @property(cc.Node)
    rankValueTitle: cc.Node = null;

    @property(cc.Node)
    emptyTip: cc.Node = null;

    protected _type: DunRankType = 0;
    protected _rankReq: { [key: number]: boolean } = {};
    //protected _ranks: RankData[] = [];
    //protected _myRank: RankData = null;
    protected async _preloadRes() {
        await super._preloadRes();

        await udgLogic.udgRankReq(false, 0, 49);
        this._rankReq[DunRankType.Union_Contribution] = true;
    }
    onInit(data: any) {
        this._type = data ? data : DunRankType.Union_Contribution;
    }

    onLoad() {
        super.onLoad();
    }

    onDestroy() {
        super.onDestroy();
    }

    start() {
        super.start();

        this.registerEvent();
        this.refreshRankView();
    }

    protected registerEvent() {
        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data === "UnionDungeonRankPanel") {
                this.refreshRankView();
            }
        })
        this._eventListeners.push(listener);
    }

    protected onTabClick(event: cc.Event.EventTouch, index: string) {
        let type: number = parseInt(index);
        if (this._type == type) { return; }

        this._type = type;
        this.refreshRankView();
    }

    protected onItemRender(item: cc.Node, index: number) {
        let rank = item.getChildByName('rank');
        let data = udgLogic.getRankData(this.isAll(), index + 1);
        if (rank) {
            let comp = rank.getComponent(CommonLoader).loaderNode.getComponent(DungeonRankItem);
            comp.refresh(data);
            if (this.isAll()) { comp.showUnionName(); }
        }
    }

    protected async refreshRankView() {
        // head
        let valueTitle = this.getValueTitle(this._type);
        this.rankValueTitle.getComponent(cc.Label).string = valueTitle;

        // list
        this.rankList.getComponent(cc.Widget).updateAlignment();
        let len = udgLogic.getRankLen(this._type == DunRankType.Union_Battle);
        if (len <= 0 || !this._rankReq[this._type]) {
            await udgLogic.udgRankReq(this.isAll(), 0, 49);
            this._rankReq[this._type] = true;
            len = udgLogic.getRankLen(this._type == DunRankType.Union_Battle);
        }
        this.rankList.numItems = len;

        this.rankList.node.parent.active = len > 0;
        this.emptyTip.active = len <= 0;
        // my
        let rank = this.myRank.getChildByName('rank');
        let comp = rank.getComponent(CommonLoader).loaderNode.getComponent(DungeonRankItem);
        let myRankData = udgLogic.getMyRank(this.isAll());
        comp.refresh(myRankData);
    }

    protected isAll() { return this._type == DunRankType.Union_Battle; }

    protected getValueTitle(type: DunRankType) {
        if (type == DunRankType.Union_Contribution) {
            return '今日讨伐积分';
        } else if (type == DunRankType.Union_Battle) {
            return '讨伐积分';
        }
        return '';
    }
}
