import { PopupPanel } from "../../BasePanel";
import gm from "../../../../manager/GameManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/dungeon/UnionDungeonClearPanel")
export default class UnionDungeonClearPanel extends PopupPanel {

    @property(cc.Label)
    udgProgValue: cc.Label = null;

    @property(cc.Node)
    reward: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    protected _callFunc: Function = null;
    protected _reward: number[][] = [];
    protected _udgValue: number = 0;
    onInit(data: any) {
        super.onInit(data);
        if (data) {
            this._callFunc = data.callback;
            this._reward = data.reward;
            this._udgValue = data.value;
        }
    }
    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
        this.heroItem.parent = null;
        this.equipItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
        this.heroItem.destroy();
        this.equipItem.destroy();
    }

    start() {
        super.start();

        this.udgProgValue.string = `${this._udgValue}%`;
        this.reward.destroyAllChildren();
        let data: number[][] = this._reward || [];
        for (let i = 0; i < data.length; i++) {
            gm.showGoodItem(data[i], {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem,
            }, this.reward, 1);
        }
    }

    onClickConfirm() {
        if (this._callFunc) { this._callFunc(); }
        this.closePanel();
    }

}
