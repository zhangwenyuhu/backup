import { PopupPanel } from "../../BasePanel";
import EManager, { EName } from "../../../../manager/EventManager";
import udgLogic from "../../../../logics/UnionDungeonLogic";
import CommonLoader from "../../../common/CommonLoader";
import HeroCard from "../../../component/Hero/HeroCard";
import gm from "../../../../manager/GameManager";
import loadUtils from "../../../../utils/LoadUtils";
import commonUtils from "../../../../utils/CommonUtils";
import DungeonNpc from "../../../component/Union/DungeonNpc";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/dungeon/UnionDungeonMonsterPanel")
export default class UnionDungeonMonsterPanel extends PopupPanel {

    @property(cc.Label)
    npcName: cc.Label = null;

    @property(cc.Node)
    udgNpc: cc.Node = null;

    @property(cc.Label)
    npcProg: cc.Label = null;

    @property(cc.Label)
    npcFightTimes: cc.Label = null;

    @property(cc.Label)
    npcBuffDesc: cc.Label = null;

    @property(cc.Label)
    suggestPower: cc.Label = null;

    @property(cc.Label)
    rewardScore: cc.Label = null;

    @property(cc.Node)
    npcHero: cc.Node = null;

    @property(cc.Node)
    fightReward: cc.Node = null;

    @property(cc.Node)
    btnAutoFight: cc.Node = null;

    @property(cc.Node)
    diffTab: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    protected _pos: number = 1;
    protected _diff: number = 1;
    protected async _preloadRes() {
        await super._preloadRes();

        await udgLogic.unionDungeonSimpleReq();
    }
    onInit(data: any) {
        this._pos = data ? data.pos : this._pos;
        this._diff = data ? data.diff : this._diff;
    }

    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
        this.heroItem.parent = null;
        this.equipItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
        this.heroItem.destroy();
        this.equipItem.destroy();
    }

    async start() {
        super.start();
        await udgLogic.udgClearResultReq(this._pos, this._diff);

        this.registerEvent();
        this.refreshView();
    }

    protected registerEvent() {
        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data === "UnionDungeonMonsterPanel") {
                this.refreshView(true);
            }
        })
        this._eventListeners.push(listener);
    }

    protected onTabClick(event: cc.Event.EventTouch, index: string) {
        let diff: number = parseInt(index);
        if (this._diff == diff) { return; }

        this._diff = diff;
        this.refreshView();
    }

    protected async refreshView(req?: boolean) {
        if (req) {
            await udgLogic.unionDungeonSimpleReq();
            EManager.emit(EName.onFreshPanel, 'UnionDungeonMainPanel');
        }

        let npc = udgLogic.getDungeonMonster(this._pos);
        if (!npc) { console.error('副本信息未找到'); return; }
        let data = npc.getMonster(this._diff);
        if (!data) { console.error('怪物信息未找到'); return; }

        this.npcName.string = data.getTitle();
        let comp = this.udgNpc.getComponent(CommonLoader).loaderNode.getComponent(DungeonNpc);
        comp.refresh(npc);

        let prog: number = npc.getNpcProg();
        prog = prog > 100 ? 100 : prog;
        this.npcProg.string = `${prog}%`;

        let leftTimes = udgLogic.getUdgFightMaxTimes() - udgLogic.getTodayFightTimes();
        this.npcFightTimes.string = `${leftTimes}/${udgLogic.getUdgFightMaxTimes()}`;

        this.suggestPower.string = slib.BigNumberHelper.convertNumStr2UnitStr(data.getTotalPower().toString(), 0, 2);
        this.rewardScore.string = `${data.getUdgScore()}`;

        this.btnAutoFight.active = npc.canAutoFight(this._diff);

        this.npcHero.destroyAllChildren();
        let heros = data.getMonster();
        for (let i = 0; i < heros.length; i++) {
            let tmp = cc.instantiate(this.heroItem);
            tmp.parent = this.npcHero;
            tmp.scale = 0.88;
            let comp = tmp.getComponent(CommonLoader).loaderNode.getComponent(HeroCard);
            comp.refresh(heros[i]);
        }

        let reward = data.getFightReward();
        this.fightReward.destroyAllChildren();
        for (let i = 0; i < reward.length; i++) {
            gm.showGoodItem(reward[i], {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem,
            }, this.fightReward, 1);
        }
    }

    protected onClickFight() {
        if (!this._canFight()) { return; }
        let npc = udgLogic.getDungeonMonster(this._pos);
        let battleData = npc.getMonster(this._diff);
        gcc.core.showLayer("prefabs/panel/battle/BattlePreparePanel", { data: battleData });
    }

    protected onClickAutoFight() {
        if (!this._canFight()) { return; }

        let clearData = udgLogic.getUdgClearData(this._pos, this._diff);
        let reward = udgLogic.getUdgFightReward(this._diff, clearData[0], clearData[1]);
        let score = udgLogic.getKillScore(this._diff, clearData[0], clearData[1]);
        let total = udgLogic.udgScoreCof.totalscore;
        let value = Math.floor(score * 100 / total);
        gcc.core.showLayer("prefabs/panel/union/dungeon/UnionDungeonClearPanel", {
            data: {
                value: value,
                reward: reward,
                callback: () => {
                    this.doCommitUdgFight(clearData[0], clearData[1])
                }
            }
        });
    }

    protected async doCommitUdgFight(boss: number, normal: number) {
        try {
            let proto = await udgLogic.commitDungeonBattleResult(this._pos, this._diff, boss, normal);
            gm.getReward(proto);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }

        this.refreshView();
        EManager.emit(EName.onFreshPanel, 'UnionDungeonMainPanel');
    }

    protected _canFight(): boolean {
        let now = udgLogic.getTodayFightTimes();
        let total = udgLogic.getUdgFightMaxTimes();
        if (now >= total) { gm.toast('挑战次数已用完'); return false; }
        let npc = udgLogic.getDungeonMonster(this._pos);
        if (npc.getNpcProg() >= 100 && !udgLogic.isAllComplete()) { gm.toast('副本怪物已讨伐,请选择其他怪物'); return false; }

        return true;
    }
}
