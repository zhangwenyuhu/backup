import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from "../BasePanel";
import Union, { UnionEnterMode } from "../../../data/union/Union";
import { RefreshSprite, RefreshLabel } from "../../../decorator/RefreshDecorator";
import UnionInfoPanel from "./UnionInfoPanel";
import loadUtils from "../../../utils/LoadUtils";
import List from '../../common/List';
import unionLogic from '../../../logics/UnionLogic';
import UnionMemberItem from '../../widget/union/UnionMemberItem';
import gm from '../../../manager/GameManager';
import playerLogic from '../../../logics/PlayerLogic';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/UnionJoinPanel")
export default class UnionJoinPanel extends PopupPanel {
    @RefreshSprite({
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return caller.getAvatar() },
        updateSpriteFrame: (sprite: cc.Sprite, value: number) => {
            loadUtils.loadSpriteFrame(`textures/ui/panel/union/union_avatar_icon${value}`, sprite);
        }
    })
    @property(cc.Sprite)
    spriteAvatar: cc.Sprite = null;

    @RefreshLabel({
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return `Lv.${caller.getLevel()}` }
    })
    @property(cc.Label)
    labelLevel: cc.Label = null;

    @RefreshLabel({
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return caller.getCurActiveScore() }
    })
    @property(cc.Label)
    labelScore: cc.Label = null;

    @RefreshLabel({
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return caller.getName() }
    })
    @property(cc.Label)
    labelName: cc.Label = null;

    @RefreshLabel({
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return `ID ${caller.getId()}` }
    })
    @property(cc.Label)
    labelID: cc.Label = null;

    @RefreshLabel({
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return caller.getNotice() }
    })
    @property(cc.Label)
    labelNotice: cc.Label = null;

    @RefreshLabel({
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => {
            let lv = caller.getEnterLevel();
            if (lv <= 0) { return stringConfigMap.key_exchange_text3.Value; }
            return lv;
        }
    })
    @property(cc.Label)
    labelMinLevel: cc.Label = null;

    @RefreshLabel({
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return `${caller.getMembers().length}/${caller.getMaxMembers()}` }
    })
    @property(cc.Label)
    labelMember: cc.Label = null;

    @RefreshLabel({
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => {
            return stringConfigMap[`key_union_enter_mode${caller.getEnterMode()}`].Value;
        }
    })
    @property(cc.Label)
    labelEnterMode: cc.Label = null;

    @property(cc.Label)
    labelLang: cc.Label = null;

    @property(List)
    memberList: List = null;

    @property(cc.Node)
    btnJoin: cc.Node = null;

    union: Union = null;
    callback: Function = null;

    onInit(data: { union: Union, callback: Function }) {
        super.onInit(data);
        this.union = data.union;
        this.callback = data.callback;
    }

    start() {
        super.start();

        this.memberList.getComponent(cc.Widget).updateAlignment();
        this.memberList.numItems = this.union.getMembers().length;
        if (playerLogic.getPlayer().isInUnion()) {
            this.btnJoin.active = false;
        }

        if (this.btnJoin.active) {
            let model = this.union.getEnterMode();
            let joinText: string = '';
            if (model == UnionEnterMode.All) {
                joinText = stringConfigMap.key_quickjoin.Value;
            } else {
                joinText = stringConfigMap.key_applyjoin.Value;
            }
            this.btnJoin.getComponentInChildren(cc.Label).string = joinText;
        }
    }

    updateMemberItem(node: cc.Node, index: number) {
        let members = this.union.getMembers();
        let item = node.getComponent(UnionMemberItem);
        item.updateView(members[index], this.union.getPresident(), index);
    }

    async onJoin() {
        try {
            let unions = await unionLogic.doJoinUnion(this.union);
            if (this.callback) { this.callback(unions); }
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}
