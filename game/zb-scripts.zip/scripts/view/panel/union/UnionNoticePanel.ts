import { PopupPanel } from "../BasePanel";
import gm from "../../../manager/GameManager";
import unionLogic from "../../../logics/UnionLogic";
import { stringConfigMap } from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/UnionNoticePanel")
export default class UnionNoticePanel extends PopupPanel {
    @property(cc.EditBox)
    editBox: cc.EditBox = null;

    start() {
        super.start();
        this.editBox.string = unionLogic.getUnion().getNotice();
    }

    async onConfirm() {
        try {
            await unionLogic.doChangeNotice(this.editBox.string);
            gm.toast(stringConfigMap.key_modify_success.Value);
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
                unionLogic.doRefreshUnion();
                this.closePanel();
            }
            else {
                throw e;
            }
        }
    }
}
