import {PopupPanel} from "../BasePanel";
import unionLogic from "../../../logics/UnionLogic";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/UnionHuntRecordPanel")
export default class UnionHuntRecordPanel extends PopupPanel {

    @property(cc.Node)
    scrollView: cc.Node = null;

    async start() {
        super.start();
        await unionLogic.doGetHuntRecord();
        this.scrollView.getComponent(ScrollViewLoader).refresh(unionLogic.unionHuntRecord);
    }

}