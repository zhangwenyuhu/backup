import { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import RedPack from "../../../data/union/RedPack";
import unionLogic from "../../../logics/UnionLogic";
import gm from "../../../manager/GameManager";
import GameProxy, { RoleVO } from "../../../proxy/GameProxy";
import User from "../../../data/user/User";
import loadUtils from "../../../utils/LoadUtils";
import commonUtils from "../../../utils/CommonUtils";

const { ccclass, property, menu } = cc._decorator;

// 红包信息
@ccclass
@menu("view/panel/union/RedPackLogPanel")
export default class RedPackLogPanel extends cc.Component {

    @property(List)
    packLogList: List = null;

    @property(cc.Node)
    goodIcon: cc.Node = null;

    @property(cc.Label)
    goodNum: cc.Label = null;

    @property(cc.Label)
    recvNum: cc.Label = null;

    @property(cc.Label)
    totalNum: cc.Label = null;

    protected _redpack: RedPack = null;
    protected _recvInfo: string[][] = [];
    onInit(data: any) {
        this._redpack = data || [];
    }

    start() {
        //super.start();
        if (!this._redpack) { return; }
        this._recvInfo = this._redpack.getRecvInfo();
        this._recvInfo.sort((a, b) => {
            let nA = parseInt(a[1]);
            let nB = parseInt(b[1]);
            return nB - nA;
        })
        this.packLogList.getComponent(cc.Widget).updateAlignment();
        this.packLogList.numItems = this._recvInfo.length;

        let goodId = this._redpack.getGoodId();
        loadUtils.loadSpriteFrame(commonUtils.getGoodIconUrl(goodId), this.goodIcon.getComponent(cc.Sprite));
        this.goodNum.string = `${this._redpack.getRecvAmt()}`;

        this.totalNum.string = `${this._redpack.getTotalAmt()}`;
        let totalCount: number = this._redpack.getTotalNum()
        let recvCount: number = totalCount - this._redpack.getLeftNum();
        this.recvNum.string = `${recvCount}/${totalCount}`;
    }

    async onItemRender(item: cc.Node, index: number) {
        let data = this._recvInfo[index];
        let player = await this.getPlayer(data[0]);
        let goodId = this._redpack.getGoodId();

        let name = player ? player.getNickname() : data[0];
        item.getChildByName("name").getComponent(cc.Label).string = name;
        let icon = item.getChildByName("good").getChildByName("icon");
        let costNum = item.getChildByName("good").getChildByName("num");
        loadUtils.loadSpriteFrame(commonUtils.getGoodSIconUrl(goodId), icon.getComponent(cc.Sprite));
        costNum.getComponent(cc.Label).string = data[1];
    }

    async getPlayer(id: string) {
        let player = unionLogic.getUnion().getMember(id);
        if (!player) {
            let playerProto = await gm.request<RoleVO>(GameProxy.apiRolegetRole, id);
            if (playerProto) {
                return new User(playerProto);
            } else {
                return null;
            }

        } else {
            return player;
        }
    }
}
