import { PopupPanel } from "../BasePanel";
import Good, { GoodId, GoodType } from "../../../data/card/Good";
import commonUtils from "../../../utils/CommonUtils";
import loadUtils from "../../../utils/LoadUtils";
import RedTask from "../../../data/assignment/RedTask";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/PackSendPanel")
export default class PackSendPanel extends PopupPanel {

    @property(cc.Label)
    pack_num: cc.Label = null;

    @property(cc.Node)
    pack_icon: cc.Node = null;

    @property(cc.Label)
    pack_amt: cc.Label = null;


    protected _redTask: RedTask = null;
    protected _callback: Function = null;

    onInit(data: any) {
        if (data) {
            this._redTask = data.task;
            this._callback = data.callback;
        }
    }

    async start() {
        super.start();

        if (this._redTask) {
            this.pack_num.string = `${this._redTask.getPackRecvNum()}`;
            this.pack_amt.string = `${this._redTask.getPackAmt()}`;
            loadUtils.loadSpriteFrame(commonUtils.getGoodSIconUrl(GoodId.Diamond), this.pack_icon.getComponent(cc.Sprite));
        }
    }

    async onUse() {
        if (this._callback) { this._callback(); }
        this.closePanel();
    }
}
