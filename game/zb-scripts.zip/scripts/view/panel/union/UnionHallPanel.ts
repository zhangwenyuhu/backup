import { FullscreenPanel } from "../BasePanel";
import { StoreTab } from "../store/StorePanel";
import gm from "../../../manager/GameManager";
import { ShopVO } from "../../../proxy/GameProxy";
import GameProxy from "../../../proxy/GameProxy";
import shopLogic from "../../../logics/ShopLogic";
import timeUtils from "../../../utils/TimeUtils";
import commonUtils from "../../../utils/CommonUtils";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/UnionHallPanel")
export default class UnionHallPanel extends FullscreenPanel {

    @property(cc.Node)
    huntingNode: cc.Node = null;

    @property(cc.Node)
    huntingTip: cc.Node = null;

    @property(cc.Label)
    timeLabel: cc.Label = null;

    async start() {
        let shopProto = await gm.request<ShopVO>(GameProxy.apiShopgetShopDetail, "GuildShop");
        shopLogic.init(shopProto, gm);
        this.unschedule(this.onShowTime);
        this.onShowTime();
        let time = shopLogic.getRefreshTs() - gm.getCurrentTimestamp();
        let day = time / 1000 / 3600;
        if (day > 24) {
            this.timeLabel.string = `${Math.floor(day / 24)}天${Math.floor(day % 24)}小时`;
        } else {
            this.schedule(this.onShowTime, 1);
        }
    }

    onShowTime() {
        let time = shopLogic.getRefreshTs() - gm.getCurrentTimestamp();
        this.timeLabel.string = timeUtils.formatTime(time / 1000);
        if (time <= 0) {
            this.unschedule(this.onShowTime);
        }
    }

    onHunt() {
        gcc.core.showLayer("prefabs/panel/union/UnionHuntPanel");
    }

    onStore() {
        gm.toast(stringConfigMap.key_auto_580.Value);
        //gcc.core.showLayer("prefabs/panel/store/StorePanel", { data: StoreTab.Union });
    }

    protected async _preloadRes() {
        await super._preloadRes();
        this._unloadInfos.push({ url: commonUtils.getBgUrl("arena_bg"), type: cc.SpriteFrame });
    }
}