import { PopupPanel } from "../BasePanel";
import { ZhuanPanType } from "../../../utils/DefineUtils";
import loadUtils from "../../../utils/LoadUtils";
import commonUtils from "../../../utils/CommonUtils";
import gm from "../../../manager/GameManager";
import zpLogic from "../../../logics/ZhuanPanLogic";
import { unlockConfigMap } from "../../../configs/unlockConfig";
import zhuanpanTip from "../../component/zhuanpanTip";
import CommonLoader from "../../common/CommonLoader";

const { ccclass, property, menu } = cc._decorator;

type ZhuanpanIcon = {
    type: ZhuanPanType,
    img: string,
    unlock: Function,
    prefab: string,
    tip: string,
}

let zhuanpans: ZhuanpanIcon[] = [
    {
        type: ZhuanPanType.Normal,
        img: `zhuanpan_normal`,
        unlock: () => { return true; },
        prefab: `ZhuanPanPanel`,
        tip: "",
    },
    {
        type: ZhuanPanType.Better,
        img: `zhuanpan_better`,
        unlock: () => { return zpLogic.isUnlockBetterZhuanPan(); },
        prefab: `ZhuanPanPanel`,
        tip: 'VIP3解锁',
    }
]

@ccclass
@menu("view/panel/union/ZhuanPanSelectPanel")
export default class ZhuanPanSelectPanel extends PopupPanel {

    @property(cc.Node)
    zhuanpanList: cc.Node = null;

    @property(cc.Node)
    zpNormal: cc.Node = null;

    @property(cc.Node)
    zpAdvance: cc.Node = null;

    @property(cc.Node)
    zpTip: cc.Node = null;

    @property(cc.Material)
    normalMaterial: cc.Material = null;

    @property(cc.Material)
    grayMaterial: cc.Material = null;

    onLoad() {
        super.onLoad();
    }

    onDestroy() {
        super.onDestroy();
    }

    start() {
        super.start();
        this.initZhuanPanSelect();
        this.updateZhuanPanTip();
    }

    protected updateZhuanPanTip() {
        let loader = this.zpTip.getComponent(CommonLoader).loaderNode;
        loader.getComponent(zhuanpanTip).refresh(zpLogic.getZpHeroId());
    }

    protected initZhuanPanSelect() {
        this.zpNormal.getComponent(cc.Button).clickEvents[0].customEventData = `${ZhuanPanType.Normal}`;
        this.freshSelect(this.zpNormal, zhuanpans[0]);
        this.zpAdvance.getComponent(cc.Button).clickEvents[0].customEventData = `${ZhuanPanType.Better}`;
        this.freshSelect(this.zpAdvance, zhuanpans[1])
    }

    protected freshSelect(node: cc.Node, data: ZhuanpanIcon) {
        let imageNode = node.getChildByName("image");
        loadUtils.loadSpriteFrame(commonUtils.getPanelIconUrl("zhuanpan", data.img), imageNode.getComponent(cc.Sprite));
        let mat = data.unlock() ? this.normalMaterial : this.grayMaterial;
        imageNode.getComponent(cc.Sprite).setMaterial(0, mat);

        let lockNode = node.getChildByName("lock");
        lockNode.active = !data.unlock();

        let descNode = node.getChildByName("desc").getComponent(cc.Label);
        descNode.node.active = !data.unlock();
        descNode.string = data.tip;
    }

    onClickZhuanPanSelect(event: cc.Event.EventTouch, index: string) {
        let type = parseInt(index);
        let data = zhuanpans.find((a) => { return a.type == type; });
        if (!data) { return; }
        if (!data.unlock()) { gm.toast(data.tip); return; }

        gcc.core.showLayer("prefabs/panel/union/ZhuanPanPanel", { data: type });
        this.closePanel();
    }
}
