import { UnionPermission } from './../../../logics/UnionLogic';
import { stringConfigMap } from './../../../configs/stringConfig';
import { RefreshLabel, RefreshSprite, RefreshNode, RefreshProgressBar } from './../../../decorator/RefreshDecorator';
import BasePanel, { FullscreenPanel } from "../BasePanel";
import Good from "../../../data/card/Good";
import bagLogic from '../../../logics/BagLogic';
import Union from '../../../data/union/Union';
import unionLogic from '../../../logics/UnionLogic';
import loadUtils from '../../../utils/LoadUtils';
import User from '../../../data/user/User';
import Player from '../../../data/user/Player';
import playerLogic from '../../../logics/PlayerLogic';
import UnionMemberItem from '../../widget/union/UnionMemberItem';
import Member from '../../../data/union/Member';
import List from '../../common/List';
import EManager, { EName } from '../../../manager/EventManager';
import gm from '../../../manager/GameManager';
import commonUtils from '../../../utils/CommonUtils';
import stringUtils from '../../../utils/StringUtils';
import promptLogic, { PromptType } from '../../../logics/PromptLogic';
import { CommonAdd } from '../../../utils/DefineUtils';
import heroLogic from '../../../logics/HeroLogic';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/UnionInfoPanel")
export default class UnionInfoPanel extends FullscreenPanel {
    @property(cc.Label)
    labelPower: cc.Label = null;

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: (caller: UnionInfoPanel) => { return caller.gold },
        getValue: (caller: Good) => { return caller.getAmount() },
        getString: (value: string) => { return slib.BigNumberHelper.convertNumStr2UnitStr(value.toString(), 0, 0) }
    })
    @property(cc.Label)
    labelGold: cc.Label = null;

    @RefreshLabel({
        eventName: Good.Event.onAmountDirty,
        getData: (caller: UnionInfoPanel) => { return caller.diamond },
        getValue: (caller: Good) => { return caller.getAmount() },
        getString: (value: number) => { return slib.BigNumberHelper.convertNumStr2UnitStr(value.toString(), 0, 0) }
    })
    @property(cc.Label)
    labelDiamond: cc.Label = null;

    @property(List)
    memberList: List = null;

    @RefreshSprite({
        eventName: Union.Event.onAvatarDirty,
        getData: (caller: UnionInfoPanel) => { return caller.union },
        refresh: async (sprite: cc.Sprite, union: Union) => {
            let spriteFrame = await loadUtils.loadRes(`textures/ui/panel/union/union_avatar_icon${union.getAvatar()}`, cc.SpriteFrame) as cc.SpriteFrame;
            if (cc.isValid(sprite)) {
                sprite.spriteFrame = spriteFrame;
            }
        }
    })
    @property(cc.Sprite)
    spriteAvatar: cc.Sprite = null;

    @RefreshLabel({
        eventName: Union.Event.onLevelDirty,
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return caller.getLevel() },
        getString: (value: number) => { return `Lv.${value}` }
    })
    @property(cc.Label)
    labelLevel: cc.Label = null;

    @RefreshLabel({
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return caller.getId() }
    })
    @property(cc.Label)
    labelId: cc.Label = null;

    @RefreshLabel({
        eventName: Union.Event.onNameDirty,
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return caller.getName() }
    })
    @property(cc.Label)
    labelName: cc.Label = null;

    @RefreshLabel({
        eventName: Union.Event.onCurActiveScoreDirty,
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return caller.getCurActiveScore() }
    })
    @property(cc.Label)
    labelActiveScore: cc.Label = null;

    @RefreshNode({
        eventName: User.Event.onUnionJobDirty,
        getData: (caller: UnionInfoPanel) => { return caller.player },
        refresh: (node: cc.Node, player: Player) => {
            node.active = unionLogic.hasPermission(UnionPermission.AllowApply);
        }
    })
    @property(cc.Node)
    btnApply: cc.Node = null;

    @RefreshNode({
        eventName: User.Event.onUnionJobDirty,
        getData: (caller: UnionInfoPanel) => { return caller.player },
        refresh: (node: cc.Node, player: Player) => {
            node.active = unionLogic.hasPermission(UnionPermission.ChangeNotice);
        }
    })
    @property(cc.Node)
    btnNotice: cc.Node = null;

    @RefreshNode({
        eventName: User.Event.onUnionJobDirty,
        getData: (caller: UnionInfoPanel) => { return caller.player },
        refresh: (node: cc.Node, player: Player) => {
            node.active = unionLogic.hasPermission(UnionPermission.ChangeName);
        }
    })
    @property(cc.Node)
    btnSet: cc.Node = null;

    @RefreshNode({
        eventName: User.Event.onUnionJobDirty,
        getData: (caller: UnionInfoPanel) => { return caller.player },
        refresh: (node: cc.Node, player: Player) => {
            node.active = unionLogic.hasPermission(UnionPermission.SendUnionMail);
        }
    })
    @property(cc.Node)
    btnMail: cc.Node = null;

    @RefreshNode({
        eventName: User.Event.onUnionJobDirty,
        getData: (caller: UnionInfoPanel) => { return caller.player },
        refresh: (node: cc.Node, player: Player) => {
            node.active = unionLogic.hasPermission(UnionPermission.UnionExit);
        }
    })
    @property(cc.Node)
    btnExit: cc.Node = null;

    @RefreshNode({
        eventName: User.Event.onUnionJobDirty,
        getData: (caller: UnionInfoPanel) => { return caller.player },
        refresh: (node: cc.Node, player: Player) => {
            node.active = unionLogic.hasPermission(UnionPermission.DismissUnion);
        }
    })
    @property(cc.Node)
    btnDismiss: cc.Node = null;

    @RefreshProgressBar({
        eventName: Union.Event.onCurActiveScoreDirty,
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => {
            if (caller.nextLevelPoint > 0) {
                return caller.curLevelPoint;
            }
            else {
                return 1;
            }
        },
        getTotal: (caller: Union) => {
            if (caller.nextLevelPoint > 0) {
                return caller.nextLevelPoint;
            }
            else {
                return 1;
            }
        }
    })
    @property(cc.ProgressBar)
    progressBar: cc.ProgressBar = null;

    @RefreshLabel({
        eventName: Union.Event.onCurActiveScoreDirty,
        getData: (caller: UnionInfoPanel) => { return caller.union },
        refresh: (label: cc.Label, union: Union) => {
            if (union.nextLevelPoint > 0) {
                label.string = `${union.curLevelPoint}/${union.nextLevelPoint}`;
            }
            else {
                label.string = stringConfigMap.key_max_level2.Value;
            }
        }
    })
    @property(cc.Label)
    labelProgress: cc.Label = null;

    @RefreshLabel({
        eventName: Union.Event.onNoticeDirty,
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return caller.getNotice() }
    })
    @property(cc.Label)
    labelNotice: cc.Label = null;

    @RefreshLabel({
        eventName: Union.Event.onMemberDirty,
        getData: (caller: UnionInfoPanel) => { return caller.union },
        getValue: (caller: Union) => { return `${caller.getMembers().length}/${caller.getMaxMembers()}` }
    })
    @property(cc.Label)
    labelMember: cc.Label = null;

    @property(cc.Node)
    nodeManager: cc.Node = null;

    @property(cc.Node)
    unionHelpTimes: cc.Node = null;

    @property(cc.Node)
    maxTimes: cc.Node = null;

    gold: Good = null;
    diamond: Good = null;
    union: Union = null;
    player: Player = null;

    protected _members: Member[] = [];

    onLoad() {
        super.onLoad();
        this.gold = bagLogic.getGood(Good.GoodId.Gold);
        this.diamond = bagLogic.getGood(Good.GoodId.Diamond);
        this.union = unionLogic.getUnion();
        this.player = playerLogic.getPlayer();

        this.nodeManager.active = false;

        this.registerEvents();
        this.freshUI();
    }

    registerEvents() {
        let listener = EManager.addEvent(Union.Event.onMemberDirty, (data: { target: Union }) => {
            if (this.union == data.target) {
                this._members = this.union.getMembers(true);
                this.memberList.numItems = this._members.length;
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data == "UnionInfoPanel") {
                this.freshUI();
            }
        });
        this._eventListeners.push(listener);
    }

    freshUI() {
        this.memberList.numItems = this._members.length;

        let self = this.union.getMember(playerLogic.getPlayer().getRoleId());
        let max = this.union.getMaxHelpTimes();
        let left = max - self.getSendHelp();
        this.unionHelpTimes.getComponent(cc.Label).string = `${left}`;
        this.unionHelpTimes.color = cc.Color.WHITE.fromHEX("d5d1cf");
        if (left == 0) { this.unionHelpTimes.color = cc.Color.RED; }
        this.maxTimes.getComponent(cc.Label).string = `/${max}`;
    }

    start() {
        super.start();

        this._members = this.union.getMembers(true);
        this.memberList.getComponent(cc.Widget).updateAlignment();
        this.memberList.numItems = this._members.length;
        this.labelPower.string = this.player.getPower().toString();
    }

    updateMemberItem(node: cc.Node, index: number) {
        let item = node.getComponent(UnionMemberItem);
        item.updateView(this._members[index], this.union.getPresident(), index);
    }

    /**入会申请 */
    onApply() {
        gcc.core.showLayer("prefabs/panel/union/UnionApplyPanel");
    }

    /**修改公告 */
    onNotice() {
        gcc.core.showLayer("prefabs/panel/union/UnionNoticePanel");
    }

    /**信息设置 */
    onSet() {
        gcc.core.showLayer("prefabs/panel/union/UnionSetPanel");
    }

    /**全员邮件 */
    onMail() {
        gcc.core.showLayer("prefabs/panel/union/UnionMailPanel");
    }

    /**查找公会 */
    onFind() {
        gcc.core.showLayer("prefabs/panel/union/UnionListPanel");
    }

    /**退出公会 */
    onExit() {
        gm.dialog({
            content: stringConfigMap.key_sure_to_exit_union.Value,
            confirm: async () => {
                try {
                    await unionLogic.doExitUnion();
                    playerLogic.getPlayer().updateCommonAdd([], CommonAdd.statuePart1);
                    playerLogic.getPlayer().updateCommonAdd([], CommonAdd.statuePart2);
                    playerLogic.getPlayer().updateCommonAdd([], CommonAdd.statuePart3);
                    playerLogic.getPlayer().setPowerDirty();
                    heroLogic.updateHeroCommonAdd();
                    BasePanel.closePanel("UnionHallNewPanel");
                    this.closePanel();
                } catch (e) {
                    if (e.name == "ToastError") {
                        gm.toast(e.message);
                        unionLogic.doRefreshUnion();
                    }
                    else {
                        throw e;
                    }
                }
            }
        })
    }

    /**解散公会 */
    onDismiss() {
        gm.dialog({
            content: stringConfigMap.key_sure_to_dismiss_union.Value,
            confirm: async () => {
                try {
                    let name = await unionLogic.doDismissUnion();
                    gm.toast(stringUtils.getString(stringConfigMap.key_union_dismiss.Value, { name: name }));
                    BasePanel.closePanel("UnionHallNewPanel");
                    this.closePanel();
                    playerLogic.getPlayer().updateCommonAdd([], CommonAdd.statuePart1);
                    playerLogic.getPlayer().updateCommonAdd([], CommonAdd.statuePart2);
                    playerLogic.getPlayer().updateCommonAdd([], CommonAdd.statuePart3);
                    playerLogic.getPlayer().setPowerDirty();
                    heroLogic.updateHeroCommonAdd();
                    gcc.core.showLayer("prefabs/panel/union/UnionListPanel");

                    promptLogic.setPromptRead([PromptType.UNION_HUNT_NORMAL]);
                    promptLogic.setPromptRead([PromptType.UNION_HUNT_ADVANCE]);
                    EManager.emit(EName.onRedDirty, 3600);
                } catch (e) {
                    if (e.name == "ToastError") {
                        gm.toast(e.message);
                        unionLogic.doRefreshUnion();
                    }
                    else {
                        throw e;
                    }
                }
            }
        })
    }

    /**管理 */
    onManage() {
        this.nodeManager.active = !this.nodeManager.active;
    }

    /**公会日志 */
    onLog() {

    }

    /**公会大厅 */
    onHall() {
        this.closePanel();
        gcc.core.showLayer("prefabs/panel/union/UnionHallNewPanel");
    }

    onTip() {
        let union = unionLogic.getUnion();
        let send: number = union.getMaxHelpTimes();
        let recv: number = union.getMaxRecvTimes();
        let tip = `公会成员每日可以赠送礼物${send}次,接受礼物${recv}次.\n赠送礼物自己也可以获得相应奖励`;
        gm.toast(tip);
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("union_bg"), type: cc.SpriteFrame });
    }
}
