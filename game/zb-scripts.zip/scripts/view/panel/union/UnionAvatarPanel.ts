import { PopupPanel } from "../BasePanel";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/union/UnionAvatarPanel")
export default class UnionAvatarPanel extends PopupPanel {
    @property(cc.SpriteFrame)
    avatarSpriteFrames: cc.SpriteFrame[] = [];

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    item: cc.Node = null;

    protected _selectIndex: number = -1;
    protected _callback: Function = null;

    onInit(data: { index: number, callback: Function }) {
        super.onInit(data);
        this._selectIndex = data.index;
        this._callback = data.callback;
    }

    onLoad() {
        super.onLoad();
        this.item.parent = null;
    }

    start() {
        super.start();

        for (let i = 0; i < this.avatarSpriteFrames.length; i++) {
            let item = cc.instantiate(this.item);
            item.parent = this.content;

            let bg = item.getChildByName("bg");
            bg.active = this._selectIndex == i;

            let img = item.getChildByName("img");
            img.getComponent(cc.Sprite).spriteFrame = this.avatarSpriteFrames[i];

            let select = item.getChildByName("select");
            select.active = this._selectIndex == i;

            item.on("click", () => { this._onSelect(i); }, this);
        }
    }

    onConfirm() {
        if (this._callback) {
            this._callback(this._selectIndex);
        }
        this.closePanel();
    }

    protected _onSelect(index: number) {
        if (this._selectIndex == index) {
            return;
        }

        let child = this.content.children[this._selectIndex];
        if (child) {
            let bg = child.getChildByName("bg");
            bg.active = false;

            let select = child.getChildByName("select");
            select.active = false;
        }

        this._selectIndex = index;

        child = this.content.children[this._selectIndex];

        let bg = child.getChildByName("bg");
        bg.active = true;

        let select = child.getChildByName("select");
        select.active = true;
    }
}
