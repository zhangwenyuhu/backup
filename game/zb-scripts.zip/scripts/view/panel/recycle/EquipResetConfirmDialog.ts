import { defaultConfigMap } from './../../../configs/defaultConfig';
import { PopupPanel } from "../BasePanel";
import gm from "../../../manager/GameManager";
import PopBg from "../../component/PopBg";
import CommonLoader from "../../common/CommonLoader";
import bagLogic from "../../../logics/BagLogic";
import Good from "../../../data/card/Good";
import stringUtils from "../../../utils/StringUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import PlayerEquip from "../../../data/card/PlayerEquip";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/recycle/EquipResetConfirmDialog")
export default class EquipResetConfirmDialog extends PopupPanel {

    @property(CommonLoader)
    dialog: CommonLoader = null;

    @property(cc.Label)
    labelDiamond: cc.Label = null;

    equip: PlayerEquip = null;
    success: Function = null;

    onInit(data: { equip: PlayerEquip, success: Function }) {
        super.onInit(data);
        this.equip = data.equip;
        this.success = data.success;
    }

    start() {
        super.start();

        let comp = this.dialog.loaderNode.getComponent(PopBg);
        comp.closeCallback = () => { this.closePanel() };

        this.labelDiamond.string = `${defaultConfigMap.equipreborncost.value}`;
    }

    async onReset() {
        try {
            let cards = await bagLogic.doResetEquip(this.equip);
            if (this.success) this.success(cards);
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                if (e.message == stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: bagLogic.getGood(Good.GoodId.Diamond).getName() })) {
                    gm.diamondLessToast();
                    this.closePanel();
                }
                else {
                    gm.toast(e.message);
                }
            }
            else {
                throw e;
            }
        }
    }
}
