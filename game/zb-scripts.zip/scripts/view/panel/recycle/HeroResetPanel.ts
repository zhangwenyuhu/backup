import { stringConfigMap } from './../../../configs/stringConfig';
import heroLogic from "../../../logics/HeroLogic";
import { HeroSelect } from "../../widget/hero/HeroSelectItem";
import { RefreshNode, RefreshLabel } from "../../../decorator/RefreshDecorator";
import EManager, { EListener } from "../../../manager/EventManager";
import HeroResetPreview from '../../widget/hero/HeroResetPreview';
import HeroSelectLockItem from "../../widget/hero/HeroSelectLockItem";
import List from '../../common/List';
import Card from '../../../data/card/Card';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/recycle/HeroResetPanel")
export default class HeroResetPanel extends cc.Component {

    @RefreshNode({
        eventName: HeroSelect.Event.onSelectDirty,
        getData: (caller: HeroResetPanel) => { return caller.heroSelect },
        refresh: (node: cc.Node, heroSelect: HeroSelect) => {
            let button = node.getComponent(cc.Button)
            button.interactable = heroSelect.isSelect;

            let diamond = node.getChildByName("diamond");
            diamond.active = heroSelect.isSelect;
        }
    })
    @property(cc.Node)
    btnReset: cc.Node = null;

    @property(cc.Label)
    labelHeroCounts: cc.Label = null;

    @property(List)
    heroList: List = null;

    @RefreshNode({
        eventName: HeroSelect.Event.onSelectDirty,
        getData: (caller: HeroResetPanel) => { return caller.heroSelect },
        refresh: (node: cc.Node, heroSelect: HeroSelect) => {
            node.active = !heroSelect.isSelect;
        }
    })
    @property(cc.Node)
    tipNode: cc.Node = null;

    @RefreshNode({
        eventName: HeroSelect.Event.onSelectDirty,
        getData: (caller: HeroResetPanel) => { return caller.heroSelect },
        refresh: (node: cc.Node, heroSelect: HeroSelect) => {
            node.active = heroSelect.isSelect;
            if (node.active) {
                let comp = node.getComponent(HeroResetPreview);
                comp.refresh(heroSelect);
            }
        }
    })
    @property(cc.Node)
    previewNode: cc.Node = null;

    @RefreshLabel({
        getData: () => { return heroLogic },
        getValue: () => { return heroLogic.getResetHeroDiamond() }
    })
    @property(cc.Label)
    labelDiamond: cc.Label = null;

    heroSelect: HeroSelect = null;
    protected _selectHeroes: HeroSelect[] = [];
    protected _eventListeners: EListener[] = [];

    static createHeroFunction: Function = null;

    onLoad() {
        this.previewNode.active = false;
        this.heroSelect = new HeroSelect();

        if (!HeroResetPanel.createHeroFunction) {
            let target: { data: cc.Node, _createFunction: Function } = { data: this.heroList.tmpNode, _createFunction: null };
            cc.Prefab.prototype.compileCreateFunction.call(target);
            HeroResetPanel.createHeroFunction = target._createFunction;
        }
        this.heroList.createTmpFunction = HeroResetPanel.createHeroFunction;
    }

    start() {
        this._updateHeroList();
    }

    onHeroRender(item: cc.Node, index: number) {
        let select = this._selectHeroes[index];
        let comp = item.getComponent(HeroSelectLockItem);
        comp.checkLockCallback = (heroSelect: HeroSelect) => {
            return { result: !heroSelect.hero.isLock(), message: stringConfigMap.key_hero_locked.Value }
        }
        comp.init(select.hero, select.isSelect, true);
        this._selectHeroes[index] = comp.heroSelect;

        let func = HeroSelectLockItem.prototype.onToggleSelect;
        comp.onToggleSelect = () => {
            if (this.heroSelect.isSelect && this.heroSelect.hero != comp.heroSelect.hero) {
                this.heroSelect.isSelect = false;
            }
            this.heroSelect = comp.heroSelect;
            func.call(comp);
        }
    }

    onReset() {
        gcc.core.showLayer("prefabs/panel/recycle/HeroResetConfirmDialog", {
            data: {
                hero: this.heroSelect.hero,
                success: (cards: Card[]) => {
                    this._updateHeroList();
                    EManager.emit(HeroSelect.Event.onSelectDirty, { target: this.heroSelect });
                    gcc.core.showLayer("prefabs/panel/reward/RewardPanel", { data: { cards: cards }, modalTouch: true });
                }
            }
        });
    }

    protected _updateHeroList() {
        this.heroSelect = new HeroSelect();

        let heroes = heroLogic.getResetableHeroes(true);
        this._selectHeroes = [];
        for (let hero of heroes) {
            let select = new HeroSelect(hero);
            this._selectHeroes.push(select);
        }

        this.heroList.getComponent(cc.Widget).updateAlignment();
        this.heroList.numItems = this._selectHeroes.length;
        this.labelHeroCounts.string = `${heroes.length}/${heroLogic.getHeroesCount()}`;
    }
}
