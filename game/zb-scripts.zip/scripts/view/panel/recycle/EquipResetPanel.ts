import { defaultConfigMap } from './../../../configs/defaultConfig';
import EquipSelectItem, { EquipSelect } from './../../widget/equip/EquipSelectItem';
import { RefreshNode, RefreshLabel } from "../../../decorator/RefreshDecorator";
import EManager, { EListener } from "../../../manager/EventManager";
import List from '../../common/List';
import Card from '../../../data/card/Card';
import EquipResetPreview from '../../widget/equip/EquipResetPreview';
import bagLogic from '../../../logics/BagLogic';
import Equip from '../../../data/card/Equip';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/recycle/EquipResetPanel")
export default class EquipResetPanel extends cc.Component {

    @RefreshNode({
        eventName: EquipSelect.Event.onSelectDirty,
        getData: (caller: EquipResetPanel) => { return caller.equipSelect },
        refresh: (node: cc.Node, equipSelect: EquipSelect) => {
            let button = node.getComponent(cc.Button)
            button.interactable = equipSelect.isSelect;

            let diamond = node.getChildByName("diamond");
            diamond.active = equipSelect.isSelect;
        }
    })
    @property(cc.Node)
    btnReset: cc.Node = null;

    @property(List)
    equipList: List = null;

    @RefreshNode({
        eventName: EquipSelect.Event.onSelectDirty,
        getData: (caller: EquipResetPanel) => { return caller.equipSelect },
        refresh: (node: cc.Node, equipSelect: EquipSelect) => {
            node.active = !equipSelect.isSelect;
        }
    })
    @property(cc.Node)
    tipNode: cc.Node = null;

    @RefreshNode({
        eventName: EquipSelect.Event.onSelectDirty,
        getData: (caller: EquipResetPanel) => { return caller.equipSelect },
        refresh: (node: cc.Node, equipSelect: EquipSelect) => {
            node.active = equipSelect.isSelect;
            if (node.active) {
                let comp = node.getComponent(EquipResetPreview);
                comp.refresh(equipSelect);
            }
        }
    })
    @property(cc.Node)
    previewNode: cc.Node = null;

    @RefreshLabel({
        getData: () => { return bagLogic },
        getValue: () => { return defaultConfigMap.equipreborncost.value }
    })
    @property(cc.Label)
    labelDiamond: cc.Label = null;

    equipSelect: EquipSelect = null;
    protected _selectEquips: EquipSelect[] = [];
    protected _eventListeners: EListener[] = [];

    static createEquipFunction: Function = null;

    onLoad() {
        this.previewNode.active = false;
        this.equipSelect = new EquipSelect();

        if (!EquipResetPanel.createEquipFunction) {
            let target: { data: cc.Node, _createFunction: Function } = { data: this.equipList.tmpNode, _createFunction: null };
            cc.Prefab.prototype.compileCreateFunction.call(target);
            EquipResetPanel.createEquipFunction = target._createFunction;
        }
        this.equipList.createTmpFunction = EquipResetPanel.createEquipFunction;
    }

    start() {
        this._updateEquipList();
    }

    onEquipRender(item: cc.Node, index: number) {
        let select = this._selectEquips[index];
        let comp = item.getComponent(EquipSelectItem);
        comp.init(select.equip, select.isSelect);
        this._selectEquips[index] = comp.equipSelect;

        let func = EquipSelectItem.prototype.onToggleSelect;
        comp.onToggleSelect = () => {
            if (this.equipSelect.isSelect && this.equipSelect.equip != comp.equipSelect.equip) {
                this.equipSelect.isSelect = false;
            }
            this.equipSelect = comp.equipSelect;
            func.call(comp);
        }
    }

    onReset() {
        gcc.core.showLayer("prefabs/panel/recycle/EquipResetConfirmDialog", {
            data: {
                equip: this.equipSelect.equip,
                success: (cards: Card[]) => {
                    this._updateEquipList();
                    EManager.emit(EquipSelect.Event.onSelectDirty, { target: this.equipSelect });
                    gcc.core.showLayer("prefabs/panel/reward/RewardPanel", { data: { cards: cards }, modalTouch: true });
                }
            }
        });
    }

    protected _updateEquipList() {
        this.equipSelect = new EquipSelect();

        let equips = bagLogic.getEquips((a: Equip) => { return a.isTrained() && a.getHero() == null; });
        equips.sort((a: Equip, b: Equip) => {
            if (a.getRank() != b.getRank()) { return b.getRank() - a.getRank(); }
            if (a.getStar() != b.getStar()) { return b.getStar() - a.getStar(); }
            if (a.getLevel() != b.getLevel()) { return b.getLevel() - a.getLevel(); }
            return a.getIndex() - b.getIndex();
        });

        this._selectEquips = [];
        for (let equip of equips) {
            let select = new EquipSelect(equip);
            this._selectEquips.push(select);
        }

        this.equipList.getComponent(cc.Widget).updateAlignment();
        this.equipList.numItems = this._selectEquips.length;
    }
}
