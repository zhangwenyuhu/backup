import { PopupPanel } from "../../panel/BasePanel";
import CommonLoader from "../../common/CommonLoader";
import PopBg from "../../component/PopBg";
import { HeroSplitGroup } from "./HeroSplitPanel";
import heroLogic from "../../../logics/HeroLogic";
import gm from "../../../manager/GameManager";
import EManager from "../../../manager/EventManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/recycle/HeroSplitDialog")
export default class HeroSplitDialog extends PopupPanel {
    @property(CommonLoader)
    dialog: CommonLoader = null;

    @property(cc.Node)
    contentBg: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    protected _heroGroup: HeroSplitGroup = null;

    onInit(data: HeroSplitGroup) {
        super.onInit(data);
        this._heroGroup = data;
    }

    onLoad() {
        super.onLoad();
        this.equipItem.parent = null;
        this.goodItem.parent = null;
    }

    start() {
        super.start();

        let comp = this.dialog.loaderNode.getComponent(PopBg);
        comp.closeCallback = () => { this.closePanel() };

        let heroSelects = this._heroGroup.getSelectHeroes();
        let heroes = [];
        for (let select of heroSelects) {
            heroes.push(select.hero);
        }
        let allCards = heroLogic.getSplitAllCards(heroes);
        gm.createRewards(allCards, { goodItem: this.goodItem, equipItem: this.equipItem, heroItem: null }, this.contentBg);
    }

    async onSplit() {
        try {
            let heroSelects = this._heroGroup.getSelectHeroes();
            let heroes = [];
            for (let select of heroSelects) {
                heroes.push(select.hero);
            }
            let cards = await heroLogic.doSplitHeroes(heroes);

            this.closePanel();
            EManager.emit(HeroSplitGroup.Event.onTotalHeroCountDirty);
            gcc.core.showLayer("prefabs/panel/reward/RewardPanel", { data: { cards: cards }, modalTouch: true });
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}