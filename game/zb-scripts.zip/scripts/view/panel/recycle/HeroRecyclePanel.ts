import { EName } from './../../../manager/EventManager';
import { Storage } from './../../../utils/DefineUtils';
import { FullscreenPanel } from "../BasePanel";
import commonUtils from "../../../utils/CommonUtils";
import { StoreTab } from "../store/StorePanel";
import storageUtils from "../../../utils/StorageUtils";
import EManager from '../../../manager/EventManager';
import { PromptType } from '../../../data/prompt/PromptModal';
import guideLogic from '../../../logics/GuideLogic';

const { ccclass, property, menu } = cc._decorator;

enum TabState {
    Focus,
    Unfocus
}

enum TabType {
    HeroReset,
    HeroSplit,
    HeroRollback,
    EquipReset
}

@ccclass
@menu("view/panel/recycle/HeroRecyclePanel")
export default class HeroRecyclePanel extends FullscreenPanel {

    @property(cc.Node)
    btnSplit: cc.Node[] = [];

    @property(cc.Node)
    btnReset: cc.Node[] = [];

    @property(cc.Node)
    btnRollback: cc.Node[] = [];

    @property(cc.Node)
    btnEquipReset: cc.Node[] = [];

    @property(cc.Node)
    contentBg: cc.Node = null;

    @property(cc.Prefab)
    prefabSplit: cc.Prefab = null;

    @property(cc.Prefab)
    prefabReset: cc.Prefab = null;

    @property(cc.Prefab)
    prefabRollback: cc.Prefab = null;

    @property(cc.Prefab)
    prefabEquipReset: cc.Prefab = null;

    @property(cc.Node)
    btnShop: cc.Node = null;

    protected _tabs: cc.Node[][] = [];

    onLoad() {
        super.onLoad();

        this._tabs = [
            this.btnReset,
            this.btnSplit,
            this.btnRollback,
            this.btnEquipReset
        ];
    }

    start() {
        super.start();

        if (!storageUtils.getBoolean(Storage.RecycleGuide)) {
            storageUtils.setBoolean(Storage.RecycleGuide.Key, true, true);
            EManager.emit(EName.onRedDirty, PromptType.RecycleBtn);
            guideLogic.guideId = 100001;
        }

        let widget = this.contentBg.getComponent(cc.Widget);
        widget.updateAlignment();

        this.onTabReset();
    }

    onTabSplit() {
        for (let i = 0; i < this._tabs.length; i++) {
            let tabs = this._tabs[i];
            tabs[TabState.Focus].active = i == TabType.HeroSplit;
            tabs[TabState.Unfocus].active = i != TabType.HeroSplit;
        }
        this.btnShop.active = true;

        this.contentBg.destroyAllChildren();

        let panel = cc.instantiate(this.prefabSplit);
        panel.setPosition(0, 0);
        panel.setContentSize(this.contentBg.getContentSize());
        this.contentBg.addChild(panel);
    }

    onTabReset() {
        for (let i = 0; i < this._tabs.length; i++) {
            let tabs = this._tabs[i];
            tabs[TabState.Focus].active = i == TabType.HeroReset;
            tabs[TabState.Unfocus].active = i != TabType.HeroReset;
        }
        this.btnShop.active = true;

        this.contentBg.destroyAllChildren();

        let panel = cc.instantiate(this.prefabReset);
        panel.setPosition(0, 0);
        panel.setContentSize(this.contentBg.getContentSize());
        this.contentBg.addChild(panel);
    }

    onTabRollback() {
        for (let i = 0; i < this._tabs.length; i++) {
            let tabs = this._tabs[i];
            tabs[TabState.Focus].active = i == TabType.HeroRollback;
            tabs[TabState.Unfocus].active = i != TabType.HeroRollback;
        }
        this.btnShop.active = true;

        this.contentBg.destroyAllChildren();

        let panel = cc.instantiate(this.prefabRollback);
        panel.setPosition(0, 0);
        panel.setContentSize(this.contentBg.getContentSize());
        this.contentBg.addChild(panel);
    }

    onTabEquipReset() {
        for (let i = 0; i < this._tabs.length; i++) {
            let tabs = this._tabs[i];
            tabs[TabState.Focus].active = i == TabType.EquipReset;
            tabs[TabState.Unfocus].active = i != TabType.EquipReset;
        }
        this.btnShop.active = false;

        this.contentBg.destroyAllChildren();

        let panel = cc.instantiate(this.prefabEquipReset);
        panel.setPosition(0, 0);
        panel.setContentSize(this.contentBg.getContentSize());
        this.contentBg.addChild(panel);
    }

    onStore() {
        gcc.core.showLayer("prefabs/panel/store/StorePanel", { data: StoreTab.Split });
    }

    onHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "recycle" } });
    }

    protected async _preloadRes() {
        await super._preloadRes();

        this._unloadInfos.push({ url: commonUtils.getBgUrl("hero_reset_bg"), type: cc.SpriteFrame });
        this._unloadInfos.push({ url: commonUtils.getBgUrl("hero_split_bg"), type: cc.SpriteFrame });
    }

    protected _unloadRes(prefab: cc.Prefab) {
        cc.loader.releaseAsset(this.prefabSplit);
        cc.loader.releaseAsset(this.prefabReset);
        cc.loader.releaseAsset(this.prefabRollback);
        cc.loader.releaseAsset(this.prefabEquipReset);
        super._unloadRes(prefab);
    }
}
