import { stringConfigMap } from './../../../configs/stringConfig';
import EManager, { EListener } from './../../../manager/EventManager';
import { HeroSelect } from './../../widget/hero/HeroSelectItem';
import { WatchProperty } from "../../../decorator/PropertyDecorator";
import { RefreshNode } from '../../../decorator/RefreshDecorator';
import heroLogic from '../../../logics/HeroLogic';
import HeroSplitReview from '../../widget/hero/HeroSplitReview';
import gm from '../../../manager/GameManager';
import stringUtils from '../../../utils/StringUtils';
import storageUtils from '../../../utils/StorageUtils';
import { Storage } from '../../../utils/DefineUtils';
import HeroSelectLockItem from '../../widget/hero/HeroSelectLockItem';
import List from '../../common/List';

const { ccclass, property, menu } = cc._decorator;

export class HeroSplitGroup {
    static Event = {
        onSelectHeroCountDirty: "on select hero count dirty",
        onTotalHeroCountDirty: "on total hero count dirty"
    }

    @WatchProperty(HeroSplitGroup.Event.onSelectHeroCountDirty)
    selectHeroCount: number = 0;

    protected _heroSelects: HeroSelect[] = [];

    addHero(heroSelect: HeroSelect) {
        this._heroSelects.push(heroSelect);
    }

    getHero(index: number): HeroSelect {
        return this._heroSelects[index]
    }

    setHero(heroSelect: HeroSelect, index: number) {
        this._heroSelects[index] = heroSelect;
    }

    clearHeroes() {
        this._heroSelects = [];
    }

    getHeroes() {
        return this._heroSelects;
    }

    getSplitableHeroes(): HeroSelect[] {
        let heroSelects = [];
        for (let select of this._heroSelects) {
            if (!select.hero.isLock()) {
                heroSelects.push(select);
            }
        }
        return heroSelects;
    }

    getSelectHeroes(): HeroSelect[] {
        let heroSelects = [];
        for (let select of this._heroSelects) {
            if (select.isSelect) {
                heroSelects.push(select);
            }
        }
        heroSelects.sort((a: HeroSelect, b: HeroSelect) => {
            return a.timestamp - b.timestamp;
        })
        return heroSelects;
    }

    updateSelectHeroCount() {
        let count = 0;
        for (let select of this._heroSelects) {
            if (select.isSelect) {
                count++;
            }
        }
        this.selectHeroCount = count;
    }
}

@ccclass
@menu("view/panel/recycle/HeroSplitPanel")
export default class HeroSplitPanel extends cc.Component {
    @property(cc.Node)
    btnOnekey: cc.Node = null;

    @RefreshNode({
        eventName: HeroSplitGroup.Event.onSelectHeroCountDirty,
        getData: (caller: HeroSplitPanel) => { return caller.heroGroup },
        refresh: (node: cc.Node, heroGroup: HeroSplitGroup) => {
            let button = node.getComponent(cc.Button);
            button.interactable = heroGroup.selectHeroCount > 0;
        }
    })
    @property(cc.Node)
    btnSplit: cc.Node = null;

    @property(cc.Label)
    labelHeroCounts: cc.Label = null;

    @property(cc.Node)
    autoSplitSelect: cc.Node = null;

    @property(List)
    heroList: List = null;

    @RefreshNode({
        eventName: HeroSplitGroup.Event.onSelectHeroCountDirty,
        getData: (caller: HeroSplitPanel) => { return caller.heroGroup },
        refresh: (node: cc.Node, heroGroup: HeroSplitGroup) => {
            node.active = heroGroup.selectHeroCount == 0;
        }
    })
    @property(cc.Node)
    tipNode: cc.Node = null;

    @RefreshNode({
        eventName: HeroSplitGroup.Event.onSelectHeroCountDirty,
        getData: (caller: HeroSplitPanel) => { return caller.heroGroup },
        refresh: (node: cc.Node, heroGroup: HeroSplitGroup) => {
            node.active = heroGroup.selectHeroCount > 0;
            if (node.active) {
                let comp = node.getComponent(HeroSplitReview);
                comp.refresh();
            }
        }
    })
    @property(cc.Node)
    selectList: cc.Node = null;

    @property(cc.Node)
    autoSplitNode: cc.Node = null;

    heroGroup: HeroSplitGroup = new HeroSplitGroup();
    protected _eventListeners: EListener[] = [];

    static createHeroFunction: Function = null;

    onLoad() {
        let comp = this.selectList.getComponent(HeroSplitReview);
        comp.init(this.heroGroup);

        this.autoSplitNode.active = storageUtils.getBoolean(Storage.AutoSplit);

        if (!HeroSplitPanel.createHeroFunction) {
            let target: { data: cc.Node, _createFunction: Function } = { data: this.heroList.tmpNode, _createFunction: null };
            cc.Prefab.prototype.compileCreateFunction.call(target);
            HeroSplitPanel.createHeroFunction = target._createFunction;
        }
        this.heroList.createTmpFunction = HeroSplitPanel.createHeroFunction;
    }

    onEnable() {
        let listener = EManager.addEvent(HeroSelect.Event.onSelectDirty, (data: any) => {
            this.heroGroup.updateSelectHeroCount();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(HeroSplitGroup.Event.onTotalHeroCountDirty, (data: any) => {
            this._updateHeroList();
            this.heroGroup.updateSelectHeroCount();
        });
        this._eventListeners.push(listener);
    }

    onDisable() {
        for (let listener of this._eventListeners) {
            EManager.removeEvent(listener);
        }
        this._eventListeners = [];
    }

    start() {
        this._updateHeroList();
    }

    onOneKey() {
        let heroSelects = this.heroGroup.getSelectHeroes();
        let count = this.selectList.childrenCount - heroSelects.length;
        if (count == 0) {
            gm.toast(stringUtils.getString(stringConfigMap.key_hero_split_select_limit.Value, { count: this.selectList.childrenCount }));
            return;
        }

        heroSelects = this.heroGroup.getSplitableHeroes();
        if (heroSelects.length == 0) {
            gm.toast(stringConfigMap.key_no_split_hero.Value);
            return;
        }

        for (let select of heroSelects) {
            if (count == 0) break;
            if (!select.isSelect) {
                select.timestamp = new Date().getTime();
                select.isSelect = true;
                count--;
            }
        }
    }

    onSplit() {
        gcc.core.showLayer("prefabs/panel/recycle/HeroSplitDialog", { data: this.heroGroup });
    }

    onToggleAutoSplit() {
        this.autoSplitNode.active = !this.autoSplitNode.active;
        storageUtils.setBoolean(Storage.AutoSplit.Key, this.autoSplitNode.active, true);
    }

    onHeroRender(item: cc.Node, index: number) {
        let select = this.heroGroup.getHero(index);
        let comp = item.getComponent(HeroSelectLockItem);
        comp.checkLockCallback = (heroSelect: HeroSelect) => {
            return { result: !heroSelect.hero.isLock(), message: stringConfigMap.key_hero_locked.Value }
        }
        comp.init(select.hero, select.isSelect, true);
        this.heroGroup.setHero(comp.heroSelect, index);

        let func = HeroSelectLockItem.prototype.onToggleSelect;
        comp.onToggleSelect = () => {
            if (!comp.heroSelect.isSelect) {
                if (this.heroGroup.selectHeroCount == this.selectList.childrenCount) {
                    gm.toast(stringUtils.getString(stringConfigMap.key_hero_split_select_limit.Value, { count: this.selectList.childrenCount }));
                    return;
                }
            }
            func.call(comp);
        }
    }

    protected _updateHeroList() {
        this.heroGroup.clearHeroes();

        let heroes = heroLogic.getSplitableHeroes(true);
        for (let hero of heroes) {
            let select = new HeroSelect(hero);
            this.heroGroup.addHero(select);
        }

        this.heroList.getComponent(cc.Widget).updateAlignment();
        this.heroList.numItems = this.heroGroup.getHeroes().length;

        this.labelHeroCounts.string = `${heroes.length}/${heroLogic.getHeroesCount()}`;

        let button = this.btnOnekey.getComponent(cc.Button);
        button.interactable = heroes.length > 0;
    }
}
