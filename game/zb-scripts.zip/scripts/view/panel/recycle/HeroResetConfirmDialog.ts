import { PopupPanel } from "../BasePanel";
import Hero from "../../../data/card/Hero";
import heroLogic from "../../../logics/HeroLogic";
import gm from "../../../manager/GameManager";
import PopBg from "../../component/PopBg";
import CommonLoader from "../../common/CommonLoader";
import bagLogic from "../../../logics/BagLogic";
import Good from "../../../data/card/Good";
import stringUtils from "../../../utils/StringUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import PlayerHero from "../../../data/card/PlayerHero";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/recycle/HeroResetConfirmDialog")
export default class HeroResetConfirmDialog extends PopupPanel {

    @property(CommonLoader)
    dialog: CommonLoader = null;

    @property(cc.Label)
    labelDiamond: cc.Label = null;

    hero: PlayerHero = null;
    success: Function = null;

    onInit(data: { hero: PlayerHero, success: Function }) {
        super.onInit(data);
        this.hero = data.hero;
        this.success = data.success;
    }

    start() {
        super.start();

        let comp = this.dialog.loaderNode.getComponent(PopBg);
        comp.closeCallback = () => { this.closePanel() };

        this.labelDiamond.string = `${heroLogic.getResetHeroDiamond()}`;
    }

    async onReset() {
        try {
            let cards = await heroLogic.doResetHero(this.hero);
            if (this.success) this.success(cards);
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                if (e.message == stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: bagLogic.getGood(Good.GoodId.Diamond).getName() })) {
                    gm.diamondLessToast();
                    this.closePanel();
                }
                else {
                    gm.toast(e.message);
                }
            }
            else {
                throw e;
            }
        }
    }
}
