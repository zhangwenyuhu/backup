import BasePanel, { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import gm from "../../../manager/GameManager";
import loadUtils from "../../../utils/LoadUtils";
import ChessTask from "../../../data/assignment/ChessTask";
import chessLogic from "../../../logics/ChessLogic";
import MainScene from "../../../scenes/MainScene";
import EManager, { EName } from "../../../manager/EventManager";
import Good from "../../../data/card/Good";
import activityLogic, { ActivityType } from "../../../logics/ActivityLogic";
import promptLogic, { PromptType } from "../../../logics/PromptLogic";
import friendLogic from "../../../logics/FriendLogic";
import CommonLoader from "../../common/CommonLoader";
import VideoBtn from "../../../gleecomponent/VideoBtn";
import { VideoKey } from "../../../utils/DefineUtils";
import videoAdLogic, { AD_TYPE } from "../../../logics/VideoAdLogic";
import rechargeLogic from "../../../logics/RechargeLogic";
import giftLogic from "../../../logics/GiftLogic";
import { MarketTab } from "../market/MarketPanel";
import { MarketLimitTab } from "../../component/Market/LimitMarketModule";
import gotoUtils, { GotoModule } from "../../../utils/GotoUtils";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/chess/DiceTaskPanel")
export default class TenDicePanel extends PopupPanel {

    @property(List)
    diceTaskList: List = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    private tasks: ChessTask[] = [];
    private _videoFirst: boolean = true;
    onInit(data: any) {
        this.tasks = chessLogic.diceTasks;
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        EManager.emit(EName.onFreshPanel, "ChessPanel");
        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();

        this.diceTaskList.getComponent(cc.Widget).updateAlignment();
        this.freshTask();
        EManager.emit(EName.onUpdateActivityDatas, ActivityType.CheckerBoard);
    }

    videoItemRender(node: cc.Node) {
        node.getChildByName("complete").active = false;
        node.getChildByName("progress").active = false;
        node.getChildByName("num").active = false;
        node.getChildByName("get").active = false;
        node.getChildByName("go").active = false;

        let mask = node.getChildByName("mask");
        let desc = node.getChildByName("desc");
        let tip = node.getChildByName("videoDesc");
        let btnVideo = node.getChildByName("btnVideo");

        let videoValid: boolean = videoAdLogic.canVideoAd(AD_TYPE.Dice);
        desc.active = true;
        desc.getComponent(cc.Label).string = "免费获得一个普通骰子";
        tip.active = true;
        let nowTimes = videoAdLogic.adNowTimes(AD_TYPE.Dice);
        let maxTimes = videoAdLogic.adMaxTimes(AD_TYPE.Dice);
        tip.getComponent(cc.Label).string = `今日已获取${maxTimes - nowTimes}/${maxTimes}次`;
        mask.active = !videoValid;
        btnVideo.active = videoValid;

        let videoNode = btnVideo.getComponent(CommonLoader).loaderNode;
        videoNode.getComponent(VideoBtn).setImageFrame(false);
        let ts = this.getChessTs();
        videoNode.getComponent(VideoBtn).limitTs = ts;
        videoNode.getComponent(VideoBtn).videoText = "领取";
        videoNode.getComponent(VideoBtn).eventName = VideoKey.ChessDice;
        videoNode.getComponent(VideoBtn).onSuccessFunc = () => {
            if (this.isChessOver()) {
                this.chessOverTip();
                return;
            }
            videoAdLogic.videoPlayTimesCount(AD_TYPE.Dice);
            this.getDice();
        }

        node.getChildByName("reward").destroyAllChildren();
        gm.showGoodItem([Good.GoodId.RandomDice, 1], {
            goodItem: this.goodItem,
            equipItem: this.equipItem,
            heroItem: this.heroItem
        }, node.getChildByName("reward"), 0.75);
    }

    async getDice() {
        await chessLogic.videoDiceReq();
        this.freshTask();
    }

    onItemRender(item: cc.Node, index: number) {
        if (item) {
            if (this._videoFirst) {
                let bVideo: boolean = index == 0;
                if (bVideo) {
                    this.videoItemRender(item);
                } else {
                    this.freshItem(item, index - 1);
                }
            } else {
                if (index == this.tasks.length) {
                    this.videoItemRender(item)
                } else {
                    this.freshItem(item, index);
                }
            }

        }
    }

    freshItem(node: cc.Node, index: number) {
        let data: ChessTask = this.tasks[index];
        node.getChildByName("videoDesc").active = false;
        node.getChildByName("btnVideo").active = false;

        node.getChildByName("desc").getComponent(cc.Label).string = data.desc;
        let overNode = node.getChildByName("complete");
        let proNode = node.getChildByName("progress");
        let numNode = node.getChildByName("num");
        let btnGet = node.getChildByName("get");
        let btnGo = node.getChildByName("go");
        let mask = node.getChildByName("mask")
        node.getChildByName("title").active = data.gotReward;
        mask.active = data.gotReward;
        if (data.gotReward) {
            overNode.active = false;
            proNode.active = false;
            btnGet.active = false;
            btnGo.active = false;
            numNode.active = false;
        } else {
            overNode.active = data.completeTask;
            proNode.active = !data.completeTask;
            numNode.active = !data.completeTask;
            btnGet.active = data.completeTask;
            btnGo.active = !data.completeTask;
            if (proNode.active) {
                numNode.getComponent(cc.Label).string = `${data.nowProgress}/${data.needProgress()}`;
                proNode.getComponent(cc.ProgressBar).progress = data.nowProgress / data.needProgress();
            }
        }
        if (mask.active) {
            mask.opacity = 50;
        }

        btnGet.getComponent(cc.Button).clickEvents[0].customEventData = `${data.cfg.ID}`;
        btnGo.getComponent(cc.Button).clickEvents[0].customEventData = `${data.cfg.ID}`;

        node.getChildByName("reward").destroyAllChildren();
        gm.showGoodItem(data.cfg.reward[0], {
            goodItem: this.goodItem,
            equipItem: this.equipItem,
            heroItem: this.heroItem
        }, node.getChildByName("reward"), 0.75);
    }

    freshTask() {
        this._videoFirst = videoAdLogic.canVideoAd(AD_TYPE.Dice);
        this.diceTaskList.numItems = this.tasks.length + 1;
    }

    async onClickGetReward(sender: cc.Event.EventTouch, index: string) {
        try {
            await chessLogic.getDiceTaskRewardReq(index);
            chessLogic.initDiceTasks();
            this.tasks = chessLogic.diceTasks;
            this.freshTask();
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.CheckerBoard);
            if (!chessLogic.hasDiceTaskReward()) {
                promptLogic.setPrompt(PromptType.ACTIVITY_CHESS, false);
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    onClickGetMoreDice() {
        if (this.isChessOver()) {
            this.chessOverTip();
            return;
        }
        BasePanel.closePanel("ActivityPanel");
        BasePanel.closePanel("ChessPanel");
        this.scheduleOnce(() => { this.closePanel(); });

        this.GotoGiftPanel();
    }

    async GotoGiftPanel() {
        gcc.core.showLayer("prefabs/panel/market/MarketPanel", { data: { tabIndex: MarketTab.Limit, tabChildIndex: MarketLimitTab.Chess } });
    }

    onClickGoto(sender: cc.Event.EventTouch, index: string) {
        if (this.isChessOver()) {
            this.chessOverTip();
            return;
        }
        let id: number = parseInt(index);
        BasePanel.closePanel("ActivityPanel");
        BasePanel.closePanel("ChessPanel");
        let diceTask = this.tasks.find((a) => { return a.id == id; })
        if (diceTask) {
            switch (diceTask.cfg.tasktype) {
                case 6001:
                    // 日常任务活跃度
                    break;
                case 6002:
                    // 智慧树boss
                    gotoUtils.gotoPanel(GotoModule.Mazon);
                    break;
                case 6003:
                    // 添加好友
                    gotoUtils.gotoPanel(GotoModule.Friend);
                    break;
                case 6004:
                    // 使用友情点召唤英雄
                    gotoUtils.gotoPanel(GotoModule.ChouKa);
                    break;
                case 6005:
                    // 竞技场胜利
                    gotoUtils.gotoPanel(GotoModule.Arena);
                    break;
                case 6006:
                    // 进阶英雄
                    gotoUtils.gotoPanel(GotoModule.AdvanceHero);
                    break;
                case 1009:
                    // 公会狩猎
                    gotoUtils.gotoPanel(GotoModule.Union);
                    break;
                default:
                    break;
            }
        }
        this.scheduleOnce(() => { this.closePanel(); })
    }

    private isChessOver(): boolean {
        let data = activityLogic.getActivityConfigs(ActivityType.CheckerBoard)
        if (data) {
            let endTs: number = data.closeAt;
            let leftSec: number = (endTs - gm.getCurrentTimestamp()) / 1000;
            return leftSec <= 0;
        } else {
            return true;
        }
    }

    private getChessTs() {
        let data = activityLogic.getActivityConfigs(ActivityType.CheckerBoard)
        if (data) {
            return data.closeAt / 1000;
        }
    }

    private chessOverTip() {
        gm.toast(stringConfigMap.key_desc_55.Value);
    }

}
