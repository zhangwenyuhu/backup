import BasePanel, { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import gm from "../../../manager/GameManager";
import { RankListVO } from "../../../proxy/GameProxy";
import chessLogic from "../../../logics/ChessLogic";
import playerLogic from "../../../logics/PlayerLogic";
import circlerankconfig from "../../../configs/circlerankconfig";
import RankData from "../../../data/record/RankData";
import User from "../../../data/user/User";
import CommonLoader from "../../common/CommonLoader";
import PlayerHead from "../../component/Player/PlayerHead";
import PlayerName from "../../component/Player/PlayerName";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/chess/ChessRankPanel")
export default class ChessRankPanel extends PopupPanel {

    @property(List)
    rankList: List = null;

    @property(List)
    rewardList: List = null;

    @property(cc.Node)
    rankItem: cc.Node = null;

    @property(cc.Node)
    rankBg: cc.Node = null;

    @property(cc.Node)
    rewardBg: cc.Node = null;

    @property(cc.Node)
    myRank: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    private _tab: number = 1; // 1 排名 2 奖励
    private _rank: RankData[] = [];
    private _myRankData: RankData = null;
    onInit(data: any) {
        let ranks: RankListVO = data;
        this._myRankData = new RankData(ranks.myRank);
        for (let i = 0; i < ranks.rankDetail.length; i++) {
            let tmp: RankData = new RankData(ranks.rankDetail[i]);
            this._rank.push(tmp);
        }
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        //EManager.emit(EName.onFreshPanel,"ChessPanel");
        super.onDestroy();

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();

        this.rankList.getComponent(cc.Widget).updateAlignment();
        this.rewardList.getComponent(cc.Widget).updateAlignment();
        this._tab = 1;
        this.freshUI();

        let myRankItem = cc.instantiate(this.rankItem);
        myRankItem.parent = this.myRank;
        myRankItem.anchorX = 0.5;
        myRankItem.anchorY = 0.5;
        myRankItem.position = cc.v2(0, 0);
        this.freshRankItem(myRankItem, -1, true);

    }

    freshUI() {
        let rankValid: boolean = this._tab == 1;
        this.rankBg.active = rankValid;
        this.rankList.node.parent.active = rankValid;

        this.rewardBg.active = !rankValid;
        this.rewardList.node.parent.active = !rankValid;

        if (rankValid) {
            this.rankList.numItems = this._rank.length;
        } else {
            this.rewardList.numItems = circlerankconfig.length;
        }
    }

    onRankItemRender(item: cc.Node, index: number) {
        if (item) {
            this.freshRankItem(item, index);
        }
    }

    freshRankItem(node: cc.Node, index: number, self: boolean = false) {
        let data: RankData = self ? this._myRankData : this._rank[index];

        // rank
        let num = data.getRank();
        for (let i = 1; i < 4; i++) {
            node.getChildByName(`rank${i}`).active = (i == num);
        }
        let str = (num > 50 || num <= 0) ? "未上榜" : `${num}`;
        node.getChildByName("rank").getComponent(cc.Label).string = str;
        node.getChildByName("rank").active = num > 3 || num <= 0;

        // head and name
        let head = node.getChildByName("player_head");
        let name = node.getChildByName("player_name");
        let user: User = null;
        if (!self) {
            user = data.getRole();
            node.getChildByName("bg2").active = false;
            node.getChildByName("bg1").active = data.getRank() % 2 > 0;
        } else {
            user = playerLogic.getPlayer();
            node.getChildByName("bg2").active = true;
            node.getChildByName("bg1").active = false;
        }
        head.getComponent(CommonLoader).loaderNode.getComponent(PlayerHead).refresh(user);
        name.getComponent(CommonLoader).loaderNode.getComponent(PlayerName).refresh(user);

        // score
        node.getChildByName("score").getComponent(cc.Label).string = `${data.getScore()}`;
    }

    onRewardItemRender(item: cc.Node, index: number) {
        if (item) {
            this.freshRewardItem(item, index);
        }
    }

    freshRewardItem(node: cc.Node, index: number) {

        node.getChildByName("bg1").active = (index + 1) % 2 == 0;
        // rank
        let num = 0;
        let cfg = circlerankconfig[index];
        let str = `${cfg.circlerank[0]}-${cfg.circlerank[1]}`;
        if (cfg.circlerank[0] == cfg.circlerank[1]) {
            str = cfg.circlerank[0];
            num = cfg.circlerank[0];
        }
        for (let i = 1; i < 4; i++) {
            node.getChildByName(`rank${i}`).active = (i == num);
        }

        node.getChildByName("layout").active = num > 3 || num <= 0;
        node.getChildByName("layout").getChildByName("rank").getComponent(cc.Label).string = str;

        // reward
        let reward = node.getChildByName("rewards");
        reward.destroyAllChildren();
        let data: number[][] = cfg.reward;
        for (let i = 0; i < data.length; i++) {
            gm.showGoodItem(data[i], {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem
            }, reward, 0.75);
        }
    }

    getRewardCfg(rank: number) {
        let cfgs = circlerankconfig;
        for (let i = 0; i < cfgs.length; i++) {
            if (cfgs[i].circlerank[0] <= rank && cfgs[i].circlerank[1] >= rank) {
                return cfgs[i];
            }
        }
    }

    async onClickTab(event: cc.Event.EventTouch, index: string) {
        let tabSelect: number = parseInt(index);
        if (this._tab == tabSelect) {
            return;
        }

        this._tab = tabSelect;
        this.freshUI();
    }
}
