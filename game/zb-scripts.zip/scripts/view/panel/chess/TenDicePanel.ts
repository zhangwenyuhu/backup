import { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import gm from "../../../manager/GameManager";
import loadUtils from "../../../utils/LoadUtils";
import chessLogic, { DiceType, ChessEvent } from "../../../logics/ChessLogic";
import EManager, { EName } from "../../../manager/EventManager";
import bagLogic from "../../../logics/BagLogic";
import Good from "../../../data/card/Good";
import { ActivityType } from "../../../logics/ActivityLogic";
import { ResourceVO, ChessEventItem } from "../../../proxy/GameProxy";
import cm from "../../../manager/ConfigManager";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/chess/TenDicePanel")
export default class TenDicePanel extends PopupPanel {

    @property(List)
    diceList: List = null;

    @property(cc.Node)
    chessCount: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    tip: cc.Node = null;

    @property(cc.Node)
    touch: cc.Node = null;

    private diceActionSec: number = 20;
    private result: { [key: number]: { rand: number[], step: number[], event: ChessEventItem[][] } } = null;
    private _tenReward: ResourceVO = null;
    private _gotReward: boolean = false;
    private againReqing: boolean = true;

    onInit(data: any) {
        this.result = data ? data.rands : null;
        this._tenReward = data ? data.reward : null;
        this.showTip(false);
        this.touch.active = true;
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        EManager.emit(EName.onFreshPanel, "ChessPanel");
        EManager.emit(EName.onUpdateActivityDatas, ActivityType.CheckerBoard);
        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();

        this.diceList.getComponent(cc.Widget).updateAlignment();
        this.diceList.numItems = this.getDiceLen();
        this.freshUI();
    }

    freshUI() {
        let step: number = chessLogic.getChessData().playerStep;
        this.chessCount.getComponent(cc.Label).string = `${chessLogic.getNowStarCount()}`;
    }

    onItemRender(item: cc.Node, index: number) {
        if (item) {
            this.freshItem(item, index);
        }
    }

    protected getDiceLen(): number { return this.result[DiceType.Normal].rand.length; }
    protected getRands() { return this.result[DiceType.Normal].rand; }
    protected getEvents() { return this.result[DiceType.Normal].event; }
    protected getMySteps() { return this.result[DiceType.Normal].step; }
    protected getZoSteps() { return this.result[DiceType.Zombie].step; }
    protected getZoRands() { return this.result[DiceType.Zombie].rand; }

    freshItem(item: cc.Node, index: number) {

        let node = item.getChildByName("item");
        node.active = false;
        let sec: number = index + 1;
        let myRands = this.getRands();
        let zoRands = this.getZoRands();
        let mySteps = this.getMySteps();
        let zoSteps = this.getZoSteps();

        //console.log(`第${sec}次投掷!`)
        node.getChildByName("bg1").active = sec % 2 == 0;
        let numNode = node.getChildByName("layout").getChildByName("num");
        numNode.getComponent(cc.Label).string = `${sec}`;

        let point: number = myRands[index];
        let pointNode = node.getChildByName("bg2").getChildByName("dice");
        let url: string = `textures/ui/panel/chess/chess_point_${point}`;
        loadUtils.loadSpriteFrame(url, pointNode.getComponent(cc.Sprite));

        let catchZombie: boolean = chessLogic.isMeet(mySteps[index], zoSteps[index] - zoRands[index]);
        let catched: boolean = chessLogic.isMeet(mySteps[index], zoSteps[index]);
        let catchTag = node.getChildByName("bg2").getChildByName("tag");
        catchTag.active = catchZombie || catched;
        if (catchTag.active) {
            let icon = catchZombie ? "chess_36" : "chess_35";
            loadUtils.loadSpriteFrame(`textures/ui/panel/chess/${icon}`, catchTag.getComponent(cc.Sprite));
            console.log(`和僵尸相碰 我的步数:${mySteps[index]} 僵尸步数:${zoSteps[index]}`);
        }
        node.getChildByName("flag").getChildByName("tag").active = catched;

        let rewardNode = node.getChildByName("rewards");
        rewardNode.destroyAllChildren();
        let event = this.getEvents()[index];
        if (event && event.length) {
            let tmp = event.find((a) => { return a.eventId == ChessEvent.Reward; })
            if (tmp) {
                let param = tmp.para.split(',').map((v, i, a) => { return parseInt(v); });
                let cfg = cm.getChessConfig(param[0]);
                gm.showGoodItem(cfg.reward[param[1]], {
                    goodItem: this.goodItem,
                    equipItem: this.equipItem,
                    heroItem: this.heroItem
                }, rewardNode);
            }
        }
        node.getChildByName("start").active = chessLogic.getChessCfgIndex(mySteps[index]) == 1;

        let width: number = item.getContentSize().width;
        this.scheduleOnce(() => {
            node.active = true;
            node.position = cc.v2(-width / 2, 0);
            node.runAction(cc.moveTo(0.1, cc.v2(0, 0)));
            this.moveTo(index - 2);
            if (index == this.getDiceLen() - 1) {
                this.showTip(true);
            }
        }, index * this.diceActionSec / 100);

    }

    private moveTo(index: number) {
        index = index <= 1 ? 0 : index;
        this.diceList.scrollTo(index, this.diceActionSec / 100);
    }

    private showTip(valid: boolean = true) {
        this.tip.active = valid;
        if (valid) {
            this.againReqing = false;
        }

        if (!this._gotReward && valid) {
            gm.getReward(this._tenReward);
            this._gotReward = true;
            this.touch.active = false;
        }
    }

    async onClickAgain(sender: cc.Event.EventTouch, index: string) {
        if (this.againReqing) { return; }
        this.diceList.numItems = 0;
        this.againReqing = true;
        await this.TenDiceAgain();
    }

    async TenDiceAgain() {
        try {
            if (bagLogic.getGood(Good.GoodId.RandomDice).getAmount() < 10) {
                gm.toast(stringConfigMap.key_desc_56.Value);
                return;
            }
            let data = await chessLogic.tenStepCommit();
            this.result = data.rands;
            this._tenReward = data.reward;
            this._gotReward = false;
            this.touch.active = true;

            this.diceList.numItems = this.getDiceLen();
            this.freshUI();

            let num: number = bagLogic.getGood(Good.GoodId.RandomDice).getAmount();
            console.warn(`当前骰子数量: ${num}`);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
                this.touch.active = false;
            }
            else {
                throw e;
            }
        }
    }

}
