import { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import gm from "../../../manager/GameManager";
import activityLogic, { ActivityModal, ActivityType } from "../../../logics/ActivityLogic";
import ChessActivityDatas from "../../../data/activity/roleactivitydatas/ChessActivityDatas";
import cm from "../../../manager/ConfigManager";
import chessLogic from "../../../logics/ChessLogic";
import circleconfig from "../../../configs/circleconfig";
import EManager, { EName } from "../../../manager/EventManager";
import commonUtils from "../../../utils/CommonUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/chess/ChessRewardPanel")
export default class ChessRewardPanel extends PopupPanel {
    @property(List)
    rewardList: List = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    protected _modal: ActivityModal = null;

    protected async _preloadRes() {
        await super._preloadRes();
        this._unloadInfos.push({ url: commonUtils.getBgUrl("activity_sign_bg"), type: cc.SpriteFrame });
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();
        if (!cc.isValid(this.node)) return;

        this._modal = activityLogic.getActivityConfigs(ActivityType.CheckerBoard);
        this.rewardList.getComponent(cc.Widget).updateAlignment();
        this.rewardList.numItems = this.getChessData().getCircleRewards().length;
    }

    getChessData(): ChessActivityDatas {
        return this._modal.roleActivityDatas as ChessActivityDatas;
    }

    getCfg(circle: number) {
        for (let i = 0; i < circleconfig.length; i++) {
            if (circleconfig[i].circle == circle) {
                return circleconfig[i];
            }
        }
    }

    onRewardItemRender(node: cc.Node, index: number) {
        let data = this.getChessData().getCircleRewards()[index];
        node.active = data ? true : false;
        if (!data) { return; }
        let circle: number = parseInt(data.tag)
        let cfg = this.getCfg(circle);
        if (cfg) {
            let title: string = `累计获得 ${circle} 星星积分`;
            cc.find("bg1/title", node).getComponent(cc.Label).string = title;
            cc.find("bg2/title", node).getComponent(cc.Label).string = title;
            let bComplete: boolean = this.getChessData().getStarCount() >= circle;

            node.getChildByName("bg1").active = !bComplete;
            node.getChildByName("bg2").active = bComplete;
            node.getChildByName("flag").active = bComplete && data.recv;
            node.getChildByName("btnGet").active = bComplete && !data.recv;
            node.getChildByName("btnGoto").active = !bComplete;

            let btn = node.getChildByName("btnGet").getComponent(cc.Button);
            btn.clickEvents[0].customEventData = data.tag;

            let rewardNode = node.getChildByName("rewards");
            rewardNode.destroyAllChildren();
            let rewards: number[][] = cfg.reward
            for (let i = 0; i < rewards.length; i++) {
                gm.showGoodItem(rewards[i], {
                    goodItem: this.goodItem,
                    equipItem: this.equipItem,
                    heroItem: this.heroItem
                }, rewardNode, 0.85);
            }
        }
    }

    async onClickGetReward(sender: cc.Event.EventTouch, data: string) {
        try {
            await chessLogic.circleRewardReq(this._modal.id, data);
            this.getChessData().setCircelRewardGot(data);
            this.rewardList.numItems = this.getChessData().getCircleRewards().length;
            EManager.emit(EName.onUpdateActivityDatas, ActivityType.CheckerBoard);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}