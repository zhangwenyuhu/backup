import EManager, { EName } from './../../../manager/EventManager';
import BasePanel, { FullscreenPanel } from "../BasePanel";
import commonUtils from '../../../utils/CommonUtils';
import MapHelper from './MapHelper';
import loadUtils from '../../../utils/LoadUtils';
import gm from '../../../manager/GameManager';
import activityLogic, { ActivityType, ActivityModal } from '../../../logics/ActivityLogic';
import ChessActivityDatas from '../../../data/activity/roleactivitydatas/ChessActivityDatas';
import chessLogic, { ChessEvent } from '../../../logics/ChessLogic';
import bagLogic from '../../../logics/BagLogic';
import Good, { GoodId } from '../../../data/card/Good';
import cm from '../../../manager/ConfigManager';
import timeUtils from '../../../utils/TimeUtils';
import RankData from '../../../data/record/RankData';
import CommonLoader from '../../common/CommonLoader';
import PlayerHead from '../../component/Player/PlayerHead';
import playerLogic from '../../../logics/PlayerLogic';
import stringUtils from '../../../utils/StringUtils';
import Monster from '../../../data/card/Monster';
import commitLogic, { DiamondSource } from '../../../logics/CommitLogic';
import PlayerAvatar from '../../component/Player/PlayerAvatar';
import tipUtils from '../../../utils/TipUtils';
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

class chessItem {
    node: cc.Node;
    pos: number[];
    cfgId: number;

    isOrigin() {
        return this.pos[0] == 0 && this.pos[1] == 1;
    }
}

enum ChessStatu {
    Hold = 1,     //  默认
    Over = 2,     //  结束
}

@ccclass
@menu("view/panel/chess/ChessPanel")
export default class ChessPanel extends FullscreenPanel {

    @property(cc.Node)
    nodeChess: cc.Node = null;

    @property(cc.Node)
    chessLayer: cc.Node = null;

    @property(cc.Node)
    actionLayer: cc.Node = null;

    @property(cc.Node)
    rankLayer: cc.Node = null;

    @property(cc.Node)
    chessTime: cc.Node = null;

    @property(cc.Node)
    chessCircle: cc.Node = null;

    @property(cc.Node)
    wishDiceItem: cc.Node = null;

    @property(cc.Node)
    wishDices: cc.Node = null;

    @property(cc.Node)
    rankItem: cc.Node = null;

    @property(cc.Node)
    ranks: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    moveLayer: cc.Node = null;

    @property(cc.Node)
    player: cc.Node = null;

    @property(cc.Node)
    zombie: cc.Node = null;

    @property(cc.Node)
    touch: cc.Node = null;

    @property(cc.Node)
    wishDiceNum: cc.Node = null;

    @property(cc.Node)
    randomDiceNum: cc.Node = null;

    @property(cc.Node)
    catchNode: cc.Node = null;

    @property(cc.Node)
    npcLayer: cc.Node = null;

    private posPool: number[][] = [
        [0, 1], [0, 2], [0, 3], [0, 4], [0, 5],
        [1, 5],
        [1, 6], [2, 6], [3, 6], [4, 6], [5, 6],
        [5, 5],
        [6, 5], [6, 4], [6, 3], [6, 2], [6, 1],
        [5, 1],
        [5, 0], [4, 0], [3, 0], [2, 0], [1, 0],
        [1, 1]
    ];
    private xNum: number = 7;
    private yNum: number = 7;
    private preY: number = 20;
    private defaultZombieStep: number = 12;

    private chessPool: chessItem[] = [];
    private tenRandom: boolean = false;
    private nowPos: number[] = [0, 1];
    private zombiePos: number[] = [];
    private _rankTop: RankData[] = [];
    private _chessEnd: boolean = false;
    protected _skeletonDatas: sp.SkeletonData[] = [];

    protected async _preloadRes() {
        await super._preloadRes();
        await activityLogic.activityReq(ActivityType.CheckerBoard);
        this._unloadInfos.push({ url: commonUtils.getBgUrl("chess_bg"), type: cc.SpriteFrame });
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
        this.rankItem.parent = null;
        this.wishDiceItem.parent = null;

        this.nodeChess.active = false;
        chessLogic.initChessRewards(this.getChessData().getRandomSeed());
        this.updateNowPos();
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
        this.rankItem.destroy();
        this.wishDiceItem.destroy();
        this._releaseSkeletonDatas();
    }

    async refresh() {
        // 重新获取棋盘活动数据
        await activityLogic.activityReq(ActivityType.CheckerBoard);
        // 同步骰子数量
        let tag: number = 3;
        let num = bagLogic.getGood(GoodId.RandomDice).getAmount();
        if (num < tag && num != 0) { await bagLogic.updateGoodAmt(GoodId.RandomDice); }
        num = bagLogic.getGood(GoodId.WishDice).getAmount();
        if (num < tag && num != 0) { await bagLogic.updateGoodAmt(GoodId.WishDice); }

        this.updateNowPos();
        this.freshUI();
        this.freshAllItem();
        this.touch.active = false;
    }

    async start() {
        super.start();

        this.initChess();
        this.chessStatu = ChessStatu.Hold;
        this.freshUI();
        this.initPlayerIcon();

        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data == "ChessPanel") {
                this.updateNowPos();
                this.freshUI();
                this.freshAllItem();
            }
        });
        this._eventListeners.push(listener);

        this.checkChessTime();
        if (this._chessEnd) {
            this.showRank(true);
        }
        this.freshActivityTime();
        this.schedule(() => {
            this.freshActivityTime();
        }, 1);

        await this.initNpc(872001, this.npcLayer.getChildByName("npc1"));
        await this.initNpc(873001, this.npcLayer.getChildByName("npc2"), false);
    }

    async initNpc(id: number, node: cc.Node, toRight: boolean = true) {

        let dis: number = toRight ? 250 : 250;
        let sec: number = toRight ? 9 : 5;
        let scale: number = toRight ? 0.5 : 0.9;
        node.scaleX = toRight ? scale : -scale;
        node.scaleY = scale;

        let npc = new Monster(id);
        let spineHero = node.getComponent(sp.Skeleton);
        await gm.createHeroSpine(npc, spineHero, "run");
        spineHero.skeletonData.lock();
        this._skeletonDatas.push(spineHero.skeletonData);

        let effects: cc.FiniteTimeAction[] = [];
        let callTurn: cc.ActionInstant = cc.callFunc(() => {
            node.scaleX = -node.scaleX;
        });
        dis = toRight ? dis : -dis;
        effects.push(cc.moveBy(sec, dis, 0));
        effects.push(callTurn);
        effects.push(cc.moveBy(sec, -dis, 0));
        effects.push(callTurn);
        node.runAction(cc.repeatForever(cc.sequence(effects)));
    }

    protected _releaseSkeletonDatas() {
        for (let skeletonData of this._skeletonDatas) {
            skeletonData.unlock();
            loadUtils.releaseAssetRecursively(skeletonData);
        }
        this._skeletonDatas = [];
    }

    checkChessTime() {
        let endTs: number = this.chessModal.closeAt;
        let leftSec: number = (endTs - gm.getCurrentTimestamp()) / 1000;
        this._chessEnd = leftSec <= 0;
    }

    chessOverTip() {
        gm.toast(stringConfigMap.key_desc_55.Value);
    }

    async rankTopReq() {
        return;
        if (this._rankTop.length == 3) { return; }
        let proto = await chessLogic.chessRankReq(3);
        if (proto && proto.rankDetail) {
            for (let i = 0; i < proto.rankDetail.length; i++) {
                if (i > 2) { break; }
                let tmp = new RankData(proto.rankDetail[i]);
                this._rankTop.push(tmp);
            }
        }
    }

    get chessModal() {
        return activityLogic.getActivityConfigs(ActivityType.CheckerBoard);
    }

    getChessData(): ChessActivityDatas {
        return this.chessModal.roleActivityDatas as ChessActivityDatas;
    }

    // 是否和僵尸相遇
    isMeetZombie(): boolean {
        return this.nowPos[0] == this.zombiePos[0] && this.nowPos[1] == this.zombiePos[1];
    }

    catchByZombie() {
        let dice = bagLogic.getGood(Good.GoodId.RandomDice);
        if (dice.getAmount() > 0) {
            dice.changeAmount(-1);
        }
        this.freshUI();
        this.showCatchNode();
    }

    // 更新自己和僵尸的位置数据
    updateNowPos() {
        let chessData: ChessActivityDatas = this.getChessData();
        let step: number = chessData.playerStep;
        let len: number = this.posPool.length;
        let index: number = (step - 1) % len;

        this.nowPos = this.posPool[index];

        step = chessData.zombieStep;
        index = (step - 1) % len;
        this.zombiePos = this.posPool[index];
    }

    set chessStatu(value: ChessStatu) {
        this.actionLayer.active = false;
        this.rankLayer.active = false;
        this.wishDices.parent.active = false;
        this.touch.active = false;

        this.showRank(value == ChessStatu.Over);
        this.showWishDice(false);
        this.showCatchNode(false);
    }

    initChess() {
        // 初始化棋盘
        let areaSize = this.chessLayer.getContentSize();
        let size = this.nodeChess.getContentSize();
        MapHelper.instance.initMapInfo(areaSize.width, areaSize.height, size.width, size.height);
        for (let i = 0; i < this.posPool.length; i++) {
            let node = cc.instantiate(this.nodeChess);
            node.active = true;
            node.parent = this.chessLayer;
            let pX = MapHelper.instance.getPosX(this.posPool[i][0]) - (size.width * this.xNum) / 2;
            let pY = MapHelper.instance.getPosY(this.posPool[i][1]) - (size.height * this.yNum) / 2;
            node.setPosition(cc.v2(pX, pY));

            let tmp = new chessItem;
            tmp.node = node;
            tmp.pos = this.posPool[i];
            tmp.cfgId = i + 1;
            this.chessPool.push(tmp);

            this.freshChessItem(tmp);
        }
    }

    freshAllItem(action: boolean = false) {
        this.chessPool.forEach((v, i, a) => {
            this.freshChessItem(v, action);
        })
    }

    freshUI() {
        // 累计圈数
        let step: number = this.getChessData().playerStep;
        let circle: number = chessLogic.getNowStarCount();
        this.chessCircle.getComponent(cc.Label).string = `${circle}`;
        // 心愿和普通骰子数量
        let str = `${bagLogic.getGood(Good.GoodId.WishDice).getAmount()}/1`;
        this.wishDiceNum.getComponent(cc.Label).string = str;
        let cost: number = this.tenRandom ? 10 : 1;
        str = `${bagLogic.getGood(Good.GoodId.RandomDice).getAmount()}/${cost}`;
        this.randomDiceNum.getComponent(cc.Label).string = str;
    }

    freshActivityTime() {
        // 活动持续时间
        let endTs: number = this.chessModal.closeAt;
        let leftSec: number = (endTs - gm.getCurrentTimestamp()) / 1000;
        //console.warn(`棋盘寻宝活动剩余时间: ${leftSec} s`);
        let title: string = "";
        this.checkChessTime();
        if (this._chessEnd) {
            let ex: string = leftSec > 0 ? timeUtils.formatTime(leftSec) : "00:00:00";
            title = `活动已结束 ` + ex;
            this.showRank();
        } else {
            let endSec: number = leftSec;
            title = `活动倒计时 ` + stringUtils.formatTimeWithHour(endSec);
            this.showRank(false);
        }
        this.chessTime.getComponent(cc.Label).string = title;
    }

    getUrl(name: string): string {
        let url: string = `textures/ui/panel/chess/${name}`;
        return url;
    }
    getChessQualityBgUrl(num: number) {
        return `textures/ui/panel/chess/chess_boardbg_${num}`;
    }

    freshChessItem(data: chessItem, action: boolean = false) {
        let node = data.node;
        if (!node || !data) { return; }

        let reward = node.getChildByName("reward");
        let rewardBg = node.getChildByName("quality");
        let event = node.getChildByName('event');
        let level = node.getChildByName('level');

        reward.destroyAllChildren();
        reward.active = true;
        rewardBg.active = false;
        let cfg = cm.getChessConfig(data.cfgId);
        if (data.isOrigin()) {
            // 起点位置
            loadUtils.loadSpriteFrame(this.getUrl("chess_28"), reward.getComponent(cc.Sprite));
        } else {
            // 奖励信息
            let chessReward = chessLogic.getChessReward(cfg.Key)
            if (chessReward) {
                gm.showGoodItem(chessReward, {
                    goodItem: this.goodItem,
                    equipItem: this.equipItem,
                    heroItem: this.heroItem
                }, reward, 0.75, true);
            }
        }

        let hasEvent: boolean = chessLogic.hasEvent(data.cfgId);
        let eventId: number = chessLogic.getEventId(data.cfgId);
        event.active = hasEvent;
        level.active = eventId == ChessEvent.MoGuHome;

        let runningAction: boolean = this.touch.active;
        if (data.pos[0] == this.nowPos[0] && data.pos[1] == this.nowPos[1]) {
            // 当前点是玩家所在点
            reward.active = data.isOrigin() ? true : false;
            event.active = false;
            level.active = false;
            if (!runningAction) {
                this.freshPlayerPos(node.position);
            } else {
                reward.active = hasEvent ? false : reward.active;
                event.active = hasEvent;
                level.active = eventId == ChessEvent.MoGuHome;
            }
        }
        if (data.pos[0] == this.zombiePos[0] && data.pos[1] == this.zombiePos[1]) {
            // 当前点是僵尸所在点
            reward.active = data.isOrigin() ? true : false;
            event.active = false;
            level.active = false;
            if (!runningAction) {
                this.freshZombiePos(node.position);
            } else {
                reward.active = hasEvent ? false : reward.active;
                event.active = hasEvent;
                level.active = eventId == ChessEvent.MoGuHome;
            }
        }

        // 事件icon和等级
        if (event.active) {
            let url: string = chessLogic.getEventBuildUrl(eventId, chessLogic.getEventBuildLevel(data.cfgId))
            loadUtils.loadSpriteFrame(url, event.getComponent(cc.Sprite));
            reward.active = false;
        }
        if (level.active) {
            let levelNum: number = chessLogic.getEventBuildLevel(data.cfgId);
            level.getComponent(cc.Label).string = levelNum > 0 ? `Lv.${levelNum}` : ``;
        }

        // 奖励icon和动画
        rewardBg.active = reward.active && (cfg.type ? true : false);
        if (rewardBg.active) {
            let url: string = this.getChessQualityBgUrl(cfg.type);
            if (url) {
                loadUtils.loadSpriteFrame(url, rewardBg.getComponent(cc.Sprite));
            }
            if (cfg.type > 1) {
                let actionEx: number = 0;
                if (cfg.type == 2) {
                    actionEx = 2;
                } else if (cfg.type == 3) {
                    actionEx = 3;
                } else if (cfg.type == 4) {
                    actionEx = 1;
                }
                let effect = node.getComponent(cc.Animation);
                effect.play(`ChessPanel_icon${actionEx}`, 0);
            }
        }

        let btn = node.getComponent(cc.Button);
        btn.clickEvents[0].customEventData = `${data.cfgId}`;
    }

    onClickChessItem(sender: cc.Event.EventTouch, customData: string) {
        let cfgId: number = parseInt(customData);
        let cfg = cm.getChessConfig(cfgId)
        if (cfg) {
            if (chessLogic.hasEvent(cfgId)) {
                //gm.toast(stringUtils.getString(stringConfigMap.key_auto_641.Value, {p1: chessLogic.getEventId(cfgId)}));
                let item = this.getChessItemByIndex(cfgId);
                if (item) {
                    let eventId: number = chessLogic.getEventId(cfgId);
                    tipUtils.showTip(item.node, chessLogic.getEventDesc(eventId));
                }
            }
        }
    }

    initPlayerIcon() {
        if (this.player) {
            let avatarLoader = this.player.getChildByName("rect").getChildByName("avatar").getComponent(CommonLoader);
            let comp = avatarLoader.loaderNode.getComponent(PlayerAvatar);
            comp.refresh(playerLogic.getPlayer().getAvatar());
        }
    }
    freshPlayerPos(pos: cc.Vec2) {
        if (this.player) {
            this.player.position = cc.v2(pos.x, pos.y + this.preY);
        }
    }
    freshZombiePos(pos: cc.Vec2) {
        if (this.zombie) {
            this.zombie.position = cc.v2(pos.x, pos.y + this.preY * 2);
        }
    }

    async showRank(valid: boolean = true) {
        return;
        if (valid && this._rankTop.length < 1) {
            await this.rankTopReq();
        }
        if (valid) {
            valid = this._rankTop.length == 0 ? false : valid;
        }
        // 显示棋盘寻宝排行前三位
        if (this.rankLayer.active && valid) { return; }
        this.rankLayer.active = valid;
        if (!this.rankLayer.active) { return; }

        this.ranks.destroyAllChildren();
        let tmp = cc.instantiate(this.rankItem);
        tmp.parent = this.ranks;
        this.freshRankItem(tmp, 2);

        tmp = cc.instantiate(this.rankItem);
        tmp.parent = this.ranks;
        this.freshRankItem(tmp, 1);

        tmp = cc.instantiate(this.rankItem);
        tmp.parent = this.ranks;
        this.freshRankItem(tmp, 3);
    }

    showWishDice(valid: boolean = true) {
        this.wishDices.parent.active = valid;
        if (!this.wishDices.parent.active) { return; }

        let diceCount: number = 6;
        if (this.wishDices.children.length == diceCount) { return; }

        this.wishDices.destroyAllChildren();
        for (let i = 0; i < diceCount; i++) {
            let diceNum = i + 1;
            let tmp = cc.instantiate(this.wishDiceItem);
            tmp.parent = this.wishDices;
            let url = `textures/ui/panel/chess/chess_rpoint_${diceNum}`;
            loadUtils.loadSpriteFrame(url, tmp.getComponent(cc.Sprite));

            let btn = tmp.getComponent(cc.Button);
            btn.clickEvents[0].customEventData = `${diceNum}`;
        }
    }

    private freshRankItem(node: cc.Node, rank: number) {
        node.active = this._rankTop.length >= rank;
        if (node.active) {
            let data = this._rankTop[rank - 1];
            // head and name
            let head = node.getChildByName("player_head");
            let user = data.getRole();
            let headObj = head.getComponent(CommonLoader).loaderNode.getComponent(PlayerHead)
            headObj.refresh(user);
            headObj.hideLevel();
            node.getChildByName("name").getComponent(cc.Label).string = user.getNickname();
            // rank
            let url: string = commonUtils.getCommonUrl(`common_junior_rank${rank}`);
            loadUtils.loadSpriteFrame(url, node.getChildByName("rank").getComponent(cc.Sprite));
            node.scale = rank == 1 ? 1.10 : 0.9;
            // bg
            let iconName: string = rank == 1 ? "chess_7" : "chess_8";
            url = `textures/ui/panel/chess/${iconName}`;
            loadUtils.loadSpriteFrame(url, node.getChildByName("bg").getComponent(cc.Sprite));
            // score
            node.getChildByName("num").getComponent(cc.Label).string = `${data.getScore()}`;
        }
    }

    update(dt: number) {
        super.update(dt);
    }

    onClickWishDice() {
        if (this._chessEnd) {
            this.chessOverTip();
            return;
        }
        let count: number = bagLogic.getGood(Good.GoodId.WishDice).getAmount();
        if (count < 1) {
            gm.toast(stringConfigMap.key_auto_575.Value);
            return;
        }
        this.showWishDice();
    }

    // 心愿骰子
    async onClickChessDiceNum(sender: cc.Event.EventTouch, data: string) {
        let diceNum: number = parseInt(data);
        let count: number = bagLogic.getGood(Good.GoodId.WishDice).getAmount();

        if (count < 1) {
            gm.toast(stringConfigMap.key_auto_575.Value);
        } else {

            let check = async () => {
                if (this.isMeetZombie()) {
                    // 追上僵尸
                    console.warn("玩家追上僵尸");
                    await this.throwDice(this.defaultZombieStep, 1, true, (data) => { });
                } else {
                    await this.throwDice(chessLogic.getRandomStep(true), 1, true, (data) => {
                        if (this.isMeetZombie()) {
                            // 被僵尸追上
                            console.warn("僵尸追上玩家");
                            this.catchByZombie();
                        }
                    });
                }
            }

            await this.throwDice(diceNum, 3, true, async (data: any) => {
                if (this.nowHasStandEvent()) {
                    await this.chessStandEvent(async () => {
                        await check();
                    })
                } else {
                    await check();
                }
            });
        }
    }

    onClickCloseWishDice() {
        this.showWishDice(false);
    }

    onClickTenDice(sender: cc.Event.EventTouch, data: string) {
        this.tenRandom = !this.tenRandom;
        let name: string = this.tenRandom ? "common_radio_select" : "common_radio_unselect";
        let node = sender.currentTarget;
        loadUtils.loadSpriteFrame(commonUtils.getCommonUrl(name), node.getComponent(cc.Sprite));
        this.freshUI();
    }

    // 随机骰子
    async onClickRandomDice() {
        if (this._chessEnd) {
            this.chessOverTip();
            return;
        }
        let count: number = bagLogic.getGood(Good.GoodId.RandomDice).getAmount();
        try {
            if (this.tenRandom) {
                // 十连投掷
                if (count < 10) {
                    gm.toast(stringConfigMap.key_auto_576.Value);
                    return;
                } else {
                    let data = await chessLogic.tenStepCommit();
                    this.updateNowPos();
                    this.freshUI();
                    this.freshAllItem();
                    gcc.core.showLayer("prefabs/panel/chess/TenDicePanel", { data: data });
                }
            } else {
                // 单次随机
                if (count < 1) {
                    gm.toast(stringConfigMap.key_auto_576.Value);
                    return;
                }
                let diceNum: number = chessLogic.getRandomStep();
                this.touch.active = true;
                this.throwAction(diceNum, () => { this.oneChess(diceNum); });
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
                this.refresh();
            }
            else {
                throw e;
            }
        }
    }

    async oneChess(diceNum: number) {
        await this.throwDice(diceNum, 2, true, async (data) => {
            let check = async () => {
                if (this.isMeetZombie()) {
                    // 追上僵尸
                    await this.throwDice(this.defaultZombieStep, 1, true, (data) => { });
                } else {
                    await this.throwDice(chessLogic.getRandomStep(true), 1, true, (data) => {
                        if (this.isMeetZombie()) {
                            // 被僵尸追上
                            if (bagLogic.getGood(Good.GoodId.RandomDice).getAmount() <= 0) {
                                gm.toast(stringConfigMap.key_desc_49.Value);
                            }
                            this.catchByZombie();
                        }
                    });
                }
            }

            if (this.nowHasStandEvent()) {
                this.chessStandEvent(async () => {
                    await check();
                })
            } else {
                await check();
            }
        });
    }

    async onClickChess() {
        if (this._chessEnd) {
            this.chessOverTip();
            return;
        }
        // 骰子获取
        await activityLogic.activityReq(ActivityType.CheckerBoard);
        chessLogic.initDiceTasks();
        gcc.core.showLayer("prefabs/panel/chess/DiceTaskPanel");
    }

    onClickHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "chess" } });
    }

    async onClickChessRank() {
        return;
        let data = await chessLogic.chessRankReq(50);
        gcc.core.showLayer("prefabs/panel/chess/ChessRankPanel", { data: data });
    }

    onClickChessReward() {
        // 圈数奖励
        gcc.core.showLayer("prefabs/panel/chess/ChessRewardPanel");
    }

    onClickHideCatchNode() {
        this.showCatchNode(false);
    }

    showCatchNode(valid: boolean = true) {
        this.catchNode.active = valid;
        if (this.catchNode.active) {
            /*
            this.catchAction(this.catchNode,()=>{
                this.catchNode.active=false;
            })*/
        }
    }

    getChessItem(pos: number[]): chessItem {
        let item: chessItem = this.chessPool.find((a: chessItem) => { return a.pos[0] == pos[0] && a.pos[1] == pos[1]; })
        return item ? item : null;
    }

    protected getChessItemByIndex(cfgId: number): chessItem {
        let item: chessItem = this.chessPool.find((a: chessItem) => { return a.cfgId == cfgId; })
        return item ? item : null;
    }

    protected nowHasStandEvent(): boolean {
        let item = this.getChessItem(this.nowPos);
        return this.hasStandEvent(item.cfgId);
    }

    // 是否触发正邪小屋
    protected hasStandEvent(cfgId: number): boolean {
        return chessLogic.getEventId(cfgId) == ChessEvent.StandHome;
    }

    // 触发正邪小屋事件
    protected async chessStandEvent(callback: Function) {
        let tmp: number = chessLogic.getRandomStep(false);
        let step: number = chessLogic.getEventRandomStep(tmp);
        this.throwAction(tmp, async () => {
            this.showWishDice(false);
            BasePanel.closePanel('RewardPanel');
            try {
                let reward = await chessLogic.standEvent(step);
                let param: chessItem[] = [];
                let nowItem = this.getChessItem(this.nowPos);
                if (step > 0) {
                    param = this.getMoveParam(nowItem, step);
                } else {
                    let preCfgId: number = nowItem.cfgId == 1 ? 24 : nowItem.cfgId - 1;
                    let preItem = this.chessPool.find((a) => { return a.cfgId == preCfgId; })
                    if (preItem) {
                        param.push(nowItem);
                        param.push(preItem);
                    }
                }
                this.moveAction(param, () => {
                    this.updateNowPos();
                    this.freshAllItem(true)
                    gm.getReward(reward);
                    EManager.emit(EName.onUpdateActivityDatas, ActivityType.CheckerBoard);
                    this.freshUI();
                    if (callback) { callback(reward); }
                }, this.preY, false);

            } catch (e) {
                if (e.name == "ToastError") {
                    gm.toast(e.message);
                    this.refresh();
                }
                else {
                    throw e;
                }
            }
        });

    }

    // 投掷骰子
    async throwDice(diceNum: number, type: number, needCommit: boolean, callback: Function) {
        //1:僵尸 2：普通骰子 3：心愿骰子
        this.showWishDice(false);
        let actId: string = this.chessModal.id;
        let step: number = 0;
        let data = this.getChessData();
        step = type == 1 ? (data.zombieStep + diceNum) : (data.playerStep + diceNum);
        try {
            let reward = null;
            if (needCommit) {
                reward = await chessLogic.stepCommit(actId, type, step);
            }
            let pos: number[] = type > 1 ? this.nowPos : this.zombiePos;

            let nowItem = this.getChessItem(pos);
            let param = this.getMoveParam(nowItem, diceNum)
            let preY: number = type > 1 ? this.preY : this.preY * 2;
            let isZombie: boolean = type > 1 ? false : true;
            this.moveAction(param, () => {
                //console.warn(" 寻宝完成一次");
                if (type > 1) {
                    (this.chessModal.roleActivityDatas as ChessActivityDatas).playerStep = step;
                    let id: number = type == 2 ? Good.GoodId.RandomDice : Good.GoodId.WishDice;
                    if (bagLogic.getGood(id).getAmount() > 0) {
                        bagLogic.changeGoodAmount(id, -1);
                    }
                    EManager.emit(EName.onUpdateActivityDatas, ActivityType.CheckerBoard);
                } else {
                    (this.chessModal.roleActivityDatas as ChessActivityDatas).zombieStep = step;
                }
                this.updateNowPos();
                this.freshAllItem(true)
                gm.getReward(reward);
                commitLogic.commitReward(reward, DiamondSource.actChess);
                this.freshUI();
                if (callback) { callback(reward); }
            }, preY, isZombie);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
                this.refresh();
            }
            else {
                throw e;
            }
        }
    }

    private getMoveParam(start: chessItem, step: number): chessItem[] {
        let now: boolean = false;
        let len = this.chessPool.length;
        let param: chessItem[] = [];
        for (let i = 0; i < len; i++) {
            if (this.chessPool[i].pos[0] == start.pos[0] && this.chessPool[i].pos[1] == start.pos[1]) {
                now = true;
            }
            if (now) {
                param.push(this.chessPool[i]);
                if (param.length == step + 1) { break; }
            }

        }
        if (param.length < step + 1) {
            len = step + 1 - param.length;
            for (let i = 0; i < len; i++) {
                param.push(this.chessPool[i]);
            }
        }
        return param;
    }

    // 移动动画
    private moveAction(param: chessItem[], callback: Function, preY: number = 0, isZombie: boolean = false) {
        if (!param && param.length < 2) { if (callback) { callback(); } return; }
        let delay: number = 0.2;
        this.touch.active = true;

        let effects: cc.FiniteTimeAction[] = [];
        let start: cc.ActionInstant = cc.callFunc(() => {
            this.freshChessItem(param[0]);
        });
        for (let i = 0; i < param.length; i++) {
            if (i != 0) {
                let tmp = cc.moveTo(delay, cc.v2(param[i].node.position.x, param[i].node.position.y + preY));
                effects.push(tmp);
                if (i == 1) {
                    effects.push(start);
                }
            }
        }
        let finish: cc.ActionInstant = cc.callFunc(() => {
            this.touch.active = false;
            let finishItem = param[param.length - 1]
            this.nowPos = isZombie ? this.nowPos : finishItem.pos;
            this.zombiePos = isZombie ? finishItem.pos : this.zombiePos;
            this.freshChessItem(finishItem);
            if (callback) { callback(); }
        });
        effects.push(finish);
        if (isZombie) {
            this.zombie.runAction(cc.sequence(effects));
        } else {
            this.player.runAction(cc.sequence(effects));
        }
    }

    private throwAction(num: number, callback: Function) {
        this.actionLayer.active = true;
        let node = this.actionLayer.getChildByName("EffectSz");
        let dice = this.actionLayer.getChildByName("dice");
        let url: string = `textures/ui/panel/chess/chess_point_${num}`;
        loadUtils.loadSpriteFrame(url, dice.getComponent(cc.Sprite));
        dice.active = false;
        let effect = node.getComponent(cc.Animation);
        effect.play("ChessPanel_EffectSz", 0);
        effect.off("finished");
        effect.on("finished", (e) => {
            dice.active = true;
            this.scheduleOnce(() => {
                this.actionLayer.active = false;
                if (callback) { callback(); }
            }, 0.3);
        })
    }

    private catchAction(node: cc.Node, callback: Function) {
        let effectNode = node.getChildByName("EffectAtk");
        let effect = effectNode.getComponent(cc.Animation);
        effect.play("ChessPanel_Atk", 0);
        effect.off("finished");
        effect.on("finished", (e) => {
            this.scheduleOnce(() => {
                if (callback) { callback(); }
            }, 0.5);
        })
    }
}
