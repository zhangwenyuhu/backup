import { unlockConfigMap } from './../../../configs/unlockConfig';
import { ResourceVO } from './../../../proxy/GameProxy';
import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from "../BasePanel";
import playerLogic from "../../../logics/PlayerLogic";
import stringUtils from "../../../utils/StringUtils";
import gm from "../../../manager/GameManager";
import assignmentLogic from '../../../logics/AssignmentLogic';
import { DailyType } from '../../../utils/DefineUtils';
import Card from '../../../data/card/Card';
import EManager, { EName } from "../../../manager/EventManager";
import guideTaskLogic from '../../../logics/GuideTaskLogic';
import UnlockWrapper from '../../widget/unlock/UnlockWrapper';
import pushManager from "../../../manager/PushManager";
import { PushType } from "../../../data/push/PushModal";
import VipBuff from '../../component/VipBuff';
import { RightType } from '../../../logics/RechargeLogic';
import CommonLoader from '../../common/CommonLoader';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/hangup/HangupRewardPanel")
export default class HangupRewardPanel extends PopupPanel {
    @property(cc.Label)
    labelGold: cc.Label = null;

    @property(cc.Label)
    labelExp: cc.Label = null;

    @property(cc.Label)
    labelPlayerExp: cc.Label = null;

    @property(cc.Label)
    labelTime: cc.Label = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    list: cc.Node = null;

    @property(cc.Node)
    empty: cc.Node = null;

    @property(cc.Node)
    btnFastHangup: cc.Node = null;

    @property(cc.Node)
    buffGold: cc.Node = null;

    @property(cc.Node)
    buffExp: cc.Node = null;

    protected _resource: ResourceVO = null;
    protected _dt: number = 0;

    onInit(data: { resource: ResourceVO, dt: number }) {
        super.onInit(data);
        this._resource = data.resource;
        this._dt = data.dt;
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.heroItem.parent = null;
        this.equipItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.heroItem.destroy();
        this.equipItem.destroy();
    }

    onEnable() {
        super.onEnable();
        this.btnFastHangup.active = UnlockWrapper.isUnlock(unlockConfigMap.快速挂机);
    }

    start() {
        super.start();

        this.labelGold.string = `+${playerLogic.goldSpeed}/m`;
        this.labelExp.string = `+${playerLogic.heroExpSpeed}/m`;
        this.labelPlayerExp.string = `+${playerLogic.groupExpSpeed}/m`;
        this.labelTime.string = stringUtils.formatTimeWithHour(Math.floor(this._dt));

        this.list.destroyAllChildren();
        if (this._resource) {
            let cards = playerLogic.getCards(this._resource);
            cards.sort((a: Card, b: Card) => { return a.getIndex() - b.getIndex() });
            this.empty.active = false;
            gm.createRewards(cards, {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem
            }, this.list, 0);
        }
        else {
            this.content.active = false;
        }

        guideTaskLogic.guideTaskProgressCommit(5007, 1, true);
        pushManager.updateLocalPushs([PushType.OFFLINE_BENEFIT]);

        let loader = this.buffGold.getComponent(CommonLoader).loaderNode;
        loader.getComponent(VipBuff).buffType = RightType.IdleGold;
        loader = this.buffExp.getComponent(CommonLoader).loaderNode;
        loader.getComponent(VipBuff).buffType = RightType.IdleExp;
    }

    update(dt: number) {
        super.update(dt);
        this._dt = Math.min(this._dt + dt, 12 * 3600);
        this.labelTime.string = stringUtils.formatTimeWithHour(Math.floor(this._dt));
    }

    onClaim() {
        this.closePanel();
    }

    onFast() {
        gcc.core.showLayer("prefabs/panel/hangup/HangupFastPanel");
    }

    closePanel() {
        let cards: Card[] = [];
        if (this._resource) {
            assignmentLogic.dailyTaskProCommit(DailyType.hangup_reward);
            cards = playerLogic.getCards(this._resource);
            cards.sort((a: Card, b: Card) => { return a.getIndex() - b.getIndex() });
            EManager.emit(EName.onRewardFly, cards);
            EManager.emit(EName.onFreshGuideTask);
        }
        else {
            gm.toast(stringConfigMap.key_no_claim.Value);
        }
        if (cards.length > 0) {
            playerLogic.addRewards(cards);
        }
        super.closePanel();
    }
}