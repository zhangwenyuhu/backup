import { stringConfigMap } from './../../../configs/stringConfig';
import { EName } from './../../../manager/EventManager';
import { PopupPanel } from "../BasePanel";
import playerLogic from "../../../logics/PlayerLogic";
import stringUtils from "../../../utils/StringUtils";
import gm from "../../../manager/GameManager";
import EManager from "../../../manager/EventManager";
import GameProxy, { HangUpSpeedBO } from '../../../proxy/GameProxy';
import assignmentLogic from '../../../logics/AssignmentLogic';
import { DailyType, VideoKey } from '../../../utils/DefineUtils';
import videoAdLogic, { AD_TYPE } from '../../../logics/VideoAdLogic';
import CommonLoader from '../../common/CommonLoader';
import VideoBtn from '../../../gleecomponent/VideoBtn';
import bagLogic from '../../../logics/BagLogic';
import Good from '../../../data/card/Good';
import guideTaskLogic from '../../../logics/GuideTaskLogic';
import pushManager from "../../../manager/PushManager";
import { PushType } from "../../../data/push/PushModal";
import cm from '../../../manager/ConfigManager';
import rechargeLogic, { RightType } from '../../../logics/RechargeLogic';
import gotoUtils, { GotoModule } from '../../../utils/GotoUtils';
import vipconfig from '../../../configs/vipconfig';
import { MarketTab } from '../market/MarketPanel';
import { defaultConfigMap } from '../../../configs/defaultConfig';
import giftLogic from '../../../logics/GiftLogic';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/hangup/HangupFastPanel")
export default class HangupFastPanel extends PopupPanel {
    @property(cc.Label)
    labelCost: cc.Label = null;

    @property(cc.Label)
    labelCountDown: cc.Label = null;

    @property(cc.Label)
    labelCount: cc.Label = null;

    @property(cc.Label)
    labelFree: cc.Label = null;

    @property(cc.Node)
    nodeCost: cc.Node = null;

    @property(cc.Button)
    btnConfirm: cc.Button = null;

    @property(cc.Node)
    btnVideo: cc.Node = null;

    @property(cc.Button)
    btnMonthBuy: cc.Button = null;

    @property(cc.Label)
    labelMonthBuyCount: cc.Label = null;

    @property(cc.Node)
    monthBuyDesc: cc.Node = null;

    protected _isRequesting: boolean = false;
    protected _bVideo: boolean = false;

    onLoad() {
        super.onLoad();
        this.registerEvents();
    }

    async start() {
        super.start();
        this._updateView();

        let delta = Math.max(0, playerLogic.quickHangResetTimestamp - gm.getCurrentTimestamp());
        this.labelCountDown.string = stringUtils.formatTimeWithHour(Math.floor(delta / 1000));
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onHangupDirty, () => {
            this._updateView();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onApplyOrder, () => {
            this._updateView();
        });
        this._eventListeners.push(listener);
    }

    update(dt: number) {
        super.update(dt);

        if (this._isRequesting) {
            return;
        }

        let delta = Math.max(0, playerLogic.quickHangResetTimestamp - gm.getCurrentTimestamp());
        this.labelCountDown.string = stringUtils.formatTimeWithHour(Math.floor(delta / 1000));
        if (delta == 0) { this._refreshHangup(); }
    }

    onGotoMonthPanel() {
        gcc.core.showLayer("prefabs/panel/market/MarketPanel", {
            data: {
                tabIndex: MarketTab.MonthCard,
            }
        });
        this.closePanel();
    }

    async onConfirm() {
        try {
            let cards = await playerLogic.doClaimHangupFast(this._bVideo);
            gm.rewardGoldFly();
            setTimeout(() => {
                gcc.core.showLayer("prefabs/panel/reward/RewardPanel", {
                    data: {
                        cards: cards,
                        callback: () => {
                            EManager.emit(EName.onRewardFly, cards);
                        }
                    }, modalTouch: true
                });
            }, 2370);

            pushManager.updateLocalPushs([PushType.OFFLINE_BENEFIT]);
            assignmentLogic.dailyTaskProCommit(DailyType.hangup_quick);
            assignmentLogic.dailyTaskProCommit(DailyType.hangup_reward);
            await guideTaskLogic.guideTaskProgressCommit(1007, 1);
            await guideTaskLogic.guideTaskProgressCommit(5007, 1);
            EManager.emit(EName.onFreshGuideTask);
            this._bVideo = false;
            if (playerLogic.quickHangRemain > 0 || videoAdLogic.canVideoAd(AD_TYPE.QuickHangup)) {
                this._updateView();
            }
            else {
                this.closePanel();
            }
        } catch (e) {
            if (e.name == "ToastError") {
                if (e.message == stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: bagLogic.getGood(Good.GoodId.Diamond).getName() })) {
                    gm.diamondLessToast();
                }
                else {
                    gm.toast(e.message);
                }
            }
            else {
                throw e;
            }
        }
    }

    protected async _refreshHangup() {
        this._isRequesting = true;

        await videoAdLogic.allVideoAdTimesReq();
        let hangupProto = await gm.request<HangUpSpeedBO>(GameProxy.apihangUpgetHangUpSpeed)
        playerLogic.updateHangup(hangupProto);

        this._isRequesting = false;
    }

    protected _updateView() {
        let isFree = false;
        this.updateMonthBuyTip();

        this.btnMonthBuy.node.active = playerLogic.quickHangRemain <= 0 && !giftLogic.isBuySuperMonthCard();
        this.btnConfirm.node.active = playerLogic.quickHangRemain > 0 || !this.btnMonthBuy.node.active;

        this.labelCount.string = playerLogic.quickHangRemain.toString();
        if (playerLogic.quickHangRemain > 0) {
            this.btnConfirm.interactable = true;
            if (playerLogic.quickHangCost > 0) {
                this.labelFree.node.active = false;
                this.nodeCost.active = true;
                this.labelCost.string = playerLogic.quickHangCost.toString();
            }
            else {
                this.labelFree.node.active = true;
                this.nodeCost.active = false;
                this.labelFree.string = '免费领取';

                isFree = true;
            }
        }
        else {
            this.btnConfirm.interactable = false;
            this.labelFree.node.active = true;
            this.nodeCost.active = false;
            this.labelFree.string = stringConfigMap.key_in_cooling.Value;
        }

        if (!isFree) {
            let bVideo = videoAdLogic.canVideoAd(AD_TYPE.QuickHangup);
            this.btnVideo.active = bVideo;
            if (this.btnVideo.active) {
                let videoNode = this.btnVideo.getComponent(CommonLoader).loaderNode;

                let desc = stringUtils.getString(stringConfigMap.key_free_times.Value, {
                    count1: videoAdLogic.adNowTimes(AD_TYPE.QuickHangup),
                    count2: videoAdLogic.adMaxTimes(AD_TYPE.QuickHangup)
                });
                videoNode.getComponent(VideoBtn).videoText = desc;
                videoNode.getComponent(VideoBtn).eventName = VideoKey.QuickHangup;
                videoNode.getComponent(VideoBtn).onSuccessFunc = () => {
                    this._bVideo = true;
                    videoAdLogic.videoPlayTimesCount(AD_TYPE.QuickHangup);
                    this.onConfirm();
                }
            }
        }
        else {
            this.btnVideo.active = false;
        }
    }

    isMonthCardValid(): boolean {
        return giftLogic.isBuyNormalMonthCard() || giftLogic.isBuySuperMonthCard();
    }

    protected updateMonthBuyTip() {
        this.monthBuyDesc.active = !giftLogic.isBuySuperMonthCard();
        if (this.monthBuyDesc.active) {
            let nTip: string = '购买月卡,可增加快速挂机次数上限至';
            let sTip: string = '购买超级月卡,可增加快速挂机次数上限至';
            if (giftLogic.isBuyNormalMonthCard()) {
                this.monthBuyDesc.getChildByName('label').getComponent(cc.Label).string = sTip;
                this.labelMonthBuyCount.string = '' + defaultConfigMap.smonthcardquickprofit.value + `次`;
            } else {
                this.monthBuyDesc.getChildByName('label').getComponent(cc.Label).string = nTip;
                this.labelMonthBuyCount.string = '' + defaultConfigMap.monthcardquickprofit.value + `次`;
            }

        }
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await this._refreshHangup();
    }
}
