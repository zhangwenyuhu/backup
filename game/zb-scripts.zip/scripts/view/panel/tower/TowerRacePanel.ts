import { FullscreenPanel } from "../BasePanel";
import towerLogic, { RaceType } from "../../../logics/TowerLogic";
import gm from "../../../manager/GameManager";
import EManager, { EName } from "../../../manager/EventManager";
import { MarketTab } from "../market/MarketPanel";
import { MarketDiscountTab } from "../../component/Market/DiscountMarketModule";
import stringUtils from "../../../utils/StringUtils";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/tower/TowerRacePanel")
export default class TowerRacePanel extends FullscreenPanel {

    @property(cc.Node)
    race_normal: cc.Node = null;

    @property(cc.Node)
    race_1: cc.Node = null;

    @property(cc.Node)
    race_2: cc.Node = null;

    @property(cc.Node)
    race_3: cc.Node = null;

    @property(cc.Node)
    race_4: cc.Node = null;

    @property(cc.Material)
    normalMaterial: cc.Material = null;

    @property(cc.Material)
    grayMaterial: cc.Material = null;

    private _nowDay: number = 0;
    protected async _preloadRes() {
        await super._preloadRes();
    }

    onLoad() {
        super.onLoad();
    }

    start() {
        super.start();
        towerLogic.initMyTopHero();

        this.freshUI();
        this.registerEvent();
        this.schedule(() => { this.checkOpen(); }, 1);
    }

    registerEvent() {
        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data == "TowerRacePanel") {
                this.freshUI();
            }
        });
        this._eventListeners.push(listener);
    }

    freshUI() {
        let nowDate = new Date(gm.getCurrentTimestamp());
        this._nowDay = nowDate.getUTCDay();

        this.renderRaceItem(RaceType.Wuzhuang, this.race_1);
        this.renderRaceItem(RaceType.Jixie, this.race_2);
        this.renderRaceItem(RaceType.Bianzhong, this.race_3);
        this.renderRaceItem(RaceType.Jiangshi, this.race_4);

        let nowLevel = towerLogic.getCurrentTower();
        let maxLevel = towerLogic.getMaxLevel();
        if (nowLevel > maxLevel) { nowLevel = maxLevel; }
        this.setTowerLevel(this.race_normal.getChildByName("level"), nowLevel);
    }

    checkOpen() {
        let nowDate = new Date(gm.getCurrentTimestamp());
        let currentDay: number = nowDate.getUTCDay();
        if (this._nowDay < currentDay) {
            this.freshUI();
        }
    }

    update(dt: number) {
        super.update(dt);
    }

    onClickRaceItem(sender: cc.Event.EventTouch, data: string) {
        let type = parseInt(data);
        if (type == RaceType.Default) {
            // 普通塔
            gcc.core.showLayer("prefabs/panel/tower/SimpleRaceTowerPanel", { data: type });
        } else {
            // 种族塔
            console.log("utc time: ")
            if (this.raceOpen(type)) {
                gcc.core.showLayer("prefabs/panel/tower/SimpleRaceTowerPanel", { data: type });
            } else {
                let openTime: string = this.getRaceOpenDays(type).join("/");
                gm.toast(stringUtils.getString(stringConfigMap.key_auto_635.Value, {p1: openTime}));
            }
        }
    }

    renderRaceItem(type: RaceType, item: cc.Node) {
        let open: boolean = this.raceOpen(type);
        let bg = item.getChildByName("bg");
        bg.getComponent(cc.Sprite).setMaterial(0, open ? this.normalMaterial : this.grayMaterial);
        item.getChildByName("labelBg").active = !open;
        item.getChildByName("layout").active = !open;

        let nowLevel: number = towerLogic.getRaceTowerNowLevel(type);
        let maxLevel: number = towerLogic.getMaxLevel(type);
        if (nowLevel > maxLevel) { nowLevel = maxLevel; }
        this.setTowerLevel(item.getChildByName("level"), nowLevel);
    }

    onTowerOrder() {
        gcc.core.showLayer("prefabs/panel/market/MarketPanel", {
            data: {
                tabIndex: MarketTab.Discount,
                tabChildIndex: MarketDiscountTab.TowerCommand,
            }
        });
    }

    private setTowerLevel(node: cc.Node, level: number) {
        if (node && node.getComponent(cc.Label)) {
            level = level <= 0 ? 1 : level;
            node.getComponent(cc.Label).string = `${level}` + "层";
        }
    }

    private getRaceOpenDays(type: RaceType): number[] {
        let days: number[] = [];
        if (type == RaceType.Wuzhuang) {
            days = [1, 5, 7];
        } else if (type == RaceType.Jixie) {
            days = [2, 5, 7];
        } else if (type == RaceType.Bianzhong) {
            days = [3, 6, 7];
        } else if (type == RaceType.Jiangshi) {
            days = [4, 6, 7];
        }
        return days;
    }

    private raceOpen(type: RaceType): boolean {
        //return true;
        let open: boolean = false;
        let days = this.getRaceOpenDays(type);
        let nowDate = new Date(gm.getCurrentTimestamp());
        let nowDay: number = nowDate.getUTCDay();
        nowDay = nowDay == 0 ? 7 : nowDay;
        open = days.some((v, i, a) => { return v == nowDay; })
        return open;
    }
}
