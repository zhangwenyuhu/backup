import { PopupPanel } from "../BasePanel";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import towerLogic, { RaceType } from "../../../logics/TowerLogic";
import cm from "../../../manager/ConfigManager";
import { GoodVO } from "../../../proxy/GameProxy";
import Good from "../../../data/card/Good";
import CommonLoader from "../../common/CommonLoader";
import GoodCard from "../../component/Good/GoodCard";
import User from "../../../data/user/User";
import gm from "../../../manager/GameManager";
import {stringConfigMap} from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/tower/TowerDetailPanel")
export default class TowerDetailPanel extends PopupPanel {

    @property(cc.Node)
    emptyTips: cc.Node = null;

    @property(cc.Node)
    playerScrollView: cc.Node = null;

    @property(cc.Node)
    towerRewards: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    private _towerId: number = 0;
    private type: RaceType = 0;
    onInit(data: any) {
        this._towerId = data.level;
        this.type = data.type;
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    async start() {
        super.start();

        await towerLogic.towerDetailReq(this._towerId, this.type);
        this.initScollView();
        this.initTowerRewards(this._towerId);

        let fightData = towerLogic.getTowerInfo(this._towerId, this.type);
        this.emptyTips.active = fightData.pass.length > 0 ? false : true;
        //this.emptyTips.active = false;
    }

    initScollView() {
        let tmp: User[] = towerLogic.getTowerPass(this._towerId, this.type);
        this.playerScrollView.getComponent(ScrollViewLoader).refresh(tmp, false, this.onClickDetail.bind(this));
    }

    async onClickDetail(data: any) {
        if (data instanceof User) {
            await towerLogic.towerFightRecordReq(data.getRoleId(), this._towerId, this.type);
            let reportData = towerLogic.getTowerRecord(data.getRoleId(), this._towerId, this.type);
            if (!reportData) {
                gm.toast(stringConfigMap.key_desc_62.Value);
                return;
            }
            reportData.type = this.type;
            gcc.core.showLayer("prefabs/panel/tower/TowerReportPanel", { data: reportData });
        }
    }

    initTowerRewards(id: number) {
        this.towerRewards.destroyAllChildren();
        let rewards: number[][] = towerLogic.getTowerPassRewards(id, this.type);
        rewards.forEach((v, i, a) => {
            gm.showGoodItem(v, {
                goodItem: this.goodItem,
                equipItem: this.equipItem,
                heroItem: this.heroItem
            }, this.towerRewards);
        });
    }
}
