import { PopupPanel } from "../BasePanel";
import Hero from "../../../data/card/Hero";
import Tower from "../../../data/tower/Tower";
import ArenaBattleReportItem from "../../component/Arena/ArenaBattleReportItem";
import friendMerLogic from "../../../logics/FriendMerLogic";
import playerLogic from "../../../logics/PlayerLogic";
import tipUtils from "../../../utils/TipUtils";
import towerLogic from "../../../logics/TowerLogic";
import { RoleVO } from "../../../proxy/GameProxy";
import Monster from "../../../data/card/Monster";
import Player from "../../../data/user/Player";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/tower/TowerReportPanel")
export default class TowerReportPanel extends PopupPanel {

    @property(cc.Node)
    battle_report1: cc.Node = null;

    @property(cc.Node)
    battle_report2: cc.Node = null;

    async start() {
        super.start();

        this.initReportTip(this.battle_report1);
        this.initReportTip(this.battle_report2);

        let contribution = this._data.result;
        let heros = {
            selfHero: this._data.selfTroops,
            enemyHero: this._data.enemyTroops,
        }
        let selfData = this._getItemListData(heros.selfHero, contribution, this._data.win);

        let selfUser;
        if (this._data.role == playerLogic.getPlayer().getRoleId()) {
            selfUser = playerLogic.getPlayer();
        } else {
            selfUser = friendMerLogic.getUserDataByRoleId(this._data.role);
        }

        if (!selfUser) {
            await friendMerLogic.userDataReq(this._data.role);
            selfUser = friendMerLogic.getUserDataByRoleId(this._data.role);
        }
        this.battle_report1.getComponent(ArenaBattleReportItem).refresh({ data: selfData, user: selfUser });
        let enemyData = this._getItemListData(heros.enemyHero, contribution, !this._data.win);

        let tower;
        if (this._data.type > 0) {
            let race = towerLogic.getRaceTower(this._data.type, this._data.id);
            tower = new Tower(race.cfg.ID, 1);
        } else {
            tower = new Tower(this._data.id)
        }
        let monster = tower.getBoss() as Monster;
        let role = new RoleVO();
        role.nick = monster.getName();
        role.lv = monster.getLevel();
        role.avatar = monster.getIndex().toString();
        role.avatarFrame = "";
        role.mainForce = [];
        let enemyUser = new Player(role);
        this.battle_report2.getComponent(ArenaBattleReportItem).refresh({ data: enemyData, user: enemyUser });
    }

    protected _getItemListData(heros: Hero[], contribution: rpgfight.HeroContributionStatistic[], isWin: boolean) {
        let itemData = [];
        let totalHurt: number = 0;
        let totalHealed: number = 0;
        let totalInjured: number = 0;
        heros = heros.filter((v, i, a) => { return v; })
        let report = contribution.find(a => a.heroId == heros[0].getId());
        if (report) {
            for (let hero of heros) {
                let reportData = contribution.find(a => a.heroId == hero.getId());
                totalHurt += reportData.hpHurt;
                totalHealed += reportData.hpHealed;
                totalInjured += reportData.hpInjured;
            }
            for (let hero of heros) {
                let data = {};
                data["hero"] = hero;
                data["report"] = contribution.find(a => a.heroId == hero.getId());
                data["totalHpHurt"] = totalHurt;
                data["totalHpHealed"] = totalHealed;
                data["totalHpInjured"] = totalInjured;
                data["isWin"] = isWin;
                itemData.push(data);
            }
        } else {
            for (let i = 0; i < heros.length; i++) {
                let heroId = this._data.enemyIndex[i];
                let reportData = contribution.find(a => a.heroId == heroId);
                totalHurt += reportData.hpHurt;
                totalHealed += reportData.hpHealed;
                totalInjured += reportData.hpInjured;
            }

            for (let i = 0; i < heros.length; i++) {
                let data = {};
                data["hero"] = heros[i];
                let heroId = this._data.enemyIndex[i];
                data["report"] = contribution.find(a => a.heroId == heroId);
                data["totalHpHurt"] = totalHurt;
                data["totalHpHealed"] = totalHealed;
                data["totalHpInjured"] = totalInjured;
                data["isWin"] = isWin;
                itemData.push(data);
            }
        }

        return itemData;
    }

    onPlay() {
        let tower;
        if (this._data.type > 0) {
            let race = towerLogic.getRaceTower(this._data.type, this._data.id);
            tower = new Tower(race.cfg.ID, 1);
        } else {
            tower = new Tower(this._data.id)
        }
        let sceneConfig = new rpgfight.SceneConfig();
        sceneConfig.width = cc.director.getWinSize().width;
        sceneConfig.height = 750;
        sceneConfig.time = tower.getTime() * 1000;
        sceneConfig.seed = this._data.seed || 0;

        gcc.core.showLayer("prefabs/panel/battle/BattleRecordPanel", {
            data: {
                battleData: tower,
                troops: {
                    selfTroop: this._data.selfTroops,
                    enemyTroop: tower.getMonsters(),
                },
                sceneConfig: sceneConfig,
                skills: this._data.skills,
            },
        });

        this.scheduleOnce(() => {
            this.closePanel();
        });

    }

    initReportTip(node: cc.Node) {
        if (!node) { return; }

        for (let i = 0; i < 3; i++) {
            let ex: number = i + 1;
            let name: string = `arena_report_icon${ex}`;
            let tmp: cc.Node = node.getChildByName(name);
            if (tmp) {
                tmp.off(cc.Node.EventType.TOUCH_END);
                tmp.on(cc.Node.EventType.TOUCH_END, (e: cc.Event.EventTouch) => {
                    tipUtils.showTip(tmp, this.getTip(ex));
                })
            }
        }
    }

    getTip(index: number): string {
        let tmp: string = "";
        if (index == 1) {
            tmp = "伤害量";
        } else if (index == 2) {
            tmp = "治疗量";
        } else if (index == 3) {
            tmp = "承受伤害量";
        }
        return tmp;
    }
}