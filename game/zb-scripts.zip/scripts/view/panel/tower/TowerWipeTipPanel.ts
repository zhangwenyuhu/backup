import { PopupPanel } from "../BasePanel";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/tower/TowerWipeTipPanel")
export default class TowerWipeTipPanel extends PopupPanel {

    @property(cc.Label)
    desc: cc.Label = null;

    protected _callback: Function = null;
    protected _level: number = 0;
    onInit(data: any) {
        this._callback = data ? data.callback : null;
        this._level = data ? data.level : 0;
    }

    async start() {
        super.start();

        //this.desc.string = `推荐您直接扫荡${this._level}层`;
    }

    onClickGoGoGo() {
        if (this._callback) { this._callback(); }
        this.closePanel();
    }
}
