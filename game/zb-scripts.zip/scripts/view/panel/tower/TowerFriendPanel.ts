import { PopupPanel } from "../BasePanel";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import User from "../../../data/user/User";
import towerLogic, { RaceType } from "../../../logics/TowerLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/tower/TowerFriendPanel")
export default class TowerFriendPanel extends PopupPanel {

    @property(cc.Node)
    friendScrollView: cc.Node = null;

    @property(cc.Node)
    emptyTips: cc.Node = null;

    private _towerId: number = 0;
    private type:RaceType=0;
    onInit(data: any) {
        this._towerId = data.level;
        this.type = data.type;
    }

    start() {
        super.start();

        this.initScollView();

        let fightData = towerLogic.getTowerInfo(this._towerId,this.type);
        this.emptyTips.active = fightData.friends.length > 0 ? false : true;
    }

    initScollView() {
        let tmp: User[] = towerLogic.getTowerFriends(this._towerId,this.type);
        this.friendScrollView.getComponent(ScrollViewLoader).refresh(tmp);
    }
}
