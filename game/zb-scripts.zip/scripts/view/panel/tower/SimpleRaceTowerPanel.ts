import { EName } from './../../../manager/EventManager';
import { FullscreenPanel } from "../BasePanel";
import towerLogic, { RaceType } from "../../../logics/TowerLogic";
import EManager from "../../../manager/EventManager";
import { Goto, BattleType } from '../../../utils/DefineUtils';
import List from '../../common/List';
import RaceTowerItem from '../../component/tower/RaceTowerItem';
import benefitLogic from '../../../logics/BenefitLogic';
import TopTitle from '../../component/TopTitle';
import gm from '../../../manager/GameManager';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/tower/SimpleRaceTowerPanel")
export default class SimpleRaceTowerPanel extends FullscreenPanel {

    @property(cc.Node)
    title: cc.Node = null;

    @property(List)
    towerList: List = null;

    @property(cc.Widget)
    towerListWidget: cc.Widget = null;

    @property(cc.Label)
    passLevel: cc.Label = null;

    @property(cc.Node)
    passReward: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    private _towersTag: { [key: number]: boolean } = {};
    private _nowLevel: number = 0;
    private _towers: any[] = [];
    private _raceType: number = 0;
    private _startFriendReq: boolean = false;

    protected _towerScrollView: cc.ScrollView = null;
    protected _needRefresh: boolean = false;

    onInit(data: any) {
        this._raceType = data;

        towerLogic.initMyTopHero();
    }

    onLoad() {
        super.onLoad();
        this.registerEvents();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    // 刷新下一次通关可获得奖励的楼层信息
    protected updatePassReward() {
        let data = towerLogic.getNextPassRewardTower(this._raceType);
        this.passLevel.node.parent.active = data ? true : false;
        if (data) {
            this.passLevel.string = `${data.getLevel()}层`;

            this.passReward.destroyAllChildren();
            let rewards: number[][] = [data.getPassReward()];
            rewards.forEach((v, i, a) => {
                gm.showGoodItem(v, {
                    goodItem: this.goodItem,
                    equipItem: this.equipItem,
                    heroItem: this.heroItem
                }, this.passReward, 0.65);
            });
        }
    }

    start() {
        super.start();
        let title: string = towerLogic.getRaceTitle(this._raceType);
        this.title.getComponent(TopTitle).updateTitle(title);

        this.towerListWidget.updateAlignment();
        this.towerList.viewTopOffset = 100;
        this.towerList.viewBottomOffset = -130;
        this._towerScrollView = this.towerList.getComponent(cc.ScrollView);

        this.refreshTowerList();
        this.scheduleOnce(() => { this.moveToCurrentLevel(0.1) }, 0.1);
        this.scheduleOnce(() => {
            this._startFriendReq = true;
            for (let i = 0; i < 4; i++) {
                this.scheduleOnce(() => {
                    this.towerFriendsReq(this._towers.length - i - 1);
                }, 0.2 * i);
            }
        }, 1.5);
        this.updatePassReward();
    }

    update(dt: number) {
        super.update(dt);

        this._towerScrollView.setTouchEnable(true);
        for (let child of this.towerList.content.children) {
            let item = child.getComponent(RaceTowerItem);
            if (!item.isTouchable) {
                this._towerScrollView.setTouchEnable(false);
                break;
            }
        }
    }

    onEnable() {
        //console.log('TowerPanel onEnable');
        super.onEnable();
        if (this._needRefresh) {
            this.refreshTowerList();
            this.moveToCurrentLevel();
            this._needRefresh = false;
        }
    }

    onDestroy() {
        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();

        EManager.emit(EName.onFreshPanel, "TowerRacePanel");
        super.onDestroy();
    }

    onTowerScrolling(target, data) {
        if (this._startFriendReq) {
            this.towerFriendsReq(this.getNowScrollingLevel());
        }
    }

    getNowScrollingLevel(): number {
        let maxLevel = this._towers.length;
        let scrollLevel: number = maxLevel;
        let offSet = this._towerScrollView.getScrollOffset();
        let itemHeight: number = 370;
        scrollLevel = maxLevel - Math.floor(offSet.y / itemHeight) - 3;
        return scrollLevel;
    }

    refreshTowerList() {
        if (this._raceType == RaceType.Default) {
            this._towers = towerLogic.getAllTowers();
        } else {
            this._towers = towerLogic.getRaceTowers(this._raceType);
        }
        this._nowLevel = towerLogic.getCurrentTower(this._raceType);
        this.towerList.numItems = this._towers.length;
    }

    moveToCurrentLevel(sec?: number) {
        let cur = towerLogic.getCurrentTower(this._raceType);
        let toIndex: number = cur > 3 ? 2 : cur - 2;
        this.towerList.scrollTo(toIndex, sec);
    }

    onTowerItemRender(item: cc.Node, index: number) {
        let tower = this._towers[index];
        let comp = item.getComponent(RaceTowerItem);
        comp.refresh(tower);
        comp.validPassReward({
            goodItem: this.goodItem,
            equipItem: this.equipItem,
            heroItem: this.heroItem
        })
        item.zIndex = index;
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType, goto: Goto }) => {
            if (data.type != BattleType.Tower) {
                return;
            }

            if (typeof data.goto == "number") {
                if (data.goto == Goto.HeroList) {
                    this.closePanel();
                    return;
                } else if (data.goto == Goto.TowerFight) {
                    this._needRefresh = true;

                    let tower = towerLogic.getTowerInfo(towerLogic.getCurrentTower(this._raceType), this._raceType);
                    gcc.core.showLayer("prefabs/panel/battle/BattlePreparePanel", { data: tower });
                    return;
                }
            }

            let currentLevel = towerLogic.getCurrentTower(this._raceType);
            if (currentLevel > this._nowLevel) {
                this._needRefresh = true;
                this.checkGift(this._nowLevel - 1);
            }
            this.updatePassReward();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onWipeTower, (data) => {
            let currentLevel = towerLogic.getCurrentTower(this._raceType);
            if (currentLevel > this._nowLevel) {
                this.refreshTowerList();
                this.moveToCurrentLevel();
                this.checkGift(this._nowLevel - 1);
            }
            this.updatePassReward();
        });
        this._eventListeners.push(listener);
    }

    onClickHelp() {
        let type = towerLogic.getRaceConfigType(this._raceType);
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: type } });
    }
    onClickRank() {
        gcc.core.showLayer("prefabs/panel/tower/TowerRankPanel", { data: this._raceType });
    }

    towerFriendsReq(id: number) {
        if (id <= 0) { return; }
        if (this._towersTag[id]) { return; }

        console.log(`开始请求好友 type:${this._raceType} level:${id}`);
        towerLogic.towerFriendsReq(id, this._raceType);
        this._towersTag[id] = true;
    }

    async checkGift(level: number) {
        let type: number = 3;
        type = this._raceType > 0 ? 4 : type;
        await benefitLogic.checkSurpriseGift(type, level);
    }
}
