import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from "../BasePanel";
import Tower from "../../../data/tower/Tower";
import gm from "../../../manager/GameManager";
import towerLogic from "../../../logics/TowerLogic";
import stringUtils from "../../../utils/StringUtils";
import skybuildconfig from '../../../configs/skybuildconfig';
import Good from '../../../data/card/Good';
import commonUtils from '../../../utils/CommonUtils';
import factionconfig from '../../../configs/factionconfig';
import factionskybuildconfig from '../../../configs/factionskybuildconfig';
import CommonLoader from '../../common/CommonLoader';
import GoodCard from '../../component/Good/GoodCard';
import cm from '../../../manager/ConfigManager';
import bagLogic from '../../../logics/BagLogic';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/tower/TowerFindPanel")
export default class TowerFindPanel extends PopupPanel {
    @property(cc.Label)
    labelTowerLevel: cc.Label = null;

    @property(cc.Label)
    labelFindCount: cc.Label = null;

    @property(cc.Label)
    labelFree: cc.Label = null;

    @property(cc.Node)
    nodeCost: cc.Node = null;

    @property(cc.Label)
    labelCost: cc.Label = null;

    @property(cc.Node)
    goodContainer: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Button)
    btnSearch: cc.Button = null;

    protected _tower: Tower = null;
    protected _nextRefreshTimestamp: number = 0;

    onInit(tower: Tower) {
        this._tower = tower;
    }

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
    }

    onDestroy() {
        this.goodItem.destroy();

        super.onDestroy();
    }

    start() {
        super.start();

        this.labelTowerLevel.string = `${this._tower.getLevel() - 1}层`;
        this._updateInfo();

        let goods: { [key: number]: Good } = {};
        if (this._tower.getRaceType() == 0) {
            for (let config of skybuildconfig) {
                if (config.floorlevel == this._tower.getLevel()) {
                    break;
                }
                for (let reward of config.searchreward) {
                    let good = commonUtils.item2Card(reward) as Good;
                    if (goods[good.getIndex()]) {
                        goods[good.getIndex()].changeAmount(good.getAmount());
                    }
                    else {
                        goods[good.getIndex()] = good;
                    }
                }
            }
        }
        else {
            for (let config of factionskybuildconfig) {
                if (config.Faction != this._tower.getRaceType()) {
                    continue;
                }
                if (config.FactionFloor == this._tower.getLevel()) {
                    break;
                }
                for (let reward of config.searchreward) {
                    let good = commonUtils.item2Card(reward) as Good;
                    if (goods[good.getIndex()]) {
                        goods[good.getIndex()].changeAmount(good.getAmount());
                    }
                    else {
                        goods[good.getIndex()] = good;
                    }
                }
            }
        }

        let rewards = Object.values(goods);
        for (let reward of rewards) {
            let item = cc.instantiate(this.goodItem);
            item.parent = this.goodContainer;

            let loader = item.getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(GoodCard);
            comp.refresh(reward);
            comp.registerOnGoodInfo();
        }
    }

    update(dt: number) {
        super.update(dt);

        if (this._nextRefreshTimestamp > 0) {
            if (gm.getCurrentTimestamp() > this._nextRefreshTimestamp) {
                this._nextRefreshTimestamp = 0;
                towerLogic.doGetSearchInfo(this._tower).then(() => {
                    if (cc.isValid(this)) {
                        this._updateInfo();
                    }
                });
            }
        }
    }

    async onSearch() {
        try {
            await towerLogic.doSearchRewards(this._tower);
            this._updateInfo();
        } catch (e) {
            if (e.name == "ToastError") {
                let good = bagLogic.getGood(Good.GoodId.Diamond);
                if (e.message == stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: good.getName() })) {
                    gm.diamondLessToast();
                }
                else {
                    gm.toast(e.message);
                }
            }
            else {
                throw e;
            }
        }
    }

    protected _updateInfo() {
        let remainCount = towerLogic.getSearchRemainCount(this._tower);
        this.labelFindCount.string = stringUtils.getString(stringConfigMap.key_times.Value, { count: remainCount });
        this.labelFree.node.active = towerLogic.isSearchFree(this._tower);

        let cost = towerLogic.getSearchCost(this._tower);
        if (this.labelFree.node.active) {
            this.nodeCost.active = false;
        }
        else {
            this.nodeCost.active = remainCount > 0 && cost > 0;
        }
        if (this.nodeCost.active) {
            this.labelCost.string = cost.toString();
        }
        this.btnSearch.interactable = remainCount > 0;
        this._nextRefreshTimestamp = towerLogic.getSearchRefreshTimestamp(this._tower);
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await towerLogic.doGetSearchInfo(this._tower)
    }
}
