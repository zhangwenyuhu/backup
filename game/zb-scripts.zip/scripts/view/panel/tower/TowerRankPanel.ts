import { PopupPanel } from "../BasePanel";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import towerLogic, { RaceType } from "../../../logics/TowerLogic";
import CommonLoader from "../../common/CommonLoader";
import PlayerHead from "../../component/Player/PlayerHead";
import playerLogic from "../../../logics/PlayerLogic";
import { stringConfigMap } from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/tower/TowerRankPanel")
export default class TowerRankPanel extends PopupPanel {

    @property(cc.Node)
    towerScrollView: cc.Node = null;

    @property(cc.Node)
    myTowerRank: cc.Node = null;

    @property(cc.Node)
    playerHead: cc.Node = null;

    @property(cc.Node)
    nickName: cc.Node = null;

    @property(cc.Node)
    currentTower: cc.Node = null;

    private type:RaceType=0;
    onInit(data: any) {
        this.type = data || 0;
    }

    async start() {
        super.start();

        await towerLogic.rankReq(this.type);
        this.initScollView();
    }

    initScollView() {
        let tmp = towerLogic.getTowerRanks(this.type);
        this.towerScrollView.getComponent(ScrollViewLoader).refresh(tmp);

        let num = towerLogic.getMyRank(this.type);
        let str: string = num > 0 ? `${num}` : stringConfigMap.key_common_tip3.Value;
        this.myTowerRank.getComponent(cc.Label).string = str;
        this.nickName.getComponent(cc.Label).string = playerLogic.getPlayer().getNickname();
        this.currentTower.getComponent(cc.Label).string = `${towerLogic.getCurrentTower(this.type) - 1}`;
        this.playerHead.getComponent(CommonLoader).loaderNode.getComponent(PlayerHead).refresh(playerLogic.getPlayer());
    }
}
