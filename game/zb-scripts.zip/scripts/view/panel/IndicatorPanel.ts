const { ccclass, property } = cc._decorator;

@ccclass
export default class IndicatorPanel extends cc.Component {
    protected _referenceCount: number = 0;
    protected _maxTime: number = 30;

    show(delay?: number) {
        this._referenceCount++;

        if (!this.node.active) {
            this.node.active = true;
            let content = this.node.getChildByName("node");
            content.active = false;
            if (typeof delay == "number") {
                this.scheduleOnce(() => { content.active = true; }, delay);
            }
            else {
                this.scheduleOnce(() => { content.active = true; }, 1.5);
            }
            //超过30秒取消显示
            // this.scheduleOnce(() => {
            //     if (this.node.active) {
            //         this.unscheduleAllCallbacks();
            //         this.node.active = false;
            //         this._referenceCount = 0;
            //     }
            // }, this._maxTime);
            console.log("show indicator");
        }
    }

    hide() {
        this._referenceCount--;
        // if (this._referenceCount > 0) {
        //     return;
        // }

        if (this.node.active) {
            console.log("hide indicator");
            this.unscheduleAllCallbacks();
            this.node.active = false;
        }
    }
}