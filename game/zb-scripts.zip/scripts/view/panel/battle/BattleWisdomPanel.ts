import BattleSharePanel from "./BattleSharePanel";
import wisdomTreeLogic from "../../../logics/WisdomTreeLogic";
import WisdomMonsterInfoPanel from "../wisdomtree/WisdomMonsterInfoPanel";
import activityLogic, {ActivityType} from "../../../logics/ActivityLogic";
import {TaskActivityType} from "../../../utils/DefineUtils";
import gm from "../../../manager/GameManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleWisdomPanel")
export default class BattleWisdomPanel extends BattleSharePanel {
    async startBattle() {
        super.startBattle();

        let heros = this._fightNode.manager.getHeroList();
        for (let hero of heros) {
            let wisdomHero = wisdomTreeLogic.wisdomHero.wisdomTreeHeroData.find(a => a.hero == hero.heroData.heroId || (a.heroVO && a.heroVO.heroId == hero.heroData.heroId));
            if (!wisdomHero) {
                wisdomHero = WisdomMonsterInfoPanel.guardWisdomTreeBase.wisdomTreeData.wisdomData.grardData.find(a => a.hero == hero.heroData.heroId || (a.heroVO && a.heroVO.heroId == hero.heroData.heroId));
            }
            if (wisdomHero && wisdomHero.hp > 0) {
                hero.heroData.hp = wisdomHero.hp;
                hero.heroData.hpMax = wisdomHero.hpMax;
                hero.heroData.power = wisdomHero.power;
            }
        }

        if (activityLogic.taskWisdomCloudData && activityLogic.taskWisdomCloudData.checkWisdomTreeTs(wisdomTreeLogic.wisdomTreeCurrent.wisdomEndTime)) {
            await activityLogic.doIncTaskActProgress(ActivityType.WisdomStorm, TaskActivityType.JoinWisdomTree, null, 1);
            let lastTime = wisdomTreeLogic.wisdomTreeCurrent.wisdomEndTime - gm.getCurrentTimestamp();
            activityLogic.taskWisdomCloudData.setWisdomTreeTs(wisdomTreeLogic.wisdomTreeCurrent.wisdomEndTime);
            activityLogic.taskWisdomCloudData.doPutCloudData(lastTime);
        }
    }

}