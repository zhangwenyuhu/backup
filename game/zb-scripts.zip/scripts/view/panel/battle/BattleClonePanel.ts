import { stringConfigMap } from './../../../configs/stringConfig';
import BattleSharePanel from "./BattleSharePanel";
import CloneBattleData from "../../../data/clone/CloneBattleData";
import clonebattleconfig from "../../../configs/clonebattleconfig";
import battleLogic from "../../../logics/BattleLogic";
import gm from "../../../manager/GameManager";
import BattleUIPanel from "./BattleUIPanel";
import CommonLoader from "../../common/CommonLoader";
import GoodCard from "../../component/Good/GoodCard";
import stringUtils from '../../../utils/StringUtils';
import FightSkill from '../../fight/FightSkill';
import cMissionLogic from "../../../logics/CMissionLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleClonePanel")
export default class BattleClonePanel extends BattleSharePanel {
    @property({
        override: true,
        type: cc.Label,
        visible: false
    })
    labelGold: cc.Label = null;

    @property({
        override: true,
        type: cc.Label,
        visible: false
    })
    labelChest: cc.Label = null;

    @property({
        override: true,
        type: cc.Node,
        visible: false
    })
    nodeGold: cc.Node = null;

    @property({
        override: true,
        type: cc.Node,
        visible: false
    })
    nodeChest: cc.Node = null;

    @property(cc.Animation)
    waveAnimation: cc.Animation = null;

    @property(cc.Label)
    labelTitleWave: cc.Label = null;

    @property(cc.Label)
    labelWave: cc.Label = null;

    @property(CommonLoader)
    goodLoader: CommonLoader = null;

    @property(cc.Label)
    labelTip: cc.Label = null;

    onLoad() {
        super.onLoad();

        this.waveAnimation.node.active = false;
        this.labelTitleWave.node.active = false;

        let comp = this.ui.loaderNode.getComponent(BattleUIPanel);
        let widget = comp.btnSkip.getComponent(cc.Widget);
        widget.right += 82;
    }

    startBattle() {
        let heroes: rpgfight.Hero[] = [];
        let aliveHeroes: { [key: string]: { hp: number, power: number } } = {}
        if (this._fightNode) {
            heroes = this._fightNode.manager.getHeroList();
            for (let hero of heroes) {
                if (hero.battleTeam == rpgfight.BattleTeam.our
                    && hero.heroData.heroType == rpgfight.HeroType.Hero
                    && hero.isAtAliveState
                    && hero.heroData.hp > 0) {
                    aliveHeroes[hero.heroData.config.heroId] = { hp: hero.heroData.hpRealtime, power: hero.heroData.powerRealtime };
                }
            }

            let selfHeroes = battleLogic.getTroop(true);
            for (let i = 0; i < selfHeroes.length; i++) {
                if (selfHeroes[i] && !aliveHeroes[selfHeroes[i].getId()]) {
                    selfHeroes[i] = null;
                }
            }
            let enemyHeroes = this._battleData.getMonsters();
            battleLogic.init({ selfTroop: selfHeroes, enemyTroop: enemyHeroes }, gm);

            this._fightNode.node.destroy();
            this._fightNode = null;

            let comp = this.ui.loaderNode.getComponent(BattleUIPanel);
            comp.clearMask();
        }

        super.startBattle();

        let comp = this.ui.loaderNode.getComponent(BattleUIPanel);
        heroes = this._fightNode.manager.getHeroList();
        for (let hero of heroes) {
            let id = hero.heroData.config.heroId;
            if (aliveHeroes[id]) {
                hero.heroData.hp = aliveHeroes[id].hp;
                hero.heroData.power = aliveHeroes[id].power;
            }

            if (hero.battleTeam == rpgfight.BattleTeam.our) {
                let item = comp.skillCardList.children[hero.heroData.config.battleStation - 1];
                if (item) {
                    let skillNode = item.getChildByName(hero.name);
                    if (skillNode) {
                        let skill = skillNode.getComponent(FightSkill);
                        skill.hpBar.setFightHero(hero);
                    }
                }
            }
        }

        this.waveAnimation.node.active = true;
        this.waveAnimation.play("fight_start");
        this.waveAnimation.off("finished");
        this.waveAnimation.on("finished", () => {
            if (this.waveAnimation.currentClip.name == "fight_start") {
                this.waveAnimation.play("fight_start2");
            }
            else {
                this.waveAnimation.node.active = false;
            }
        }, this);

        let battleData = this._battleData as CloneBattleData;
        if (battleData.waveIndex == 0) {
            cMissionLogic.battleStartTs = gm.getCurrentTimestamp();
        }
        this.labelTitleWave.node.active = true;
        this.labelTitleWave.string = stringUtils.getString(stringConfigMap.key_wave.Value, { wave: battleData.waveIndex + 1 });
        this.labelWave.string = (battleData.waveIndex + 1).toString();

        comp.btnSkip.active = battleData.canSkip();
        if (comp.btnSkip.active) {
            let button = comp.btnSkip.getComponent(cc.Button);
            comp.btnSkip.off(cc.Node.EventType.TOUCH_END, button["_onTouchEnded"], button);
            button["_onTouchEnded"] = cc.Button.prototype["_onTouchEnded"];
            comp.btnSkip.on(cc.Node.EventType.TOUCH_END, button["_onTouchEnded"], button);
        }

        let reward = battleData.getNextReward();
        if (reward) {
            this.goodLoader.node.active = true;
            this.labelTip.node.active = true;

            let comp = this.goodLoader.loaderNode.getComponent(GoodCard);
            comp.refresh(reward.good);
            comp.registerOnGoodInfo();

            this.labelTip.string = stringUtils.getString(stringConfigMap.key_wave.Value, { wave: reward.waveIndex + 1 }) + stringConfigMap.key_claim.Value.replace(" ", '');
        }
        else {
            this.goodLoader.node.active = false;
            this.labelTip.node.active = false;
        }
    }

    protected _showBattleResult(isWin: boolean) {
        let battleData = this._battleData as CloneBattleData;
        if (isWin) {
            battleData.waveIndex++;
            if (battleData.waveIndex < clonebattleconfig.length) {
                this._isGameover = false;
                this.startBattle();
                return;
            }
        }

        this.scheduleOnce(() => {
            gcc.core.showLayer("prefabs/panel/clone/CloneResultPanel", {
                data: {
                    wave: battleData.waveIndex,
                    statistics: this.getContributionResult()
                }
            });
        }, 0.5);
    }
}
