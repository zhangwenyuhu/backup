import BasePanel, { PopupPanel } from './../BasePanel'
import EManager, { EName } from '../../../manager/EventManager';
import { BattleReportBO, RoleVO } from "../../../proxy/GameProxy";
import arenaLogic, { RankType } from "../../../logics/ArenaLogic";
import CommonLoader from "../../common/CommonLoader";
import Player from "../../../data/user/Player";
import PlayerHead from "../../component/Player/PlayerHead";
import gm from "../../../manager/GameManager";
import assignmentLogic from "../../../logics/AssignmentLogic";
import {BattleType, TaskActivityType} from "../../../utils/DefineUtils";
import am from '../../../manager/AudioManager';
import heroLogic from "../../../logics/HeroLogic";
import commitLogic, { ArenaPvpType } from '../../../logics/CommitLogic';
import activityLogic, {ActivityType} from "../../../logics/ActivityLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattlePVPWinPanel")
export default class BattlePVPWinPanel extends PopupPanel {

    @property(cc.Label)
    newRank: cc.Label = null;

    @property(cc.Label)
    rankChange: cc.Label = null;

    @property(CommonLoader)
    myPlayer: CommonLoader = null;

    @property(cc.Label)
    myName: cc.Label = null;

    @property(cc.Label)
    myScore: cc.Label = null;

    @property(cc.Label)
    myScoreChange: cc.Label = null;

    @property(CommonLoader)
    otherPlayer: CommonLoader = null;

    @property(cc.Label)
    otherName: cc.Label = null;

    @property(cc.Label)
    otherScore: cc.Label = null;

    @property(cc.Label)
    otherScoreChange: cc.Label = null;

    @property(cc.Node)
    task1: cc.Node = null;

    @property(cc.Label)
    taskLabel1: cc.Label = null;

    @property(cc.Node)
    task2: cc.Node = null;

    @property(cc.Label)
    taskLabel2: cc.Label = null;

    onLoad() {
        super.onLoad();
        this.registerEvents();

        let animation = this.getComponent(cc.Animation);
        animation.once("finished", () => { animation.play("battle_win_loop") });

        BasePanel.closePanel("BattlePausePanel");
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType }) => {
            if (data.type == BattleType.PVP) {
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);

        cc.director.setTimeScale(1);
    }

    async start() {
        super.start();

        am.playEffect("BGM_win");

        let rank = arenaLogic.getMyArenaByRankType(RankType.ArenaNormal);
        if (rank) {
            let _player = new Player(rank.role);
            this.myPlayer.loaderNode.getComponent(PlayerHead).refresh(_player);
            this.myPlayer.loaderNode.getComponent(PlayerHead).hideLevel();
            this.myName.string = rank.role.nick;
            this.newRank.string = this.data.rank.toString();
            let diffRank = rank.no - this.data.rank;
            this.rankChange.string = "+" + diffRank;
            rank.no = this.data.rank;

            this.myScore.string = (this.data.score + rank.score).toString();
            this.myScoreChange.string = "+" + this.data.score;
            rank.score = this.data.score + rank.score;
            if (arenaLogic.getRivalData()) {
                let _player = new Player(arenaLogic.getRivalData().role);
                this.otherPlayer.loaderNode.getComponent(PlayerHead).refresh(_player);
                this.otherPlayer.loaderNode.getComponent(PlayerHead).hideLevel();
                this.otherName.string = arenaLogic.getRivalData().role.nick;
                this.otherScore.string = arenaLogic.getRivalData().score + this.data.rivalScore;
                this.otherScoreChange.string = "-" + Math.abs(this.data.rivalScore);
            } else if (arenaLogic.getRivalRecordData()) {
                let role = new RoleVO();
                let rivalRecordData = arenaLogic.getRivalRecordData();
                role.avatarFrame = rivalRecordData.avatarFrame;
                role.avatar = rivalRecordData.avatar;
                role.nick = rivalRecordData.nick;
                role.roleId = rivalRecordData.rivalRoleId;
                role.lv = rivalRecordData.lv;
                role.mainForce = [];
                let _player = new Player(role);
                this.otherPlayer.loaderNode.getComponent(PlayerHead).refresh(_player);
                this.otherPlayer.loaderNode.getComponent(PlayerHead).hideLevel();
                this.otherName.string = rivalRecordData.nick;
                this.otherScore.string = this.data.rivalRawScore + this.data.rivalScore;
                this.otherScoreChange.string = "-" + Math.abs(this.data.rivalScore);
            }
        }
        arenaLogic.showReward();
        let bg = this.node.getChildByName("modalBg");
        bg.once(cc.Node.EventType.TOUCH_END, this.onExit, this);

        let task = assignmentLogic.getMainTaskInfo(7);
        if (!task) {
            await assignmentLogic.mainTaskReq(0);
            await assignmentLogic.tasksReq(0);
        }
        //每日竞技场任务
        this.task1.active = false;
        /*
        let task_daily = assignmentLogic.getDailyTasks().find(a => a.taskId == 1010);
        if (task_daily.complete_task && assignmentLogic.arenaTaskFinished) {
            this.task1.active = true;
            this.taskLabel1.string = `(${task_daily.completeValue}/${task_daily.cfg.value}) ${task_daily.desc}`;
            this.taskLabel1.node.color = cc.Color.GREEN;
            assignmentLogic.arenaTaskFinished = false;
        } else {
            this.task1.active = false;
        }*/

        heroLogic.artifactUnlockInfo && heroLogic.artifactUnlockInfo.addTaskProgress(3007);

        commitLogic.arenaBattle(ArenaPvpType.normal, true);
        activityLogic.doIncTaskActProgress(ActivityType.CrazyArena, TaskActivityType.ArenaWin, null, 1);
    }

    onDestroy() {
        EManager.emit(EName.onUpdateRank);
        arenaLogic.resetRivalData();
        super.onDestroy();
    }

    onExit() {
        EManager.emit(EName.onGameExit, { type: BattleType.PVP });
    }

    async onHistory() {
        try {
            await arenaLogic.doArenaPlayBack(parseInt(arenaLogic.getBattleData().battleNo));
            gcc.core.showLayer("prefabs/panel/arena/ArenaBattleReportPanel", {
                data: {
                    battleNo: parseInt(arenaLogic.getBattleData().battleNo),
                    user: this._getPlayer(),
                    battleType: BattleType.PVP,
                    isWin: 0
                }
            });
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    protected _getPlayer() {
        let rivalData = arenaLogic.getRivalData();
        let player = new Player(rivalData.role);
        return player;
    }
}
