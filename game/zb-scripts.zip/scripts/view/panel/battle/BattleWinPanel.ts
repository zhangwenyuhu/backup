import { unlockConfigMap, unlockConfigRow } from './../../../configs/unlockConfig';
import { stringConfigMap } from './../../../configs/stringConfig';
import BasePanel, { PopupPanel } from './../BasePanel'
import Mission from '../../../data/mission/Mission';
import EManager, { EName } from '../../../manager/EventManager';
import { BattleType, Goto, WeekType } from '../../../utils/DefineUtils';
import gm from '../../../manager/GameManager';
import missionLogic from '../../../logics/MissionLogic';
import IBattleData from '../../../data/IBattleData';
import towerLogic from '../../../logics/TowerLogic';
import Tower from '../../../data/tower/Tower';
import Card from '../../../data/card/Card';
import assignmentLogic from '../../../logics/AssignmentLogic';
import playerLogic from '../../../logics/PlayerLogic';
import Hero from '../../../data/card/Hero';
import benefitLogic from '../../../logics/BenefitLogic';
import wisdomTreeLogic from "../../../logics/WisdomTreeLogic";
import WisdomMonsterInfoPanel from "../wisdomtree/WisdomMonsterInfoPanel";
import am from '../../../manager/AudioManager';
import dungeonLogic, { DungeonBattleData } from '../../../logics/DungeonLogic';
import battleLogic from '../../../logics/BattleLogic';
import commonUtils from '../../../utils/CommonUtils';
import { GoodId } from '../../../data/card/Good';
import CommonLoader from '../../common/CommonLoader';
import VipBuff from '../../component/VipBuff';
import { RightType } from '../../../logics/RechargeLogic';
import unlockConfig from '../../../configs/unlockConfig';
import cm from '../../../manager/ConfigManager';
import stringUtils from '../../../utils/StringUtils';
import StoryComponent, { StoryWhere } from '../../widget/story/StoryComponent';
import UnlockWrapper from '../../widget/unlock/UnlockWrapper';
import commitLogic from '../../../logics/CommitLogic';
import RMission from "../../../data/mission/RMission";
import rMissionLogic from "../../../logics/RMissionLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleWinPanel")
export default class BattleWinPanel extends PopupPanel {
    @property(cc.Node)
    rewardList: cc.Node = null;

    @property(cc.Node)
    rewardItem: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    btnNext: cc.Node = null;

    @property(cc.Node)
    btnClaim: cc.Node = null;

    @property(cc.Node)
    labelExit: cc.Node = null;

    @property(cc.Node)
    targetList: cc.Node = null;

    @property(cc.Node)
    targetTemplate: cc.Node = null;

    @property(cc.Node)
    fightHistory: cc.Node = null;

    @property(cc.Sprite)
    spriteHero: cc.Sprite = null;

    @property(cc.Label)
    hurtPercentage: cc.Label = null;

    @property(cc.Sprite)
    killSprite: cc.Sprite = null;

    @property(cc.SpriteFrame)
    killFrames: cc.SpriteFrame[] = [];

    protected _battleData: IBattleData = null;
    protected _selectHero: Hero = null;
    protected _canExit: boolean = false;

    public passedStageId: number = 0;

    onInit(data: {
        battleData: IBattleData,
        skills: any,
        contribution?: rpgfight.HeroContributionStatistic[]
    }) {
        super.onInit(data.battleData);
        this._battleData = data.battleData;
        if (this._battleData == undefined) {
            console.error("this._battleData = undefined");
        }
        if (this._battleData.getBattleType() != BattleType.PVE) {
            this.btnNext.active = false;
        }
    }

    onLoad() {
        super.onLoad();

        if (this.targetTemplate) {
            this.targetTemplate.parent = null;
        }
        this.goodItem.position = cc.v2();
        this.heroItem.position = cc.v2();
        this.equipItem.position = cc.v2();
        this.goodItem.parent = null;
        this.heroItem.parent = null;
        this.equipItem.parent = null;
        this.rewardItem.parent = null;
        this.registerEvents();

        let animation = this.getComponent(cc.Animation);
        animation.once("finished", () => { animation.play("battle_win_loop"); });

        this.scheduleOnce(() => { this._canExit = true; }, 1.0);

        if (this._battleData.getBattleType() == BattleType.PVE) {
            let mission = this._battleData as Mission;
            this.passedStageId = mission.getStageId();
        }

        BasePanel.closePanel("BattlePausePanel");
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.heroItem.destroy();
        this.equipItem.destroy();
        this.rewardItem.destroy();
    }

    hideFightHistory() {
        this.fightHistory.active = false;
    }

    hideBtnNext() {
        this.btnNext.active = false;
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType }) => {
            if (data.type == this._battleData.getBattleType()) {
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);

        cc.director.setTimeScale(1);
    }

    async start() {
        super.start();

        am.playEffect("BGM_win");

        let contributions = this._data.contribution as rpgfight.HeroContributionStatistic[];
        contributions = contributions.filter((a: rpgfight.HeroContributionStatistic) => { return a.battleTeam == rpgfight.BattleTeam.our; });
        contributions.sort((a: rpgfight.HeroContributionStatistic, b: rpgfight.HeroContributionStatistic) => {
            return b.hpHurt - a.hpHurt;
        });
        let contribution = contributions[0];
        let heroes = battleLogic.getTroop(true);
        let hero = heroes.filter((a: Hero) => { return a && a.getId() == contribution.heroId })[0];

        let spriteFrame = cc.loader.getRes(commonUtils.getHeroBigUrl(hero.getIndex()), cc.SpriteFrame);
        this.spriteHero.spriteFrame = spriteFrame;

        let totalHurt = 0;
        for (let contribute of contributions) {
            totalHurt += contribute.hpHurt;
        }
        this.hurtPercentage.string = `${Math.round((contribution.hpHurt / totalHurt) * 100)}%`;

        if (contribution.killCount > 1) {
            this.killSprite.node.active = true;
            this.killSprite.spriteFrame = this.killFrames[Math.min(contribution.killCount - 2, 3)];
        }
        else {
            this.killSprite.node.active = false;
        }

        try {
            let cards: Card[] = [];
            if (this._battleData.getBattleType() == BattleType.PVE) {
                this.fightHistory.active = UnlockWrapper.isUnlock(unlockConfigMap.战斗回放与任务目标);
                this.targetList.active = false;
                if (!this.targetList.active) {
                    this.btnNext.y += 90;
                    this.btnClaim.y += 90;
                    this.labelExit.y += 90;
                }

                let mission = this._battleData as Mission;
                cards = await missionLogic.doPassMission(mission);

                let comp = this.addComponent(StoryComponent);
                comp.init(mission.getStageId(), StoryWhere.BattleWin);

                // if (mission.getStageId() == 14) { // 通关5-2触发任务引导
                //     guideLogic.guideId = 150001;
                // }
            }
            else if (this._battleData.getBattleType() == BattleType.Tower) {
                this.fightHistory.active = true;

                let type: number = 0;
                if (this._battleData instanceof Tower) { type = this._battleData.getRaceType(); }
                if (type > 0) {
                    cards = await towerLogic.raceTowerPassCommit(this._battleData as Tower);
                } else {
                    cards = await towerLogic.towerPassCommit(this._battleData as Tower);
                    commitLogic.towerPass((this._battleData as Tower).id);
                }
            } else if (this._battleData.getBattleType() == BattleType.Maze) {
                for (let vo of this._battleData.getRewards()) {
                    cards.push(vo);
                }
                await wisdomTreeLogic.doGetGuardReward(WisdomMonsterInfoPanel.guardWisdomTreeBase);
            } else if (this._battleData.getBattleType() == BattleType.Dungeon) {
                cards = await dungeonLogic.doClaimMissionRewards();
            } else if (this._battleData.getBattleType() == BattleType.Material) {
                this.fightHistory.active = false;
                this.targetList.active = false;

                let rMission = this._battleData as RMission;
                cards = await rMissionLogic.doPassMission(rMission);
            } else if (this._battleData.getBattleType() == BattleType.WonderSpace) {
                this.fightHistory.active = false;
            }

            let layout = this.rewardList.getComponent(cc.Layout);
            if (cards.length <= 4) { layout.type = cc.Layout.Type.HORIZONTAL; }

            let items = commonUtils.card2Item(cards);
            this.rewardList.destroyAllChildren();
            for (let item of items) {
                let listItem = cc.instantiate(this.rewardItem);
                listItem.parent = this.rewardList;
                listItem.getChildByName("good").destroyAllChildren();
                gm.showGoodItem(item, {
                    goodItem: this.goodItem,
                    equipItem: this.equipItem,
                    heroItem: this.heroItem
                }, listItem.getChildByName("good"));

                let buff = listItem.getChildByName("vipBuff");
                if (buff) {
                    buff.active = item[0] == GoodId.WisdomCoin && this._battleData.getBattleType() == BattleType.Maze;
                    if (buff.active) {
                        let loader = buff.getComponent(CommonLoader).loaderNode;
                        loader.getComponent(VipBuff).buffType = RightType.MazeGold;
                    }
                }
            }
            layout.updateLayout();
            if (layout.node.childrenCount > 4) {
                layout.enabled = false;
                let newWidth = 0;
                let count = 0;
                for (let i = 4; i < layout.node.childrenCount; i++) {
                    let child = layout.node.children[i];
                    newWidth += child.width;
                    count++;
                }
                newWidth += (count - 1) * layout.spacingX;
                let startX = -newWidth / 2;
                for (let i = 4; i < layout.node.childrenCount; i++) {
                    let child = layout.node.children[i];
                    child.x = startX + child.width / 2;
                    startX += child.width + layout.spacingX;
                }
            }

            if (this.targetList) {
                this.targetList.active = false;
                /*this.targetList.y = ((this.rewardList.y - this.rewardList.height)
                    + (this.btnNext.y + this.btnNext.height / 2)) / 2;*/
            }

            this.fightTipsDesc();
            for (let card of cards) {
                if (card.getType() == Card.Type.Hero) {
                    this._selectHero = card as Hero;
                    break;
                }
            }

            if (this._battleData.getBattleType() == BattleType.PVE) {
                let mission = this._battleData as Mission;
                EManager.emit(EName.onMissionPass, mission);
                await this.checkGift(mission.getStageId());
            }

        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }

        this.commitBattleWinEvent();
    }

    fightTipsDesc() {
        let type = this._battleData.getBattleType();
        if (type == BattleType.PVE) {
            this.pveAssignDesc();
        } else if (type == BattleType.Tower) {
            this.towerAssignDesc();
        }
    }

    protected towerAssignDesc() {
        return;
        // 每日摩天楼挑战任务完成显示        
        let task = assignmentLogic.getDailyTasks().find(a => a.taskId == 1004);
        if (task && task.complete_task && !assignmentLogic.completeTowerDailyTask) {
            let tmp = cc.instantiate(this.targetTemplate);
            tmp.parent = this.targetList;

            let tip = `(${task.completeValue}/${task.cfg.value}) ${task.desc}`;
            this.freshTipNode(tmp, tip, task.complete_task);
        }
    }

    protected async pveAssignDesc() {
        return;
        // 日常
        /*
        let task = assignmentLogic.getDailyTasks().find(a => a.taskId == 1001);
        if (task && task.complete_task && !assignmentLogic.completePveDailyTask) {
            let tmp = cc.instantiate(this.targetTemplate);
            tmp.parent = this.targetList;

            let tip: string = `(${task.completeValue}/${task.cfg.value}) ${task.desc}`;
            this.freshTipNode(tmp, tip, task.complete_task);
        }*/

        // 主线关卡
        let stageId = assignmentLogic.getPassMissionStageId(this.passedStageId);
        let tmp = cc.instantiate(this.targetTemplate);
        tmp.parent = this.targetList;

        let stageCfg = cm.getStageConfig(stageId);
        let tip = `(${this.passedStageId}/${stageId}) 通关主线 ${stageCfg.HouseID}-${stageCfg.level}`;
        this.freshTipNode(tmp, tip, stageId == this.passedStageId);

        let mission = this._battleData as Mission;
        let currentUnlockConfigs: unlockConfigRow[] = [];
        let nextUnlockConfigs: unlockConfigRow[] = [];
        let configs = unlockConfig.slice(0);
        configs.sort((a: unlockConfigRow, b: unlockConfigRow) => { return a.battleId - b.battleId });
        for (let config of configs) {
            if (config.battleId == mission.getStageId() && config.priority > 0) {
                currentUnlockConfigs.push(config);
            }
            else if (config.battleId > mission.getStageId()) {
                if (nextUnlockConfigs.length == 0 || config.battleId == nextUnlockConfigs[0].battleId) {
                    if (config.priority > 0) {
                        nextUnlockConfigs.push(config);
                    }
                }
                else {
                    break;
                }
            }
        }
        currentUnlockConfigs.sort((a: unlockConfigRow, b: unlockConfigRow) => { return a.priority - b.priority });
        nextUnlockConfigs.sort((a: unlockConfigRow, b: unlockConfigRow) => { return a.priority - b.priority });

        let hasUnlock: boolean = currentUnlockConfigs.length > 0;
        let unlockConfigs = hasUnlock ? [currentUnlockConfigs] : [nextUnlockConfigs];
        for (let i = 0; i < unlockConfigs.length; i++) {
            if (unlockConfigs[i].length > 0) {
                let item = cc.instantiate(this.targetTemplate);
                item.parent = this.targetList;

                let names = [];
                for (let j = 0; j < unlockConfigs[i].length; j++) {
                    names.push(unlockConfigs[i][j].Key);
                }

                let config = unlockConfigs[i][0];
                let stage = cm.getStageConfig(config.battleId);
                let tip = stringUtils.getString(stringConfigMap.key_pass_mission_to_unlock.Value,
                    {
                        cur: mission.getStageId(),
                        total: config.battleId,
                        houseId: stage.HouseID,
                        level: stage.level,
                        name: names.join(',')
                    });
                this.freshTipNode(item, tip, hasUnlock, true);
            }
        }
    }


    protected freshTipNode(node: cc.Node, desc: string, complete: boolean, unlock?: boolean) {
        // 
        node.getChildByName("complete").active = complete;
        let labelColor = complete ? cc.Color.GREEN.fromHEX("#65c46e") : cc.Color.YELLOW.fromHEX("#efa63e");

        let tip = node.getChildByName("text").getComponent(cc.Label);
        tip.node.color = labelColor;
        if (!complete) { tip.node.x -= 30; }
        if (unlock) { tip.node.color = complete ? cc.Color.GREEN.fromHEX("#65c46e") : cc.Color.WHITE.fromHEX("#acb0c4"); }
        tip.string = desc;
    }

    onExit() {
        if (!this._canExit) return;

        EManager.emit(EName.onGameExit, { type: this._battleData.getBattleType() });
        if (this._battleData.getBattleType() == BattleType.PVE) {
            let mission = this._battleData as Mission;
            let country = missionLogic.getCountry(mission.getCountryId());
            let chapter = missionLogic.getChapter(mission.getChapterId());
            if (country.isPassed()) {
                EManager.emit(EName.onGotoView, { goto: Goto.CountryPassed, mission: mission });
            }
            else if (chapter.isPassed()) {
                EManager.emit(EName.onGotoView, { goto: Goto.ChapterPassed, mission: mission });
            }
            else {
                EManager.emit(EName.onGotoView, { goto: Goto.MainScene, mission: mission });
            }
        } else if (this._battleData.getBattleType() == BattleType.Maze ||
            this._battleData.getBattleType() == BattleType.WonderSpace ||
            this._battleData.getBattleType() == BattleType.Material) {
            EManager.emit(EName.onGameResult, true);
        }
        if (this._battleData.getBattleType() == BattleType.Material) {
            assignmentLogic.weekTaskProCommit(WeekType.fight_mat);
            commitLogic.matFight((this._battleData as RMission).getType(), true, false);
        }
    }

    onNext() {
        EManager.emit(EName.onGameExit, { type: this._battleData.getBattleType() });

        if (this._battleData.getBattleType() == BattleType.PVE) {
            let mission = this._battleData as Mission;
            let country = missionLogic.getCountry(mission.getCountryId());
            let chapter = missionLogic.getChapter(mission.getChapterId());
            if (country.isPassed()) {
                EManager.emit(EName.onGotoView, { goto: Goto.CountryPassed, mission: mission });
            }
            else if (chapter.isPassed()) {
                EManager.emit(EName.onGotoView, { goto: Goto.ChapterPassed, mission: mission });
            }
            else {
                EManager.emit(EName.onGotoView, { goto: Goto.BuildingInfo, mission: mission });
            }
        }
    }

    onClaim() {
        if (this._selectHero) {
            gcc.core.showLayer("prefabs/panel/hero/HeroGetPanel", {
                data: {
                    hero: this._selectHero,
                    new: true,
                    finishCall: () => { this.onExit(); }
                }
            });
        }
    }

    async onFightHistory() {
        if (this._battleData.getBattleType() == BattleType.Tower) {
            let type: number = 0;
            if (this._battleData instanceof Tower) { type = this._battleData.getRaceType(); }
            let level = towerLogic.getCurrentTower(type);
            let roleId = playerLogic.getPlayer().getRoleId();
            await towerLogic.towerFightRecordReq(roleId, level - 1, type);
            let reportData = towerLogic.getTowerRecord(roleId, level - 1, type);
            reportData.type = type;
            gcc.core.showLayer("prefabs/panel/tower/TowerReportPanel", { data: reportData });
        } else {
            gcc.core.showLayer("prefabs/panel/arena/ArenaBattleReportPanel", {
                data: {
                    battleType: this._battleData.getBattleType(),
                    skills: this.data.skills,
                    contribution: this.data.contribution,
                    isWin: true
                }
            });
        }
    }

    async checkGift(mission: number) {
        await benefitLogic.checkSurpriseGift(2, mission);
    }

    protected commitBattleWinEvent() {
        if (this._battleData.getBattleType() == BattleType.PVE) {
            commitLogic.missionBattle(missionLogic.getCurrentMission().getStageId() - 1, true);
        } else if (this._battleData.getBattleType() == BattleType.Maze) {
            // 不在此处统计
        } else if (this._battleData.getBattleType() == BattleType.Tower) {
            if (this._battleData instanceof Tower) {
                commitLogic.raceTowerBattle(this._battleData.getRaceType(), this._battleData.id, true);
            }
        } else if (this._battleData.getBattleType() == BattleType.Dungeon) {
            let data = this._battleData as DungeonBattleData;
            if (data) {
                commitLogic.dungeonBattle(data.id, true);
            }
        }
    }
}
