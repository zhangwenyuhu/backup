import { EName } from './../../../manager/EventManager';
import BattlePanel from "./BattlePanel";
import battleLogic from "../../../logics/BattleLogic";
import EManager from "../../../manager/EventManager";
import { BattleType } from '../../../utils/DefineUtils';
import commonUtils from '../../../utils/CommonUtils';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleTrialPanel")
export default class BattleTrialPanel extends BattlePanel {
    getBattleType(): BattleType {
        return BattleType.Trail;
    }

    getBgUrl(): string {
        return commonUtils.getBgUrl("battle_bg");
    }

    protected _onHeroDead(fightHero: rpgfight.Hero) {
        super._onHeroDead(fightHero);

        if (fightHero.heroData.isShock) return;
        if (fightHero.heroData.heroType == rpgfight.HeroType.Summoned) return;

        let selectConfig: rpgfight.HeroConfig = null;
        let configs = battleLogic.getHeroList();
        for (let config of configs) {
            if (config.heroId == fightHero.heroData.heroId) {
                selectConfig = config;
                break;
            }
        }

        this.scheduleOnce(() => {
            if (this._fightNode.manager && this._fightNode.manager.gameState != rpgfight.GameState.running) {
                this._fightNode.manager.gameState = rpgfight.GameState.running;
            }
            this._fightNode.addHeroWithHeroConfig(selectConfig);
            EManager.emit(EName.onHeroReset, selectConfig);
        }, 0.5);
    }
}
