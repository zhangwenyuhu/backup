import { ActivityWorldBossModal } from './../../../logics/ActivityLogic';
import BattleSharePanel from "./BattleSharePanel";
import WorldBossActConfig from '../../../data/activity/actconfig/WorldBossActConfig';
import WorldBossActivityDatas from '../../../data/activity/roleactivitydatas/WorldBossActivityDatas';
import Monster from '../../../data/card/Monster';
import stringUtils from '../../../utils/StringUtils';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleWorldBossPanel")
export default class BattleWorldBossPanel extends BattleSharePanel {
    @property({
        override: true,
        type: cc.Label,
        visible: false
    })
    labelGold: cc.Label = null;

    @property({
        override: true,
        type: cc.Label,
        visible: false
    })
    labelChest: cc.Label = null;

    @property({
        override: true,
        type: cc.Node,
        visible: false
    })
    nodeGold: cc.Node = null;

    @property({
        override: true,
        type: cc.Node,
        visible: false
    })
    nodeChest: cc.Node = null;

    @property(cc.ProgressBar)
    hpProgress: cc.ProgressBar = null;

    @property(cc.ProgressBar)
    hpProgressEx: cc.ProgressBar = null;

    @property(cc.Label)
    labelProgress: cc.Label = null;

    protected _nowHp: number = 0;
    protected _boss: Monster = null;
    protected _battleBoss: rpgfight.Hero = null;

    update(dt: number) {
        super.update(dt);

        if (this._battleBoss) {
            if (!this._isGameover) {
                let hp = Math.max(this._battleBoss.heroData.hpRealtime, 0);
                let hpMax = this._battleBoss.heroData.hpMaxRealtime;
                this.hpProgress.progress = hp / hpMax;
                this.labelProgress.string = `${stringUtils.formatValueByWan(hp)}/${stringUtils.formatValueByWan(hpMax)}`;
            }
        }

        if (this.hpProgressEx.progress > this.hpProgress.progress) {
            let progress = this.hpProgressEx.progress - 0.5 * dt;
            this.hpProgressEx.progress = Math.max(progress, this.hpProgress.progress);
        }
    }

    startBattle() {
        super.startBattle();

        let modal = this._battleData as ActivityWorldBossModal;
        let config = modal.actConfig as WorldBossActConfig;
        let data = modal.roleActivityDatas as WorldBossActivityDatas;
        this.labelProgress.string = `${data.hpNow}/${config.hp}`;
        this.hpProgress.progress = data.hpNow / config.hp;
        this.hpProgressEx.progress = 1;

        this._nowHp = data.hpNow;
        this._boss = config.boss;

        let heros = this._fightNode.manager.getHeroList();
        for (let hero of heros) {
            if (hero.heroData.heroId == this._boss.getId()) {
                hero.heroData.hpMax = config.hp;
                hero.heroData.hp = data.hpNow;
                this._battleBoss = hero;
                return;
            }
        }
    }

    protected _showBattleResult(isWin: boolean) {
        let hp = Math.max(this._battleBoss.heroData.hp, 0);
        let hpMax = this._battleBoss.heroData.hpMaxRealtime;
        this.hpProgress.progress = hp / hpMax;
        this.labelProgress.string = `${stringUtils.formatValueByWan(hp)}/${stringUtils.formatValueByWan(hpMax)}`;

        this.scheduleOnce(() => {
            gcc.core.showLayer("prefabs/panel/activity/worldboss/WorldBossResultPanel", {
                data: {
                    totalHurt: Math.floor(this._nowHp - hp),
                    statistics: this.getContributionResult()
                }
            });
        }, 0.5);
    }
}
