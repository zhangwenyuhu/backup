import BasePanel, {PopupPanel} from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import ArenaSeniorHistory from "../../component/Arena/ArenaSeniorHistory";
import arenaSeniorLogic from "../../../logics/ArenaSeniorLogic";
import EManager, {EName} from "../../../manager/EventManager";
import {BattleType, TaskActivityType} from "../../../utils/DefineUtils";
import ArenaSeniorRankBig from "../../component/Arena/ArenaSeniorRankBig";
import ArenaRankconfig from "../../../configs/ArenaRankconfig";
import Player from "../../../data/user/Player";
import commitLogic, {ArenaPvpType} from "../../../logics/CommitLogic";
import activityLogic, {ActivityType} from "../../../logics/ActivityLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleSeniorPVPResultPanel")
export default class BattleSeniorPVPResultPanel extends PopupPanel {

    @property(cc.Node)
    failNode: cc.Node = null;

    @property(cc.Node)
    successNode: cc.Node = null;

    @property(cc.Node)
    arenaRank1: cc.Node = null;

    @property(cc.Node)
    arenaRank2: cc.Node = null;

    @property(cc.Label)
    score: cc.Label = null;

    @property(cc.Node)
    goldNode: cc.Node = null;

    @property(cc.Label)
    gold: cc.Label = null;

    @property(cc.Node)
    scoreNode: cc.Node = null;

    @property(cc.Label)
    scoreLabel: cc.Label = null;

    @property(cc.Label)
    scoreAddLabel: cc.Label = null;

    @property(cc.Node)
    redArrow: cc.Node = null;

    @property(cc.Node)
    greenArrow: cc.Node = null;

    @property(cc.Node)
    record1: cc.Node = null;

    @property(cc.Node)
    record2: cc.Node = null;

    @property(cc.Node)
    record3: cc.Node = null;

    onLoad() {
        super.onLoad();
        this.registerEvents();

        if (arenaSeniorLogic.getBattleReport().isWin) {
            let animation = this.getComponent(cc.Animation);
            animation.once("finished", () => {
                animation.play("battle_win_loop")
            });
        }

        BasePanel.closePanel("BattlePausePanel");
    }

    start() {
        super.start();

        let bg = this.node.getChildByName("modalBg");
        bg.once(cc.Node.EventType.TOUCH_END, this.onExit, this);

        let win = arenaSeniorLogic.getBattleReport().isWin;
        this.failNode.active = !win;
        this.successNode.active = win;
        this.goldNode.active = win;
        this.scoreNode.active = false;
        let goldIncrease = this._getGoldIncreaseStr();
        if (goldIncrease) {
            this.gold.string = goldIncrease;
        }
        if (Number(arenaSeniorLogic.getBattleReport().newRank) == Number(arenaSeniorLogic.getBattleReport().rawRank)) {
            this.goldNode.active = false;
        }
        this.score.string = arenaSeniorLogic.getScore();
        this._showScore();

        let player = new Player(arenaSeniorLogic.getRivalData().role);
        this.record1.getComponent(CommonLoader).loaderNode.getComponent(ArenaSeniorHistory).refresh({ groupId: 1, player: player });
        this.record2.getComponent(CommonLoader).loaderNode.getComponent(ArenaSeniorHistory).refresh({ groupId: 2, player: player });
        this.record3.getComponent(CommonLoader).loaderNode.getComponent(ArenaSeniorHistory).refresh({ groupId: 3, player: player });

        this.arenaRank1.getComponent(CommonLoader).loaderNode.getComponent(ArenaSeniorRankBig).refresh(Number(arenaSeniorLogic.getBattleReport().newRankId));
        this.arenaRank2.getComponent(CommonLoader).loaderNode.getComponent(ArenaSeniorRankBig).refresh(Number(arenaSeniorLogic.getBattleReport().rivalNewRankId));

        commitLogic.arenaBattle(ArenaPvpType.high, win);

        if (win) {
            activityLogic.doIncTaskActProgress(ActivityType.CrazyArena, TaskActivityType.SeniorArenaWin, null, 1);
        }
    }

    protected _getGoldIncreaseStr() {
        let arenaRankCfg = ArenaRankconfig.find(a => a.ID == Number(arenaSeniorLogic.getBattleReport().newRank));
        if (!arenaRankCfg) {
            arenaRankCfg = ArenaRankconfig[ArenaRankconfig.length - 1];
        }
        let otherHour = arenaRankCfg.coindrophour;
        arenaRankCfg = ArenaRankconfig.find(a => a.ID == Number(arenaSeniorLogic.getBattleReport().rivalNewRank));
        if (!arenaRankCfg) {
            arenaRankCfg = ArenaRankconfig[ArenaRankconfig.length - 1];
        }
        let myHour = arenaRankCfg.coindrophour;
        if (otherHour > myHour) {
            return `+${otherHour - myHour}/H`;
        }
        return null;
    }

    protected _showScore() {
        let battleReport = arenaSeniorLogic.getBattleReport();
        let win = battleReport.isWin;
        this.scoreNode.active = true;
        if (!win) {
            this.scoreNode.y = 0;
        }
        this.scoreLabel.string = battleReport.rawScore.toString();
        this.redArrow.active = this.greenArrow.active = false;
        if (win) {
            this.scoreAddLabel.string = `+${battleReport.newScore - battleReport.rawScore}`;
            let color = cc.Color.WHITE;
            color.fromHEX("#30E739");
            this.scoreAddLabel.node.color = color;
            this.greenArrow.active = true;
        } else {
            this.scoreAddLabel.string = `-${battleReport.rawScore - battleReport.newScore}`;
            let color = cc.Color.WHITE;
            color.fromHEX("#D34A4A");
            this.scoreAddLabel.node.color = color;
            this.redArrow.active = true;
        }
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType }) => {
            if (data.type == BattleType.PVP_Senior) {
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);

        cc.director.setTimeScale(1);
    }

    onDestroy() {
        let ex: string = arenaSeniorLogic.getBattleReport().isWin ? "win" : "";
        EManager.emit(EName.onArenaUpdateRank, ex);
        super.onDestroy();
    }

    onExit() {
        EManager.emit(EName.onGameExit, { type: BattleType.PVP_Senior });
        let battleReport = arenaSeniorLogic.getBattleReport();
        if (battleReport.newRankId > arenaSeniorLogic.oldRankId) {
            gcc.core.showLayer("prefabs/panel/arena/ArenaSeniorScoreChangePanel", {
                data: {
                    player1: arenaSeniorLogic.myRank,
                    player2: arenaSeniorLogic.getRivalData()
                }
            });
        }
    }

}
