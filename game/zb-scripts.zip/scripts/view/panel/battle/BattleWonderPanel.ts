import BattleSharePanel from "./BattleSharePanel";
import wonderSpaceLogic from "../../../logics/WonderSpaceLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleWonderPanel")
export default class BattleWonderPanel extends BattleSharePanel {

    startBattle() {
        super.startBattle();

        let heros = this._fightNode.manager.getHeroList();
        for (let hero of heros) {
            let wisdomHero = wonderSpaceLogic.wonderHero.wisdomTreeHeroData.find(a => a.hero == hero.heroData.heroId);
            if (wisdomHero && wisdomHero.hp > 0) {
                hero.heroData.hp = wisdomHero.hp;
                hero.heroData.hpMax = wisdomHero.hpMax;
                hero.heroData.power = wisdomHero.power;
            }
        }
    }

}