import EManager, {EName} from './../../../manager/EventManager';
import BattlePanel from "./BattlePanel";
import stringUtils from "../../../utils/StringUtils";
import Hero from "../../../data/card/Hero";
import commonUtils from "../../../utils/CommonUtils";
import battleLogic from "../../../logics/BattleLogic";
import arenaLogic from "../../../logics/ArenaLogic";
import {BattleType, TaskActivityType} from "../../../utils/DefineUtils";
import activityLogic, {ActivityType} from "../../../logics/ActivityLogic";
import gm from "../../../manager/GameManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattlePVPPanel")
export default class BattlePVPPanel extends BattlePanel {
    @property(cc.Label)
    labelTime: cc.Label = null;

    @property(cc.Label)
    labelGold: cc.Label = null;

    @property(cc.Label)
    labelChest: cc.Label = null;

    onInit(data: {
        troops: { selfTroop: Hero[], enemyTroop: Hero[] },
        sceneConfig: rpgfight.SceneConfig,
        playBack?: boolean,
        battleNo?: number
    }) {
        super.onInit(data);
        battleLogic.initPVP();
        activityLogic.doIncTaskActProgress(ActivityType.CrazyArena, TaskActivityType.JoinArena, null, 1);
    }

    getBattleType(): BattleType {
        return this.data.playBack ? BattleType.PVP_PlayBack : BattleType.PVP;
    }

    getBgUrl(): string {
        return commonUtils.getBgUrl("arena_battle_bg");
    }

    update(dt: number) {
        super.update(dt);

        if (!this._fightNode) {
            return;
        }
        let totalTime = this._fightNode.manager.getScene().sceneData.config.time;
        let currentTime = this._fightNode.manager.clock.currentTime;
        let remainTime = Math.max(totalTime - currentTime, 0);
        remainTime = Math.floor(remainTime / 1000);
        if (remainTime <= 0) {
            this.labelTime.string = "00:00";
        } else {
            this.labelTime.string = stringUtils.formatTime(remainTime);
        }
    }

    protected async _onSelfTroopDead() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;

        this._fightNode.finishGame(false);
        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onSelfTroopDead();
        if (this.data.playBack) {
            EManager.emit(EName.onGameExit, { type: BattleType.PVP_PlayBack });
        } else {
            this._onGetGameResult();
        }
    }

    protected async _onEnemyTroopDead() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;
        this._fightNode.finishGame(true);

        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onEnemyTroopDead();
        if (this.data.playBack) {
            EManager.emit(EName.onGameExit, { type: BattleType.PVP_PlayBack });
        } else {
            this._onGetGameResult();
        }
    }

    protected async _onGameTimeout() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;
        this._fightNode.finishGame(false);

        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onGameTimeout();
        if (this.data.playBack) {
            EManager.emit(EName.onGameExit, { type: BattleType.PVP_PlayBack });
        } else {
            this._onGetGameResult();
        }
    }

    protected async _onGameSkip() {
        this._isGameover = true;
        await this._onGetGameResult();
        let bWin: boolean = arenaLogic.getBattleReport().isWin == 0;
        if (bWin) {
            super.winTaskCommit();
            super.mercHeroNumCommit();
            activityLogic.doIncTaskActProgress(ActivityType.CrazyArena, TaskActivityType.ArenaWin, null, 1);
        }
        this._fightNode.finishGame(arenaLogic.getBattleReport().isWin == 0);
    }

    protected async _onGetGameResult() {
        try {
            await arenaLogic.doArenaResult(this.data.battleNo);
            if (arenaLogic.getBattleReport()) {
                if (arenaLogic.getBattleReport().isWin == 0) {
                    gcc.core.showLayer("prefabs/panel/battle/BattlePVPWinPanel", {data: arenaLogic.getBattleReport()});
                } else {
                    gcc.core.showLayer("prefabs/panel/battle/BattlePVPLosePanel", {data: arenaLogic.getBattleReport()});
                }
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
                EManager.emit(EName.onGameExit, { type: BattleType.PVP });
            } else {
                throw e;
            }
        }
    }
}
