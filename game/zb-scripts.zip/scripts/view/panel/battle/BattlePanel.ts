import { EName } from './../../../manager/EventManager';
import { FightViewPool } from './../../fight/FightViewPool';
import { FullscreenPanel } from './../BasePanel'
import gm from '../../../manager/GameManager';
import FightRoot from '../../fight/FightRoot';
import CommonLoader from '../../common/CommonLoader';
import BattleUIPanel from './BattleUIPanel';
import Hero from '../../../data/card/Hero';
import battleLogic from '../../../logics/BattleLogic';
import EManager from '../../../manager/EventManager';
import commonUtils from '../../../utils/CommonUtils';
import loadUtils from '../../../utils/LoadUtils';
import assignmentLogic from '../../../logics/AssignmentLogic';
import { BattleType, DailyType, WeekType } from '../../../utils/DefineUtils';
import friendMerLogic from '../../../logics/FriendMerLogic';
import am from '../../../manager/AudioManager';
import cm from '../../../manager/ConfigManager';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattlePanel")
export abstract default class BattlePanel extends FullscreenPanel {
    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(CommonLoader)
    ui: CommonLoader = null;

    protected _sceneConfig: rpgfight.SceneConfig = null;
    protected _fightNode: FightRoot;
    protected _heroSkillFrames: { [key: number]: { active: boolean, heroIds: string[] } } = {};
    protected _isRestart: boolean = false;
    protected _isGameover: boolean = false;

    onInit(data: {
        troops: {
            selfTroop: Hero[],
            enemyTroop: Hero[],
        },
        sceneConfig: rpgfight.SceneConfig
    }) {
        super.onInit(data);
        battleLogic.init(data.troops, gm);
        battleLogic.battleData = this.data;
        this._sceneConfig = data.sceneConfig;
        this._heroSkillFrames = {};
    }

    onLoad() {
        super.onLoad();
        this.ui.node.zIndex = 255;
        this.registerEvents();
        gm.isFighting = true;
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onTryGamePause, (data: { type: BattleType }) => {
            if (this.getBattleType() != data.type) return;
            if (this._isGameover) return;
            gcc.core.showLayer("prefabs/panel/battle/BattlePausePanel", {
                data: { battleType: this.getBattleType(), battleData: this.data.battleData }
            });
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onGamePause, (data: { type: BattleType }) => {
            if (data.type == this.getBattleType()) {
                this.pause();
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onGameResume, (data: { type: BattleType }) => {
            if (data.type == this.getBattleType()) {
                this.resume();
            }
        });
        this._eventListeners.push(listener);

        let listeners = EManager.addEventArray([EName.onGameExit, EName.onGameRestart], (data: { type: BattleType }) => {
            if (this.getBattleType() != data.type) {
                return;
            }
            if (this._fightNode) { this._fightNode.abortBattle() }
            this.closePanel();
        });
        this._eventListeners.pushList(listeners);

        listener = EManager.addEvent(EName.onClickHeroSkill, (hero: Hero) => {
            if (this.getBattleType() == BattleType.Record ||
                this.getBattleType() == BattleType.PVP ||
                this.getBattleType() == BattleType.PVP_PlayBack ||
                this.getBattleType() == BattleType.PVP_Senior ||
                this.getBattleType() == BattleType.PVP_Senior_Record) {
                return;
            }

            if (this._fightNode) {
                this._fightNode.activeTheSkill(hero.getId());
            }
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onHeroDead, (fightHero: rpgfight.Hero) => {
            if (fightHero.manager.battleType != this.getBattleType()) {
                return;
            }
            this._onHeroDead(fightHero);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onGameSkillAuto, (data: { type: BattleType, isAuto: boolean }) => {
            if (data.type != this.getBattleType()) return;
            this._onGameSkillAuto(data.isAuto);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onGameSpeedX2, (data: { type: BattleType, isSpeedX2: boolean }) => {
            if (data.type != this.getBattleType()) return;
            this._onGameSpeedX2(data.isSpeedX2);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onSelfTroopDead, (data: { type: BattleType }) => {
            if (data.type != this.getBattleType()) return;
            this._onSelfTroopDead();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onEnemyTroopDead, (data: { type: BattleType }) => {
            if (data.type != this.getBattleType()) return;
            this._onEnemyTroopDead();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onGameTimeout, (data: { type: BattleType }) => {
            if (data.type != this.getBattleType()) return;
            this._onGameTimeout();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onGameSkip, (data: { type: BattleType }) => {
            if (data.type != this.getBattleType()) return;
            this._onGameSkip();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onShakeScreen, (hero: rpgfight.Hero) => {
            if (hero.manager.battleType != this.getBattleType()) return;
            this._onShakeScreen();
        });
        this._eventListeners.push(listener);
    }

    onDestroy() {
        gm.isFighting = false;
        cc.director.setTimeScale(1);
        super.onDestroy();
    }

    start() {
        super.start();

        let type = this.getBattleType()
        let comp = this.ui.loaderNode.getComponent(BattleUIPanel);
        comp.init(type);

        this.startBattle();
        this.fightTaskCommit();
    }

    // 日常挑战任务提交
    fightTaskCommit() {
        let fightType = this.getBattleType();
        if (fightType == BattleType.PVE) {
            let task = assignmentLogic.getDailyTasks().find(a => a.taskId == 1001);
            if (task) {
                assignmentLogic.completePveDailyTask = task.complete_task;
                assignmentLogic.dailyTaskProCommit(DailyType.fight_header);
            }
        } else if (fightType == BattleType.PVP) {
            assignmentLogic.dailyTaskProCommit(DailyType.fight_arena);
        } else if (fightType == BattleType.Tower) {
            let task = assignmentLogic.getDailyTasks().find(a => a.taskId == 1004);
            if (task) {
                assignmentLogic.completeTowerDailyTask = task.complete_task;
                assignmentLogic.dailyTaskProCommit(DailyType.fight_tower);
            }
        } else if (fightType == BattleType.Hunt) {
            assignmentLogic.dailyTaskProCommit(DailyType.fight_union);
        }
    }

    // 周常挑战胜利任务提交
    winTaskCommit() {
        let fightType = this.getBattleType();
        if (fightType == BattleType.PVP) {
            assignmentLogic.weekTaskProCommit(WeekType.win_arena);
        } else if (fightType == BattleType.Maze) {

        }
    }

    // 雇佣英雄次数处理
    mercHeroNumCommit() {
        if (!friendMerLogic.needMercHero(this.getBattleType())) { return; }
        if (this._data) {
            let myHeros: Hero[] = this._data.troops.selfTroop;
            if (myHeros) {
                let len = myHeros.length;
                for (let i = 0; i < len; i++) {
                    if (myHeros[i]) {
                        friendMerLogic.mercHeroFightCommit(myHeros[i].getId(), this.getBattleType());
                    }
                }
            }
        }
    }

    startBattle() {
        if (this.getBattleType() != BattleType.Record && this.getBattleType() != BattleType.PVP_PlayBack && this.getBattleType() != BattleType.PVP_Senior_Record) {
            gm.battleType = this.getBattleType();
        }

        //创建战斗视图
        let fightNode = cc.find('fightNode', this.node) || new cc.Node('fightNode')
        let root = fightNode.addComponent(FightRoot);
        let data = null;
        let heroList: rpgfight.HeroConfig[] = battleLogic.getHeroList();
        for (let hero of heroList) {
            hero.power = this.getDefaultPower();
            hero.powerSpeedupRate = this.getPowerSpeedupRate();

            if (this.getBattleType() == BattleType.Hunt
                || this.getBattleType() == BattleType.WorldBoss
                || this.getBattleType() == BattleType.Treasure) {
                if (hero.battleTeam == rpgfight.BattleTeam.enemy) {
                    hero.battleInitPosition = ml.p(rpgfight.Hero.StationPositionX[hero.battleStation - 1],
                        rpgfight.Hero.StationPositionY[hero.battleStation - 1]);
                }
            }
        }
        if (this.getBattleType() == BattleType.PVP ||
            this.getBattleType() == BattleType.PVP_PlayBack ||
            this.getBattleType() == BattleType.PVP_Senior ||
            this.getBattleType() == BattleType.PVP_Senior_Record) {
            data = new rpgfight.ArenaData(this._sceneConfig, heroList, battleLogic.getSummonList());
        } else {
            data = new rpgfight.NormalData(this._sceneConfig, heroList, battleLogic.getSummonList());
        }
        root.startFight(data, this.getBattleType());
        root.setFightLogEnabled(!CC_JSB);
        root.manager.robotPlayer.autoPlay = battleLogic.isAutoSkill;

        let activeHeroSkill = root.manager.robotPlayer.activeHeroSkill;
        root.manager.robotPlayer.activeHeroSkill = (hero: rpgfight.Hero): boolean => {
            let ret = activeHeroSkill.call(root.manager.robotPlayer, hero);
            if (ret) { this._onActiveHeroBSkill(hero); }
            return ret;
        }
        let deactiveHeroSkill = root.manager.robotPlayer.deactiveHeroSkill;
        root.manager.robotPlayer.deactiveHeroSkill = (hero: rpgfight.Hero): boolean => {
            let ret = deactiveHeroSkill.call(root.manager.robotPlayer, hero);
            if (ret) { this._onDeactiveHeroBSkill(hero); }
            return ret;
        }

        if (this.getBattleType() == BattleType.Record) { root.manager.robotPlayer.autoPlay = false; }
        root.manager.effectViewManager.isEnemyCloseupEnabled = (
            this.getBattleType() == BattleType.PVP ||
            this.getBattleType() == BattleType.PVP_PlayBack ||
            this.getBattleType() == BattleType.PVP_Senior ||
            this.getBattleType() == BattleType.PVP_Senior_Record
        );
        this._fightNode = root;
        let bg = this.node.getChildByName("bg");
        if (bg) {
            fightNode.parent = bg;
        }
        else {
            fightNode.parent = this.node;
        }
        fightNode.position = cc.v2(0, -135);

        let comp = this.ui.loaderNode.getComponent(BattleUIPanel);
        comp.fightRoot = root;

        gm.isBattled = true;
    }

    getContributionResult(): rpgfight.HeroContributionStatistic[] {
        let fightManager = this._fightNode.fightManager as rpgfight.BattleManager;
        if (fightManager.getContributionResult) {
            return (this._fightNode.fightManager as rpgfight.BattleManager).getContributionResult();
        } else {
            return [];
        }
    }

    getPowerSpeedupRate(): number {
        return 1;
    }

    getDefaultPower(): number {
        return 0;
    }

    getHeroSkillFrames(): { [key: number]: { active: boolean, heroIds: string[] } } {
        return this._heroSkillFrames;
    }

    pause() {
        this.pauseBattle();
        commonUtils.pauseNode(this.node);
    }

    resume() {
        this.resumeBattle();
        commonUtils.resumeNode(this.node);
    }

    pauseBattle() {
        if (!!this._fightNode) {
            commonUtils.pauseNode(this._fightNode.node);
            this._fightNode.pause()
        }
    }

    resumeBattle() {
        if (!!this._fightNode) {
            this._fightNode.resume()
            commonUtils.resumeNode(this._fightNode.node);
        }
    }

    protected _onActiveHeroBSkill(hero: rpgfight.Hero) {
        if (this._fightNode) {
            if (this.getBattleType() == BattleType.Record ||
                this.getBattleType() == BattleType.PVP ||
                this.getBattleType() == BattleType.PVP_PlayBack ||
                this.getBattleType() == BattleType.PVP_Senior ||
                this.getBattleType() == BattleType.PVP_Senior_Record) {
                return;
            }
            if (hero.heroData.battleTeam == rpgfight.BattleTeam.our) {
                let frameCount = this._fightNode.manager.runner.frameCount;
                let frame = this._heroSkillFrames[frameCount];
                if (!frame) {
                    frame = { active: true, heroIds: [] };
                    this._heroSkillFrames[frameCount] = frame;
                }
                frame.heroIds.push(hero.heroData.heroId);
            }
        }
    }

    protected _onDeactiveHeroBSkill(hero: rpgfight.Hero) {
        if (this._fightNode) {
            if (this.getBattleType() == BattleType.Record ||
                this.getBattleType() == BattleType.PVP ||
                this.getBattleType() == BattleType.PVP_PlayBack ||
                this.getBattleType() == BattleType.PVP_Senior ||
                this.getBattleType() == BattleType.PVP_Senior_Record) {
                return;
            }
            if (hero.heroData.battleTeam == rpgfight.BattleTeam.our) {
                let frameCount = this._fightNode.manager.runner.frameCount;
                let frame = this._heroSkillFrames[frameCount];
                if (!frame) {
                    frame = { active: false, heroIds: [] };
                    this._heroSkillFrames[frameCount] = frame;
                }
                frame.heroIds.push(hero.heroData.heroId);
            }
        }
    }

    protected _onHeroDead(fightHero: rpgfight.Hero) {

    }

    protected _onGameSkillAuto(isAuto: boolean) {
        if (this._fightNode) {
            if (this.getBattleType() == BattleType.Record) { return; }
            this._fightNode.manager.robotPlayer.autoPlay = isAuto;
        }
    }

    protected _onGameSpeedX2(isSpeedX2: boolean) {
        cc.director.setTimeScale(isSpeedX2 ? 1.7 : 1);
    }

    protected _onSelfTroopDead() {
        // override
    }

    protected _onEnemyTroopDead() {
        // override
        this.winTaskCommit();
        this.mercHeroNumCommit();
    }

    protected _onGameTimeout() {
        // override
    }

    protected _onGameSkip() {
        console.time("跳过");
        let manager = this._fightNode.manager as any;
        manager.skip = true;
        while (manager.gameState == rpgfight.GameState.running) {
            manager.runner.update();
        }
        console.timeEnd("跳过");
    }

    protected _onShakeScreen() {
        let bg = this.node.getChildByName("bg");
        if (bg) {
            let animation = bg.getComponent(cc.Animation);
            if (animation) animation.play();
        }
    }

    protected async _preloadRes() {
        await super._preloadRes();

        FightViewPool.inst.unloadAll()
        am.uncacheAll();
        cc.sys.garbageCollect();

        if (this.getBattleType() == BattleType.PVP ||
            this.getBattleType() == BattleType.PVP_PlayBack ||
            this.getBattleType() == BattleType.PVP_Senior ||
            this.getBattleType() == BattleType.PVP_Senior_Record) {
            am.playMusic("BGM_pvp");
        }
        else {
            am.playMusic("BGM_battle");
        }
        gm.destroyHangUpBattle();

        try {
            await this._preloadBg();
            await this._preloadHeroes();
            await this._preloadEffects();
        } catch (e) {
            console.error(e);
        }
    }

    protected _unloadRes(prefab: cc.Prefab) {
        FightViewPool.inst.unloadAll()
        am.uncacheAll();
        am.stopMusic();
        cc.sys.garbageCollect();

        super._unloadRes(prefab);

        let loader = cc.loader;
        let resources = (loader as any)._resources;
        let assetsType = [sp.SkeletonData, cc.Prefab];
        for (let asset of assetsType) {
            let uuids = resources.getUuidArray("spine/buff", asset);
            uuids.pushList(resources.getUuidArray("spine/effect", asset));
            for (let uuid of uuids) {
                let path = resources._uuidToPath[uuid];
                if (path && path.startsWith("spine/buff/CommonBuff")) {
                    continue;
                }

                let ref = (cc.loader as any)._getReferenceKey(uuid);
                let item = (cc.loader as any)._cache[ref];
                if (item && item.alias) {
                    item = item.alias;
                }
                if (item && item.complete) {
                    let res = item.content;
                    loadUtils.releaseAssetRecursively(res);
                }
            }
        }
    }

    protected async _preloadBg() {
        let frame = cc.loader.getRes(this.getBgUrl(), cc.SpriteFrame);
        if (!cc.isValid(frame)) {
            frame = await loadUtils.loadRes(this.getBgUrl(), cc.SpriteFrame) as cc.SpriteFrame;
            this._unloadInfos.push({ url: this.getBgUrl(), type: cc.SpriteFrame });
            if (!cc.isValid(this.bg)) {
                throw new Error("this.bg is invalid");
            }
        }
        this.bg.spriteFrame = frame;
    }

    protected async _preloadHeroes() {
        let url = 'prefabs/fight/fight_toast';
        let toastPrefab = await loadUtils.loadRes(url, cc.Prefab) as cc.Prefab;

        url = 'prefabs/fight/fight_kill';
        let killPrefab = await loadUtils.loadRes(url, cc.Prefab) as cc.Prefab;

        let heroes = battleLogic.getHeroList();
        for (let hero of heroes) {
            if (!hero) continue;
            let config = cm.getHeroConfig(Number(hero.heroConfigId));
            if (!config) continue;

            let url = commonUtils.getHeroSpineUrl(config.Spine);
            let skeletonData = cc.loader.getRes(url, sp.SkeletonData) as sp.SkeletonData;
            if (!skeletonData) { await loadUtils.loadRes(url, sp.SkeletonData); }

            let node = cc.instantiate(toastPrefab) as cc.Node;
            FightViewPool.inst.nodePool.put("play_toast_effect", node);

            node = cc.instantiate(killPrefab) as cc.Node;
            FightViewPool.inst.nodePool.put("play_kill_effect", node);
        }

        let summons = battleLogic.getSummonList();
        for (let summon of summons) {
            if (!summon) continue;
            let config = cm.getHeroConfig(Number(summon.heroConfigId));
            if (!config) continue;

            let url = commonUtils.getHeroSpineUrl(config.Spine);
            let skeletonData = cc.loader.getRes(url, sp.SkeletonData) as sp.SkeletonData;
            if (!skeletonData) {
                await loadUtils.loadRes(url, sp.SkeletonData);
                this._unloadInfos.push({ url: url, type: sp.SkeletonData });
            }
        }
    }

    protected async _preloadEffects() {
        try {
            let heroes = battleLogic.getHeroList();
            let effectIds = new Set<number>();
            let audioNames = new Set<string>();
            for (let hero of heroes) {
                let skills = [hero.attackSkill];
                skills.pushList(hero.skillList);
                for (let skill of skills) {
                    let entity = skill.triggerTree as rpgfight.ISkillEntity;

                    let effectNames = entity.getEffectNames();
                    for (let name of effectNames) {
                        let effectId = Number(name);
                        if (!isNaN(effectId)) { effectIds.add(effectId); }
                    }

                    let names = entity.getAudioNames();
                    for (let name of names) { audioNames.add(name); }
                }
            }

            let ids = Array.from(effectIds);
            for (let id of ids) {
                let config = cm.getEffectView(id);
                if (config) { await loadUtils.loadRes(`spine/${config.Path}`, sp.SkeletonData); }
            }

            let names = Array.from(audioNames);
            for (let name of names) {
                await am.preloadEffect(`skill/${name}`);
            }
        } catch (error) {
            console.error(error);
        }
    }

    public abstract getBgUrl(): string;
    public abstract getBattleType(): BattleType;
}
