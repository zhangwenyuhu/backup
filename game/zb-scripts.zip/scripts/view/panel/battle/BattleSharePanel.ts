import { unlockConfigMap } from './../../../configs/unlockConfig';
import { SharedHeroEffectView } from './../../fight/SharedHeroEffectView';
import { defaultConfigMap } from './../../../configs/defaultConfig';
import { EName } from './../../../manager/EventManager';
import BattlePanel from "./BattlePanel";
import stringUtils from "../../../utils/StringUtils";
import Hero from "../../../data/card/Hero";
import commonUtils from "../../../utils/CommonUtils";
import battleLogic from "../../../logics/BattleLogic";
import { BattleType } from "../../../utils/DefineUtils";
import IBattleData from "../../../data/IBattleData";
import EManager from "../../../manager/EventManager";
import towerLogic from '../../../logics/TowerLogic';
import Mission, { MissionType } from '../../../data/mission/Mission';
import guideTaskLogic from '../../../logics/GuideTaskLogic';
import unionLogic from "../../../logics/UnionLogic";
import guideLogic from '../../../logics/GuideLogic';
import cm from '../../../manager/ConfigManager';
import loadUtils from '../../../utils/LoadUtils';
import FightViewFactory from '../../fight/FightViewFactory';
import Npc from '../../../data/card/Npc';
import Skill from '../../../data/card/Skill';
import HeroView from '../../fight/HeroView';
import am from '../../../manager/AudioManager';
import Tower from '../../../data/tower/Tower';
import UnlockWrapper from '../../widget/unlock/UnlockWrapper';
import BattleUIPanel from './BattleUIPanel';
import VipUnlockWrapper from '../../widget/unlock/VipUnlockWrapper';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleSharePanel")
export default class BattleSharePanel extends BattlePanel {
    @property(cc.Label)
    labelTime: cc.Label = null;

    @property(cc.Label)
    labelGold: cc.Label = null;

    @property(cc.Label)
    labelChest: cc.Label = null;

    @property(cc.Node)
    nodeGold: cc.Node = null;

    @property(cc.Node)
    nodeChest: cc.Node = null;

    protected _battleData: IBattleData = null;
    protected _chestCnt: number = 0;

    public isHeroEntered: boolean = false;
    public isHeroDead: boolean = false;
    public heroCondition: string = "";

    onInit(data: {
        battleData: IBattleData,
        troops: { selfTroop: Hero[], enemyTroop: Hero[] },
        sceneConfig: rpgfight.SceneConfig,
        playBack?: boolean
    }) {
        super.onInit(data);
        this._battleData = data.battleData;
        if (this.getBattleType() != BattleType.Record && this._battleData.getBattleType instanceof Function) {
            if (this._battleData.getBattleType() == BattleType.Tower
                || this._battleData.getBattleType() == BattleType.PVE
                || this._battleData.getBattleType() == BattleType.Dungeon) {
                this.nodeGold.active = false;
                this.nodeChest.active = false;
            }
            if (this._battleData.getBattleType() == BattleType.Maze) {
                battleLogic.initMaze();
                guideTaskLogic.guideTaskProgressCommit(5006, 1, true);
            } else if (this._battleData.getBattleType() == BattleType.WonderSpace) {
                battleLogic.initMaze(true);
            } else if (this._battleData.getBattleType() == BattleType.Treasure) {
                battleLogic.initTreasure();
                guideTaskLogic.guideTaskProgressCommit(5006, 1, true);
            } else if (this._battleData.getBattleType() == BattleType.Dungeon) {
                battleLogic.initDungeon();
            }
        }
        if (this._battleData.getBattleType instanceof Function) {
            if (this._battleData.getBattleType() == BattleType.Hunt) {
                battleLogic.initHunt(unionLogic.unionHuntMonster.getMonsterId());
            }
        }
    }

    start() {
        super.start();

        let showSkipBtn = function (comp: BattleUIPanel) {
            let wrapper = comp.btnSkip.getComponent(VipUnlockWrapper);
            wrapper.enabled = false;

            comp.btnSkip.active = true;

            let widget = comp.btnSkip.getComponent(cc.Widget);
            widget.right += 82;
            widget.updateAlignment();
        }

        let comp = this.ui.loaderNode.getComponent(BattleUIPanel);
        if (this._battleData.getBattleType() == BattleType.PVE) {
            comp.btnSkip.active = false;

            if (UnlockWrapper.isUnlock(unlockConfigMap.主线关卡跳过)) {
                let mission = this._battleData as Mission;
                if (mission.getMissionType() != MissionType.Boss) {
                    showSkipBtn(comp);
                }
            }
        }
        else if (this._battleData.getBattleType() == BattleType.UnionWar ||
            this._battleData.getBattleType() == BattleType.UnionDungeon) {
            showSkipBtn(comp);
        }
    }

    registerEvents() {
        super.registerEvents();

        let listener = EManager.addEvent(EName.onChestGet, () => {
            this._chestCnt++;
            this.labelChest.string = this._chestCnt.toString();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onHeroCallback, (data: { key: string }) => {
            this.heroCondition = data.key;
        });
        this._eventListeners.push(listener);
    }

    getBattleType(): BattleType {
        return this._battleData.getBattleType();
    }

    getBgUrl(): string {
        let url = "";
        if (this._battleData.getBattleType() == BattleType.PVE) {
            let mission = this._battleData as Mission;
            url = commonUtils.getBattleBgUrl(BattleType.PVE, mission.config.Battlebg)
        }
        else {
            url = commonUtils.getBattleBgUrl(this._battleData.getBattleType());
        }
        return url;
    }

    getPowerSpeedupRate(): number {
        if (this._battleData.getBattleType instanceof Function) {
            if (this._battleData.getBattleType() == BattleType.PVE) {
                let mission = this._battleData as Mission;
                if (mission.getStageId() == guideLogic.artifactStageId) {
                    return 0.1;
                }
            }
        }
        return super.getPowerSpeedupRate();
    }

    getDefaultPower(): number {
        if (this._battleData.getBattleType instanceof Function) {
            if (this._battleData.getBattleType() == BattleType.PVE) {
                let mission = this._battleData as Mission;
                if (mission.getStageId() < defaultConfigMap.energyaddstop.value && mission.getStageId() != guideLogic.artifactStageId) {
                    return defaultConfigMap.energystartadd.value;
                }
            }
        }
        return super.getDefaultPower();
    }

    update(dt: number) {
        super.update(dt);

        if (this._isGameover) {
            return;
        }
        if (!this._fightNode) {
            return;
        }
        let totalTime = this._fightNode.manager.getScene().sceneData.config.time;
        let currentTime = this._fightNode.manager.clock.currentTime;
        let remainTime = Math.max(totalTime - currentTime, 0);
        remainTime = Math.floor(remainTime / 1000);
        if (remainTime <= 0) {
            this.labelTime.string = "00:00";
        }
        else {
            this.labelTime.string = stringUtils.formatTime(remainTime);
        }
        this.isHeroEntered = this._fightNode.manager.isHeroEntered;
    }

    protected async _onSelfTroopDead() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;

        if (this.getBattleType() == BattleType.Maze || this.getBattleType() == BattleType.WonderSpace) {
            EManager.emit(EName.onWisdomSaveHero, this._fightNode.manager.getHeroList());
        }
        this._fightNode.finishGame(false);

        await commonUtils.sleep(1.5, this);
        EManager.emit(EName.onGameOver);
        EManager.emit(EName.onFreshGuideTask);

        if (this.data.playBack) {
            EManager.emit(EName.onGameExit, { type: this.getBattleType() });
        } if (this.getBattleType() == BattleType.Record || this.getBattleType() == BattleType.PVP_PlayBack) {
            this.scheduleOnce(() => { this.closePanel(); })
        } else if (this.getBattleType() == BattleType.Hunt) {
            this.scheduleOnce(() => {
                gcc.core.showLayer("prefabs/panel/union/UnionHuntResultPanel", {
                    data: {
                        battleData: this._battleData,
                        troops: this.data.troops,
                        sceneConfig: this.data.sceneConfig,
                        skills: this.getHeroSkillFrames(),
                        contribution: this.getContributionResult()
                    }
                });
            }, 2);
        } else if (this.getBattleType() == BattleType.Treasure) {
            gcc.core.showLayer("prefabs/panel/battle/BattleRaiderResultPanel");
        } else if (this.getBattleType() == BattleType.WorldBoss
            || this.getBattleType() == BattleType.Clone) {
            this._showBattleResult(false);
        } else if (this.getBattleType() == BattleType.Dungeon) {
            gcc.core.showLayer("prefabs/panel/dungeon/DungeonLosePanel", {
                data: {
                    battleData: this._battleData,
                    skills: this.getHeroSkillFrames(),
                    contribution: this.getContributionResult()
                }
            });
        } else if (this.getBattleType() == BattleType.UnionWar) {
            gcc.core.showLayer("prefabs/panel/union_war/UnionWarResultPanel", {
                data: {
                    result: false,
                    battleData: this._battleData,
                    skills: this.getHeroSkillFrames(),
                    contribution: this.getContributionResult(),
                    heroList: this._fightNode.fightManager.getHeroList()
                }
            });
        } else if (this.getBattleType() == BattleType.UnionDungeon) {
            gcc.core.showLayer("prefabs/panel/union/dungeon/UnionDungeonResultPanel", {
                data: {
                    result: false,
                    battleData: this._battleData,
                    skills: this.getHeroSkillFrames(),
                    contribution: this.getContributionResult(),
                    heroList: this._fightNode.fightManager.getHeroList()
                }
            });
        }
        else {
            gcc.core.showLayer("prefabs/panel/battle/BattleLosePanel", {
                data: {
                    battleData: this._battleData,
                    skills: this.getHeroSkillFrames(),
                    contribution: this.getContributionResult()
                }
            });
        }
        super._onSelfTroopDead();
        this._saveTowerBattle();
    }

    protected async _onEnemyTroopDead() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;

        if (this._fightNode) {
            if (this.getBattleType() == BattleType.Maze || this.getBattleType() == BattleType.WonderSpace) {
                EManager.emit(EName.onWisdomSaveHero, this._fightNode.manager.getHeroList());
            }
            this._fightNode.finishGame(true);
        }
        await commonUtils.sleep(1.5, this);
        EManager.emit(EName.onGameOver);
        EManager.emit(EName.onFreshGuideTask);

        if (this.getBattleType() == BattleType.Record ||
            this.getBattleType() == BattleType.PVP_PlayBack) {
            this.scheduleOnce(() => {
                this.closePanel();
            })
        } else if (this.getBattleType() == BattleType.Hunt) {
            this.scheduleOnce(() => {
                gcc.core.showLayer("prefabs/panel/union/UnionHuntResultPanel", {
                    data: {
                        battleData: this._battleData,
                        troops: this.data.troops,
                        sceneConfig: this.data.sceneConfig,
                        skills: this.getHeroSkillFrames(),
                        contribution: this.getContributionResult()
                    }
                });
            }, 2);
        } else if (this.getBattleType() == BattleType.Treasure) {
            gcc.core.showLayer("prefabs/panel/battle/BattleRaiderResultPanel");
        } else if (this.getBattleType() == BattleType.WorldBoss
            || this.getBattleType() == BattleType.Clone) {
            this._showBattleResult(true);
        } else if (this.getBattleType() == BattleType.Dungeon) {
            gcc.core.showLayer("prefabs/panel/dungeon/DungeonWinPanel", {
                data: {
                    battleData: this._battleData,
                    skills: this.getHeroSkillFrames(),
                    contribution: this.getContributionResult()
                }
            });
        } else if (this.getBattleType() == BattleType.UnionWar) {
            gcc.core.showLayer("prefabs/panel/union_war/UnionWarResultPanel", {
                data: {
                    result: true,
                    battleData: this._battleData,
                    skills: this.getHeroSkillFrames(),
                    contribution: this.getContributionResult(),
                    heroList: this._fightNode.fightManager.getHeroList()
                }
            });
        } else if (this.getBattleType() == BattleType.UnionDungeon) {
            gcc.core.showLayer("prefabs/panel/union/dungeon/UnionDungeonResultPanel", {
                data: {
                    result: true,
                    battleData: this._battleData,
                    skills: this.getHeroSkillFrames(),
                    contribution: this.getContributionResult(),
                    heroList: this._fightNode.fightManager.getHeroList()
                }
            });
        } else {
            if (this.data.playBack) {
                EManager.emit(EName.onGameExit, { type: this.getBattleType() });
            } else {
                gcc.core.showLayer("prefabs/panel/battle/BattleWinPanel", {
                    data: {
                        battleData: this._battleData,
                        skills: this.getHeroSkillFrames(),
                        contribution: this.getContributionResult()
                    }
                });
            }
        }

        super._onEnemyTroopDead();
        this._saveTowerBattle(true);
    }

    private _saveTowerBattle(win: boolean = false) {
        if (this.getBattleType() == BattleType.Tower) {
            let manager = this._fightNode.manager as rpgfight.BattleManager;
            let result = manager.getContributionResult().concat();
            let type: number = 0;
            if (this._battleData instanceof Tower) { type = this._battleData.getRaceType(); }
            if (type > 0) {
                towerLogic.raceTowerFightCommit(this._data, this._heroSkillFrames, result, this._sceneConfig.seed, win);
            } else {
                towerLogic.towerFightCommit(this._data, this._heroSkillFrames, result, this._sceneConfig.seed, win);
            }

        }
    }

    protected async _onGameTimeout() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;

        if (this.getBattleType() == BattleType.Maze || this.getBattleType() == BattleType.WonderSpace) {
            let heroes = this._fightNode.manager.getHeroList();
            for (let hero of heroes) {
                if (hero.heroData.battleTeam == rpgfight.BattleTeam.our) {
                    hero.heroData.hp = 0;
                }
            }
            EManager.emit(EName.onWisdomSaveHero, heroes);
        }
        this._fightNode.finishGame(false);

        await commonUtils.sleep(1.5, this);
        EManager.emit(EName.onGameOver);

        if (this.getBattleType() == BattleType.Record ||
            this.getBattleType() == BattleType.PVP_PlayBack) {
            this.scheduleOnce(() => {
                this.closePanel();
            })
        } else if (this.getBattleType() == BattleType.Hunt) {
            this.scheduleOnce(() => {
                gcc.core.showLayer("prefabs/panel/union/UnionHuntResultPanel", {
                    data: {
                        battleData: this._battleData,
                        troops: this.data.troops,
                        sceneConfig: this.data.sceneConfig,
                        skills: this.getHeroSkillFrames(),
                        contribution: this.getContributionResult()
                    }
                });
            }, 2);
        } else if (this.getBattleType() == BattleType.Treasure) {
            gcc.core.showLayer("prefabs/panel/battle/BattleRaiderResultPanel");
        } else if (this.getBattleType() == BattleType.WorldBoss
            || this.getBattleType() == BattleType.Clone) {
            this._showBattleResult(false);
        } else if (this.getBattleType() == BattleType.Dungeon) {
            gcc.core.showLayer("prefabs/panel/dungeon/DungeonLosePanel", {
                data: {
                    battleData: this._battleData,
                    skills: this.getHeroSkillFrames(),
                    contribution: this.getContributionResult()
                }
            });
        } else if (this.getBattleType() == BattleType.UnionWar) {
            gcc.core.showLayer("prefabs/panel/union_war/UnionWarResultPanel", {
                data: {
                    result: false,
                    battleData: this._battleData,
                    skills: this.getHeroSkillFrames(),
                    contribution: this.getContributionResult(),
                    heroList: this._fightNode.fightManager.getHeroList()
                }
            });
        } else if (this.getBattleType() == BattleType.UnionDungeon) {
            gcc.core.showLayer("prefabs/panel/union/dungeon/UnionDungeonResultPanel", {
                data: {
                    result: true,
                    battleData: this._battleData,
                    skills: this.getHeroSkillFrames(),
                    contribution: this.getContributionResult(),
                    heroList: this._fightNode.fightManager.getHeroList()
                }
            });
        } else {
            gcc.core.showLayer("prefabs/panel/battle/BattleLosePanel", {
                data: {
                    battleData: this._battleData,
                    skills: this.getHeroSkillFrames(),
                    contribution: this.getContributionResult()
                }
            });
        }
        super._onGameTimeout();
        this._saveTowerBattle();
    }

    protected _showBattleResult(isWin: boolean) {
        // override
    }

    public leishenCome() {
        let heroes = this._fightNode.manager.getHeroList((hero: rpgfight.Hero) => { return hero.battleTeam == rpgfight.BattleTeam.our });
        let battleNos = new Set<number>([1, 2, 3, 4, 5]);
        for (let hero of heroes) {
            battleNos.delete(hero.getBattleNo(null));
        }

        let battleNo = 1;
        if (battleNos.size > 0) {
            battleNo = Array.from(battleNos)[0];
        }
        let targetX = -rpgfight.Hero.StationPositionX[battleNo - 1];
        let targetY = rpgfight.Hero.StationPositionY[battleNo - 1];
        let factory = this._fightNode.manager.viewFactory as FightViewFactory;
        let effectView = factory.getSharedEffectView() as SharedHeroEffectView;
        let node = new cc.Node("LeiShenCome");
        node.position = cc.v2(targetX, targetY);
        node.parent = effectView.root;
        let skeleton = node.addComponent(sp.Skeleton);
        skeleton.skeletonData = cc.loader.getRes('spine/effect/LeishenCome/7014', sp.SkeletonData);
        skeleton.setCompleteListener(() => { node.destroy() });
        skeleton.setEventListener((entry: any, event: any) => {
            if (event.data.name == 'thor come') {
                let hero = new Npc(20033, 80, 4);
                battleLogic.addHeroToTroop(hero, true);

                let config = hero.getBattleCfg();
                config.battleTeam = rpgfight.BattleTeam.our;
                config.battleStation = battleNo;
                config.battleInitPosition = ml.p(targetX, targetY);
                config.power = config.powerMax;
                config.attack = 2000;
                config.hp = 100000;
                let fightHero = this._fightNode.manager.addHeroWithHeroConfig(config);
                for (let skill of fightHero.heroData.skillList) {
                    if (skill.isWithCloseUp) {
                        skill.startCd = 0.01;
                        skill.autoPlay = true;
                        break;
                    }
                }

                am.playEffect('skill/雷神技能3');
            }
        });
        skeleton.animation = '7015';
        skeleton.loop = false;
    }

    protected _onHeroDead(fightHero: rpgfight.Hero) {
        super._onHeroDead(fightHero);

        if (this.getBattleType() == BattleType.PVE) {
            let mission = this._battleData as Mission;
            if (mission.getStageId() == guideLogic.leishenStageId
                || mission.getStageId() == guideLogic.artifactStageId) {
                if (fightHero.battleTeam == rpgfight.BattleTeam.our) {
                    this.isHeroDead = true;
                    let heroes = this._fightNode.manager.getHeroList((hero: rpgfight.Hero) => { return hero.battleTeam == rpgfight.BattleTeam.our; });
                    for (let hero of heroes) {
                        let view = hero.view as HeroView;
                        if (view.isAlive) {
                            return;
                        }
                    }
                    this.isHeroDead = false;
                    guideLogic.guideId = guideLogic.recordId;
                }
            }
        }
    }

    protected async _preloadHeroes() {
        await super._preloadHeroes();

        if (this.getBattleType() == BattleType.PVE) {
            let mission = this._battleData as Mission;
            if (mission.getStageId() == guideLogic.leishenStageId) {
                let heroes = battleLogic.getHeroList();
                heroes = heroes.filter((hero: rpgfight.HeroConfig) => { return hero.battleTeam == rpgfight.BattleTeam.our });
                if (heroes.length > 1) {
                    guideLogic.guideId = 120001;

                    let config = cm.getHeroConfig(20033);
                    let url = commonUtils.getHeroSpineUrl(config.Spine);
                    let skeletonData = cc.loader.getRes(url, sp.SkeletonData) as sp.SkeletonData;
                    if (!skeletonData) {
                        await loadUtils.loadRes(url, sp.SkeletonData);
                        this._unloadInfos.push({ url: url, type: sp.SkeletonData });
                    }

                    url = 'spine/effect/LeishenCome/7014';
                    await loadUtils.loadRes(url, sp.SkeletonData);

                    url = 'sounds/skill/雷神技能3';
                    await loadUtils.loadRes(url, cc.AudioClip);
                }
            }
            else if (mission.getStageId() == guideLogic.artifactStageId) {
                let heroes = battleLogic.getHeroList();
                heroes = heroes.filter((hero: rpgfight.HeroConfig) => { return hero.battleTeam == rpgfight.BattleTeam.our; });
                if (heroes.length > 0) {
                    let skill = new Skill(null, cm.getSkillConfig(995008), []);
                    skill.getLevel = () => { return 1 }
                    let cfg = Hero.getSkillCfg(skill, heroes[0].skillList.length);
                    heroes[0].skillList.push(cfg);
                }
            }
        }
    }
}
