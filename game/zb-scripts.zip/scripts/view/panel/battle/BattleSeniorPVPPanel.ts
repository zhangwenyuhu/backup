import EManager, {EName} from './../../../manager/EventManager';
import BattlePanel from "./BattlePanel";
import stringUtils from "../../../utils/StringUtils";
import Hero from "../../../data/card/Hero";
import commonUtils from "../../../utils/CommonUtils";
import battleLogic from "../../../logics/BattleLogic";
import {BattleType} from "../../../utils/DefineUtils";
import arenaSeniorLogic from "../../../logics/ArenaSeniorLogic";
import ArenaSeniorBattlePlayer from "../../component/Arena/ArenaSeniorBattlePlayer";
import Player from "../../../data/user/Player";
import playerLogic from "../../../logics/PlayerLogic";
import gm from "../../../manager/GameManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleSeniorPVPPanel")
export default class BattleSeniorPVPPanel extends BattlePanel {

    @property(cc.Label)
    labelTime: cc.Label = null;

    @property(cc.Label)
    labelGold: cc.Label = null;

    @property(cc.Label)
    labelChest: cc.Label = null;

    @property(cc.Node)
    leftPlayer: cc.Node = null;

    @property(cc.Node)
    rightPlayer: cc.Node = null;

    @property(cc.Label)
    title: cc.Label = null;

    @property(cc.Node)
    turnNode: cc.Node = null;

    @property(cc.Node)
    turn1: cc.Node = null;

    @property(cc.Node)
    turn2: cc.Node = null;

    @property(cc.Node)
    turn3: cc.Node = null;

    onInit(data: {
        troops: { selfTroop: Hero[], enemyTroop: Hero[] },
        sceneConfig: rpgfight.SceneConfig,
        playBack?: boolean,
        battleNo?: number,
        groupId?: number
    }) {
        super.onInit(data);
        battleLogic.initSeniorPVP(data.groupId);
    }

    start() {
        super.start();
        this._refreshPlayerTurn();
    }

    protected _refreshPlayerTurn() {
        let rivalData = arenaSeniorLogic.getRivalData();
        let player = new Player(rivalData.role);
        this.leftPlayer.getComponent(ArenaSeniorBattlePlayer).refresh(playerLogic.getPlayer());
        this.rightPlayer.getComponent(ArenaSeniorBattlePlayer).refresh(player);
    }

    getBattleType(): BattleType {
        return this.data.playBack ? BattleType.PVP_Senior_Record : BattleType.PVP_Senior;
    }

    getBgUrl(): string {
        return commonUtils.getBgUrl("arena_battle_bg");
    }

    update(dt: number) {
        super.update(dt);

        if (!this._fightNode) {
            return;
        }
        let totalTime = this._fightNode.manager.getScene().sceneData.config.time;
        let currentTime = this._fightNode.manager.clock.currentTime;
        let remainTime = Math.max(totalTime - currentTime, 0);
        remainTime = Math.floor(remainTime / 1000);
        if (remainTime <= 0) {
            this.labelTime.string = "00:00";
        } else {
            this.labelTime.string = stringUtils.formatTime(remainTime);
        }
    }

    protected async _onSelfTroopDead() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;
        arenaSeniorLogic.setBattleTurnResult(this.data.groupId, false);

        this._fightNode.finishGame(false);
        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onSelfTroopDead();
        if (this.data.playBack) {
            EManager.emit(EName.onGameExit, { type: BattleType.PVP_Senior_Record });
        } else {
            this._onGetGameResult();
        }
    }

    protected async _onEnemyTroopDead() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;
        arenaSeniorLogic.setBattleTurnResult(this.data.groupId, true);
        this._fightNode.finishGame(true);

        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onEnemyTroopDead();
        if (this.data.playBack) {
            EManager.emit(EName.onGameExit, { type: BattleType.PVP_Senior_Record });
        } else {
            this._onGetGameResult();
        }
    }

    protected async _onGameTimeout() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;
        arenaSeniorLogic.setBattleTurnResult(this.data.groupId, false);
        this._fightNode.finishGame(false);

        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onGameTimeout();
        if (this.data.playBack) {
            EManager.emit(EName.onGameExit, { type: BattleType.PVP_Senior_Record });
        } else {
            this._onGetGameResult();
        }
    }

    protected async _onGameSkip() {
        this._isGameover = true;
        this.data.groupId = 3;
        await this._onGetGameResult();
        this._fightNode.finishGame(arenaSeniorLogic.getBattleReport().isWin);
    }

    protected async _onGetGameResult() {
        if (this.data.groupId == 3) {
            this._refreshPlayerTurn();
            let battleNo = this.data.battleNo;
            //todo 结算
            try {
                await arenaSeniorLogic.doResult(battleNo);
                await arenaSeniorLogic.doPlaybackMul(battleNo);
                gcc.core.showLayer("prefabs/panel/battle/BattleSeniorPVPResultPanel");
            } catch (e) {
                if (e.name == "ToastError") {
                    gm.toast(e.message);
                    EManager.emit(EName.onGameExit, { type: BattleType.PVP_Senior });
                } else {
                    throw e;
                }
            }
        } else {
            //todo 进入下一场
            let group = this.data.groupId + 1;
            let troops = await playerLogic.getTroop(BattleType.PVP_Senior);
            gcc.core.showLayer(`prefabs/panel/battle/BattleSeniorPVP${group}Panel`, {
                data: {
                    troops: {
                        selfTroop: arenaSeniorLogic.getMyAttackTroops(troops, group),
                        enemyTroop: arenaSeniorLogic.getEnemyDefenseTroops(group)
                    },
                    sceneConfig: arenaSeniorLogic.getBattleScene(group),
                    battleNo: this.data.battleNo,
                    groupId: group
                }
            });
        }
    }
}
