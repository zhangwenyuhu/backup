import Hero from "../../../data/card/Hero";
import Npc from '../../../data/card/Npc';
import IBattleData from '../../../data/IBattleData';
import Mission from '../../../data/mission/Mission';
import Tower from '../../../data/tower/Tower';
import { WisdomCloudData, WisdomStance } from "../../../data/wisdomtree/WisdomTreeBase";
import { WonderCloudData, WonderStance } from "../../../data/wonderspace/WonderSpaceBaseData";
import battleLogic from "../../../logics/BattleLogic";
import friendMerLogic from '../../../logics/FriendMerLogic';
import guideLogic from '../../../logics/GuideLogic';
import heroLogic from "../../../logics/HeroLogic";
import playerLogic from '../../../logics/PlayerLogic';
import unionLogic from "../../../logics/UnionLogic";
import unionWarLogic from '../../../logics/UnionWarLogic';
import wisdomTreeLogic from "../../../logics/WisdomTreeLogic";
import wonderSpaceLogic from "../../../logics/WonderSpaceLogic";
import cm from '../../../manager/ConfigManager';
import EManager from '../../../manager/EventManager';
import gm from '../../../manager/GameManager';
import { BattleStanceBO } from '../../../proxy/GameProxy';
import commonUtils from '../../../utils/CommonUtils';
import { BattleType } from '../../../utils/DefineUtils';
import loadUtils from '../../../utils/LoadUtils';
import stringUtils from '../../../utils/StringUtils';
import CommonLoader from '../../common/CommonLoader';
import TabLoader from "../../common/loader/TabLoader";
import FightStation from '../../fight/FightStation';
import GuideBaseStep from '../../widget/guide/GuideBaseStep';
import StoryComponent, { StoryWhere } from '../../widget/story/StoryComponent';
import TroopPicker from '../../widget/troop/TroopPicker';
import { FullscreenPanel } from "../BasePanel";
import { stringConfigMap } from './../../../configs/stringConfig';
import { EName } from './../../../manager/EventManager';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattlePreparePanel")
export default class BattlePreparePanel extends FullscreenPanel {
    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(cc.Node)
    selfStations: cc.Node[] = [];

    @property(cc.Node)
    enemyStations: cc.Node[] = [];

    @property(cc.Node)
    stationItem: cc.Node = null;

    @property(cc.Node)
    stationBgItem: cc.Node = null;

    @property(sp.Skeleton)
    leftFlower: sp.Skeleton = null;

    @property(sp.Skeleton)
    rightFlower: sp.Skeleton = null;

    @property(TroopPicker)
    troopPicker: TroopPicker = null;

    @property(cc.Label)
    selfPower: cc.Label = null;

    @property(cc.Label)
    enemyPower: cc.Label = null;

    @property(cc.Node)
    missionInfo: cc.Node = null;

    @property(cc.Label)
    labelMission: cc.Label = null;

    @property(cc.Material)
    normalMaterial: cc.Material = null;

    @property(cc.Material)
    grayMaterial: cc.Material = null;

    @property(cc.Node)
    factionNode: cc.Node = null;

    @property(cc.Node)
    speakNode: cc.Node = null;

    @property(cc.Label)
    speakLabel: cc.Label = null;

    @property(CommonLoader)
    relationLoader: CommonLoader = null;

    protected _oldStanceProtos: BattleStanceBO[] = [];
    protected _selectHeroes: { [key: number]: Hero } = {};
    protected _battleData: IBattleData = null;
    protected _selfItems: cc.Node[] = [];
    protected _enemyItems: cc.Node[] = [];
    protected _speakStations: FightStation[] = [];
    protected _speakInterval: number = 0;
    protected _filterIndex: number = -1;
    protected _noRollback: boolean = false;

    onInit(data: IBattleData) {
        super.onInit(data);
        this._battleData = data;
    }

    onLoad() {
        super.onLoad();
        this.stationItem.parent = null;
        this.stationBgItem.parent = null;
        if (this.speakNode) {
            this.speakNode.active = false;
        }
        this.registerEvents();
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onFightStationMoved, (station: FightStation) => {
            this._onFightStationMoved(station);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onFightStationChanged, (station: FightStation) => {
            this._onFightStationChanged(station);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onFightStationClick, (station: FightStation) => {
            this._onFightStationClick(station);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onUpdateTroopHero, () => {
            this.updateSelfStations();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onUpdateTroops, () => {
            this.updateHeroListByFaction(this._filterIndex, true);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType }) => {
            if (data.type == BattleType.Record || data.type == BattleType.PVP_PlayBack)
                return;
            this._noRollback = true;
            this.closePanel();
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onTouch, () => {
            if (this.speakNode && this.speakNode.active) {
                this.speakNode.stopAllActions();
                this.speakNode.scale = 0;
            }
        });
        this._eventListeners.push(listener);
    }

    async start() {
        super.start();

        this.createAllStations();

        if (this._battleData.getBattleType() == BattleType.PVE) {
            this.missionInfo.active = true;

            let mission = this._battleData as Mission;
            this.labelMission.string = stringUtils.getString(stringConfigMap.key_current_mission.Value, { house: mission.getBuildingId(), level: mission.getId() });

            let comp = this.addComponent(StoryComponent);
            comp.init(mission.getStageId(), StoryWhere.BattlePrepare);
            comp.startStory();
        }
        else {
            this.missionInfo.active = false;
        }

        let faction = this.isRaceTower() ? this.getRace() : Hero.Faction.All;
        this._challengeLimit(faction);

        this.updateAllStations();

        if (friendMerLogic.needMercHero(this._battleData.getBattleType())) {
            if (friendMerLogic.needReqMercHero()) {
                await friendMerLogic.mercHerosReq();
            }
            friendMerLogic.currentPreparFightType = this._battleData.getBattleType();
        }

        this.updateHeroListByFaction(faction);
        this.initFilterUI();
    }

    update(dt: number) {
        if (this.speakNode && this.speakNode.active && this.speakNode.getNumberOfRunningActions() == 0) {
            if (this._speakInterval == 0) {
                let station = this._speakStations[Math.floor(Math.random() * this._speakStations.length)];
                this._onFightStationClick(station);
            }
            else {
                this._speakInterval = Math.max(0, this._speakInterval - dt);
            }
        }
    }

    createAllStations() {
        for (let i = 0; i < this.selfStations.length; i++) {
            let station = this.selfStations[i];

            let item = cc.instantiate(this.stationBgItem);
            item.parent = station;
            let labelNode = item.getChildByName("label");
            let label = labelNode.getComponent(cc.Label);
            label.string = `${i + 1}`;

            item = cc.instantiate(this.stationItem);
            let comp = item.getComponent(FightStation);
            comp.init(label, i + 1, true, (skeletonData: sp.SkeletonData) => {
                this._releaseSkeletonData(skeletonData);
            });
            item.parent = station;
            this._selfItems.push(item);
        }

        for (let i = 0; i < this.enemyStations.length; i++) {
            let station = this.enemyStations[i];

            let item = cc.instantiate(this.stationBgItem);
            item.parent = station;
            let labelNode = item.getChildByName("label");
            let label = labelNode.getComponent(cc.Label);
            label.string = `${i + 1}`;

            item = cc.instantiate(this.stationItem);
            let comp = item.getComponent(FightStation);
            comp.init(label, i + 1, false);
            item.parent = station;
            this._enemyItems.push(item);
        }
    }

    updateAllStations() {
        this.updateSelfStations();
        this.updateEnemyStations();
    }

    updateSelfStations(isMoved: boolean = false) {
        for (let i = 0; i < this._selfItems.length; i++) {
            let comp = this._selfItems[i].getComponent(FightStation);
            comp.updateView(this._selectHeroes[i + 1], isMoved);
        }

        let troops = this.getTroops();
        battleLogic.init(troops, gm);

        this.relationLoader.node.active = false;
        // let relation = this.relationLoader.loaderNode.getComponent(BattleRelation);
        // relation.refresh();

        this.leftFlower.node.parent.active = false;
        // this.leftFlower.animation = battleLogic.getFlowerAnimation(true);

        let power = 0;
        for (let hero of troops.selfTroop) {
            if (hero) power += hero.getPower();
        }
        this.selfPower.string = slib.BigNumberHelper.convertNumStr2UnitStr(power.toString());
    }

    updateEnemyStations() {
        let monsters = this._battleData.getMonsters();
        for (let i = 0; i < this._enemyItems.length; i++) {
            let monster = monsters[i];
            let comp = this._enemyItems[i].getComponent(FightStation);
            comp.updateView(monster);

            if (this._battleData.getBattleType() == BattleType.PVE) {
                if (monster && monster.getRank() > 1 && monster.getHeroTypeDesc()) {
                    this._speakStations.push(comp);
                }
            }
        }

        this.rightFlower.node.parent.active = false;
        // this.rightFlower.animation = battleLogic.getFlowerAnimation(false);

        let power = 0;
        for (let monster of monsters) {
            if (monster) power += monster.getPower();
        }
        this.enemyPower.string = slib.BigNumberHelper.convertNumStr2UnitStr(power.toString());

        if (this.speakNode && this._speakStations.length > 0) {
            this.speakNode.active = true;
            this.speakNode.scale = 0;
            this._speakInterval = 0;
        }
    }

    updateHeroListByFaction(faction: number, force: boolean = false): boolean {
        if (this._filterIndex == faction && !force) {
            return false;
        }
        this._filterIndex = faction;

        let heroes: Hero[] = [];
        let merHeros: Hero[] = [];
        if (faction == Hero.Faction.All) {
            heroes = heroLogic.getHeroes({ sort: true });
            merHeros = friendMerLogic.getBorrowedHeros();
        }
        else {
            heroes = heroLogic.getHeroes({
                filter: (hero: Hero) => { return hero.getFaction() == faction; },
                sort: true
            });
            merHeros = friendMerLogic.getBorrowedHeros((hero: Hero) => { return hero.getFaction() == faction; });
        }
        if (friendMerLogic.needMercHero(this._battleData.getBattleType())) {
            let len = merHeros.length;
            for (let i = 0; i < len; i++) {
                heroes.unshift(merHeros[i]);
            }
        }

        if (this._battleData.getBattleType() == BattleType.Maze || this._battleData.getBattleType() == BattleType.WonderSpace) {
            let wisdomPubHero = null;
            if (this._battleData.getBattleType() == BattleType.Maze) {
                wisdomPubHero = wisdomTreeLogic.wisdomPubHero;
            } else {
                wisdomPubHero = wonderSpaceLogic.wonderPubHero;
            }
            if (wisdomPubHero.length > 0) {
                for (let hero of wisdomPubHero) {
                    if (hero.hp > 0) {
                        heroes.unshift(new Hero(hero.heroVO));
                    }
                }
            }
            heroLogic.sortHeroes(heroes, { sortPower: true });
            if (this._battleData.getBattleType() == BattleType.Maze) {
                this.troopPicker.setReviveType(1);
                this.troopPicker.setDeadHeroes(battleLogic.getMazeDeadTroops(heroes));
                this.troopPicker.setWisdomTree(true);
            } else {
                this.troopPicker.setReviveType(2);
                this.troopPicker.setDeadHeroes(battleLogic.getWonderDeadTroops(heroes));
                this.troopPicker.setWisdomTree(false);
            }
        }

        if (this.isRaceTower()) {
            heroes = heroes.filter((v, i, a) => { return v.getFaction() == this.getRace(); })
        }
        this.troopPicker.init(this._battleData);
        this.troopPicker.updateTroop(heroes, this._selectHeroes);
        this.updateSelfStations();

        return true;
    }

    getTroops(): { selfTroop: Hero[], enemyTroop: Hero[] } {
        let selfTroop: Hero[] = [];
        for (let i = 0; i < playerLogic.getMaxInstanceTroopCount(); i++) {
            selfTroop.push(this._selectHeroes[i + 1]);
        }
        let enemyTroop: Hero[] = this._battleData.getMonsters();

        return {
            selfTroop: selfTroop,
            enemyTroop: enemyTroop
        }
    }

    async updateTroop() {
        if (this._battleData.getBattleType() == BattleType.Friend) {
            await playerLogic.doUpdateMainTroop(this._selectHeroes);
        }
        else {
            let race: number = 0;
            if (this.isRaceTower()) { race = this.getRace(); }
            await playerLogic.doUpdateTroop(this._selectHeroes, this._battleData.getBattleType(), this._battleData.getTroopExpire(), race);
        }
    }

    async onFight() {
        console.log("BattlePreparePanel onFight");

        try {
            await this.updateTroop();
            await gm.showBattleIndicator();

            let panel = "BattleSharePanel";
            if (this._battleData.getBattleType() == BattleType.Hunt) {
                await unionLogic.doCheckHunt(unionLogic.unionHuntMonsterType);
                panel = "BattleHuntPanel";
            } else if (this._battleData.getBattleType() == BattleType.Maze || this._battleData.getBattleType() == BattleType.WonderSpace) {
                let stance = {};
                for (let i = 1; i <= playerLogic.getMaxInstanceTroopCount(); i++) {
                    if (this._selectHeroes[i] && !(this._selectHeroes[i] instanceof Npc)) {
                        stance[i - 1] = this._selectHeroes[i].getId();
                    }
                    else {
                        stance[i - 1] = null;
                    }
                }
                if (this._battleData.getBattleType() == BattleType.Maze) {
                    let wisdomStance = new WisdomStance();
                    wisdomStance.stance = stance;
                    wisdomTreeLogic.wisdomStance = wisdomStance;
                    wisdomTreeLogic.setWisdomTreeDirty([WisdomCloudData.Stance])
                    panel = "BattleWisdomPanel";
                } else {
                    let wonderStance = new WonderStance();
                    wonderStance.stance = stance;
                    wonderSpaceLogic.wonderStance = wonderStance;
                    wonderSpaceLogic.setWonderSpaceDirty([WonderCloudData.Stance]);
                    panel = "BattleWonderPanel";
                }
            } else if (this._battleData.getBattleType() == BattleType.Treasure) {
                panel = "BattleRaiderPanel";
            } else if (this._battleData.getBattleType() == BattleType.WorldBoss) {
                panel = "BattleWorldBossPanel";
            } else if (this._battleData.getBattleType() == BattleType.Clone) {
                panel = "BattleClonePanel";
            } else if (this._battleData.getBattleType() == BattleType.UnionWar) {
                await unionWarLogic.doBattleStart(this._battleData);
            }

            let sceneConfig = new rpgfight.SceneConfig();
            sceneConfig.width = cc.director.getWinSize().width;
            sceneConfig.height = 750;
            sceneConfig.time = this._battleData.getTime() * 1000;
            if (GuideBaseStep.isGuiding) {
                sceneConfig.seed = 0;
            }
            else {
                sceneConfig.seed = gm.getCurrentTimestamp();
                if (this._battleData.getBattleType() == BattleType.PVE) {
                    let mission = this._battleData as Mission;
                    if (mission.getStageId() == guideLogic.leishenStageId
                        || mission.getStageId() == guideLogic.artifactStageId
                        || mission.getStageId() == guideLogic.banzangStageId) {
                        sceneConfig.seed = 0;
                    }
                }
            }

            gcc.core.showLayer(`prefabs/panel/battle/${panel}`, {
                data: {
                    battleData: this._battleData,
                    troops: this.getTroops(),
                    sceneConfig: sceneConfig
                },
                callback: () => { gm.hideBattleIndicator(); }
            });

        } catch (e) {
            gm.hideBattleIndicator();
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    isRaceTower(): boolean {
        let raceTower: boolean = false;
        if (this._battleData instanceof Tower) {
            return this._battleData.getRaceType() > 0;
        }
        return raceTower;
    }
    getRace(): number {
        let raceTower = this._battleData as Tower;
        return raceTower.getRaceType();
    }
    // 种族塔时 种族选择界面
    initFilterUI() {
        if (this.isRaceTower()) {
            let raceTower = this._battleData as Tower;
            let race: number = raceTower.getRaceType();
            let filterNode = this.troopPicker.node.parent.getChildByName("faction_bg");
            if (filterNode) {
                for (let i = 0; i < filterNode.children.length; i++) {
                    if (race == i + 1) {
                        // 选中该种族tab
                        let btn = filterNode.children[i].getComponent(cc.Button);
                        btn.clickEvents[0].emit([]);
                        continue;
                    } else {
                        // 其他阵营tab变灰
                        filterNode.children[i].getComponent(cc.Button).interactable = false;
                        let sprites = filterNode.children[i].getComponentsInChildren(cc.Sprite);
                        for (let j = 0; j < sprites.length; j++) {
                            sprites[j].setMaterial(0, this.grayMaterial);
                        }
                    }
                }
            }
        }
    }

    onFilter(e: cc.Event.EventTouch, faction: string) {
        if (this.isRaceTower()) {
            if (this.getRace() != parseInt(faction)) {
                gm.toast(stringConfigMap[`key_faction_filter_${this.getRace()}`].Value);
            }
            return;
        }
        if (this.updateHeroListByFaction(Number(faction))) {
            //gm.toast(stringConfigMap[`key_faction_filter_${faction}`].Value);
        }
    }

    onLeftRelationship() {
        gcc.core.showLayer("prefabs/panel/battle/BattleRelationPanel", {
            data: true,
            modalTouch: true
        });
    }

    onRightRelationship() {
        gcc.core.showLayer("prefabs/panel/battle/BattleRelationPanel", {
            data: false,
            modalTouch: true
        });
    }

    onRestraint() {
        gcc.core.showLayer("prefabs/panel/battle/BattleRestraintPanel", {
            modalTouch: true
        });
    }

    async onHeroFlyIn(step: GuideBaseStep) {
        step.delay = 1;

        let station = this._selfItems[0].getComponent(FightStation);
        station.skeleton.node.opacity = 0;

        let node = new cc.Node("chaoren");
        node.position = station.skeleton.node.position;
        node.parent = station.skeleton.node.parent;
        let skeleton = node.addComponent(sp.Skeleton);
        let heroUrl = commonUtils.getHeroSpineUrl(station.getHero().getSpineFile()) + "_yinqindonhua";
        let skeletonData = await loadUtils.loadRes(heroUrl, sp.SkeletonData) as sp.SkeletonData;
        if (!cc.isValid(this.node)) return;
        skeleton.skeletonData = skeletonData;
        skeleton.animation = 'ruchang';
        skeleton.loop = false;
        skeleton.setCompleteListener(() => {
            node.destroy();
            loadUtils.releaseAssetRecursively(skeletonData);
            station.skeleton.node.opacity = 0xff;
        });
    }

    protected _challengeLimit(faction: number) {
        if (this._battleData.getBattleType() == BattleType.WonderSpace && wonderSpaceLogic.wonderSpaceGuard) {
            let challengeFaction = wonderSpaceLogic.wonderSpaceGuard.challengeFaction;
            if (challengeFaction.length > 0) {
                let disableList = [];
                for (let i = 0; i < Hero.Faction.Num; i++) {
                    if (!challengeFaction.find(a => a == i)) {
                        disableList.push(i);
                    }
                }
                if (disableList.length > 0) {
                    this._selectHeroes = {};
                    faction = challengeFaction[0];
                    this.factionNode.getComponent(TabLoader).setTabDisable(disableList);
                    this.factionNode.getComponent(TabLoader).switchTab(faction);
                }
            }
        }
    }

    get lastFightStationNo(): number {
        if (this._lastFightStation) {
            return this._lastFightStation.stationNumber;
        }
        return 0;
    }

    get isHeroSelected(): boolean {
        let heroes = Object.values(this._selectHeroes);
        let hasHero = false;
        for (let hero of heroes) {
            if (hero && !(hero instanceof Npc)) {
                hasHero = true;
                break;
            }
        }
        return hasHero;
    }

    protected _lastFightStation: FightStation = null;
    protected _onFightStationMoved(station: FightStation) {
        for (let item of this._selfItems) {
            let comp = item.getComponent(FightStation);
            let hero = comp.getHero();
            if (hero && hero instanceof Npc) {
                continue;
            }

            if (comp != station && comp != this._lastFightStation) {
                let position = station.moveArea.convertToWorldSpaceAR(cc.v2());
                position = comp.moveArea.convertToNodeSpace(position);
                let rect = cc.rect(0, 0, comp.moveArea.width, comp.moveArea.height);
                if (rect.contains(position)) {
                    if (this._lastFightStation) {
                        this._lastFightStation.resetMoveArea();
                    }
                    this._lastFightStation = comp;
                    station.setPositionForStation(comp);
                    break;
                }
            }
        }
    }

    protected _onFightStationChanged(station: FightStation) {
        if (this._lastFightStation) {
            this._lastFightStation.resetMoveArea();
            this._changeStation(station);
        }
    }

    protected _onFightStationClick(station: FightStation) {
        if (!this.speakNode || !this.speakNode.active) return;

        let stations = this._speakStations.filter(s => s == station);
        if (stations.length == 0) return;

        this._speakInterval = cm.heroConversationTime[1] + 0.5;

        let worldPosition = station.node.convertToWorldSpaceAR(cc.v2(0, 140));
        this.speakNode.position = this.node.convertToNodeSpaceAR(worldPosition);
        this.speakNode.getComponent(cc.Animation).play("bubble_in");
        this.speakLabel.string = station.getHero().getHeroTypeDesc();
        (this.speakLabel as any)._updateRenderData(true);
        if (this.speakLabel.node.height > 50) {
            this.speakLabel.horizontalAlign = cc.Label.HorizontalAlign.LEFT;
        }
        else {
            this.speakLabel.horizontalAlign = cc.Label.HorizontalAlign.CENTER;
        }

        this.speakNode.stopAllActions();
        this.speakNode.runAction(cc.sequence(
            cc.delayTime(cm.heroConversationTime[0] + 0.5),
            cc.callFunc(() => { this.speakNode.getComponent(cc.Animation).play("bubble_out"); }, this)))
    }

    protected _changeStation(station: FightStation) {
        if (station.getHero()) {
            this._selectHeroes[this._lastFightStation.stationNumber] = station.getHero();
        }
        else {
            delete this._selectHeroes[this._lastFightStation.stationNumber];
        }
        if (this._lastFightStation.getHero()) {
            this._selectHeroes[station.stationNumber] = this._lastFightStation.getHero();
        }
        else {
            delete this._selectHeroes[station.stationNumber];
        }
        this._lastFightStation = null;
        this.updateSelfStations(true);
    }

    protected _releaseSkeletonData(skeletonData: sp.SkeletonData) {
        if (!skeletonData) return;

        for (let item of this._selfItems) {
            let station = item.getComponent(FightStation);
            if (station.skeleton.skeletonData == skeletonData) {
                return;
            }
        }
        loadUtils.releaseAssetRecursively(skeletonData);
    }

    protected async _getTroop(): Promise<Hero[]> {
        let troop: Hero[] = [];
        if (this._battleData.getBattleType() == BattleType.Friend) {
            troop = playerLogic.getPlayer().getMainTroop();
        }
        else {
            let race: number = 0;
            if (this.isRaceTower()) { race = this.getRace(); }
            troop = await playerLogic.getTroop(this._battleData.getBattleType(), race,
                this._battleData.getBattleType() == BattleType.UnionWar);
        }
        return troop;
    }

    protected async _preloadRes() {
        await super._preloadRes();
        await this._preloadData();

        let url = "";
        if (this._battleData.getBattleType() == BattleType.PVE) {
            let mission = this._battleData as Mission;
            url = commonUtils.getBattleBgUrl(BattleType.PVE, mission.config.Battlebg)
        }
        else {
            url = commonUtils.getBattleBgUrl(this._battleData.getBattleType());
        }
        let spriteFrame = await loadUtils.loadRes(url, cc.SpriteFrame) as cc.SpriteFrame;
        this._unloadInfos.push({ url: url, type: cc.SpriteFrame });
        if (!cc.isValid(this.bg)) return;

        this.bg.spriteFrame = spriteFrame;
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);
        this._unloadSpine();

        if (this._battleData.getBattleType() == BattleType.PVE) {
            let mission = this._battleData as Mission;
            if ((mission.getStageId() == guideLogic.artifactStageId
                || mission.getStageId() == guideLogic.banzangStageId) && !this._noRollback) {
                guideLogic.guideId = guideLogic.recordId;
            }
        }
    }

    protected async _preloadData() {
        let npcs = this._battleData.getNpcs();
        let troop = await this._getTroop();

        for (let i = 0; i < troop.length; i++) {
            if (npcs[i + 1]) {
                this._selectHeroes[i + 1] = npcs[i + 1];
            }
            else {
                if (troop[i]) { this._selectHeroes[i + 1] = troop[i]; }
            }
        }

        for (let key in this._selectHeroes) {
            let hero = this._selectHeroes[key];
            let heroIds = this._battleData ? this._battleData.getUntroopHeroIds() : null;
            if (heroIds && heroIds.has(hero.getId())) {
                this._selectHeroes[key] = null;
            }
        }

        if (this._battleData.getBattleType() == BattleType.PVE) {
            let step = guideLogic.currentStep;
            if (step) {
                if (step.ID == 1002) {
                    if (this._selectHeroes[2]) {
                        delete this._selectHeroes[2];
                    }
                    if (this._selectHeroes[3]) {
                        delete this._selectHeroes[3];
                    }
                }
                else if (step.ID == 1013) {
                    if (this._selectHeroes[1]) {
                        this._selectHeroes[3] = this._selectHeroes[1];
                        delete this._selectHeroes[1];
                    }
                }
            }

            let mission = this._battleData as Mission;
            if (mission.getStageId() == guideLogic.artifactStageId) {
                guideLogic.guideId = 130001;
            }
            else if (mission.getStageId() == guideLogic.banzangStageId) {
                guideLogic.guideId = 200001;
                this._selectHeroes = {};
                this._selectHeroes[1] = new Npc(20054, 240, 11);
            }
        }
        else if (this._battleData.getBattleType() == BattleType.Maze) {
            battleLogic.initMazeTroops(this._selectHeroes);
        } else if (this._battleData.getBattleType() == BattleType.WonderSpace) {
            battleLogic.initWonderTroops(this._selectHeroes);
        }
    }

    protected async _preloadSpine() {
        for (let key in this._selectHeroes) {
            let hero = this._selectHeroes[key];
            await loadUtils.loadRes(commonUtils.getHeroSpineUrl(hero.getSpineFile()), sp.SkeletonData);
        }

        let monsters = this._battleData.getMonsters();
        for (let monster of monsters) {
            if (monster) {
                await loadUtils.loadRes(commonUtils.getHeroSpineUrl(monster.getSpineFile()), sp.SkeletonData);
            }
        }
    }

    protected _unloadSpine() {
        let troop = this.getTroops();
        if (this._battleData.getBattleType() != BattleType.PVE) {
            for (let hero of troop.selfTroop) {
                if (!hero) continue;
                let skeletonData = cc.loader.getRes(commonUtils.getHeroSpineUrl(hero.getSpineFile()), sp.SkeletonData) as sp.SkeletonData;
                loadUtils.releaseAssetRecursively(skeletonData);
            }
        }
        for (let hero of troop.enemyTroop) {
            if (!hero) continue;
            let skeletonData = cc.loader.getRes(commonUtils.getHeroSpineUrl(hero.getSpineFile()), sp.SkeletonData) as sp.SkeletonData;
            if (skeletonData) { skeletonData.unlock(); }
            loadUtils.releaseAssetRecursively(skeletonData);
        }
    }
}
