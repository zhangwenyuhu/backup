import { BattleType, Storage } from './../../../utils/DefineUtils';
import { stringConfigMap } from './../../../configs/stringConfig';
import { EListener, EName } from './../../../manager/EventManager';
import FightRoot from "../../fight/FightRoot";
import Hero from "../../../data/card/Hero";
import battleLogic from "../../../logics/BattleLogic";
import CommonLoader from "../../common/CommonLoader";
import FightSkill from "../../fight/FightSkill";
import EManager from "../../../manager/EventManager";
import gm from '../../../manager/GameManager';
import { SharedHeroEffectView } from '../../fight/SharedHeroEffectView';
import giftLogic from '../../../logics/GiftLogic';
import VipUnlockWrapper from '../../widget/unlock/VipUnlockWrapper';
import storageUtils from '../../../utils/StorageUtils';
import UnlockWrapper from '../../widget/unlock/UnlockWrapper';
import { unlockConfigMap } from '../../../configs/unlockConfig';
import GuideBaseStep from '../../widget/guide/GuideBaseStep';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleUIPanel")
export default class BattleUIPanel extends cc.Component {

    @property(cc.Node)
    btnPause: cc.Node = null;

    @property(cc.Node)
    btnAuto: cc.Node = null;

    @property(cc.Node)
    btnSkip: cc.Node = null;

    @property(cc.Node)
    btnSkipAdv: cc.Node = null;

    @property(cc.Sprite)
    btn2x: cc.Sprite = null;

    @property(cc.Node)
    finger: cc.Node = null;

    @property(sp.Skeleton)
    leftFlower: sp.Skeleton = null;

    @property(sp.Skeleton)
    rightFlower: sp.Skeleton = null;

    @property(cc.Node)
    skillCardList: cc.Node = null;

    @property(cc.Node)
    skillCard: cc.Node = null;

    @property(cc.Node)
    mask: cc.Node = null;

    @property(cc.SpriteFrame)
    btnSpeedX2Frames: cc.SpriteFrame[] = [];

    @property(cc.SpriteFrame)
    btnAutoFrames: cc.SpriteFrame[] = [];

    protected _closeupSet: Set<cc.Node> = new Set<cc.Node>();
    protected _highlightSet: Set<cc.Node> = new Set<cc.Node>();

    protected _fightRoot: FightRoot = null;
    protected _selfTroop: Hero[] = [];
    protected _enemyTroop: Hero[] = [];
    protected _eventListeners: EListener[] = [];
    protected _battleType: BattleType = BattleType.PVE;
    protected _fightRootMask: cc.Node = null;

    init(battleType: BattleType) {
        this._battleType = battleType;
        if (this._battleType == BattleType.PVP || this._battleType == BattleType.PVP_Senior) {
            this.btnAuto.active = false;
            this.btnPause.active = false;
            this.btnSkip.active = this._battleType == BattleType.PVP;
            if (this.btnSkipAdv) {
                this.btnSkipAdv.active = this._battleType == BattleType.PVP_Senior;
            }
            this.btnSkip.getComponent(VipUnlockWrapper).lockTip = "跳过战斗功能VIP6解锁";
        }
        else if (this._battleType == BattleType.PVP_PlayBack || this._battleType == BattleType.Record || this._battleType == BattleType.PVP_Senior_Record) {
            this.btnAuto.active = false;
            this.btnPause.active = true;
        }
        else if (this._battleType == BattleType.Dungeon) {
            this.btnPause.active = false;
        }
        else if (this._battleType == BattleType.Maze
            || this._battleType == BattleType.Tower
            || this._battleType == BattleType.WonderSpace) {
            if (giftLogic.isBuyNormalMonthCard() || giftLogic.isBuySuperMonthCard()) {
                let wrapper = this.btnSkip.getComponent(VipUnlockWrapper);
                wrapper.enabled = false;

                this.btnSkip.active = true;

                let widget = this.btnSkip.getComponent(cc.Widget);
                widget.right += 82;
                widget.updateAlignment();

                let btnSkip = this.btnSkip.getComponent(cc.Button);
                btnSkip.interactable = false;
            }
        }
        else if (this._battleType == BattleType.Clone) {
            this.btnPause.active = false;
            this.btnSkip.active = false;
        }
        else if (this._battleType == BattleType.UnionWar) {
            this.btnPause.active = false;
        }

        battleLogic.battleType = battleType;

        let heroes = battleLogic.getTroop(true);
        for (let hero of heroes) {
            if (!hero) continue;

            let item = cc.instantiate(this.skillCard);
            item.parent = this.skillCardList;

            let loader = item.getComponent(CommonLoader);
            let skill = loader.loaderNode.getComponent(FightSkill);
            skill.init(hero, this._battleType);
        }

        this._updateAutoSkill();
        this._updateSpeedX2();

        if (this._battleType === BattleType.PVE) {
            let wrapper = this.btn2x.getComponent(VipUnlockWrapper);
            if (!storageUtils.getBoolean(Storage.GuideSpeedX2)
                && wrapper.unlock && !battleLogic.isSpeedX2) {
                this.finger.active = true;
                storageUtils.setBoolean(Storage.GuideSpeedX2.Key, true, true);
            }
        }
    }

    onLoad() {
        this.node.setContentSize(cc.director.getWinSize());
        this.skillCard.parent = null;
        this.mask.active = false;

        let listener = EManager.addEvent(EName.onEnterHeroCloseUp, (data: { hero: rpgfight.Hero, root: cc.Node }) => {
            if (data.hero.manager.battleType != this._battleType) return;
            this._showMask(data.root);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onLeaveHeroCloseUp, (data: { hero: rpgfight.Hero, root: cc.Node }) => {
            if (data.hero.manager.battleType != this._battleType) return;
            this._hideMask(data.root);
        });
        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onHighlight, (data: { hero: rpgfight.Hero, root: cc.Node }) => {
            if (data.hero.manager.battleType != this._battleType) return;
            this._highlight(data.root);
        })
        this._eventListeners.push(listener);
    }

    onDestroy() {
        for (let listener of this._eventListeners) {
            EManager.removeEvent(listener);
        }
        this._eventListeners = [];
    }

    start() {
        this.leftFlower.node.parent.active = false;
        this.rightFlower.node.parent.active = false;
        // this.leftFlower.animation = battleLogic.getFlowerAnimation(true);
        // this.rightFlower.animation = battleLogic.getFlowerAnimation(false);
    }

    update(dt: number) {
        if (!this._fightRoot) {
            return;
        }

        if (this._battleType == BattleType.Maze
            || this._battleType == BattleType.Tower
            || this._battleType == BattleType.WonderSpace) {
            if (this.btnSkip.active) {
                let button = this.btnSkip.getComponent(cc.Button);
                if (!button.interactable) {
                    let currentTime = this._fightRoot.manager.clock.currentTime;
                    if (currentTime > 3 * 1000) {
                        button.interactable = true;
                    }
                }
            }
        }
        else if (this._battleType == BattleType.PVE) {
            if (this.finger.active && (GuideBaseStep.isGuiding || this._fightRoot.manager.gameState != rpgfight.GameState.running)) {
                this.finger.active = false;
            }
        }
    }

    set fightRoot(comp: FightRoot) {
        this._fightRoot = comp;

        let worldPoint = this._fightRoot.node.parent.convertToWorldSpaceAR(this._fightRoot.node.position);
        let localPoint = this.mask.convertToNodeSpaceAR(worldPoint);

        let node = new cc.Node(this._fightRoot.node.name);
        node.position = localPoint;
        node.parent = this.mask;
        this._fightRootMask = node;
    }

    get fightRoot(): FightRoot {
        return this._fightRoot;
    }

    onLeftRelationship() {
        gcc.core.showLayer("prefabs/panel/battle/BattleRelationPanel", {
            data: true,
            modalTouch: true
        });
    }

    onRightRelationship() {
        gcc.core.showLayer("prefabs/panel/battle/BattleRelationPanel", {
            data: false,
            modalTouch: true
        });
    }

    onPause() {
        EManager.emit(EName.onTryGamePause, { type: this._battleType });
    }

    onToggleAuto() {
        battleLogic.isAutoSkill = !battleLogic.isAutoSkill;
        this._updateAutoSkill();
        if (battleLogic.isAutoSkill) {
            gm.toast(stringConfigMap.key_auto_skill_tip.Value);
        }
    }

    onToggle2X() {
        if (!this.unlockSpeed2x()) { return; }
        battleLogic.isSpeedX2 = !battleLogic.isSpeedX2;
        this._updateSpeedX2();
        if (battleLogic.isSpeedX2) {
            gm.toast(stringConfigMap.key_speed_x2.Value);
            this.finger.active = false;
        }
        else {
            gm.toast(stringConfigMap.key_speed_x1.Value);
        }
    }
    protected unlockSpeed2x(): boolean {
        let unlock = UnlockWrapper.isUnlock(unlockConfigMap.战斗加速);
        return unlock;
    }

    onSkip() {
        EManager.emit(EName.onGameSkip, { type: this._battleType });
    }

    clearMask() {
        this._closeupSet.clear();
        this._highlightSet.clear();
        for (let child of this.mask.children) {
            if (child.name != 'mask') {
                child.destroy();
            }
        }
        this.mask.active = false;
    }

    protected _updateAutoSkill() {
        if (this.btnAuto.active) {
            let sprite = this.btnAuto.getComponent(cc.Sprite);
            sprite.spriteFrame = this.btnAutoFrames[battleLogic.isAutoSkill ? 0 : 1];
            EManager.emit(EName.onGameSkillAuto, { type: this._battleType, isAuto: battleLogic.isAutoSkill });
        }
    }

    protected _updateSpeedX2() {
        let sprite = this.btn2x.getComponent(cc.Sprite);
        sprite.spriteFrame = this.btnSpeedX2Frames[battleLogic.isSpeedX2 ? 0 : 1];
        EManager.emit(EName.onGameSpeedX2, { type: this._battleType, isSpeedX2: battleLogic.isSpeedX2 });
    }

    protected _showMask(node: cc.Node) {
        if (this._closeupSet.has(node)) return;
        if (this._highlightSet.has(node)) {
            this._closeupSet.add(node);
            this._highlightSet.delete(node);
            return;
        }
        this._closeupSet.add(node);

        if (!this.mask.active) {
            let factory = this.fightRoot.manager.viewFactory;
            let effectView = factory.getSharedEffectView() as SharedHeroEffectView;
            effectView.root.parent = this._fightRootMask;
        }
        this.mask.active = true;
        node.parent = this._fightRootMask;
    }

    protected _hideMask(node: cc.Node) {
        if (!this._closeupSet.has(node)) return;
        node.parent = this._fightRoot.node;
        this._closeupSet.delete(node);

        if (this._closeupSet.size == 0) {
            let nodes = Array.from(this._highlightSet);
            for (let node of nodes) {
                node.parent = this._fightRoot.node;
            }
            this._highlightSet.clear();
            this.mask.active = false;

            let factory = this.fightRoot.manager.viewFactory;
            let effectView = factory.getSharedEffectView() as SharedHeroEffectView;
            effectView.root.parent = this._fightRoot.node;
        }
    }

    protected _highlight(node: cc.Node) {
        if (!this.mask.active) return;
        if (this._highlightSet.has(node)) return;
        this._highlightSet.add(node);

        node.parent = this._fightRootMask;
    }
}
