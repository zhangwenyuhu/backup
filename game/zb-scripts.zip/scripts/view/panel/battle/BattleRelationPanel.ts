import propertyConfig, { propertyConfigMap } from './../../../configs/propertyConfig';
import { FactionRelation } from './../../../logics/BattleLogic';
import { EName } from './../../../manager/EventManager';
import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from './../BasePanel'
import stringUtils from '../../../utils/StringUtils';
import battleLogic from '../../../logics/BattleLogic';
import EManager from '../../../manager/EventManager';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleRelationPanel")
export default class BattleRelationPanel extends PopupPanel {
    @property(cc.Node)
    relationList: cc.Node = null;

    @property(cc.Node)
    relationItem1: cc.Node = null;

    @property(cc.Node)
    relationItem2: cc.Node = null;

    @property(cc.Node)
    relationItem3: cc.Node = null;

    @property(cc.Node)
    gainItem1: cc.Node = null;

    @property(cc.Node)
    gainItem2: cc.Node = null;

    @property(cc.SpriteFrame)
    relationIconFrames: cc.SpriteFrame[] = [];

    @property(cc.Color)
    highlightColor1: cc.Color = cc.Color.WHITE;

    @property(cc.Color)
    highlightColor2: cc.Color = cc.Color.WHITE;

    @property(cc.Material)
    grayMaterial: cc.Material = null;

    @property(cc.Material)
    normalMaterial: cc.Material = null;

    protected _isSelf: boolean = false;

    onInit(isSelf: boolean) {
        super.onInit(isSelf);
        this._isSelf = isSelf;
    }

    onLoad() {
        super.onLoad();

        this.relationItem1.parent = null;
        this.gainItem1.parent = null;
        this.relationItem2.parent = null;
        this.gainItem2.parent = null;
        this.relationItem3.parent = null

        this.registerEvents();
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onGameOver, () => {
            this.closePanel();
        });
        this._eventListeners.push(listener);
    }

    start() {
        super.start();

        let useSuperRelation = false;
        let relations = battleLogic.getFactionRelations(this._isSelf);
        let relations1: FactionRelation[] = [];
        let relations2: FactionRelation[] = [];
        for (let relation of relations) {
            if (relation.getId() <= 4 || relation.getId() == 10) {
                relations1.push(relation);
            }
            else {
                relations2.push(relation);
            }
        }

        for (let i = 0; i < relations1.length; i++) {
            let relation = relations1[i];
            let item = cc.instantiate(this.relationItem1);
            item.parent = this.relationList;

            let isSatisfy = relation.isSatisfy();
            let icon = cc.find("icon", item);
            let sprite = icon.getComponent(cc.Sprite);
            sprite.spriteFrame = this.relationIconFrames[i];
            sprite.setMaterial(0, isSatisfy ? this.normalMaterial : this.grayMaterial);

            let desc = cc.find("content/labelDesc", item);
            let labelDesc = desc.getComponent(cc.Label);
            labelDesc.string = relation.getDesc();
            if (relation.isSatisfy()) {
                labelDesc.node.color = this.highlightColor1;
                useSuperRelation = relation.isUseSuperRelation();
            }

            let gainList1 = cc.find("content/property_item", item);
            let gains = relation.getGains();
            for (let gain of gains) {
                let gainItem = cc.instantiate(this.gainItem1);
                gainItem.parent = gainList1;
                let label = gainItem.getComponent(cc.Label);
                if (gain.config == propertyConfigMap.施法迅捷) {
                    label.string = `${gain.config.ProName}: +${gain.value}`
                }
                else {
                    label.string = `${gain.config.ProName}: +${Math.floor(gain.value * 100)}%`;
                }
                if (relation.isSatisfy()) label.node.color = this.highlightColor2;
            }
        }

        this.relationItem2.parent = this.relationList;
        if (useSuperRelation) {
            let desc = cc.find("labelDesc", this.relationItem2);
            desc.color = this.highlightColor1;
        }

        this.relationItem3.parent = this.relationList;
        let hasSatisfy = false;
        let gainList2 = cc.find("content", this.relationItem3);
        for (let i = 0; i < relations2.length; i++) {
            let relation = relations2[i];
            let item = cc.instantiate(this.gainItem2);
            item.parent = gainList2;

            let gains = relation.getGains();
            let title = stringUtils.getString(stringConfigMap.key_more_than.Value, { count: relation.getCount() });
            let value = "";
            if (gains[0].config == propertyConfigMap.施法迅捷) {
                value = `${gains[0].config.ProName}+${gains[0].value}`;
            }
            else {
                value = `${gains[0].config.ProName}+${Math.floor(gains[0].value * 100)}%`;
            }
            let label = item.getComponent(cc.Label);
            label.string = `${title}: ${value}`;
            if (relation.isSatisfy()) {
                label.node.color = this.highlightColor2;
                hasSatisfy = true;
            }
            else {
                let icon = cc.find("icon", this.relationItem3);
                let sprite = icon.getComponent(cc.Sprite);
                sprite.setMaterial(0, this.grayMaterial);
            }
        }
        if (hasSatisfy) {
            let desc = cc.find("labelDesc", gainList2)
            desc.color = this.highlightColor1;
        }
    }
}
