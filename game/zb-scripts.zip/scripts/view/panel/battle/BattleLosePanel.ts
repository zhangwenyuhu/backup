import { unlockConfigMap } from './../../../configs/unlockConfig';
import BasePanel, { PopupPanel } from "../BasePanel";
import EManager, { EName } from "../../../manager/EventManager";
import { BattleType, Goto, Storage } from "../../../utils/DefineUtils";
import IBattleData from "../../../data/IBattleData";
import Mission from "../../../data/mission/Mission";
import towerLogic from "../../../logics/TowerLogic";
import playerLogic from "../../../logics/PlayerLogic";
import am from "../../../manager/AudioManager";
import storageUtils from "../../../utils/StorageUtils";
import guideLogic from "../../../logics/GuideLogic";
import UnlockWrapper from "../../widget/unlock/UnlockWrapper";
import commitLogic, { ArenaPvpType } from '../../../logics/CommitLogic';
import missionLogic from '../../../logics/MissionLogic';
import wisdomTreeLogic from '../../../logics/WisdomTreeLogic';
import { DungeonBattleData } from '../../../logics/DungeonLogic';
import Tower from '../../../data/tower/Tower';
import RMission from '../../../data/mission/RMission';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleLosePanel")
export default class BattleLosePanel extends PopupPanel {
    @property(cc.Node)
    fightHistory: cc.Node = null;

    protected _battleData: IBattleData = null;
    protected _canExit: boolean = false;

    onInit(data: {
        battleData: IBattleData,
        skills: any,
        contribution?: rpgfight.HeroContributionStatistic[]
    }) {
        super.onInit(data.battleData);
        this._battleData = data.battleData;
    }

    onLoad() {
        super.onLoad();

        this.registerEvents();
        this.scheduleOnce(() => { this._canExit = true; }, 1.0);

        if (this._battleData.getBattleType() == BattleType.PVE) {
            this.fightHistory.active = UnlockWrapper.isUnlock(unlockConfigMap.战斗回放与任务目标);

            if (!storageUtils.getBoolean(Storage.FirstFail)) {
                storageUtils.setBoolean(Storage.FirstFail.Key, true, true);
                guideLogic.guideId = 6001;
            }
        } else if (this._battleData.getBattleType() == BattleType.WonderSpace) {
            let historyNode = cc.find("arena_history", this.node);
            if (historyNode) {
                historyNode.active = false;
            }
        } else if (this._battleData.getBattleType() == BattleType.Material) {
            this.fightHistory.active = false;
            commitLogic.matFight((this._battleData as RMission).getType(), false, false);
        }

        BasePanel.closePanel("BattlePausePanel");
    }

    start() {
        super.start();
        am.playEffect("BGM_lose");
        this.commitBattleFailEvent();
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType }) => {
            if (data.type == BattleType.Record || data.type == BattleType.PVP_PlayBack)
                return;
            this.closePanel();
        });
        this._eventListeners.push(listener);

        cc.director.setTimeScale(1);
    }

    onExit() {
        if (!this._canExit) return;

        if (this._battleData.getBattleType() == BattleType.Maze ||
            this._battleData.getBattleType() == BattleType.WonderSpace ||
            this._battleData.getBattleType() == BattleType.Material) {
            EManager.emit(EName.onGameResult, false);
        }
        EManager.emit(EName.onGameExit, { type: this._battleData.getBattleType() });
    }

    onRestart() {
        if (this._battleData.getBattleType() == BattleType.Tower) {
            EManager.emit(EName.onGameExit, { type: BattleType.Tower, goto: Goto.TowerFight });
            return;
        } else if (this._battleData.getBattleType() == BattleType.Maze || this._battleData.getBattleType() == BattleType.WonderSpace) {
            EManager.emit(EName.onGameResult, false);
        }
        EManager.emit(EName.onGameExit, { type: this._battleData.getBattleType() });
        if (this._battleData.getBattleType() == BattleType.PVE) {
            EManager.emit(EName.onGotoView, { goto: Goto.EditTroop, mission: this._battleData as Mission });
        }
    }

    onEditTroop() {
        EManager.emit(EName.onGameExit, { type: this._battleData.getBattleType() });
        if (this._battleData.getBattleType() == BattleType.PVE) {
            EManager.emit(EName.onGotoView, { goto: Goto.EditTroop, mission: this._battleData as Mission });
        }
    }

    onStrongEquip() {
        EManager.emit(EName.onGameExit, { type: this._battleData.getBattleType(), goto: Goto.HeroList });
        EManager.emit(EName.onGotoView, { goto: Goto.HeroList });
    }

    onStrongHero() {
        EManager.emit(EName.onGameExit, { type: this._battleData.getBattleType(), goto: Goto.HeroList });
        EManager.emit(EName.onGotoView, { goto: Goto.HeroList });
    }

    async onFightHistory() {
        if (this._battleData.getBattleType() == BattleType.Tower) {
            let type: number = 0;
            if (this._battleData instanceof Tower) { type = this._battleData.getRaceType(); }
            let level = towerLogic.getCurrentTower(type);
            let roleId = playerLogic.getPlayer().getRoleId();
            await towerLogic.towerFightRecordReq(roleId, level, type);
            let reportData = towerLogic.getTowerRecord(roleId, level, type);
            reportData.type = type;
            gcc.core.showLayer("prefabs/panel/tower/TowerReportPanel", { data: reportData });
        } else {
            gcc.core.showLayer("prefabs/panel/arena/ArenaBattleReportPanel", {
                data: {
                    battleType: this._battleData.getBattleType(),
                    skills: this.data.skills,
                    contribution: this.data.contribution,
                    isWin: false
                }
            });
        }

    }

    protected commitBattleFailEvent() {
        if (this._battleData.getBattleType() == BattleType.PVE) {
            commitLogic.missionBattle(missionLogic.getCurrentMission().getStageId(), false);
        } else if (this._battleData.getBattleType() == BattleType.Maze) {
            commitLogic.wisdomTreeBattle(wisdomTreeLogic.wisdomTreeCurrentPos + 1, false);
        } else if (this._battleData.getBattleType() == BattleType.PVP) {
            commitLogic.arenaBattle(ArenaPvpType.normal, false);
        } else if (this._battleData.getBattleType() == BattleType.Tower) {
            if (this._battleData instanceof Tower) {
                commitLogic.raceTowerBattle(this._battleData.getRaceType(), this._battleData.id, false);
            } else {
                commitLogic.raceTowerBattle(0, (this._battleData as Tower).id, false);
            }
        } else if (this._battleData.getBattleType() == BattleType.Dungeon) {
            let data = this._battleData as DungeonBattleData;
            if (data) {
                commitLogic.dungeonBattle(data.id, false);
            }
        }
    }
}
