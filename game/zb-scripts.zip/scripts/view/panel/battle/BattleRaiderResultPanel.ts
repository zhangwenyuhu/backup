import { PopupPanel } from "../BasePanel";
import EManager, { EName } from "../../../manager/EventManager";
import activityLogic, { ActivityType } from "../../../logics/ActivityLogic";
import TreasureActConfig from "../../../data/activity/actconfig/TreasureActConfig";
import { BattleType } from "../../../utils/DefineUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleRaiderResultPanel")
export default class BattleRaiderResultPanel extends PopupPanel {

    @property(cc.Button)
    title: cc.Button = null;

    @property(cc.Node)
    successTitle: cc.Node = null;

    @property(cc.Node)
    successText: cc.Node = null;

    @property(cc.Node)
    failTitle: cc.Node = null;

    @property(cc.Node)
    failText: cc.Node = null;

    @property(cc.Label)
    cnt: cc.Label = null;

    start() {
        super.start();
        let activity = activityLogic.getActivityConfigs(ActivityType.Treasure);
        let actConfig = activity.actConfig as TreasureActConfig;
        if (actConfig.treasureRewardCnt > 0) {
            this.title.interactable = true;
        } else {
            this.title.interactable = true;
        }
        this.title.interactable = actConfig.treasureRewardCnt > 0;
        this.successTitle.active = this.successText.active = actConfig.treasureRewardCnt > 0;
        this.failTitle.active = this.failText.active = actConfig.treasureRewardCnt <= 0;
        this.cnt.string = `×${actConfig.treasureRewardCnt}`;
    }

    onLoad() {
        super.onLoad();
        let listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType }) => {
            if (data.type == BattleType.Treasure) {
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);
    }

    onRetry() {
        EManager.emit(EName.onGameExit, { type: BattleType.Treasure });
        EManager.emit(EName.onReChallenge);
    }

    async onConfirm() {
        await activityLogic.doAtkTreaRaider();
        EManager.emit(EName.onGameExit, { type: BattleType.Treasure });
    }

}
