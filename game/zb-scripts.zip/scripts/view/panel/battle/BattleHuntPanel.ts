import BattleSharePanel from "./BattleSharePanel";
import { BattleType } from "../../../utils/DefineUtils";
import IBattleData from "../../../data/IBattleData";
import Hero from "../../../data/card/Hero";
import EManager, { EName } from "../../../manager/EventManager";
import { RewardBO } from "../../../proxy/GameProxy";
import HuntChestList from "../../component/Hunt/HuntChestList";
import CommonLoader from "../../common/CommonLoader";
import battleLogic from "../../../logics/BattleLogic";
import unionLogic from "../../../logics/UnionLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleHuntPanel")
export default class BattleHuntPanel extends BattleSharePanel {

    @property(cc.Node)
    huntHpNode: cc.Node = null;

    @property(cc.Node)
    chestNode: cc.Node = null;

    onInit(data: {
        battleData: IBattleData,
        troops: { selfTroop: Hero[], enemyTroop: Hero[] },
        sceneConfig: rpgfight.SceneConfig,
        playBack?: boolean
    }) {
        super.onInit(data);
        let huntBoss = unionLogic.getUnionHuntBossById(unionLogic.unionHuntBossId);
        if (huntBoss) {
            battleLogic.setHeroHuntHurtFact(huntBoss.flawFac, 0.2);
        }
        if (this.huntHpNode) {
            this.huntHpNode.active = this._battleData.getBattleType() == BattleType.Hunt;
        }
    }

    onLoad() {
        super.onLoad();
        let listener = EManager.addEvent(EName.onHuntChest, (data: { startPos: cc.Vec2, chestId: number, reward: RewardBO }) => {
            let chestPos = this.labelChest.node.convertToWorldSpaceAR(cc.p(0, 0));
            this.chestNode.getComponent(HuntChestList).addChest(data.startPos, chestPos, data.chestId, data.reward);
        });
        this._eventListeners.push(listener);
    }

    start() {
        super.start();
        if (this.huntHpNode) {
            this.huntHpNode.getComponent(CommonLoader).loaderNode;
        }
    }

}