import { EName } from './../../../manager/EventManager';
import { PopupPanel } from "../BasePanel";
import EManager from "../../../manager/EventManager";
import { BattleType } from '../../../utils/DefineUtils';
import guideLogic from '../../../logics/GuideLogic';
import Mission from '../../../data/mission/Mission';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattlePausePanel")
export default class BattlePausePanel extends PopupPanel {
    protected _battleType: BattleType;
    protected _battleData: any;

    onInit(data: { battleType: BattleType, battleData: any }) {
        super.onInit(data);

        this._battleType = data.battleType;
        this._battleData = data.battleData;

        if (this._battleType == BattleType.PVP || this._battleType == BattleType.PVP_PlayBack
            || this._battleType == BattleType.Record) {
            let node = cc.find("Layout/btn_again", this.node);
            node.active = false;
        }
        else if (this._battleType == BattleType.PVE) {
            let mission = this._battleData as Mission;
            if (mission.getStageId() == guideLogic.banzangStageId) {
                let node = cc.find("Layout/btn_again", this.node);
                node.active = false;
            }
        }
    }

    onEnable() {
        super.onEnable();
        EManager.emit(EName.onGamePause, { type: this._battleType });
    }

    onResume() {
        this.closePanel();
        EManager.emit(EName.onGameResume, { type: this._battleType });
    }

    onExit() {
        this.closePanel();
        EManager.emit(EName.onGameExit, { type: this._battleType });

        if (this._battleType == BattleType.PVE) {
            let mission = this._battleData as Mission;
            if (mission.getStageId() == guideLogic.artifactStageId
                || mission.getStageId() == guideLogic.leishenStageId
                || mission.getStageId() == guideLogic.banzangStageId) {
                guideLogic.guideId = guideLogic.recordId;
            }
        }
    }

    onRestart() {
        this.closePanel();
        EManager.emit(EName.onGameRestart, { type: this._battleType });

        if (this._battleType == BattleType.PVE) {
            let mission = this._battleData as Mission;
            if (mission.getStageId() == guideLogic.artifactStageId
                || mission.getStageId() == guideLogic.leishenStageId) {
                guideLogic.guideId = guideLogic.recordId;
            }
        }
    }
}
