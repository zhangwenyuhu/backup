import Hero from "../../../data/card/Hero";
import { BattleType } from "../../../utils/DefineUtils";
import IBattleData from "../../../data/IBattleData";
import loadUtils from "../../../utils/LoadUtils";
import commonUtils from "../../../utils/CommonUtils";
import gm from "../../../manager/GameManager";
import battleLogic from "../../../logics/BattleLogic";
import arenaLogic from "../../../logics/ArenaLogic";
import BattlePanel from "./BattlePanel";
import EManager, { EName } from "../../../manager/EventManager";
import stringUtils from "../../../utils/StringUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattlePVPRecordPanel")
export default class BattlePVPRecordPanel extends BattlePanel {

    @property(cc.Label)
    labelTime: cc.Label = null;

    @property(cc.Label)
    labelGold: cc.Label = null;

    @property(cc.Label)
    labelChest: cc.Label = null;

    @property(cc.Sprite)
    spriteBg: cc.Sprite = null;

    protected _skillActiveFrame: { [key: number]: string } = {};
    onInit(data: {
        battleData: IBattleData,
        troops: { selfTroop: Hero[], enemyTroop: Hero[] },
        sceneConfig: rpgfight.SceneConfig,
        skills: any,
    }) {
        super.onInit(data);
        battleLogic.initPVP();
        this._skillActiveFrame = data.skills;
    }

    update(dt: number) {
        super.update(dt);

        if (this._isGameover) {
            return;
        }
        if (!this._fightNode) {
            return;
        }
        if (this._fightNode) {
            let nowFrame = this._fightNode.manager.runner.frameCount;
            if (this._skillActiveFrame[nowFrame]) {
                this._fightNode.activeTheSkill(this._skillActiveFrame[nowFrame]);
            }
        }
        let totalTime = this._fightNode.manager.getScene().sceneData.config.time;
        let currentTime = this._fightNode.manager.clock.currentTime;
        let remainTime = Math.max(totalTime - currentTime, 0);
        remainTime = Math.floor(remainTime / 1000);
        if (remainTime <= 0) {
            this.labelTime.string = "00:00";
        } else {
            this.labelTime.string = stringUtils.formatTime(remainTime);
        }
    }

    protected async _onSelfTroopDead() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;

        this._fightNode.finishGame(false);
        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onSelfTroopDead();
        this.closePanel();
    }

    protected async _onEnemyTroopDead() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;
        this._fightNode.finishGame(true);

        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onEnemyTroopDead();
        this.closePanel();
    }

    protected async _onGameTimeout() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;
        this._fightNode.finishGame(false);

        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onGameTimeout();
        this.closePanel();
    }

    protected async _onGameSkip() {
        this._isGameover = true;
        this._fightNode.finishGame(arenaLogic.getBattleReport().isWin == 0);
    }

    getBattleType(): BattleType {
        return BattleType.PVP_PlayBack;
    }

    getBgUrl(): string {
        return commonUtils.getBgUrl("arena_battle_bg");
    }
}
