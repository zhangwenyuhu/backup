import BasePanel, { PopupPanel } from "../BasePanel";
import EManager, { EName } from "../../../manager/EventManager";
import { BattleType, Goto } from "../../../utils/DefineUtils";
import { BattleReportBO, RoleVO } from "../../../proxy/GameProxy";
import arenaLogic, { RankType } from "../../../logics/ArenaLogic";
import gm from "../../../manager/GameManager";
import Player from "../../../data/user/Player";
import am from "../../../manager/AudioManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattlePVPLosePanel")
export default class BattlePVPLosePanel extends PopupPanel {

    @property(cc.Label)
    nowRank: cc.Label = null;

    @property(cc.Label)
    rankChange: cc.Label = null;

    @property(cc.Label)
    nowScore: cc.Label = null;

    @property(cc.Label)
    scoreChange: cc.Label = null;

    onInit(data: BattleReportBO) {

    }

    start() {
        super.start();

        am.playEffect("BGM_lose");

        let rank = arenaLogic.getMyArenaByRankType(RankType.ArenaNormal);
        if (rank) {
            this.nowRank.string = this.data.rank.toString();
            let diffRank = rank.no - this.data.rank;
            this.rankChange.string = diffRank.toString();
            this.nowScore.string = (rank.score + this.data.score).toString();
            this.scoreChange.string = this.data.score.toString();
            rank.no = this.data.rank;
            rank.score = rank.score + this.data.score;
        }
    }

    onLoad() {
        super.onLoad();

        this.registerEvents();

        BasePanel.closePanel("BattlePausePanel");
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType }) => {
            if (data.type == BattleType.PVP) {
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);

        cc.director.setTimeScale(1);
    }

    onDestroy() {
        super.onDestroy();
        arenaLogic.resetRivalData();
    }

    onExit() {
        EManager.emit(EName.onUpdateRank);
        EManager.emit(EName.onGameExit, { type: BattleType.PVP });
    }

    onRestart() {
        EManager.emit(EName.onGameExit, { type: BattleType.PVP });
        EManager.emit(EName.onGotoView, { goto: Goto.BuildingInfo });
    }

    onEditTroop() {
        EManager.emit(EName.onUpdateRank);
        EManager.emit(EName.onGameExit, { type: BattleType.PVP });
        gcc.core.showLayer("prefabs/panel/arena/ArenaDefenseSetPanel", { data: { defense: true } });
    }

    onStrongEquip() {
        this._gotoHero();
    }

    onStrongHero() {
        this._gotoHero();
    }

    async onHistory() {
        try {
            await arenaLogic.doArenaPlayBack(parseInt(arenaLogic.getBattleData().battleNo));
            if (!cc.isValid(this.node)) {
                return;
            }
            gcc.core.showLayer("prefabs/panel/arena/ArenaBattleReportPanel", {
                data: {
                    battleNo: parseInt(arenaLogic.getBattleData().battleNo),
                    user: this._getPlayer(),
                    battleType: BattleType.PVP
                }
            });
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    protected _getPlayer() {
        let player = null;
        if (arenaLogic.getRivalData()) {
            let rivalData = arenaLogic.getRivalData();
            player = new Player(rivalData.role);
        } else if (arenaLogic.getRivalRecordData()) {
            let rivalRecordData = arenaLogic.getRivalRecordData();
            let role = new RoleVO();
            role.avatarFrame = rivalRecordData.avatarFrame;
            role.avatar = rivalRecordData.avatar;
            role.nick = rivalRecordData.nick;
            role.roleId = rivalRecordData.rivalRoleId;
            role.lv = rivalRecordData.lv;
            role.mainForce = [];
            player = new Player(role);
        }
        return player;
    }

    protected _gotoHero() {
        EManager.emit(EName.onGameExit, { type: BattleType.PVP });
        EManager.emit(EName.onGotoView, { goto: Goto.HeroList });
        setTimeout(() => {
            EManager.emit(EName.onClosePanels, ["ArenaChallengePanel", "ArenaRecordPanel", "ArenaJuniorPanel"])
        }, 100);
    }
}
