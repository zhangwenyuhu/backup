import BattleSharePanel from "./BattleSharePanel";
import IBattleData from "../../../data/IBattleData";
import Hero from "../../../data/card/Hero";
import EManager, {EName} from "../../../manager/EventManager";
import {RewardBO} from "../../../proxy/GameProxy";
import HuntChestList from "../../component/Hunt/HuntChestList";
import activityLogic, {ActivityModal, ActivityType} from "../../../logics/ActivityLogic";
import TreasureActConfig from "../../../data/activity/actconfig/TreasureActConfig";
import CommonLoader from "../../common/CommonLoader";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleRaiderPanel")
export default class BattleRaiderPanel extends BattleSharePanel {

    @property(cc.Node)
    fightRaiderHp: cc.Node = null;

    @property(cc.Node)
    chestNode: cc.Node = null;

    onInit(data: {
        battleData: IBattleData,
        troops: { selfTroop: Hero[], enemyTroop: Hero[] },
        sceneConfig: rpgfight.SceneConfig,
        playBack?: boolean
    }) {
        super.onInit(data);
    }

    onLoad() {
        super.onLoad();
        let data: ActivityModal = activityLogic.getActivityConfigs(ActivityType.Treasure);
        let actConfig = data.actConfig as TreasureActConfig;
        actConfig.treasureRewardCnt = 0;
        actConfig.treasureTotalHurt = 0;
        let listener = EManager.addEvent(EName.onHuntChest, (data: { startPos: cc.Vec2, chestId: number, reward: RewardBO }) => {
            let chestPos = this.labelChest.node.convertToWorldSpaceAR(cc.p(0, 0));
            this.chestNode.getComponent(HuntChestList).addChest(data.startPos, chestPos, data.chestId, data.reward);
        });
        this._eventListeners.push(listener);
    }

    start() {
        super.start();
        if (this.fightRaiderHp) {
            this.fightRaiderHp.getComponent(CommonLoader).loaderNode;
        }
    }

}
