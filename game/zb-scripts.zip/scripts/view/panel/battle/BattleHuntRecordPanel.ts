import { BattleType } from "../../../utils/DefineUtils";
import IBattleData from "../../../data/IBattleData";
import Hero from "../../../data/card/Hero";
import EManager, { EName } from "../../../manager/EventManager";
import { RewardBO } from "../../../proxy/GameProxy";
import HuntChestList from "../../component/Hunt/HuntChestList";
import BattleRecordPanel from "./BattleRecordPanel";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleHuntRecordPanel")
export default class BattleHuntRecordPanel extends BattleRecordPanel {

    @property(cc.Node)
    huntHpNode: cc.Node = null;

    @property(cc.Node)
    chestNode: cc.Node = null;

    onInit(data: {
        battleData: IBattleData,
        troops: { selfTroop: Hero[], enemyTroop: Hero[] },
        sceneConfig: rpgfight.SceneConfig,
        skills: any,
    }) {
        super.onInit(data);
        if (this.huntHpNode) {
            this.huntHpNode.active = this._battleData.getBattleType() == BattleType.Hunt;
        }
    }

    onLoad() {
        super.onLoad();

        let listener = EManager.addEvent(EName.onHuntChest, (data: { startPos: cc.Vec2, chestId: number, reward: RewardBO }) => {
            let chestPos = this.labelChest.node.convertToWorldSpaceAR(cc.p(0, 0));
            this.chestNode.getComponent(HuntChestList).addChest(data.startPos, chestPos, data.chestId, data.reward);
        });
        this._eventListeners.push(listener);
    }
}