import BattleSharePanel from "./BattleSharePanel";
import Hero from "../../../data/card/Hero";
import { BattleType } from "../../../utils/DefineUtils";
import IBattleData from "../../../data/IBattleData";
import battleLogic from "../../../logics/BattleLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleRecordPanel")
export default class BattleRecordPanel extends BattleSharePanel {
    protected _heroSkillFrames: { [key: number]: { active: boolean, heroIds: string[] } } = {};

    onInit(data: {
        battleData: IBattleData,
        troops: { selfTroop: Hero[], enemyTroop: Hero[] },
        sceneConfig: rpgfight.SceneConfig,
        skills: any,
    }) {
        super.onInit(data);
        this._heroSkillFrames = data.skills;
    }

    startBattle() {
        let heroList: rpgfight.HeroConfig[] = battleLogic.getHeroList();
        for (let hero of heroList) {
            hero.power = this.getDefaultPower();
            hero.powerSpeedupRate = this.getPowerSpeedupRate();

            if (this._battleData.getBattleType() == BattleType.Hunt
                || this._battleData.getBattleType() == BattleType.WorldBoss
                || this._battleData.getBattleType() == BattleType.Treasure) {
                if (hero.battleTeam == rpgfight.BattleTeam.enemy) {
                    hero.battleInitPosition = ml.p(rpgfight.Hero.StationPositionX[hero.battleStation - 1],
                        rpgfight.Hero.StationPositionY[hero.battleStation - 1]);
                }
            }
        }

        super.startBattle();

        let update = this._fightNode.manager.robotPlayer.update;
        this._fightNode.manager.robotPlayer.update = (dt: number) => {
            let curFrame = this._fightNode.manager.runner.frameCount;
            let frame = this._heroSkillFrames[curFrame];
            if (typeof frame == 'string') {
                this._fightNode.activeTheSkill(frame); // 兼容老的回放                
            }
            else if (typeof frame == 'object') {
                for (let heroId of frame.heroIds) {
                    if (frame.active) {
                        this._fightNode.activeTheSkill(heroId);
                    }
                    else {
                        this._fightNode.deactiveTheSkill(heroId);
                    }
                }
            }
            update.call(this._fightNode.manager.robotPlayer, dt);
        }
    }

    getBattleType(): BattleType {
        return BattleType.Record;
    }
}
