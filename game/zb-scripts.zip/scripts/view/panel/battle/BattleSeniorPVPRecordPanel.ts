import Hero from "../../../data/card/Hero";
import { BattleType } from "../../../utils/DefineUtils";
import IBattleData from "../../../data/IBattleData";
import commonUtils from "../../../utils/CommonUtils";
import battleLogic from "../../../logics/BattleLogic";
import BattlePanel from "./BattlePanel";
import EManager, { EName } from "../../../manager/EventManager";
import stringUtils from "../../../utils/StringUtils";
import arenaSeniorLogic from "../../../logics/ArenaSeniorLogic";
import ArenaSeniorBattlePlayer from "../../component/Arena/ArenaSeniorBattlePlayer";
import playerLogic from "../../../logics/PlayerLogic";
import Player from "../../../data/user/Player";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/battle/BattleSeniorPVPRecordPanel")
export default class BattleSeniorPVPRecordPanel extends BattlePanel {

    @property(cc.Label)
    labelTime: cc.Label = null;

    @property(cc.Label)
    labelGold: cc.Label = null;

    @property(cc.Label)
    labelChest: cc.Label = null;

    @property(cc.Node)
    leftPlayer: cc.Node = null;

    @property(cc.Node)
    rightPlayer: cc.Node = null;

    protected _skillActiveFrame: { [key: number]: string } = {};
    onInit(data: {
        battleData: IBattleData,
        troops: { selfTroop: Hero[], enemyTroop: Hero[] },
        sceneConfig: rpgfight.SceneConfig,
        skills: any,
        groupId?: number,
        player?: Player,
        defense?: boolean
    }) {
        super.onInit(data);
        battleLogic.initSeniorPVPRecord(data.groupId, false);
        this._skillActiveFrame = data.skills;
    }

    start() {
        super.start();
        this.leftPlayer.getComponent(ArenaSeniorBattlePlayer).refresh(this.data.defense ? this.data.player : playerLogic.getPlayer());
        this.rightPlayer.getComponent(ArenaSeniorBattlePlayer).refresh(this.data.defense ? playerLogic.getPlayer() : this.data.player);
    }

    update(dt: number) {
        super.update(dt);

        if (this._isGameover) {
            return;
        }
        if (!this._fightNode) {
            return;
        }
        if (this._fightNode) {
            let nowFrame = this._fightNode.manager.runner.frameCount;
            if (this._skillActiveFrame[nowFrame]) {
                this._fightNode.activeTheSkill(this._skillActiveFrame[nowFrame]);
            }
        }
        let totalTime = this._fightNode.manager.getScene().sceneData.config.time;
        let currentTime = this._fightNode.manager.clock.currentTime;
        let remainTime = Math.max(totalTime - currentTime, 0);
        remainTime = Math.floor(remainTime / 1000);
        if (remainTime <= 0) {
            this.labelTime.string = "00:00";
        } else {
            this.labelTime.string = stringUtils.formatTime(remainTime);
        }
    }

    protected async _onSelfTroopDead() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;

        this._fightNode.finishGame(false);
        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onSelfTroopDead();
        this.closePanel();
    }

    protected async _onEnemyTroopDead() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;
        this._fightNode.finishGame(true);

        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onEnemyTroopDead();
        this.closePanel();
    }

    protected async _onGameTimeout() {
        if (this._isGameover) {
            return;
        }
        this._isGameover = true;
        this._fightNode.finishGame(false);

        await commonUtils.sleep(1.5);
        EManager.emit(EName.onGameOver);

        super._onGameTimeout();
        this.closePanel();
    }

    protected async _onGameSkip() {
        this._isGameover = true;
        this._fightNode.finishGame(arenaSeniorLogic.getBattleDataByGroupId(this.data.groupId).result["isGameWin"]);
    }

    getBattleType(): BattleType {
        return BattleType.PVP_Senior_Record;
    }

    getBgUrl(): string {
        return commonUtils.getBgUrl("arena_battle_bg");
    }
}
