import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from './../BasePanel';
import CommonLoader from '../../common/CommonLoader';
import Artifact from '../../../data/card/Artifact';
import EquipCard from '../../component/Equip/EquipCard';
import HeroCard from '../../component/Hero/HeroCard';
import stringUtils from '../../../utils/StringUtils';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/ArtifactDetailPanel")
export default class ArtifactDetailPanel extends PopupPanel {
    @property(CommonLoader)
    equipLoader: CommonLoader = null;

    @property(CommonLoader)
    heroLoader: CommonLoader = null;

    @property(cc.Label)
    labelName: cc.Label = null;

    @property(cc.Node)
    propertyArea: cc.Node = null;

    @property(cc.Node)
    propertyItem: cc.Node = null;

    @property(cc.Node)
    skillArea: cc.Node = null;

    @property(cc.Node)
    skillItem: cc.Node = null;

    @property(cc.Node)
    skillTitle: cc.Node = null;

    @property(cc.Color)
    focusColor: cc.Color = cc.Color.BLUE;

    protected _artifact: Artifact = null;

    onInit(artifact: Artifact) {
        super.onInit(artifact);
        this._artifact = artifact;
    }

    start() {
        super.start();

        let artifact = this._artifact;

        let equipCard = this.equipLoader.loaderNode.getComponent(EquipCard);
        equipCard.refresh({ equip: artifact });

        let hero = artifact.getHero();
        if (hero) {
            let heroCard = this.heroLoader.loaderNode.getComponent(HeroCard);
            heroCard.refresh(hero);
        }
        else {
            this.heroLoader.node.active = false;
        }

        this.labelName.string = artifact.getName();

        this.propertyItem.parent = null;
        this.skillItem.parent = null;
        this.skillTitle.parent = null;
        this._updateProperties(artifact);
    }

    protected _updateProperties(artifact: Artifact) {
        let property = artifact.getProperty();
        let values = property.getValues();
        let titles = property.getTitles();

        for (let i = 0; i < titles.length; i++) {
            let title = titles[i];
            let value = values[i];
            if (value) {
                let item = cc.instantiate(this.propertyItem);
                item.parent = this.propertyArea;

                let label = item.getComponent(cc.Label);
                label.string = `${title}：${value < 1 ? Math.floor(value * 100) + "%" : value}`;
            }
        }
        this.propertyArea.getComponent(cc.Layout).updateLayout();

        let title = cc.instantiate(this.skillTitle);
        title.getComponent(cc.Label).string = "主动技能";
        title.parent = this.skillArea;
        let skills = artifact.getSkills();
        for (let i = 1; i <= 5; i++) {
            this._addSkillDesc(artifact, skills[1], i, true);
        }
        title = cc.instantiate(this.skillTitle);
        title.getComponent(cc.Label).string = "被动技能";
        title.parent = this.skillArea;
        for (let i = 1; i <= 3; i++) {
            this._addSkillDesc(artifact, skills[0], i, false);
        }
        this.skillArea.getComponent(cc.Layout).updateLayout();
    }

    protected _addSkillDesc(artifact, skill, i, initiative: boolean) {
        let item = cc.instantiate(this.skillItem);
        item.parent = this.skillArea;

        let desc = skill.getSkillDesc(i);
        let label = item.getComponent(cc.Label);
        label.string = `${i}.${desc}`;

        if (skill.getLevel() >= i) {
            item.color = this.focusColor;
        }
        else {
            label.string += "(" + stringUtils.getString(stringConfigMap.key_artifact_skill_unlock.Value, { count: artifact.getStarByUnlockSkillLevel(i, initiative) }) + ")";
        }
        (label as any)._updateRenderData(true);
    }
}
