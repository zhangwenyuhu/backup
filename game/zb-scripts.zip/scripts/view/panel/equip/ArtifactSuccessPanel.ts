import { PopupPanel } from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import Artifact from "../../../data/card/Artifact";
import loadUtils from "../../../utils/LoadUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/ArtifactSuccessPanel")
export default class ArtifactSuccessPanel extends PopupPanel {

    @property({
        type: cc.SpriteFrame
    })
    starFrames: cc.SpriteFrame[] = [];

    @property(sp.Skeleton)
    artifact: sp.Skeleton = null;

    @property(cc.Node)
    starNode1: cc.Node = null;

    @property(cc.Node)
    starNode2: cc.Node = null;

    @property(CommonLoader)
    skill1: CommonLoader = null;

    @property(CommonLoader)
    skill2: CommonLoader = null;

    @property(CommonLoader)
    property1: CommonLoader = null;

    @property(CommonLoader)
    property2: CommonLoader = null;

    protected _skeletonData: sp.SkeletonData = null;

    onInit(data: {
        before: Artifact,
        after: Artifact
    }) {
        super.onInit(data);
    }

    onLoad() {
        super.onLoad();

        let animation = this.node.getComponent(cc.Animation);
        animation.play("jinhuachenggong_ruchang", 0);
        animation.on("finished", () => {
            animation.off("finished");
            animation.play("jinhuachenggong_loop", 0);
        }, this);
    }

    async start() {
        super.start();
        this._showInfo();
        let url = `spine/ui/shenqi/${this.data.after.getSpineFile()}`;
        this._skeletonData = await loadUtils.loadRes(url, sp.SkeletonData) as sp.SkeletonData;
        this.artifact.skeletonData = this._skeletonData;
        this.artifact.animation = "animation";
        this.artifact.loop = true;
    }

    protected _showInfo() {
        this._showStar(this.starNode1, this.data.before.getStar(), true);
        this._showStar(this.starNode2, this.data.after.getStar(), true);
        this.skill1.refreshComponent({ before: this.data.before.getSkills()[1], after: this.data.after.getSkills()[1] });
        this.skill2.refreshComponent({ before: this.data.before.getSkills()[0], after: this.data.after.getSkills()[0] });

        let before = this.data.before as Artifact;
        let property = before.getProperty();
        let values = property.getValues(true);
        let titles = property.getTitles(true);

        let nextArtifact = this.data.before.clone() as Artifact;
        nextArtifact.setStar(nextArtifact.getStar() + 1);
        let nextProperty = nextArtifact.getProperty();
        let nextValues = nextProperty.getValues(true);

        let index = 1;
        this.property1.node.active = this.property2.node.active = false;
        for (let i = 0; i < values.length; i++) {
            let value = values[i];
            let nextValue = nextValues[i];
            if (value > 0) {
                let title = titles[i];
                if (index == 1) {
                    this.property1.node.active = true;
                    this.property1.refreshComponent({
                        artifact: before,
                        str: title,
                        value1: value,
                        value2: nextValue,
                        max: before.getStar() == before.getStarLimit()
                    });
                } else if (index == 2) {
                    this.property2.node.active = true;
                    this.property2.refreshComponent({
                        artifact: before,
                        str: title,
                        value1: value,
                        value2: nextValue,
                        max: before.getStar() == before.getStarLimit()
                    });
                }
                index++;
            }
        }
    }

    protected _showStar(starNode, star, showBlock: boolean = false) {
        for (let i = 0; i < this.data.before.getStarLimit(); i++) {
            let node = starNode.children[i];
            if (showBlock) {
                if (star == 0) {
                    if (i == 0) {
                        node.getComponent(cc.Sprite).spriteFrame = this.starFrames[1];
                    } else {
                        node.active = false;
                    }
                } else {
                    node.active = (i + 1) <= star;
                    node.getComponent(cc.Sprite).spriteFrame = this.starFrames[0];
                }
            } else {
                node.active = (i + 1) <= star;
                node.getComponent(cc.Sprite).spriteFrame = this.starFrames[0];
            }
        }
    }

}
