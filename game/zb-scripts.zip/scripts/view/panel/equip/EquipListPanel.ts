import { PopupPanel } from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import { RefreshLabel } from "../../../decorator/RefreshDecorator";
import Equip from "../../../data/card/Equip";
import Hero from "../../../data/card/Hero";
import EquipCard from "../../component/Equip/EquipCard";
import { stringConfigMap } from "../../../configs/stringConfig";
import stringUtils from "../../../utils/StringUtils";
import EManager, { EName } from "../../../manager/EventManager";
import bagLogic from "../../../logics/BagLogic";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import heroUtils from "../../../utils/HeroUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/EquipListPanel")
export default class EquipListPanel extends PopupPanel {

    @property(CommonLoader)
    equipLoader: CommonLoader = null;

    @property(cc.Node)
    equipInfo: cc.Node = null;

    @property(cc.Node)
    noEquip: cc.Node = null;

    @property(cc.Label)
    labelNoEquip: cc.Label = null;

    @property(cc.Label)
    equipName: cc.Label = null;

    @RefreshLabel({
        eventName: Equip.Event.onStarDirty,
        getData: (caller: EquipListPanel) => {
            return caller.equip
        },
        getValue: (caller: Equip) => {
            return caller.getPower()
        }
    })
    @property(cc.Label)
    equipFight: cc.Label = null;

    @property(cc.Node)
    equipScrollView: cc.Node = null;

    @property(cc.Label)
    labelTitle: cc.Label = null;

    @property(cc.Node)
    content: cc.Node = null;

    equip: Equip = null;
    wearType: number = 0;
    hero: Hero = null;

    onInit(data: any) {
        this.equip = data.equip;
        this.wearType = data.wearType;
        this.hero = data.hero;
    }

    onLoad() {
        super.onLoad();
        this.registerEvents();
    }

    start() {
        if (this.wearType == EquipCard.WearType.Artifact) {
            this.labelTitle.string = stringConfigMap.key_artifact.Value;
        }
        else {
            this.labelTitle.string = stringConfigMap.key_equip.Value;
        }
        if (this.equip) {
            this.equipName.string = this.equip.getName();
            let equipQuality = heroUtils.getEquipQuality(this.equip.getRank());
            let color = cc.Color.WHITE;
            color.fromHEX(equipQuality.qualityColor);
            this.equipName.node.color = color;
            this.equipLoader.loaderNode.getComponent(EquipCard).refresh({ equip: this.equip });
            this.noEquip.active = false;
            this.content.height = 460;
        } else {
            this.equipInfo.active = false;
            this.noEquip.active = true;
            this.labelNoEquip.string = stringUtils.getString(stringConfigMap.key_no_equip.Value, { name: this.labelTitle.string });
            this.content.height = 540;
        }
        this.showEquipList();
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onUpdateEquip, (hero: Hero) => {
            if (this.hero == hero) {
                this.closePanel();
            }
        })
        this._eventListeners.push(listener);
    }

    showEquipList() {
        let equips = bagLogic.getSuitableEquipsForHero(this.hero, this.wearType);
        equips.sort((a: Equip, b: Equip) => {
            let tempA = a.clone();
            tempA.heroId = this.hero.getId();
            let tempB = b.clone();
            tempB.heroId = this.hero.getId();

            return tempB.getPower() - tempA.getPower();
        })
        let data = [];
        for (let i = 0; i < equips.length; i++) {
            if (!this.equip || equips[i].getId() != this.equip.getId()) {
                let _arr = {
                    equip: equips[i],
                    wearType: this.wearType,
                    hero: this.hero
                };
                data.push(_arr);
            }
        }
        this.equipScrollView.getComponent(ScrollViewLoader).refresh(data);
    }

}