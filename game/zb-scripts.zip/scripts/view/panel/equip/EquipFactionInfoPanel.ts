import { PopupPanel } from "../BasePanel";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/EquipFactionInfoPanel")
export default class EquipFactionInfoPanel extends PopupPanel {

    @property(cc.Sprite)
    hero_tag: cc.Sprite = null;

    @property(cc.Label)
    desc: cc.Label = null;

    protected _frame: cc.SpriteFrame = null;
    protected _text: string = "";

    onInit(data: {
        frame: cc.SpriteFrame,
        text: string
    }) {
        super.onInit(data);
        this._frame = data.frame;
        this._text = data.text;
    }

    start() {
        this.hero_tag.spriteFrame = this._frame;
        this.desc.string = this._text;
    }
}
