import { Storage } from './../../../utils/DefineUtils';
import BasePanel, { FullscreenPanel } from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import artifactConfig, { artifactConfigRow } from "../../../configs/artifactConfig";
import heroLogic from "../../../logics/HeroLogic";
import artifactunlockConfig from "../../../configs/artifactunlockConfig";
import Tasktypeconfig from "../../../configs/Tasktypeconfig";
import loadUtils from "../../../utils/LoadUtils";
import Artifact from "../../../data/card/Artifact";
import commonUtils from "../../../utils/CommonUtils";
import bagLogic from "../../../logics/BagLogic";
import GoodCard from "../../component/Good/GoodCard";
import gm from "../../../manager/GameManager";
import Skill from "../../../data/card/Skill";
import SkillCard from "../../component/Skill/SkillCard";
import EManager, { EName } from "../../../manager/EventManager";
import { stringConfigMap } from "../../../configs/stringConfig";
import giftLogic from "../../../logics/GiftLogic";
import ArtifactTaskItem from "../../component/Artifact/ArtifactTaskItem";
import storageUtils from "../../../utils/StorageUtils";
import guideLogic from '../../../logics/GuideLogic';
import commitLogic from '../../../logics/CommitLogic';
import artifactLogic from "../../../logics/ArtifactLogic";
import artifactcompoundConfig from "../../../configs/artifactcompoundConfig";
import ArtifactName from "../../component/Artifact/ArtifactName";
import ArtifactForge from "../../component/Artifact/ArtifactForge";
import UnlockWrapper from "../../widget/unlock/UnlockWrapper";
import { unlockConfigMap, unlockConfigRow } from "../../../configs/unlockConfig";

const { ccclass, property, menu } = cc._decorator;

export enum ArtifactTabIndex {
    Evolution,
    Forge
}

@ccclass
@menu("view/panel/equip/ArtifactNewPanel")
export default class ArtifactNewPanel extends FullscreenPanel {

    @property(cc.Sprite)
    bg: cc.Sprite = null;

    @property(CommonLoader)
    topBar: CommonLoader = null;

    @property(cc.Node)
    panel_bg: cc.Node = null;

    @property(sp.Skeleton)
    skeleton: sp.Skeleton = null;

    @property(cc.Node)
    btnPrevious: cc.Node = null;

    @property(cc.Node)
    btnNext: cc.Node = null;

    @property(CommonLoader)
    artifact_name: CommonLoader = null;

    @property(cc.Label)
    artifact_level: cc.Label = null;

    @property(cc.Node)
    starNode: cc.Node = null;

    @property({
        type: cc.SpriteFrame
    })
    starFrames: cc.SpriteFrame[] = [];

    @property(cc.Label)
    lock_tip: cc.Label = null;

    @property(CommonLoader)
    skill1: CommonLoader = null;

    @property(CommonLoader)
    skill2: CommonLoader = null;

    @property(cc.Node)
    content1: cc.Node = null;

    @property(cc.Node)
    propertyBg: cc.Node = null;

    @property(CommonLoader)
    property1: CommonLoader = null;

    @property(CommonLoader)
    property2: CommonLoader = null;

    @property(cc.Node)
    evolutionNode: cc.Node = null;

    @property(cc.Node)
    star1: cc.Node = null;

    @property(cc.Node)
    evoArrow: cc.Node = null;

    @property(cc.Node)
    star2: cc.Node = null;

    @property(CommonLoader)
    goodEvo: CommonLoader = null;

    @property(cc.Label)
    goodEvoCnt: cc.Label = null;

    @property(cc.Label)
    totalGoodCnt: cc.Label = null;

    @property(cc.Node)
    content2: cc.Node = null;

    @property(cc.ProgressBar)
    taskProgress: cc.ProgressBar = null;

    @property(cc.Label)
    taskLabel: cc.Label = null;

    @property(cc.Node)
    scrollContent: cc.Node = null;

    @property(cc.Node)
    item: cc.Node = null;

    @property(cc.Node)
    item2: cc.Node = null;

    @property(cc.Button)
    evoBtn: cc.Button = null;

    @property(cc.Label)
    evoLabel: cc.Label = null;

    @property(cc.Node)
    getBtn: cc.Node = null;

    @property(cc.Node)
    unlockBtn: cc.Node = null;

    @property(cc.Node)
    lockNode: cc.Node = null;

    @property(cc.Node)
    unlockAnim: cc.Node = null;

    @property(cc.Node)
    levelAnim: cc.Node = null;

    @property(cc.Node)
    evoAnim: cc.Node = null;

    @property(cc.Node)
    forgeAnim: cc.Node = null;

    @property(cc.Sprite)
    compoundIcon: cc.Sprite = null;

    @property(cc.Node)
    compoundStar: cc.Node = null;

    @property(cc.Node)
    compoundStarNode: cc.Node = null;

    @property(cc.Node)
    tab: cc.Node = null;

    @property(cc.Node)
    content3: cc.Node = null;

    @property(cc.Node)
    forgeLock: cc.Node = null;

    protected _artifactCfg: artifactConfigRow = null;
    protected _artifact: Artifact = null;
    protected _skeletonData: sp.SkeletonData = null;
    protected _artifactList: number[] = [];
    protected _artifactId: number = 0;
    protected _artifactSkeletonData: { [key: string]: sp.SkeletonData } = {};
    protected _nowTabIndex: number = ArtifactTabIndex.Evolution;

    onInit(data: {
        artifactId: number
    }) {
        super.onInit(data);
        this._artifactId = data.artifactId;
        this._initData();
    }

    protected _initData() {
        this._artifactCfg = artifactConfig.find(a => a.Id == this._artifactId);
        this._artifact = heroLogic.artifactUnlockInfo.getArtifact(this._artifactId);
        for (let i = 1; i <= 7; i++) {
            let cfg = artifactunlockConfig.find(a => a.order == i);
            if (this._artifactList.indexOf(cfg.ArtifactID) == -1) {
                this._artifactList.push(cfg.ArtifactID);
            }
        }
    }

    onLoad() {
        super.onLoad();

        let listener = EManager.addEvent(EName.onTouch, () => {
            EManager.emit(EName.onClosePanel, "SkillGetDetailPanel");
        });

        this._eventListeners.push(listener);

        listener = EManager.addEvent(EName.onArtifactForge, () => {
            this._refreshArtifactInfo();
            this._playForgeAnim();
        });
        this._eventListeners.push(listener);

        this.item.parent = null;
        this.item2.parent = null;
        this.compoundStar.parent = null;

        this.panel_bg.height = cc.winSize.height / 2 + this.panel_bg.y - 115;
    }

    onDestroy() {
        super.onDestroy();

        this.item.destroy();
        this.item2.destroy();
        this.compoundStar.destroy();
    }

    async start() {
        super.start();
        this.forgeAnim.active = false;
        this.topBar.loaderNode;
        this._showView();
        this._showArrow();
        this._showCompound();
        this.forgeLock.active = !UnlockWrapper.isUnlock(unlockConfigMap.神器锻造);
        await this._initArtifact();

        if (!storageUtils.getBoolean(Storage.ArtifactForgeGuide)) {
            if (this.canForge()) {
                guideLogic.guideId = 290001;
            }
        }
    }

    canForge() {
        if (!UnlockWrapper.isUnlock(unlockConfigMap.神器锻造)) {
            return false;
        }
        if (!heroLogic.artifactUnlockInfo.isArtifactUnlock(this._artifact.getIndex())) {
            return false;
        }
        let ret = artifactLogic.canForgeArtifact(this._artifact);
        return ret.result;
    }

    protected async _initArtifact() {
        let url = `spine/ui/shenqi/${this._artifact.getSpineFile()}`;
        this._skeletonData = await loadUtils.loadRes(url, sp.SkeletonData) as sp.SkeletonData;
        this._skeletonData.lock();
        this._artifactSkeletonData[url] = this._skeletonData;
        this.skeleton.skeletonData = this._skeletonData;
        this.skeleton.animation = "animation";
        this.skeleton.loop = true;
        this._refreshArtifactInfo();
    }

    protected _refreshArtifactInfo() {
        this._showStar(this.starNode, this._artifact.getStar());
        if (this._artifact.getForgeLv() > 0) {
            this.artifact_level.node.active = true;
            this.artifact_level.string = "Lv." + this._artifact.getForgeLv();
        } else {
            this.artifact_level.node.active = false;
        }
        let comp = this.artifact_name.loaderNode.getComponent(ArtifactName);
        comp.refresh(this._artifact.getIndex());
    }

    protected _showView() {
        let isUnlock = heroLogic.artifactUnlockInfo.isArtifactUnlock(this._artifactCfg.Id);
        this.content1.active = this.content2.active = this.content3.active = false;
        this._showTop();
        if (isUnlock) {
            this.tab.active = true;
            this.content1.active = true;
            this.lock_tip.node.active = false;
            this.artifact_level.node.active = true;
            this.starNode.active = true;
            //进阶
            if (this._nowTabIndex == ArtifactTabIndex.Evolution) {
                this._showEvolution();
            } else if (this._nowTabIndex == ArtifactTabIndex.Forge) {
                this._showForge();
            }
        } else {
            //立即获得、解锁任务
            this.content2.active = true;
            this.tab.active = false;
            this._showTask();
        }
    }

    /**显示神器 */
    protected _showTop() {
        this._refreshArtifactInfo();
        let skill: Skill[] = this._artifact.getSkills();
        let loaderNode = this.skill1.loaderNode;
        loaderNode.getComponent(SkillCard).refresh({ skill: skill[1], artifact: this._artifact });
        loaderNode.getComponent(SkillCard).registerArtifactDetail();
        loaderNode = this.skill2.loaderNode;
        loaderNode.getComponent(SkillCard).refresh({ skill: skill[0], artifact: this._artifact });
        loaderNode.getComponent(SkillCard).registerArtifactDetail();
    }

    /**显示星星 */
    protected _showStar(starNode: cc.Node, star: number, showBlock: boolean = false) {
        for (let i = 0; i < this._artifact.getStarLimit(); i++) {
            let node = starNode.children[i];
            if (showBlock) {
                if (star == 0) {
                    if (i == 0) {
                        node.active = true;
                        node.getComponent(cc.Sprite).spriteFrame = this.starFrames[1];
                    } else {
                        node.active = false;
                    }
                } else {
                    node.active = (i + 1) <= star;
                    node.getComponent(cc.Sprite).spriteFrame = this.starFrames[0];
                }
            } else {
                node.active = (i + 1) <= star;
                node.getComponent(cc.Sprite).spriteFrame = this.starFrames[0];
            }
        }
    }

    /**神器待解锁 */
    protected _showTask() {
        this.content1.active = false;
        this.content2.active = true;
        this.getBtn.active = true;
        this.artifact_level.node.active = false;
        this.lock_tip.node.active = true;
        this.starNode.active = false;
        this.scrollContent.destroyAllChildren();
        let artifactUnlockCfgs = artifactunlockConfig.where(a => a.ArtifactID == this._artifact.getIndex());
        let max = 0;
        let taskIds = [];
        for (let artifactUnlockCfg of artifactUnlockCfgs) {
            let taskTypeCfg = Tasktypeconfig.find(a => a.tasktypeID == artifactUnlockCfg.tasktype);
            if (taskTypeCfg) {
                taskIds.push(artifactUnlockCfg.ID);
                max++;
            }
        }
        if (taskIds.length == 1) {
            let node = cc.instantiate(this.item2);
            node.getComponent(CommonLoader).refreshComponent(taskIds[0]);
            this.scrollContent.addChild(node);
        } else {
            for (let id of taskIds) {
                let node = cc.instantiate(this.item);
                node.getComponent(CommonLoader).refreshComponent(id);
                this.scrollContent.addChild(node);
            }
        }

        for (let i = 0; i < this.scrollContent.childrenCount; i++) {
            let child = this.scrollContent.children[i];
            let loader = child.getComponent(CommonLoader);
            let item = loader.loaderNode.getComponent(ArtifactTaskItem);
            if (item.goBtn.active) {
                item.isGuideTarget = true;
                break;
            }
        }

        let now = heroLogic.artifactUnlockInfo.getTaskProgress(this._artifact.getIndex());
        max = Math.max(1, max);
        this.taskProgress.progress = now / max;
        this.taskLabel.string = `${now}/${max}`;
        if (heroLogic.artifactUnlockInfo.canArtifactMerge(this._artifact.getIndex())) {
            this.getBtn.active = false;
            this.unlockBtn.active = true;
        } else {
            this.getBtn.active = true;
            this.unlockBtn.active = false;
        }
        this._showGetBtn();
        if (taskIds.length == 0) {
            this.content2.active = false;
            this.lockNode.active = true;
            this.getBtn.active = false;
            this.unlockBtn.active = false;
        } else {
            this.lockNode.active = false;
        }
    }

    /**进阶神器 */
    protected _showEvolution() {
        this.content1.active = true;
        this.content2.active = false;
        this.content3.active = false;
        this.lockNode.active = false;
        this.evolutionNode.active = true;
        this.getBtn.active = false;
        this.unlockBtn.active = false;
        let loaderNode = this.goodEvo.loaderNode;
        let consumeGood = this._artifact.getConsumeGood();
        loaderNode.getComponent(GoodCard).refresh(consumeGood);
        loaderNode.getComponent(GoodCard).showAmount(false);
        loaderNode.getComponent(GoodCard).registerOnGoodInfo();
        let hasCnt = bagLogic.getGood(consumeGood.getIndex()).getAmount();
        this.goodEvoCnt.string = hasCnt.toString();
        this.totalGoodCnt.string = "/" + consumeGood.getAmount();
        let color = cc.color(255, 255, 255, 255);
        if (hasCnt < consumeGood.getAmount()) {
            color = cc.color(255, 0, 0, 255);
        }
        this.goodEvoCnt.node.color = color;
        this.star1.active = this.star2.active = true;
        this._showStar(this.star1, this._artifact.getStar(), true);
        if (this._artifact.getStar() < this._artifact.getStarLimit()) {
            this.star1.x = -44;
            this.evoArrow.active = true;
            this._showStar(this.star2, this._artifact.getStar() + 1, true);
            this.evoBtn.interactable = true;
            this.evoLabel.string = stringConfigMap.key_artifact_evo_text1.Value;
            this.goodEvo.node.active = true;
            this.evoBtn.node.getComponent(cc.Widget).bottom = -374;
            this.evoBtn.node.getComponent(cc.Widget).updateAlignment();
        } else {
            //已满阶
            this.star1.x = 120;
            this.star2.active = false;
            this.evoArrow.active = false;
            this.evoBtn.interactable = false;
            this.evoLabel.string = stringConfigMap.key_artifact_evo_text2.Value;
            this.goodEvo.node.active = false;
            this.evoBtn.node.getComponent(cc.Widget).bottom = -304;
            this.evoBtn.node.getComponent(cc.Widget).updateAlignment();
        }

        let property = this._artifact.getProperty();
        let values = property.getValues(true);
        let titles = property.getTitles(true);

        let nextArtifact = this._artifact.clone();
        nextArtifact.setStar(nextArtifact.getStar() + 1);
        let nextProperty = nextArtifact.getProperty();
        let nextValues = nextProperty.getValues(true);

        let index = 1;
        this.property1.node.active = this.property2.node.active = false;
        for (let i = 0; i < values.length; i++) {
            let value = values[i];
            let nextValue = nextValues[i];
            if (value > 0) {
                let title = titles[i];
                if (index == 1) {
                    this.property1.node.active = true;
                    this.property1.refreshComponent({
                        str: title,
                        value1: value,
                        value2: nextValue,
                        max: this._artifact.getStar() == this._artifact.getStarLimit()
                    });
                } else if (index == 2) {
                    this.property2.node.active = true;
                    this.property2.refreshComponent({
                        str: title,
                        value1: value,
                        value2: nextValue,
                        max: this._artifact.getStar() == this._artifact.getStarLimit()
                    });
                }
                index++;
            }
        }
        this.propertyBg.active = this.property2.node.active;
    }

    protected _showForge() {
        this.content1.active = false;
        this.content2.active = false;
        this.content3.active = true;
        this.getBtn.active = false;
        this.unlockBtn.active = false;
        this.content3.getComponent(ArtifactForge).refresh(this._artifact);
    }

    protected _playLevelUpAnim() {
        let anim = this.levelAnim.getComponent(cc.Animation);
        anim.play("shenqiqianghua0", 0);
    }

    protected _playEvoAnim() {
        let anim = this.evoAnim.getComponent(cc.Animation);
        anim.play("shenqiqianghua1", 0);
    }

    protected _playUnlockAnim(callback = null) {
        let anim = this.unlockAnim.getComponent(cc.Animation);
        anim.play("Shengqi_hc", 0);
        anim.on("finished", () => {
            callback && callback();
        });
    }

    protected _playForgeAnim() {
        this.forgeAnim.active = true;
        let anim = this.forgeAnim.getComponent(cc.Animation);
        anim.play("ArtifactNewPanelCZ", 0);
        anim.on("finished", () => {
            anim.off("finished");
            this.forgeAnim.active = false;
        });
    }

    protected _showGetBtn() {
        this.getBtn.active = true;
        switch (this._artifactId) {
            case 40001: //风暴战斧
                //新手每日光环
                this.getBtn.active = giftLogic.dailyLightModal && giftLogic.dailyLightModal.isDailyLightValid;
                break;
            case 40004: //魔戒
            //vip8
            case 40005: //石中剑
                //vip12
                this.getBtn.active = true;
                break;
            case 40002: //法老面具
            case 40003: //杰克的罗盘
            case 40006: //死海文书
            case 40007: //灭霸手套
                this.getBtn.active = false;
                break;
        }
    }

    protected _showArrow() {
        let index = this._artifactList.indexOf(this._artifact.getIndex());
        this.btnPrevious.active = this.btnNext.active = true;
        if (index == 0) {
            this.btnPrevious.active = false;
        } else if (index == this._artifactList.length - 1) {
            this.btnNext.active = false;
        }
    }

    protected _showCompound() {
        let compound = artifactLogic.getArtifactCompound(this._artifactId);
        let id = compound.propertyIds[0];
        let cfg = artifactcompoundConfig[id - 1];
        if (cfg.artifactID.length == 1) {
            loadUtils.loadSpriteFrame(commonUtils.getArtifactIconUrl(this._artifactCfg.Id, this._artifact.getStar()), this.compoundIcon);
        } else if (cfg.artifactID.length == 2) {
            let compoundId = cfg.artifactID[0] == this._artifactId ? cfg.artifactID[1] : cfg.artifactID[0];
            loadUtils.loadSpriteFrame(commonUtils.getArtifactIconUrl(compoundId, this._artifact.getStar()), this.compoundIcon);
        }
        this.compoundStarNode.destroyAllChildren();
        for (let i = 0; i < compound.compoundLv; i++) {
            let node = cc.instantiate(this.compoundStar);
            node.parent = this.compoundStarNode;
        }
    }

    onPrevious() {
        let index = this._artifactList.indexOf(this._artifact.getIndex());
        if (index > 0) {
            this._artifactId = this._artifactList[index - 1];
            this._initData();
            this._initArtifact();
            this._showView();
            this._showCompound();
        }
        this._showArrow();
    }

    onNext() {
        let index = this._artifactList.indexOf(this._artifact.getIndex());
        if (index < this._artifactList.length - 1) {
            this._artifactId = this._artifactList[index + 1];
            this._initData();
            this._initArtifact();
            this._showView();
            this._showCompound();
        }
        this._showArrow();
    }

    /**跳转 */
    async onGet() {
        BasePanel.closePanel("ArtifactNewPanel");
        BasePanel.closePanel("ArtifactInfoPanel");
        BasePanel.closePanel("HeroInfoPanel");
        if (this._artifactId == 40001) {
            //新手每日光环
            if (giftLogic.dailyLightModal && giftLogic.dailyLightModal.isDailyLightValid) {
                gcc.core.showLayer("prefabs/panel/activity/ActivityDailyLightPanel");
            }
        } else if (this._artifactId == 40004 || this._artifactId == 40005) {
            let vip = artifactunlockConfig.find(a => a.ArtifactID == this._artifactId).vipunlock;
            gcc.core.showLayer("prefabs/panel/market/VIPPanel", { data: vip });
        }
    }

    /**合成 */
    async onUnlock() {
        try {
            this.setPanelTouchEnable(false);
            let reward = await heroLogic.doUnlockArtifact(this._artifact.getIndex());
            if (reward.length > 0) {
                this._playUnlockAnim(() => {
                    this.setPanelTouchEnable(true);
                    this._artifact = heroLogic.artifactUnlockInfo.getArtifact(this._artifact.getIndex());
                    this._showView();
                    gcc.core.showLayer("prefabs/panel/reward/RewardPanel", {
                        data: { cards: reward },
                        modalTouch: true,
                        callback: () => {
                            if (!storageUtils.getBoolean(Storage.ArtifactGuide)) {
                                storageUtils.setBoolean(Storage.ArtifactGuide.Key, true, true);
                                guideLogic.guideId = 140001;
                            }
                        }
                    });
                });
                commitLogic.artifactTrack(1);
            }
        } catch (e) {
            this.setPanelTouchEnable(true);
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    /**进阶 */
    async onEvolution() {
        if (this._artifact.getStar() == 5) {
            gm.toast(stringConfigMap.key_artifact_star_max.Value);
            return;
        }
        let consumeGood = this._artifact.getConsumeGood();
        let hasCnt = bagLogic.getGood(consumeGood.getIndex()).getAmount();
        if (hasCnt < consumeGood.getAmount()) {
            gm.toast(stringConfigMap.key_artifact_piece_not_enough.Value);
            return;
        }
        try {
            await heroLogic.doStrengArtifact(this._artifact);
            this._playEvoAnim();
            this._showEvolution();
            this._showTop();
            this._showCompound();
            commitLogic.artifactTrack(4);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    onBack() {
        EManager.emit(EName.onUpdateArtifact);
        this.closePanel();
    }

    onCompound() {
        gcc.core.showLayer("prefabs/panel/equip/ArtifactResonatePanel", { data: this._artifactId });
    }

    onTab(event: cc.Event.EventTouch, index: string) {
        this._nowTabIndex = Number(index);
        if (Number(index) == ArtifactTabIndex.Evolution) {
            this._showEvolution();
        } else if (Number(index) == ArtifactTabIndex.Forge) {
            this._showForge();
        }
    }

    onForgeLock() {
        gm.toast(unlockConfigMap.神器锻造.tips);
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);

        loadUtils.releaseAssetRecursively(this.bg.spriteFrame);

        let skeletonData = Object.values(this._artifactSkeletonData);
        for (let data of skeletonData) {
            if (data) {
                data.unlock();
                loadUtils.releaseAssetRecursively(data);
                data = null;
            }
        }
    }

}
