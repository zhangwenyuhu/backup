import {PopupPanel} from "../BasePanel";
import ArtifactForgeEffect from "../../component/Artifact/ArtifactForgeEffect";
import artifactforgeConfig, {artifactforgeConfigRow} from "../../../configs/artifactforgeConfig";
import List from "../../common/List";
import Artifact from "../../../data/card/Artifact";
import Property from "../../../data/Property";
import loadUtils from "../../../utils/LoadUtils";
import propertyConfig from "../../../configs/propertyConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/ArtifactForgeListPanel")
export default class ArtifactForgeListPanel extends PopupPanel {

    @property(cc.Label)
    nowForge: cc.Label = null;

    @property(cc.Node)
    desc3: cc.Node = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    unlockProperty: cc.Node = null;

    protected _artifact: Artifact = null;

    onInit(data) {
        super.onInit(data);
        this._artifact = data;
    }

    onLoad() {
        super.onLoad();
        this.unlockProperty.parent = null;
    }

    start() {
        super.start();
        if (this._artifact.getForgeLv() > 0) {
            this.nowForge.node.active = true;
            this.nowForge.string = `(当前锻造等级Lv.${this._artifact.getForgeLv()})`;
        } else {
            this.nowForge.node.active = false;
        }
        let addProps = this._getAddProp();
        if (addProps.prop.length > 0) {
            this.desc3.active = true;
            for (let prop of addProps.prop) {
                let node = cc.instantiate(this.unlockProperty);
                node.parent = this.content;
                this._showUnlockProperty(node, addProps.level, prop);
            }
        } else {
            this.desc3.active = false;
        }
    }

    protected _showUnlockProperty(node: cc.Node, lv: number, property: number[]) {
        let proNode = node.getChildByName("proNode");
        let icon = proNode.getChildByName("icon").getComponent(cc.Sprite);
        let text = proNode.getChildByName("text").getComponent(cc.Label);
        let unlock = node.getChildByName("label").getComponent(cc.Label);
        let c = Property.getConfig(property);
        loadUtils.loadSpriteFrame(`textures/ui/common/icon_property_${c.config.VarName}`, icon);
        text.string = propertyConfig[property[0] - 1].ProName;
        unlock.string = `(锻造等级达到Lv.${lv}解锁)`;
    }

    protected _getAddProp() {
        if (this._artifact.getForgeLv() == 0) {
            return {prop: artifactforgeConfig[0].AForgeProWarehouse, level: 1};
        } else if (this._artifact.getForgeLv() == this._artifact.getForgeLimit()) {
            return {prop: [], level: 1};
        } else {
            let nowProps = artifactforgeConfig[this._artifact.getForgeLv() - 1].AForgeProWarehouse;
            let nextCfg = null;
            for (let i = this._artifact.getForgeLv(); i < artifactforgeConfig.length; i++) {
                let cfg = artifactforgeConfig[i];
                if (cfg.AForgeProWarehouse.length > nowProps.length) {
                    nextCfg = cfg;
                    break;
                }
            }
            if (!nextCfg) {
                return {prop: [], level: 1};
            }
            let prop = [];
            let level = 1;
            for (let _prop of nextCfg.AForgeProWarehouse) {
                if (!this._existInProps(nowProps, _prop)) {
                    prop.push(_prop);
                    level = nextCfg.artifactForgeLV;
                }
            }
            return {prop: prop, level: level};
        }
    }

    protected _existInProps(props: number[], prop: number[]) {
        for (let _prop of props) {
            if (_prop[0] == prop[0]) {
                return true;
            }
        }
        return false;
    }

}
