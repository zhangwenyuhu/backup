import {PopupPanel} from "../BasePanel";
import Artifact from "../../../data/card/Artifact";
import CommonLoader from "../../common/CommonLoader";
import ArtifactInfo from "../../component/Artifact/ArtifactInfo";
import artifactforgeConfig from "../../../configs/artifactforgeConfig";
import Property from "../../../data/Property";
import ArtifactReForgeProperty from "../../component/Artifact/ArtifactReforgeProperty";
import artifactLogic from "../../../logics/ArtifactLogic";
import gm from "../../../manager/GameManager";
import ArtifactForgeNeed from "../../component/Artifact/ArtifactForgeNeed";
import {GoodId} from "../../../data/card/Good";
import EManager, {EName} from "../../../manager/EventManager";
import propertyConfig from "../../../configs/propertyConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/ArtifactReforgePanel")
export default class ArtifactReforgePanel extends PopupPanel {

    @property(CommonLoader)
    artifactInfo: CommonLoader = null;

    @property(cc.Node)
    bg: cc.Node = null;

    @property(CommonLoader)
    forgeNeed: CommonLoader = null;

    @property(cc.Node)
    propertyContent: cc.Node = null;

    @property(cc.Node)
    reforgeBtn: cc.Node = null;

    @property(cc.Node)
    btnNode: cc.Node = null;

    protected _artifact: Artifact = null;
    protected _forgePre = null;

    onInit(data) {
        super.onInit(data);
        this._artifact = data;
    }

    start() {
        super.start();
        this.artifactInfo.loaderNode.getComponent(ArtifactInfo).refresh(this._artifact.getIndex());
        this._showProps();
    }

    protected _showProps() {
        let proNumber = this._artifact.getForgeLv() > 0 ? artifactforgeConfig[this._artifact.getForgeLv() - 1].AForgeProNum : 0;
        this.bg.active = proNumber > 1;
        let props = this._artifact.getForgeProps();
        for (let i = 1; i <= 3; i++) {
            let property = this.propertyContent.getChildByName(`property${i}`);
            if (i <= proNumber) {
                property.active = true;
                let prop = props[i - 1];
                let params = [];
                params.push(prop.key);
                params.push(prop.data);
                let cfg = Property.getConfig(params);
                let nextProp = null;
                if (this._artifact.isForgeable()) {
                    nextProp = this._artifact.getNextForgeProp(prop.key);
                }
                property.getComponent(CommonLoader).loaderNode.getComponent(ArtifactReForgeProperty).refresh({
                    str: cfg.config.ProName,
                    strName: propertyConfig[prop.key - 1].ProName,
                    value1: prop.data,
                    pre: this._forgePre != null ? this._forgePre[i - 1] : null
                })
            } else {
                property.active = false;
            }
        }
        this.forgeNeed.loaderNode.getComponent(ArtifactForgeNeed).refresh(this._artifact.getForgeChangeCost());
        this._refreshBtns();
    }

    protected _refreshBtns() {
        this.reforgeBtn.active = !this._forgePre;
        this.btnNode.active = this._forgePre;
    }

    async onReforgePre() {
        let ret = this.forgeNeed.loaderNode.getComponent(ArtifactForgeNeed).checkGood();
        if (!ret.result) {
            if (ret.goodId == GoodId.Diamond) {
                gm.diamondLessToast();
                return;
            }
            gm.toast(ret.message);
            return;
        }
        try {
            this._forgePre = await artifactLogic.doForgeChangePre(this._artifact);
            this._showProps();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }

    async onSave() {
        try {
            await artifactLogic.doForgeChange(this._artifact);
            EManager.emit(EName.onArtifactReforge);
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            } else {
                throw e;
            }
        }
    }


    onTips() {
        gcc.core.showLayer("prefabs/panel/equip/ArtifactReForgeListPanel", {data: this._artifact, modalTouch: true});
    }

}
