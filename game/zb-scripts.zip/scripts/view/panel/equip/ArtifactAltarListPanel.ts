import {PopupPanel} from "../BasePanel";
import heroLogic from "../../../logics/HeroLogic";
import Property from "../../../data/Property";
import {stringConfigMap} from "../../../configs/stringConfig";
import propertyConfig, {propertyConfigMap} from "../../../configs/propertyConfig";
import loadUtils from "../../../utils/LoadUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/ArtifactAltarListPanel")
export default class ArtifactAltarListPanel extends PopupPanel {

    @property(cc.Node)
    property: cc.Node = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    unlockNode: cc.Node = null;

    @property(cc.Node)
    lockNode: cc.Node = null;

    @property(cc.Node)
    content2: cc.Node = null;

    onLoad() {
        super.onLoad();
        this.property.parent = this.unlockNode.parent = this.lockNode.parent = null;
    }

    start() {
        super.start();
        let levelAddition = heroLogic.artifactUnlockInfo.getAllLevelAddition();
        for (let i = 0; i < levelAddition.additions.length; i++) {
            let des = "";
            let _addition = levelAddition.additions[i];
            for (let j = 0; j < _addition.artifactPro.length; j++) {
                let addition = _addition.artifactPro[j];
                let cfg = Property.getConfig(addition);
                des += propertyConfig[addition[0] - 1].ProName;
                let value = addition[1];
                if (value < 1) {
                    des += `+${Math.floor(value * 100)}%`;
                } else {
                    des += `+${value}`;
                }
                if (j != _addition.artifactPro.length - 1) {
                    des += "，";
                }
            }
            des = `所有英雄${des}`;
            let node = null;
            if (i <= levelAddition.unlock) {
                node = cc.instantiate(this.unlockNode);
            } else {
                node = cc.instantiate(this.lockNode);
                des += `（Lv.${_addition.Level}解锁）`;
            }
            node.parent = this.content2;
            let label = node.getChildByName("Ex_label").getComponent(cc.Label);
            label.string = des;
        }
        this._showProperty(stringConfigMap.key_atk.Value, heroLogic.artifactUnlockInfo.getAtkAdd());
        this._showProperty(stringConfigMap.key_hp.Value, heroLogic.artifactUnlockInfo.getHpAdd());
    }

    protected _showProperty(str, value) {
        let node = cc.instantiate(this.property);
        node.parent = this.content;
        let icon = node.getChildByName("icon").getComponent(cc.Sprite);
        let text = node.getChildByName("text").getComponent(cc.Label);
        let label = node.getChildByName("label").getComponent(cc.Label);
        let iconName = propertyConfigMap[str].VarName;
        loadUtils.loadSpriteFrame(`textures/ui/common/icon_property_${iconName}`, icon);
        text.string = str;
        label.string = "+" + value.toString();
    }

}
