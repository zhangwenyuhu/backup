import { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import CommonLoader from "../../common/CommonLoader";
import Equip from "../../../data/card/Equip";
import EquipCard from "../../component/Equip/EquipCard";
import equipLevelConfig, { equipLevelConfigRow } from "../../../configs/equipLevelConfig";
import { EquipBO } from "../../../proxy/GameProxy";
import storageUtils from "../../../utils/StorageUtils";
import { Storage } from "../../../utils/DefineUtils";
import bagLogic from "../../../logics/BagLogic";
import cm from "../../../manager/ConfigManager";
import gm from "../../../manager/GameManager";
import heroConfig from "../../../configs/heroConfig";
import heroLogic from "../../../logics/HeroLogic";
import { GoodId } from "../../../data/card/Good";
import EManager, { EName } from "../../../manager/EventManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/EquipAutoMergePanel")
export default class EquipAutoMergePanel extends PopupPanel {

    @property(List)
    equips: List = null;

    @property(cc.Label)
    labelCost: cc.Label = null;

    @property(cc.Label)
    labelResult: cc.Label = null;

    @property(cc.Node)
    resultEquip: cc.Node = null;

    @property(cc.Button)
    btnConfirmMerge: cc.Button = null;

    protected _equip: Equip[] = [];
    protected _equipCofId: number = 0;
    protected _equipCof: equipLevelConfigRow = null;
    protected _ignoreEquipIds: string[] = [];
    onInit(data: any) {
        super.onInit(data);
        this._equipCofId = data;
        this._equipCof = cm.getEquipConfig(this._equipCofId);
    }

    start() {
        super.start();

        let mergeResult = bagLogic.getEquipAutoMergeMatEx(this._equipCofId);
        this._equip = mergeResult.mat;
        this.freshUI();
    }

    protected _isIgnored(equipId: string): boolean {
        if (this._ignoreEquipIds.length <= 0) { return false; }
        let index = this._ignoreEquipIds.findIndex((a) => { return a == equipId; })
        return index >= 0;
    }
    protected _addToIgnore(equipId: string) {
        let index = this._ignoreEquipIds.findIndex((a) => { return a == equipId; });
        if (index >= 0) { return; }
        this._ignoreEquipIds.push(equipId);
    }
    protected _removeFromIgnore(equipId: string) {
        let index = this._ignoreEquipIds.findIndex((a) => { return a == equipId; });
        if (index >= 0) { this._ignoreEquipIds.splice(index, 1); }
    }

    protected onRenderItem(item: cc.Node, index: number) {
        let data = this._equip[index];
        let cardLoader = item.getChildByName('equip').getComponent(CommonLoader).loaderNode;
        let comp = cardLoader.getComponent(EquipCard);
        comp.refresh({ equip: data });

        let ignore = this._isIgnored(data.getId());
        item.getChildByName('select').active = !ignore;
        comp.showMask(!ignore);

        let btn = item.getChildByName('btn');
        btn.off('click');
        btn.on('click', () => {
            let equipId: string = data.getId();
            let ignore = this._isIgnored(equipId);
            if (ignore) {
                this._removeFromIgnore(equipId);
            } else {
                this._addToIgnore(equipId);
            }
            this.freshUI();
        })
    }

    protected freshUI() {
        this.equips.getComponent(cc.Widget).updateAlignment();
        this.updateMatListView(this._equip);
        this.updateResultEquip();
        //this.resultEquip.parent.active = mergeResult.res;
        //this.btnConfirmMerge.interactable = mergeResult.res;
    }

    protected updateMatListView(mat: Equip[]) {
        this._equip = mat;
        this._equip.sort((a, b) => {
            /*
            let s_a: boolean = this._isIgnored(a.getId());
            let s_b: boolean = this._isIgnored(b.getId());
            if (s_a || s_b) {
                if (!s_a) { return -1; }
                if (!s_b) { return 1; }
                return 0;
            }*/
            if (a.getChargingLv() == b.getChargingLv()) {
                if (a.getStar() == b.getStar()) {
                    return a.getLevel() - b.getLevel();
                } else {
                    return a.getStar() - b.getStar();
                }
            } else {
                return a.getChargingLv() - b.getChargingLv();
            }
        })
        this.equips.numItems = this._equip.length;
    }

    // 显示智能合成的装备信息
    protected updateResultEquip() {
        let equipBo = new EquipBO();
        equipBo.equipCofId = this._equipCofId;
        let equip = new Equip(equipBo);

        let cardLoader = this.resultEquip.getComponent(CommonLoader).loaderNode;
        let comp = cardLoader.getComponent(EquipCard)
        comp.refresh({ equip: equip });

        let ignore = this._ignoreEquipIds.length;
        let targetNum = Math.floor((this._equip.length - ignore) / 3);
        this.labelResult.string = targetNum > 0 ? `x${targetNum}` : `材料不足`;
        this.labelResult.node.color = targetNum > 0 ? cc.Color.WHITE : cc.Color.RED;

        let cost = equipLevelConfig[this._equipCof.Rank - 1].EqComCost * targetNum;
        let has = bagLogic.getGood(GoodId.Gold).getAmount();
        this.labelCost.string = `${cost}`;
        this.labelCost.node.color = has >= cost ? cc.Color.WHITE : cc.Color.RED;

        this.btnConfirmMerge.interactable = targetNum > 0;
    }

    protected async onClickMerge() {
        let ignore = this._ignoreEquipIds.length;
        let targetNum = Math.floor((this._equip.length - ignore) / 3);
        if (targetNum <= 0) { return; }
        try {
            let mats: string[][] = [];
            let matEquip = this._equip.filter((v, i, a) => { return !this._isIgnored(v.getId()) });
            matEquip = matEquip.slice(0, targetNum * 3);

            let goMerge = async () => {
                for (let i = 0; i < targetNum; i++) {
                    let mat: string[] = [];
                    for (let j = 0; j < 3; j++) {
                        let index = 3 * i + j;
                        mat.push(matEquip[index].getId());
                    }
                    mats.push(mat);
                }
                let cost = equipLevelConfig[this._equipCof.Rank - 1].EqComCost * targetNum;
                await bagLogic.doAutoMergeEquip(this._equipCofId, mats);
                bagLogic.getGood(GoodId.Gold).changeAmount(-cost);
                EManager.emit(EName.onFreshPanel, 'EquipMergePanel');
                this.closePanel();
            }
            let ret = bagLogic.checkMatEquip(matEquip);
            if (ret.ret) {
                goMerge();
            } else {
                gm.dialog({
                    content: ret.msg,
                    okText: '继续',
                    confirm: () => {
                        goMerge();
                    }
                })
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}
