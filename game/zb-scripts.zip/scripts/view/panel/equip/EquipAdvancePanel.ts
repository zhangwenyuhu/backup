import Equip, { EquipPlace } from "../../../data/card/Equip";
import Hero from "../../../data/card/Hero";
import PlayerEquip from "../../../data/card/PlayerEquip";
import bagLogic from "../../../logics/BagLogic";
import guideLogic from "../../../logics/GuideLogic";
import heroLogic from "../../../logics/HeroLogic";
import commonUtils from "../../../utils/CommonUtils";
import { AdvanceType, AdvEffectName } from "../../../utils/DefineUtils";
import loadUtils from "../../../utils/LoadUtils";
import storageUtils from "../../../utils/StorageUtils";
import CommonLoader from "../../common/CommonLoader";
import List from "../../common/List";
import EquipAdvance from "../../component/Equip/EquipAdvance";
import EquipCard from "../../component/Equip/EquipCard";
import HeroCard from "../../component/Hero/HeroCard";
import PromptPoint from "../../component/PromptPoint";
import UnlockWrapper from '../../widget/unlock/UnlockWrapper';
import { FullscreenPanel } from "../BasePanel";
import { unlockConfigMap, unlockConfigRow } from './../../../configs/unlockConfig';
import { Storage } from './../../../utils/DefineUtils';
import gm from "../../../manager/GameManager";

const { ccclass, property, menu } = cc._decorator;

export type AdvanceModule = {
    name: string,
    prefab: string,
    btnLabel: string,
    type: AdvanceType,
}

enum TabState {
    Focus,
    Unfocus
}

let advModule: { [key: number]: AdvanceModule } = {
    1: {
        name: '强化',
        prefab: 'EquipUpgrade',
        btnLabel: '强化',
        type: AdvanceType.Upgrade,
    },
    2: {
        name: '升星',
        prefab: 'EquipStar',
        btnLabel: '升星',
        type: AdvanceType.Star,
    },
    3: {
        name: '充能',
        prefab: 'EquipCharging',
        btnLabel: '装备充能',
        type: AdvanceType.Charging,
    },
    4: {
        name: '重铸',
        prefab: 'EquipRecast',
        btnLabel: '重铸',
        type: AdvanceType.Recast,
    }
}

@ccclass
@menu("view/panel/equip/EquipAdvancePanel")
export default class EquipAdvancePanel extends FullscreenPanel {

    @property(cc.Node)
    advanceTabs: cc.Node[] = [];

    @property(cc.SpriteFrame)
    tabFrames: cc.SpriteFrame[] = [];

    @property(List)
    heroView: List = null;

    @property(cc.Node)
    btnPreHero: cc.Node = null;

    @property(cc.Node)
    btnNextHero: cc.Node = null;

    @property(cc.Node)
    heroEquips: cc.Node = null;

    @property(cc.Node)
    heroEquipItem: cc.Node = null;

    @property(cc.Node)
    equipInfo: cc.Node = null;

    @property(cc.Node)
    advModule: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    advEffect: cc.Node = null;

    @property(cc.Node)
    advLvUpEffect: cc.Node = null;

    @property(cc.Node)
    ignoreTouch: cc.Node = null;

    @property(PromptPoint)
    promptPoints: PromptPoint[] = [];

    protected _advanceType: number = -1;
    protected _defaultTab: number = AdvanceType.Upgrade;
    protected _selectHero: Hero = null;
    protected _selectEquip: PlayerEquip = null;
    protected _heros: Hero[] = [];
    protected _heroEquipNode: { [key: number]: cc.Node } = {};
    protected _prefabUrl: string = '';
    onInit(data: any) {
        super.onInit(data);
        if (data && data.equip instanceof PlayerEquip) {
            this._selectEquip = data.equip;
            this._defaultTab = data.type;
            this._selectHero = this._selectEquip.getHero();
        }
    }

    start() {
        super.start();

        this._heros = heroLogic.getHeroes({
            filter: (hero) => {
                return hero.getEquips() && hero.getEquips().length > 0 && hero.getSharePosition() <= 0;
            }
        });
        this._heros.sort((a, b) => { return b.getPower() - a.getPower(); })
        if (!this._selectEquip) {
            this._selectHero = this._heros[0];
            this._selectEquip = this.getDefaultEquip();
        }

        this._refreshHeroList();
        this._updateHeroEquips(true);
        this._updateSelectEquipDetail(this._selectEquip);
        this.advEffect.active = false;
        this.advLvUpEffect.active = false;

        this.onTabClick(null, this._defaultTab.toString());
        this._updateButtonsLock();

        for (let promptPoint of this.promptPoints) {
            promptPoint.refresh(this._selectHero, [this._selectEquip]);
        }

        do {
            if (!storageUtils.getBoolean(Storage.GuideStarEquip)) {
                if (this.canStar()) {
                    guideLogic.guideId = 270001;
                    break;
                }
            }
            if (!storageUtils.getBoolean(Storage.GuideChargeEquip)) {
                if (this.canCharge()) {
                    guideLogic.guideId = 280001;
                    break;
                }
            }
        } while (false);
    }

    onLoad() {
        super.onLoad();
        this.heroEquipItem.parent = null;
        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }
    onDestroy() {
        super.onDestroy();
        this.heroEquipItem.destroy();
        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    // 播放装备培养相关动画
    protected playEffect(node: cc.Node, name: string, callback: Function, data?: Function) {
        let ani = node.getComponent(cc.Animation);
        this.ignoreTouch.active = true;
        node.active = true;
        ani.play(name, 0);
        ani.off('finished');
        ani.on("finished", (e) => {
            if (callback) { callback(data); }
            ani.node.active = false;
            this.ignoreTouch.active = false;
        })
    }

    protected getDefaultEquip(): PlayerEquip {
        if (!this._selectHero) { return; }
        let equip = this._selectHero.getEquip(EquipPlace.Weapon);
        if (equip) { return equip as PlayerEquip; }

        equip = this._selectHero.getEquip(EquipPlace.Armor);
        if (equip) { return equip as PlayerEquip; }

        equip = this._selectHero.getEquip(EquipPlace.Helmet);
        if (equip) { return equip as PlayerEquip; }

        equip = this._selectHero.getEquip(EquipPlace.Shoes);
        if (equip) { return equip as PlayerEquip; }
    }

    protected _refreshHeroList() {
        this.heroView.getComponent(cc.Widget).updateAlignment();
        this.heroView.numItems = this._heros.length;

        let index = this._heros.findIndex((a) => { return a.getId() == this._selectHero.getId(); })
        let max: number = 4
        let min: number = Math.floor(max / 2);
        let scrollIndex: number = index - min;
        scrollIndex = scrollIndex < 0 ? 0 : scrollIndex;
        this.heroView.scrollTo(scrollIndex, 0.3);

        this._updateHeroSelectBtn();
    }

    protected onRenderHeroItem(node: cc.Node, index: number) {
        let data = this._heros[index];
        let bSelect: boolean = this._selectHero && this._selectHero.getId() == data.getId();

        let hero = node.getChildByName('hero');
        hero.destroyAllChildren();
        let tmp = cc.instantiate(this.heroItem);
        tmp.parent = hero;
        let comp = tmp.getComponent(CommonLoader).loaderNode.getComponent(HeroCard);
        comp.refresh(data);
        //comp.showOpacity(bSelect ? 255 : 88);
        comp.showMask(!bSelect);

        node.getChildByName('select').active = bSelect;
        node.scale = bSelect ? 1.1 : 1;

        let btn = node.getChildByName('btn');
        btn.getComponent(cc.Button).clickEvents[0].customEventData = `${index}`;
        //btn.off('click');
        //btn.on('click', () => { this._changeSelectHero(data); })
    }
    protected onClickHero(sender: cc.Event.EventTouch, custom: string) {
        let index: number = parseInt(custom);
        if (this._heros[index]) {
            this._changeSelectHero(this._heros[index]);
        }
    }
    protected _changeSelectHero(hero: Hero) {
        if (this._selectHero && this._selectHero.getId() == hero.getId()) { return; }

        this._selectHero = hero;
        this._selectEquip = this.getDefaultEquip();
        this._refreshHeroList();
        this._updateHeroEquips(false);
        this._updateSelectEquipDetail(this._selectEquip);
        this._showAdvanceView(this._advanceType);

        for (let promptPoint of this.promptPoints) {
            promptPoint.refresh(this._selectHero, [this._selectEquip]);
        }
    }
    protected _changeSelectEquip(equip: PlayerEquip) {
        if (!equip) { return; }
        if (this._selectEquip && this._selectEquip.getId() == equip.getId()) { return; }

        this._selectEquip = equip;
        this._updateHeroEquips(false);
        this._updateSelectEquipDetail(this._selectEquip);
        this._showAdvanceView(this._advanceType);

        for (let promptPoint of this.promptPoints) {
            promptPoint.refresh(this._selectHero, [this._selectEquip]);
        }
    }
    // 显示选择的英雄携带的装备
    protected _updateHeroEquips(bInit: boolean) {
        if (bInit) {
            this.heroEquips.destroyAllChildren();
            for (let i = EquipPlace.Weapon; i <= EquipPlace.Shoes; i++) {
                let tmp = cc.instantiate(this.heroEquipItem);
                tmp.parent = this.heroEquips;
                this._heroEquipNode[i] = tmp;
            }
        }
        for (let i = EquipPlace.Weapon; i <= EquipPlace.Shoes; i++) {
            if (this._heroEquipNode[i]) {
                let equip = this._selectHero ? this._selectHero.getEquip(i) as PlayerEquip : null;
                this._renderHeroEquipItem(this._heroEquipNode[i], equip, i);
            }
        }
    }

    protected _renderHeroEquipItem(node: cc.Node, equip: PlayerEquip, place: number) {
        let has: boolean = equip ? true : false;
        let select: boolean = has && this._selectEquip && equip.getId() == this._selectEquip.getId();

        node.getChildByName('select').active = select;

        let equipNode = node.getChildByName('equip');
        let equipDefault = node.getChildByName('default');
        equipNode.active = has;
        equipNode.scale = select ? 1.05 : 1;
        equipDefault.active = !has;

        if (has) {
            let equipCard: cc.Node;
            if (equipNode.childrenCount <= 0) {
                let tmp = cc.instantiate(this.equipItem);
                tmp.parent = equipNode;
                equipCard = tmp;
            } else {
                equipCard = equipNode.children[0];
            }

            let comp = equipCard.getComponent(CommonLoader).loaderNode.getComponent(EquipCard);
            comp.refreshOutfitIcon = true;
            comp.refresh({ equip: equip, hero: equip.getHero() });
        } else {
            let icon = equipDefault.getChildByName('place').getComponent(cc.Sprite);
            loadUtils.loadSpriteFrame(`textures/icon/equip/equip_wear${place}`, icon);
        }


        node.off('click');
        node.on('click', () => { this._changeSelectEquip(equip); })
    }

    protected _updateSelectEquipDetail(equip: Equip) {
        //if (!equip) { return; }
        let name = this.equipInfo.getChildByName('bg').getChildByName('name');
        name.getComponent(cc.Label).string = equip ? equip.getName() : '';

        let icon = this.equipInfo.getChildByName('icon');
        icon.active = equip ? true : false;
        if (icon.active) {
            let url: string = commonUtils.getEquipIconUrl(equip.getIndex());
            loadUtils.loadSpriteFrame(url, icon.getComponent(cc.Sprite));
        }
    }

    onTabClick(event: cc.Event.EventTouch, index: string) {
        let type: number = parseInt(index);
        if (this._advanceType == type) { return; }
        let ret = this._isEquipAdvanceUnlock(type);
        if (!ret.ret) { gm.toast(ret.msg); return; }

        let tab = this.advanceTabs[this._advanceType - 1];
        if (tab) {
            let button = tab.getChildByName("button").getComponent(cc.Sprite);
            button.spriteFrame = this.tabFrames[TabState.Unfocus];
        }

        this._advanceType = type;
        tab = this.advanceTabs[this._advanceType - 1];
        let button = tab.getChildByName("button").getComponent(cc.Sprite);
        button.spriteFrame = this.tabFrames[TabState.Focus];

        this._showAdvanceView(type);
    }

    protected _updateButtonsLock() {
        for (let i = 0; i < this.advanceTabs.length; i++) {
            let type = i + 1;
            let unlock = this._isEquipAdvanceUnlock(type);
            let lock = this.advanceTabs[i].getChildByName('lock');
            if (lock) { lock.active = !unlock.ret; }
        }
    }

    protected _isEquipAdvanceUnlock(type: number) {
        let cof: unlockConfigRow = null;
        if (type == AdvanceType.Star) {
            cof = unlockConfigMap.装备升星;
        } else if (type == AdvanceType.Charging) {
            cof = unlockConfigMap.装备充能;
        } else if (type == AdvanceType.Recast) {
            cof = unlockConfigMap.装备重铸;
        }
        let ret = cof ? UnlockWrapper.isUnlock(cof) : true;
        let msg = cof ? cof.tips : '';
        return { ret: ret, msg: msg }
    }

    canCharge(): boolean {
        if (!UnlockWrapper.isUnlock(unlockConfigMap.装备充能)) {
            return false;
        }

        let ret = bagLogic.canChargingEquip(this._selectEquip);
        return ret.result;
    }

    canStar(): boolean {
        if (!UnlockWrapper.isUnlock(unlockConfigMap.装备升星)) {
            return false;
        }

        let ret = bagLogic.canRefineEquip(this._selectEquip);
        return ret.result;
    }

    protected async _showAdvanceView(type: AdvanceType) {
        let advance: cc.Node;
        let module = advModule[type]
        if (!module.prefab) { return; }
        if (this._prefabUrl == module.prefab) {
            advance = this.advModule.children[0];
        } else {
            let url: string = this._getModulePrefabUrl(type);
            let prefab = cc.loader.getRes(url, cc.Prefab);
            if (!prefab) { prefab = await loadUtils.loadRes(url, cc.Prefab) as cc.Prefab; }

            this.advModule.active = true;
            this.advModule.getComponent(cc.Widget).updateAlignment();
            this.advModule.destroyAllChildren();

            advance = cc.instantiate(prefab) as cc.Node;
            advance.setContentSize(this.advModule.getContentSize());
            advance.position = cc.v2();
            advance.parent = this.advModule;
            this._prefabUrl = module.prefab;
        }
        let comp = advance.getComponent(EquipAdvance);
        comp.init(type, this._selectEquip as PlayerEquip);
        comp.refresh();
        comp.registerCallback(this._callback_freshEquip.bind(this));
        comp.registerEffectCall(this._callback_effectCall.bind(this));
    }

    protected _callback_freshEquip(type: AdvanceType) {
        this._updateHeroEquips(false);
        this._updateSelectEquipDetail(this._selectEquip);
    }

    protected _callback_effectCall(name: string, callback: Function, data?: Function) {
        let node: cc.Node;
        if (name == AdvEffectName.levelUp) {
            node = this.advLvUpEffect;
        } else if (name == AdvEffectName.recast) {
            node = this.advEffect;
        }
        if (node) { this.playEffect(node, name, callback, data); }
    }

    protected _getModulePrefabUrl(type: AdvanceType) {
        return `prefabs/panel/equip/module/${advModule[type].prefab}`;
    }

    protected onClickPreHero() {
        let selectIndex = this._heros.findIndex((v, i, a) => { return v.getId() == this._selectHero.getId(); })
        if (selectIndex <= 0) { return; }
        this._changeSelectHero(this._heros[selectIndex - 1]);
    }

    protected onClickNextHero() {
        let selectIndex = this._heros.findIndex((v, i, a) => { return v.getId() == this._selectHero.getId(); })
        if (selectIndex + 1 >= this._heros.length) { return; }
        this._changeSelectHero(this._heros[selectIndex + 1]);
    }

    protected _updateHeroSelectBtn() {
        let selectIndex = this._heros.findIndex((v, i, a) => { return v.getId() == this._selectHero.getId(); })
        this.btnPreHero.active = selectIndex > 0;
        this.btnNextHero.active = selectIndex + 1 < this._heros.length;
    }
}
