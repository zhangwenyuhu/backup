import {PopupPanel} from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import artifactLogic from "../../../logics/ArtifactLogic";
import artifactcompoundConfig from "../../../configs/artifactcompoundConfig";
import ArtifactResonateList from "../../component/Artifact/ArtifactResonateList";
import ArtifactInfo from "../../component/Artifact/ArtifactInfo";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/ArtifactCompoundPanel")
export default class ArtifactCompoundPanel extends PopupPanel {

    @property(cc.Sprite)
    chains: cc.Sprite = null;

    @property({
        type: cc.Material
    })
    materials: cc.Material[] = [];

    @property(CommonLoader)
    artifact1: CommonLoader = null;

    @property(CommonLoader)
    artifact2: CommonLoader = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    compoundItem: cc.Node = null;

    protected _artifactId = 0;

    onInit(data) {
        super.onInit(data);
        this._artifactId = data;
    }

    onLoad() {
        super.onLoad();
        this.compoundItem.parent = null;
    }

    start() {
        super.start();
        let compound = artifactLogic.getArtifactCompound(this._artifactId);
        let id = compound.propertyIds[0];
        let cfg = artifactcompoundConfig[id - 1];
        let index = 0;
        for (let i = 0; i < compound.propertyIds.length; i++) {
            let id = compound.propertyIds[i];
            let cfg = artifactcompoundConfig[id - 1];
            for (let prop of cfg.artifactComPro) {
                let node = cc.instantiate(this.compoundItem);
                node.parent = this.content;
                node.getComponent(CommonLoader).loaderNode.getComponent(ArtifactResonateList).refresh({prop: prop, index: index, star: i, unlock: compound.compoundLv > i});
                index++;
            }
        }
        if (cfg.artifactID.length == 1) {
            this.artifact1.node.x = 0;
            this.chains.node.active = false;
            this.artifact2.node.active = false;
            this.artifact1.loaderNode.getComponent(ArtifactInfo).refresh(this._artifactId);
        } else if (cfg.artifactID.length == 2) {
            let compoundId = cfg.artifactID[0] == this._artifactId ? cfg.artifactID[1] : cfg.artifactID[0];
            this.artifact1.loaderNode.getComponent(ArtifactInfo).refresh(this._artifactId);
            this.artifact2.loaderNode.getComponent(ArtifactInfo).refresh(compoundId);
        }
        this.chains.setMaterial(0, compound.compoundLv > 0 ? this.materials[0] : this.materials[1]);
    }

}
