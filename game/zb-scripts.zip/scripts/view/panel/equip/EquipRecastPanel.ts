import { stringConfigMap } from './../../../configs/stringConfig';
import { PopupPanel } from "../BasePanel";
import Equip from "../../../data/card/Equip";
import commonUtils from "../../../utils/CommonUtils";
import stringUtils from '../../../utils/StringUtils';
import PlayerEquip from '../../../data/card/PlayerEquip';
import bagLogic from '../../../logics/BagLogic';
import Good from '../../../data/card/Good';
import gm from '../../../manager/GameManager';
import EManager, { EName } from '../../../manager/EventManager';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/EquipRecastPanel")
export default class EquipRecastPanel extends PopupPanel {

    @property(cc.Sprite)
    prevIco: cc.Sprite = null;

    @property(cc.Sprite)
    nowIco: cc.Sprite = null;

    @property(cc.Label)
    prevLabel: cc.Label = null;

    @property(cc.Label)
    nowLabel: cc.Label = null;

    @property(cc.RichText)
    labelTip: cc.RichText = null;

    @property(cc.Label)
    labelHas: cc.Label = null;

    @property(cc.Label)
    labelNeed: cc.Label = null;

    protected _prevFaction: number = 0;
    protected _nowFaction: number = 0;
    protected _equip: PlayerEquip = null;
    protected _confirm: Function = null;
    protected _cancel: Function = null;
    protected _effect: Function = null;

    onInit(data: {
        prevFaction: number,
        nowFaction: number,
        equip: PlayerEquip,
        confirm: Function,
        cancel: Function,
        effect: Function
    }) {
        this._prevFaction = data.prevFaction;
        this._nowFaction = data.nowFaction;
        this._equip = data.equip;
        this._confirm = data.confirm;
        this._cancel = data.cancel;
        this._effect = data.effect;
    }

    start() {
        super.start();

        this.prevIco.spriteFrame = cc.loader.getRes(commonUtils.getHeroFactionUrl(this._prevFaction), cc.SpriteFrame);
        this.nowIco.spriteFrame = cc.loader.getRes(commonUtils.getHeroFactionUrl(this._nowFaction), cc.SpriteFrame);
        this.prevLabel.string = stringConfigMap[`key_faction_${this._prevFaction}`].Value + stringConfigMap.key_race.Value;
        this.nowLabel.string = stringConfigMap[`key_faction_${this._nowFaction}`].Value + stringConfigMap.key_race.Value;
        this.labelTip.string = stringUtils.getString(stringConfigMap.key_equip_recast_tip.Value, {
            faction: stringConfigMap[`key_faction_${this._nowFaction}`].Value,
            value: `${Math.floor(Equip.campAddition * 100)}%`
        });

        this._updateCost();
        this._eventListeners = [];
        let listener = EManager.addEvent(EName.onApplyOrder, (data: any) => {
            this._updateCost();
        })
        this._eventListeners.push(listener);
    }

    protected _updateCost() {
        let hasDiamond = bagLogic.getGood(Good.GoodId.Diamond).getAmount();
        let needDiamond = bagLogic.getConsumeDiamondForRecastEquip(this._equip);
        this.labelHas.string = stringUtils.formatAmount(hasDiamond);
        this.labelHas.node.color = hasDiamond < needDiamond ? cc.Color.RED : cc.Color.WHITE;
        this.labelNeed.string = "/" + needDiamond.toString();
    }

    async onContinue() {
        let num = bagLogic.getConsumeDiamondForRecastEquip(this._equip);
        if (!gm.enoughDimond(num)) {
            gm.diamondLessToast();
            return;
        }

        if (this._cancel) {
            this._cancel();
        }
        this.closePanel();

        try {
            if (this._effect) {
                let id = this._equip.getId();
                let nowFaction = this._nowFaction;
                this._effect(async (callback: Function) => {
                    let equip = bagLogic.getEquip(id);
                    await bagLogic.doRecastEquip(equip, nowFaction, callback);
                })
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    onConfirm() {
        if (this._confirm) {
            this._confirm();
        }
        this.closePanel();
        EManager.emit(EName.onFreshPanel, 'EquipAdvance');
    }

    onCancel() {
        if (this._cancel) {
            this._cancel();
        }
        this.closePanel();
    }
}
