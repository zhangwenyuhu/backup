import { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import CommonLoader from "../../common/CommonLoader";
import Equip from "../../../data/card/Equip";
import EquipCard from "../../component/Equip/EquipCard";
import bagLogic from "../../../logics/BagLogic";
import EquipFilter from "../../component/Equip/EquipFilter";
import cm from "../../../manager/ConfigManager";
import { EquipBO } from "../../../proxy/GameProxy";
import equipConfig from "../../../configs/equipConfig";
import gm from "../../../manager/GameManager";
import equipLevelConfig from "../../../configs/equipLevelConfig";
import towerLogic from "../../../logics/TowerLogic";
import EManager, { EName } from "../../../manager/EventManager";
import {stringConfigMap} from "../../../configs/stringConfig";
import stringUtils from "../../../utils/StringUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/EquipMergePanel")
export default class EquipMergePanel extends PopupPanel {

    @property(List)
    equips: List = null;

    @property(cc.Node)
    filter: cc.Node = null;

    protected _equip: Equip[] = [];
    protected _career: number = 0;
    protected _place: number = 0;
    onInit(data: any) {
        super.onInit(data);
    }

    start() {
        super.start();

        let loader = this.filter.getComponent(CommonLoader).loaderNode;
        let comp = loader.getComponent(EquipFilter);
        comp.registerEquipFilter(this.onSelectCareer.bind(this), this.onSelectPlace.bind(this))
        comp.setBgWidth(this.filter.parent.width - 20);

        this.freshEquipUI();

        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data == "EquipMergePanel") {
                this.freshEquipUI();
            }
        });
        this._eventListeners.push(listener);
    }

    protected onSelectCareer(career: number) {
        if (this._career == career) { return; }
        this._career = career;
        this.freshEquipUI();
    }
    protected onSelectPlace(place: number) {
        if (this._place == place) { return; }
        this._place = place;
        this.freshEquipUI();
    }

    protected onRenderItem(item: cc.Node, index: number) {
        let data = this._equip[index];

        let comp = item.getChildByName('equip').getComponent(CommonLoader).loaderNode.getComponent(EquipCard);
        comp.refresh({ equip: data });

        let mergeResult = bagLogic.getEquipAutoMergeMatEx(data.config.Id);
        let canMerge: boolean = mergeResult.res;
        let ret = this.isMergeUnlock(data.config.Rank);
        canMerge = !ret.result ? false : canMerge;
        comp.showMask(!canMerge);

        item.getChildByName('lock').active = !ret.result;
        item.getChildByName('red').active = canMerge;

        let btn = item.getChildByName('btn').getComponent(cc.Button);
        btn.clickEvents[0].customEventData = `${data.getIndex()}`;
    }

    protected getTmpEquip(cofId: number): Equip {
        let equipBo = new EquipBO();
        equipBo.equipCofId = cofId;
        return new Equip(equipBo);
    }

    protected onClickSelectItem(sender: cc.Event.EventTouch, customData: string) {
        let equipCofId: number = parseInt(customData);
        let cfg = cm.getEquipConfig(equipCofId);
        let ret = this.isMergeUnlock(cfg.Rank)
        if (!ret.result) {
            gm.toast(stringUtils.getString(stringConfigMap.key_auto_638.Value, {p1: ret.limit}));
            return;
        }
        let mergeResult = bagLogic.getEquipAutoMergeMat(equipCofId, cfg.Rank - 1);
        if (mergeResult.res) {
            gcc.core.showLayer('prefabs/panel/equip/EquipAutoMergePanel', { data: equipCofId });
        } else {
            gm.toast('合成该装备的材料不足');
        }
    }

    protected isMergeUnlock(equipRank: number): { result: boolean, limit: number } {
        let cfg = equipLevelConfig[equipRank - 1];
        if (!cfg) { return { result: false, limit: 0 }; }

        let towerLevel = towerLogic.getCurrentTower();
        return { result: towerLevel > cfg.EqComLimit, limit: cfg.EqComLimit }
    }

    protected freshEquipUI() {
        this.equips.getComponent(cc.Widget).updateAlignment();
        this._equip = [];
        for (let i = 0; i < equipConfig.length; i++) {
            let cof = equipConfig[i];
            if (cof.Rank > 1 && (this._career == 0 || this._career == cof.Career) &&
                (this._place == 0 || this._place == cof.Place)) {
                this._equip.push(this.getTmpEquip(equipConfig[i].Id));
            }
        }

        this._equip.sort((a, b) => { return a.getIndex() - b.getIndex(); })
        this.equips.numItems = this._equip.length;
    }
}
