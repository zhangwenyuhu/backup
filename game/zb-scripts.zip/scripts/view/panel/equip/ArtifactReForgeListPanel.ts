import {PopupPanel} from "../BasePanel";
import ArtifactForgeEffect from "../../component/Artifact/ArtifactForgeEffect";
import artifactforgeConfig, {artifactforgeConfigRow} from "../../../configs/artifactforgeConfig";
import List from "../../common/List";
import Artifact from "../../../data/card/Artifact";
import Property from "../../../data/Property";
import loadUtils from "../../../utils/LoadUtils";
import propertyConfig from "../../../configs/propertyConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/ArtifactReForgeListPanel")
export default class ArtifactReForgeListPanel extends PopupPanel {

    @property(cc.Label)
    nowForge: cc.Label = null;

    @property(cc.Node)
    content: cc.Node = null;

    @property(cc.Node)
    unlockProperty: cc.Node = null;

    protected _artifact: Artifact = null;

    onInit(data) {
        super.onInit(data);
        this._artifact = data;
    }

    onLoad() {
        super.onLoad();
        this.unlockProperty.parent = null;
    }

    start() {
        super.start();
        if (this._artifact.getForgeLv() > 0) {
            this.nowForge.node.active = true;
            this.nowForge.string = `(当前锻造等级Lv.${this._artifact.getForgeLv()})`;
        } else {
            this.nowForge.node.active = false;
        }
        for (let cfg of this._artifact.getCurrentForgeProp()) {
            let node = cc.instantiate(this.unlockProperty);
            node.parent = this.content;
            this._showUnlockProperty(node, cfg);
        }
    }

    protected _showUnlockProperty(node: cc.Node, property: number[]) {
        let proNode = node.getChildByName("proNode");
        let icon = proNode.getChildByName("icon").getComponent(cc.Sprite);
        let text = proNode.getChildByName("text").getComponent(cc.Label);
        let c = Property.getConfig(property);
        loadUtils.loadSpriteFrame(`textures/ui/common/icon_property_${c.config.VarName}`, icon);
        text.string = propertyConfig[property[0] - 1].ProName;
    }

}
