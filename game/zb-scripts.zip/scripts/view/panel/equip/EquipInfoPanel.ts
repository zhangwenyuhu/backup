import { propertyConfigRow, propertyConfigMap } from './../../../configs/propertyConfig';
import { PopupPanel } from "../BasePanel";
import Equip from "../../../data/card/Equip";
import { RefreshLabel, RefreshNode, RefreshSprite } from "../../../decorator/RefreshDecorator";
import stringUtils from "../../../utils/StringUtils";
import { stringConfigMap } from "../../../configs/stringConfig";
import commonUtils from "../../../utils/CommonUtils";
import CommonLoader from "../../common/CommonLoader";
import EquipCard from "../../component/Equip/EquipCard";
import Good, { GoodId } from "../../../data/card/Good";
import EManager, { EName } from "../../../manager/EventManager";
import Card from "../../../data/card/Card";
import heroLogic from "../../../logics/HeroLogic";
import Hero from "../../../data/card/Hero";
import gm from "../../../manager/GameManager";
import shopLogic from "../../../logics/ShopLogic";
import Property from "../../../data/Property";
import bagLogic from "../../../logics/BagLogic";
import heroUtils from "../../../utils/HeroUtils";
import Artifact from "../../../data/card/Artifact";
import PlayerEquip from "../../../data/card/PlayerEquip";
import PlayerHero from "../../../data/card/PlayerHero";
import { AdvanceType, EvolutionType } from '../../../utils/DefineUtils';
import isInstanceOf = rpgfight.isInstanceOf;
import UnlockWrapper from '../../widget/unlock/UnlockWrapper';
import { unlockConfigMap } from '../../../configs/unlockConfig';
import equipLevelConfig from '../../../configs/equipLevelConfig';
import PromptPoint from '../../component/PromptPoint';


const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/EquipInfoPanel")
export default class EquipInfoPanel extends PopupPanel {
    equip: Equip = null;

    @RefreshLabel({
        getData: (caller: EquipInfoPanel) => { return caller.equip },
        getValue: (caller: Equip) => { return caller.getName() }
    })
    @property(cc.Label)
    labelTitle: cc.Label = null;

    @RefreshLabel({
        eventName: Equip.Event.onStarDirty,
        getData: (caller: EquipInfoPanel) => { return caller.equip },
        getValue: (caller: Equip) => { return caller.getPower() },
        getString: (value: number) => { return stringUtils.toFixed(value, 2) }
    })
    @property(cc.Label)
    labelPower: cc.Label = null;

    @RefreshLabel({
        getData: (caller: EquipInfoPanel) => { return caller.equip },
        getValue: (caller: Equip) => { return caller.getEquipCareer() },
        getString: (value: number) => { return stringConfigMap[`key_equip_type_${value}`].Value }
    })
    @property(cc.Label)
    labelType: cc.Label = null;

    @RefreshSprite({
        getData: (caller: EquipInfoPanel) => { return caller.equip },
        getValue: (call: Equip) => { return call.getEquipCareer() },
        updateSpriteFrame: async (sprite: cc.Sprite, value: number) => {
            sprite.spriteFrame = cc.loader.getRes(commonUtils.getEquipTypeUrl(value), cc.SpriteFrame) as cc.SpriteFrame;
        }
    })
    @property(cc.Sprite)
    iconType: cc.Sprite = null;

    @RefreshLabel({
        eventName: Equip.Event.onCampDirty,
        getData: (caller: EquipInfoPanel) => { return caller.equip },
        getValue: (caller: Equip) => { return caller.getCamp() },
        getString: (value: number) => {
            if (value > 0) {
                return stringConfigMap[`key_faction_${value}`].Value;
            }
            return stringConfigMap.key_none.Value;
        }
    })
    @property(cc.Label)
    labelAddition: cc.Label = null;

    @RefreshSprite({
        eventName: Equip.Event.onCampDirty,
        getData: (caller: EquipInfoPanel) => { return caller.equip },
        getValue: (caller: Equip) => { return caller.getCamp() },
        updateSpriteFrame: async (sprite: cc.Sprite, value: number) => {
            if (value > 0) {
                sprite.spriteFrame = cc.loader.getRes(commonUtils.getHeroFactionUrl(value), cc.SpriteFrame) as cc.SpriteFrame;
            }
            else {
                sprite.spriteFrame = null;
            }
        }
    })
    @property(cc.Sprite)
    iconAddition: cc.Sprite = null;

    @RefreshNode({
        eventName: Equip.Event.onCampDirty,
        getData: (caller: EquipInfoPanel) => { return caller.equip },
        refresh: (node: cc.Node, equip: Equip) => {
            node.active = equip.getCamp() > 0;
        }
    })
    @property(cc.Node)
    itemAddition: cc.Node = null;

    @property(cc.Node)
    propertyItem: cc.Node = null;

    @property(CommonLoader)
    equipIcon: CommonLoader = null;

    @RefreshNode({
        eventName: Equip.Event.onStarDirty,
        getData: (caller: EquipInfoPanel) => { return caller.equip },
        refresh: (node: cc.Node, equip: Equip) => {
            if (equip && equip.getRank() > 1) {
                node.width = 166;
            }
            else {
                node.width = 240;
            }
        }
    })
    @property(cc.Node)
    btnOff: cc.Node = null;

    @RefreshNode({
        eventName: Equip.Event.onStarDirty,
        getData: (caller: EquipInfoPanel) => { return caller.equip },
        refresh: (node: cc.Node, equip: Equip) => {
            if (equip && equip.getRank() > 1) {
                node.width = 166;
            }
            else {
                node.width = 240;
            }
        }
    })
    @property(cc.Node)
    btnReplace: cc.Node = null;

    @RefreshNode({
        eventName: Equip.Event.onStarDirty,
        getData: (caller: EquipInfoPanel) => { return caller.equip },
        refresh: (node: cc.Node, equip: Equip) => {
            node.active = equip && !(equip instanceof Artifact) && equip.getRank() > 1;
        }
    })
    @property(cc.Node)
    btnStrong: cc.Node = null;

    @RefreshNode({
        eventName: Equip.Event.onStarDirty,
        getData: (caller: EquipInfoPanel) => { return caller.equip },
        refresh: (node: cc.Node, equip: Equip) => {
            let layout = node.getComponent(cc.Layout);
            if (equip && !(equip instanceof Artifact) && equip.getMaxStar() > 0) {
                layout.spacingX = 8;
            }
            else {
                layout.spacingX = 30;
            }
        }
    })
    @property(cc.Node)
    buttons: cc.Node = null;

    @property(cc.Node)
    scrollView: cc.Node = null;

    @property(cc.Node)
    content_bg: cc.Node = null;

    @property(cc.Node)
    buyBtn: cc.Node = null;

    @property(cc.Node)
    seeBtn: cc.Node = null;

    @property(cc.Node)
    splitBtn: cc.Node = null;

    @property(cc.Node)
    buyPriceNode: cc.Node = null;

    @property(cc.Sprite)
    price_icon: cc.Sprite = null;

    @property(cc.Label)
    price: cc.Label = null;

    @property(cc.Node)
    baseProperty: cc.Node = null;

    @property(cc.Node)
    basePropertyBg: cc.Node = null;

    @property(cc.Node)
    attachProperty: cc.Node = null;

    @property(cc.Node)
    attachPropertyBg: cc.Node = null;

    @property(cc.Node)
    factionProperty: cc.Node = null;

    @property(cc.Node)
    factionPropertyBg: cc.Node = null;

    @property(cc.Node)
    outfitProperty: cc.Node = null;

    @property(cc.Node)
    outfitPropertyBg: cc.Node = null;

    @property(cc.Node)
    outfitItem: cc.Node = null;

    @property(cc.Node)
    outfitDescItem: cc.Node = null;

    @property(cc.Node)
    shareNode: cc.Node = null;

    @property(cc.Node)
    btnMerge: cc.Node = null;

    @property(PromptPoint)
    promptPoint: PromptPoint = null;

    protected _hero: Hero = null;
    onInit(data: {
        equip: Equip,
        split: boolean,
        hero?: Hero,
        share?: boolean
    }) {
        this.equip = data.equip;
        this._hero = data.hero;
    }

    onLoad() {
        super.onLoad();

        this.propertyItem.parent = null;
        if (this.outfitItem) {
            this.outfitItem.parent = null;
        }
        if (this.outfitDescItem) {
            this.outfitDescItem.parent = null;
        }

        this.registerEvents();
    }

    onDestroy() {
        this.propertyItem.destroy();
        if (this.outfitItem) {
            this.outfitItem.destroy();
        }
        if (this.outfitDescItem) {
            this.outfitDescItem.destroy();
        }

        super.onDestroy();
    }

    start() {
        super.start();
        let equipQuality: { qualityHead: string, qualityColor: string, qualityStr: string };
        if (this.equip instanceof Artifact) {
            equipQuality = heroUtils.getArtifactQuality();
        } else {
            equipQuality = heroUtils.getEquipQuality(this.equip.getRank());
        }
        let color = cc.Color.WHITE;
        color.fromHEX(equipQuality.qualityColor);

        if (this.labelTitle) {
            this.labelTitle.node.color = color;
        }

        let comp = this.equipIcon.loaderNode.getComponent(EquipCard);
        comp.refreshOutfitIcon = true;
        comp.refresh({ equip: this.equip, hero: this._hero });
        this._updateProperties();
        this._updateButtons();

        this.promptPoint.refresh(this._hero, [this.equip]);
    }

    registerEvents() {
        let listeners = EManager.addEventArray([Equip.Event.onStarDirty, Equip.Event.onCampDirty, Equip.Event.onChargingLvDirty, Equip.Event.onLevelDirty], (data: any) => {
            if (this.equip == data.target) {
                this._updateProperties();
                let comp = this.equipIcon.loaderNode.getComponent(EquipCard);
                comp.refreshOutfitIcon = true;
                comp.refresh({ equip: this.equip });
            }
        })
        this._eventListeners.pushList(listeners);

        let listener = EManager.addEvent(EName.onUpdateEquip, (hero: Hero) => {
            this.closePanel();
        })
        this._eventListeners.push(listener);

        listener = EManager.addEvent(Equip.Event.onChargingLvDirty, (data: any) => {
            if (this.equip.heroId && this.equip.heroId == data.target.heroId) {
                this._updateProperties();
                let comp = this.equipIcon.loaderNode.getComponent(EquipCard);
                comp.refreshOutfitIcon = true;
                comp.refresh({ equip: this.equip });
            }
        })
        this._eventListeners.push(listener);
    }

    async onTakeOff() {
        try {
            let hero = this.equip.getHero();
            let properties: Property = null;
            if (this.equip.getType() == Card.Type.Equip) {
                properties = await heroLogic.doUnequip(hero as PlayerHero, [this.equip.getEquipPlace()]);
            }
            else {
                properties = await heroLogic.doUnequipArtifact(hero as PlayerHero);
            }
            gm.propertyToast(properties);
            EManager.emit(EName.onUpdateEquip, hero);
        } catch (e) {
            if (e.name == "ToastError") {
                // gm.toast(error.message);
            }
            else {
                throw e;
            }
        }
    }

    onStrengthen() {
        gcc.core.showLayer("prefabs/panel/equip/EquipAdvancePanel", {
            data: { equip: this.equip, type: AdvanceType.Upgrade }
        });
        //gcc.core.showLayer("prefabs/panel/equip/EquipStrongPanel", { data: this.equip });
    }

    onReplace() {
        gcc.core.showLayer("prefabs/panel/equip/EquipListPanel", { data: { equip: this.equip, wearType: this.equip.getEquipPlace(), hero: this.equip.getHero() }, modalTouch: true });
    }

    protected _updateButtons() {
        if (this.shareNode) {
            this.shareNode.active = this.data.share || false;
            this.btnMerge.active = !this.shareNode.active;
        }
        if (this.btnMerge.active) {
            let unlock = UnlockWrapper.isUnlock(unlockConfigMap.合成);
            let canMerge = false;
            if (this.equip) { canMerge = this.equip.getRank() < equipLevelConfig.length; }
            this.btnMerge.active = unlock && canMerge;
        }
        this.buttons.active = !this.data.nobtn;
        this.seeBtn.active = this.buyBtn.active = this.buyPriceNode.active = this.data.good;
        if (this.data.nobuy) {
            this.buyBtn.active = false;
        }
        let equipNeedHeros = heroLogic.getEquipNeedHeros(this.data.equip);
        if (this.data.good && equipNeedHeros.length == 0) {
            this.seeBtn.active = false;
        }
        this.scrollView.height = this.content_bg.height = this.data.good ? 284 : 334;
        if (this.data.good) {
            let costType = 0;
            let price = 0;
            if (this.data.wisdomshop) {
                costType = this.data.wisdomshop.costType;
                price = Math.floor(this.data.wisdomshop.amt * this.data.wisdomshop.discount);
            } else {
                costType = this.data.good.getCostType();
                price = this.data.good.getPrice();
            }
            if (costType == GoodId.Gold) {
                this.price.string = slib.BigNumberHelper.convertNumStr2UnitStr(price.toString());
            } else {
                this.price.string = price.toString();
            }
            let color = cc.Color.WHITE;
            if (price > bagLogic.getGood(costType).getAmount()) {
                color = cc.Color.RED;
            }
            this.price.node.color = color;
            this.price_icon.spriteFrame = cc.loader.getRes(commonUtils.getGoodSIconUrl(costType), cc.SpriteFrame) as cc.SpriteFrame;
        }

        this.splitBtn.active = this.data.split ? true : false;
    }

    protected _createPropertyItem(config: propertyConfigRow, parent: cc.Node) {
        let getOutfitAddition: (config: propertyConfigRow) => number = null;
        let getStrongMasterAddition: (config: propertyConfigRow) => number = null;
        let getStarMasterAddition: (config: propertyConfigRow) => number = null;
        let hero = this.equip.getHero() as PlayerHero;
        if (hero) {
            getOutfitAddition = hero.getOutfitAddition;
            getStrongMasterAddition = hero.getStrongMasterAddition;
            getStarMasterAddition = hero.getStarMasterAddition;
        }
        let baseValue = this.equip.getValue(config, true);
        let nowValue = this.equip.getValue(config, undefined,
            getOutfitAddition,
            getStrongMasterAddition,
            getStarMasterAddition);

        if (nowValue == baseValue && baseValue == 0) return;

        let item = cc.instantiate(this.propertyItem);
        item.parent = parent;

        let width = 0;

        let title = item.getChildByName('title').getComponent(cc.Label);
        title.string = config.ProName;
        (title as any)._forceUpdateRenderData();
        width += title.node.width;

        width += 16;

        let base = item.getChildByName('base').getComponent(cc.Label);
        base.node.x = width;
        base.string = Property.getShowValue(config.ProName, baseValue);
        (base as any)._forceUpdateRenderData();
        width += base.node.width;

        let addition = item.getChildByName('addition').getComponent(cc.Label);
        if (nowValue > baseValue) {
            addition.node.x = width;
            addition.string = '+' + Property.getShowValue(config.ProName, nowValue - baseValue);
            (addition as any)._forceUpdateRenderData();
            width += addition.node.width;
        }
        else {
            addition.node.active = false;
        }

        //item.width = width;
    }

    protected _updateProperties() {
        this.basePropertyBg.destroyAllChildren();
        let configs = [propertyConfigMap.攻击, propertyConfigMap.生命, propertyConfigMap.防御];
        for (let config of configs) {
            this._createPropertyItem(config, this.basePropertyBg);
        }
        this.baseProperty.active = this.basePropertyBg.childrenCount > 0;

        this.attachPropertyBg.destroyAllChildren();
        for (let config of Property.AttachConfig) {
            this._createPropertyItem(config, this.attachPropertyBg);
        }
        this.attachProperty.active = this.attachPropertyBg.childrenCount > 0;

        this.factionProperty.active = this.equip.getCamp() > 0;
        if (this.factionProperty.active) {
            let label = this.factionPropertyBg.getChildByName("label1").getComponent(cc.Label);
            label.string = `【${stringConfigMap[`key_faction_${this.equip.getCamp()}`].Value}】`;

            label = this.factionPropertyBg.getChildByName("label3").getComponent(cc.Label);
            label.string = `${Equip.campAddition * 100}%`;
        }

        this.outfitProperty.active = false;
        let hero = this.equip.getHero() as PlayerHero;
        let outfitValid: boolean = (hero ? true : false) || this.equip.getOutfitId() > 0;
        if (outfitValid) {
            let outfits = hero ? hero.getEquipOutfit(this.equip) : this.equip.getEquipOutfit();
            this.outfitProperty.active = outfits.length > 0;
            if (this.outfitProperty.active) {
                this.outfitPropertyBg.destroyAllChildren();
                for (let outfit of outfits) {
                    let item = cc.instantiate(this.outfitItem);
                    item.parent = this.outfitPropertyBg;

                    let title = item.getChildByName('title');
                    let label = title.getChildByName("label1").getComponent(cc.Label);
                    label.string = `【${outfit.config.EqOutfitName}】`;
                    label = title.getChildByName("label2").getComponent(cc.Label);
                    label.string = `${outfit.count}/${Equip.EquipPlace.Num}`;

                    let deletedChildren: cc.Node[] = [];
                    for (let i = 1; i < item.children.length; i++) {
                        let child = item.children[i];
                        if (child) {
                            deletedChildren.push(child);
                        }
                    }
                    for (let child of deletedChildren) {
                        child.parent = null;
                        child.destroy();
                    }

                    for (let i = 2; i <= Equip.EquipPlace.Num; i++) {
                        let descItem = cc.instantiate(this.outfitDescItem);
                        descItem.parent = item;

                        let label = descItem.getChildByName("label1").getComponent(cc.Label);
                        label.node.color = outfit.count >= i ? cc.Color.WHITE.fromHEX('#CB73EB') : cc.Color.WHITE.fromHEX('#7C7C7D');

                        label = descItem.getChildByName("label2").getComponent(cc.Label);
                        label.string = stringUtils.getString(stringConfigMap.key_pieces.Value, { count: i });
                        label.node.color = outfit.count >= i ? cc.Color.WHITE.fromHEX('#C5C7C6') : cc.Color.WHITE.fromHEX('#7C7C7D');

                        label = descItem.getChildByName("label3").getComponent(cc.Label);
                        label.node.color = outfit.count >= i ? cc.Color.WHITE.fromHEX('#CB73EB') : cc.Color.WHITE.fromHEX('#7C7C7D');
                        let params = outfit.config[`EqOutfit${i}`] as number[][];
                        if (params) {
                            let contents: string[] = [];
                            for (let param of params) {
                                let c = Property.getConfig(param);
                                if (c.value < 1) {
                                    contents.push(`${c.config.ProName}+${c.value * 100}%`);
                                }
                                else {
                                    contents.push(`${c.config.ProName}+${c.value}`);
                                }
                            }
                            label.string = contents.join('，');
                        }
                    }
                }
            }
        }
    }

    onSee() {
        gcc.core.showLayer("prefabs/panel/store/StoreEquipSeePanel", { data: { equip: this.data.equip }, modalTouch: true });
    }

    onMerge() {
        gcc.core.showLayer("prefabs/panel/evolution/EvolutionPanel", { data: { tab: EvolutionType.EquipMerge, param: this.equip } });
    }

    async onBuy() {
        if (this.data.wisdomshop) {
            EManager.emit(EName.onWisdomShopBuy);
        } else {
            try {
                await shopLogic.doBuyGood(this.data.good);
            } catch (e) {
                if (e.name == "ToastError") {
                    if (e.message == stringUtils.getString(stringConfigMap.key_no_enough.Value, { name: bagLogic.getGood(Good.GoodId.Diamond).getName() })) {
                        gm.diamondLessToast();
                    }
                    else {
                        gm.toast(e.message);
                    }
                } else {
                    throw e;
                }
            }
        }
        this.closePanel();
    }

    onEquipType(e: cc.Event.EventTouch) {
        let node = e.target as cc.Node;
        let sprite = node.getComponent(cc.Sprite);
        gcc.core.showLayer("prefabs/panel/equip/EquipFactionInfoPanel",
            {
                data: {
                    frame: sprite.spriteFrame,
                    text: stringConfigMap[`key_equip_career${this.equip.getEquipCareer()}`].Value
                },
                modalTouch: true
            });
    }

    onFactionType(e: cc.Event.EventTouch) {
        let text = stringUtils.getString(stringConfigMap.key_equip_addition_camp.Value, {
            faction: stringConfigMap[`key_faction_${this.equip.getCamp()}`].Value,
            percentage: `${this.equip.getCampAddition() * 100}%`
        });

        let node = e.target as cc.Node;
        let sprite = node.getComponent(cc.Sprite);
        gcc.core.showLayer("prefabs/panel/equip/EquipFactionInfoPanel", {
            data: {
                frame: sprite.spriteFrame,
                text: text
            },
            modalTouch: true
        });
    }

    async onClickEquipSplit() {
        try {
            let cards = await bagLogic.doSplitEquip(this.equip as PlayerEquip);
            if (cards.length > 0) {
                gcc.core.showLayer("prefabs/panel/reward/RewardPanel", { data: { cards: cards }, modalTouch: true });
                this.closePanel();
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}