import { PopupPanel } from "../BasePanel";
import Hero from "../../../data/card/Hero";
import Artifact from "../../../data/card/Artifact";
import bagLogic from "../../../logics/BagLogic";
import artifactConfig from "../../../configs/artifactConfig";
import { ArtifactBO } from "../../../proxy/GameProxy";
import stringUtils from "../../../utils/StringUtils";
import ArtifactInfoItem from "../../widget/artifact/ArtifactInfoItem";
import EManager, { EName } from "../../../manager/EventManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/ArtifactListPanel")
export default class ArtifactListPanel extends PopupPanel {
    @property(cc.Layout)
    content: cc.Layout = null;

    @property(cc.Layout)
    ownList: cc.Layout = null;

    @property(cc.Layout)
    unownList: cc.Layout = null;

    @property(cc.Node)
    item: cc.Node = null;

    @property(cc.Node)
    ownTitle: cc.Node = null;

    @property(cc.Node)
    unownTitle: cc.Node = null;

    protected _target: Hero = null;

    onInit(target: Hero) {
        super.onInit(target)
        this._target = target;
    }

    onLoad() {
        super.onLoad();
        this.item.parent = null;
        this.registerEvents();
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onUpdateEquip, (hero: Hero) => {
            if (this._target == hero) {
                this.closePanel();
            }
        })
        this._eventListeners.push(listener);
    }

    start() {
        super.start();

        let ownList: Artifact[] = bagLogic.getArtifacts();
        ownList.sort((a: Artifact, b: Artifact) => {
            if (a.getHero() == this._target) {
                return -1;
            }
            else if (b.getHero() == this._target) {
                return 1;
            }
            else {
                let aStar = a.getStar();
                let bStar = b.getStar();
                if (aStar != bStar) return bStar - aStar;
                return a.getIndex() - b.getIndex();
            }
        });

        let ownSet = new Set<number>();
        for (let item of ownList) {
            ownSet.add(item.getIndex());
        }

        let unownList: Artifact[] = [];
        for (let config of artifactConfig) {
            if (!ownSet.has(config.Id)) {
                let bo = new ArtifactBO();
                bo.artifactCofId = config.Id;
                bo.artifactId = stringUtils.generateUUID();
                bo.heroId = "";
                bo.rank = 0;
                let artifact = new Artifact(bo);
                unownList.push(artifact);
            }
        }
        unownList.sort((a: Artifact, b: Artifact) => { return a.getIndex() - b.getIndex() });

        if (ownList.length > 0) {
            for (let artifact of ownList) {
                let item = cc.instantiate(this.item);
                item.parent = this.ownList.node;

                let comp = item.getComponent(ArtifactInfoItem);
                comp.init(artifact, this._target, true);
            }
        }
        else {
            this.ownTitle.active = false;
            this.ownList.node.active = false;
        }

        if (unownList.length > 0) {
            for (let artifact of unownList) {
                let item = cc.instantiate(this.item);
                item.parent = this.unownList.node;

                let comp = item.getComponent(ArtifactInfoItem);
                comp.init(artifact, this._target, false);
            }
        }
        else {
            this.unownTitle.active = false;
            this.unownList.node.active = false;
        }

        this.ownList.updateLayout();
        this.unownList.updateLayout();
        this.content.updateLayout();
    }
}
