import { stringConfigMap } from '../../../configs/stringConfig';
import { PopupPanel } from "../BasePanel";
import Equip from "../../../data/card/Equip";
import commonUtils from "../../../utils/CommonUtils";
import stringUtils from '../../../utils/StringUtils';
import PlayerEquip from '../../../data/card/PlayerEquip';
import bagLogic from '../../../logics/BagLogic';
import Good from '../../../data/card/Good';
import gm from '../../../manager/GameManager';
import CommonLoader from '../../common/CommonLoader';
import EquipCard from '../../component/Equip/EquipCard';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/EquipInheritPanel")
export default class EquipInheritPanel extends PopupPanel {

    @property(CommonLoader)
    curLoader: CommonLoader = null;

    @property(CommonLoader)
    replaceLoader: CommonLoader = null;

    protected _curEquip: Equip = null;
    protected _replaceEquip: Equip = null;
    protected _confirm: Function = null;
    protected _cancel: Function = null;

    onInit(data: {
        curEquip: Equip,
        replaceEquip: Equip
        confirm: Function,
        cancel: Function
    }) {
        this._curEquip = data.curEquip;
        this._replaceEquip = data.replaceEquip;
        this._confirm = data.confirm;
        this._cancel = data.cancel;
    }

    start() {
        super.start();

        let comp = this.curLoader.loaderNode.getComponent(EquipCard);
        comp.refresh({ equip: this._curEquip });

        comp = this.replaceLoader.loaderNode.getComponent(EquipCard);
        comp.refresh({ equip: this._replaceEquip });
    }

    onConfirm() {
        if (this._confirm) {
            this._confirm();
        }
        this.closePanel();
    }

    onCancel() {
        if (this._cancel) {
            this._cancel();
        }
        this.closePanel();
    }
}
