import { propertyConfigRow, propertyConfigMap } from './../../../configs/propertyConfig';
import equipstrengmasterconfig from './../../../configs/equipstrengmasterconfig';
import { EName } from './../../../manager/EventManager';
import { PopupPanel } from './../BasePanel';
import PlayerHero from '../../../data/card/PlayerHero';
import Equip, { EquipPlace } from '../../../data/card/Equip';
import CommonLoader from '../../common/CommonLoader';
import EquipCard from '../../component/Equip/EquipCard';
import EManager from '../../../manager/EventManager';
import Hero from '../../../data/card/Hero';
import equipstarmasterConfig from '../../../configs/equipstarmasterConfig';
import Property from '../../../data/Property';
import HeroCard from '../../component/Hero/HeroCard';
import heroLogic from '../../../logics/HeroLogic';
import gm from '../../../manager/GameManager';
const { ccclass, property, menu } = cc._decorator;

enum EquipMasterTab {
    /**强化大师 */
    Strong,

    /**精炼大师 */
    Star
}

const EquipMasterStrings = [
    {
        title: '强化进度',
        tip: '点击装备可直接去强化',
        equipMaster: '装备强化大师',
        equipMasterTip: '全身4件装备达到',
        equipMasterMax: '全身4件装备强化等级已达上限'
    },
    {
        title: '升星进度',
        tip: '点击装备可直接去升星',
        equipMaster: '装备升星大师',
        equipMasterTip: '全身4件装备达到',
        equipMasterMax: '全身4件装备星级已达上限'
    },
]

@ccclass
@menu("view/panel/equip/EquipMasterPanel")
export default class EquipMasterPanel extends PopupPanel {
    @property(cc.Label)
    labelTitle: cc.Label = null;

    @property(cc.Label)
    labelTip: cc.Label = null;

    @property(cc.Node)
    equipContainer: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(cc.Node)
    tabNodes: cc.Node[] = [];

    @property(cc.Label)
    labelEquipMaster: cc.Label = null;

    @property(cc.Label)
    labelCurLevel: cc.Label = null;

    @property(cc.Node)
    arrowNode: cc.Node = null;

    @property(cc.Label)
    labelNextLevel: cc.Label = null;

    @property(cc.Label)
    labelEquipMasterTip: cc.Label = null;

    @property(cc.Node)
    star1Container: cc.Node = null;

    @property(cc.Node)
    star2Container: cc.Node = null;

    @property(cc.Node)
    star1Item: cc.Node = null;

    @property(cc.Node)
    star2Item: cc.Node = null;

    @property(cc.Label)
    labelNextLevel2: cc.Label = null;

    @property(cc.Node)
    additionContainer: cc.Node = null;

    @property(cc.Node)
    additionItem: cc.Node = null;

    @property(cc.Node)
    btnQuickStrong: cc.Node = null;

    @property(cc.Node)
    owerHero: cc.Node = null;

    protected _tabIndex: number = -1;
    protected _hero: PlayerHero = null;
    protected _playEffect: boolean = false;
    protected _playUpEffect: boolean = false;
    protected _defaultIndex: number = 0;

    onInit(data: { hero: PlayerHero, effect?: boolean, tab?: number }) {
        this._hero = data.hero;
        this._playEffect = data.effect;
        this._defaultIndex = data.tab ? data.tab : this._defaultIndex;
    }

    onLoad() {
        super.onLoad();

        this.equipItem.parent = null;
        this.star1Item.parent = null;
        this.star2Item.parent = null;
        this.additionItem.parent = null;

        this.registerEvents();
    }

    onDestroy() {
        this.equipItem.destroy();
        this.star1Item.destroy();
        this.star2Item.destroy();
        this.additionItem.destroy();

        super.onDestroy();
    }

    start() {
        super.start();

        this.onTab(null, this._defaultIndex.toString());
    }

    registerEvents() {
        let listeners = EManager.addEventArray([Equip.Event.onStarDirty, Equip.Event.onCampDirty, Equip.Event.onChargingLvDirty, Equip.Event.onLevelDirty], (data: any) => {
            this._updateView();
        })
        this._eventListeners.pushList(listeners);
        let listener = EManager.addEvent(EName.onUpdateEquip, (hero: Hero) => {
            if (this._hero == hero) {
                this._updateView();
            }
        });
        this._eventListeners.push(listener);
    }

    async onQuickStrong() {
        try {
            await heroLogic.doStrongEquipAll(this._hero as PlayerHero);
            this._playUpEffect = true;
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }

        this._updateView();
    }

    onTab(event: cc.Event.EventTouch, index: string) {
        if (this._tabIndex.toString() == index) return;

        let tabNode = this.tabNodes[this._tabIndex];
        if (tabNode) {
            tabNode.width = 125;
            let mask = tabNode.getChildByName("mask");
            mask.active = true;
        }

        this._tabIndex = Number(index);

        tabNode = this.tabNodes[this._tabIndex];
        tabNode.width = 140;
        let mask = tabNode.getChildByName("mask");
        mask.active = false;

        this.btnQuickStrong.active = this._tabIndex == EquipMasterTab.Strong;

        let str = EquipMasterStrings[this._tabIndex];
        this.labelTitle.string = str.title;
        this.labelTip.string = str.tip;
        this.labelEquipMaster.string = str.equipMaster;
        this.labelEquipMasterTip.string = str.equipMasterTip;
        this._updateView();
    }

    protected _onClickEquip(comp: EquipCard, equip: Equip) {
        if (equip) {
            if (equip.getHero() != this._hero) {
                gcc.core.showLayer("prefabs/panel/equip/EquipInfoPanel", {
                    data: { equip: equip, wearType: equip.getEquipPlace(), nobtn: true },
                    modalTouch: true
                });
            }
            else {
                comp.onEquipInfo();
            }
        }
        else {
            comp.onEquip();
        }
    }

    protected _updateEquips() {
        this.equipContainer.destroyAllChildren();
        for (let i = EquipPlace.Weapon; i <= EquipPlace.Shoes; i++) {
            let item = cc.instantiate(this.equipItem);
            item.parent = this.equipContainer;

            let equip = this._hero.getEquip(i);
            let equipLoader = item.getChildByName("equip").getComponent(CommonLoader);
            let comp = equipLoader.loaderNode.getComponent(EquipCard);
            comp.refresh({ equip: equip, wearType: i, hero: this._hero });
            comp.showEquipBg();
            comp.starNode.active = false;

            item.off("click");
            item.on("click", () => { this._onClickEquip(comp, equip); }, this);

            if (equip && equip.getHero() != this._hero) {
                equipLoader.node.opacity = 128;
            }
            else {
                equipLoader.node.opacity = 255;
            }

            let labelName = item.getChildByName("equipName").getComponent(cc.Label);
            labelName.string = equip ? equip.getName() : '未穿戴装备';
            if (equip) {
                labelName.node.color = cc.Color.WHITE.fromHEX(equip.getLevelConfig().RankColor);
            }
            else {
                labelName.node.color = cc.Color.WHITE.fromHEX("#ACA9A9");
            }

            let progress = item.getChildByName("progress");
            let starContainer = item.getChildByName("star");
            let tip = item.getChildByName("tip");
            if (equip) {
                if (this._tabIndex == EquipMasterTab.Strong) {
                    starContainer.active = false;
                    tip.active = false;

                    let maxLevel = equipstrengmasterconfig.length
                    let level = this._hero.getEquipStrongMasters().length;
                    if (level < maxLevel) {
                        progress.active = true;
                        let needLevel = equipstrengmasterconfig[level].equiplevel;
                        let curLevel = equip.getLevel();

                        let bar = progress.getComponent(cc.ProgressBar);
                        bar.progress = curLevel / needLevel;

                        let label = progress.getChildByName("label").getComponent(cc.Label);
                        label.string = `${curLevel}/${needLevel}`;
                    }
                    else {
                        progress.active = false;
                    }
                }
                else {
                    progress.active = false;
                    if (equip.getStar() > 0) {
                        starContainer.active = true;
                        tip.active = false;

                        let count = Math.floor(equip.getStar() / 5);
                        let star1 = starContainer.getChildByName('star1');
                        star1.active = count > 0;
                        if (star1.active) {
                            star1.destroyAllChildren();
                            for (let i = 0; i < count; i++) {
                                let star = cc.instantiate(this.star1Item);
                                star.parent = star1;
                            }
                        }

                        let star2 = starContainer.getChildByName('star2');
                        if (!star1.active) {
                            count = equip.getStar() % 5;
                            star2.active = count > 0;
                            if (star2.active) {
                                star2.destroyAllChildren();
                                for (let i = 0; i < count; i++) {
                                    let star = cc.instantiate(this.star2Item);
                                    star.parent = star2;
                                }
                            }
                        }
                        else {
                            star2.active = false;
                        }
                    }
                    else {
                        starContainer.active = false;
                        tip.active = true;
                    }
                }

                if (this._playUpEffect) {
                    let ani = item.getChildByName('effect').getComponent(cc.Animation);
                    ani.play('Itemlevelup', 0);
                }
            }
            else {
                starContainer.active = false;
                tip.active = false;
                progress.active = false;
            }
        }
    }

    protected _updateEquipNeed() {
        let maxLevel = this._tabIndex == EquipMasterTab.Strong ? equipstrengmasterconfig.length : equipstarmasterConfig.length;
        let level = this._tabIndex == EquipMasterTab.Strong ? this._hero.getEquipStrongMasters().length : this._hero.getEquipStarMasters().length;
        this.labelCurLevel.string = ` Lv.${level}  `;
        if (maxLevel > level) {
            this.arrowNode.active = true;
            this.labelNextLevel.node.active = true;
            this.labelNextLevel.string = ` Lv.${level + 1}`;
            if (this._tabIndex == EquipMasterTab.Strong) {
                this.labelNextLevel2.node.active = true;
                this.labelNextLevel2.string = `Lv.${equipstrengmasterconfig[level].equiplevel}`;
                this.star1Container.active = false;
                this.star2Container.active = false;
            }
            else {
                this.labelNextLevel2.node.active = false;

                let starNeed = equipstarmasterConfig[level].EqStarNeed;
                let count = Math.floor(starNeed / 5);
                this.star1Container.active = count > 0;
                if (this.star1Container.active) {
                    this.star1Container.destroyAllChildren();
                    for (let i = 0; i < count; i++) {
                        let star = cc.instantiate(this.star1Item);
                        star.parent = this.star1Container;
                    }
                }

                count = starNeed % 5;
                this.star2Container.active = count > 0;
                if (this.star2Container.active) {
                    this.star2Container.destroyAllChildren();
                    for (let i = 0; i < count; i++) {
                        let star = cc.instantiate(this.star2Item);
                        star.parent = this.star2Container;
                    }
                }
            }
        }
        else {
            this.arrowNode.active = false;
            this.labelNextLevel.node.active = false;
            this.labelNextLevel2.node.active = false;
            this.star1Container.active = false;
            this.star2Container.active = false;

            let str = EquipMasterStrings[this._tabIndex];
            this.labelEquipMasterTip.string = str.equipMasterMax;
        }
    }

    protected _getStrongMasterAdditionByLevel(level: number, config: propertyConfigRow): number {
        let c = equipstrengmasterconfig[level - 1];
        if (c[config.VarName]) {
            return c[config.VarName];
        }
        return 0;
    }

    protected _getStarMasterAdditionByLevel(level: number, config: propertyConfigRow): number {
        let c = equipstarmasterConfig[level - 1];
        if (config == propertyConfigMap.攻击) {
            return c.EqStarMasterATK;
        }
        else if (config == propertyConfigMap.生命) {
            return c.EqStarMasterHP;
        }
        return 0;
    }

    protected _updateEquipAddition() {
        let maxLevel = this._tabIndex == EquipMasterTab.Strong ? equipstrengmasterconfig.length : equipstarmasterConfig.length;
        let level = this._tabIndex == EquipMasterTab.Strong ? this._hero.getEquipStrongMasters().length : this._hero.getEquipStarMasters().length;
        let nextLevel = level + 1;

        this.additionContainer.destroyAllChildren();
        for (let config of Property.Config) {
            let curValue: string = "";
            let nextValue: string = "";

            if (level < maxLevel) {
                let value = this._tabIndex == EquipMasterTab.Strong ? this._getStrongMasterAdditionByLevel(nextLevel, config) : this._getStarMasterAdditionByLevel(nextLevel, config);
                if (value == 0) continue;

                //nextValue = (this._hero.getValue(config) + value).toString();

                nextValue = `${this._getEquipPropertyAddValue(config, nextLevel)}`;
                if (level == 0) {
                    curValue = '未激活';
                }
                else {
                    //curValue = this._hero.getValue(config).toString();
                    curValue = `${this._getEquipPropertyAddValue(config, level)}`;
                }
            }
            else {
                let value = this._tabIndex == EquipMasterTab.Strong ? this._hero.getStrongMasterAddition(config) : this._hero.getStarMasterAddition(config);
                if (value == 0) continue;

                //curValue = this._hero.getValue(config).toString();
                curValue = `${this._getEquipPropertyAddValue(config, level)}`;
                nextValue = "MAX!";
            }

            let item = cc.instantiate(this.additionItem);
            item.parent = this.additionContainer;

            let labelName = item.getChildByName('name').getComponent(cc.Label);
            labelName.string = config.ProName;

            let labelCur = item.getChildByName('cur').getComponent(cc.Label);
            labelCur.string = curValue;

            let labelNext = item.getChildByName('next').getComponent(cc.Label);
            labelNext.string = nextValue;

            if (this._playEffect) {
                let ani = item.getChildByName('effect').getComponent(cc.Animation);
                ani.play('ItemlevelupGlow', 0);
            }
        }
    }

    protected _getEquipPropertyAddValue(config: propertyConfigRow, masterLevel: number) {
        //EquipMasterTab.Strong;
        if (this._tabIndex == EquipMasterTab.Strong) {
            return this._getEquipMasterPropertyAddValue(config, masterLevel);
        } else {
            return this._getEquipStarMasterPropertyAddValue(config, masterLevel);
        }
    }

    protected _getEquipMasterPropertyAddValue(config: propertyConfigRow, masterLevel: number): number {
        if (masterLevel == 0) { return 0; }
        if (masterLevel >= equipstrengmasterconfig.length) { masterLevel = equipstrengmasterconfig.length; }
        if (config.Id == propertyConfigMap.攻击.Id) {
            return equipstrengmasterconfig[masterLevel - 1].atk;
        } else if (config.Id == propertyConfigMap.生命.Id) {
            return equipstrengmasterconfig[masterLevel - 1].hp;
        }
        return 0;
    }

    protected _getEquipStarMasterPropertyAddValue(config: propertyConfigRow, masterLevel: number): number {
        if (masterLevel == 0) { return 0; }
        if (masterLevel >= equipstarmasterConfig.length) { masterLevel = equipstarmasterConfig.length; }
        if (config.Id == propertyConfigMap.攻击.Id) {
            return equipstarmasterConfig[masterLevel - 1].EqStarMasterATK;
        } else if (config.Id == propertyConfigMap.生命.Id) {
            return equipstarmasterConfig[masterLevel - 1].EqStarMasterHP;
        }
        return 0;
    }

    protected _updateOwerHero() {
        let comp = this.owerHero.getComponent(CommonLoader).loaderNode.getComponent(HeroCard);
        comp.refresh(this._hero);
    }

    protected _updateView() {
        this._updateEquips();
        this._updateEquipNeed();
        this._updateEquipAddition();
        this._updateOwerHero();

        this._playEffect = false;
        this._playUpEffect = false;
    }
}
