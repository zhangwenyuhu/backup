import { PopupPanel } from "../BasePanel";
import CommonLoader from "../../common/CommonLoader";
import Equip from "../../../data/card/Equip";
import Good from "../../../data/card/Good";
import bagLogic from "../../../logics/BagLogic";
import PlayerEquip from "../../../data/card/PlayerEquip";
import GoodCard from "../../component/Good/GoodCard";

const { ccclass, property, menu } = cc._decorator;
// 装备分解提醒窗口
@ccclass
@menu("view/panel/equip/EquipSplitPanel")
export default class EquipSplitPanel extends PopupPanel {
    @property(cc.Label)
    labelEquipColor: cc.Label = null;

    @property(cc.Node)
    splitReward: cc.Node = null;

    @property(cc.Node)
    goodItem: cc.Node = null;

    protected _equip: Equip = null;
    protected _confirm: Function = null;
    protected _cancel: Function = null;

    onInit(data: { equip: Equip, confirm: Function, cancel: Function }) {
        super.onInit(data);

        this._equip = data.equip;
        this._confirm = data.confirm;
        this._cancel = data.cancel;
    }

    onLoad() {
        super.onLoad();
        this.goodItem.parent = null;
    }
    onDestroy() {
        super.onDestroy();
        this.goodItem.destroy();
    }

    async start() {
        super.start();

        let cfg = this._equip.getLevelConfig();
        this.labelEquipColor.string = cfg.RankName;
        this.labelEquipColor.node.color = cc.Color.WHITE.fromHEX(cfg.RankColor);

        this.splitReward.destroyAllChildren();

        let cards = await bagLogic.doSplitEquipPreview(this._equip as PlayerEquip);
        if (!cc.isValid(this)) return;

        for (let card of cards) {
            let item = cc.instantiate(this.goodItem);
            item.parent = this.splitReward;

            let loader = item.getComponent(CommonLoader);
            let comp = loader.loaderNode.getComponent(GoodCard);
            comp.refresh(card as Good);
            comp.registerOnGoodInfo();
        }
    }

    onConfirm() {
        if (this._confirm) {
            this._confirm();
        }
        this.closePanel();
    }

    onCancel() {
        if (this._cancel) {
            this._cancel();
        }
        this.closePanel();
    }
}
