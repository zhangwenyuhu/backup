import { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import equipoutfitConfig, { equipoutfitConfigRow } from "../../../configs/equipoutfitConfig";
import cm from "../../../manager/ConfigManager";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/EquipOutfitPanel")
export default class EquipOutfitPanel extends PopupPanel {

    @property(cc.Node)
    outfitView: cc.Node = null;

    @property(cc.Node)
    outfitItem: cc.Node = null;

    @property(cc.Label)
    outfitTitle: cc.Label = null;

    @property(cc.Node)
    outfitBuff: cc.Node = null;

    @property(cc.Node)
    activeFlag: cc.Node = null;

    protected _outfitId: number = 0;
    protected _active: boolean = false;
    protected _outfitCof: equipoutfitConfigRow = null;
    protected _outfitInfo: { num: number, value: number[][] }[] = [];
    onInit(data: any) {
        super.onInit(data);

        this._outfitId = data.outfitId;
        this._active = data.active;
    }

    onLoad() {
        super.onLoad();
        this.outfitBuff.parent = null;
        this.outfitItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();
        this.outfitBuff.destroy();
        this.outfitItem.destroy();
    }

    start() {
        super.start();
        this._outfitCof = equipoutfitConfig.find((a) => { return a.EqOutfitID == this._outfitId; });
        this._initOutfitInfo();

        this.outfitTitle.string = this._outfitCof.EqOutfitName;

        this.outfitView.getComponent(cc.Widget).updateAlignment();
        this.outfitView.destroyAllChildren();
        for (let i = 0; i < this._outfitInfo.length; i++) {
            let tmp = cc.instantiate(this.outfitItem);
            tmp.parent = this.outfitView;

            this.onRenderItem(tmp, i);
        }
        this.activeFlag.active = this._active;
    }

    protected _initOutfitInfo() {
        this._outfitInfo = [];
        this._outfitInfo.push({ num: 2, value: this._outfitCof.EqOutfit2 });
        this._outfitInfo.push({ num: 3, value: this._outfitCof.EqOutfit3 });
        this._outfitInfo.push({ num: 4, value: this._outfitCof.EqOutfit4 });
    }

    protected onRenderItem(item: cc.Node, index: number) {
        let data = this._outfitInfo[index];

        let title = item.getChildByName('title');
        let num = title.getChildByName('num').getComponent(cc.Label);
        num.string = `${data.num}`;
        let name = title.getChildByName('name').getComponent(cc.Label);
        name.string = `件${this._outfitCof.EqOutfitName}套装`;

        let buff = item.getChildByName('buff');
        buff.destroyAllChildren();
        for (let i = 0; i < data.value.length; i++) {
            let tmp = cc.instantiate(this.outfitBuff);
            tmp.parent = buff;

            this._renderBuff(tmp, data.value[i]);
        }
    }

    protected _renderBuff(item: cc.Node, buff: number[]) {
        let node = item.getChildByName('item');
        let cfg = cm.getPropertyConfig(buff[0]);
        node.getChildByName('name').getComponent(cc.Label).string = cfg.ProName;

        let propValue: string = cfg.ProType > 0 ? `+${buff[1] * 100}%` : `+${buff[1]}`;
        node.getChildByName('value').getComponent(cc.Label).string = propValue;
    }
}
