import { Storage } from './../../../utils/DefineUtils';
import { stringConfigMap } from './../../../configs/stringConfig';
import { GoodVO } from './../../../proxy/GameProxy';
import EquipStrongSelectItem, { EquipGroup, GoodGroup, IGroup } from "../../widget/equip/EquipStrongSelectItem";
import { FullscreenPanel } from "../BasePanel";
import { RefreshLabel, RefreshNode, RefreshProgressBar } from "../../../decorator/RefreshDecorator";
import Equip, { EquipPlace } from "../../../data/card/Equip";
import EquipStrongStar from "../../widget/equip/EquipStrongStar";
import bagLogic from "../../../logics/BagLogic";
import Good from "../../../data/card/Good";
import equipLevelConfig from "../../../configs/equipLevelConfig";
import EquipStrongProperty from "../../widget/equip/EquipStrongProperty";
import EManager from "../../../manager/EventManager";
import gm from "../../../manager/GameManager";
import assignmentLogic from "../../../logics/AssignmentLogic";
import { DailyType } from "../../../utils/DefineUtils";
import Card from '../../../data/card/Card';
import heroUtils from "../../../utils/HeroUtils";
import List from '../../common/List';
import am from '../../../manager/AudioManager';
import storageUtils from '../../../utils/StorageUtils';
import EquipStrongItem from '../../component/Equip/EquipStrongItem';
import Hero from '../../../data/card/Hero';
import Property from '../../../data/Property';
import PlayerEquip from '../../../data/card/PlayerEquip';
import equipstarConfig from '../../../configs/equipstarConfig';

const { ccclass, property, menu } = cc._decorator;

class GroupContainer {
    protected _groups: IGroup[] = [];

    addGroup(group: IGroup) {
        this._groups.push(group);
    }

    getSelectExp(): number {
        let exp = 0;
        for (let group of this._groups) {
            exp += group.getSelectExp();
        }
        return exp;
    }

    getSelectEquipIds(): string[] {
        let ids = [];
        for (let group of this._groups) {
            if (group.getCard().getType() == Card.Type.Equip && group.getSelectCount() > 0) {
                ids.pushList((group as EquipGroup).getSelectIds());
            }
        }
        return ids;
    }

    getSelectGoods(): Good[] {
        let goods: Good[] = [];
        for (let group of this._groups) {
            if (group.getCard().getType() == Card.Type.Good && group.getSelectCount() > 0) {
                let good = group.getCard() as Good;
                let vo = new GoodVO();
                vo.propId = good.getIndex();
                vo.amt = group.getSelectCount();
                goods.push(new Good(vo));
            }
        }
        return goods;
    }

    getGroups(): IGroup[] {
        return this._groups;
    }

    getGroup(index: number): IGroup {
        return this._groups[index];
    }
}

@ccclass
@menu("view/panel/equip/EquipStrongPanel")
export default class EquipStrongPanel extends FullscreenPanel {

    @RefreshLabel({
        getData: (caller: EquipStrongPanel) => { return caller.equip },
        getValue: (caller: Equip) => { return caller.getName() }
    })
    @property(cc.Label)
    labelName: cc.Label = null;

    @property(cc.Node)
    equipContainer: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(EquipStrongStar)
    equipStrongStar: EquipStrongStar = null;

    @property(cc.Node)
    propertyBg: cc.Node = null;

    @property(cc.Node)
    propertyItem: cc.Node = null;

    @property(List)
    materialList: List = null;

    @RefreshLabel({
        eventName: Equip.Event.onTotalExpDirty,
        getTarget: (caller: EquipStrongPanel) => { return caller.equipCopy },
        getData: (caller: EquipStrongPanel) => { return caller.twoEquips },
        refresh: (label: cc.Label, twoEquips: { cur: Equip, next: Equip }) => {
            let deltaExp = Math.min(twoEquips.next.getMaxExp(), twoEquips.next.getTotalExp()) - twoEquips.cur.getTotalExp();
            let totalAmount = bagLogic.getGood(Good.GoodId.Gold).getAmount();
            let consumeAmount = bagLogic.getConsumeGoldForRefineEquip(deltaExp);
            label.string = `${slib.BigNumberHelper.convertNumStr2UnitStr(totalAmount.toString())}`;
            label.node.color = totalAmount >= consumeAmount ? cc.color(79, 103, 103) : cc.Color.RED;
        }
    })
    @property(cc.Label)
    labelGold: cc.Label = null;

    @RefreshLabel({
        eventName: Equip.Event.onTotalExpDirty,
        getTarget: (caller: EquipStrongPanel) => { return caller.equipCopy },
        getData: (caller: EquipStrongPanel) => { return caller.twoEquips },
        refresh: (label: cc.Label, twoEquips: { cur: Equip, next: Equip }) => {
            let deltaExp = Math.min(twoEquips.next.getMaxExp(), twoEquips.next.getTotalExp()) - twoEquips.cur.getTotalExp();
            let consumeAmount = bagLogic.getConsumeGoldForRefineEquip(deltaExp);
            label.string = `/${slib.BigNumberHelper.convertNumStr2UnitStr(consumeAmount.toString())}`;
        }
    })
    @property(cc.Label)
    labelCost: cc.Label = null;

    @RefreshProgressBar({
        eventName: Equip.Event.onTotalExpDirty,
        getData: (caller: EquipStrongPanel) => { return caller },
        getTarget: (caller: EquipStrongPanel) => { return caller.equipCopy },
        getValue: (caller: EquipStrongPanel) => {
            if (caller.equipCopy.getStar() == caller.equipCopy.getMaxStar()) {
                return 1;
            }
            if (caller.equipCopy.getStar() > caller.equip.getStar() && caller.equipCopy.getExp() == 0) {
                return 1;
            }
            return caller.equipCopy.getExp();
        },
        getTotal: (caller: EquipStrongPanel) => {
            if (caller.equipCopy.getStar() == caller.equipCopy.getMaxStar()) {
                return 1;
            }
            if (caller.equipCopy.getStar() > caller.equip.getStar() && caller.equipCopy.getExp() == 0) {
                return 1;
            }
            let config = equipLevelConfig[caller.equipCopy.getRank() - 1];
            let value = config[`Exp${caller.equipCopy.getStar() + 1}`];
            return value;
        },
        refresh: (progressBar: cc.ProgressBar, panel: EquipStrongPanel) => {
            if (panel.equipCopy.getTotalExp() != panel.equip.getTotalExp()) {
                progressBar.barSprite.spriteFrame = panel.barSpriteFrames[0];
            }
            else {
                progressBar.barSprite.spriteFrame = panel.barSpriteFrames[1];
            }
        }
    })
    @property(cc.ProgressBar)
    progressBar: cc.ProgressBar = null;

    @RefreshLabel({
        eventName: Equip.Event.onTotalExpDirty,
        getData: (caller: EquipStrongPanel) => { return caller },
        getTarget: (caller: EquipStrongPanel) => { return caller.equipCopy },
        refresh: (label: cc.Label, panel: EquipStrongPanel) => {
            let config = equipLevelConfig[panel.equipCopy.getRank() - 1];
            if (panel.equipCopy.getStar() > panel.equip.getStar() && panel.equipCopy.getExp() == 0) {
                let total = config[`Exp${panel.equipCopy.getStar()}`];
                label.string = `${total}/${total}`;
            }
            else {
                let exp = panel.equipCopy.getExp();
                let star = Math.min(panel.equipCopy.getStar() + 1, panel.equipCopy.getMaxStar());
                let total = config[`Exp${star}`];
                label.string = `${exp}/${total}`;
            }
        }
    })
    @property(cc.Label)
    labelProgress: cc.Label = null;

    @RefreshLabel({
        eventNames: [Equip.Event.onStarDirty, Equip.Event.onTotalExpDirty],
        getData: (caller: EquipStrongPanel) => { return caller },
        getTarget: (caller: EquipStrongPanel) => { return caller.equipCopy },
        refresh: (label: cc.Label, panel: EquipStrongPanel) => {
            let star = panel.equipCopy.getStar();
            if ((panel.equipCopy.getExp() == 0 || panel.equipCopy.getStar() == panel.equipCopy.getMaxStar()) && panel.equipCopy.getStar() > panel.equip.getStar()) {
                star--;
            }
            let content = `${stringConfigMap.key_equip_star.Value}: ${star}`;
            label.string = content;
        }
    })
    @property(cc.Label)
    labelCurStar: cc.Label = null;

    @RefreshNode({
        eventName: Equip.Event.onStarDirty,
        getData: (caller: EquipStrongPanel) => { return caller.equipCopy },
        refresh: (node: cc.Node, equip: Equip) => {
            node.active = equip.getStar() < equip.getMaxStar();
        }
    })
    @property(cc.Node)
    starArrow: cc.Node = null;

    @RefreshLabel({
        eventNames: [Equip.Event.onStarDirty, Equip.Event.onTotalExpDirty],
        getData: (caller: EquipStrongPanel) => { return caller },
        getTarget: (caller: EquipStrongPanel) => { return caller.equipCopy },
        refresh: (label: cc.Label, panel: EquipStrongPanel) => {
            let star = panel.equipCopy.getStar();
            if (panel.equipCopy.getExp() > 0 && star < panel.equipCopy.getMaxStar()) {
                star++;
            }
            else if (panel.equipCopy.getStar() == panel.equip.getStar() && panel.equipCopy.getExp() == 0) {
                star++;
            }
            let content = `${stringConfigMap.key_equip_star.Value}: ${star}`;
            if (star == panel.equipCopy.getMaxStar()) {
                content += '(MAX)';
            }
            label.string = content;
        }
    })
    @property(cc.Label)
    labelNextStar: cc.Label = null;

    @RefreshNode({
        eventName: Equip.Event.onStarDirty,
        getData: (caller: EquipStrongPanel) => { return caller.twoEquips.cur },
        refresh: (node: cc.Node, equip: Equip) => {
            let button = node.getComponent(cc.Button)
            button.interactable = equip.getStar() < equip.getMaxStar();
        }
    })
    @property(cc.Node)
    btnStrong: cc.Node = null;

    @property(cc.Node)
    strongEffect: cc.Node = null;

    @property(cc.SpriteFrame)
    barSpriteFrames: cc.SpriteFrame[] = [];

    @property(cc.ScrollView)
    propertyList: cc.ScrollView = null;

    twoEquips: { cur: Equip, next: Equip } = null;
    equip: PlayerEquip = null;
    equipCopy: Equip = null;
    groupContainer: GroupContainer = null;

    protected _hero: Hero = null;
    protected _place: EquipPlace = EquipPlace.Unknow;
    protected _equipItems: { [key: number]: EquipStrongItem } = {};
    protected _starStrongEffect: cc.Animation = null;
    protected _propertyStrongEffects: cc.Animation[] = [];

    onInit(equip: PlayerEquip) {
        this._hero = equip.getHero();
        this._place = equip.getEquipPlace();
    }

    onLoad() {
        super.onLoad();

        this.strongEffect.parent = null;
        this.propertyItem.parent = null;
        this.equipItem.parent = null;

        for (let i = EquipPlace.Weapon; i <= EquipPlace.Shoes; i++) {
            let item = cc.instantiate(this.equipItem);
            item.parent = this.equipContainer;

            let equip = this._hero.getEquip(i);
            let comp = item.getComponent(EquipStrongItem);
            comp.init(equip, i);
            comp.unfocus();

            item.on("click", () => { this._onTab(i); }, this);

            this._equipItems[i] = comp;
        }

        let place = this._place;
        do {
            let equip = this._hero.getEquip(place);
            if (equip && equip.getStar() < equip.getMaxStar()) {
                break;
            }
            place = place % EquipPlace.Shoes + 1;
        } while (place != this._place);
        this._place = place;

        let effect = cc.instantiate(this.strongEffect);
        effect.position = cc.v2();
        effect.parent = this.equipStrongStar.node;
        this._starStrongEffect = effect.getComponent(cc.Animation);

        this._onTab(this._place, true);

        this.registerEvents();
    }

    onDestroy() {
        super.onDestroy();

        this.strongEffect.destroy();
        this.propertyItem.destroy();
        this.equipItem.destroy();
    }

    registerEvents() {
        let listeners = EManager.addEventArray([
            GoodGroup.Event.onSelectCountDirty,
            EquipGroup.Event.onSelectCountDirty], () => {
                this.equipCopy.setTotalExp(this.equip.getTotalExp() + this.groupContainer.getSelectExp());
            });
        this._eventListeners.pushList(listeners);
    }

    markGuideEquipStrong() {
        storageUtils.setBoolean(Storage.GuideStrongEquip.Key, true, true);
    }

    onSmartFill() {
        if (this.equipCopy.getStar() == this.equipCopy.getMaxStar()) {
            gm.toast(stringConfigMap.key_max_level.Value);
            return;
        }

        let nextStar = this.equipCopy.getStar() + 1;
        let exp = this._getTotalExp(nextStar);
        let delta = exp - this.equipCopy.getTotalExp();
        let groups = this.groupContainer.getGroups();
        if (groups.length > 0) {
            for (let group of groups) {
                delta = group.addSelectCount(delta);
                if (delta <= 0) break;
                if (nextStar == this.equipCopy.getStar()) {
                    break;
                }
            }
        }
        else {
            gm.toast(stringConfigMap.key_no_enough_material.Value);
        }
    }

    async onStrong() {
        try {
            let deltaExp = Math.min(this.equipCopy.getMaxExp(), this.equipCopy.getTotalExp()) - this.equip.getTotalExp();
            deltaExp = await bagLogic.doRefineEquip(this.equip, this.groupContainer.getSelectGoods(), deltaExp);
            let data = {};
            data[stringConfigMap.key_strong_exp.Value] = deltaExp;
            gm.propertyToast(data);

            this._starStrongEffect.play();
            for (let effect of this._propertyStrongEffects) {
                effect.play();
            }
            this._equipItems[this._place].showEffect();

            this._updateFillEquips();
            EManager.emit(Equip.Event.onTotalExpDirty, { target: this.equipCopy });
            EManager.emit(Equip.Event.onStarDirty, { target: this.equipCopy });
            assignmentLogic.dailyTaskProCommit(DailyType.strong_equip);
            am.playEffect("equip_strengthen");
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    onMaterialRender(item: cc.Node, index: number) {
        let group = this.groupContainer.getGroup(index);
        let comp = item.getComponent(EquipStrongSelectItem);
        comp.refresh(group);

        let func = EquipStrongSelectItem.prototype.onSelect;
        comp.onSelect = () => {
            if (this.equipCopy.getStar() == this.equipCopy.getMaxStar()) {
                gm.toast(stringConfigMap.key_max_level.Value);
                return;
            }
            func.call(comp);
        }
    }

    refreshWithProperty() {
        this.equipCopy = this.equip.clone();
        this.twoEquips = {
            cur: this.equip,
            next: this.equipCopy
        }
        this.equipStrongStar.refreshWithProperty(this.equip, this.equipCopy);

        this.propertyList.content.destroyAllChildren();
        this._propertyStrongEffects = [];

        let propertyCopy = this.equipCopy.getProperty();
        let valuesCopy = propertyCopy.getValues(true);

        for (let i = 0; i < valuesCopy.length; i++) {
            let value = valuesCopy[i];
            if (value == 0) continue;

            let item = cc.instantiate(this.propertyItem);
            item.parent = this.propertyList.content;
            let property = item.getComponent(EquipStrongProperty);
            property.init(this.equip, this.equipCopy, Property.Config[i]);

            let effect = cc.instantiate(this.strongEffect);
            effect.position = cc.v2();
            effect.parent = item;
            this._propertyStrongEffects.push(effect.getComponent(cc.Animation));
        }

        let equipQuality = heroUtils.getEquipQuality(this.equip.getRank());
        let color = cc.Color.WHITE;
        color.fromHEX(equipQuality.qualityColor);
        this.labelName.node.color = color;

        this._updateFillEquips();
    }

    protected _onTab(place: EquipPlace, force?: boolean) {
        if (this._place == place && !force) {
            return;
        }

        let item = this._equipItems[place];
        if (!item.equip) {
            return;
        }
        if (item.equip.getRank() <= 2) {
            gm.toast(stringConfigMap.key_goto_strong_equip_tip.Value);
            return;
        }

        item = this._equipItems[this._place];
        if (item) { item.unfocus(); }

        this._place = place;
        item = this._equipItems[this._place];
        item.focus();

        this.equip = item.equip as PlayerEquip;
        this.refreshWithProperty();
    }

    protected _getTotalExp(star: number): number {
        let exp = 0;
        let count = Math.min(star, this.equip.getMaxStar());
        for (let i = 0; i < count; i++) {
            exp += equipstarConfig[i].EqStarExp;
        }
        return exp;
    }

    protected _updateFillEquips() {
        this.groupContainer = new GroupContainer();

        let good = bagLogic.getGood(Good.GoodId.BlackCoin);
        if (good.getAmount() > 0) {
            let group = new GoodGroup(good);
            this.groupContainer.addGroup(group);
        }

        good = bagLogic.getGood(Good.GoodId.HighBlackCoin);
        if (good.getAmount() > 0) {
            let group = new GoodGroup(good);
            this.groupContainer.addGroup(group);
        }

        // let equipss = bagLogic.getEquipsForStrengthEquip(this.equip);
        // equipss.sort((a: Equip[], b: Equip[]) => {
        //     let aRank = a[0].getRank();
        //     let bRank = b[0].getRank();
        //     if (aRank != bRank) return aRank - bRank;

        //     let aIndex = a[0].getIndex();
        //     let bIndex = b[0].getIndex();
        //     if (aIndex != bIndex) return aIndex - bIndex;

        //     let aStar = a[0].getStar();
        //     let bStar = b[0].getStar();
        //     if (aStar != bStar) return aStar - bStar;

        //     return a[0].getCamp() - b[0].getCamp();
        // });
        // for (let equips of equipss) {
        //     let group = new EquipGroup(equips);
        //     this.groupContainer.addGroup(group);
        // }
        this.materialList.getComponent(cc.Widget).updateAlignment();
        this.materialList.numItems = this.groupContainer.getGroups().length;
    }
}
