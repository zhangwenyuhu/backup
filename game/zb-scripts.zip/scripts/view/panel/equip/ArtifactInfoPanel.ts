import { stringConfigMap } from './../../../configs/stringConfig';
import EquipInfoPanel from "./EquipInfoPanel";
import Artifact from "../../../data/card/Artifact";
import stringUtils from "../../../utils/StringUtils";
import BasePanel from "../BasePanel";
import EManager, { EName } from "../../../manager/EventManager";
import CommonLoader from "../../common/CommonLoader";
import ArtifactName from "../../component/Artifact/ArtifactName";
import bagLogic from "../../../logics/BagLogic";
import {propertyConfigMap, propertyConfigRow} from "../../../configs/propertyConfig";
import Property from "../../../data/Property";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/equip/ArtifactInfoPanel")
export default class ArtifactInfoPanel extends EquipInfoPanel {
    @property({
        type: cc.Label,
        visible: false,
        override: true
    })
    labelTitle: cc.Label = null;

    @property({
        type: cc.Label,
        visible: false,
        override: true
    })
    labelPower: cc.Label = null;

    @property({
        type: cc.Label,
        visible: false,
        override: true
    })
    labelType: cc.Label = null;

    @property({
        type: cc.Sprite,
        visible: false,
        override: true
    })
    iconType: cc.Sprite = null;

    @property({
        type: cc.Label,
        visible: false,
        override: true
    })
    labelAddition: cc.Label = null;

    @property({
        type: cc.Sprite,
        visible: false,
        override: true
    })
    iconAddition: cc.Sprite = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    labelAdditionCamp: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    itemAdditionCamp: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    buyBtn: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    seeBtn: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    buyPriceNode: cc.Node = null;

    @property({
        type: cc.Sprite,
        visible: false,
        override: true
    })
    price_icon: cc.Sprite = null;

    @property({
        type: cc.Label,
        visible: false,
        override: true
    })
    price: cc.Label = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    btnOff: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    btnReplace: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    itemAddition: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    splitBtn: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    baseProperty: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    basePropertyBg: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    attachProperty: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    attachPropertyBg: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    factionProperty: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    factionPropertyBg: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    outfitProperty: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    outfitPropertyBg: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    outfitItem: cc.Node = null;

    @property({
        type: cc.Node,
        visible: false,
        override: true
    })
    outfitDescItem: cc.Node = null;

    @property(cc.Node)
    propertyBg: cc.Node = null;

    @property(cc.Node)
    skillItem: cc.Node = null;

    @property(cc.Node)
    skillTitle: cc.Node = null;

    @property(cc.Node)
    propContent: cc.Node = null;

    @property(cc.Node)
    propItem: cc.Node = null;

    @property(cc.Color)
    focusSkillColor: cc.Color = cc.Color.YELLOW;

    @property(CommonLoader)
    artifactName: CommonLoader = null;

    protected _artifact: Artifact = null;

    onLoad() {
        super.onLoad();

        this.propertyItem.parent = null;
        this.skillItem.parent = null;
        this.skillTitle.parent = null;
        this.propItem.parent = null;
        this.propContent.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.propertyItem.destroy();
        this.skillItem.destroy();
        this.skillTitle.destroy();
        this.propItem.destroy();
        this.propContent.destroy();
    }

    onInit(data) {
        super.onInit(data);
        this._artifact = bagLogic.getIndexArtifact(this.equip.getIndex());
    }

    start() {
        super.start();
        this.artifactName.loaderNode.getComponent(ArtifactName).refresh(this.equip.getIndex());
    }

    onStrengthen() {
        BasePanel.closePanel("ArtifactInfoPanel");
        BasePanel.closePanel("HeroInfoPanel");
        EManager.emit(EName.onChangeToArtifact);
    }

    onReplace() {
        gcc.core.showLayer("prefabs/panel/equip/ArtifactListPanel", { data: this.equip.getHero(), modalTouch: true });
    }

    protected _updateButtons() {
        this.buttons.active = !this.data.nobtn;
    }

    protected _updateProperties() {
        let artifact = this.equip as Artifact;
        let property = artifact.getProperty();
        let values = property.getValues();
        let titles = property.getTitles();

        this.propertyBg.destroyAllChildren();

        for (let i = 0; i < titles.length; i++) {
            let title = titles[i];
            let value = values[i];
            if (value) {
                let item = cc.instantiate(this.propertyItem);
                item.parent = this.propertyBg;

                let labelNode = item.getChildByName("label");
                let valueNode = item.getChildByName("value");
                labelNode.getComponent(cc.Label).string = title + ":  ";
                valueNode.getComponent(cc.Label).string = value < 1 ? `${Math.floor(value * 100)}%` : value.toString();
            }
        }

        this.content_bg.destroyAllChildren();

        if (this._artifact && this._artifact.getForgeLv() > 0) {
            this._addTitleItem("锻造属性");
            let node = cc.instantiate(this.propContent);
            node.parent = this.content_bg;
            this._addForgeItem(propertyConfigMap.攻击, node);
            this._addForgeItem(propertyConfigMap.攻击百分比, node);
            this._addForgeItem(propertyConfigMap.生命, node);
            this._addForgeItem(propertyConfigMap.生命百分比, node);
            this._addForgeItem(propertyConfigMap.防御, node);
            this._addForgeItem(propertyConfigMap.暴击率, node);
            this._addForgeItem(propertyConfigMap.暴击伤害, node);
        }

        this._addTitleItem("主动技能");
        let skills = artifact.getSkills();
        for (let i = 1; i <= 5; i++) {
            this._addSkillItem(artifact, skills[1], i, true);
        }

        this._addTitleItem("被动技能");
        for (let i = 1; i <= 3; i++) {
            this._addSkillItem(artifact, skills[0], i, false);
        }
    }

    protected _addTitleItem(text) {
        let node = cc.instantiate(this.skillTitle);
        node.parent = this.content_bg;
        let title = node.getChildByName("title");
        title.getComponent(cc.Label).string = text;
    }

    protected _addForgeItem(config: propertyConfigRow, parent) {
        let param = [];
        param.push(config.Id);
        param.push(this._artifact.getForgeValue(config));
        let c = Property.getConfig(param);
        if (c.value > 0) {
            let node = cc.instantiate(this.propItem);
            node.parent = parent;
            let label = node.getChildByName("label");
            let value = cc.find("node/value", node);
            let add = cc.find("node/add", node);
            label.getComponent(cc.Label).string = config.ProName;
            value.active = false;
            add.getComponent(cc.Label).string = `+${c.value < 1 ? c.value * 100 + "%" : c.value}`;
        }
    }

    protected _addSkillItem(artifact, skill, i, initiative: boolean) {
        let item = cc.instantiate(this.skillItem);
        item.parent = this.content_bg;

        let desc = skill.getSkillDesc(i);
        let labelNode = item.getChildByName("label");
        let label = labelNode.getComponent(cc.Label);
        label.string = desc;

        if (skill.getLevel() >= i) {
            let icon = labelNode.getChildByName("icon");
            icon.color = labelNode.color = this.focusSkillColor;
        }
        else {
            label.string += "(" + stringUtils.getString(stringConfigMap.key_artifact_skill_unlock.Value, { count: artifact.getStarByUnlockSkillLevel(i, initiative) }) + ")";
        }
        (label as any)._updateRenderData(true);
        item.getComponent(cc.Layout).updateLayout();
    }

}
