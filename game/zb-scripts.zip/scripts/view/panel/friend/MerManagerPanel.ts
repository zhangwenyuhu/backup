import { PopupPanel } from "../BasePanel";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import gm from "../../../manager/GameManager";
import friendMerLogic from "../../../logics/FriendMerLogic";
import { stringConfigMap } from "../../../configs/stringConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/friend/MerManagerPanel")
export default class MerManagerPanel extends PopupPanel {

    @property(cc.Node)
    applyScrollView: cc.Node = null;

    @property(cc.Node)
    borrowScrollView: cc.Node = null;

    @property(cc.Node)
    applyNode: cc.Node = null;

    @property(cc.Node)
    borrowNode: cc.Node = null;

    @property(cc.Node)
    noApplyNode: cc.Node = null;

    @property(cc.Node)
    noBorrowNode: cc.Node = null;

    private _currentTab: number = 1;
    private _bInitedBorrow: boolean = false;
    onInit(data: any) {

    }

    async start() {
        super.start();

        await friendMerLogic.applyToMeMercHeroReq();
        await friendMerLogic.myMercHerosReq();

        this.initApplyView();
        //this.initBorrowView();

        this.applyNode.active = true;
        this.borrowNode.active = false;
    }

    onClickTab(event: cc.Event.EventTouch, index: string) {
        let tabSelect: number = parseInt(index);
        if (this._currentTab == tabSelect) {
            return;
        }

        this._currentTab = tabSelect;
        let showApply: boolean = this._currentTab == 1 ? true : false;
        this.applyNode.active = showApply;
        this.borrowNode.active = !showApply;
        if (!this._bInitedBorrow) {
            this.initBorrowView();
        }
    }

    initApplyView() {
        let tmp = friendMerLogic.getApplyList();
        this.noApplyNode.active = tmp.length == 0;
        this.applyScrollView.getComponent(ScrollViewLoader).refresh(tmp, false, this.onCellClick.bind(this));
    }

    initBorrowView() {
        let tmp = friendMerLogic.getMyBorrowToOtherHeroList();
        this.noBorrowNode.active = tmp.length == 0;
        this.borrowScrollView.getComponent(ScrollViewLoader).refresh(tmp, false, this.onCellClick.bind(this));
    }

    onCellClick(data: any) {
        if (this._currentTab == 1) {
            this.initApplyView();
        } else {
            this.initBorrowView();
        }
    }

    async onClickIgnoreAll() {
        let tmp = friendMerLogic.getApplyList();
        if (tmp.length == 0) {
            gm.toast(stringConfigMap.key_friend_tip11.Value)
            return;
        }

        try {
            await friendMerLogic.autoOptionMercApplyReq(false);
            this.initApplyView();
            gm.toast(stringConfigMap.key_friend_tip13.Value);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    async onClickAgreeAll() {
        let tmp = friendMerLogic.getApplyList();
        if (tmp.length == 0) {
            gm.toast(stringConfigMap.key_friend_tip11.Value)
            return;
        }

        try {
            await friendMerLogic.autoOptionMercApplyReq(true);
            this.initApplyView();
            gm.toast(stringConfigMap.key_friend_tip12.Value);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}
