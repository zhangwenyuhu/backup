import { PopupPanel } from "../BasePanel";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import friendLogic from "../../../logics/FriendLogic";
import { FriendInfoItem } from "../../../proxy/GameProxy";
import gm from "../../../manager/GameManager";
import { stringConfigMap } from "../../../configs/stringConfig";
import Friend from "../../../data/user/Friend";
import EManager, { EName } from "../../../manager/EventManager";
import loadUtils from "../../../utils/LoadUtils";
import assignmentLogic from "../../../logics/AssignmentLogic";
import { DailyType, Goto, BattleType } from "../../../utils/DefineUtils";
import { defaultConfigMap } from "../../../configs/defaultConfig";
import friendMerLogic from "../../../logics/FriendMerLogic";
import HeroMerc from "../../../data/card/HeroMerc";
import stringUtils from "../../../utils/StringUtils";
import HeroInfoPanel from "../hero/HeroInfoPanel";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/friend/FriendPanel")
export default class FriendPanel extends PopupPanel {

    @property(cc.Node)
    friendScrollView: cc.Node = null;

    @property(cc.Label)
    friend_nums: cc.Label = null;

    @property(cc.Label)
    friend_hearts: cc.Label = null;

    @property(cc.Label)
    friend_heart_limit: cc.Label = null;

    @property(cc.Node)
    sortView: cc.Node = null;

    @property(cc.Node)
    noFriendBg: cc.Node = null;

    @property(cc.Node)
    friendNode: cc.Node = null;

    @property(cc.Node)
    merNode: cc.Node = null;

    @property(cc.Node)
    merReturnTime: cc.Node = null;

    @property(cc.Node)
    merHeros: cc.Node = null;

    @property(cc.Node)
    merHero: cc.Node = null;

    @property(cc.Node)
    merHeroScrollView: cc.Node = null;

    @property(cc.Node)
    existMeroHeroTips: cc.Node = null;

    @property(cc.Node)
    noMeroHeroTips: cc.Node = null;

    private _currentTab: number = 1;
    private _borrowHeros: { index: number, data: HeroMerc, node: cc.Node }[] = [];
    private _filterTag: number = 0;
    protected _skeletonDatas: sp.SkeletonData[] = [];
    private _mercReturnCount: number = 0;

    onLoad() {
        super.onLoad();

        this.registerEvents();
        this.merHero.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.unschedule(this.mercReturnCount);
        this.merHero.destroy();
    }

    async start() {
        super.start();

        try {
            await friendLogic.panelOpenReq();
            this.data = friendLogic.getFriends();

            this.showFriendView();
            this.freshUI();
            this.freshMerHero(true);

            this.sortView.active = false;
            this.friendNode.active = true;
            this.merNode.active = false;

            this._mercReturnCount = (friendMerLogic.resetTimestamp - gm.getCurrentTimestamp()) / 1000;
            this.schedule(this.mercReturnCount, 1);
            friendMerLogic.resetMercHeroLevel();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    mercReturnCount() {
        this._mercReturnCount -= 1;
        if (this._mercReturnCount <= 0) {
            friendMerLogic.mercHerosReq();
            this.scheduleOnce(() => {
                this.freshMerHero(true);
            }, 1);

            this.unschedule(this.mercReturnCount);
        }
    }

    async initMerHeroScrollView(bInit: boolean = true) {
        let tmp = friendMerLogic.getShowMercHeros(this._filterTag);
        tmp.sort((a, b) => {
            if (a.getRank() != b.getRank()) {
                return b.getRank() - a.getRank();
            } else {
                return b.getIndex() - a.getIndex();
            }
        });

        this.merHeroScrollView.getComponent(ScrollViewLoader).refresh(tmp);

        let noMeroHero: boolean = tmp.length == 0;
        this.noMeroHeroTips.active = noMeroHero;
        this.existMeroHeroTips.active = !noMeroHero;
    }

    async freshMerHero(bInit: boolean = false) {
        if (bInit) {
            this.merHeros.destroyAllChildren();
            this._borrowHeros = [];
            let heros: HeroMerc[] = friendMerLogic.getBorrowedHeros();

            this._releaseSkeletonDatas();

            for (let i = 0; i < 3; i++) {
                let tmp = cc.instantiate(this.merHero);
                tmp.parent = this.merHeros;
                let hero = heros[i]
                if (hero) {
                    this._borrowHeros.push({ index: i + 1, data: hero, node: tmp });
                } else {
                    this._borrowHeros.push({ index: i + 1, data: null, node: tmp });
                    continue;
                }

                tmp.getChildByName("hero_head").active = true;
                let spineHero = tmp.getChildByName("hero_head").getComponent(sp.Skeleton);
                await gm.createHeroSpine(hero, spineHero);
                spineHero.skeletonData.lock();
                this._skeletonDatas.push(spineHero.skeletonData);

                let btn: cc.Button = tmp.getChildByName("btn").getComponent(cc.Button);
                btn.clickEvents[0].handler = `onMerHeroClick`;
                btn.clickEvents[0].customEventData = `${i + 1}`;

                let user = friendMerLogic.getUserDataByRoleId(hero.real_data.roleId);
                if (!user) {
                    await friendMerLogic.userDataReq(hero.real_data.roleId);
                    user = friendMerLogic.getUserDataByRoleId(hero.real_data.roleId);
                }
                tmp.getChildByName("name").getComponent(cc.Label).string = user.getNickname();
            }
        } else {
            this._borrowHeros.forEach((v, i, a) => {
                let desc: cc.Label = v.node.getChildByName("name").getComponent(cc.Label);
                let heroNode: cc.Node = v.node.getChildByName("hero_head");

                heroNode.active = v.data ? true : false;
                if (v.data) {
                    let heros: HeroMerc[] = friendMerLogic.getBorrowedHeros();
                    let has = heros.some((value, i, a) => { return value.getId() == v.data.getId(); });
                    heroNode.active = has;
                    if (has) {
                        let user = friendMerLogic.getUserDataByRoleId(v.data.real_data.roleId);
                        desc.string = user.getNickname();

                        if (v.data.getSpineSkin().length > 0) {
                            heroNode.getComponent(sp.Skeleton).setSkin(v.data.getSpineSkin());
                        }
                    } else {
                        v.data = null;
                        desc.string = stringConfigMap.key_friend_tip10.Value;
                        heroNode.getComponent(sp.Skeleton).clearTracks();
                    }

                } else {
                    desc.string = stringConfigMap.key_friend_tip10.Value;
                    heroNode.getComponent(sp.Skeleton).clearTracks();
                }
            });
        }
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onClosePanel, (data) => {
            if (data == "FriendPanel") {
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);

        let listener1 = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data == "FriendPanel") {
                this.showFriendView();
                this.freshUI();
            }
        });
        this._eventListeners.push(listener1);

        listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType, goto: Goto }) => {
            if (data.type == BattleType.Record || data.type == BattleType.PVP_PlayBack)
                return;
            if (data.goto == Goto.HeroList) {
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);
    }

    async reqfriends() {
        let result = await friendLogic.friendsReq();
    }

    async reqmanagers() {
        let result = await friendLogic.manageReq();
    }

    showFriendView() {
        let tmp = friendLogic.getFriends();
        tmp.sort((a, b) => {
            let statuA: number = a.isOnline() ? 1 : 0;
            let statuB: number = b.isOnline() ? 1 : 0;
            if (statuA == statuB) {
                if (statuA == 1) {
                    if (a.getPower() == b.getPower()) {
                        if (a.getLevel() == b.getLevel()) {
                            if (a.getNickname() < b.getNickname()) { return -1; }
                            else { return 1; }
                        } else {
                            return b.getLevel() - a.getLevel();
                        }
                    } else {
                        return b.getPower() - a.getPower();
                    }
                } else {
                    return b.getLastOfflineTimestamp() - a.getLastOfflineTimestamp();
                }

            } else {
                return statuB - statuA;
            }
        })
        this.data = tmp;
        this.friendScrollView.getComponent(ScrollViewLoader).refresh(this.data, false, this.onClickFriendCell.bind(this));
        this.noFriendBg.active = friendLogic.getFriends().length == 0;
    }

    async onClickFriendCell(data: any) {
        if (data && data instanceof Friend) {
            let result = await friendLogic.playerShow(data.getRoleId(), true);
            let userInfo = friendLogic.getPlayerInfo(data.getRoleId());
            gcc.core.showLayer("prefabs/panel/player/UserPanel", { data: { user: userInfo } });

            this.showFriendView();
        }
    }

    async onClickTab(event: cc.Event.EventTouch, index: string) {
        let tabSelect: number = parseInt(index);
        if (this._currentTab == tabSelect) {
            return;
        }

        this._currentTab = tabSelect;
        let showFriend: boolean = this._currentTab == 1 ? true : false;
        this.friendNode.active = showFriend;
        this.merNode.active = !showFriend;
        if (showFriend) {

        } else {
            if (friendMerLogic.getShowMercHeros(0).length == 0) {
                await friendMerLogic.mercHerosReq();
                this.initMerHeroScrollView(true);
                this.freshMerHero(true);
            } else {
                this.initMerHeroScrollView(false);
                this.freshMerHero(false);
            }

            let timeSec = (friendMerLogic.resetTimestamp - gm.getCurrentTimestamp()) / 1000;
            let str: string = stringUtils.formatTimeLater(Math.floor(timeSec));
            this.merReturnTime.getComponent(cc.Label).string = str;

        }
    }

    onClickHeroFilter(event: cc.Event.EventTouch, index: string) {
        // 佣兵英雄选择
        let tag: number = parseInt(index);
        tag -= 1;

        if (this._filterTag == tag) {
            return;
        }
        this._filterTag = tag;
        this.initMerHeroScrollView(false);
    }

    onClickMerManager() {
        gcc.core.showLayer("prefabs/panel/friend/MerManagerPanel");
    }

    async onMerHeroClick(sender: cc.Event.EventTouch, index: string) {
        let borrowIndex: number = parseInt(index);
        // 显示雇佣到的英雄信息
        let data = this._borrowHeros[borrowIndex - 1]
        if (data && data.data) {
            let user = friendMerLogic.getUserDataByRoleId(data.data.real_data.roleId);
            if (!user) {
                await friendMerLogic.userDataReq(data.data.real_data.roleId);
            }
            let heroId: string = data.data.getId();
            gcc.core.showLayer("prefabs/panel/hero/HeroInfoPanel", {
                data: {
                    hero: data.data, viewType: HeroInfoPanel.ViewType.Merc, owner: user, callback: async () => {
                        // 
                        await friendMerLogic.backMercHeroReq(heroId);
                        await friendMerLogic.mercHerosReq();
                        this.initMerHeroScrollView(false);
                        this.freshMerHero(false);
                        //this._borrowHeros[borrowIndex - 1].data = null;
                        //this.freshMerHero(false);
                    }
                }
            });
        }
    }

    onClickMerHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "friendmer" } });
    }

    // 一键领取和赠送
    async onClickoneKeyGetAndGive() {

        if (friendLogic.getFriends().length == 0) {
            gm.toast(stringConfigMap.key_friend_tip1.Value);
            return;
        }
        let oneKey: boolean = friendLogic.getFriends().some((v, i, a) => {
            return v.isCanGet() || v.isCanSend()
        });
        if (!oneKey) {
            gm.toast(stringConfigMap.key_friend_tip9.Value);
            console.error("没有可以赠送和领取友情点的好友数据!")
            return;
        }

        let sendIds = friendLogic.getCanSendIds();
        let recvIds = friendLogic.getCanGetIds();
        if (sendIds.length == 0 && recvIds.length == 0) {
            gm.toast(stringConfigMap.key_common_tip11.Value);
            return;
        }

        try {
            let num = sendIds.length;
            let toastStr = "";
            if (num > 0) {
                if (recvIds.length > 0) {
                    toastStr = "领取和赠送成功";
                } else {
                    toastStr = "赠送成功";
                }
            } else {
                if (recvIds.length > 0) {
                    toastStr = "领取成功";
                }
            }
            await friendLogic.sendHeartBatchReq(sendIds);
            await friendLogic.recvHeartBatchReq(recvIds);
            this.showFriendView();
            assignmentLogic.dailyTaskProCommit(DailyType.send_friend, num);
            this.freshUI();
            gm.toast(toastStr);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    async onClickFriendManager() {
        await this.reqmanagers();
        gcc.core.showLayer("prefabs/panel/friend/FriendManagerPanel", {
            data: {
                callback: (data: any) => {
                    this.showFriendView();
                    this.freshUI();
                }
            }
        });
    }

    onClickSort() {

        this.sortView.active = true;
    }

    onClickTouch() {
        this.sortView.active = false;
    }

    onClickStatuSort() {
        // 在线状态排序
        if (this.data instanceof Array) {
            this.data.sort((a: FriendInfoItem, b: FriendInfoItem) => {
                if (a.online) {
                    return b.online ? 0 : -1;
                } else {
                    return b.online ? 0 : 1;
                }
            })
        }
        this.showFriendView();
        this.sortView.active = false;
    }
    onClickNameSort() {
        // 名称排序
        if (this.data instanceof Array) {
            this.data.sort((a: FriendInfoItem, b: FriendInfoItem) => {
                let p1: string = a.nick;
                let p2: string = b.nick;
                if (p1 === p2) {
                    return 0;
                } else {
                    return p1 > p2 ? -1 : 1;
                }
            })
        }
        this.showFriendView();
        this.sortView.active = false;
    }

    onClickTip() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "friend" } });
    }

    freshUI() {
        let str: string = `${friendLogic.friendCount()}/${defaultConfigMap.friendsnumberlimit.value}`;
        this.friend_nums.getComponent(cc.Label).string = str;

        str = `${friendLogic.getNowHeart()}`;
        this.friend_hearts.getComponent(cc.Label).string = str;

        str = `${friendLogic.getSendedHeart()}/${defaultConfigMap.friendpointsendlimit.value}`;
        this.friend_heart_limit.getComponent(cc.Label).string = str;
    }

    protected _unloadRes(prefab: cc.Prefab) {
        super._unloadRes(prefab);
        this._releaseSkeletonDatas();
    }

    protected _releaseSkeletonDatas() {
        for (let skeletonData of this._skeletonDatas) {
            skeletonData.unlock();
            loadUtils.releaseAssetRecursively(skeletonData);
        }
        this._skeletonDatas = [];
    }
}
