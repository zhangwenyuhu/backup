import { defaultConfigMap } from './../../../configs/defaultConfig';
import { PopupPanel } from "../BasePanel";
import friendLogic from "../../../logics/FriendLogic";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import gm from '../../../manager/GameManager';
import { stringConfigMap } from '../../../configs/stringConfig';
import EManager, { EName } from '../../../manager/EventManager';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/friend/FriendManagerPanel")
export default class FriendManagerPanel extends PopupPanel {

    @property(cc.Label)
    friend_num: cc.Label = null;

    @property(cc.Label)
    apply_num: cc.Label = null;

    @property(cc.Label)
    black_num: cc.Label = null;

    @property(cc.Node)
    applyScrollview: cc.Node = null;

    @property(cc.Node)
    searchScrollView: cc.Node = null;

    @property(cc.Node)
    blackScrollView: cc.Node = null;

    @property(cc.Node)
    apply: cc.Node = null;

    @property(cc.Node)
    search: cc.Node = null;

    @property(cc.Node)
    black: cc.Node = null;

    @property(cc.Node)
    searchBtn: cc.Node = null;

    @property(cc.Node)
    clearBtn: cc.Node = null;

    @property(cc.Node)
    inputName: cc.Node = null;

    private _currentTab: number = 0;
    onInit(data: any) {

    }

    start() {
        super.start();

        this.clearBtn.active = false;
        this.registerEvents();
        this.showTab(1);
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onClosePanel, (data) => {
            if (data == "FriendManagerPanel") {
                this._data.callback=null;
                this.closePanel();
            }
        });
        this._eventListeners.push(listener);

        let listener1 = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data == "FriendManagerPanel") {
                this.showTab(this._currentTab);
            }
        });
        this._eventListeners.push(listener1);
    }

    onDestroy() {
        if (this._data && this._data.callback) {
            this._data.callback();
        }
        super.onDestroy();
    }

    onClickTab(sender: cc.Event.EventTouch, index: string) {
        let tab: number = parseInt(index);
        this.showTab(tab);
    }

    private showTab(index: number) {
        this.apply.active = false;
        this.search.active = false;
        this.black.active = false;
        this._currentTab = index;
        if (index == 1) {
            // 申请
            this.apply.active = true;
            this.freshApplyUI();
            this.showApplyPlayers();
        } else if (index == 2) {
            // 查找
            this.search.active = true;
            this.freshSearchUI();
        } else if (index == 3) {
            // 黑名单
            this.black.active = true;
            this.freshBlackUI();
            this.showBlackPlayers();
        }
    }

    private showApplyPlayers() {
        let applyPlayers = friendLogic.getApplyPlayers();
        this.applyScrollview.getComponent(ScrollViewLoader).refresh(applyPlayers, false, this.onFreshApplyList.bind(this));
    }

    onFreshApplyList(data: any) {
        this.showApplyPlayers();
        if (this._currentTab == 1) {
            this.freshApplyUI();
        } else if (this._currentTab == 2) {
            this.freshSearchUI();
        } else if (this._currentTab == 3) {
            this.freshBlackUI();
        }
    }

    private showBlackPlayers() {
        let blacks = friendLogic.getBlackPlayers();
        this.blackScrollView.getComponent(ScrollViewLoader).refresh(blacks, false, this.onFreshBlackList.bind(this));
    }

    onFreshBlackList(data: any) {
        this.showBlackPlayers();
    }

    private async showSearchPlayers() {
        let keyword: string = this.inputName.getComponent(cc.EditBox).string;
        let limit: number = 10;
        if (keyword == "" || !keyword) {
            console.error("搜索内容为空!");
            gm.toast(stringConfigMap.key_friend_tip5.Value);
            return;
        }

        await friendLogic.searchReq({ keyword: keyword, limitCount: limit });
        let searchs = friendLogic.getSearchPlayers();
        this.searchScrollView.getComponent(ScrollViewLoader).refresh(searchs);
        if (searchs.length == 0) {
            gm.toast(stringConfigMap.key_friend_tip4.Value);
        }
    }

    async onClickIgnoreAll() {
        if (friendLogic.getAllApplyRelationIds().length == 0) {
            gm.toast(stringConfigMap.key_friend_tip6.Value);
            return;
        }
        await friendLogic.ignoreApplyReq(friendLogic.getAllApplyRelationIds());
        //this.showApplyPlayers();
        this.onFreshApplyList(null);
    }
    async onClickAgreeAll() {
        if (friendLogic.getAllApplyRelationIds().length == 0) {
            gm.toast(stringConfigMap.key_friend_tip6.Value);
            return;
        }
        await friendLogic.acceptApplyReq(friendLogic.getAllApplyRelationIds());
        //this.showApplyPlayers();
        this.onFreshApplyList(null);
    }


    onClickSearch() {
        this.showSearchPlayers();
    }
    onClickClear() {
        this.inputName.getComponent(cc.EditBox).string = "";
        this.clearBtn.active = false;

        friendLogic.clearSearchPlayers();
        this.searchScrollView.getComponent(ScrollViewLoader).refresh([]);
    }

    onEditBegin() {
        this.editFresh(true);
        this.editValid(true);
    }
    onEditchange() {

    }
    onEditEnd() {
        this.editFresh();
        this.editValid(false);
    }
    editValid(valid: boolean) {
        if (valid && !CC_PREVIEW) {
            this.node.getChildByName("bg").y = -200;
        } else {
            this.node.getChildByName("bg").y = 0;
        }
    }

    private editFresh(bShow?: boolean) {
        let valid: boolean = bShow || this.inputName.getComponent(cc.EditBox).string.length > 0;
        this.clearBtn.active = valid;
    }

    private freshApplyUI() {
        let str: string = `${friendLogic.friendCount()}/${defaultConfigMap.friendsnumberlimit.value}`;
        this.friend_num.getComponent(cc.Label).string = str;

        str = `${friendLogic.applyCount()}/${defaultConfigMap.friendsnumberlimit.value}`;
        this.apply_num.getComponent(cc.Label).string = str;


        if (this.apply.getChildByName("bg")) {
            this.apply.getChildByName("bg").active = friendLogic.getApplyPlayers().length == 0;
        }
    }
    private freshSearchUI() {
        let str: string = `${friendLogic.friendCount()}/${defaultConfigMap.friendsnumberlimit.value}`;
        this.search.getChildByName("friend_num").getComponent(cc.Label).string = str;
    }
    private freshBlackUI() {
        this.black_num.getComponent(cc.Label).string = `${friendLogic.blackCount()}`;
        if (this.black.getChildByName("bg")) {
            this.black.getChildByName("bg").active = friendLogic.blackCount() == 0;
        }
    }
}
