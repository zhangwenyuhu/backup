import { PopupPanel } from "../BasePanel";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import friendMerLogic from "../../../logics/FriendMerLogic";
import { defaultConfigMap } from "../../../configs/defaultConfig";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/friend/MercenaryPanel")
export default class MercenaryPanel extends PopupPanel {

    @property(cc.Node)
    applyScrollView: cc.Node = null;

    @property(cc.Node)
    applyNum: cc.Node = null;

    private _heroIndex: number = 0;
    private _maxApplyNum: number = 5;
    private _applyingNum: number = 0;
    onInit(data: any) {
        this._heroIndex = data;
    }

    start() {
        super.start();
        this.initApplyView();
        this.schedule(this.freshApplyingNum, 1);
    }

    initApplyView() {
        this._maxApplyNum = defaultConfigMap.togetherapplylimit.value;
        let tmp = friendMerLogic.getMercHerosByCfgId(this._heroIndex);
        tmp.sort((a, b) => {
            if (a.getApplyIndex() != b.getApplyIndex()) {
                return a.getApplyIndex() - b.getApplyIndex();
            } else if (a.getRank() != b.getRank()) {
                return b.getRank() - a.getRank();
            } else {
                return b.getPower() - a.getPower();
            }
        });
        this.applyScrollView.getComponent(ScrollViewLoader).refresh(tmp, false, this.freshScroll.bind(this));

        let num: string = `${friendMerLogic._applyingNum}/${this._maxApplyNum}`;
        this.applyNum.getComponent(cc.Label).string = num;
        this._applyingNum = friendMerLogic._applyingNum;
    }

    freshScroll(data: any) {
        let tmp = friendMerLogic.getMercHerosByCfgId(this._heroIndex);
        this.applyScrollView.getComponent(ScrollViewLoader).refresh(tmp, false, this.freshScroll.bind(this));
    }

    freshApplyingNum() {
        if (this._applyingNum == friendMerLogic._applyingNum) {
            return;
        }
        let num: string = `${friendMerLogic._applyingNum}/${this._maxApplyNum}`;
        this.applyNum.getComponent(cc.Label).string = num;
        this._applyingNum = friendMerLogic._applyingNum;
    }
}
