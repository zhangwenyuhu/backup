import BasePanel, { PopupPanel } from "../BasePanel";
import PopBg from "../../component/PopBg";
import CommonLoader from "../../common/CommonLoader";
import missionLogic from "../../../logics/MissionLogic";
import cm from "../../../manager/ConfigManager";
import gotoUtils, { GotoModule } from "../../../utils/GotoUtils";
import UnlockWrapper from "../../widget/unlock/UnlockWrapper";
import { unlockConfigMap } from "../../../configs/unlockConfig";
import gm from "../../../manager/GameManager";
import playerLogic from "../../../logics/PlayerLogic";


const { ccclass, property, menu } = cc._decorator;
// 玩法推荐窗口
@ccclass
@menu("view/panel/mission/SuggestPanel")
export default class SuggestPanel extends PopupPanel {

    @property(CommonLoader)
    dialog: CommonLoader = null;

    @property(cc.Label)
    labelLevel: cc.Label = null;

    onInit(data) {
        super.onInit(data);
    }

    start() {
        super.start();

        let comp = this.dialog.loaderNode.getComponent(PopBg);
        comp.closeCallback = () => { this.closePanel() };

        let stageId: number = missionLogic.getCurrentMission().getStageId();
        let cfg = cm.getStageConfig(stageId);
        this.labelLevel.string = `${cfg.PlayerLevel}级`;
    }

    async onClickHangup() {
        BasePanel.closePanel('BuildingInfoPanel');
        this.closePanel();

        let timestamp = playerLogic.startHangupTS;
        let resource = await playerLogic.doClaimHangupReward();
        let delta = (gm.getCurrentTimestamp() - timestamp) / 1000;
        gcc.core.showLayer("prefabs/panel/hangup/HangupRewardPanel", { data: { resource: resource, dt: delta }, modalTouch: true });
    }
    onClikcQuickHang() {
        BasePanel.closePanel('BuildingInfoPanel');
        this.closePanel();
        gotoUtils.gotoPanel(GotoModule.HangUpFast);
    }
    onClickGotoRes() {
        if (!UnlockWrapper.isUnlock(unlockConfigMap.资源副本)) {
            gm.toast(unlockConfigMap.资源副本.tips);
        } else {
            gotoUtils.gotoPanel(GotoModule.Material);
        }
        BasePanel.closePanel('BuildingInfoPanel');
        this.closePanel();
    }
}
