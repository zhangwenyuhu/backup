import { EName } from './../../../manager/EventManager';
import { PopupPanel } from "../BasePanel";
import EManager from "../../../manager/EventManager";
import loadUtils from '../../../utils/LoadUtils';
import missionLogic from '../../../logics/MissionLogic';
import commonUtils from '../../../utils/CommonUtils';
import gm from '../../../manager/GameManager';

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/mission/ChapterPassedPanel")
export default class ChapterPassedPanel extends PopupPanel {
    @property(cc.Node)
    touchNode: cc.Node = null;

    @property(cc.Sprite)
    clearSprite: cc.Sprite = null;

    @property(cc.Sprite)
    lightSprite: cc.Sprite = null;

    @property(cc.SpriteFrame)
    clearFrame: cc.SpriteFrame = null;

    @property(cc.SpriteFrame)
    lightFrame: cc.SpriteFrame = null;

    @property(cc.Animation)
    cloudAnimation: cc.Animation = null;

    protected _isCountryPassed: boolean = false;
    protected _closeCallback: Function = null;

    onInit(data: { name: string, isCountryPassed: boolean, closeCallback: Function }) {
        super.onInit(data);
        this._isCountryPassed = data.isCountryPassed;
        if (this._isCountryPassed) {
            this.clearSprite.spriteFrame = this.clearFrame;
            this.lightSprite.spriteFrame = this.lightFrame;
        }
        this._closeCallback = data.closeCallback;
    }

    async start() {
        super.start();

        this.touchNode.active = false;

        this.node.getChildByName("light").active = true;
        this.node.getChildByName("clear").active = true;
        this.node.getChildByName("star").active = true;
        let ani = this.node.getComponent(cc.Animation);
        if (ani) {
            ani.play("clear_ruchang", 0);
            ani.off("finished");
            ani.on("finished", (e) => {
                ani.play("clear_loop", 0);
                this.touchNode.active = true;
            })
        }
    }

    onDestroy() {
        super.onDestroy();
        if (this._closeCallback) this._closeCallback();
    }

    async onNext() {
        this.cloudAnimation.node.active = true;
        this.cloudAnimation.off("finished");
        this.cloudAnimation.on("finished", async () => {
            if (this.cloudAnimation.currentClip.name == "Dungeon_map_ICloud1") {
                this.cloudAnimation.node.active = false;
                if (this._isCountryPassed) {
                    EManager.emit(EName.onNextCountry);
                }
                else {
                    EManager.emit(EName.onNextChapter);
                }
                this.closePanel();
            }
            else {
                await this._loadNextChapter();
                this.cloudAnimation.play("Dungeon_map_ICloud1");
            }
        });
        this.cloudAnimation.play("Dungeon_map_ICloud2");
    }

    protected async _loadNextChapter() {
        let chapter = missionLogic.getCurrentChapter();
        if (chapter) {
            let prefab = await loadUtils.loadRes(`prefabs/chapter/chapter${chapter.getId()}`, cc.Prefab) as cc.Prefab;
            if (!gm.usePerformance) {
                await commonUtils.addChapterFgSpriteFrame(prefab.data);
            }
        }
    }
}
