import { PopupPanel } from "../BasePanel";
import Building from "../../../data/mission/Building";
import CommonLoader from "../../common/CommonLoader";
import HeroCard from "../../component/Hero/HeroCard";
import GoodCard from "../../component/Good/GoodCard";
import Mission from "../../../data/mission/Mission";
import MissionItem from "../../widget/mission/MissionItem";
import { RefreshLabel } from "../../../decorator/RefreshDecorator";
import EManager, { EName } from "../../../manager/EventManager";
import tipUtils from "../../../utils/TipUtils";
import Monster from "../../../data/card/Monster";
import List from "../../common/List";
import { BattleType } from "../../../utils/DefineUtils";
import CloneBattleData from "../../../data/clone/CloneBattleData";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/mission/BuildingInfoPanel")
export default class BuildingInfoPanel extends PopupPanel {

    @RefreshLabel({
        getData: (caller: BuildingInfoPanel) => { return caller.building },
        getValue: (caller: Building) => { return caller.getName() }
    })
    @property(cc.Label)
    labelTitle: cc.Label = null;

    @property(cc.Node)
    enemyList: cc.Node = null;

    @property(cc.Node)
    enemyIcon: cc.Node = null;

    @property(cc.Node)
    rewardList: cc.Node = null;

    @property(cc.Node)
    rewardIcon: cc.Node = null;

    @property(cc.Node)
    popBg: cc.Node = null;

    @property(cc.Node)
    touchBg: cc.Node = null;

    @property(List)
    missionList: List = null;

    building: Building = null;

    protected _missions: Mission[] = [];

    onInit(building: Building) {
        super.onInit(building);
        this.building = building;
    }

    onLoad() {
        super.onLoad();

        this.enemyIcon.parent = null;
        this.rewardIcon.parent = null;
        this.touchBg.active = false;
        this.touchBg.on(cc.Node.EventType.TOUCH_START, this._onTouchStart, this);
        this.registerEvents();
    }

    onDestroy() {
        super.onDestroy();

        this.touchBg.off(cc.Node.EventType.TOUCH_START, this._onTouchStart, this);
        this.enemyIcon.destroy();
        this.rewardIcon.destroy();
    }

    start() {
        super.start();

        this._missions = this.building.getMissions();
        this.missionList.numItems = this._missions.length;
        let currentMission = this.building.getCurrentMission();
        for (let i = 0; i < this._missions.length; i++) {
            if (currentMission == this._missions[i]) {
                this.scheduleOnce(() => { this.missionList.scrollTo(i, 0.2); });
                break;
            }
        }
    }

    onRenderItem(item: cc.Node, index: number) {
        let currentMission = this.building.getCurrentMission();
        let comp = item.getComponent(MissionItem);
        comp.init(this.building, this._missions[index], currentMission == this._missions[index], (worldPosition: cc.Vec2, m: Mission) => {
            this._showMissionInfo(worldPosition, m);
        });
    }

    registerEvents() {
        let listener = EManager.addEvent(EName.onGameExit, (data: { type: BattleType }) => {
            if (data.type == BattleType.Record || data.type == BattleType.PVP_PlayBack)
                return;
            this.closePanel();
        });
        this._eventListeners.push(listener);
    }

    onChallenge() {
        gcc.core.showLayer("prefabs/panel/battle/BattlePreparePanel", {
            data: this.building.getCurrentMission()
        });
    }

    onUp() {
        gcc.core.showLayer("prefabs/panel/mission/SuggestPanel");
    }

    showGoodTip(e: cc.Event.EventTouch) {
        let node = e.target as cc.Node;
        let loader = node.getComponent(CommonLoader);
        let card = loader.loaderNode.getComponent(GoodCard);
        tipUtils.showTip(node, card.good.getDesc());
    }

    protected _onTouchStart() {
        this.touchBg.active = false;
    }

    protected _showMissionInfo(worldPoint: cc.Vec2, mission: Mission) {
        this.touchBg.active = true;
        this.popBg.position = this.popBg.parent.convertToNodeSpaceAR(worldPoint);

        this.enemyList.destroyAllChildren();
        this.rewardList.destroyAllChildren();

        let monsters = mission.getMonsters();
        let newMonsters = [];
        for (let monster of monsters) {
            if (monster) newMonsters.push(monster);
        }
        newMonsters.sort((a: Monster, b: Monster) => { return b.getPower() - a.getPower() });

        for (let i = 0; i < newMonsters.length; i++) {
            let monster = newMonsters[i];
            let item = cc.instantiate(this.enemyIcon);
            item.parent = this.enemyList;

            let loader = item.getComponent(CommonLoader);
            let card = loader.loaderNode.getComponent(HeroCard);
            card.refresh(monster);

            if (i == 0) {
                let boss = item.getChildByName("boss");
                boss.active = true;
                boss.zIndex = 10;
            }
        }

        let goods = mission.getRewards();
        for (let good of goods) {
            let item = cc.instantiate(this.rewardIcon);
            item.parent = this.rewardList;

            let loader = item.getComponent(CommonLoader);
            let card = loader.loaderNode.getComponent(GoodCard);
            card.refresh(good);
        }
    }
}
