import { PopupPanel } from "../BasePanel";
import announceLogic from "../../../logics/AnnounceLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/announce/AnnouncePanel")
export default class AnnouncePanel extends PopupPanel {
    @property(cc.RichText)
    richText: cc.RichText = null;

    start() {
        super.start();

        this.richText.string = "";
        this.node.runAction(cc.sequence(cc.delayTime(0.1), cc.callFunc(() => {
            let annouce = announceLogic.announces[0];
            this.richText.string = annouce.content;
        })));
    }
}
