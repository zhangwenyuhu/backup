import { PopupPanel } from "../BasePanel";
import xsLogic from "../../../logics/XuanshangLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/xs/XsMaxLevelPanel")
export default class XsMaxLevelPanel extends PopupPanel {

    @property(cc.Node)
    xs_lv: cc.Node = null;

    private _level: number = 0;
    onInit(data: any) {
        super.onInit(data);

        this._level = xsLogic.getXslevel() || 1;
    }

    start() {
        super.start();
        this.freshPanel();
    }

    freshPanel() {
        this.xs_lv.getComponent(cc.Label).string = `Lv.${this._level}`;
    }
}
