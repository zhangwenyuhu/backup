import { PopupPanel } from "../BasePanel";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import Hero from "../../../data/card/Hero";
import xsLogic from "../../../logics/XuanshangLogic";
import CustomScrollView from "../../../gleecomponent/CustomScrollView";
import heroLogic from "../../../logics/HeroLogic";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/xs/HelpHeroSetPanel")
export default class HelpHeroSetPanel extends PopupPanel {

    @property(cc.Node)
    heroScrollview: cc.Node = null;

    private _currentTab: number = 1;
    private _heros: Hero[] = [];

    onInit(data: any) {
        this._heros = xsLogic.getUserHeros();
    }

    start() {
        super.start();
        this._currentTab = 1;
        xsLogic.selectingHelpHeroIds = "";
        this.showHelpHeroSetView(this._currentTab);
    }

    showHelpHeroSetView(tab: number) {
        let tmp: Hero[] = [];
        if (tab == 1) {
            tmp = this._heros.map((v, i, a) => { return v; });
        } else {
            tmp = this._heros.filter((v, i, a) => { return v.getFaction() == (tab - 1); });
        }
        heroLogic.sortHeroes(tmp);
        this.heroScrollview.getComponent(ScrollViewLoader).refresh(tmp, true, this.onCellClick.bind(this));
    }

    onCellClick(data: any) {
        if (data && data instanceof Hero) {
            let id: string = data.getId();
            xsLogic.selectingHelpHeroIds = xsLogic.selectingToHelp(id) ? "" : id;
            this.heroScrollview.getChildByName("scrollView").getComponent(CustomScrollView).updateVisibleItems();
        }
    }

    onFilterClick(event: cc.Event.EventTouch, index: string) {
        this._currentTab = parseInt(index);
        this.showHelpHeroSetView(this._currentTab);
    }

    onEnterClick() {
        let selectIds: string[] = [];
        if(xsLogic.selectingHelpHeroIds){
            selectIds.push(xsLogic.selectingHelpHeroIds);
        }
        
        if (selectIds.length > 0) {
            let selectedIds = xsLogic.getMyHelpHeroIds().map((v, i, a) => { return v.heroId; })
            selectIds = selectedIds.pushList(selectIds);
            this.doHelpSet(selectIds);
        } else {
            this.closePanel();
        }
    }

    onCloseClick() {
        xsLogic.selectingHelpHeroIds = "";
        this.closePanel();
    }

    async doHelpSet(ids: string[]) {
        let result = await xsLogic.setMyHelpHeroReq(ids);
        if (this.data && this.data.callback) {
            this.data.callback();
        }
        this.closePanel();
    }
}
