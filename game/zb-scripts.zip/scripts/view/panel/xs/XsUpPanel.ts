import { PopupPanel } from "../BasePanel";
import xsLogic from "../../../logics/XuanshangLogic";
import cm from "../../../manager/ConfigManager";
import heroUtils from "../../../utils/HeroUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/xs/XsUpPanel")
export default class XsUpPanel extends PopupPanel {

    @property(cc.Node)
    nowLevel: cc.Node = null;

    @property(cc.Node)
    preLevel: cc.Node = null;

    @property(cc.Node)
    taskRank: cc.Node = null;

    @property(cc.Node)
    preTaskRanks: cc.Node = null;

    @property(cc.Node)
    nowTaskRanks: cc.Node = null;

    onInit(data: any) {
        super.onInit(data);
    }

    onLoad() {
        super.onLoad();

        this.taskRank.parent = null;

        let effect = this.node.getComponent(cc.Animation)
        effect.on("finished", () => {
            effect.play("player_shengji_loop");
            effect.getAnimationState("player_shengji_loop").wrapMode = cc.WrapMode.Loop;
        })
    }

    onDestroy() {
        super.onDestroy();

        this.taskRank.destroy();
    }

    start() {
        super.start();
        this.freshUi();
    }

    freshUi() {
        let nowLevel = xsLogic.getXslevel();

        this.preLevel.getComponent(cc.Label).string = `Lv.${nowLevel - 1}`;
        this.nowLevel.getComponent(cc.Label).string = `Lv.${nowLevel}`;

        this.preTaskRanks.destroyAllChildren();
        this.nowTaskRanks.destroyAllChildren();

        this.rankNode(this.preTaskRanks, nowLevel - 1);
        this.rankNode(this.nowTaskRanks, nowLevel);
    }

    rankNode(node: cc.Node, level: number) {
        let cfg = cm.getXsLvConfig(level);
        if (cfg && cfg.Rank) {
            cfg.Rank.forEach((v, i, a) => {
                let tmp = cc.instantiate(this.taskRank);
                tmp.parent = node;

                let color = cc.Color.WHITE;
                color.fromHEX(heroUtils.getXsQualityColor(v));
                tmp.color = color;
                tmp.getComponent(cc.Label).string = heroUtils.getXsQualityStr(v);
            })
        }
    }
}
