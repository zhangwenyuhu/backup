import { PopupPanel } from "../BasePanel";
import xsLogic from "../../../logics/XuanshangLogic";
import Task from "../../../data/xuanshang/task";
import Good from "../../../data/card/Good";
import { GoodVO, XsReq } from "../../../proxy/GameProxy";
import CommonLoader from "../../common/CommonLoader";
import GoodCard from "../../component/Good/GoodCard";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import loadUtils from "../../../utils/LoadUtils";
import HeroXs from "../../../data/xuanshang/HeroXs";
import HeroHelp from "../../../data/xuanshang/HeroHelp";
import HeroCardXsSelect from "../../component/Hero/HeroCardXsSelect";
import assignmentLogic from "../../../logics/AssignmentLogic";
import { DailyType, WeekType } from "../../../utils/DefineUtils";
import gm from "../../../manager/GameManager";
import friendMerLogic from "../../../logics/FriendMerLogic";
import { stringConfigMap } from "../../../configs/stringConfig";
import EManager, { EName } from "../../../manager/EventManager";
import tipUtils from "../../../utils/TipUtils";
import heroUtils from "../../../utils/HeroUtils";
import CustomScrollView from "../../../gleecomponent/CustomScrollView";
import commonUtils from "../../../utils/CommonUtils";
import playerLogic from "../../../logics/PlayerLogic";
import rechargeLogic, { RightType } from "../../../logics/RechargeLogic";
import stringUtils from "../../../utils/StringUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/xs/XsDispatchPanel")
export default class XsDispatchPanel extends PopupPanel {

    @property(cc.Node)
    task_title: cc.Node = null;

    @property(cc.Node)
    reward_good: cc.Node = null;

    @property(cc.Node)
    dispatchNode: cc.Node = null;

    @property(cc.Node)
    self_hero: cc.Node = null;

    @property(cc.Node)
    help_hero: cc.Node = null;

    @property(cc.Node)
    conditionNode: cc.Node = null;

    @property(cc.Node)
    condition_quality: cc.Node = null;

    @property(cc.Node)
    condition_type: cc.Node = null;

    @property(cc.Node)
    heroScrollView: cc.Node = null;

    @property(cc.Node)
    myHeroNode: cc.Node = null;

    @property(cc.Node)
    helpMeHeroNode: cc.Node = null;

    @property(cc.Node)
    helpHeroScrollView: cc.Node = null;

    @property(cc.Button)
    dispatchBtn: cc.Button = null;

    @property(cc.Button)
    tipBtn: cc.Button = null;

    @property(cc.Button)
    oneKeyBtn: cc.Button = null;

    private _conditions: { node: cc.Node, faction?: number }[] = [];                                    // 条件节点
    private _heros: { node: cc.Node, self: boolean, index: number, select?: boolean, id?: string }[] = [];    // 派遣的英雄
    private _heroIndex: number = 0;
    private _task: Task = null;
    private _currnetIndex: string = "1";
    private _exitSameFaction: boolean = false;             // 条件存在相同的种族要求
    private _sameFaction: { [key: number]: number } = {};      // 种族和对应的个数要求
    private _action: boolean = true;
    private _bReqHelpHeros: boolean = true;
    private _selectedHeros: HeroXs[] = [];

    onInit(data: any) {
        super.onInit(data);

        this._task = data;
        this._conditions = [];
    }

    onLoad() {
        super.onLoad();

        this.self_hero.parent = null;
        this.help_hero.parent = null;
        this.condition_type.parent = null;
        this.condition_quality.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.self_hero.destroy();
        this.help_hero.destroy();
        this.condition_type.destroy();
        this.condition_quality.destroy();
    }

    start() {
        super.start();
        console.log("DispatchPanel data:");
        console.log(this._data);
        if (this._data && this._data instanceof Task) {
            let task: Task = this._data;
            this.task_title.getComponent(cc.Label).string = task.name;

            // reward
            let good: GoodVO = {
                amt: task.taskRewardNum,
                propId: task.taskReward.parameterid,
                objId: "" + task.taskReward.type
            };
            let rewardGood: Good = new Good(good);
            this.reward_good.getComponent(CommonLoader).loaderNode.getComponent(GoodCard).refresh(rewardGood);

            // dispatch hero
            this.dispatchNode.destroyAllChildren();
            let selfHeroNum: number = task.isPeronalTask ? task.taskCfg.CountCondition : task.taskCfg.CountCondition - 1;
            let heroNum: number = 0;
            for (let i = 0; i < selfHeroNum; i++) {
                let tmp: cc.Node = cc.instantiate(this.self_hero);
                tmp.parent = this.dispatchNode;
                heroNum += 1;
                tmp.getChildByName("btn").getComponent(cc.Button).clickEvents[0].customEventData = `${heroNum}`;
                this._heros.push({ node: tmp, self: true, index: heroNum });
            }
            if (!task.isPeronalTask) {
                let tmp: cc.Node = cc.instantiate(this.help_hero);
                tmp.parent = this.dispatchNode;
                heroNum += 1;
                tmp.getChildByName("btn").getComponent(cc.Button).clickEvents[0].customEventData = `${heroNum}`;
                this._heros.push({ node: tmp, self: false, index: heroNum });
            }

            // conditons
            this.conditionNode.destroyAllChildren();
            // 品阶和数量
            let tmp: cc.Node = cc.instantiate(this.condition_quality);
            tmp.parent = this.conditionNode;
            this._conditions.push({ node: tmp });
            // 种族
            task.heroFactions.forEach((v, i, a) => {
                tmp = cc.instantiate(this.condition_type);
                tmp.parent = this.conditionNode;
                this._conditions.push({ node: tmp, faction: v });
            });
            this.freshCondition(true);

            // heros
            this._currnetIndex = "1";
            this.freshCondition(false);

            let factionArr: number[] = this._conditions.map((v, i, a) => {
                return v.faction;
            });
            let factions: { [key: string]: boolean } = {};
            factionArr.forEach((v, i, a) => {
                if (v) {
                    if (factions[v]) {
                        if (this._sameFaction[v]) {
                            this._sameFaction[v] += 1;
                        } else {
                            this._sameFaction[v] = 2;
                        }
                    }
                    factions[v] = true;
                }
            });
            this._exitSameFaction = Object.keys(factions).length < this._heros.length;
        }
    }

    async herosReq() {
        await xsLogic.dispatchHerosReq();
        this.freshCondition(false);
    }

    async helpMeHerosReq() {
        await xsLogic.helpMeHeroReq();
        this.showHelpmeHeroView(this._currnetIndex);
        this.freshCondition(false);
    }

    private condition1SelectNum(quality: number) {
        let heros: HeroXs[] = [];
        heros = this._selectedHeros;
        //heros = this._selectedHeros.length<=0?xsLogic.getAllHelpHeros():this._selectedHeros;
        let num = 0;
        for (let i = 0; i < heros.length; i++) {
            if (heros[i].select && heros[i].rank >= quality) {
                num += 1;
            }
        }
        return num;
    }

    // 派遣条件类型1是否完成
    private completeCondition1(quality: number, num: number): boolean {
        return this.condition1SelectNum(quality) >= num;
    }
    // 派遣条件类型2是否完成
    private completeCondition2(faction: number): boolean {
        let heros: HeroXs[] = [];
        heros = this._selectedHeros;
        //heros = this._selectedHeros.length<=0?xsLogic.getAllHelpHeros():this._selectedHeros;
        let bComplete: boolean = false;
        for (let i = 0; i < heros.length; i++) {
            let v = heros[i];
            if (v.select && v.cfg.Faction == faction) {
                bComplete = true;
                break;
            }
        }
        return bComplete;
    }
    private completeCondition2Value(faction: number): number {
        let heros: HeroXs[] = [];
        heros = this._selectedHeros;
        //heros = this._selectedHeros.length<=0?xsLogic.getAllHelpHeros():this._selectedHeros;
        let completeValue: number = 0;
        for (let i = 0; i < heros.length; i++) {
            let v = heros[i];
            if (v.select && v.cfg.Faction == faction) {
                completeValue += 1;
            }
        }
        return completeValue;
    }

    // 刷新派遣条件ui
    private freshCondition(bInit: boolean) {
        let completeAll: boolean = true;
        let task: Task = this._data;
        if (bInit) {
            this._conditions.forEach((v, i, a) => {
                if (v.faction) {
                    let str: string = `textures/icon/hero/hero_tag_${v.faction}`;
                    loadUtils.loadSpriteFrame(str, v.node.getChildByName("icon").getComponent(cc.Sprite));
                } else {
                    let str: string = `0/${task.taskCfg.RankCondition[1]}`;
                    v.node.getChildByName("num").getComponent(cc.Label).string = str;

                    let qualityInfo = heroUtils.getHeroQualityInfo(task.taskCfg.RankCondition[0]);
                    str = commonUtils.getHeroQualityUrl(qualityInfo.qualityLevel);
                    loadUtils.loadSpriteFrame(str, v.node.getChildByName("icon").getComponent(cc.Sprite));
                }
                /*
                v.node.off(cc.Node.EventType.TOUCH_END);
                v.node.on(cc.Node.EventType.TOUCH_END, (e: cc.Touch) => {
                    let tip: string = "";
                    if (v.faction) {
                        let factionStr = heroUtils.getFactionStr(v.faction);
                        tip = `需要1个${factionStr}英雄`;
                    } else {
                        let heroInfo = heroUtils.getHeroQualityInfo(task.taskCfg.RankCondition[0]);
                        tip = `需要${task.taskCfg.RankCondition[1]}个${heroInfo.qualityStr}英雄`;
                    }
                    tipUtils.showTip(v.node, tip);
                })*/
                v.node.off('click');
                v.node.on('click', () => {
                    let tip: string = "";
                    if (v.faction) {
                        let factionStr = heroUtils.getFactionStr(v.faction);
                        tip = `需要1个${factionStr}英雄`;
                    } else {
                        let heroInfo = heroUtils.getHeroQualityInfo(task.taskCfg.RankCondition[0]);
                        tip = `需要${task.taskCfg.RankCondition[1]}个${heroInfo.qualityStr}英雄`;
                    }
                    tipUtils.showTip(v.node, tip);
                })
            });
        }

        this.setSelectingHeros();
        if (this._exitSameFaction) {
            // 存在相同种族的要求
            this._conditions.forEach((v, i, a) => {
                if (v.faction) {
                    let haveSame: boolean = this._sameFaction[v.faction] > 0;
                    let selectNode: cc.Node = v.node.getChildByName("select");
                    let iconNode = v.node.getChildByName("icon");
                    if (haveSame) {
                        let completeValue: number = this.completeCondition2Value(v.faction);
                        let index = this.getSameFactionIndex(v.faction, v.node);
                        selectNode.active = index <= completeValue;
                        completeAll = !selectNode.active ? false : completeAll;
                    } else {
                        selectNode.active = this.completeCondition2(v.faction);
                        completeAll = !selectNode.active ? false : completeAll;
                    }
                    iconNode.color = selectNode.active ? cc.Color.GRAY : cc.Color.WHITE;
                }
            });
        } else {
            this._conditions.forEach((v, i, a) => {
                if (v.faction) {
                    let selectNode: cc.Node = v.node.getChildByName("select");
                    let iconNode = v.node.getChildByName("icon");
                    selectNode.active = this.completeCondition2(v.faction);
                    completeAll = !selectNode.active ? false : completeAll;
                    iconNode.color = selectNode.active ? cc.Color.GRAY : cc.Color.WHITE;
                }
            });
        }

        let tmp = this._conditions[0]
        if (tmp && !tmp.faction) {
            let selectNode: cc.Node = tmp.node.getChildByName("select");
            let iconNode = tmp.node.getChildByName("icon");
            let quality: number = this._task.taskCfg.RankCondition[0];
            let limit: number = this._task.taskCfg.RankCondition[1];
            let select: number = this.condition1SelectNum(quality);
            selectNode.active = this.completeCondition1(quality, limit);
            tmp.node.getChildByName("num").getComponent(cc.Label).string = `${select}/${limit}`;

            completeAll = !selectNode.active ? false : completeAll;
            iconNode.color = selectNode.active ? cc.Color.GRAY : cc.Color.WHITE;
            tmp.node.getChildByName("num").color = iconNode.color;
        }

        this.dispatchBtn.interactable = completeAll;
        this.tipBtn.node.active = !completeAll;
        let oneKey = playerLogic.getPlayer().getVipLevel() >= rechargeLogic.getUnlockVipLevel(RightType.AutoXuanshang);
        this.oneKeyBtn.node.active = oneKey;
        if (this.tipBtn.node.active) {
            this.scheduleOnce(() => {
                this.tipBtn.node.x = this.dispatchBtn.node.x;
            }, 1 / 3);
        }
    }

    private getSameFactionIndex(fac: number, node: cc.Node): number {
        let index: number = 0;
        for (let i = 0; i < this._conditions.length; i++) {
            let v = this._conditions[i];
            if (v && v.faction && v.faction == fac) {
                index += 1;
                if (v.node == node) {
                    return index;
                }
            }
        }
        return index;
    }

    private setSelectingHeros() {
        let heros: HeroXs[] = xsLogic.getAllHelpHeros();
        this._selectedHeros = [];
        for (let i = 0; i < heros.length; i++) {
            if (heros[i].select) {
                this._selectedHeros.push(heros[i]);
            }
        }
    }

    // 刷新已派遣英雄ui
    private freshDispatchHeros(all: boolean = false) {
        this._heros.forEach((v, i, a) => {
            if (i == this._heroIndex - 1 || all) {
                if (v.self) {
                    let heroNode: cc.Node = v.node.getChildByName("hero");
                    if (v.select) {
                        let heroInfo = xsLogic.getMyHeroById(v.id);
                        heroNode.getComponent(CommonLoader).loaderNode.getComponent(HeroCardXsSelect).refresh(heroInfo);
                    }
                    heroNode.active = v.select;
                } else {
                    let helpNode: cc.Node = v.node.getChildByName("help");
                    if (v.select) {
                        let helpHeroInfo = xsLogic.getHelpMeHeroById(v.id);
                        helpNode.getComponent(CommonLoader).loaderNode.getComponent(HeroCardXsSelect).refresh(helpHeroInfo);
                    }
                    helpNode.active = v.select;
                }
            }
        });
    }

    // 显示我可派遣的英雄列表
    private showMyHeroView(index: string) {
        this.myHeroNode.active = true;
        this.helpMeHeroNode.active = false;

        let tag: number = parseInt(index);
        let data: HeroXs[] = [];

        if (tag == 1) {
            // 全部
            data = xsLogic.getAllHelpHeros();
            this.heroScrollView.getComponent(ScrollViewLoader).refresh(data, false, this.onClickHelpHeroCell.bind(this))
        } else {
            tag -= 1;
            data = xsLogic.getHeroByTag(tag);
            this.heroScrollView.getComponent(ScrollViewLoader).refresh(data, false, this.onClickHelpHeroCell.bind(this))
        }
    }

    // 显示可外援我的英雄列表
    private showHelpmeHeroView(index: string) {
        this.myHeroNode.active = false;
        this.helpMeHeroNode.active = true;

        let tag: number = parseInt(index);
        let data: HeroHelp[] = [];
        if (tag == 1) {
            // 全部
            data = xsLogic.getHelpMeHeros();
            this.helpHeroScrollView.getComponent(ScrollViewLoader).refresh(data, false, this.onClickHelpHeroCell.bind(this))
        } else {
            tag -= 1;
            data = xsLogic.getHelpMeHeroByTag(tag);
            this.helpHeroScrollView.getComponent(ScrollViewLoader).refresh(data, false, this.onClickHelpHeroCell.bind(this))
        }
    }

    onClickHelpHeroCell(data: any) {
        let index = this._heroIndex - 1;
        if (data && data instanceof HeroHelp) {
            // 点击了我的外援列表中的英雄
            let preId = this._heros[index].id;
            if (preId) {
                let preStatu: boolean = this._heros[index].select;
                if (data.id == preId) {
                    this._heros[index].select = !preStatu;
                    xsLogic.validHelpMeHeroSelect(preId, !preStatu);
                } else {
                    xsLogic.validHelpMeHeroSelect(preId, false);

                    this._heros[index].id = data.id;
                    this._heros[index].select = true;
                    xsLogic.validHelpMeHeroSelect(data.id, true);
                }
            } else {
                this._heros[index].select = true;
                this._heros[index].id = data.id;
                xsLogic.validHelpMeHeroSelect(data.id, true);
            }
        }
        if (data && data instanceof HeroXs) {
            // 点击了我的可派遣列表中的英雄
            let bSelect: boolean = this._heros.some((v, i, a) => {
                return v.select && v.id == data.id;
            });
            let heroId: string = data.id;
            if (!bSelect) {
                bSelect = xsLogic.isExitSameIndexInSelectHeros(heroId, data.cfg.Id);
                heroId = bSelect ? xsLogic.getSelectingHero(data.cfg.Id).id : heroId;
            }
            if (bSelect) {
                // 如果是已选中的 则取消选中
                this._heros.forEach((v, i, a) => {
                    if (v.id === heroId) {
                        v.select = false;
                        v.id = "";
                        xsLogic.getMyHeroById(heroId).select = false;
                        this._heroIndex = i + 1;
                    }
                });
            } else {
                // 未选中则选择合适的位置
                let bFull: boolean = this._heros.every((v, i, a) => {
                    return (v.id ? true : false && v.self) || !v.self;
                });
                if (bFull) {
                    if (this._task.isPeronalTask) {
                        gm.toast(stringConfigMap.key_xuanshang_tip5.Value);
                    } else {
                        gm.toast(stringConfigMap.key_xuanshang_tip6.Value);
                    }
                    return;
                } else {
                    for (let i = 0; i < this._heros.length; i++) {
                        if (!this._heros[i].id) {
                            this._heros[i].id = data.id;
                            this._heros[i].select = true;
                            xsLogic.getMyHeroById(data.id).select = true;
                            this._heroIndex = i + 1;
                            break;
                        }
                    }
                }
            }
            this.heroScrollView.getChildByName("scrollView").getComponent(CustomScrollView).updateVisibleItems();
        }
        this.freshCondition(false);
        this.freshDispatchHeros();
    }

    // 点击+ 选择我的可派遣英雄
    onClickSelectMyHero(sender: cc.Event.EventTouch) {
        let btn: cc.Button = sender.currentTarget.getComponent(cc.Button);
        let index: number = parseInt(btn.clickEvents[0].customEventData);
        this._heroIndex = index;

        for (let i = 0; i < this._heros.length; i++) {
            if (index == this._heros[i].index && this._heros[i].select) {
                xsLogic.getMyHeroById(this._heros[i].id).select = false;
                this._heros[i].id = "";
                this._heros[i].select = false;
                this.freshCondition(false);
                this.freshDispatchHeros();
                break;
            }
        }

        this.showMyHeroView(this._currnetIndex);
        this.showHelpHeroScrollViewAction();
    }

    // 点击+ 选择可外援我的英雄
    async onClickSelectHelpMeHero(sender: cc.Event.EventTouch) {
        let btn: cc.Button = sender.currentTarget.getComponent(cc.Button);
        let index: number = parseInt(btn.clickEvents[0].customEventData);
        this._heroIndex = index;

        if (this._bReqHelpHeros) {
            await this.helpMeHerosReq();
            this._bReqHelpHeros = false;
            this.helpHeroUserReq();
        } else {
            this.showHelpmeHeroView(this._currnetIndex);
            this.freshCondition(false);
        }
        this.showHelpHeroScrollViewAction();
    }

    helpHeroUserReq() {
        let data = xsLogic.getHelpMeHeros();
        let ids: { [key: string]: boolean } = {}
        for (let i = 0; i < data.length; i++) {
            let roleId: string = "" + data[i].real_data.roleId
            let user = friendMerLogic.getUserDataByRoleId(roleId);
            if (!user) {
                ids[roleId] = true;
            }
        }
        Object.keys(ids).forEach((v, i, a) => {
            let id: string = v;
            let time: number = 0.3 * i;
            this.scheduleOnce(() => {
                friendMerLogic.userDataReq(id);
            })
        });
    }

    onFilterClick(event: cc.Event.EventTouch, index: string) {
        if (this._currnetIndex == index) return;

        this._currnetIndex = index;
        if (this._heroIndex == 0) {
            return;
        }
        if (this.myHeroNode.active) {
            this.showMyHeroView(index);
        }
        if (this.helpMeHeroNode.active) {
            this.showHelpmeHeroView(index);
        }

        //gm.toast(stringConfigMap[`key_faction_filter_${Number(index) - 1}`].Value);
    }

    onClickDispatch() {
        let myHeros: string[] = [];
        let helpHeros: string[] = [];
        /*
        xsLogic.getAllHelpHeros().forEach((v, i, a) => {
            if (v.select) {
                myHeros.push(v.id);
            }
        });
        xsLogic.getHelpMeHeros().forEach((v, i, a) => {
            if (v.select) {
                helpHeros.push(v.id);
            }
        });*/
        myHeros = this._selectedHeros.map((v, i, a) => { return v.id; })
        this.doDispatch({ heroIds: myHeros, xsId: this._task.id });
        assignmentLogic.dailyTaskProCommit(DailyType.task_xuanshang);
        if (!this._task.isPeronalTask) {
            assignmentLogic.weekTaskProCommit(WeekType.task_xuanshang);
        }
        this._selectedHeros = [];
    }

    // 一键派遣
    onClickAutoDispatch() {
        // 清理当前选中
        for (let i = 0; i < this._selectedHeros.length; i++) {
            xsLogic.getMyHeroById(this._selectedHeros[i].id).select = false;
        }
        this._selectedHeros = [];

        let heros: HeroXs[] = xsLogic.getAllHelpHeros(true);
        let nowTask: Task = this._data;
        if (!nowTask) { return; }
        let num: number = nowTask.taskCfg.CountCondition;
        let rank: number[] = nowTask.taskCfg.RankCondition;
        let nolimitNum: number = num - rank[1];
        let limitNum: number = rank[1];
        let factions: number[] = [];
        factions.pushList(nowTask.realData.factions);
        // 查找 符合满足阵营要求+品阶要求
        for (let i = heros.length; i > 0; i--) {
            let index = i - 1;
            if (limitNum > 0) {
                if (!heros[index].select && !heros[index].isDispatched()) {
                    let fact = heros[index].real_data.getFaction()
                    let flag = factions.indexOf(fact);
                    let hasSame = this._selectedHeros.some((v, i, a) => {
                        return v.real_data.getIndex() == heros[index].real_data.getIndex();
                    });
                    if (flag >= 0 && heros[index].rank >= rank[0] && !hasSame) {
                        heros[index].select = true;
                        limitNum -= 1;
                        factions.splice(flag, 1);
                        this._selectedHeros.push(heros[index]);
                    }
                }
            } else {
                break;
            }
        }
        // 查找 符合只有阵营要求的
        for (let i = heros.length; i > 0; i--) {
            let index = i - 1;
            if (nolimitNum > 0) {
                if (!heros[index].select && !heros[index].isDispatched()) {
                    let fact = heros[index].real_data.getFaction()
                    let flag = factions.indexOf(fact);
                    let hasSame = this._selectedHeros.some((v, i, a) => {
                        return v.real_data.getIndex() == heros[index].real_data.getIndex();
                    });
                    if (flag >= 0 && !hasSame) {
                        heros[index].select = true;
                        nolimitNum -= 1;
                        factions.splice(flag, 1);
                        this._selectedHeros.push(heros[index]);
                    }
                }
            } else {
                break;
            }
        }

        // 判断查找是否成功
        if (this._selectedHeros.length < num) {
            gm.toast(stringConfigMap.key_auto_569.Value);
            for (let i = 0; i < this._selectedHeros.length; i++) {
                xsLogic.getMyHeroById(this._selectedHeros[i].id).select = false;
            }
            return;
        }

        // 设置选中数据及刷新ui
        for (let i = 0; i < this._selectedHeros.length; i++) {
            if (this._heros[i]) {
                this._heros[i].id = this._selectedHeros[i].id;
                this._heros[i].select = true;
            }
        }
        this.freshCondition(false);
        this.freshDispatchHeros(true);
    }

    onClickBtnTip() {
        gm.toast(stringUtils.getString(stringConfigMap.key_desc_71.Value, {}));
    }

    async doDispatch(param: XsReq) {
        let result = await xsLogic.dispatchTaskReq(param);
        this.freshTask();
        this.closePanel();
    }

    freshTask() {
        xsLogic.getPersonalTask().forEach((v, i, a) => {
            if (v.id == this._task.id) {
                v.changeServerData(null);
            }
        });
        EManager.emit(EName.onFreshPanel, "XuanshangPanel");
    }

    private showHelpHeroScrollViewAction() {
        if (this._action) {
            let node = cc.find("root/bottom", this.node);
            if (node) {
                //node.runAction(cc.moveBy(0.25,cc.v2(0,480)));
                node.runAction(cc.moveTo(0.25, cc.v2(0, -667)));
            }
            this._action = false;
        }
        else {
            gm.toast(stringConfigMap.key_click_hero_to_dispatch.Value);
        }
    }
}
