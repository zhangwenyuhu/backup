import { PopupPanel } from "../BasePanel";
import ScrollViewLoader from "../../common/loader/ScrollViewLoader";
import xsLogic from "../../../logics/XuanshangLogic";
import { HelpHeroVO } from "../../../proxy/GameProxy";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/xs/HelpHeroPanel")
export default class HelpHeroPanel extends PopupPanel {

    @property(cc.Node)
    heroView: cc.Node = null;

    @property(cc.Label)
    canHelpNum: cc.Label = null;

    start() {
        super.start();
        this.myHelpHerosReq();
    }

    async myHelpHerosReq() {
        let result = await xsLogic.myHelpHeroReq();
        this.showHeroScrollView(xsLogic.getMyHelpHeroIds());
    }

    showHeroScrollView(data: HelpHeroVO[]) {
        let tmp: HelpHeroVO[] = data.map((v, i, a) => { return v; });
        let maxLen: number = 6;
        //maxLen = maxLen>0?maxLen:6;                         // test
        for (let i = 0; i < maxLen - data.length; i++) {
            tmp.push(null);
        }
        this.heroView.getComponent(ScrollViewLoader).refresh(tmp, false, this.onFresh.bind(this));
        this.canHelpNum.string = `${data.length}/${tmp.length}`;
    }

    onFresh(data: any) {
        this.showHeroScrollView(xsLogic.getMyHelpHeroIds());
    }
}
