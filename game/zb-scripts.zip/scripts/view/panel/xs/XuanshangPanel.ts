import BasePanel from "../BasePanel";
import xsLogic, { XuanshangLogic } from "../../../logics/XuanshangLogic";
import gm from "../../../manager/GameManager";
import Task from "../../../data/xuanshang/task";
import { stringConfigMap } from "../../../configs/stringConfig";
import stringUtils from "../../../utils/StringUtils";
import List from "../../common/List";
import loadUtils from "../../../utils/LoadUtils";
import { GoodVO } from "../../../proxy/GameProxy";
import Good from "../../../data/card/Good";
import CommonLoader from "../../common/CommonLoader";
import GoodCard from "../../component/Good/GoodCard";
import EManager, { EName } from "../../../manager/EventManager";
import GleeTimerLabel from "../../../gleecomponent/GleeTimerLabel";
import cm from "../../../manager/ConfigManager";
import VideoBtn from "../../../gleecomponent/VideoBtn";
import { VideoKey, Storage } from "../../../utils/DefineUtils";
import videoAdLogic, { AD_TYPE } from "../../../logics/VideoAdLogic";
import ad from "../../../manager/AdManager";
import xsConfig from "../../../configs/xsConfig";
import xsLvConfig from "../../../configs/xsLvConfig";
import { defaultConfigMap } from "../../../configs/defaultConfig";
import bagLogic from "../../../logics/BagLogic";
import pushManager from "../../../manager/PushManager";
import { PushType } from "../../../data/push/PushModal";
import playerLogic from "../../../logics/PlayerLogic";
import commonUtils from "../../../utils/CommonUtils";
import commitLogic, { DiamondCost } from "../../../logics/CommitLogic";
import storageUtils from "../../../utils/StorageUtils";

const { ccclass, property, menu } = cc._decorator;

enum TaskType {
    SenLin = 1,
    FeiXu = 2,
    KuangDong = 3,
}

const tabInfo = {
    1: {
        url: "textures/ui/panel/xs/xuanshang_2",
    },
    2: {
        url: "textures/ui/panel/xs/xuanshang_4",
    },
    3: {
        url: "textures/ui/panel/xs/xuanshang_3",
    },
}

@ccclass
@menu("view/panel/xs/XuanshangPanel")
export default class XuanshangPanel extends BasePanel {

    @property(List)
    taskScrollView: List = null;

    @property(cc.Label)
    xsLv: cc.Label = null;

    @property(cc.Node)
    tabs: cc.Node = null;

    @property(cc.Node)
    tabBg: cc.Node = null;

    @property(cc.Node)
    starItem: cc.Node = null;

    @property(cc.Label)
    leftTime: cc.Label = null;

    @property(cc.Node)
    emptyFlag: cc.Node = null;

    @property(cc.Node)
    vipTip: cc.Node = null;

    @property(cc.Node)
    oneKeyDispatch: cc.Node = null;

    @property(cc.Node)
    oneKeyRecv: cc.Node = null;

    @property(cc.Node)
    btnFresh: cc.Node = null;

    private _currentTaskType: TaskType = TaskType.SenLin;
    private _taskTimestamp: number = 0;
    private _tasks: Task[] = [];

    onInit(data: any) {
        if (data && data.lvUp) {
            gcc.core.showLayer("prefabs/panel/xs/XsUpPanel");
        }
        pushManager.updateLocalPushs([PushType.TASK_UNRECV]);
    }

    onLoad() {
        super.onLoad();

        this.starItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.unschedule(this.freshPerSecond);
        this.starItem.destroy();
    }

    async start() {
        super.start();

        this.xsLv.string = `${xsLogic.getXslevel()}`;
        let nowTimestamp = gm.getCurrentTimestamp();
        this._taskTimestamp = Math.floor((xsLogic.getXsfreshTimestamp() - nowTimestamp) / 1000);
        this.leftTime.string = stringUtils.formatTime(this._taskTimestamp);
        this._currentTaskType = TaskType.SenLin;
        this.schedule(this.freshPerSecond, 1);
        this.freshTab(this._currentTaskType);

        let listener = EManager.addEvent(EName.onFreshPanel, (data) => {
            if (data === "XuanshangPanel") {
                this.freshXuanshangView();
            }
        })
        this._eventListeners.push(listener);
        await xsLogic.dispatchHerosReq();
        this.showTaskView(this._currentTaskType);
    }

    async freshXuanshangView() {
        if (this.checkCanLevelUp()) {
            console.info("悬赏任务 可以升级!");
            await xsLogic.xsTaskReq();
            this.xsLv.string = `${xsLogic.getXslevel()}`;
            gcc.core.showLayer("prefabs/panel/xs/XsUpPanel");
        }
        this.showTaskView(this._currentTaskType);
    }

    onTab(sender: cc.Event.EventTouch) {
        if (sender && sender.currentTarget && sender.currentTarget.getComponent(cc.Button)) {
            let btn: cc.Button = sender.currentTarget.getComponent(cc.Button);
            let type = parseInt(btn.clickEvents[0].customEventData);
            if (this._currentTaskType == type) { return; }

            this._currentTaskType = type;
            this.freshTab(type)
            this.showTaskView(type);
        }
    }

    freshTab(type: TaskType) {
        let senlin = this.tabs.getChildByName("Senlin");
        let feixu = this.tabs.getChildByName("Feixu");
        let kuangdong = this.tabs.getChildByName("Kuangdong");
        senlin.getChildByName("select").active = false;
        senlin.getChildByName("default").active = true;
        feixu.getChildByName("select").active = false;
        feixu.getChildByName("default").active = true;
        kuangdong.getChildByName("select").active = false;
        kuangdong.getChildByName("default").active = true;
        if (type == TaskType.SenLin) {
            senlin.getChildByName("select").active = true;
            senlin.getChildByName("default").active = false;
            storageUtils.setBoolean(Storage.XsSenlinRead.Key, true);
        } else if (type == TaskType.FeiXu) {
            feixu.getChildByName("select").active = true;
            feixu.getChildByName("default").active = false;
            storageUtils.setBoolean(Storage.XsFeixuRead.Key, true);
        } else if (type == TaskType.KuangDong) {
            kuangdong.getChildByName("select").active = true;
            kuangdong.getChildByName("default").active = false;
            storageUtils.setBoolean(Storage.XsKuangdongRead.Key, true);
        }

        loadUtils.loadSpriteFrame(tabInfo[type].url, this.tabBg.getComponent(cc.Sprite));
    }

    freshRed() {
        let senlin = this.tabs.getChildByName("Senlin");
        let feixu = this.tabs.getChildByName("Feixu");
        let kuangdong = this.tabs.getChildByName("Kuangdong");
        senlin.getChildByName("red").active = xsLogic.xuanshangRed(TaskType.SenLin);
        feixu.getChildByName("red").active = xsLogic.xuanshangRed(TaskType.FeiXu);
        kuangdong.getChildByName("red").active = xsLogic.xuanshangRed(TaskType.KuangDong);
    }

    freshPerSecond() {
        this._taskTimestamp -= 1;
        this.leftTime.string = stringUtils.formatTime(this._taskTimestamp);

        if (this._taskTimestamp <= 0) {
            this.reSetTask();
        }
    }

    onClickLv() {
        let maxLevel = xsLvConfig.length;
        if (xsLogic.getXslevel() < maxLevel) {
            gcc.core.showLayer("prefabs/panel/xs/XsLevelUpPanel");
        } else {
            gcc.core.showLayer("prefabs/panel/xs/XsMaxLevelPanel");
        }
    }

    onClickFreshTask() {
        if (!this.freshTip()) { return; }
        // 个人任务刷新
        let bVideo = videoAdLogic.canVideoAd(AD_TYPE.TaskFresh);
        console.info("视频可以视频刷新: " + bVideo);
        let cost: number = defaultConfigMap.taskresetcost.value;
        gcc.core.showLayer("prefabs/panel/help/DiamondConfirmDialog", {
            data: {
                cost: cost,
                video: bVideo,
                desc: stringConfigMap.key_common_tip12.Value,
                btnOkText: stringConfigMap.key_common_tip13.Value,
                success: (bVideo) => {
                    //
                    this.freshTasks(bVideo);
                    if (!bVideo) {
                        bagLogic.changeGoodAmount(Good.GoodId.Diamond, -cost);
                        commitLogic.costDiamond(cost, DiamondCost.xuanshangRefresh);
                    }
                }
            }
        });
    }

    onClickHelp() {
        gcc.core.showLayer("prefabs/panel/help/GameHelp", { data: { type: "xuanshang" } });
    }

    async onClickSend(sender: cc.Event.EventTouch, index: string) {
        try {
            let data = this._tasks[index];
            if (data) {
                await xsLogic.dispatchHerosReq();
                gcc.core.showLayer("prefabs/panel/xs/XsDispatchPanel", { data: data });
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    async onClickRecv(sender: cc.Event.EventTouch, index: string) {
        try {
            let data = this._tasks[index];
            if (data) {
                await this.doGetReward(data.id);
                EManager.emit(EName.onFreshPanel, "XuanshangPanel");
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    private showTaskView(type: TaskType) {
        let tasks = xsLogic.getTasks();
        this._tasks = tasks.filter((v, i, a) => { return v.taskCfg.type == type; })
        this.taskScrollView.numItems = this._tasks.length > 3 ? 3 : this._tasks.length;

        this.emptyFlag.active = this._tasks.length == 0;

        let nowVip = playerLogic.getPlayer().getVipLevel();
        let unlockVip = xsLogic.getOneKeyVipLevel();
        this.vipTip.active = nowVip < unlockVip;

        let canDispatch = tasks.some((v, i, a) => { return !v.isOpen; });
        let canRecv = tasks.some((v, i, a) => { return v.isOver && v.isOpen; });
        this.oneKeyDispatch.active = canDispatch;
        this.oneKeyRecv.active = canRecv;
        if (!this.oneKeyDispatch.active && !this.oneKeyRecv.active) {
            this.vipTip.active = false;
        }
        this.freshRed();

        // 刷新按钮
        this.btnFresh.active = this.hasTaskCanFresh();
    }

    private hasTaskCanFresh(): boolean {
        let tasks = xsLogic.getTasks();
        if (tasks.length <= 0) { return false; }

        let index = tasks.findIndex((a) => { return a.isOpen == false; })
        return index >= 0;
    }

    onItemRender(item: cc.Node, index: number) {
        let data = this._tasks[index];
        if (data) {
            // 奖励
            let good: GoodVO = {
                amt: data.taskRewardNum,
                propId: data.taskReward.parameterid,
                objId: "" + data.taskReward.type
            };
            let rewardGood: Good = new Good(good);
            let nodeReward = item.getChildByName("good_card").getComponent(CommonLoader).loaderNode;
            nodeReward.getComponent(GoodCard).refresh(rewardGood);
            nodeReward.getComponent(GoodCard).registerOnGoodInfo();

            item.getChildByName("name").getComponent(cc.Label).string = data.name;
            item.getChildByName("desc").getComponent(cc.Label).string = data.desc;
            item.getChildByName("line").active = (index + 1) != this._tasks.length;

            let stars = item.getChildByName("stars");
            stars.destroyAllChildren();
            for (let i = 0; i < data.star; i++) {
                let tmp = cc.instantiate(this.starItem);
                tmp.parent = stars;
            }

            let btnSend = item.getChildByName("btnSend");
            let btnRecv = item.getChildByName("btnRecv");
            let desc = item.getChildByName("desc");
            let progress = item.getChildByName("progress");
            let restTime = item.getChildByName("rest_time");
            let completeTip = item.getChildByName("complete");
            btnSend.getComponent(cc.Button).clickEvents[0].customEventData = "" + index;
            btnRecv.getComponent(cc.Button).clickEvents[0].customEventData = "" + index;
            btnSend.active = false;
            btnRecv.active = false;
            desc.active = false;
            progress.active = false;
            restTime.active = false;
            completeTip.active = false;

            if (data.isOpen) {
                if (data.isOver) {
                    completeTip.active = true;
                    btnRecv.active = true;
                } else {
                    progress.active = true;
                    restTime.active = true;
                }
            } else {
                desc.active = true;
                btnSend.active = true;
            }
            if (progress.active) {
                let pro: number = data.leftTimeStamp / (data.taskCfg.time * 3600)
                pro = pro > 1 ? 1 : pro;
                progress.getComponent(cc.ProgressBar).progress = 1 - pro;
                let timeStr: string = stringUtils.formatTimeWithHour(data.leftTimeStamp);

                //restTime.getComponent(cc.Label).string = timeStr;
                restTime.getComponent(GleeTimerLabel).lefttime = data.leftTimeStamp;
                restTime.off("timerlabel:on-timeout");
                restTime.on("timerlabel:on-timeout", (data) => { EManager.emit(EName.onFreshPanel, "XuanshangPanel"); })
            }

            let btnVideo = item.getChildByName("btnVideo");
            btnVideo.active = false;
            if (!btnRecv.active && !btnSend.active) {
                //console.error("视频完成任务剩余次数: "+videoAdLogic.adNowTimes(AD_TYPE.TaskComplete));
                if (videoAdLogic.canVideoAd(AD_TYPE.TaskComplete)) {
                    btnVideo.active = true;
                    let videoNode = btnVideo.getComponent(CommonLoader).loaderNode;

                    videoNode.getComponent(VideoBtn).setImageFrame(false);
                    videoNode.getComponent(VideoBtn).videoText = "快速完成";
                    videoNode.getComponent(VideoBtn).eventName = VideoKey.XsComplete;
                    videoNode.getComponent(VideoBtn).onSuccessFunc = () => {
                        videoAdLogic.videoPlayTimesCount(AD_TYPE.TaskComplete);
                        this.videoCompleteTask(data.id);
                    }
                }
            }
        }
    }

    async videoCompleteTask(id: string) {
        try {
            let bLevelUp = await xsLogic.xsQuickComplete(id);
            this.showTaskView(this._currentTaskType);
            if (bLevelUp) {
                gcc.core.showLayer("prefabs/panel/xs/XsUpPanel");
            }
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    async freshTasks(bVideo: boolean) {
        try {
            //if(!this.freshTip()){return;}
            await xsLogic.xsTaskRefreshReq(bVideo);
            if (bVideo) {
                videoAdLogic.videoPlayTimesCount(AD_TYPE.TaskFresh);
            }
            this.showTaskView(this._currentTaskType);
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    freshTip(): boolean {
        let fresh: boolean = true;
        let tasks = xsLogic.getTasks();
        if (tasks.length == 0) { fresh = false; }
        fresh = tasks.some((v, i, a) => { return v.realData.state == 0; });
        if (!fresh) { gm.toast(stringConfigMap.key_xuanshang_tip3.Value); }
        return fresh;
    }

    async doGetReward(id: string) {
        await xsLogic.getTaskRewardReq(id);
        this.showTaskView(this._currentTaskType);
    }

    async reSetTask() {
        await xsLogic.xsTaskReq();

        let nowTimestamp = gm.getCurrentTimestamp();
        this._taskTimestamp = Math.floor((xsLogic.getXsfreshTimestamp() - nowTimestamp) / 1000);
        this.showTaskView(this._currentTaskType);
    }

    async onClickOneKeyDispatch() {
        let nowVip = playerLogic.getPlayer().getVipLevel();
        let unlockVip = xsLogic.getOneKeyVipLevel();
        if (nowVip < unlockVip) {
            //this.oneKeyUnlockTip();
            gm.toast(stringUtils.getString(stringConfigMap.key_auto_639.Value, {p1: unlockVip}));
        } else {
            let tasks = xsLogic.getTasks();
            let canDispatch = tasks.some((v, i, a) => { return !v.isOpen && v.canDispatch(); });
            if (!canDispatch) { gm.toast(stringConfigMap.key_auto_570.Value); return; }
            await xsLogic.dispatchHerosReq();
            gcc.core.showLayer("prefabs/panel/xs/AutoDispatchPanel");
        }
    }

    onClickOneKeyRecv() {
        let nowVip = playerLogic.getPlayer().getVipLevel();
        let unlockVip = xsLogic.getOneKeyVipLevel();
        if (nowVip < unlockVip) {
            //this.oneKeyUnlockTip();
            gm.toast(stringUtils.getString(stringConfigMap.key_auto_640.Value, {p1: unlockVip}));
        } else {
            this.doAutoRecv();
        }
    }

    async doAutoRecv() {
        let task = xsLogic.getTasks().filter((v, i, a) => { return v.isOpen && v.isOver; });
        let param = task.map((v, i, a) => { return v.id; });
        try {
            await xsLogic.autoGetTaskRewardReq(param);
            this.freshXuanshangView();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }

    protected oneKeyUnlockTip() {
        let nowVip = playerLogic.getPlayer().getVipLevel();
        let unlockVip = xsLogic.getOneKeyVipLevel();
        gm.dialog({
            content: `VIP等级不足,还差${unlockVip - nowVip}级可解锁\n是否前往提升VIP?`,
            confirm: () => {
                gm.gotoBuy();
                this.closePanel();
            }
        })
    }

    checkCanLevelUp() {
        // 取消升级本地判断
        return false;
        let nowLevel = xsLogic.getXslevel();
        let num: number = cm.getXsLvConfig(nowLevel).Condition[1];
        let nowTimes: number = xsLogic.getXsCondition()[0];
        console.info(`悬赏任务 now: ${nowTimes} next: ${num}`);
        return num <= nowTimes;
    }
}