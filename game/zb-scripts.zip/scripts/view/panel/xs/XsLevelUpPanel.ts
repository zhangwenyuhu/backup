import { PopupPanel } from "../BasePanel";
import { xsLvConfigRow } from "../../../configs/xsLvConfig";
import cm from "../../../manager/ConfigManager";
import xsLogic from "../../../logics/XuanshangLogic";
import { stringConfigMap } from "../../../configs/stringConfig";
import stringUtils from "../../../utils/StringUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/xs/XsLevelUpPanel")
export default class XsLevelUpPanel extends PopupPanel {

    @property(cc.Node)
    xs_lv: cc.Node = null;

    @property(cc.Node)
    xs_now: cc.Node = null;

    @property(cc.Node)
    xs_next: cc.Node = null;

    @property(cc.Node)
    xs_star: cc.Node = null;

    @property(cc.Node)
    personal_condition: cc.Node = null;

    @property(cc.Node)
    team_condition: cc.Node = null;

    private _level: number = 0;
    private _now_lvcfg: xsLvConfigRow = null;
    private _next_lvcfg: xsLvConfigRow = null;
    onInit(data: any) {
        super.onInit(data);

        this._level = xsLogic.getXslevel() || 1;
        this._now_lvcfg = cm.getXsLvConfig(this._level);
        this._next_lvcfg = cm.getXsLvConfig(this._level + 1);
    }

    onLoad() {
        super.onLoad();

        this.xs_star.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.xs_star.destroy();
    }

    start() {
        super.start();
        this.freshPanel();
    }

    freshPanel() {
        this.xs_lv.getComponent(cc.Label).string = `Lv.${this._level}`;

        // now
        this.xs_now.active = this._now_lvcfg ? true : false;
        if (this._now_lvcfg) {
            this.xs_now.getChildByName("lv").getComponent(cc.Label).string = `Lv.${this._level}`;

            let stars: cc.Node = this.xs_now.getChildByName("stars");
            stars.destroyAllChildren();
            this._now_lvcfg.Rank.forEach((v, i, a) => {
                let tmp: cc.Node = cc.instantiate(this.xs_star);
                tmp.getChildByName("num").getComponent(cc.Label).string = `${v}`;
                tmp.parent = stars;
            });
        }
        // next
        this.xs_next.active = this._next_lvcfg ? true : false;
        if (this._next_lvcfg) {
            this.xs_next.getChildByName("lv").getComponent(cc.Label).string = `Lv.${this._next_lvcfg.Id}`;

            let stars: cc.Node = this.xs_next.getChildByName("stars");
            stars.destroyAllChildren();
            this._next_lvcfg.Rank.forEach((v, i, a) => {
                let tmp: cc.Node = cc.instantiate(this.xs_star);
                tmp.getChildByName("num").getComponent(cc.Label).string = `${v}`;
                tmp.parent = stars;
            });

            // personal condition
            let star: number = this._now_lvcfg.Condition[0];
            let num: number = this._now_lvcfg.Condition[1];
            let str: string = `${star}`;
            let nowTimes: number = xsLogic.getXsCondition()[0];
            cc.find("layout/star/num", this.personal_condition).getComponent(cc.Label).string = str;
            str = stringUtils.getString("" + stringConfigMap.key_xuanshang_tip1.Value, { count: num });
            cc.find("layout/msg", this.personal_condition).getComponent(cc.Label).string = str;
            str = `(${nowTimes}/${num})`;

            let numNode = cc.find("num", this.personal_condition)
            numNode.getComponent(cc.Label).string = str;
            this.modifyColor(numNode, nowTimes >= num);
            cc.find("progress", this.personal_condition).getComponent(cc.ProgressBar).progress = nowTimes / num;
        }

        // team condition
        /*
        star = this._now_lvcfg.Condition2[0];
        num = this._now_lvcfg.Condition2[1];
        str = `${star}`;
        nowTimes = xsLogic.getXsCondition()[1];
        cc.find("layout/star/num", this.team_condition).getComponent(cc.Label).string = str;
        str = stringUtils.getString("" + stringConfigMap.key_xuanshang_tip2.Value, { count: num });
        cc.find("layout/msg", this.team_condition).getComponent(cc.Label).string = str;
        str = `(${nowTimes}/${num})`;
        numNode = cc.find("num", this.team_condition)
        numNode.getComponent(cc.Label).string = str;
        this.modifyColor(numNode, nowTimes >= num);
        cc.find("progress", this.team_condition).getComponent(cc.ProgressBar).progress = nowTimes / num;
        */
    }

    modifyColor(node: cc.Node, bComplete: boolean) {
        let color = bComplete ? cc.color(100, 203, 141) : cc.color(203, 100, 100);
        if (node && node.getComponent(cc.Label)) {
            node.color = color;
        }
    }
}
