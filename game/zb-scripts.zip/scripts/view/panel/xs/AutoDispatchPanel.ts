import { PopupPanel } from "../BasePanel";
import List from "../../common/List";
import xsLogic from "../../../logics/XuanshangLogic";
import Task from "../../../data/xuanshang/task";
import HeroXs from "../../../data/xuanshang/HeroXs";
import gm from "../../../manager/GameManager";
import loadUtils from "../../../utils/LoadUtils";
import commonUtils from "../../../utils/CommonUtils";
import heroUtils from "../../../utils/HeroUtils";
import Hero from "../../../data/card/Hero";
import { XsReq } from "../../../proxy/GameProxy";
import EManager, { EName } from "../../../manager/EventManager";
import assignmentLogic from "../../../logics/AssignmentLogic";
import { DailyType, WeekType } from "../../../utils/DefineUtils";

const { ccclass, property, menu } = cc._decorator;

@ccclass
@menu("view/panel/xs/AutoDispatchPanel")
export default class AutoDispatchPanel extends PopupPanel {

    @property(cc.Node)
    goodItem: cc.Node = null;

    @property(cc.Node)
    heroItem: cc.Node = null;

    @property(cc.Node)
    equipItem: cc.Node = null;

    @property(List)
    dispatchList: List = null;

    protected _dispatchInfo: { [key: string]: string[] } = {};
    protected _selectInfo: { id: string, select: boolean }[] = [];

    onLoad() {
        super.onLoad();

        this.goodItem.parent = null;
        this.equipItem.parent = null;
        this.heroItem.parent = null;
    }

    onDestroy() {
        super.onDestroy();

        this.goodItem.destroy();
        this.equipItem.destroy();
        this.heroItem.destroy();
    }

    start() {
        super.start();

        this.makeAutoDispatchInfo();
        this.dispatchList.getComponent(cc.Widget).updateAlignment();
        this.dispatchList.numItems = this._selectInfo.length;
    }

    // 生成一键派遣信息
    makeAutoDispatchInfo() {
        this._dispatchInfo = {};
        this._selectInfo = [];

        let tasks: Task[] = xsLogic.getTasks().filter((v, i, a) => { return !v.isOpen; });
        tasks.sort((a, b) => { return a.taskCfg.type - b.taskCfg.type; });
        let heros: HeroXs[] = xsLogic.getAllHelpHeros(true);
        heros = heros.filter((v, i, a) => { return !v.isDispatched(); })
        let selected: string[] = [];
        for (let i = 0; i < tasks.length; i++) {
            let data = tasks[i];
            let result = this.getDispatchHeros(data, heros, selected);
            if (result && result.length == data.taskCfg.CountCondition) {
                this._dispatchInfo[data.id] = result;
                this._selectInfo.push({ id: data.id, select: true });
                selected = selected.concat(result);
            }
        }
    }

    // 获取满足悬赏任务的最低要求的英雄
    protected getDispatchHeros(data: Task, heros: HeroXs[], selected: string[]): string[] {
        console.warn(`派遣任务 id:${data.id}`);
        console.warn(`已选英雄 id:${selected.join(`-`)}`);
        let heroIds: string[] = [];
        let res: HeroXs[] = [];
        for (let i = 0; i < heros.length; i++) {
            let id = heros[i].id;
            let selecting = false;
            for (let j = 0; j < selected.length; j++) {
                if (selected[j] == id) {
                    selecting = true;
                }
            }
            if (!selecting) {
                res.push(heros[i]);
            }
        }
        if (res.length < data.taskCfg.CountCondition) { return heroIds; }

        let dispatchHeros: HeroXs[] = []
        let num: number = data.taskCfg.CountCondition;
        let rank: number[] = data.taskCfg.RankCondition;
        let nolimitNum: number = num - rank[1];
        let limitNum: number = rank[1];
        let factions: number[] = [];
        factions.pushList(data.realData.factions)
        // 查找 符合满足阵营要求+品阶要求
        for (let i = res.length; i > 0; i--) {
            let index = i - 1;
            if (limitNum > 0) {
                if (!xsLogic.isDispatched(res[index].id)) {
                    let fact = res[index].real_data.getFaction()
                    let flag = factions.indexOf(fact);
                    let hasSame = dispatchHeros.some((v, i, a) => {
                        return v.real_data.getIndex() == res[index].real_data.getIndex();
                    });
                    let hasSelect: boolean = dispatchHeros.some((v, i, a) => { return v.id == res[index].id; });
                    if (flag >= 0 && res[index].real_data.getRank() >= rank[0] && !hasSame && !hasSelect) {
                        limitNum -= 1;
                        factions.splice(flag, 1);
                        dispatchHeros.push(res[index]);
                    }
                }
            } else {
                break;
            }
        }
        // 查找 符合只有阵营要求的
        for (let i = res.length; i > 0; i--) {
            let index = i - 1;
            if (nolimitNum > 0) {
                if (!xsLogic.isDispatched(res[index].id)) {
                    let fact = res[index].real_data.getFaction()
                    let flag = factions.indexOf(fact);
                    let hasSame = dispatchHeros.some((v, i, a) => {
                        return v.real_data.getIndex() == res[index].real_data.getIndex();
                    });
                    if (flag >= 0 && !hasSame) {
                        nolimitNum -= 1;
                        factions.splice(flag, 1);
                        dispatchHeros.push(res[index]);
                    }
                }
            } else {
                break;
            }
        }

        heroIds = dispatchHeros.map((v, i, a) => { return v.id; })
        return heroIds;
    }

    onItemRender(item: cc.Node, index: number) {
        let data = this._selectInfo[index];
        let task = xsLogic.getTaskById(data.id);
        let heroIds = this._dispatchInfo[data.id];
        if (!data || !task) {
            item.active = false;
            console.error("派遣数据未找到");
            return;
        }

        // 奖励
        let dispatchReward = item.getChildByName("reward");
        dispatchReward.destroyAllChildren();
        gm.showGoodItem(task.taskCfg.item, {
            goodItem: this.goodItem,
            equipItem: this.equipItem,
            heroItem: this.heroItem
        }, dispatchReward, 0.7);

        // 任务名称和星级
        let name = item.getChildByName("info").getChildByName("label");
        name.getComponent(cc.Label).string = task.taskCfg.sence + "-" + task.name;
        let stars = item.getChildByName("info").getChildByName("stars");
        for (let i = 0; i < stars.childrenCount; i++) {
            let star = stars.children[i];
            let reach = i + 1 <= task.taskCfg.Rank;
            let iconName = reach ? "xuanshang_24" : "xuanshang_21";
            loadUtils.loadSpriteFrame(commonUtils.getPanelIconUrl("xs", iconName), star.getComponent(cc.Sprite));
        }

        // 派遣条件
        let icon = item.getChildByName("condition1").getChildByName("1").getChildByName("icon");
        let num = item.getChildByName("condition1").getChildByName("1").getChildByName("num");
        let str: string = `${task.taskCfg.RankCondition[1]}/${task.taskCfg.RankCondition[1]}`;
        num.getComponent(cc.Label).string = str;
        let qualityInfo = heroUtils.getHeroQualityInfo(task.taskCfg.RankCondition[0]);
        str = commonUtils.getHeroQualityUrl(qualityInfo.qualityLevel);
        loadUtils.loadSpriteFrame(str, icon.getComponent(cc.Sprite));

        let condition2 = item.getChildByName("condition2");
        for (let j = 0; j < condition2.childrenCount; j++) {
            let faction = condition2.children[j];
            let valid: boolean = j + 1 <= heroIds.length;
            faction.active = valid;
            if (faction.active) {
                let hero = xsLogic.getMyHeroById(heroIds[j]);
                let url = commonUtils.getHeroFactionUrl(hero.real_data.getFaction());
                loadUtils.loadSpriteFrame(url, faction.getComponent(cc.Sprite));
            }
        }

        // 派遣英雄列表
        let heroNode = item.getChildByName("heros");
        heroNode.destroyAllChildren();
        let cards: Hero[] = [];
        for (let i = 0; i < heroIds.length; i++) {
            let hero = xsLogic.getMyHeroById(heroIds[i]);
            cards.push(hero.real_data);
        }
        gm.createRewards(cards, {
            goodItem: this.goodItem,
            equipItem: this.equipItem,
            heroItem: this.heroItem
        }, heroNode, 2, false, 0.6);

        // 选择
        let selectNode = item.getChildByName("btnSelect");
        selectNode.getChildByName("green").active = data.select;
        selectNode.off(cc.Node.EventType.TOUCH_END);
        selectNode.on(cc.Node.EventType.TOUCH_END, (e: cc.Touch) => {
            let info = this._selectInfo.findIndex((a) => { return a.id == data.id; });
            if (info >= 0) {
                this._selectInfo[info].select = !this._selectInfo[info].select;
                selectNode.getChildByName("green").active = this._selectInfo[info].select;
            }
        })
    }

    async onClickDispatch() {
        let param: XsReq[] = [];
        for (let i = 0; i < this._selectInfo.length; i++) {
            if (this._selectInfo[i].select) {
                let tmp = new XsReq;
                tmp.heroIds = this._dispatchInfo[this._selectInfo[i].id];
                tmp.xsId = this._selectInfo[i].id;
                param.push(tmp);
            }
        }
        try {
            await xsLogic.autoDispatchTaskReq(param);
            EManager.emit(EName.onFreshPanel, "XuanshangPanel");

            assignmentLogic.dailyTaskProCommit(DailyType.task_xuanshang, param.length);
            assignmentLogic.weekTaskProCommit(WeekType.task_xuanshang, param.length);
            this.closePanel();
        } catch (e) {
            if (e.name == "ToastError") {
                gm.toast(e.message);
            }
            else {
                throw e;
            }
        }
    }
}
