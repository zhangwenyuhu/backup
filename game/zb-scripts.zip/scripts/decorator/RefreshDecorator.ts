import { EName } from './../manager/EventManager';
import EManager from "../manager/EventManager";

function registerTarget(obj: {
    target: any,
    data: any,
    cls: any,
    eventNames: string[],
    update: Function
}) {
    let target = obj.target;
    let update = obj.update;
    let start = target.start;
    let onDestroy = target.onDestroy;
    let refresh = target.refreshWithProperty;

    target.refreshWithProperty = function (...params: any[]) {
        if (refresh) refresh.apply(this, params);
        update.call(this);
    };
    target.start = function () {
        if (start) start.call(this);
        update.call(this);

        if (!this._propertyListeners) {
            this._propertyListeners = [];
        }

        if (obj.eventNames instanceof Array) {
            let listeners = EManager.addEventArray(obj.eventNames, (data: any) => {
                if (obj.cls(this) === data.target) {
                    update.call(this);
                }
            });
            this._propertyListeners.pushList(listeners);
        }

        let listener = EManager.addEvent(EName.onDataDirty, (data: any) => {
            if (obj.cls(this) === data) {
                update.call(this);
            }
        });
        this._propertyListeners.push(listener);
    };
    target.onDestroy = function () {
        if (onDestroy) onDestroy.call(this);

        if (this._propertyListeners instanceof Array) {
            for (let listener of this._propertyListeners) {
                EManager.removeEvent(listener)
            }
            this._propertyListeners = [];
        }
    };
}

/**
 * 刷新节点
 * @param params 
 */
export function RefreshNode(params: {
    eventName?: string,
    eventNames?: string[],
    getTarget?: (caller: any) => any,
    getData: (caller: any) => any,
    refresh: (node: cc.Node, data: any) => void
}) {
    return function (target: any, key: string) {
        let update = function () {
            let node = this[key];
            let data = params.getData(this);
            if (node && data) {
                params.refresh(node, data);
            }
        };
        registerTarget({
            target: target,
            data: params.getData,
            cls: params.getTarget ? params.getTarget : params.getData,
            eventNames: params.eventName ? [params.eventName] : params.eventNames,
            update: update
        });
    };
}

/**
 * 刷新Label组件
 * @param params 
 */
export function RefreshLabel(params: {
    eventName?: string,
    eventNames?: string[],
    getTarget?: (caller: any) => any,
    getData: (caller: any) => any,
    getValue?: (caller: any) => any,
    getString?: (value: number | string) => string,
    refresh?: (label: cc.Label, data: any) => void
}) {
    return function (target: any, key: string) {
        let update = function () {
            let label = this[key];
            let data = params.getData(this);
            if (label && data) {
                if (params.getValue) {
                    if (params.getString) {
                        label.string = params.getString(params.getValue(data));
                    }
                    else {
                        label.string = `${params.getValue(data)}`;
                    }
                }
                if (params.refresh) {
                    params.refresh(label, data);
                }
            }
        };
        registerTarget({
            target: target,
            data: params.getData,
            cls: params.getTarget ? params.getTarget : params.getData,
            eventNames: params.eventName ? [params.eventName] : params.eventNames,
            update: update
        });
    };
}

/**
 * 刷新Sprite组件
 * @param params 
 */
export function RefreshSprite(params: {
    eventName?: string,
    eventNames?: string[],
    getTarget?: (caller: any) => any,
    getData: (caller: any) => any,
    getValue?: (caller: any) => any,
    updateSpriteFrame?: (sprite: cc.Sprite, value: number | string) => void,
    refresh?: (sprite: cc.Sprite, data: any) => void
}) {
    return function (target: any, key: string) {
        let update = function () {
            let sprite = this[key]
            let data = params.getData(this);
            if (sprite && data && params.getValue) {
                params.updateSpriteFrame(sprite, params.getValue(data));
            }
            if (params.refresh) {
                params.refresh(sprite, data);
            }
        }
        registerTarget({
            target: target,
            data: params.getData,
            cls: params.getTarget ? params.getTarget : params.getData,
            eventNames: params.eventName ? [params.eventName] : params.eventNames,
            update: update
        });
    }
}

/**
 * 刷新ProgressBar组件
 * @param params 
 */
export function RefreshProgressBar(params: {
    eventName?: string,
    eventNames?: string[],
    getTarget?: (caller: any) => any,
    getData: (caller: any) => any,
    getValue: (caller: any) => any,
    getTotal: (caller: any) => any,
    refresh?: (progressBar: cc.ProgressBar, data: any) => void
}) {
    return function (target: any, key: string) {
        let update = function () {
            let progressBar = this[key]
            let data = params.getData(this);
            if (progressBar && data) {
                progressBar.progress = params.getValue(data) / params.getTotal(data);
                if (params.refresh) {
                    params.refresh(progressBar, data);
                }
            }
        }
        registerTarget({
            target: target,
            data: params.getData,
            cls: params.getTarget ? params.getTarget : params.getData,
            eventNames: params.eventName ? [params.eventName] : params.eventNames,
            update: update
        });
    }
}