import EManager from "../manager/EventManager";

let decode = window['decode'];
let encode = window['encode'];

/**
 * 监视成员变量（装饰器）
 * @param eventName 事件名
 */
export function WatchProperty(eventName: string) {
    return function (target: any, propertyName: string) {
        target.__defineGetter__(propertyName, function () {
            return decode(this["_" + propertyName]);
        })
        target.__defineSetter__(propertyName, function (value) {
            let oldValue = this[propertyName];
            if (oldValue === value) {
                return;
            }
            this["_" + propertyName] = encode(value);
            if (oldValue !== undefined) {
                EManager.emit(eventName, { target: this, oldValue: oldValue, newValue: value });
            }
        });
    }
}

/**
 * 监视成员变量（装饰器）
 * @param eventNames 事件名
 */
export function WatchProperties(eventNames: string[]) {
    return function (target: any, propertyName: string) {
        target.__defineGetter__(propertyName, function () {
            return decode(this["_" + propertyName]);
        })
        target.__defineSetter__(propertyName, function (value) {
            let oldValue = this[propertyName];
            if (oldValue === value) {
                return;
            }
            this["_" + propertyName] = encode(value);
            if (oldValue !== undefined) {
                for (let eventName of eventNames) {
                    EManager.emit(eventName, { target: this, oldValue: oldValue, newValue: value });
                }
            }
        });
    }
}