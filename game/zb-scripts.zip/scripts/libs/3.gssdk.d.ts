declare namespace GSSDK {
    enum ShareType {
        /**
         * 普通分享 以分享类型进行关联分组
         */
        NORMAL = 0,
        /**
         * 以一天的某个时间点进行分组
         */
        DAY = 1,
        /**
         * 从分享时，开始计时，一定时间内都用同一个分享组，该时间可以进行修改，以延长时间
         */
        TIME = 2,
        /**
         * 签名动态生成
         */
        ONCE = 3,
        /**
         * 服务器0点时间作为sign值,防止玩家刷
         */
        SERVER_TIME_0 = 4
    }
    class ShareLog {
        /**
         * 分享key
         */
        key: string;
        /**
         * 分享类型
         */
        type: ShareType;
        hour?: number;
        duration?: number;
        /**
         * 最终使用的分享文件信息id
         */
        shareId: string;
        /**
         * 最终的key
         */
        sign: string;
        /**
         * 分享的附加数据
         */
        data: {
            [key: string]: string;
        };
        /**
         * 分享的时间
         */
        time: number;
        /**
         * 是否为单条日志
         */
        singleLog: boolean;
        /**
         * 分享的相关数据
         */
        info?: {
            openGId: string;
        };
        isTimeOut(): boolean;
    }
    class ShareData {
        shareList: ShareLog[];
        groupMap: {};
        lastShareTime: number;
        /**
         * 获取存档中保存的实例
         */
        static get saved(): ShareData;
        /**
         * 获取分享的数据
         * @param key 分享的key
         * @param type 分享的类型
         */
        getShareLog(key: string, type: ShareType): ShareLog;
        /**
         * 获取分享列表
         * @param key 分享的key
         * @param type 分享的类型
         * @param filter 筛选函数
         */
        getShareLogList(key: string, type: ShareType, filter: (log: ShareLog) => boolean): ShareLog[];
        /**
         * 移除分享项
         * @param key 分享的key
         * @param type 分享的类型
         * @param filter 筛选函数
         */
        removeLog(key: string, type: ShareType, filter: (log: ShareLog) => boolean): void;
        /**
         * 判断今天是否可以分享
         */
        isLastTimeYeasterDay(): boolean;
        /**
         * 记录分享时间，在分享成功后会自动调用
         */
        recordTime(): void;
    }
}
declare namespace GSSDK {
    class Info {
        /**
         * 游戏的启动模式。
         * 可以是 开发、测试、发布
         *
         */
        mode: "develop" | "test" | "release";
        /**
         * APPID 一般为微信ID
         */
        appId: string;
        /**
         * 游戏当前的版本号，需要手动编辑
         */
        version: string;
        /**
         * 游戏的资源版本号，每次发布的时候会自动+1
         */
        resVersion: number;
        /**
         * 游戏的服务器地址例如 https://xzxxxx.com
         */
        gameUrl: string;
        /**
         * 账号服 https
         */
        accountServer: string;
        /**
         * 低速账号服地址 https ，用于减少服务器cdn加速的开支，不重要的请求使用低速地址。
         */
        accountServerLowSpeed: string;
        /**
         * 日志服务器地址
         */
        logUrl: string;
        /**
         * 测试日志，如果开启，日志自动回添加测试字段，用于统计过滤
         */
        logTest: boolean;
        /**
         * 游戏cdn地址
         */
        cdnUrl: string;
        /**
         * 游戏分享信息配置文件地址
         */
        shareConfigUrl: string;
        /**
         * 支付id
         */
        offerId: string;
        /**
         * 支付时，是否使用安全沙箱
         */
        chargeSandbox: boolean;
        /**
         * 微信安卓平台分享时，所使用的代理地址
         */
        shareProxyUrl: string;
        /** 优先只启用客服跳转支付 */
        requireCustomServicePay: boolean;
        /**
         * 优先只启用小程序跳转支付
         */
        requireMiniAppPay: boolean;
        requireIndiaSPSPay: boolean;
        /**
         * 跳转支付appid
         */
        miniAppOfferId?: string;
        /** 跳转支付app模式 */
        payAppEnvVersion?: "trial" | "release" | "develop";
        /**
         * 启用游戏存档
         */
        useGameStorage: boolean;
        /**
         * 使用默认存档秘钥
         */
        useDefatulEncryptKey?: boolean;
        /**
         * 上传线上开发日志
         */
        uploadDevlog?: boolean;
        /**
         * 手动补单
         */
        userDealingOrder?: boolean;
        /**
         * 不使用用户id隔离存档
         */
        noRoleIsolation?: boolean;
        /**
         * 使用内存动态加密
         */
        encodeWithDynamicKey?: boolean;
        /**
         * 广告平台
         * - ironsource
         * - adtiming
         */
        advertPlatform: GDK.AdvertsAllPlatforms;
        advertPlatforms: GDK.AdvertsAllPlatforms[];
        /**
        * 更新提示回调
        */
        updateCallback?: (obj: {
            data: any;
            callback: (res: any) => void;
        }) => void;
        /**
         * 当前环境info实例
         */
        static instance: Info;
    }
}
declare namespace GSSDK {
    enum ChatEvent {
        ChatOnMessage = "ChatOnMessage"
    }
    class ServerChat {
        constructor();
        chatClient: WebSocket;
        protected _connected: boolean;
        protected _connecting: boolean;
        protected _connectCallback: () => void;
        protected _errorCallback: (error: any, retry: () => void) => void;
        protected _disconnectCallback: Function;
        connect(url: string, token: string, groupId: string, callback?: () => void): void;
        onOpenHandler(ev: Event): any;
        onCloseHandler(ev: CloseEvent): any;
        onMessageHandler(ev: MessageEvent): any;
        onErrorHandler(ev: Event): any;
        get connected(): boolean;
        get connecting(): boolean;
        request(data: {
            fromId: string;
            groupId: string;
            content: string;
            extras: {};
            toId?: number;
            chatType?: number;
        }): void;
        close(): void;
        /**
        * 当发生错误时的统一回调
        */
        setErrorCallback(callback: (error: any, retry: () => void) => void): void;
        /**
        * 设置断开连接回调
        */
        setDisconnectCallback(callback: any): void;
    }
}
declare namespace GSSDK {
    /**
     * 每日给力小游戏服务端对外接口文件
     */
    class GleeServerSDKInterface {
        version: string;
        ShareType: typeof ShareType;
        Info: typeof Info;
        sizeOfCache: number;
        private bindCallback;
        /**
        * 初始化SDK
        * @param info SDK配置信息
        * @param ext 扩展参数
        */
        init(info: Info, ext?: {
            /**
             * 自定义游戏客户端，目前仅用在仅接入gssdk的支付的情况下
             */
            gameClient?: slib.HttpGameClient;
            userId?: number;
        }): void;
        /**
         * 登录接口
         */
        login(param: LoginParam): Promise<unknown>;
        setLoadingProgress(param: {
            progress: number;
        }): void;
        /**
         * 设置app 3rd sdk bind callback
         * @param success 成功
         * @param fail 失败
         */
        setBindCallBack(callback: (succ: boolean, data?: any) => void): void;
        /**
         * 加载分享配置文件，建议在进入游戏后，在后台默默加载
         * @param success 成功
         * @param fail 失败
         */
        loadShareConfig(): Promise<void>;
        /**
         * # 该函数已经弃用
         * 向服务器提交日志记录
         * @param point 分享点，一个数字
         * @param data 分享的数据对象，该对象会被序列化成json文件，并且会在对象中额外赋值一些参数：
         * * appId 应用ID
         * * userId 用户RoleId
         * * version 游戏版本
         * * resVersion 游戏资源版本
         * * model 当前是开发还是测试
         * * systemInfo 系统信息
         * * createTime 账号创建时间
         * * channelId 渠道ID
         * @deprecated
         */
        commitLog(point: number, data: any): void;
        /**
         * 日志提交工具
         */
        get logCommitTool(): LogCommit;
        /**
         * 获取存储中心，所有玩家存档数据都保存在此
         * 老机制，存档时所有玩家数据整体同步到后端
         */
        get storage(): StorageCenter;
        /**
         * 获取分享类
         */
        get share(): Share;
        /**
         * 检查某个开关是否打开
         * @param key 开关名称
         */
        checkFeature(key: string): boolean;
        /**
         * 获取消费记录
         */
        get consumeLog(): ConsumeLog;
        /**
         * 同步服务器时间
         */
        syncServerTime(): Promise<unknown>;
        /**
         * 设置服务器时间差
         */
        set serverTimeOffset(v: number);
        /**
         * 获取服务器时间，已经考虑服务器与客户端的时间差
         */
        get serverTime(): Date;
        /**
         * 获取分享数据
         */
        get shareData(): ShareData;
        /**
         * 设置网络错误回调，在网络遇到错误时，会返回错误信息和重试函数。游戏中可以弹出提示框提示玩家。并可以让玩家点击重试来重连网络。
         * @param callback 回调函数
         */
        setNetErrorCallback(callback: (
        /**
         * 错误信息
         */
        error: any, 
        /**
         * 重试函数
         */
        retry: () => void) => void): void;
        /**
         * 网络握手遇到错误
         * @param callback
         */
        setSSLHandShakeErrorCallBack(callback: (index: number, url: string) => void): void;
        /**
         * 当现实模态弹框的回调
         */
        set showModalCallback(v: (index: number, url: string) => void);
        get showModalCallback(): (index: number, url: string) => void;
        /**
         * 当关闭模态弹框的回调
         */
        set closeModalCallback(v: (index: number, url: string) => void);
        get closeModalCallback(): (index: number, url: string) => void;
        /**
         * 支付流程实例
         */
        get payflow(): PayFlow.IPayFlow;
        /**
         * 设置加密key
         * @param key
         */
        setEncryptKey(key: string): void;
        /**
         * 全局事件中心
         */
        get gevent(): slib.SEvent<any>;
        /**
         * 支付事件中心
         */
        get payEvent(): slib.SEventOutput<PayFlow.ApplyOrderInfo>;
        /**
         * 游戏启动时的配置基础信息
         */
        get info(): Info;
        /**
         * 获取当前登录信息
         */
        get loginData(): LoginData;
        /**
         * 刷新用户信息
         * * 刷新RoleData中的值
         * * 刷新服务器所存储的用户信息
         */
        updateUserInfo(): Promise<unknown>;
        /**
         * 进行新的分享关联，一遍在onShow后需要执行一次
         * @returns 返回数字 0:不是群分享, 1:第1个挖宝者, 2:不是第一个挖宝者, 3:这个用户已经挖过宝了
         */
        shareRelation(): Promise<number>;
        /**
         * 强制更新游戏，如果当前已经是最新版本则不会被执行
         */
        forceUpdate(): Promise<unknown>;
        /**
         * 加载数据表
         * * info.platform 等于 develop 则加载本地表
         * * 其他值 加载服务器表
         * @param useLocal 是否使用本地表
         */
        loadTable(useLocal?: boolean): Promise<unknown>;
        /**
         * 设置默认的分享config
         */
        setDefaultShareConfig(configs: ShareConfig[]): void;
        /**
         * 查询红包余额
         */
        redPacketQuery(): Promise<{
            /**
            * 总红包数
            */
            money: number;
            /**
             * 达到多少钱可以提现
             */
            maxMoney: number;
            /**
             * 是否有红包可抽取
             */
            packetNum: number;
        }>;
        /**
         * 查询红包余额
         */
        redPacketLottery(): Promise<{
            /**
             * 总红包数
             */
            money: number;
            /**
             * 抽到的红包数
             */
            currentMoney: number;
            /**
             * 多少钱可以提现
             */
            maxMoney: number;
            /**
             * 是否有红包可抽取
             */
            packetNum: number;
        }>;
        /**
         * 触发红包
         * @returns true 添加红包成功 false 无法添加红包，已经到达红包领取上限
         */
        addRedPacket(): Promise<boolean>;
        /**
         * 默认游戏服务器对应的Client
         */
        get gameClient(): slib.HttpGameClient;
        /**
         * 低速客户端
         */
        get gameLowSpeedClient(): slib.HttpGameClient;
        protected _videoAd: GSSDK.VideoAd;
        /**
         * 单例，每次create出来是同一个
         */
        createVideoAd(param: GDK.VideoAdCreateParam): VideoAd;
        createVideoAdPolicy(): VideoAdPolicy;
        protected _fullscreenVideoAd: GSSDK.FullscreenVideoAd;
        /**
         * 单例，创建视频,创建失败返回null
         * @param param
         */
        createFullscreenVideoAd(param: GDK.FullscreenVideoAdCreateParam): FullscreenVideoAd;
        /**
         * 解密微信数据
         */
        wxDecrypt(data: {
            encryptedData: string;
            iv: string;
        }): Promise<string>;
        /**
         * 获取公告列表
         */
        getNoticeList(): Promise<{
            noticePicUrl: string;
            notices: {
                id: number;
                title: string;
                content: string;
                effectiveTime: number;
                expirationTime: number;
            }[];
        }>;
        getServerAddrList(data: {
            tishen: boolean;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                list: Array<DistrictDO>;
                myList: Array<number>;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): Promise<{}>;
        /**
         * 获取邮件列表
         */
        getMailList(): Promise<{
            [key: number]: {
                id: number;
                title: string;
                content: string;
                senderName: string;
                createTime: number;
                attachment: Array<any>;
            };
        }>;
        /**
         * 获取MQTT Token
         */
        getMQTTToken(data: any): Promise<any>;
        /**
         * 聊天
         */
        ChatEvent: typeof ChatEvent;
        get serverChat(): ServerChat;
        /**
         * 设置debug url
         */
        setAccountServerDebugUrl(url: any): void;
        /**
         * 更新结点信息
         */
        updateNode(nodeUrl: string, nodeValue: string): void;
    }
}
declare var gssdk: GSSDK.GleeServerSDKInterface;
declare namespace GSSDK {
    class FeatureSwitch {
        static readonly instance: FeatureSwitch;
        protected switchMap: {
            [key: string]: any;
        };
        /**
         * 设置功能的开启和关闭
         * @param key 功能key
         * @param enabled 是否开启
         */
        setFeature(key: string, enabled: boolean): void;
        /**
         * 检查某项功能是否开启
         * @param key
         */
        check(key: string): boolean;
        /**
         * 获取Map
         */
        getSwitchMap(): {
            [key: string]: any;
        };
    }
}
declare namespace GSSDK {
    class FullscreenVideoAdv1 {
        params: GDK.FullscreenVideoAdCreateParam;
        protected _reload: Function;
        protected _reloadKey: number;
        /**
         * 广告错误只上报n次
         */
        errorReportTimes: number;
        /**
         * 提交广告日志
         */
        commitLog(params: {
            eventId: number;
            index: number;
            eventName: string;
            eventKey: string;
            reason?: any;
        }): void;
        constructor(params: GDK.FullscreenVideoAdCreateParam);
        /**
         * 设置广告拉取间隔
         * - 默认每 1e31ms 一次
         */
        set loadInterval(value: number);
        protected _videoAd: GDK.IFullscreedVideoAd;
        /**
         * 广告已经加载
         * @readonly
         */
        private _isAdValid;
        get isAdValid(): boolean;
        set isAdValid(value: boolean);
        /**
         * 广告正在播放
         * @readonly
         */
        isShowing: boolean;
        /**
         * 预加载广告
         */
        load(): Promise<void>;
        /**
         * 广告加载成功回调
         */
        onLoad(callback: Function): void;
        offLoad(callback: Function): void;
        /**
         * 广告加载失败回调
         */
        onError(callback: (res: GDK.FullscreenAdOnErrorParam) => void): void;
        offError(callback: Function): void;
        /**
         * @param eventName 用于数据统计
         */
        play(params: {
            eventName: string;
        }): Promise<{
            isEnded: boolean;
        }>;
    }
}
declare namespace GSSDK {
    class InterstitialAdv1 {
        params: GDK.InterstitialAdCreateParam;
        protected _reload: Function;
        protected _reloadKey: number;
        /**
         * 广告错误只上报n次
         */
        errorReportTimes: number;
        /**
         * 提交广告日志
         */
        commitLog(params: {
            eventId: number;
            index: number;
            eventName: string;
            eventKey: string;
            reason?: any;
        }): void;
        constructor(params: GDK.InterstitialAdCreateParam);
        /**
         * 设置广告拉取间隔
         * - 默认每 10000ms 一次
         */
        set loadInterval(value: number);
        protected _videoAd: GDK.IInterstitialAd;
        /**
         * 广告已经加载
         * @readonly
         */
        private _isAdValid;
        get isAdValid(): boolean;
        set isAdValid(value: boolean);
        /**
         * 广告正在播放
         * @readonly
         */
        isShowing: boolean;
        /**
         * 预加载广告
         */
        load(): Promise<void>;
        /**
         * 广告加载成功回调
         */
        onLoad(callback: Function): void;
        offLoad(callback: Function): void;
        /**
         * 广告加载失败回调
         */
        onError(callback: (res: GDK.InterstitialAdOnErrorParam) => void): void;
        offError(callback: Function): void;
        /**
         * @param eventName 用于数据统计
         */
        play(params?: {
            eventName: string;
        }): Promise<{
            isEnded: boolean;
        }>;
    }
}
declare namespace GSSDK {
    class VideoAdv1 {
        params: GDK.VideoAdCreateParam;
        protected _reload: Function;
        protected _reloadKey: number;
        /**
         * 广告错误只上报n次
         */
        errorReportTimes: number;
        videoAdPolicy: VideoAdPolicy;
        /**
         * 提交广告日志
         */
        commitLog(params: {
            eventId: number;
            index: number;
            eventName: string;
            eventKey: string;
            reason?: any;
        }): void;
        constructor(params: GDK.VideoAdCreateParam);
        /**
         * 设置广告拉取间隔
         * - 默认每 1e31ms 一次
         */
        set loadInterval(value: number);
        protected _videoAd: GDK.IRewardedVideoAd;
        /**
         * 广告已经加载
         * @readonly
         */
        private _isAdValid;
        get isAdValid(): boolean;
        set isAdValid(value: boolean);
        /**
         * 广告正在播放
         * @readonly
         */
        isShowing: boolean;
        currentPlacementId: string;
        /**
         * 预加载广告
         */
        load(loadParams?: GDK.RewardVideoAdLoadParams): Promise<void>;
        /**
         * - 广告加载成功回调
         * - 执行顺序：
         *  - 后加后执行
         * - 用法示例：
         * ```typescript
         * onLoad(()=>{
         * 	...
         * })
         * ```
         */
        onLoad(callback: Function): void;
        offLoad(callback: Function): void;
        /**
         * 广告加载失败回调
         */
        onError(callback: (res: GDK.RewardedVideoAdOnErrorParam) => void): void;
        offError(callback: Function): void;
        /**
         * @param eventName 用于数据统计
         */
        play(params: {
            eventName: string;
            onShow?: () => void;
            onClose?: () => void;
        }): Promise<{
            isEnded: boolean;
        }>;
    }
}
declare namespace GSSDK {
    class AdConfig {
        advertId: number;
        name: string;
        priority: number;
        /**
         * 是否优质广告源
         */
        highgrade: number;
        countLimit: number;
        probability: number;
        advertPlatform: string;
    }
    class AdInfo {
        advertId: number;
        advertPlatform: string;
        lookTimes: number;
    }
    class VideoAdPolicy {
        adsConfig: AdConfig[];
        adsInfo: AdInfo[];
        saveTime: number;
        storageKey: string;
        constructor();
        saveAdsInfo(): void;
        setAdsConfig(adsConfig: AdConfig[]): void;
        markWatchedOnce(platform: string): void;
        /**
         * 依次按照 是否超过次数上限、是否标记+是否已播放、权重、广告源泉编号 排序
         */
        getNewAdInfo(): string;
    }
}
declare namespace GSSDK {
    class FullscreenVideoAdv2 {
        protected _videoAd: GDK.IAdvertUnit;
        params: GDK.FullscreenVideoAdCreateParam;
        protected _reload: Function;
        protected _reloadKey: number;
        /**
         * 广告错误只上报n次
         */
        errorReportTimes: number;
        /**
         * 提交广告日志
         */
        commitLog(params: {
            eventId: number;
            index: number;
            eventName: string;
            eventKey: string;
            reason?: any;
        }): void;
        constructor(params: GDK.FullscreenVideoAdCreateParam);
        /**
         * 广告已经加载
         * @readonly
         */
        private _isAdValid;
        get isAdValid(): boolean;
        set isAdValid(value: boolean);
        /**
         * 广告正在播放
         * @readonly
         */
        isShowing: boolean;
        /**
         * 预加载广告
         */
        load(): Promise<void>;
        /**
         * 广告加载成功回调
         */
        onLoadCallback: Function;
        onLoad(callback: Function): void;
        offLoadCallback: Function;
        offLoad(callback: Function): void;
        /**
         * 广告加载失败回调
         */
        onErrorCallback: Function;
        onError(callback: (res: GDK.FullscreenAdOnErrorParam) => void): void;
        offErrorCallback: Function;
        offError(callback: Function): void;
        /**
         * @param eventName 用于数据统计
         */
        play(params: {
            eventName: string;
        }): Promise<{
            isEnded: boolean;
        }>;
    }
}
declare namespace GSSDK {
    class InterstitialAdv2 {
        params: GDK.InterstitialAdCreateParam;
        protected _videoAd: GDK.IAdvertUnit;
        protected _reload: Function;
        protected _reloadKey: number;
        /**
         * 广告错误只上报n次
         */
        errorReportTimes: number;
        constructor(params: GDK.InterstitialAdCreateParam);
        /**
         * 广告已经加载
         * @readonly
         */
        private _isAdValid;
        get isAdValid(): boolean;
        set isAdValid(value: boolean);
        /**
         * 广告正在播放
         * @readonly
         */
        isShowing: boolean;
        /**
         * 预加载广告
         */
        load(): Promise<void>;
        /**
         * 广告加载成功回调
         */
        onLoadCallback: Function;
        onLoad(callback: Function): void;
        offLoadCallback: Function;
        offLoad(callback: Function): void;
        /**
         * 广告加载失败回调
         */
        onErrorCallback: Function;
        onError(callback: (res: GDK.InterstitialAdOnErrorParam) => void): void;
        offErrorCallback: Function;
        offError(callback: Function): void;
        /**
         * @param eventName 用于数据统计
         */
        play(params?: {
            eventName: string;
        }): Promise<{
            isEnded: boolean;
        }>;
    }
}
declare namespace GSSDK {
    class VideoAdv2 {
        params: GDK.VideoAdCreateParam;
        protected _videoAd: GDK.IAdvertUnit;
        protected _reload: Function;
        protected _reloadKey: number;
        /**
         * 广告错误只上报n次
         */
        errorReportTimes: number;
        constructor(params: GDK.VideoAdCreateParam);
        /**
         * 广告已经加载
         * @readonly
         */
        private _isAdValid;
        get isAdValid(): boolean;
        set isAdValid(value: boolean);
        /**
         * 广告正在播放
         * @readonly
         */
        isShowing: boolean;
        currentPlacementId: string;
        /**
         * 预加载广告
         */
        load(loadParams?: GDK.RewardVideoAdLoadParams): Promise<void>;
        /**
         * - 广告加载成功回调
         * - 执行顺序：
         *  - 后加后执行
         * - 用法示例：
         * ```typescript
         * onLoad(()=>{
         * 	...
         * })
         * ```
         */
        onLoadCallback: Function;
        onLoad(callback: Function): void;
        offLoadCallback: Function;
        offLoad(callback: Function): void;
        /**
         * 广告加载失败回调
         */
        onErrorCallback: Function;
        onError(callback: (res: GDK.RewardedVideoAdOnErrorParam) => void): void;
        offErrorCallback: Function;
        offError(callback: Function): void;
        /**
         * @param eventName 用于数据统计
         */
        play(params: {
            eventName: string;
            onShow?: () => void;
            onClose?: () => void;
        }): Promise<{
            isEnded: boolean;
        }>;
    }
}
declare namespace GSSDK {
    /**
     * 加载存档
     */
    class ArchivesLoader extends slib.LogicChainItem {
        setLoginData(): void;
        logic(): Promise<slib.LogicResult>;
    }
}
declare namespace GSSDK {
    /**
     * 验证存档版本
     */
    class CheckArchivesVersion extends slib.LogicChainItem {
        logic(): Promise<slib.LogicResult>;
    }
}
declare namespace GSSDK {
    /**
     * 检查实名验证
     */
    class CheckIdentityCertification extends slib.LogicChainItem {
        static instance: CheckIdentityCertification;
        private timeHandler;
        protected guestTime: number;
        protected guestInterval: number;
        protected minorTimeDaily: number;
        protected minorTimeHoliday: number;
        protected minorHourStart: number;
        protected minorHourEnd: number;
        private contentHourQuit;
        private contentTimeQuit1;
        private contentTimeQuit2;
        private notifys;
        private isCertificating;
        private getCertificationURL;
        private verifiedLogic;
        private guestLogic;
        logic(): Promise<slib.LogicResult>;
        private gotoCertificate;
        addNotify(f: (b: boolean) => void): void;
        showForceQuitDialog(content: string): Promise<void>;
        protected showMinorInfo(): Promise<void>;
        protected startNativeRealName(f: boolean): Promise<void>;
        showForceCertificationDialog(): Promise<void>;
        showCertificationTipDialog(): Promise<void>;
    }
}
declare namespace GSSDK {
    /**
     * 检查更新
     */
    class CheckNode extends slib.LogicChainItem {
        param: LoginParam;
        constructor(param: LoginParam);
        logic(data: any): Promise<slib.LogicResult>;
    }
}
declare namespace GSSDK {
    /**
     * 检查更新
     */
    class CheckUpdate extends slib.LogicChainItem {
        exitGame(): void;
        logic(): Promise<slib.LogicResult>;
    }
}
declare namespace GSSDK {
    class LogCommit {
        static readonly instance: LogCommit;
        /**
         * 游戏所在区ID
         */
        districtId: number | undefined;
        /**
         * 区分中的角色ID
         */
        roleId: string | number | undefined;
        constructor();
        /**
         * 用于扩展日志传递时所携带的参数；当拼装好日志对象后，会调用该函数。
         */
        applyLog: (data: any) => void;
        /**
         * 向服务器提交日志记录，仅仅起到记录的功能
         * @param point 分享点，一个数字
         * @param data 分享的数据对象，该对象会被序列化成json文件，并且会在对象中额外赋值一些参数：
         * * appId 应用ID
         * * userId 用户RoleId
         * * version 游戏版本
         * * resVersion 游戏资源版本
         * * model 当前是开发还是测试
         * * systemInfo 系统信息
         * * createTime 账号创建时间
         * * channelId 渠道ID
         */
        commit(point: number, data: any): void;
        /**
         * 提交分享日志
         * @param log
         */
        commitShareLog(log: ShareLog, logKey?: string): void;
        /**
        * 提交开发日志，用于线上问题日志收集
        * *
        * @param log
        */
        commitDevlog(data: {
            index: number;
            eventName: string;
        } | any): void;
        /**
         * 提交通用日志，用作后端统计
         * * 一般不需要主动调用
         * @param log
         */
        commitCommon(data: {
            /**
             * 事件类型参考附录
             * 1. 新手引导
             * 2. 分享状态 点击、成功、失败
             * 3. 用户等级
             * * 后续自行扩展
             */
            eventId: number;
            /**
             * 排序索引
             */
            index: number;
            /**
             * 事件名称
             */
            eventName: string;
        } | any): void;
        /**
         * 提交用户行为事件
         *
         * > 用户行为事件数据以多层数据结构组成，一般以 `模块、功能、结果` 组成，例如 :
         * ```javascript
         *      commitEvent("关卡",["闯关模式","第1关","胜利","获得金币"],100)；//最终会产生 `关卡/闯关模式/第1关/胜利` 这样的事件记录
         * ```
         * > 服务器根据该结构的事件记录进行分组汇总，得出最终的统计数据
         *
         * > 建议将所有行为事件名声明成常量，以避免手写错误。
         * > 数据层级的顺序将直接影响到统计的汇总计算，因此不应该频繁得修改层级顺序，例如：
         * ```javascript
         *     commitEvent("关卡",["闯关模式","第1关","胜利"])；
         *     commitEvent("关卡",["第1关","闯关模式","胜利"])；//进行这样的修改是完全没有必要的
         * ```
         *
         * @param groupName root层，所有数据以root为基础进行汇总统计。
         * @param eventNamePath 具体的行为数据
         * @param eventValue 扩展数据
         */
        commitEvent(groupName: string, eventNamePath: string[], eventValue?: number): void;
        /**
         * 提交踪迹，服务器会记录每一条踪迹
         * @param eventName 踪迹名称
         * @param eventParams 踪迹携带的数据，可以是数字和字符串；时间信息请传递毫秒的时间戳（number）；
         */
        commitTrack(eventName: string, eventParams: {
            [key: string]: string | number;
        }): void;
        /**
         * 提交用户数据大点
         * @param eventType user_set：设置或覆盖某个值；user_setOnce：设置并后期无法修改；user_add：进行数值累加。
         * @param eventParams 数据参数
         */
        commitUserData(eventType: "user_set" | "user_setOnce" | "user_add", eventParams: {
            [key: string]: string | number;
        }): void;
        /**
         * 提交引导日志
         * @param index 排序值
         * @param name 引导的名称
         */
        commitGuide(index: number, name: string): void;
        /**
         * 提交分享状态信息
         * @param name
         */
        commitShareState(
        /**
         * * 0 点击
         * * 1 成功
         * * 2 失败
         */
        state: 0 | 1 | 2, 
        /**
         * 分享点
         */
        point: string): void;
        /**
         * 提交用户等级变化信息
         * @param index 等级索引
         * @param name 等级名称
         */
        commitLevel(index: number, name: string): void;
        /**
         * 获取安装时间
         */
        installTime(): number;
        /**
         * 启动激活打点
         */
        commitActive(): void;
        startNetTest(listUrl: string): void;
        private commitNetTestStatistics;
        /**
         * 提交网络时间统计
         * @param name 接口名称
         * @param millisecond 消耗时间
         */
        commitNetTimeStatistics(name: string, millisecond: number): void;
        /**
         * 是否正在在线时长打点
         */
        protected _isLoopRunning: boolean;
        /**
         * 当前提交的在线时长时间
         */
        protected _loopTime: number;
        /**
         * 启动当现在的在线时长总时间
         */
        protected _allLoopTime: number;
        /**
         * 下一次发送的时间
         */
        protected _nextSend: number;
        /**
         * 最大的发送时间
         */
        protected _maxSendTime: number;
        protected _onlineTimer: any;
        /**
         * 平均在线时长间隔 分钟
         */
        onlineLoopTime: number;
        /**
         * 开始在线时长循环打点
         */
        startOnlineLoop(): void;
        /**
         * 停止在线时长循环打点
         */
        stopOnlineLoop(): void;
        commitOnlineTime(time: any): void;
    }
}
declare namespace GSSDK {
    class LoginParam {
        /**
        * 是否禁止游客登陆
        */
        disableVisitor?: boolean;
        /**
         * 是否允许Google登陆
         */
        google?: boolean;
        /**
         * 是否允许facebook登陆
         */
        facebook?: boolean;
        /**
         * 是否静默登陆
         */
        silent?: boolean;
        /**
         * 是否允许账号注册和登陆
         */
        account?: boolean;
        /**
         * 是否需要实名制
         */
        realName?: boolean;
        /**
         * 是否允许自动登陆
         * * 如果当前未绑定任何第三方账号，则执行游客登陆
         * * 否则，执行第三方账号的自动登陆
         */
        autoLogin?: boolean;
        /**
        * gamepind 登录token
        */
        token?: string;
        /**
        * need check node before login
        */
        nodeUrl?: string;
        /**
        * server node
        */
        node?: string | null;
    }
    class Login extends slib.LogicChainItem {
        param: LoginParam;
        constructor(param: LoginParam);
        logic(data: any): Promise<slib.LogicResult>;
    }
}
declare namespace GSSDK {
    enum OrderState {
        fail = 2,
        ok = 1,
        unknown = 0
    }
    type OrderInfoRaw = {
        id: string;
        userId: string;
        quantity: number;
        title: string;
        outTradeNo: string;
        goodsId: number;
        state: number;
        time: number;
        purchaseToken: string;
        payWay?: PayFlow.PayWay;
    };
    type OrderInfo = {
        outTradeNo: string;
        state: OrderState;
        goodsId: number;
        time: number;
        purchaseToken: string;
        payWay?: PayFlow.PayWay;
    };
    class DistrictDO {
        _appId_: number;
        closedInfo: string;
        districtId: number;
        host: string;
        id: string;
        name: string;
        no: number;
        open: boolean;
        openAt: number;
        sandbox: boolean;
        state: number;
        test: boolean;
    }
    class ServerProxy {
        static gameClient: slib.HttpGameClient;
        static gameLowSpeedClient: slib.HttpGameClient | null;
        static commonClient: slib.HttpGameClient;
        /**
         * 用户登录接口(用户首次进入游戏调用)
         */
        static loginTest(data: {}, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                userId: number;
                openId?: string;
                serviceTimestamp: number;
                service24Timestamp: number;
                dataTimestamp: number;
                nickname: string;
                profileImg: string;
                backupTime: number;
                userNew: false;
                shareSwitch: {};
                gameCurrency: {
                    gold: string;
                    diamond: string;
                    seed: string;
                };
                createTime: string;
                channelId: number;
                encryptKey: string;
                token: string;
                gametoken: string;
                noticeSign: string;
                heart: string;
                custom: string;
                /**
                 * 性别
                 */
                gender: number;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        /**
         * 游客登陆
         * * openId 传入空则产生新的账号
         * * 传入历史openId则表示游客再次登陆
         */
        static loginByOpenId(data: {
            openId: string;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                userId: number;
                openId?: string;
                serviceTimestamp: number;
                service24Timestamp: number;
                dataTimestamp: number;
                nickname: string;
                profileImg: string;
                backupTime: number;
                userNew: false;
                shareSwitch: {};
                gameCurrency: {
                    gold: string;
                    diamond: string;
                    seed: string;
                };
                createTime: string;
                channelId: number;
                encryptKey: string;
                token: string;
                gametoken: string;
                noticeSign: string;
                heart: string;
                custom: string;
                /**
                 * 性别
                 */
                gender: number;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        /**
         * 用户登录接口(用户首次进入游戏调用)
         */
        static userLogin(data: {
            code: string;
            system: number;
            launchOptionsQuery?: any;
            launchOptionsPath?: any;
            channelId?: number;
            clientSystemInfo: any;
            extraData?: any;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                userId: number;
                openId?: string;
                serviceTimestamp: number;
                dataTimestamp: number;
                nickname: string;
                profileImg: string;
                backupTime: number;
                userNew: false;
                service24Timestamp: number;
                shareSwitch: {};
                gameCurrency: {
                    gold: string;
                    diamond: string;
                    seed: string;
                };
                createTime: string;
                channelId: number;
                encryptKey: string;
                token: string;
                heart: number;
                gametoken: string;
                noticeSign: string;
                custom: string;
                gender: number;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        /**
         * 用户信息接口
         */
        static userGetUserInfo(data: {
            userId: string;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                userId: number;
                openId?: string;
                serviceTimestamp: number;
                dataTimestamp: number;
                nickname: string;
                profileImg: string;
                backupTime: number;
                shareSwitch: {};
                gameCurrency: {
                    gold: string;
                    diamond: string;
                    seed: string;
                };
                createTime: string;
                channelId: number;
                encryptKey: string;
                token: string;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        /**
         * 保存用户信息
         */
        static userSaveUserInfo(data: {
            userId: string;
            nickName: string;
            headImgUrl: string;
            iv?: any;
            encryptedData?: any;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: null;
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        /**
         * 保存游戏数据
         */
        static backupSave(data: {
            secretKey: string;
            timestamp: string;
            backupData: string;
            especially: number;
            diamondLog?: string;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data?: number;
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        /**
         * 保存游戏数据操作记录
         */
        static backupOpRecord(data: string, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data?: number;
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void, customUrl?: string): void;
        static backupGetBackup(data: {
            userId: number;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                backupData: string;
                secretKey: string;
                timestamp: number;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static checkUpdate(data: {
            version: string;
            versionCode: number;
            packageName: string;
            clientSystemInfo: any;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                id: string;
                createTime: string;
                updateTime: string;
                appId: number;
                packageName: string;
                platform: string;
                title: string;
                content: string;
                minVersion: string;
                maxVersion: string;
                state: number;
                downloadUrl: string;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static checkNode(data: {
            nodeUrl: string;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                node: string;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static updateNode(nodeUrl: string, data: {
            node: string;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: null;
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static shareAddShareRelation(data: {
            shareUserId: string;
            sign: string;
            userNew: boolean;
            sType?: any;
            wordId: any;
            iv?: any;
            addSelf: any;
            encryptedData?: any;
            bilateral?: any;
            special?: any;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            /**
             * 0:不是群分享, 1:第1个挖宝者, 2:不是第一个挖宝者, 3:这个用户已经挖过宝了
             */
            data: number;
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static shareGetShareRelationList(data: {
            sign: string;
            size: number;
            onlyNew: number;
            special: number;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                shareRelations: {
                    userId: number;
                    relationId: number;
                    sign: string;
                    nickname: string;
                    profileImg: string;
                    joinTimestamp: string;
                    userNew: boolean;
                }[];
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static isHoliday(data: {}, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: boolean;
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static gameGetSystemTime(data: {}, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: number;
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static checkForceUpdate(data: {
            version: string;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                needUpdate: boolean;
                newVersion: number;
                /**
                 * 缓存上限值
                 */
                sizeOfCache: number;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static getWxErCode(data: {
            scene: string;
        }, callback: (data: any) => void, modal?: boolean, errorCallback?: (err: any, retry: () => void) => void): void;
        static getPromotionList(data: {}, callback: (data: any) => void, modal?: boolean, errorCallback?: (err: any, retry: () => void) => void): void;
        static orderGenOrder(data: {
            payWay: PayFlow.PayWay;
            price?: number;
            priceCNY: number;
            priceUSD: number;
            quantity: number;
            goodsId: number;
            title: string;
            itemId: number;
            districtId?: string;
            qqGoodid?: string;
            token?: string;
            extra?: Object;
            others?: Object;
            customKey?: string;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: OrderInfo;
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static orderCheckOrderState(data: {
            payWay: PayFlow.PayWay;
            quantity?: number;
            goodsId?: number;
            title?: string;
            state?: 2 | 1 | 0;
            errCode?: number;
            gameId?: number;
            openKey?: string;
            outTradeNo: string;
            purchaseData?: string;
            signature?: string;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: 0 | 1;
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static orderReqDiffOrderList(data: {
            gameId: number;
            openKey: string;
            time: number;
            state?: number;
            purchaseData: any;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: OrderInfoRaw[];
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static wxDecrypt(data: {
            encryptedData: string;
            iv: string;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: string;
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static packetQueryRedPacket(data: {}, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                /**
                * 总红包数
                */
                money: number;
                /**
                 * 多少钱可以提现
                 */
                maxMoney: number;
                /**
                 * 是否有红包可抽取
                 */
                packetNum: number;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static packetLottery(data: {}, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                /**
                 * 总红包数
                 */
                money: number;
                /**
                 * 抽到的红包数
                 */
                currentMoney: number;
                /**
                 * 多少钱可以提现
                 */
                maxMoney: number;
                /**
                 * 是否有红包可抽取
                 */
                packetNum: number;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static packetAddRedPacket(data: {}, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            /**
             * * true 添加红包成功
             * * false 无法添加红包，已经到达红包领取上限
             */
            data: boolean;
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static getServerAddrList(data: {
            tishen: boolean;
        }, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                list: Array<DistrictDO>;
                myList: Array<number>;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static getNoticeList(data: {}, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                noticePicUrl: string;
                notices: {
                    id: number;
                    title: string;
                    content: string;
                    effectiveTime: number;
                    expirationTime: number;
                }[];
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static getMailList(data: {}, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                [key: number]: {
                    id: number;
                    title: string;
                    content: string;
                    senderName: string;
                    createTime: number;
                    attachment: Array<any>;
                };
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static getMQTTToken(data: any, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                [key: string]: {
                    id: number;
                    title: string;
                    content: string;
                    senderName: string;
                    effectiveTime: number;
                    expirationTime: number;
                    attachment: string;
                    createTime: number;
                }[];
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static getSubscribeOrder(data: {}, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: OrderInfoRaw[];
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
        static getVerifiedInfo(data: {}, callback: (data: {
            succeed: boolean;
            code: 0 | number;
            message: "success" | string;
            data: {
                verified: boolean;
                verifiedInfo?: any;
            };
        }) => void, modal?: boolean, errorCallback?: (error: any, retry: () => void) => void): void;
    }
}
declare namespace GSSDK {
    class ServerTime {
        protected static _serverTimeOffset: number;
        /**
         * 获取当前设置的与服务器产生的时间偏移值
         */
        static get serverTimeOffset(): number;
        /**
         * 设置当前设置的与服务器产生的时间偏移值，用于客户端时间转换为服务器端时间
         */
        static set serverTimeOffset(value: number);
        /**
         * 获取当前服务器时间
         */
        static get now(): Date;
        /**
         * 同步服务器时间
         */
        static syncServerTime(): Promise<unknown>;
    }
}
declare namespace GSSDK {
    class ShareConfig {
        /**
         * 确定哪些分享key可以使用 "0"可用于任何分享
         */
        shareFrom: string;
        /**
         * 分享的ID
         */
        shareID: string;
        /**
         * 分享的图片
         */
        sharePicUrl: string;
        /**
         * 分享的内容
         */
        shareContent: string;
    }
    class Share {
        static instance: Share;
        constructor();
        /**
         * 当自己与别人的分享产生关联时，将会产生该回调
         */
        shareRelationCallback: (query: {
            [key: string]: string;
        }, res: any) => void;
        /**
         * 分享的配置列表
         */
        shareConfig: ShareConfig[];
        /**
         * 生成分享数据结构
         * @param key 分享的分组ID
         * @param type 分享的类型
         * @param hour 当type==DAY时，用来表示分享签名失效的时间点。例如hour==5，则从5点到次日4:59期间，都只会使用一个分享key，以进行分组
         * @param duration 当type==TIME时，表示使用同一个key持续的时间。单位毫秒。
         */
        createShareData(key: string, type: ShareType, config: ShareConfig, { hour, duration, addSelf, bilateral, special, ext, logKey }?: {
            hour?: number;
            duration?: number;
            addSelf?: boolean;
            bilateral?: number;
            special?: number;
            ext?: string;
            logKey?: string;
        }): ShareLog;
        /**
         * 获取分享配置
         * @param shareId 分享id
         */
        getShareConfigBy(shareId: string): ShareConfig;
        /**
         * 获取分享配置
         * @param log 分享日志
         */
        getShareConfigByLog(log: ShareLog): ShareConfig;
        /**
         * 发起分享
         * @param key 分享的分组ID
         * @param type 分享的类型
         * ### 扩展参数
         * * hour 当type==DAY时，用来表示分享签名失效的时间点。例如hour==5，则从5点到次日4:59期间，都只会使用一个分享key，以进行分组
         * * duration 当type==TIME时，表示使用同一个key持续的时间。单位毫秒。
         * * mustGroup 必须为分享对群，如果设置为true，只有分享到群才会回调
         * * addSelf 是否允许添加自己
         * * special 额外特殊值
         * * ext 扩展属性
         * * inevitableSucceed 必然成功，如果传入true，在则不会触发分享失败
         */
        share(key: string, type: ShareType, { hour, duration, mustGroup, addSelf, bilateral, special, ext, inevitableSucceed, logKey }?: {
            hour?: number;
            duration?: number;
            mustGroup?: boolean;
            mustDifferentGroup?: boolean;
            addSelf?: boolean;
            bilateral?: number;
            special?: number;
            ext?: string;
            inevitableSucceed?: boolean;
            logKey?: string;
        }, success?: (isGroup: boolean, log: ShareLog) => void, fail?: (data?: any) => void): void;
        /**
         * 根据key和type查找ShareLog
         */
        getShareLog(key: string, type: ShareType): ShareLog;
        /**
         * 添加、替换现有的分享日志，key和type值相同的会被替换
         */
        setShareLog(log: ShareLog): void;
        /**
         * 根据分享日志获取分享列表
         * @param shareLog 分享日志
         * @param size 列表长度
         * @param onlyNew 是否只需要新玩家
         * @param callback 回调
         * @param showBlockLayer 是否显示遮挡层
         */
        getRelationList(shareLog: ShareLog, size: number, onlyNew: boolean, callback: (list: {
            userId: number;
            relationId: number;
            sign: string;
            nickname: string;
            profileImg: string;
            joinTimestamp: string;
            userNew: boolean;
        }[]) => void, showBlockLayer?: boolean, special?: number): void;
        /**
         * 根据key和type查找ShareLog
         * @param key 分享key
         * @param type 分享类型
         */
        findShareLog(key: string, type: ShareType): any;
    }
}
declare namespace GSSDK {
    /**
     * 加载用于分享的数据，不必必须下载完成
     */
    class ShareLoader extends slib.LogicChainItem {
        logic(data: any): Promise<slib.LogicResult>;
    }
}
declare namespace GSSDK {
    /**
     * 如果是点击分享的内容进来，则将该进来的用户关联到分享者
     */
    class ShareRelation extends slib.LogicChainItem {
        static isSendNew: boolean;
        logic(data: any): Promise<slib.LogicResult>;
    }
}
declare namespace GSSDK {
    /**
     * 加载服务器数据表，必须加载成功
     */
    class TableLoader extends slib.LogicChainItem {
        loadTable: (data: any) => void;
        constructor(loadTable: (data: any) => void);
        logic(data: any): Promise<slib.LogicResult>;
    }
}
declare namespace GSSDK {
    const gevent: slib.SEvent<any>;
}
declare namespace GSSDK.PayFlow {
    /**
     * 订单状态
     */
    type wxPayState = {
        errCode: number;
        state: OrderState;
        extra?: any;
    };
    type PaymentSuccessCallbackParams = {
        config: PaymentParams;
        orderInfo?: OrderInfo;
    };
    type PaymentSuccessCallback = (res: PaymentSuccessCallbackParams) => void;
    type PaymentMergeOptions = {
        /**
         * 是否补单流程中补发的订单
         */
        isMakingUpOrder: boolean;
    };
    /** 道具充值配置项 */
    interface RechargeConfigRow {
        /** 支付方式 */
        payWay?: PayWay;
        /** 序号，同时也是我们的商品ID */
        id?: number;
        /** 金额 */
        money?: number;
        /** 中间货币数量 */
        amount?: number;
        /** 商品名称 */
        title?: string;
        /** 后台二级货币ID */
        coinId?: number;
        /** 第三方后台商品ID */
        productId?: string;
        /** 商品实际付款价格 */
        price?: number;
        /**
         * 人民币总额（用于后台统计）
         */
        priceCNY?: number;
        /**
         * 美元总额（用于后台统计）
         */
        priceUSD?: number;
    }
    interface PaymentParamsOptions {
        /**
         * （正在弃用，用payUrl代替）每日给力支付app分区 ID
         * - 0 测试版
         * - 1 fox应用
         * - 2 海洋馆应用
         */
        gleeZoneId?: number;
        /**
         * 用于代替gleeZoneId判断app分区
         * - 用于客服跳转支付和app跳转支付
         * - 默认会检测传入 游戏地址 或 账号服地址
         * - 也可能需要手动填写此参数，形如 "https://sandbox.focus.mosoga.net"
         */
        payUrl?: string;
        /**
         * 屏幕方向
         * - 1 竖屏(默认)
         * - 2.横屏（home键在左边）
         * - 3.横屏 （home键在右边）
         */
        gameOrientation?: number;
        /**
         * - 副标题
         * - 客服跳转支付，会话内消息卡片标题
         */
        subTitle?: string;
        /**
         * - 客服跳转支付，会话内消息卡片图片路径
         */
        imagePath?: string;
        /**
         * 自定义附加参数
         */
        customExtra?: string;
        /**
         * 自定义附加参数(JSON格式)
         */
        customJsonExtra?: string;
        /**
         * 自动补单重试次数
         */
        autoMakeupRetryTimes?: number;
    }
    type PayWay = 'WechatPay' | 'AliPay' | 'UnifiedSdk' | 'VivoAppPay' | 'OppoApp' | 'GooglePay' | 'IosPay' | 'BaiduAppPay' | 'YYBPay' | 'AliGameAppPay' | 'meituAppPay' | 'xiao7';
    interface PaymentParams extends RechargeConfigRow {
        /**
         * 这里加自定义选项
         */
        options?: PaymentParamsOptions;
        qqGoodid?: string;
        others?: object;
        customKey?: string;
        /**
         * 合作商订单ID
         */
        coopOrder?: string;
    }
    interface Parent {
        /**
         * 支付平台ID，仅支持单个
         * - 如果需要多个，用 payWays 字段
         */
        channelId?: PayWay;
        /**
         * 多个支付平台ID
         * - 当前发布渠道需要支持几个支付平台，那么在当前渠道对应的代码里填几个支付平台的payWay
         */
        payWays?: PayWay[];
        /**
         * 充值配置表
         */
        chargeconfig: RechargeConfigRow[];
    }
    interface OrderRecordExported {
        orderno: string;
        state: OrderState;
        /** 订单生成时间 */
        time: number;
        /** 配表序号 */
        id: number;
        /** 金额 */
        money: number;
        /** 精灵石数量 */
        amount: number;
        /** 商品名称 */
        itemName: string;
        /** 用户ID */
        userId: string;
    }
    /**
     * 订单合并结果
     */
    interface MakeupOrdersResult {
        /** 合并顺利无异常 */
        isMergeOk: boolean;
        /** 有差异订单 */
        isDiffExist: boolean;
    }
    /**
     * 订单支付成功通知
     * 登录补单之前就要一直监听
     * example: GlobalEmit.instance.messsgeEmit.emit("onApplyOrder",<ApplyOrderInfo>notifyData);
     */
    interface IPayFlow {
        _status: PayFlowStatus;
        /**
         * 设置充值配置
         * @param parent
         */
        initConfig(parent: Parent): void;
        /**
         * 发起支付
         * - 如果是微信app跳转支付，successCallback 接口不会生效，需要通过补单流程完成支付，即监听 'onApplyOrder' 事件
         * - 如果是app内充值，那么 successCallback 和 'onApplyOrder' 事件都会生效
         * @param config 配置信息
         * @param successCallback 支付成功回调
         * @param failCallback 支付失败回调
         */
        payment(config: PaymentParams, successCallback?: PaymentSuccessCallback, failCallback?: Function): void;
        /**
         * 检查充值是否已经购买过一次
         * @param config 配置信息
         * @returns
         */
        isItemBoughtEver(config: RechargeConfigRow): boolean;
        /**
         * 校验补发订单
         * @returns
         */
        pullDiffOrders(successCallback: Function, failCallback?: Function, options?: PaymentParamsOptions): any;
        /**
         * 设置监听，用于微信app跳转支付
         * - 不再需要外部传入onShow方法
         */
        initListener(onShow?: (callback: Function) => void): void;
        /**
         * - false: 充值回调不可信（一律回调失败，但是实际上可能充值成功了），要通过后台切回补单事件通知来发奖励，如微信小游戏跳转支付、微信客服跳转支付、原生微信充值
         * - true: 可直接在充值回调中发放奖励，如谷歌支付，ios IAP
         */
        readonly isPayCallbackValid: boolean;
        /**
         * 订单历史
         * - 序号为0的订单是最早的订单
         */
        readonly orderRecordList: OrderRecordExported[];
        /**
         * 流程名
         */
        readonly payFlowName: string;
    }
}
declare namespace GSSDK.PayFlow {
    class PayFlowStatus {
        _rechargeBlockLayerIndex: [number, string];
        _isRecharging: boolean;
        /**
         * 包含各种外部传入配置
         */
        _parent: Parent;
    }
}
declare namespace GSSDK.PayFlow {
    class PayFlowMG implements IPayFlow {
        get payFlowName(): string;
        _status: PayFlowStatus;
        protected get _parent(): Parent;
        protected set _parent(value: Parent);
        protected get _isRecharging(): boolean;
        protected set _isRecharging(value: boolean);
        protected get _rechargeBlockLayerIndex(): [number, string];
        protected set _rechargeBlockLayerIndex(value: [number, string]);
        protected _payFlow: IPayFlow;
        protected _appPayFlowMap: {
            [index: string]: IPayFlow;
        };
        getPayFlow(payWay: string): IPayFlow;
        static readonly inst: PayFlowMG;
        get isPayCallbackValid(): boolean;
        constructor();
        initConfig(parent: Parent): void;
        initListener(onShow?: (callback: Function) => void): void;
        pullDiffOrders(successCallback: Function, failCallback?: Function, options?: PaymentParamsOptions): any;
        /**
         * 支付
         * @@export
         * @param config 配置信息
         * @param callback 支付成功回调
         */
        payment(config: PaymentParams, successCallback?: PaymentSuccessCallback, failCallback?: Function): void;
        /**
         * 检查充值是否已经购买
         * @@export
         * @param config 配置信息
         */
        isItemBoughtEver(config: RechargeConfigRow): boolean;
        get orderRecordList(): OrderRecordExported[];
    }
}
declare namespace GSSDK.PayFlow {
    type ApplyOrderInfo = {
        /**
         * 订单信息
         */
        orderInfo: OrderInfo;
        /**
         * 购买项
         */
        config: RechargeConfigRow;
        /**
         * 是否延后补发的订单
         */
        isDelayedApply: boolean;
        /**
         * 其他附加值
         */
        options: PaymentMergeOptions;
    };
    class OrderRecord {
        orderno: string;
        state: OrderState;
        /** 订单生成时间 */
        time: number;
        /** 序号 */
        Id: number;
        /** 金额 */
        Money: number;
        /** 精灵石数量 */
        Amt: number;
        /** 商品名称 */
        ItemName: string;
        /** 用户ID */
        userId: string;
        purchaseToken: string;
        constructor(orderInfo: OrderInfo, state: OrderState, config: RechargeConfigRow);
    }
    class PayRecords {
        /**
         * 订单最近同步时间
         */
        lastOrdersSyncTime: number;
        /**
         * 充值记录列表
         */
        orderRecordList: OrderRecord[];
        addRecord(orderInfo: OrderInfo, config: RechargeConfigRow): void;
        addRecordRaw(orderInfo: OrderInfo, config: RechargeConfigRow): void;
        deapplyRecord(orderInfo: OrderInfo, config: RechargeConfigRow): void;
        commitPayLog(key: string, config: PaymentParams, orderInfo: OrderInfo): void;
        commitPaidLog(key: string, config: PaymentParams, orderInfo: OrderInfo): void;
        applyRecord(orderInfo: OrderInfo, config: RechargeConfigRow, options: PaymentMergeOptions): void;
        isItemBoughtEver(config: RechargeConfigRow): boolean;
        /**
         * 获取存档中的实例
         */
        static get saved(): PayRecords;
    }
}
declare namespace GSSDK.PayFlow {
    class PayStatistic {
        commitLog(key: string, config: PaymentParams, orderInfo: OrderInfo): void;
        commitPaidLog(logType: string, config: PaymentParams, orderInfo: OrderInfo): void;
    }
    const payStatistic: PayStatistic;
}
declare namespace GSSDK.PayFlow.APayBase {
    /**
     * 基本支付流程
     */
    class PayFlow implements IPayFlow {
        payFlowName: string;
        _status: PayFlowStatus;
        protected get _parent(): Parent;
        protected set _parent(value: Parent);
        protected get _isRecharging(): boolean;
        protected set _isRecharging(value: boolean);
        protected get _rechargeBlockLayerIndex(): [number, string];
        protected set _rechargeBlockLayerIndex(value: [number, string]);
        get isPayCallbackValid(): boolean;
        constructor();
        initConfig(parent: Parent): void;
        initListener(onShow?: (callback: Function) => void): void;
        enableRechargeBlock(): boolean;
        disableRechargeBlock(): void;
        getHistoryCutline(): number;
        /**
         * 获取尽量早的订单同步时间点
         */
        getLastOrdersSyncTime(): number;
        /**
         * 仅在补单成功之后，立即更新最早未知订单时间点，用于同步订单
         */
        updateLastOrdersSyncTime(): void;
        /**
         * 以可读形式打印订单信息
         */
        getPrettyLocalRechargeRecords(): {
            time: number;
            state: OrderState;
            orderno: string;
            Money: number;
            Amt: number;
        }[];
        pullDiffOrders(successCallback: (result: MakeupOrdersResult) => void, failCallback?: Function): void;
        /**
         * app内sdk支付
         * @param config 配置信息
         * @param successCallback 支付成功回调
         * @param failCallback
         */
        payment(config: PaymentParams, successCallback?: PaymentSuccessCallback, failCallback?: Function): void;
        getCoinId(config: RechargeConfigRow): number;
        genOrder(config: RechargeConfigRow, extra: any, successCallback: (orderInfo: OrderInfo) => void, failCallback?: Function): void;
        hintPayAPIErrorCode(errCode: number): void;
        commitPayLog(key: string, config: PaymentParams, orderInfo: OrderInfo): void;
        payAPICall(config: PaymentParams, orderInfo: any, successCallback: (res: wxPayState) => void, failCallback: (res: wxPayState) => void): void;
        checkOrderState({ orderno, extra, config }: {
            orderno: string;
            extra: wxPayState;
            config: RechargeConfigRow;
        }, successCallback: (state: number) => void, failCallback?: Function): void;
        reqDiffOrderList({ time }: {
            time: number;
        }, successCallback: (result: OrderInfo[]) => void, failCallback?: Function): void;
        diffOrderList(infos: OrderInfo[]): {
            result: OrderInfo[];
            diffExist: boolean;
            needSync: boolean;
        };
        applyOrderList(infos: OrderInfo[], options: PaymentMergeOptions): void;
        mergeOrderList(infos: OrderInfo[], options: PaymentMergeOptions, successCallback: (result: OrderInfo[], diffExist: boolean, needSync: boolean) => void, failCallback?: Function): void;
        syncStorage(successCallback?: Function, failCallback?: Function): void;
        saveOrder(orderInfo: OrderInfo, config: RechargeConfigRow): void;
        applyOrder(orderInfo: OrderInfo, config: RechargeConfigRow, options: PaymentMergeOptions): void;
        /**
         * 检查充值是否已经购买
         * @@export
         * @param config 配置信息
         */
        isItemBoughtEver(config: RechargeConfigRow): boolean;
        get paysdk(): PayRecords;
        get orderRecordList(): OrderRecordExported[];
    }
}
declare namespace GSSDK.PayFlow.PayInApp {
    /**
     * 类似微信、玩一玩等内购支付流程
     */
    class PayFlow extends APayBase.PayFlow {
        payFlowName: string;
    }
}
declare namespace GSSDK.PayFlow.PayInAppWithAutoMakeup {
    /**
     * 充值之后，自带轮询补单
     * - 默认补单 3s * 2次
     */
    class PayFlow extends APayBase.PayFlow {
        payFlowName: string;
        /**
         * 剩余补单次数
         */
        protected autoMakeupOrderLeftTimes: number;
        /**
         * 补单定时器id
         */
        protected autoMakeupOrderScheduleId: any;
        /**
         * 自动补单间隔
         */
        protected autoMakeupOrderInterval: number;
        /**
         * 当前是否正在补单
         */
        protected isAutoMakingupOrders: boolean;
        /**
         * 触发自动定时补单
         */
        protected scheduleAutoMakeup(retryTimes?: number): void;
        /**
         * 暂停自动轮询补单入口
         */
        protected pauseAutoMakeup(): void;
        pullDiffOrders(successCallback: (result: MakeupOrdersResult) => void, failCallback?: Function): void;
        payment(config: PaymentParams, successCallback?: PaymentSuccessCallback, failCallback?: Function): void;
    }
}
declare namespace GSSDK.PayFlow.PayInsideLocalV1 {
    /**
     * 兼容类似谷歌支付等有本地支付缓存的老版本apk
     * - https://developer.android.com/google/play/billing/api.html?hl=zh-cn
     */
    class PayFlow extends APayBase.PayFlow {
        payFlowName: string;
    }
}
declare namespace GSSDK.PayFlow.PayInsideLocalV2 {
    /**
     * 支持类似谷歌支付等有本地支付缓存的支付方式
     * - https://developer.android.com/google/play/billing/api.html?hl=zh-cn
     */
    class PayFlow extends APayBase.PayFlow {
        payFlowName: string;
        checkOutLocalOrder(purchaseToken: string, payWay: PayWay): OrderInfo;
        /**
         * 本地化支付
         * @param config
         * @param successCallback
         * @param failCallback
         */
        payment(config: PaymentParams, successCallback?: PaymentSuccessCallback, failCallback?: Function): void;
        pullDiffOrders(successCallback: (result: MakeupOrdersResult) => void, failCallback?: Function, options?: PaymentParamsOptions): void;
        genOrder(config: RechargeConfigRow, extra: any, successCallback: (orderInfo: OrderInfo) => void, failCallback?: Function): void;
    }
}
declare namespace GSSDK.PayFlow.PayOutside {
    /**
     * 这种流程只通过后台切回补单事件通知来完成充值，不存在直接payment充值成功回调
     */
    class PayFlow extends APayBase.PayFlow {
        payFlowName: string;
        get isPayCallbackValid(): boolean;
        /**
         * 小程序跳转支付和客服支付
         * @param config
         * @param successCallback
         * @param failCallback
         */
        payment(config: PaymentParams, successCallback?: PaymentSuccessCallback, failCallback?: Function): void;
    }
}
declare namespace GSSDK.PayFlow.PayOutsideGamepind {
    /**
     * 这种流程需要提前生成第三方订单号，并且只通过后台切回补单事件通知来完成充值，不存在直接payment充值成功回调
     */
    class PayFlow extends APayBase.PayFlow {
        payFlowName: string;
        get isPayCallbackValid(): boolean;
        genOrder(config: RechargeConfigRow, extra: any, successCallback: (orderInfo: OrderInfo) => void, failCallback?: Function): void;
        /**
         * app内sdk支付
         * @param config 配置信息
         * @param successCallback 支付成功回调
         * @param failCallback
         */
        payment(config: PaymentParams, successCallback?: PaymentSuccessCallback, failCallback?: Function): void;
    }
}
declare namespace GSSDK.PayFlow.PayOutsideWithOrder {
    /**
     * 这种流程需要提前生成第三方订单号，并且只通过后台切回补单事件通知来完成充值，不存在直接payment充值成功回调
     */
    class PayFlow extends APayBase.PayFlow {
        payFlowName: string;
        get isPayCallbackValid(): boolean;
        /**
         * app内sdk支付
         * @param config 配置信息
         * @param successCallback 支付成功回调
         * @param failCallback
         */
        payment(config: PaymentParams, successCallback?: PaymentSuccessCallback, failCallback?: Function): void;
    }
}
declare namespace GSSDK.PayFlow.YYBPayFlow {
    /**
     * 类似微信、玩一玩等内购支付流程
     */
    class PayFlow extends APayBase.PayFlow {
        payFlowName: string;
        pullDiffOrders(successCallback: (result: MakeupOrdersResult) => void, failCallback?: Function): void;
        reqDiffOrderList({ time }: {
            time: number;
        }, successCallback: (result: OrderInfo[]) => void, failCallback?: Function): void;
    }
}
declare namespace GSSDK {
    class LocalStorage {
        static _encryptKey: string;
        static _defaultKey: string;
        /**
         * 设置当前的加密秘钥
         */
        static set encryptKey(v: string);
        /**
         * 获取当前的加密秘钥
         */
        static get encryptKey(): string;
        /**
         * 设置一个存储项
         * @param key 存储key
         * @param value 存储的值
         * @param encrypt 是否加密
         */
        static setItem(key: string, value: string, encrypt?: boolean): void;
        /**
         * 获取一个存储项
         * @param key 存储的key
         * @param encrypt 数据存储时，是否被加密
         */
        static getItem(key: string, encrypt?: boolean): any;
    }
}
declare namespace GSSDK {
    class StorageCenter {
        /**
         * 存储数据所使用的key
         */
        protected _storageKey: string;
        /**
         * 存储保存时间所使用的key
         */
        protected _timestampKey: string;
        /**
         * 不同用户的存档隔离值
         */
        roleIsolation: string | null;
        /**
         * 不同游戏的存档隔离值
         */
        gameIsolation: string | null;
        /**
         * 存储角色id所使用的key
         */
        roleIdKey: string;
        get storageKey(): string;
        set storageKey(v: string);
        get timestampKey(): string;
        set timestampKey(v: string);
        /**
         * 自动存储的时间间隔
         */
        autoInterval: number;
        protected _autoSave: boolean;
        protected _saveHandler: any;
        protected _storageMap: {
            [key: string]: Object;
        };
        /**
         * 当自动存储时，会执行该回调
         */
        onAutoSave: (() => void) | null;
        static readonly instance: StorageCenter;
        dirty: boolean;
        private dynamicKey?;
        constructor();
        startDirtySave(interval?: number): void;
        /**
         * 设置是否自动存储
         */
        set autoSave(value: boolean);
        /**
         * 获取当前是否自动存储
         */
        get autoSave(): boolean;
        /**
         * 保存存档到本地存储
         */
        saveToLocalStorage(): void;
        /**
         * 从本地存储读取存档
         */
        loadFromLocalStorage(): void;
        /**
         * 保存玩家数据至字符串
         */
        protected save(): any;
        /**
         * 加载玩家数据字符串
         */
        protected load(data: any): void;
        /**
         * 保存对象
         * @param obj 对象数据
         * @returns 保存后的数据
         */
        protected saveObject(obj: any): any;
        /**
         * 从对象中加载数据
         * @param obj 对象
         */
        protected loadObject(obj: any): any;
        /**
         * 本地是否已经有存档
         */
        get isSaved(): boolean;
        /**
         * 获取最新保存的存档的时间戳，如果获取失败返回0
         */
        get timestamp(): number;
        /**
         * 获取已存入的数据
         * @param key 数据的key
         */
        getSavedData(key: string): any;
        /**
         * 将数据存入
         * @param key key
         * @param data 数据
         */
        setSavedData(key: string, data: object): void;
        /**
         * 重置存储
         */
        reset(): void;
        protected timerid: number | null;
        protected currentBackupTime: number;
        /**
         * 重新开始计时备份
         */
        rescheduleBackup(): void;
        /**
         * 开始自动备份到服务器
         * @param backupTime 备份的时间间隔 秒
         */
        startBackup(backupTime?: number): void;
        /**
         * 暂停向服务器备份存档
         */
        stopBackup(): void;
        /**
         * 立即上传存档至服务器
         * * 注意，这里是从本地存储中读取的存档。因此可能由于自动存档的时间间隔而产生存档的误差，如果需要保证存档的及时性，应该先调用storage.saveToLocalStorage()
         */
        backup(): void;
    }
    let storage: StorageCenter;
}
declare namespace GSSDK {
    type ConsumeInfo = {
        recordid?: string;
        reason: string;
        current: number;
        diff: number;
        time?: number;
        stuff?: number;
        isIncrease?: boolean;
    };
    type ConsumeInfoRaw = {
        recordid?: string;
        reason: string;
        current: number;
        diff: number;
        time: number;
        stuff: number;
        isIncrease: boolean;
    };
    class ConsumeLog {
        protected records: ConsumeInfoRaw[];
        _curtimestamp: string;
        _idindex: number;
        /**
         * 获取唯一的记录id
         */
        protected genRecordID(): string;
        /**
         * 添加消费记录
         * @param info
         */
        addRecord(info: ConsumeInfoRaw): void;
        /**
         * 获取消费记录列表
         */
        getRecords(): string;
        /**
         * 清空消费记录
         */
        clearRecords(): void;
        /**
         * 获取当前存档保存的实例
         */
        static get saved(): ConsumeLog;
    }
}
declare namespace GSSDK {
    class LoginData {
        /**
         * 可以是角色的id 也可以是openid，是服务器唯一的角色key
         */
        roleId: any;
        /**
         * token数据
         */
        token: any;
        /**
         * 游戏服务器token数据
         */
        gameToken: any;
        /**
         * 登陆的openid
         */
        openId?: string | null;
        /**
         * 当前用户是否授权
         */
        isAuthorize: boolean;
        /**
         * 头像url
         */
        avatarUrl: string | null;
        /**
         * 昵称
         */
        nickName: string | null;
        /**
         * 性别
         * * 0 未知
         * * 1 男
         * * 2 女
         */
        gender: number;
        /**
         * 是否是新用户
         */
        isNew: boolean;
        /**
         * 创建时间
         */
        createTime: any;
        /**
         * 渠道id
         */
        channelId: any;
        /**
         * 游戏版本号
         */
        version: string;
        /**
         * 当天在线时长统计(s)
         */
        todayOnlineTime: number;
        /**
         * 下个0点，用于标记当天在线时长
         */
        tomorrowTimestamp: number;
        /**
         * 是否实名认证
         */
        isVerified?: boolean;
        /**
         * 实名认证信息
         * @example {"age": 8,"birthday": "2011-10-29","name":"xxxx",idCard:"330381201110291412"}
         */
        verifiedInfo?: {
            age: number;
            birthday: string;
            name: string;
            idCard: string;
        } | null;
        /**
         * 当天是否是节假日
         */
        isHoliday?: boolean;
        /**
         * 获取存档中的实例
         */
        static get saved(): LoginData;
        needSave(name: string): boolean;
        /**
         * 设置完整的登录数据
         * @param data
         */
        setLoginData(data: any): void;
        /**
         * 获取完整的登录数据
         */
        getLoginData(): {
            /**
             * 用户ID，就是roleId
             */
            userId: number;
            /**
             * 登录后的唯一ID
             */
            openId?: string;
            /**
             * 服务器时间戳，用于同步客户端和服务器端时间差
             */
            serviceTimestamp: number;
            /**
             * 下一天0点的时间戳
             */
            service24Timestamp: number;
            /**
             * 上次存档的时间戳
             */
            dataTimestamp: number;
            /**
             * 当前服务器上的昵称
             */
            nickname: string;
            /**
             * 当前服务器上的头像
             */
            profileImg: string;
            /**
             * 上传存档时间间隔 单位 秒
             */
            backupTime: number;
            /**
             * 是否为新用户
             */
            userNew: boolean;
            /**
             * 服务器所控制的开关
             */
            shareSwitch: {};
            /**
             * 服务器向客户端发放的奖励数据
             */
            gameCurrency: {
                gold: string;
                diamond: string;
                seed: string;
            };
            /**
             * 玩家创建时间
             */
            createTime: string;
            /**
             * 该玩家绑定的渠道ID
             */
            channelId: number;
            /**
             * 存档加密key
             */
            encryptKey: string;
            /**
             * 访问账号服所使用的 token
             */
            token: string;
            /**
             * 访问游戏服 所使用的 token
             */
            gametoken: string;
            /**
             * 心数量
             */
            heart: number;
            /**
             * 当前是否有公告 1表示有公告
             */
            noticeSign: 0 | 1;
            /**
             * 性别
             * * 0未知
             * * 1男
             * * 2女
             */
            gender: number;
            custom: string;
            /**
             * 测试证书
             */
            qa?: string;
            /**
             * 广告信息
             */
            ad?: string;
            /**
             * 服务器结点地区
             */
            node?: string;
            /**
             * 是否实名认证
             */
            verified?: boolean;
            /**
             * 实名认证信息
             * @example {"age": 8,"birthday": "2011-10-29","name":"xxxx",idCard:"330381201110291412"}
             */
            verifiedInfo?: {
                age: number;
                birthday: string;
                name: string;
                idCard: string;
            };
            /**
             * 当天是否是节假日
             */
            holidays?: boolean;
        };
        /**
         * 获取服务器下次0点的时间戳
         */
        getService24Timestamp(): number;
        /**
         * 调整第二天的0点时间
         * @param servertime 时间点
         */
        updateServer24Timestamp(servertime: number): void;
    }
}
