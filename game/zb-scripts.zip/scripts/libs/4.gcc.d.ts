declare namespace gcc {
    /**
     * 在window中注入兼容对象，达到兼容旧版本游戏的目的
     */
    function injectCompatibleObject(): void;
}
declare var core: gcc.Core;
declare var storage: GSSDK.StorageCenter;
declare namespace gcc {
    class CustomScrollView extends cc.Component {
        cellSize: cc.Size;
        cell: cc.Node;
        prefabCell: cc.Prefab;
        _lastRefreshTime: number;
        _scrollView: cc.ScrollView;
        _nodePool: cc.NodePool;
        _freshFunc: Function;
        _data: any[];
        _inited: {
            [key: number]: boolean;
        };
        _onRender: boolean;
        _isLoaded: boolean;
        onLoad(): void;
        start(): void;
        /**
         * @param data 数据
         * @param freshFunc 刷新每个节点的方法  freshFunc(node,index,data)
         */
        setData(data: any[], freshFunc: Function, relocate?: boolean): void;
        onLoaded: () => void;
        /**
         * 节点数量不变 单纯刷新的时候用
         * @param index 节点index
         * @param data 新的数据
         */
        refreshItem(index: number, data: any): void;
        updateVisibleItems(): void;
        /**
         * 创建一个占位的node
         */
        private _createNewNode;
        private _onScrollViewEvent;
        private _refreshContentNodes;
        _autoReleasePool: boolean;
        setOutsidePool(pool: cc.NodePool, autoRelease?: boolean): void;
        _getCellNode(): cc.Node;
        _refreshContent(): void;
        recycleForce(): void;
        onDestroy(): void;
        /**
         * 末尾插入一个节点
         * @param data 数据
         */
        pushItem(data: any, callback?: Function): void;
    }
}
declare namespace gcc {
    class ILabel extends cc.Component {
        key: string;
        onEnable(): void;
    }
}
declare namespace gcc {
    class ISprite extends cc.Component {
        onEnable(): void;
    }
}
declare namespace gcc {
    /**
     * 开关类，用于记录当前有哪些功能是开启的
     */
    class Switch {
        static instance: Switch;
        protected _switchData: {
            [key: string]: boolean;
        };
        constructor();
        /**
         * 初始化数据，需要传入一个功能Map
         * @param data
         */
        initData(data: {
            [key: string]: boolean;
        }): void;
        /**
         * 应用服务器提供的开关数据
         * @param data 值 0|'0'|false 关闭  1|'1'|true 开启
         */
        applyData(data: {
            [key: string]: any;
        }): void;
        /**
         * 检查功能模块是否开启
         */
        check(key: string): boolean;
    }
}
/**
 * hint

    cc.instantiate
    cc.isValid
    destroy
    cc.director
    cc.game
    
    // ctor() {}
    // update (dt) {}
    // lateUpdate(dt) {}
    // onDestroy() {}
    // onEnable() {}
    // onDisable() {}
    
 !zh
 计时器停止，会 emit('timerlabel:on-timer-stop',{time:this._lefttime})
 时间到零，会 emit('timerlabel:on-timeout')
 */
declare namespace gcc {
    class TimerLabel extends cc.Component {
        _timeformat: string;
        _lasTrigger: Function;
        _callTime: number;
        _isTouchlastFun: boolean;
        timeformat: string;
        _lefttime: number;
        lasTrigger: Function;
        callTime: number;
        isTouchlastFun: boolean;
        lefttime: number;
        protected _needUpdate: boolean;
        _labelComponent: cc.Label;
        _shallStartJustNow: boolean;
        shallStartJustNow: boolean;
        readonly formattedTime: string;
        _formattedTime: string;
        _timercallback: any;
        _endtip: string;
        endTip: string;
        onLoad(): void;
        start(): void;
        resumeTimer(): void;
        pauseTimer(): void;
        triggerEvent(): void;
        updateDate(): void;
        showEndTip(): void;
    }
}
declare namespace gcc {
    class BrightnessTo extends cc.ActionInterval {
        protected _toBrightness: number;
        protected _fromBrightness: number;
        constructor(duration: number, brightness: number);
        clone(): BrightnessTo;
        update(time: any): void;
        startWithTarget(target: cc.Node): void;
    }
    class ActionHelper {
        static readonly instance: ActionHelper;
        /**
         * 所有子节点的 action
         * @param node 节点
         * @param self 自己是否也执行
         */
        stopChildrenAllAction(node: cc.Node, self?: boolean, tag?: number): void;
        /**
         * 对所有子节点执行action
         * @param node 节点
         * @param action 动作
         * @param self 自己是否也执行
         */
        runChildrenAction(node: cc.Node, action: cc.Action, self?: boolean, tag?: number, excludeName?: any): void;
    }
}
declare namespace gcc {
    /**
     * 场景数据，每个场景在创建是都会附带这份数据。
     * 用于对节点和数据的维护
     */
    class SceneData {
        protected static _index: number;
        /**
         * 获取持续累加的索引
         */
        static readonly index: number;
        protected _index: number;
        protected _name: string;
        protected _data: Object;
        /**
         * 创建场景数据
         * @param name 场景的名称
         * @param data 场景需要传入的数据
         */
        constructor(name: string, data: Object);
        /**
         * 当前场景的索引id
         */
        readonly index: number;
        /**
         * 获取场景的名称
         */
        readonly name: string;
        /**
         * 获取场景的数据
         */
        readonly data: Object;
    }
    /**
     * 图层显示的类型
     */
    enum LayerType {
        /**
         * 常规弹框
         */
        FLOAT = 0,
        /**
         * 相对重要的信息弹框，通常为toast。
         * 层级比FLOAT高
         */
        INFO = 1,
        /**
         * 最高的层级，通常用来显示调试工具等
         */
        DEBUG = 2
    }
    /**
     * 图层数据，每个图层在创建是都会附带这份数据。
     * 用于对节点和数据的维护
     */
    class LayerData {
        protected static _index: number;
        /**
         * 获取持续累加的索引
         */
        static readonly index: number;
        protected _index: number;
        protected _url: string;
        protected _prefab: cc.Prefab;
        protected _data: Object;
        protected _node: cc.Node;
        protected _layerType: LayerType;
        protected _isCancel: boolean;
        /**
         * 图层数据
         * @param prefab 图层的预制体
         * @param data 图层的数据
         * @param node 图层的节点
         * @param layerType 图层所在的位置
         * @param url 图层的地址
         */
        constructor(prefab?: cc.Prefab, data?: Object, node?: cc.Node, layerType?: LayerType, url?: string);
        /**
         * 获取图层的id
         */
        readonly index: number;
        /**
         * 获取图层的url
         */
        readonly url: string;
        /**
         * 获取图层的预制体
         */
        readonly prefab: cc.Prefab;
        /**
         * 获取图层的数据
         */
        readonly data: Object;
        /**
         * 获取图层的节点
         */
        readonly node: cc.Node;
        /**
         * 获取图层的显示类型
         */
        readonly layerType: LayerType;
        /**
         * 是否取消
         */
        readonly isCancel: boolean;
        /**
         * 取消加载
         */
        cancel(): void;
    }
    class CacheLayerInfo {
        url: string;
        data: {
            data?: any;
            modalWindow?: boolean;
            layer?: LayerType;
            single?: boolean;
            cache?: boolean;
            modalTouch?: boolean;
            callback?: (layerData: LayerData) => void;
        };
    }
    /**
     * 核心库，主要用于场景和图层的管理。
     * 其次还附带toast、应用info、程序隐藏显示事件、gc事件等
     */
    class Core extends cc.EventTarget {
        protected static _instance: Core;
        /**
         * 获取Core的全局实例
         */
        static readonly instance: Core;
        /**
         * 当框架初始化完成触发
         */
        static readonly INIT: string;
        /**
         * 当游戏从后台进入时触发
         */
        static readonly SHOW: string;
        /**
         * 当游戏进入后台时触发
         */
        static readonly HIDE: string;
        /**
         * 当游戏调用GC时触发
         */
        static readonly GC: string;
        /**
         * Dialog显示或消失
         */
        static readonly LayerChange: string;
        protected _isShowed: boolean;
        /**
         * 当前游戏是否在前台
         */
        readonly isShowed: boolean;
        protected _loadingIndex: number;
        /**
         * 当前总共产生的loading总数
         */
        readonly loadingIndex: number;
        /**
         * 当显示toast时的屏幕偏移值
         */
        toastOffset: cc.Vec2;
        protected _sceneLoadingList: {
            index: number;
            scene: SceneData;
            callback: () => void;
        }[];
        protected _sceneList: Array<SceneData>;
        protected _layerList: Array<LayerData>;
        protected _cachedLayer: Array<CacheLayerInfo>;
        protected _floatLayer: cc.Node;
        protected _infoLayer: cc.Node;
        protected _debugLayer: cc.Node;
        protected _showLoadingModalCallback: (index: number, url: string) => void;
        protected _closeLoadingModalCallback: (index: number, url: string) => void;
        protected _bgTexture: cc.Texture2D;
        bgTexture: cc.Texture2D;
        /**
         * 控制是否弹出资源加载重试框
         */
        isShowRetryDialog: boolean;
        constructor();
        /**
         * 初始化场景，构建基础图层
         * 浮动层
         * 信息层
         * debug层
         */
        init(): void;
        protected openScene(scene: SceneData, callback?: () => void): void;
        /**
         * 压入场景
         * @param name 场景的名称
         * @param data 传递给场景的数据
         * @param callback 回调
         */
        pushScene(name: string, data?: any, callback?: () => void): SceneData;
        /**
         * 弹出场景
         * @param callback 回调
         */
        popScene(callback?: () => void): SceneData;
        /**
         * 切换场景
         * @param name 场景的名称
         * @param data 传递给场景的数据
         * @param callback 回调
         */
        replaceScene(name: string, data?: any, callback?: () => void): SceneData;
        /**
         * 获取当前的场景
         */
        readonly currentScene: SceneData;
        /**
         * 通过预制资源 显示图层
         */
        protected showLayerPrefab(layerData: LayerData, prefab: cc.Prefab, data: object, modalWindow?: boolean, layer?: LayerType, url?: string, modalTouch?: boolean): LayerData;
        getLayerCount(ltype: LayerType): number;
        /**
         * 显示图层对话框
         * @param url 对话框地址
         * ### 扩展参数
         * * data 传递给图层的数据
         * * modalWindow 是否进入模态模式
         * * cache cache如果有相同类型,暂不显示, layer 只支持为 float
         * * layer 所显示的图层位置
         * * single 是否只允许弹出一个弹框
         * * callback 弹框显示后的回调
         */
        showLayer(url: string, { data, modalWindow, layer, single, cache, modalTouch, callback }?: {
            data?: any;
            modalWindow?: boolean;
            layer?: LayerType;
            single?: boolean;
            cache?: boolean;
            modalTouch?: boolean;
            callback?: (layerData: LayerData) => void;
        }): void;
        /**
         * 判断某个图层是否显示
         * @param data 根图层有关的数据
         */
        isLayerShown(data: number | string | LayerData | cc.Node): boolean;
        /**
         * 关闭图层
         */
        closeLayer(data: number | string | LayerData | cc.Node): void;
        /**
         * 检查是否有cached layer 需要显示
         */
        checkCachedLayer(): void;
        /**
         * 设置需要实现模态层的回调
         */
        showModalCallback: (index: number, url: string) => void;
        /**
         * 设置关闭模态层的回调
         */
        closeModalCallback: (index: number, url: string) => void;
        showLoading(value: string): number;
        closeLoading(index: number, value: string): void;
        /**
         * 获取图层列表
         */
        getLayerList(): Array<LayerData>;
        /**
         * 弹出简单信息 结束后关闭
         * @param text toast文字内容
         * ### 扩展参数
         * * prefab toast所使用的预制体
         * * icon toast所使用的图标
         */
        toast(text: string, { prefab, icon, pos }?: {
            prefab?: string;
            icon?: cc.SpriteFrame;
            pos?: cc.Vec2;
        }): void;
        protected resLoadRetry(retry: () => void): void;
        /**
         * 获取当前的浮动图层
         */
        readonly floatLayer: cc.Node;
        /**
         * 获取当前的信息图层
         */
        readonly infoLayer: cc.Node;
        /**
         * 获取当前的调试图层
         */
        readonly debugLayer: cc.Node;
    }
    var core: Core;
}
declare namespace gcc {
    class Dialog extends cc.Component {
        static ENTER_ANIMATION_FINISHED: string;
        static LEAVE_ANIMATION_FINISHED: string;
        protected _data: any;
        protected _isClosing: boolean;
        /**
         * 设置用户数据
         */
        /**
        * 获取用户数据
        */
        data: any;
        /**
         * 对话框打开后是否通过代码将对话框居中，如果勾选则会保留弹框本身的坐标
         */
        allowModifyPosition: boolean;
        /**
         * 入场动画列表，弹框打开时，每个动画都会被播放
         */
        enterAnims: cc.AnimationClip[];
        /**
         * 离场动画列表，弹框关闭时，每个动画都会被播放
         */
        leaveAnims: cc.AnimationClip[];
        enterSound: cc.AudioClip;
        leaveSound: cc.AudioClip;
        /**
         * 播放入场动画,core中对话框打开时，默认会执行这个逻辑
         * @param finished 回调函数
         */
        playEnterAnimation(finished: () => void): void;
        /**
         * 播放入场动画,core中对话框打开时，默认会执行这个逻辑
         * @param finished 回调函数
         */
        playLeaveAnimation(finished: () => void): void;
        /**
         * 当界面加载完成后执行，界面数据由此传入
         * 该逻辑将在start之后执行
         * @param data
         */
        onInit(data: any): void;
        /**
         * 关闭当前对话框
         */
        close(): void;
        readonly isClosing: boolean;
        /**
         * 要对话框要被关闭时的回调
         * @returns 当返回true时，则对话框会取消关闭
         */
        onClose(): boolean;
        /**
         * 指定层级的zorder
         */
        getZIndex(): number;
    }
}
declare namespace gcc {
    class LangUtil {
        static localizeNode(node: cc.Node): void;
        static localizeRecursive(node: cc.Node): void;
        static localizeScene(lang: string, stringTable: any, gameInfo: any): void;
    }
}
declare namespace gcc {
    class Scene extends cc.Component {
        protected _data: any;
        data: any;
        /**
         * 当界面加载完成后执行，界面数据由此传入
         * @param data
         */
        onInit(data: any): void;
    }
}
declare namespace gcc {
    class Sound {
        /**
         * 文件url
         */
        protected _url: string;
        /**
         * 是否循环播放
         */
        protected _loop: boolean;
        /**
         * 音量
         */
        protected _volume: number;
        /**
         * 当前音效的id
         */
        protected _id: number;
        /**
         * 音频对象
         */
        protected _clip: cc.AudioClip;
        /**
         * 当前音频的状态
         */
        protected _state: "play" | "stop" | "pause";
        /**
         * 当音频播放完成触发
         */
        onFinish: () => void;
        /**
         * 音效播放类
         * @param url 播放的音频地址，一旦创建不可修改
         * @param loop 是否循环播放
         * @param volume 音量
         */
        constructor(url: string, loop?: boolean, volume?: number);
        /**
         * 暂停本音效
         */
        pause(): void;
        /**
         * 继续本音效
         */
        resume(): void;
        /**
         * 停止本音效
         */
        stop(): void;
        /**
         * 重新播放本音效
         */
        play(): void;
        readonly id: number;
        readonly clip: cc.AudioClip;
        readonly state: "play" | "stop" | "pause";
        volume: any;
        readonly loop: boolean;
        readonly url: string;
    }
    class MusicHelper {
        protected static _enableEffect: boolean;
        protected static _enableMusic: boolean;
        protected static _enableVibrate: boolean;
        /**
         *
         * @param url
         * @param loop
         * @param volume
         * @returns 声音控制对象
         */
        static play(url: string, loop?: boolean, volume?: number): Sound;
        static playEffect(clip: cc.AudioClip, loop: boolean, volume: number): number;
        static playMusic(clip: cc.AudioClip, loop: boolean): number;
        static setEffect(enable: boolean): void;
        static setMusic(enable: boolean): void;
        static setVibrate(enable: boolean): void;
        static readLocalSetting(): void;
        static readonly enableEffect: boolean;
        static readonly enableMusic: boolean;
        static readonly enableVibrate: boolean;
    }
}
