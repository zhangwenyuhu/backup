declare namespace ml {
    /**
     * * 所有的方法都会产生新的对象
     * * 所有的属性都是操作当前对象
     */
    class Circle {
        protected _center: ml.Point;
        protected _radius: number;
        constructor(center: ml.Point, radius: number, offset?: ml.Point);
        containsPoint(point: ml.Point): boolean;
        readonly center: ml.Point;
        readonly radius: number;
    }
    function circle(center: ml.Point, radius: number, offset?: ml.Point): Circle;
}
declare namespace ml {
    /**
     * * 所有的方法都会产生新的对象
     * * 所有的属性都是操作当前对象
     */
    class Point {
        x: number;
        y: number;
        constructor(x?: number, y?: number);
        /**
         * 获取当前向量的长度
         */
        /**
        * 改变当前向量的长度
        */
        length: number;
        /**
         * 获取当前向量的角度
         */
        /**
        * 设置当前向量的角度
        */
        angle: number;
        /**
         * 获取当前向量的单位向量
         */
        getNormal(): Point;
        /**
         * 克隆当前向量
         */
        clone(): Point;
        /**
         * 两个point相加，产生新的对象
         * @param point 相加的对象
         */
        sub(point: Point): Point;
        /**
         * 两个point相减，产生新的对象
         * @param point 要减的对象
         */
        add(point: Point): Point;
        /**
         * point数乘
         * @param rate
         */
        mult(rate: number): Point;
        /**
         * 计算自己与目标的距离
         * @param point
         */
        distance(point: Point): number;
        /**
         * 计算自己与目标的距离，不计算 Math.sqrt
         * @param point
         */
        distanceQuick(point: Point): number;
        /**
         * 逆时针旋转rad弧度
         * @param th 0~2*Math.PI
         */
        rotate(rad: number): Point;
        /**
         * 逆时针旋转angle角度
         * @param th 0~360
         */
        rotateAngle(angle: number): Point;
        /**
         * 当前向量与指定向量进行叉乘。
         */
        cross(vector: Point): number;
        /**
         * 当前向量与指定向量进行点乘。
         */
        dot(vector: Point): number;
        /**
         * 返回该向量的长度。
         */
        mag(): number;
        /**
         * 返回该向量的长度平方。
         */
        magSqr(): number;
        /**
         * 夹角的弧度。
         */
        getAngle(vector: Point): number;
        /**
         * 带方向的夹角的弧度。
         */
        getSignAngle(vector: Point): number;
    }
    function p(x: any, y: any): Point;
}
declare namespace ml {
    function rad(deg: number): number;
    function deg(rad: number): number;
}
declare namespace ml {
    /**
     * * 所有的方法都会产生新的对象
     * * 所有的属性都是操作当前对象
     */
    class Rect {
        protected _center: ml.Point;
        protected _width: number;
        protected _height: number;
        constructor(center: ml.Point, width: number, height: number, offset?: ml.Point);
        containsRect(rect: Rect): boolean;
        containsPoint(point: ml.Point): boolean;
        readonly maxX: number;
        readonly centerX: number;
        readonly minX: number;
        readonly maxY: number;
        readonly centerY: number;
        readonly minY: number;
    }
    function rect(center: ml.Point, width: number, height: number, offset?: ml.Point): Rect;
}

declare namespace logicchart.statetree {
    /**
     * 状态对象
     */
    class StatusObject {
        static sCurObjId: number;
        objectId: string;
        name: string;
        /**
         * 状态运行树
         */
        runtimeStatusTrees: StatusGraphUnitStruct[];
        /**
         * 初始状态可选配置表
         */
        runtimeInitStatusMap: RuntimeInitStatusMap;
        /**
         * 状态列表
         */
        statusMap: {
            [name: string]: FilterState;
        };
        /**
         * 暂时只提供互斥关系
         */
        statusRelations: {
            leavesRelation: StatusRelation;
            noRelation: StatusRelation;
            mutualRelation: StatusRelation;
        };
        eventHandlerRegister: EventHandlerRegister;
        /**
         * 自定义消息发射器map
         */
        protected emitterMap: {
            [name: string]: MessageEmitter;
        };
        /**
         * 默认的发射器
         */
        protected defaultEmitter: DefaultMessageEmitter;
        constructor();
        /**
         * 声明一个状态
         */
        protected declareState(name: string, triggerValue: basictypes): void;
        /**
         * 重载一个状态变量维护实现
         */
        overrideState(name: string, state: FilterState): void;
        /**
         * 获取状态
         */
        getStateValue(name: string): boolean;
        /**
         * 设置状态
         * - 每次先 leave 上一个互斥状态，再 trigger 当前状态，再 enter 当前状态
         */
        protected setStateValue(name: string, value: basictypes, session: Session | undefined, cachedMessages: EventMessage[]): void;
        protected setStateValueRaw(name: string, value: basictypes): void;
        applyInitStatusSet(setName: string): void;
        /**
         * 此帧开始到当前，某状态是否改变
         */
        isStateChanged(name: string): boolean;
        /**
         * 增加消息处理器
         */
        addMessageHandler(message: string, handler: StatusEventHandler): void;
        /**
         * 包装为回调方式增加消息处理器
         */
        addMessageHandleCallback(message: string, callback: (message: EventMessage) => void): StatusEventHandler;
        /**
         * 移除消息处理器
         */
        removeMessageHandler(message: string, handler: StatusEventHandler): void;
        clearMessageHandlersForMessage(message: string): void;
        /**
         * 清除所有消息处理器
         */
        clearMessageHandlers(): void;
        /**
         * 重载消息发射器
         */
        protected overrideMessageEmitter(message: string, emitter: MessageEmitter): void;
        /**
         * 对外分发消息
         */
        protected emit(message: EventMessage): void;
        /**
         * 帧数据记录
         */
        protected frameDatas: FrameDatas;
        /**
         * - 根据状态切换图遍历
         * - dt为逻辑帧时间
         */
        update(dt: number): void;
        /**
         * 发射意图消息
         */
        emitStatus(session: StatusTreeSession): void;
        /**
         * 发射意图消息
         */
        emitState(state: string, value?: basictypes, customParams?: any): void;
        /**
         * 清理帧缓存数据
         */
        clearFrameCache(): void;
    }
}
declare namespace logicchart.statetree {
    type LogParam = {
        time?: boolean;
        tags?: string[];
    };
    class Log {
        private static _enablePlaneLog;
        static enablePlaneLog: boolean;
        static toPlaneLog(args: any[]): string[];
        protected static _instance: Log;
        static readonly instance: Log;
        protected time?: boolean;
        protected tags?: string[];
        constructor({ time, tags }?: LogParam);
        /**
         * 将消息打印到控制台，不存储至日志文件
         */
        info(...args: any[]): void;
        /**
         * 将消息打印到控制台，并储至日志文件
         */
        warn(...args: any[]): void;
        /**
         * 将消息打印到控制台，并储至日志文件
         */
        error(...args: any[]): void;
        /**
         * 是否启用打印
         * - false 不打印
         */
        enabled: boolean;
    }
    var devlog: Log;
}
declare namespace logicchart.statetree {
    /**
     * 用于存储消息名称和参数
     */
    class EventMessage {
        /**
         * 当前对应的消息名称
         */
        message: string;
        params: any;
        constructor(message: string, params: any);
    }
    /**
     * 事件处理
     */
    class EventHandler {
        /**
         * 当前对应的消息名称
         */
        message?: string;
        session: Session;
        constructor(session: Session);
        execute(message: EventMessage): void;
    }
    /**
     * 事件注册管理
     */
    class EventHandlerRegister {
        handlersMap: {
            [message: string]: EventHandler[];
        };
        registerHandler(message: string, handler: EventHandler): void;
        isTypeOfHandlerExist(message: string): boolean;
        removeHandler(message: string, handler: EventHandler): void;
        clearHandlersForMessage(message: string): void;
        enabled: boolean;
        triggerEvent(message: EventMessage): void;
        clearAllHandlers(): void;
    }
}
declare namespace logicchart.statetree {
    /**
     * 过滤条件式，用于触发状态切换和事件
     */
    class FilterState {
        /**
         * 状态名
         */
        name: string;
        /**
         * 上下文会话
         */
        session: StateSession;
        /**
         * 触发值
         */
        triggerValue: basictypes;
        constructor(name: string, triggerValue: basictypes, session: StateSession);
        protected _value: basictypes;
        /**
         * 状态的值
         */
        value: basictypes;
        /**
         * 上一帧状态值
         */
        protected _lastFrameValue?: basictypes;
        protected _isLastFrameValueSetted?: boolean;
        /**
         * 相对上一帧状态是否改变了
         */
        readonly isChanged: boolean;
        /**
        * 清理帧缓存数据
        */
        clearFrameCache(): void;
    }
}
declare namespace logicchart.statetree {
    /**
     * 帧内状态管理
     */
    class FrameStatusManager {
        statusObjects: StatusObject[];
        /**
         * 调用所有状态对象update
         */
        update(dt: number): void;
    }
}
declare namespace logicchart.statetree {
    /**
     * 消息发送管理
     */
    class MessageEmitter {
        /**
         * 仅仅标记
         */
        name: string;
        constructor(name: string);
        emitTo(obj: EventHandlerRegister, message: EventMessage): void;
    }
    class DefaultMessageEmitter extends MessageEmitter {
        emitTo(obj: EventHandlerRegister, message: EventMessage): void;
    }
}
declare namespace logicchart.statetree {
    /**
     * 上下文会话
     */
    interface Session {
    }
    /**
     * 状态树会话
     */
    interface StatusTreeSession extends Session {
        /**
         * 意图集合
         */
        sessionVerifyCases?: {
            [key: string]: basictypes;
        };
        /**
         * 自定义参数
         */
        customParams?: any;
    }
    /**
    * 状态对象依赖会话
    */
    interface StateSession extends Session {
        /**
         * 状态绑定的对象
         */
        bindObject: StatusObject;
    }
}
declare namespace logicchart.statetree {
    interface StatusMessageParams {
        /**
         * 状态触发阶段
         */
        stateStage?: StateStage;
        /**
         * 外部传入的session
         */
        session?: StatusTreeSession;
    }
    class StatusEventMessage extends EventMessage {
        params: StatusMessageParams;
        constructor(message: string, params: StatusMessageParams);
    }
    /**
     * 用于在接受到消息时，存储消息和参数并转变状态，或者调起自定义处理函数
     */
    class StatusEventHandler extends EventHandler {
        statusChanger: {
            [name: string]: basictypes;
        };
        execute(message: StatusEventMessage): void;
    }
}
declare namespace logicchart.statetree {
    type OnUpdateValueCallback = (member: FilterState, curValue: basictypes, newValue: basictypes) => void;
    /**
     * 状态关系
     */
    interface StatusRelation {
        /**
         * 成员列表
         */
        members: FilterState[];
        /**
         * 参考状态
         */
        mutualValue?: basictypes;
        /**
         * 设置成员状态值，会根据成员关系自动改变其他成员状态
         */
        setMemberValue(member: FilterState, value: basictypes, onUpdateValue: OnUpdateValueCallback): any;
    }
    class StatusNoRelation implements StatusRelation {
        members: FilterState[];
        mutualValue?: basictypes;
        setMemberValue(member: FilterState, value: basictypes, onUpdateValue: OnUpdateValueCallback): void;
    }
    class StatusMutualRelation implements StatusRelation {
        members: FilterState[];
        mutualValue: boolean;
        constructor(mutualValue: boolean);
        setMemberValue(member: FilterState, value: boolean, onUpdateValue: OnUpdateValueCallback): void;
    }
}
declare namespace logicchart.statetree {
    /**
     * 状态图子节点结构
     */
    class StatusGraphUnitStruct {
        /**
         * 图形单元id
         */
        gid: number;
        /**
         * 类型
         */
        gtype: string;
        /**
         * 执行分支筛选条件，读取的值为状态对象的状态值
         */
        passCases: basicpair[];
        /**
         * 执行分支筛选条件，读取的值为状态对象的状态值
         */
        sessionPassCases: basicpair[];
        /**
         * 如果通过了筛选条件，那么执行true分支
         */
        trueLeaves: StatusGraphUnitStruct[];
        /**
         * 如果未通过筛选条件，那么执行false分支
         */
        falseLeaves: StatusGraphUnitStruct[];
        /**
         * 每次进入该单元必执行此状态设置
         */
        statusSetters: basicpair[];
        /**
         * 当前节点状态统称
         */
        leafStatus: string[];
    }
    type RuntimeInitStatus = {
        key: string;
        value: basictypes;
    }[];
    type RuntimeInitStatusMap = {
        [key: string]: RuntimeInitStatus;
    };
    type TreeConstructor = {
        [key: string]: TreeConstructor | boolean;
    }[];
    class StatusObjectDataStruct {
        predefinedStatus: {
            key: string;
            trigger: boolean;
        }[];
        statusRelations: {
            name: string;
            relation: string;
            status: string[];
        }[];
        runtimeStatusTrees: StatusGraphUnitStruct[];
        runtimeInitStatusMap: RuntimeInitStatusMap;
        /**
         * 用于支持手写状态树
         */
        runtimeStatusTreesConstructor: TreeConstructor;
        runtimeStatusList: StatusGraphUnitStruct[];
        runtimeStatusIdList: {
            [key: string]: number;
        };
    }
    /**
         * 状态图子节点结构
         */
    class StatusGraphUnitStructV2 {
        /**
         * 图形单元id
         */
        gid: number;
        /**
         * 类型
         */
        gtype: string;
        /**
         * 执行分支筛选条件，读取的值为状态对象的状态值
         */
        passCases: basicpair[];
        /**
         * 执行分支筛选条件，读取的值为状态对象的状态值
         */
        sessionPassCases: basicpair[];
        /**
         * 如果通过了筛选条件，那么执行true分支
         */
        trueLeaves: number[];
        /**
         * 如果未通过筛选条件，那么执行false分支
         */
        falseLeaves: number[];
        /**
         * 每次进入该单元必执行此状态设置
         */
        statusSetters: basicpair[];
        /**
         * 当前节点状态统称
         */
        leafStatus: string[];
    }
    class StatusObjectDataStructV2 {
        predefinedStatus: {
            key: string;
            trigger: boolean;
        }[];
        statusRelations: {
            name: string;
            relation: string;
            status: string[];
        }[];
        runtimeStatusTrees: number[];
        runtimeInitStatusMap: RuntimeInitStatusMap;
        /**
         * 用于支持手写状态树
         */
        runtimeStatusTreesConstructor: TreeConstructor;
        runtimeStatusList: StatusGraphUnitStructV2[];
        runtimeStatusIdList: {
            [key: string]: number;
        };
    }
    /**
     * 帧数据记录
     */
    class FrameDatas {
        throughLeavesLastFrame: StatusGraphUnitStruct[];
        throughLeavesCurFrame: StatusGraphUnitStruct[];
        /**
         * 清除帧缓存
         */
        clearFrameCache(): void;
    }
    interface RunGraphOptions {
        obj: StatusObject;
        frameDatas: FrameDatas;
        session: StatusTreeSession;
    }
    /**
     * 状态图
     */
    class StatusGraphHelper {
        /**
         * 从左到右，深优遍历
         */
        runGraph(graphRoot: StatusGraphUnitStruct, obj: StatusObject, frameDatas: FrameDatas, session: StatusTreeSession): void;
        protected _runGraph(graphRoot: StatusGraphUnitStruct, obj: StatusObject, frameDatas: FrameDatas, session: StatusTreeSession, cachedMessages: EventMessage[]): void;
        /**
         * 执行当前节点
         */
        protected runCurNode(curNode: StatusGraphUnitStruct, obj: StatusObject, frameDatas: FrameDatas, session: StatusTreeSession, cachedMessages: EventMessage[]): boolean;
        /**
         * 从编辑器导出状态树配置构建状态树对象
         */
        buildStatusObject(source: StatusObjectDataStruct): StatusObject;
        /**
         * 从手写状态树配置构建状态树对象
         */
        buildStatusObjectFromHandwrite(source: StatusObjectDataStruct): StatusObject;
        /**
         * 从手写状态树配置构建状态树对象
         */
        buildStatusObjectFromV2(sourceV2: StatusObjectDataStructV2): StatusObject;
        static readonly inst: StatusGraphHelper;
    }
}
declare namespace logicchart.statetree {
    type basictypes = boolean;
    type basicpair = {
        key: string;
        value: basictypes;
    };
    type boolmap = {
        [key: string]: boolean;
    };
    type StateStage = 'onenter' | 'onleave' | 'ontrigger' | 'onupdate';
}
declare namespace logicchart.trigger {
    class Context {
        protected _map: {
            [key: string]: any;
        };
        constructor(map?: {
            [key: string]: any;
        });
        protected visit(key: string, nameList?: string[]): {
            [key: string]: any;
        };
        /**
         * 获取
         * @param visit
         */
        get(visit: string): any;
        /**
         * 设置上下文的值
         * @param visit
         * @param value
         */
        set(visit: string, value: any): void;
        /**
         * 执行环境中的异步函数，将返回新的环境对象
         * @param visit
         * @param argv 参数列表
         * @param slotMap 插槽列表，条件达成则进行回掉，可以返回新的上下文
         */
        runAction(visit: string, slotMap: SLOTMAP, argv: any[]): void;
        /**
         * 执行环境中的函数
         * @param visit
         * @param argv 参数列表
         */
        runFunction(visit: string, argv: any[]): any;
        /**
         * 继承当前环境，插入新的值
         * @param map
         */
        extends(map: {
            [key: string]: any;
        }): Context;
    }
}
declare namespace logicchart.trigger {
    class GlobalLib {
        protected runner: Runner;
        constructor(runner: Runner);
        /**
         * 加
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        add(context: Context, a: number, b: number): number;
        /**
         * 减
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        sub(context: Context, a: number, b: number): number;
        /**
         * 乘
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        mul(context: Context, a: number, b: number): number;
        /**
         * 除
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        div(context: Context, a: number, b: number): number;
        /**
         * 次方
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        pow(context: Context, a: number, b: number): number;
        /**
         * 向下取整
         * @param context 当前上下文
         * @param a 值A
         */
        floor(context: Context, a: number): number;
        /**
         * 向上取整
         * @param context 当前上下文
         * @param a 值A
         */
        ceil(context: Context, a: number): number;
        /**
         * 四舍五入
         * @param context 当前上下文
         * @param a 值A
         */
        round(context: Context, a: number): number;
        /**
         * 大于
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        gt(context: Context, a: number, b: number): boolean;
        /**
         * 小于
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        lt(context: Context, a: number, b: number): boolean;
        /**
         * 大于等于
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        gte(context: Context, a: number, b: number): boolean;
        /**
         * 小于等于
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        lte(context: Context, a: number, b: number): boolean;
        /**
         * 等于
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        equ(context: Context, a: any, b: any): boolean;
        /**
         * 不等于
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        nequ(context: Context, a: any, b: any): boolean;
        /**
         * 非
         * @param context 当前上下文
         * @param a 值
         */
        not(context: Context, a: boolean): boolean;
        /**
         * 与
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        and(context: Context, a: boolean, b: boolean): boolean;
        /**
         * 或
         * @param context 当前上下文
         * @param a 值A
         * @param b 值B
         */
        or(context: Context, a: boolean, b: boolean): boolean;
        /**
         * 访问属性
         * @param context 当前上下文
         * @param visit 访问的属性名，多级使用“.”分割
         */
        get(context: Context, visit: string): any;
        /**
         * 设置属性
         * @param context 当前上下文
         * @param visit 访问的属性名，多级使用“.”分割
         * @param value 写入的值
         */
        set(context: Context, visit: string, value: any): void;
        /**
         * 设置参数
         * @param context
         * @param name 变量名称
         * @param value 写入的值
         */
        setValue(context: Context, name: string, value: any): void;
        /**
         * 读取参数
         * @param context
         * @param name 变量名称
         */
        getValue(context: Context, name: string): any;
        /**
         * 是否有参数
         * @param context
         * @param name 变量名称
         */
        hasValue(context: Context, name: string): boolean;
        /**
         * 按条件取值
         * @param context
         * @param condition 条件
         * @param value1 值1，当条件达成
         * @param value2 值2，当条件未达成
         */
        conditionValue(context: Context, condition: boolean, value1: any, value2: any): any;
        /**
         * 按属性取值
         * @param context
         * @param property 对应属性
         * @param argv 值列表，必须一一配对
         */
        switchValue(context: Context, property: any, ...argv: any[]): any;
        /**
         * 按序号取值
         * @param context
         * @param property 对应属性
         * @param argv 值列表
         */
        switchValueByIndex(context: Context, property: number, ...argv: any[]): any;
        /**
         * 随机数
         * 产生一个0到1的随机值
         * @param context 当前上下文
         * @param visit 访问的属性名，多级使用“.”分割
         */
        random(context: Context): number;
        /**
         * 延迟
         * 延迟一定时间，并触发插槽，如果被取消则不会触发
         * @param context 当前上下文
         * @param slotMap finish->$timems;
         * @param time 延迟的时间
         */
        delay(context: Context, slotMap: SLOTMAP, time: number): void;
        /**
         * 延迟帧
         * 延迟一定帧数，并触发插槽，如果被取消则不会触发
         * @param context 当前上下文
         * @param slotMap finish->$fpsfps;
         * @param time 延迟的时间
         */
        delayFPS(context: Context, slotMap: SLOTMAP, fps: number): void;
        /**
         * 衔接
         * @param context 当前上下文
         * @param slotMap next->;
         */
        goon(context: Context, slotMap: SLOTMAP): void;
    }
}
declare namespace logicchart.trigger {
    class LabelRunningData {
        /**
         * 循环次数
         * 从0开始
         */
        count: number;
        /**
         * @ignore
         */
        label: LabelData;
        constructor(label: LabelData);
    }
    class Runner {
        /**
         * 设置所使用的延迟函数，自定义时间系统下，延迟函数将自定义，默认使用系统延迟函数
         */
        setTimeout: (callback: () => void, time: number) => void;
        /**
         * 设置随机数函数，外部系统可能需要传入一个固定种子函数
         */
        random: () => number;
        /**
         * 动画帧数
         */
        animationFps: number;
        protected rootContext: Context;
        protected treeData: TreeData;
        protected isCancel: boolean;
        constructor(treeData: TreeData);
        /**
         * 继承根环境，生成新的环境对象
         * @param contextMap
         */
        extendsContext(contextMap: {
            [key: string]: any;
        }): Context;
        /**
         * 指定当前逻辑数据中的某个逻辑
         * @param name 执行的逻辑名称
         * @param context 自定义的上下文对象
         */
        execute(name: string, context?: Context): any;
        /**
         * 取消逻辑的执行
         */
        cancel(): void;
        protected run(blockData: Block, context: Context): any;
    }
}
declare namespace logicchart.trigger {
    type ActionData = {
        trigger$type: DataType;
        /**
         * 访问的动作路径，用.分割
         */
        visit: string;
        /**
         * 该方法传入的参数
         */
        params: any[];
        /**
         * 绑定的插槽
         */
        slots: {
            [key: string]: Block[] | {
                title: string;
                list: Block[];
            };
        };
    };
}
declare namespace logicchart.trigger {
    type ConditionData = {
        trigger$type: DataType;
        /**
         * 执行的条件函数
         */
        function: FunctionData;
        /**
         * 返回true的动作
         */
        true: {
            title: string;
            list: Block[];
        } | Block[];
        /**
         * 返回false的动作
         */
        false: {
            title: string;
            list: Block[];
        } | Block[];
    };
}
declare namespace logicchart.trigger {
    enum DataType {
        /**
         * 根节点数据
         */
        TREE = 0,
        /**
         * 执行对象的异步方法，暴露回掉插槽
         */
        ACTION = 1,
        /**
         * 执行对象的同步方法，并返回值，用于GETTER SETTER CONDITION 中
         */
        FUNCTION = 2,
        /**
         * 验证某个条件（通过FUNCTION等），暴露true，false插槽
         */
        CONDITION = 3,
        /**
         * 创建一个标签，用于goto跳转
         */
        LABEL = 4,
        /**
         * 跳转到制定标签
         */
        GOTOLABEL = 5
    }
    type Block = ActionData | FunctionData | ConditionData | LabelData | GoToLabelData;
    type SLOTMAP = {
        [key: string]: (map?: {
            [key: string]: any;
        }) => void;
    };
}
declare namespace logicchart.trigger {
    type FunctionData = {
        trigger$type: DataType;
        /**
         * 访问的函数路径，用.分割
         */
        visit: string;
        /**
         * 该方法传入的参数
         */
        params: any[];
    };
}
declare namespace logicchart.trigger {
    type GoToLabelData = {
        trigger$type: DataType;
        /**
         * 前往标签的名称
         */
        name: string;
        /**
         * 跳转的最大次数，小于等于 0 则不限制
         */
        count: number | FunctionData;
    };
}
declare namespace logicchart.trigger {
    type LabelData = {
        trigger$type: DataType;
        /**
         * 标签的名称
         */
        name: string;
        /**
         * 该标签下的逻辑，goto到该标签后会执行
         */
        slot: {
            title: string;
            list: Block[];
        } | Block[];
    };
}
declare namespace logicchart.trigger {
    type TreeData = {
        trigger$type: DataType;
        /**
         * 启动项可以是动作、条件、循环
         */
        startSlotMap: {
            [key: string]: Block[] | {
                title: string;
                list: Block[];
            };
        };
    };
}

declare namespace rpgfight {
    class Config {
        static getTriggerData(key: string): IEntity;
        static getStatusData(key: string): logicchart.statetree.StatusObjectDataStructV2 | null;
        static getConfig(key: string): IEntity;
        static getRawConfigContent(key: string): IEntity;
        static isDebugMode: boolean;
    }
}
declare namespace rpgfight {
    /**
     * 对场景和所有对象的调度
     */
    class Runner {
        /**
         * 每一帧的长度，毫秒
         */
        readonly frameStep = 40;
        /**
         * 当前逻辑帧数
         */
        protected _frameCount: number;
        protected _objectList: {
            [key: string]: GameObject;
        };
        /**
         * 游戏流程的管理器，可以拿到buff管理器、查找对象等。
         */
        protected _manager?: ManagerBase;
        timer: UpdateTimer;
        protected _paused: boolean;
        constructor();
        pause(): void;
        resume(): void;
        update(): void;
        /**
         * 外部实际的update调用次数
         * - 和 this.timer.frameCount 不同
         */
        get frameCount(): number;
        get currentTime(): number;
        get objectsCount(): GameObject;
        filterObjects(callbackfn: (value: GameObject, index: number, array: GameObject[]) => unknown, thisArg?: any): GameObject[];
        findObject(callbackfn: (value: GameObject, index: number, array: GameObject[]) => unknown, thisArg?: any): GameObject;
        addObject(value: GameObject): void;
        removeObject(value: GameObject): void;
        destroyObjects(): void;
        /**
         * 游戏管理器
         */
        get manager(): ManagerBase;
        /**
         * 设置manager，请不要自己调用
         * @param manager
         */
        setManager(manager: ManagerBase): void;
        protected _initSeed?: number;
        protected _seed: number;
        set seed(value: number);
        /**
         * 生成一个随机数
         */
        random(): number;
    }
}
declare namespace rpgfight {
    class Version {
        /**
         * 当数据模型有较大的改动，会影响旧版本代码的执行时，需要 +1。
         */
        inputDataVersion: number;
        /**
         * 每次发布自动 +1，请不要修改该值。
         */
        codeVersion: number;
    }
    /**
     * 版本号
     */
    const version: Version;
}
declare namespace rpgfight {
    /**
     * 外部通过替换 factory 实现view的替换
     */
    class ViewFactory {
        /**
         * 创建动画view
         * @param name 动画资源KEY
         */
        createView(name: string, owner: GameObject): View;
        protected _effectView: any;
        getSharedEffectView(): SharedEffectView;
        /**
         * 创建技能关联特效
         * @param name
         * @param owner
         * @param skillData
         */
        createSkillEffectView(name: string, owner: Hero, skillData: SkillData): SkillView;
    }
    /**
     * 抽象动画与动画的1对1的实例
     */
    class SharedEffectView {
        /**
         * 这是完全抽象的播放，其实什么都没干，也不关系。
         * 播放动画，不关心动画是否真的播放了、播放完成、帧事件等等。
         * @param name 动画名称
         * @param loop 是否循环
         * @example 已有的动画：
         * - die 死亡动画
         * - hurt 受击动画
         * - idle 待机动画
         * - knockback 击退
         * - lying 躺地
         * - knockfly 击飞
         * - knockoff 击倒
         * - move 走路动画，和位移配套
         * - standup 站起来
         */
        play(name: string, options: {
            loop?: boolean;
            position?: ml.Point;
            scale?: number;
            dir?: number;
            owner?: GameObject;
        }): void;
        playHurtEffect(hero: Hero, options: HurtOptions): void;
        playHealEffect(hero: Hero, options: HealOptions): void;
        playPowerEffect(hero: Hero, options: PowerOptions): void;
        playBuffEffect(hero: Hero, options: BuffOptions): void;
        playKillEffect(hero: Hero, options: KillOptions): void;
        playMaskEffect(opacity: number, duration: number): void;
        release(hero: Hero): void;
        /**
         * 释放该视图对象
         */
        destroy(): void;
    }
    /**
     * 抽象动画与动画的1对1的实例
     */
    class View {
        /**
         * 这是完全抽象的播放，其实什么都没干，也不关系。
         * 播放动画，不关心动画是否真的播放了、播放完成、帧事件等等。
         * @param name 动画名称
         * @param loop 是否循环
         * @example 已有的动画：
         * - die 死亡动画
         * - hurt 受击动画
         * - idle 待机动画
         * - knockback 击退
         * - lying 躺地
         * - knockfly 击飞
         * - knockoff 击倒
         * - move 走路动画，和位移配套
         * - standup 站起来
         */
        play(name: string, loop: boolean): void;
        /**
         * 播放音频
         * @param name
         * @param loop
         */
        playAudio(name: string, loop: boolean): void;
        /**
         * 设置视图坐标
         * @param p
         */
        setPosition(p: ml.Point, rotation?: boolean): void;
        /**
         * 设置视图缩放
         * @param scale
         */
        setScale(scale: number): void;
        setScaleX(scaleX: number): void;
        setScaleY(scaleY: number): void;
        /**
         * 设置锚点
         * @param p
         */
        setAnchorPoint(p: ml.Point): void;
        /**
         * 设置旋转角度
         * @param angle
         */
        setRotation(angle: number): void;
        /**
         * 设置长度
         * @param length
         */
        setWidth(length: number): void;
        /**
         * 设置视图向量 1向右 -1向左
         */
        setDirection(dir: number): void;
        /**
         * 设置英雄飞行的高度
         * @param value 高度值
         */
        setFlyHeight(value: number): void;
        pause(): void;
        setTimeScale(value: number): void;
        resume(): void;
        /**
         * 释放该视图对象
         */
        destroy(): void;
        /**
         * 每帧刷新
         */
        update(dt: number, hero: GameObject): void;
        hide(): void;
        show(): void;
        /**
         * 复活
         */
        revive(): void;
        /**
         * 高亮
         */
        highlight(): void;
        /**
         * 震屏
         */
        shake(): void;
        /**
         * 设置皮肤
         */
        setSkin(skin: string): void;
    }
    /**
     * 技能视图
     */
    class SkillView extends View {
        owner: Hero;
        skillData: SkillData;
        constructor(name: string, owner: Hero, skillData: SkillData);
        isAlive: boolean;
        duration: number;
        /**
         * 释放该视图对象
         */
        destroy(): void;
    }
}
declare namespace rpgfight {
    interface IEntity {
    }
    abstract class ISkillEntity implements IEntity {
        abstract isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        abstract filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        abstract useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        abstract getEffectNames(): string[];
        abstract getAudioNames(): string[];
    }
    function safeCall(method: any, target: any, runner: logicchart.trigger.Runner, params: any[]): any;
}
declare namespace rpgfight {
    abstract class IAiEntity implements IEntity {
        abstract decision(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
    }
    class AiEntity extends IAiEntity {
        /**
         * 行为决策
         */
        decision(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
    }
}
declare namespace rpgfight {
    abstract class ICalcEntity implements IEntity {
        abstract calcPhysicHurt(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): number;
        abstract calcMagicHurt(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): number;
        abstract calcHeal(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): number;
    }
    class CalcEntity extends ICalcEntity {
        /**
         * 物理伤害公式
         */
        calcPhysicHurt(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): number;
        /**
         * 魔法伤害公式
         */
        calcMagicHurt(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): number;
        /**
         * 血量治疗公式
         */
        calcHeal(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): number;
    }
}
declare namespace rpgfight {
    class StateEntity extends logicchart.statetree.StatusObjectDataStructV2 implements IEntity {
        constructor();
    }
}
declare namespace rpgfight {
    class skill_aersasi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_aersasi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_aersasi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_aersasi_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_aersasi_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_aerteliusi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_aerteliusi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_aerteliusi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_aerteliusi_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_aerteliusi_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_anyenvwang_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_anyenvwang_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_anyenvwang_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_anyenvwang_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_anyenvwang_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_artifact01 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_artifact01_super extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_artifact02 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_artifact03 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_artifact04 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_artifact05 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_artifact06 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_artifact07 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_bajiaoci_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_bajiaoci_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_bajiaoci_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_bajiaoci_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_banzang_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_banzang_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_banzang_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_banzang_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_banzang_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_boshi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_boshi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_boshi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_boshi_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_boshi_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff10 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff11 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff12 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff13 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff14 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff15 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff16 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff17 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff18 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff19 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff20 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff21 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff22 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff23 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff24 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff25 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff26 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff27 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff4 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff5 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff6 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff7 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff8 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_buff9 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_chaoren_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_chaoren_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_chaoren_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_chaoren_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_chaoren_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dabai_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dabai_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dabai_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dabai_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dabai_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dajiangshi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dajiangshi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dajiangshi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dajiangshi_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_danding_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_danding_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_danding_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_danding_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_danding_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_degula_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_degula_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_degula_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_degula_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_degula_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dujianmu_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dujianmu_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_dujianmu_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_duomamu_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_duomamu_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_duomamu_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_duomamu_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_duomamu_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_elingqishi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_elingqishi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_elingqishi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_elingqishi_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_elingqishi_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_emozhanshi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_fanhaixin_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_fanhaixin_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_fanhaixin_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_fanhaixin_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_fanhaixin_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_feijijiangshi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_feijijiangshi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_feijijiangshi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gangtiexia_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gangtiexia_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gangtiexia_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gangtiexia_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gangtiexia_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gaojimogu_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gaojimogu_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gaojimogu_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gelute_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gelute_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gelute_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gelute_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_gelute_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius01 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius02 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius03 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius04 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius05 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius06 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius07 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius08 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius09 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius10 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius11 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_genius12 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_haicaosuoxiao_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_haicaosuoxiao_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_haicaosuoxiao_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_haicaosuoxiao_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_haiwang_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_haiwang_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_haiwang_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_haiwang_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_haiwang_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_halibote_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_halibote_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_halibote_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_halibote_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_halibote_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huacai_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huacai_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huacai_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huacai_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_hudi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_hudi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_hudi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_hudi_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huimieboshi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huimieboshi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huimieboshi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huimieboshi_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huimieboshi_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huluobo_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huluobo_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_huluobo_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_initiative_artifact01 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_initiative_artifact02 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_initiative_artifact03 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_initiative_artifact04 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_initiative_artifact05 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_initiative_artifact06 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_initiative_artifact07 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jichujiangshi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jiefeijiangshi1_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jiefeijiangshi1_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jiefeijiangshi1_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jiefeijiangshi1_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jinganglang_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jinganglang_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jinganglang_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jinganglang_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jinganglang_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jinmaoshiwang_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jinmaoshiwang_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jinmaoshiwang_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jinmaoshiwang_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jinmaoshiwang_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jiqimao_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jiqimao_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jiqimao_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jiqimao_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jiqimao_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_jiqirenjiangshi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_kuituosi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_kuituosi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_kuituosi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_kuituosi_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_kuituosi_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_labahua_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_labahua_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_labahua_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_labahua_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_lanbo_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_lanbo_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_lanbo_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_lanbo_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leimu_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leimu_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leimu_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leimu_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leimu_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leimu_sskill4 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leishen_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leishen_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leishen_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leishen_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leishen_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_leishen_sskill4 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_linke_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_linke_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_linke_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_linke_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_linke_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_longzhongshirenhua_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_longzhongshirenhua_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_longzhongshirenhua_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_lvdengxia_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_lvdengxia_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_lvdengxia_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_lvdengxia_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_meidui_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_meidui_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_meidui_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_meidui_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_meidui_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_mieba_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_mieba_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_mieba_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_mieba_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_mieba_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_mingren_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_mingren_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_mingren_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_mingren_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_mingren_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_renzhe_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_renzhe_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_renzhe_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_renzhe_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_saiyaren_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_saiyaren_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_saiyaren_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_saiyaren_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_saiyaren_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shaseng_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shaseng_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shaseng_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shaseng_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shaseng_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shenqinvxia_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shenqinvxia_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shenqinvxia_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shenqinvxia_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shenqinvxia_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shirenhua_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shirenhua_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shirenhua_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_shirenhua_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_sishi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_sishi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_sishi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_sishi_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_sishi_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_tieshu_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_tieshu_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_tieshu_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_tieshu_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_tutenghong_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_tutenghong_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_tutenghong_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_tutenglv_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_tutenglv_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_tutenglv_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_xiangyuan_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_xiangyuan_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_xiangyuan_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_xianrenzhang_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_xianrenzhang_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_xianrenzhang_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_xiaochou_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_xiaochou_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_xiaochou_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_xiaochou_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_xiaoemo_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yangcong_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yangcong_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yangcong_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yangtao_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yangtao_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yangtao_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yingshanhong_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yingshanhong_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yingshanhong_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yingshanhong_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yinhezhanshi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yinhezhanshi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yinhezhanshi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yinhezhanshi_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yinhezhanshi_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yumi_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yumi_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yumi_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_yumi_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhaohuanwu_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhizhuxia_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhizhuxia_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhizhuxia_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhizhuxia_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhizhuxia_sskill3 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhongjiezhe_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhongjiezhe_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhongjiezhe_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhongjiezhe_sskill2 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhusun_attack extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhusun_bskill extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    class skill_zhusun_sskill1 extends ISkillEntity {
        /**
        * 特定激活条件
        */
        isUsable(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): boolean;
        /**
        * 选定技能目标
        */
        filterHero(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): any[];
        /**
        * 触发技能
        */
        useSkill(c: logicchart.trigger.Context, runner: logicchart.trigger.Runner): void;
        /**
        * 获取特效ID
        */
        getEffectNames(): string[];
        /**
        * 获取音效名
        */
        getAudioNames(): string[];
    }
}
declare namespace rpgfight {
    /**
     * 方向
     */
    enum HeroDirection {
        /**
         * 左
         */
        Left = -1,
        /**
         * 中
         */
        Center = 0,
        /**
         * 右
         */
        Right = 1
    }
    const HeroState: {
        /**
         * 待机
         */
        Idel: string;
        /**
         * 攻击
         */
        Attack: string;
        /**
         * 受击
         */
        Knock: string;
        /**
         * 击飞
         */
        KnockFly: string;
        /**
         * 击退
         */
        KnockBack: string;
        /**
         * 击倒
         */
        KnockOff: string;
        /**
         * 移动
         */
        Move: string;
        /**
         * 站起来
         */
        Standup: string;
        /**
         * 死亡
         */
        Die: string;
        /**
         * 进场
         */
        Enter: string;
        /**
         * 可移动
         */
        Movable: string;
        /**
         * 受伤
         */
        Hurt: string;
        /**
         * 胜利
         */
        Win: string;
        /**
         * 失败
         */
        Loss: string;
        /**
         * 角色存活
         */
        Life: string;
        /**
         * 已死亡
         */
        Dead: string;
        /**
         * 眩晕
         */
        Dizzy: string;
        /**
         * 免疫控制
         */
        ImmuneControl: string;
        /**
         * 假死
         */
        Shock: string;
        /**
         * 跟随
         */
        Follow: string;
    };
    const HeroTriggerEvent: {
        /**
         * 受到治疗效果
         */
        OnHeal: string;
        /**
         * 受伤
         */
        OnHurt: string;
        /**
         * 击杀
         */
        OnKill: string;
        /**
         * 助攻
         */
        OnAssistKill: string;
        /**
         * 攻击暴击
         */
        OnCritAttack: string;
        /**
         * 受到吸血治疗
         */
        OnSuckBlood: string;
        /**
         * 攻击闪避
         */
        OnAttackDodged: string;
        /**
         * 添加buff
         */
        OnAttachBuff: string;
        /**
         * 移除buff
         */
        OnDettachBuff: string;
        /**
         * 血量回升
         */
        OnRecoverHp: string;
        /**
         * 释放技能
         */
        OnStartUseSkill: string;
        /**
         * 死亡
         */
        OnDie: string;
        /**
         * 使别人受伤
        */
        OnInjuryOther: string;
        /**
         * 受到自身属性治疗
         */
        OnSelfHeal: string;
        /**
         * 免疫伤害
         */
        OnImmune: string;
        /**
         * 释放大招
         */
        OnStartUseBSkill: string;
        /**
         * 受伤前
         */
        OnPreHurt: string;
        /**
         * 眩晕
         */
        OnDizzy: string;
        /**
         * 受到负面Buff
         */
        OnDebuff: string;
        /**
         * 达到叠加上限
         */
        OnBuffLimit: string;
        /**
         * 普攻
         */
        onStartNormalAttack: string;
        /**
         * 护盾受伤
         */
        onShieldHurt: string;
        /**
         * 普攻暴击
         */
        OnCritNormalAttack: string;
        /**
         * 使别人受伤前
         */
        OnPreBeHurt: string;
        /**
         * 持续回血
         */
        OnBeHealing: string;
        /**
         * 持续掉血
         */
        OnBeHurting: string;
    };
    /**
     * 触发点类型
     */
    enum HeroTriggerEventEnum {
        /**
         * 受到治疗效果
         */
        OnHeal = 0,
        /**
         * 受伤
         */
        OnHurt = 1,
        /**
         * 击杀
         */
        OnKill = 2,
        /**
         * 助攻
         */
        OnAssistKill = 3,
        /**
         * 攻击暴击
         */
        OnCritAttack = 4,
        /**
         * 受到吸血治疗
         */
        OnSuckBlood = 5,
        /**
         * 攻击闪避
         */
        OnAttackDodged = 6,
        /**
         * 添加buff
         */
        OnAttachBuff = 7,
        /**
         * 移除buff
         */
        OnDettachBuff = 8,
        /**
         * 血量回升(包括吸血和治疗带来的回血事件)
         */
        OnRecoverHp = 9,
        /**
         * 释放技能
         */
        OnStartUseSkill = 10,
        /**
         * 死亡
         */
        OnDie = 11,
        /**
         * 使别人受伤
        */
        OnInjuryOther = 12,
        /**
         * 自身属性回血
         */
        OnSelfHeal = 13,
        /**
         * 免疫伤害
         */
        OnImmune = 14,
        /**
         * 释放大招
         */
        OnStartUseBSkill = 15,
        /**
         * 受伤前
         */
        OnPreHurt = 16,
        /**
         * 眩晕
         */
        OnDizzy = 17,
        /**
         * 受到负面Buff
         */
        OnDebuff = 18,
        /**
         * 达到叠加上限
         */
        OnBuffLimit = 19,
        /**
         * 普攻
         */
        OnStartNormalAttack = 20,
        /**
         * 护盾受伤
         */
        onShieldHurt = 21,
        /**
         * 普攻暴击
         */
        OnCritNormalAttack = 22,
        /**
         * 使别人受伤前
         */
        OnPreBeHurt = 23,
        /**
         * 持续回血
         */
        OnBeHealing = 24,
        /**
         * 持续掉血
         */
        OnBeHurting = 25
    }
    const HeroTriggerEventTranslateMap: {
        /**
         * 受到治疗效果
         */
        OnHeal: string;
        /**
         * 受伤
         */
        OnHurt: string;
        /**
         * 击杀
         */
        OnKill: string;
        /**
         * 助攻
         */
        OnAssistKill: string;
        /**
         * 攻击暴击
         */
        OnCritAttack: string;
        OnSuckBlood: string;
        OnAttackDodged: string;
        OnAttachBuff: string;
        OnDettachBuff: string;
        OnRecoverHp: string;
        OnStartUseSkill: string;
        OnDie: string;
        OnInjuryOther: string;
        OnSelfHeal: string;
        OnImmune: string;
        OnStartUseBSkill: string;
        OnPreHurt: string;
        OnDizzy: string;
        OnDebuff: string;
        OnBuffLimit: string;
        OnStartNormalAttack: string;
        onShieldHurt: string;
        OnCritNormalAttack: string;
        OnPreBeHurt: string;
        OnBeHealing: string;
        OnBeHurting: string;
    };
}
declare namespace rpgfight {
    /**
     * Buff立场
     */
    enum BuffSide {
        /**
         * 正面Buff
         */
        Positive = 0,
        /**
         * 中立
         */
        Neutral = 1,
        /**
         * 负面Buff
         */
        Negative = 2,
        /**
         * 未知
         */
        Unknown = 3
    }
    /**
     * buff作用的目标的类型
     */
    type BuffTargetType = "Hero";
    interface BuffApplyOptions {
        targetType?: BuffTargetType;
    }
    /**
     * buff接口
     */
    interface IBuffBase {
        ctype: string;
        /**
         * buff名称
         */
        name: string;
        /**
         * buffId
         * - 同类型同id同时只能存在一个
         *   - 可叠加则能触发叠加
         *   - 不可叠加则不能触发叠加
         * - 同类型不同id可同时存在
         */
        buffId: string;
        /**
         * buff优先级
         */
        priority: number;
        /**
         * 记录改buff由什么技能产生
         */
        theSkill?: SkillData;
        /**
         * 依赖对象
         */
        owner: GameObject;
        /**
         * 发送者
         */
        sender?: GameObject;
        /**
         * 同类叠加次数上限
         * - 默认无限次
         */
        duplicateAddTimesLimitWithSameType: number;
        /**
         * 是否允许同id叠加
         * - 默认不允许
         */
        allowDuplicateAddWithSameId: boolean;
        /**
         * 新增buff会触发
         */
        add(): void;
        /**
         * 移除buff会柴查
         */
        remove(): void;
        /**
         * buff当前是否启用，未启用则不生效
         */
        readonly isEnabled: boolean;
        /**
         * 是否未过期失效，过期失效将被释放
         */
        readonly isValid: boolean;
        /**
         * buff是否对该对象起作用
         */
        isValidFor(target: any, options: BuffApplyOptions): boolean;
        /**
         * 应用buff效果
         */
        apply(target: any, options: BuffApplyOptions): any;
        /**
         * 每帧调用
         */
        update(dt: number): void;
        /**
         * 处理buff关系
         * - 返回true，那么buff可以共存
         * - 返回false，那么不可共存，立即移除buff，并且本buff生效期间，不可再加入
         */
        dealBuffRelation(buff: IBuffBase): boolean;
        /**
         * Buff立场
         */
        buffSide: BuffSide;
        /**
         * 重置计时
         */
        resetHourglass(): void;
        updateBeforeFrame(): any;
    }
    class BuffBase implements IBuffBase {
        runner: Runner;
        ctype: string;
        static currentBuffId: number;
        /**
         * buffId
         * - 同类型同id同时只能存在一个
         *   - 可叠加则能触发叠加
         *   - 不可叠加则不能触发叠加
         * - 同类型不同id可同时存在
         */
        private _buffId;
        get buffId(): string;
        set buffId(value: string);
        /**
         * buff名称
         */
        name: string;
        /**
         * buff优先级
         */
        priority: number;
        /**
         * 同类叠加次数上限
         */
        duplicateAddTimesLimitWithSameType: number;
        /**
         * 是否允许特殊叠加
         */
        allowDuplicateAddWithSameId: boolean;
        /**
         * 记录改buff由什么技能产生
         */
        theSkill?: SkillData;
        /**
         * 依赖对象
         */
        owner: GameObject;
        /**
         * 发送者
         */
        sender?: GameObject;
        constructor(runner: Runner, owner: GameObject);
        protected onAdd(): void;
        protected onRemove(): void;
        add(): void;
        updateBeforeFrame(): void;
        remove(): void;
        protected _isEnabled: boolean;
        /**
         * buff当前是否生效
         */
        get isEnabled(): boolean;
        /**
         * 是否未过期失效，过期失效将被释放
         */
        get isValid(): boolean;
        /**
         * buff是否对该对象起作用
         */
        isValidFor(target: any, options: BuffApplyOptions): boolean;
        /**
         * 应用buff效果
         */
        apply(target: any, options: BuffApplyOptions): void;
        protected onApply(target: any, options: BuffApplyOptions): void;
        update(dt: number): void;
        /**
         * 处理buff关系
         */
        dealBuffRelation(buff: IBuffBase): boolean;
        protected _buffSide: BuffSide;
        /**
         * Buff立场
         */
        get buffSide(): BuffSide;
        set buffSide(value: BuffSide);
        /**
         * 重置计时
         */
        resetHourglass(): void;
    }
}
declare namespace rpgfight {
    /**
     * buff子效果接口
     */
    interface IBuffEffect extends ILiveObject {
        /**
         * buff effect 类别
         */
        effectType: BuffEffectType;
        ctype: string;
        /**
         * 宿主buff
         */
        container?: BuffBase;
        /**
         * 控制buff作用范围
         */
        filter?: BuffEffectTargetFilter;
        /**
         * 控制buff作用时机
         */
        limitTrigger?: BuffLimitTrigger;
        runner: Runner;
        /**
         * buff依赖的对象
         */
        owner: GameObject;
        /**
         * 附加选项
         */
        options: any;
        /**
         * 是否未失效，如果HeroBuff的effect全部失效，则该HeroBuff失效
         */
        readonly isValid: boolean;
        /**
         * buff是否对该对象起作用
        */
        isValidFor(target: any, options: BuffApplyOptions): boolean;
        /**
         * 针对对象作用
         * @param target
         * @param options
         */
        apply(target: any, options: BuffApplyOptions): any;
        /**
         * 每帧调用
         */
        update(dt: number): void;
        /**
         * 复制一个同类buff效果
         */
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): BuffEffect;
        onAdd(): void;
        onRemove(): void;
        /**
        * 处理buff关系
        * - 返回true，那么buff可以共存
        * - 返回false，那么不可共存，立即移除buff，并且本buff生效期间，不可再加入
        */
        dealBuffRelation(buff: IBuffBase): boolean;
        buffSide: BuffSide;
        resetHourglass(): void;
        updateBeforeFrame(): any;
    }
    /**
     * buff子效果
     */
    class BuffEffect implements IBuffEffect {
        runner: Runner;
        owner: GameObject;
        options: any;
        ctype: string;
        container?: BuffBase;
        /**
         * buff施法者
         */
        buffSender?: Hero;
        /**
         * buff 效果类型
         */
        effectType: BuffEffectType;
        /**
         * 控制buff作用范围
         */
        filter?: BuffEffectTargetFilter;
        /**
         * 控制buff作用时机
         */
        limitTrigger?: BuffLimitTrigger;
        constructor(runner: Runner, owner: GameObject, options: any);
        get isAlive(): boolean;
        static currentObjectId: number;
        private _objectId;
        get objectId(): string;
        protected getIsValid(): boolean;
        protected _isValid: boolean;
        get isValid(): boolean;
        updateBeforeFrame(): void;
        /**
         * buff是否对该对象起作用
        */
        isValidFor(target: any, options: BuffApplyOptions): boolean;
        protected _isValidFor(target: any, options: BuffApplyOptions): boolean;
        /**
         * 针对对象作用
         * @param target
         * @param options
         */
        apply(target: any, options: BuffApplyOptions): void;
        protected onApply(target: any, options: BuffApplyOptions): void;
        /**
        * 每帧针对每个对象作用
        * @param objs
        */
        protected updatePerFrameForPerTarget(obj: GameObject): void;
        /**
         * 每帧针对对象列表作用
         * @param objs
         */
        protected updatePerFrameForAllTargets(objs: GameObject[]): void;
        update(dt: number): void;
        protected _clone<T extends BuffEffect>(cls: typeof BuffEffect, context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): T;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): BuffEffect;
        onAdd(): void;
        onRemove(): void;
        dealBuffRelation(buff: IBuffBase): boolean;
        /**
         * 重置计时
         */
        resetHourglass(): void;
        protected timerMap: {
            [key: string]: number;
        };
        resetTimeout(key: string, f: () => void, duration: number): void;
        buffSide: BuffSide;
    }
}
declare namespace rpgfight {
    /**
     * 作用目标过滤器
     */
    class BuffEffectTargetFilter {
        isValidFor(buffEffect: BuffEffect, target: any, options: BuffApplyOptions): boolean;
    }
    /**
     * 敌人
     */
    class BuffEffectEnermyFilter {
        isValidFor(buffEffect: BuffEffect, target: HeroData, options: BuffApplyOptions): boolean;
    }
    /**
     * 自己
     */
    class BuffEffectMyselfFilter {
        isValidFor(buffEffect: BuffEffect, target: HeroData, options: BuffApplyOptions): boolean;
    }
    /**
     * 队友（不包含自己）
     */
    class BuffEffectTeammateFilter {
        isValidFor(buffEffect: BuffEffect, target: HeroData, options: BuffApplyOptions): boolean;
    }
    /**
     * 队伍成员（包含自己）
     */
    class BuffEffectTeamMembersFilter {
        isValidFor(buffEffect: BuffEffect, target: HeroData, options: BuffApplyOptions): boolean;
    }
}
declare namespace rpgfight {
    /**
     * buff作用限制
     */
    class BuffLimitTrigger {
        get isValid(): boolean;
        /**
         * 重置计时等限制
         */
        reset(): void;
    }
    interface BuffEndTriggerOptions {
        duration?: number;
        affectTimes?: number;
        hurtHpLimit?: number;
    }
    /**
     * 时限
     */
    class TimeLimitBuffTrigger extends BuffLimitTrigger {
        runner: Runner;
        owner: GameObject;
        options: BuffEndTriggerOptions;
        constructor(runner: Runner, owner: GameObject, options: BuffEndTriggerOptions);
        startTimeStamp: number;
        protected _isEnd: boolean;
        protected timerId?: number;
        reset(): void;
        get isValid(): boolean;
        get leftTime(): number;
    }
    /**
     * 次数限制
     */
    class AffectTimesLimitBuffTrigger extends BuffLimitTrigger {
        runner: Runner;
        owner: GameObject;
        options: BuffEndTriggerOptions;
        constructor(runner: Runner, owner: GameObject, options: BuffEndTriggerOptions);
        protected _affectTimes: number;
        reset(): void;
        get isValid(): boolean;
        addupAffectTime(times?: number): void;
    }
    /**
     * 耗损血限限制
    */
    class HpHurtLimitBuffTrigger extends BuffLimitTrigger {
        runner: Runner;
        owner: GameObject;
        options: BuffEndTriggerOptions;
        constructor(runner: Runner, owner: GameObject, options: BuffEndTriggerOptions);
        protected _hurtHp: number;
        reset(): void;
        get isValid(): boolean;
        addupHurtHp(hp?: number): void;
    }
}
declare namespace rpgfight {
    let buffNameList: {
        [key: string]: string;
    };
}
declare namespace rpgfight {
    class HeroBuff extends BuffBase {
        ctype: string;
        effectList: IBuffEffect[];
        /**
         * 是否未过期失效
         */
        get isValid(): boolean;
        updateBeforeFrame(): void;
        /**
         * 获取某类型 buff effect
         */
        filterEffect(effectType: BuffEffectType): IBuffEffect[];
        /**
         * 存在某类型 buff effect
         */
        isExistEffect(effectType: BuffEffectType): boolean;
        /**
         * buff是否对该对象起作用
         */
        isValidFor(target: any, options: BuffApplyOptions): boolean;
        /**
         * 应用buff效果
         */
        apply(target: any, options: BuffApplyOptions): void;
        update(dt: number): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, optionsList: any[]): HeroBuff;
        addEffect(effect: IBuffEffect): void;
        /**
         * 处理buff关系
         */
        dealBuffRelation(buff: IBuffBase): boolean;
        protected onAdd(): void;
        protected onRemove(): void;
        /**
         * Buff立场
         */
        get buffSide(): BuffSide;
        set buffSide(side: BuffSide);
        /**
         * 重置计时
         */
        resetHourglass(): void;
    }
}
declare namespace rpgfight {
    class HeroBuffDesignUIHelper {
        /**
         * buff设计助手
         */
        protected buffHelper: HeroBuffHelper;
        protected _hero: Hero;
        constructor(hero: Hero);
        /**
         * 英雄
         * @ignore
         */
        get hero(): Hero;
        protected _currentBuffTemplate?: HeroBuff;
        protected _currentBuffName?: string;
        protected _currentBuffId?: string;
        protected _currentBuffAccTimesLimit?: number;
        protected _currentBuffEffectOptions?: any[];
        /**
         * 给buff添加子效果
         * @param effectType
         * @param options
         * @ignore
         */
        createAndAddBuffEffect(context: logicchart.trigger.Context, effectType: BuffEffectType, options: any): void;
        /**
         * 结束buff设计
         * @param buffName buff代号
         * @ignore
        */
        protected finishDesignBuff(context: logicchart.trigger.Context): void;
        /**
         * 创建【BUFF包装器】
         * 创建一个【BUFF名称为buffName】的包装器
         * @param buffName buff代号
         * @ignore
         */
        beginDesignBuff(context: logicchart.trigger.Context, buffName: string, buffId: string): void;
        /**
         * 添加【BUFF包装器】
         * 添加自定义的BUFF包装器
         * @ignore
         */
        finishDesignAndAttachBuff(context: logicchart.trigger.Context): void;
        /**
         * 添加自定义buff
         * 添加自定义的BUFF包装器
         * @param buffName buff类别名称
         * @param buffId buffId
         * @param slotMap goon-> 设定 -> { }
         */
        designAndAttachBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffName: string, buffId: string): void;
        /**
         * 标记Buff立场
         * @param buffSide 立场
         */
        markBuffSide(context: logicchart.trigger.Context, buffSide: BuffSide): void;
        /**
         * 设置叠加上限
         * @param times 叠加次数上限
         */
        setBuffAccumulateTimesLimit(context: logicchart.trigger.Context, times: number): void;
        /**
         * 设置是否允许叠加
         * @param value 是否允许叠加
         */
        setBuffAllowDuplicateAddWithSameId(context: logicchart.trigger.Context, value: boolean): void;
        /**
         * 包含效果【加强攻击-百分比】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addAttackEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【加强攻击-值】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增加值
         * @param duration 持续时长
         */
        addAttackEnhanceBuffEffect2(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【降低攻击-百分比】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addAttackWeakenBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【降低攻击-值】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 降低值
         * @param duration 持续时长
         */
        addAttackWeakenBuffEffect2(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【魔法减伤下降】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 降低值
         * @param duration 持续时长
         */
        addMagicDefenseWeakenBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【命中提高(百分比)】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 提高倍率
         * @param duration 持续时长
         */
        addHitRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【命中下降(百分比)】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addHitRateWeakenBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【命中提高(值)】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 提高值
         * @param duration 持续时长
         */
        addHitValueEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【命中下降(值)】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addHitValueWeakenBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【克制伤害系数】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 值
         * @param duration 持续时长
         */
        addRestraintHurtRateBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【免疫伤害】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addInjuryFreeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫物理伤害】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addPhysicInjuryFreeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫魔法伤害】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addMagicInjuryFreeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫特定职业的英雄伤害】
         * BUFF包装器元素
         * @param context
         * @param attrValue 1:力量 | 2:智力 | 3:敏捷
         * @param duration 持续时长
         */
        addInjuryFreeByCareerBuffEffect(context: logicchart.trigger.Context, attrValue: HeroCareerType, duration: number): void;
        /**
         * 包含效果【免疫某些BUFF】
         * BUFF包装器元素
         * @param duration 时长
         * @param buffIds BUFFID
         */
        addImmuneBuffsBuffEffect(context: logicchart.trigger.Context, duration: number, ...buffIds: string[]): void;
        /**
         * 包含效果【禁魔】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addSkillUnUsableBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【隐身】
         * BUFF包装器元素
         * @param context
         * @param attrValue 透明度
         * @param duration 持续时长
         */
        addInvisibleBuffEffect(context: logicchart.trigger.Context, attrValue: number, duration: number): void;
        /**
         * 包含效果【恢复血量限制】
         * BUFF包装器元素
         * @param context
         * @param attrValue 参数
         * @param duration 持续时长
         */
        addHealingLimitBuffEffect(context: logicchart.trigger.Context, attrValue: number, duration: number): void;
        /**
         * 包含效果【不可被敌方选中】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addUnSelectableBuffEffectByEnermy(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【眩晕状态】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addDizzyStateBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【无法攻击】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addUnAttackableBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【无法闪避】
         * BUFF包装器元素
         * @param context
         * @param duration
         */
        addUnDodgeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【不可被我方选中】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addUnSelectableBuffEffectByCompanion(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【持续性范围伤害】
         * BUFF包装器元素
         * @param context
         * @param effectRate 攻击力转化倍率
         * @param duration 持续时长
         * @param interval 作用间隔
         */
        addPeriodlyHurtBuffEffect(context: logicchart.trigger.Context, effectRate: number, duration: number, interval: number): void;
        /**
         * 包含效果【中毒】
         * BUFF包装器元素
         * @param context
         * @param effectRate 扣血百分比（传小数）
         * @param duration 持续时长
         * @param interval 作用间隔
         */
        addPoisonedBuffEffect(context: logicchart.trigger.Context, effectRate: number, duration: number, interval: number): void;
        /**
         * 包含效果【加强友军攻击】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addCompanionAttackEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【共享吸血】
         * x BUFF包装器元素
         * @param context
         * @param target 依赖目标
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addSubSuckBloodBuffEffect(context: logicchart.trigger.Context, target: Hero, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【加强吸血】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 吸血等级
         * @param duration 持续时长
         */
        addSuckBloodLevelBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【免疫debuff】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addDebuffFreeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫正面buff】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addEnhanceBuffFreeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【输出伤害增加】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强倍率
         * @param duration 持续时长
         */
        addHarmGrowUpBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【输出伤害降低】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强倍率
         * @param duration 持续时长
         */
        addHarmCutDownBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【减伤】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addInjuryFreeRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【魔法减伤】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addExtraDefenseMagicHurtBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【物理减伤】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addExtraDefensePhysicalHurtBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【易伤】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryHardRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【易伤-物理】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryPhyicHardRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【易伤-魔法】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryMagicHardRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【闪避(传值)】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addDodgeEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【暴击率】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addCritRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【暴击伤害】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addCritHurtRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【移动速度】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addMoveSpeedEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【减移速】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addMoveSpeedWeakenBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【攻击速度】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addAttackSpeedEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【能量恢复效率】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addPowerChargeRateBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【受击能量恢复效率】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addPowerChargeRateWithHurtBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【防御-百分比】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addDefenseEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【防御-值】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addDefenseValueBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【生命上限】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addHpMaxEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【治疗效果】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addHealingEffectEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【被治疗效果】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addBeHealEffectEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【受攻击能量恢复速度】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addPowerIncreaseSpeedWithHurtBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【护盾】
         * BUFF包装器元素
         * @param context
         * @param slotMap onfinish->护盾消失->$name;
         * @param attrValue 伤害吸收比例
         * @param duration 持续时长
         */
        addShieldBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, attrValue: number, duration: number): void;
        /**
         * 包含效果【持续修改命中】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyHitRateBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续修改闪避】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyDodgeRateBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续修改暴击率】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyCritRateBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续修改暴击伤害】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyCritHurtBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续恢复生命】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeHealingBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续掉血】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次掉血量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeHurtingBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【移动持续掉血】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次掉血量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addMoveBeHurtingBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续恢复能量】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeChargingEnergyBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【反转阵营】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addRevertBattleTeamBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【限制技能】
         * BUFF包装器元素
         * @param context
         * @param skillId 技能id
         * @param duration 持续时长
         */
        addFetterSkillBuffEffect(context: logicchart.trigger.Context, skillType: SkillTypeEnum, duration: number): void;
        /**
         * 包含效果【魔伤反甲】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         * @param enhanceRate 倍率
         * @param interval 最小触发间隔，填 0 则不限制
         */
        addMagicThornsBuffEffect(context: logicchart.trigger.Context, duration: number, enhanceRate: number, interval: number): void;
        /**
         * 包含效果【触发反馈】
         * BUFF包装器元素
         * @param context
         * @param slotMap ok->作用点触发->{"sourceHero":{"describe":"来源英雄","type":"Hero"},"triggerData":{"describe":"触发数据","type":"HeroTriggerData"}}
         * @param triggerEvent 触发事件
         * @param duration 持续时长
         * @param interval 触发最小间隔
         * @param custom 自定义数据
         */
        addHeroActioinTriggerBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, triggerEvent: HeroTriggerEventEnum, duration: number, interval: number, custom: number | boolean | string): void;
        /**
         * 包含效果【战斗数据累积反馈】
         * BUFF包装器元素
         * @param context
         * @param slotMap ok->作用点触发->{"fightDataAccumulated":{"describe":"累计数据","type":"HeroFightDataAccumulated"}}
         * @param duration 持续时长
         */
        addHeroFightDataAccuBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, duration: number): void;
        /**
         * 包含效果【无法移动】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addUnMovableBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫控制】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addImmuneControlBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【假死】
         * BUFF包装器元素
         * @param context
         * @param slotMap die->死亡触发->{"sourceHero":{"describe":"来源英雄","type":"Hero"}}
         * @param duration 持续时长
         */
        addShockBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, duration: number): void;
        /**
         * 包含效果【技能冷却时间】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addSkillIntervalCdBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【优先攻击】
         * BUFF包装器元素
         * @param context
         * @param target 目标
         * @param duration 持续时长
         */
        addFirstAttackHeroBuffEffect(context: logicchart.trigger.Context, target: Hero, duration: number): void;
        /**
         * 包含效果【距离监听】
         * BUFF包装器元素
         * @param context
         * @param slotMap inRange->范围内->{"范围内选择器":{"describe":"范围内选择器","type":"HeroSelector"}};outRange->范围外->{"范围外选择器":{"describe":"范围外选择器","type":"HeroSelector"}};onRemove->监听结束
         * @param distance 范围
         * @param duration 持续时长
         */
        addDistanceListenBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, distance: number, duration: number): void;
        /**
         * 包含效果【矩形监听】
         * BUFF包装器元素
         * @param context
         * @param slotMap inRange->范围内->{"范围内选择器":{"describe":"范围内选择器","type":"HeroSelector"}};outRange->范围外->{"范围外选择器":{"describe":"范围外选择器","type":"HeroSelector"}};onRemove->监听结束
         * @param width 宽
         * @param height 高
         * @param duration 持续时长
         */
        addRectListenBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, width: number, height: number, duration: number): void;
        /**
         * 包含效果【能量监听】
         * BUFF包装器元素
         * @param context
         * @param slotMap lessThan->小于;moreThan->大于;equal->等于
         * @param compareValue 比较值
         * @param duration 持续时长
         */
        addPowerListenBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, compareValue: number, duration: number): void;
        /**
         * 包含效果【血量监听】
         * BUFF包装器元素
         * @param context
         * @param slotMap lessThan->小于;moreThan->大于;equal->等于
         * @param compareValue 比较值
         * @param duration 持续时长
         */
        addHpListenBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, compareValue: number, duration: number): void;
        /**
         * 包含效果【免疫持续掉血】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addImmuneBloodLossBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫中毒】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addImmunePoisoningBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【逃跑】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addRunawayBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【空Buff】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addBuffEffectDoNothing(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【延迟Buff】
         * BUFF包装器元素
         * @param slotMap onFinish->结束
         * @param duration 时长
         */
        addDelayBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, duration: number): void;
        /**
         * 包含效果【承伤英雄】
         * BUFF包装器元素
         * @param slotMap onFinish->结束
         * @param hero 承伤英雄
         * @param duration 时长
         */
        addAcceptInjuryBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, hero: Hero, duration: number): void;
        /**
         * 包含效果【施法中】
         * BUFF包装器元素
         * @param duration 时长
         */
        addConjuringBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【攻击距离】
         * BUFF包装器元素
         * @param attrValue 值
         * @param duration 时长
         */
        addAttackDistanceBuffEffect(context: logicchart.trigger.Context, attrValue: number, duration: number): void;
        /**
         * 包含效果【变身】
         * BUFF包装器元素
         * @param skin 皮肤
         * @param duration 时长
         */
        addTransformBuffEffect(context: logicchart.trigger.Context, skin: string, duration: number): void;
        /**
         * 包含效果【施法迅捷】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addSkillSpeedBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
    }
}
declare namespace rpgfight {
    type BuffEffectType = "unknown" | "空Buff" | "攻击增强(值)" | "攻击增强(百分比)" | "攻击降低(值)" | "攻击降低(百分比)" | "持续性范围伤害" | "友军攻击增益" | "吸血增强" | "伴随吸血效果" | "免疫伤害" | "免疫物理伤害" | "免疫魔法伤害" | "免疫特定职业的英雄伤害" | "可被敌方选中" | "可被我方选中" | "无法攻击" | "禁魔" | "反转阵营" | "无法闪避" | "无法移动" | "限制技能" | "魔法反伤" | "触发反馈" | "护盾" | "持续恢复生命" | "持续掉血" | "持续恢复能量" | "减伤" | "魔法减伤" | "物理减伤" | "易伤" | "物理易伤" | "魔法易伤" | "移动速度" | "防御" | "防御(传值)" | "生命上限" | "治疗效果" | "受攻击能量恢复速度" | "攻击速度" | "被治疗效果" | "输出伤害增加" | "输出伤害降低" | "免疫debuff" | "免疫正面buff" | "魔法减伤下降" | "命中提高(百分比)" | "命中下降(百分比)" | "命中提高(值)" | "命中下降(值)" | "中毒持续掉血" | "战斗数据累积反馈" | "暴击率" | "暴击伤害" | "免疫控制" | "能量恢复效率" | "受击能量恢复效率" | "隐身" | "恢复血量限制" | "假死" | "闪避(传值)" | "技能冷却时间" | "优先攻击" | "距离监听" | "矩形监听" | "眩晕状态" | "克制伤害系数" | "能量监听" | "血量监听" | "免疫持续掉血" | "免疫中毒" | "延迟Buff" | "逃跑" | "移动持续掉血" | "承伤英雄" | "施法中" | "免疫某些BUFF" | "攻击距离" | "变身" | "施法迅捷" | "持续修改闪避" | "持续修改命中" | "持续修改暴击率" | "持续修改暴击伤害";
    type BuffType = string;
    class HeroBuffHelper {
        static readonly inst: HeroBuffHelper;
        /**
         * buff模板
         */
        buffTemplates: {
            [key: string]: HeroBuff;
        };
        /**
         * buff效果模板
         */
        buffEffectTemplates: {
            [key: string]: IBuffEffect;
        };
        /**
         * 创建buff模板
         */
        createBuffTemplate(owner: GameObject, buffName: BuffType, buffId: string): HeroBuff;
        /**
         * 注册buff
         * @param buffName
         * @param buff
         */
        registerBuff(buffName: BuffType, buff: HeroBuff): void;
        isBuffExist(buffName: BuffType): boolean;
        registerBuffEffect(effectType: BuffEffectType, effect: IBuffEffect): void;
        /**
         * 生成buff实例
         */
        genBuff(context: logicchart.trigger.Context, owner: GameObject, theSkill: SkillData, buffName: BuffType, optionsList: any[], buffId?: string): HeroBuff;
        /**
         * 添加buff子效果
         */
        genBuffEffect(context: logicchart.trigger.Context, owner: GameObject, effectType: BuffEffectType, options: any): BuffEffect;
        protected _buffEffectGenerators: {
            [effectType: string]: () => IBuffEffect;
        };
        /**
         * 注册buffeffect生成函数，延迟生成buff模板
         * @param effectType
         * @param generator
         */
        registerBuffEffectGenerator(effectType: BuffEffectType, generator: () => IBuffEffect): void;
        /**
         * 通过buffeffect生成函数生成buff模板
         */
        registerAllBuffEffects(): void;
    }
}
declare namespace rpgfight {
    class HeroBuffUIHelper {
        /**
         * @ignore
         */
        buffDesignUIHelper: HeroBuffDesignUIHelper;
        /**
         * buff设计助手
         */
        protected buffHelper: HeroBuffHelper;
        protected _hero: Hero;
        constructor(hero: Hero, 
        /**
         * @ignore
         */
        buffDesignUIHelper: HeroBuffDesignUIHelper);
        /**
         * 英雄
         * @ignore
         */
        get hero(): Hero;
        protected _currentBuffTemplate?: HeroBuff;
        protected _currentBuffName?: string;
        /**
         * 是否存在某类buff
         * - 该对象是否存在【类别为Name】的BUFF
         * @param name BUFF名称
         */
        isOwnTheBuffOfType(context: logicchart.trigger.Context, name: string): boolean;
        /**
         * 是否存在有某id的BUFF
         * - 该对象是否存在该id的BUFF
         * @param name BUFF名称
         */
        isOwnBuff(context: logicchart.trigger.Context, buffId: string): boolean;
        /**
         * 是否存在有某id相同施法者的buff
         * @param buffId
         * @param sender 施法者
         */
        isOwnBuffByHero(context: logicchart.trigger.Context, buffId: string, sender: Hero): boolean;
        /**
         * 移除几层buff
         * @param buffId
         * @param count 层数
         */
        removeDuplicateBuffById(context: logicchart.trigger.Context, buffId: string, count: number): void;
        /**
         * 移除buff
         * @param context
         * @param buffId buffId
         */
        removeBuffById(context: logicchart.trigger.Context, buffId: string): void;
        /**
         * 重置buff持续时间
         */
        resetHourglass(context: logicchart.trigger.Context, buffId: string): void;
        /**
         * 是否有负面buff
         */
        isExistDebuff(context: logicchart.trigger.Context): boolean;
        /**
         * 添加【无敌】
         * @param context
         * @param duration 持续时长
         */
        addDisappearBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【放逐】
         * @param context
         * @param duration 持续时长
         */
        addExileBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【冰冻】
         * @param context
         * @param duration 持续时长
         */
        addFrozenBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【眩晕】
         * @param context
         * @param duration 持续时长
         */
        addDizzyBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【恐惧】
         * @param context
         * @param duration 持续时长
         */
        addFrightenedBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【睡眠】
         * @param context
         * @param slotMap ok->睡眠结束->{"fightDataAccumulated":{"describe":"累计数据","type":"HeroFightDataAccumulated"}}
         * @param duration 持续时长
         */
        addSleepBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, duration: number): void;
        /**
         * 添加【共享吸血】
         * x BUFF包装器元素
         * @param context
         * @param target 依赖目标
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addSubSuckBloodBuff(context: logicchart.trigger.Context, buffId: string, target: Hero, enhanceRate: number, duration: number): void;
        /**
         * 添加【加强攻击-百分比】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addAttackEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【加强攻击-值】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增加值
         * @param duration 持续时长
         */
        addAttackEnhanceBuff2(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【降低攻击-百分比】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addAttackWeakenBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【降低攻击-值】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 降低值
         * @param duration 持续时长
         */
        addAttackWeakenBuff2(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【魔法减伤下降】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 降低值
         * @param duration 持续时长
         */
        addMagicDefenseWeakenBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【命中提高(百分比)】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 提高倍率
         * @param duration 持续时长
         */
        addHitRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【命中下降(百分比)】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addHitRateWeakenBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【命中提高(值)】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 提高值
         * @param duration 持续时长
         */
        addHitValueEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【命中下降(值)】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addHitValueWeakenBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【克制伤害系数】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 值
         * @param duration 持续时长
         */
        addRestraintHurtRateBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【免疫伤害】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addInjuryFreeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫物理伤害】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addPhysicInjuryFreeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫魔法伤害】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addMagicInjuryFreeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫特定职业的英雄伤害】
         * @param context
         * @param buffId buffId
         * @param attrValue 1:力量 | 2:智力 | 3:敏捷
         * @param duration 持续时长
         */
        addInjuryFreeByCareerBuff(context: logicchart.trigger.Context, buffId: string, attrValue: HeroCareerType, duration: number): void;
        /**
         * 添加【免疫某些BUFF】
         * BUFF包装器元素
         * @param duration 时长
         * @param buffId buffId
         * @param buffIds BUFFID
         */
        addImmuneBuffsBuff(context: logicchart.trigger.Context, buffId: string, duration: number, ...buffIds: string[]): void;
        /**
         * 添加【禁魔】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addSkillUnUsableBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【隐身】
         * @param context
         * @param buffId buffId
         * @param attrValue 透明度
         * @param duration 持续时长
         */
        addInvisibleBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, duration: number): void;
        /**
         * 添加【恢复血量限制】
         * @param context
         * @param buffId buffId
         * @param attrValue 参数
         * @param duration 持续时长
         */
        addHealingLimitBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, duration: number): void;
        /**
         * 添加【不可被敌方选中】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addUnSelectableBuffByEnermy(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【眩晕状态】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addDizzyStateBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【无法攻击】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addUnAttackableBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【无法闪避】
         * @param context
         * @param buffId buffId
         * @param duration
         */
        addUnDodgeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【不可被我方选中】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addUnSelectableBuffByCompanion(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【持续性范围伤害】
         * @param context
         * @param buffId buffId
         * @param effectRate 攻击力转化倍率
         * @param duration 持续时长
         * @param interval 作用间隔
         */
        addPeriodlyHurtBuff(context: logicchart.trigger.Context, buffId: string, effectRate: number, duration: number, interval: number): void;
        /**
         * 添加【中毒】
         * @param context
         * @param buffId buffId
         * @param effectRate 扣血百分比（传小数）
         * @param duration 持续时长
         * @param interval 作用间隔
         */
        addPoisonedBuff(context: logicchart.trigger.Context, buffId: string, effectRate: number, duration: number, interval: number): void;
        /**
         * 添加【加强友军攻击】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addCompanionAttackEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【加强吸血】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 吸血等级
         * @param duration 持续时长
         */
        addSuckBloodLevelBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【免疫debuff】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addDebuffFreeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫正面buff】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addEnhanceBuffFreeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【输出伤害增加】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强倍率
         * @param duration 持续时长
         */
        addHarmGrowUpBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【输出伤害降低】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强倍率
         * @param duration 持续时长
         */
        addHarmCutDownBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【减伤】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addInjuryFreeRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【魔法减伤】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addExtraDefenseMagicHurtBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【物理减伤】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addExtraDefensePhysicalHurtBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【易伤】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryHardRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【易伤-物理】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryPhyicHardRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【易伤-魔法】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryMagicHardRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【闪避(传值)】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addDodgeEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【暴击率】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addCritRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【暴击伤害】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addCritHurtRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【移动速度】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addMoveSpeedEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【减移速】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addMoveSpeedWeakenBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【攻击速度】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addAttackSpeedEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【能量恢复效率】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addPowerChargeRateBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【受击能量恢复效率】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addPowerChargeRateWithHurtBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【防御-百分比】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addDefenseEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【防御-值】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addDefenseValueBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【生命上限】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addHpMaxEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【治疗效果】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addHealingEffectEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【被治疗效果】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addBeHealEffectEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【受攻击能量恢复速度】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addPowerIncreaseSpeedWithHurtBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【护盾】
         * @param context
         * @param buffId buffId
         * @param slotMap onfinish->护盾消失->$name;
         * @param attrValue 伤害吸收比例
         * @param duration 持续时长
         */
        addShieldBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, attrValue: number, duration: number): void;
        /**
         * 添加【持续修改命中】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyHitRateBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续修改闪避】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyDodgeRateBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续修改暴击率】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyCritRateBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续修改暴击伤害】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyCritHurtBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续恢复生命】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeHealingBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续掉血】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次掉血量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeHurtingBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【移动持续掉血】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次掉血量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addMoveBeHurtingBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续恢复能量】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeChargingEnergyBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【反转阵营】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addRevertBattleTeamBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【限制技能】
         * @param context
         * @param buffId buffId
         * @param skillId 技能id
         * @param duration 持续时长
         */
        addFetterSkillBuff(context: logicchart.trigger.Context, buffId: string, skillType: SkillTypeEnum, duration: number): void;
        /**
         * 添加【魔伤反甲】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         * @param enhanceRate 倍率
         * @param interval 最小触发间隔，填 0 则不限制
         */
        addMagicThornsBuff(context: logicchart.trigger.Context, buffId: string, duration: number, enhanceRate: number, interval: number): void;
        /**
         * 添加【触发反馈】
         * @param context
         * @param buffId buffId
         * @param slotMap ok->作用点触发->{"sourceHero":{"describe":"来源英雄","type":"Hero"},"triggerData":{"describe":"触发数据","type":"HeroTriggerData"}}
         * @param triggerEvent 触发事件
         * @param duration 持续时长
         * @param interval 触发最小间隔
         * @param custom 自定义数据
         */
        addHeroActioinTriggerBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, triggerEvent: HeroTriggerEventEnum, duration: number, interval: number, custom: number | boolean | string): void;
        /**
         * 添加【战斗数据累积反馈】
         * @param context
         * @param buffId buffId
         * @param slotMap ok->作用点触发->{"fightDataAccumulated":{"describe":"累计数据","type":"HeroFightDataAccumulated"}}
         * @param duration 持续时长
         */
        addHeroFightDataAccuBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, duration: number): void;
        /**
         * 添加【无法移动】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addUnMovableBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫控制】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addImmuneControlBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【假死】
         * @param context
         * @param buffId buffId
         * @param slotMap die->死亡触发->{"sourceHero":{"describe":"来源英雄","type":"Hero"}}
         * @param duration 持续时长
         */
        addShockBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, duration: number): void;
        /**
         * 添加【技能冷却时间】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addSkillIntervalCdBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【优先攻击】
         * @param context
         * @param buffId buffId
         * @param target 目标
         * @param duration 持续时长
         */
        addFirstAttackHeroBuff(context: logicchart.trigger.Context, buffId: string, target: Hero, duration: number): void;
        /**
         * 添加【距离监听】
         * @param context
         * @param buffId buffId
         * @param slotMap inRange->范围内->{"范围内选择器":{"describe":"范围内选择器","type":"HeroSelector"}};outRange->范围外->{"范围外选择器":{"describe":"范围外选择器","type":"HeroSelector"}};onRemove->监听结束
         * @param distance 范围
         * @param duration 持续时长
         */
        addDistanceListenBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, distance: number, duration: number): void;
        /**
         * 添加【矩形监听】
         * @param context
         * @param buffId buffId
         * @param slotMap inRange->范围内->{"范围内选择器":{"describe":"范围内选择器","type":"HeroSelector"}};outRange->范围外->{"范围外选择器":{"describe":"范围外选择器","type":"HeroSelector"}};onRemove->监听结束
         * @param width 宽
         * @param height 高
         * @param duration 持续时长
         */
        addRectListenBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, width: number, height: number, duration: number): void;
        /**
         * 添加【能量监听】
         * @param context
         * @param buffId buffId
         * @param slotMap lessThan->小于;moreThan->大于;equal->等于
         * @param compareValue 比较值
         * @param duration 持续时长
         */
        addPowerListenBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, compareValue: number, duration: number): void;
        /**
         * 添加【血量监听】
         * @param context
         * @param buffId buffId
         * @param slotMap lessThan->小于;moreThan->大于;equal->等于
         * @param compareValue 比较值
         * @param duration 持续时长
         */
        addHpListenBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, compareValue: number, duration: number): void;
        /**
         * 添加【免疫持续掉血】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addImmuneBloodLossBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫中毒】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addImmunePoisoningBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【逃跑】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addRunawayBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【空Buff】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addBuffDoNothing(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【延迟Buff】
         * @param slotMap onFinish->结束
         * @param buffId buffId
         * @param duration 时长
         */
        addDelayBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, duration: number): void;
        /**
         * 添加【承伤英雄】
         * @param slotMap onFinish->结束
         * @param buffId buffId
         * @param hero 承伤英雄
         * @param duration 时长
         */
        addAcceptInjuryBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, hero: Hero, duration: number): void;
        /**
         * 添加【施法中】
         * @param duration 时长
         * @param buffId buffId
         */
        addConjuringBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【攻击距离】
         * @param attrValue 值
         * @param buffId buffId
         * @param duration 时长
         */
        addAttackDistanceBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, duration: number): void;
        /**
         * 添加【变身】
         * BUFF包装器元素
         * @param skin 皮肤
         * @param buffId buffId
         * @param duration 时长
         */
        addTransformBuff(context: logicchart.trigger.Context, buffId: string, skin: string, duration: number): void;
        /**
         * 添加【施法迅捷】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addSkillSpeedBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
    }
}
declare namespace rpgfight {
    class HeroSelectorBuffDesignUIHelper {
        /**
         * buff设计助手
         */
        protected buffHelper: HeroBuffHelper;
        protected _heroSelector: HeroSelector;
        constructor(heroSelector: HeroSelector);
        get selectedTargetList(): Hero[];
        /**
         * 给buff添加子效果
         * @param effectType
         * @param options
         */
        createAndAddBuffEffect(context: logicchart.trigger.Context, effectType: BuffEffectType, options: any): void;
        /**
         * 添加【BUFF包装器】
         * 添加一个【BUFF名称为buffName】的自定义包装器
         * @ignore
         */
        finishDesignAndAttachBuff(context: logicchart.trigger.Context): void;
        /**
         * 创建【BUFF包装器】
         * 创建一个【BUFF名称为buffName】的包装器
         * @ignore
         * @param buffName buff代号
         */
        beginDesignBuff(context: logicchart.trigger.Context, buffName: string, buffId: string): void;
        /**
         * 移除buff
         * @param context
         * @param buffId buffId
         */
        removeBuffById(context: logicchart.trigger.Context, buffId: string): void;
        /**
         * 包含效果【共享吸血】
         * BUFF包装器元素
         * @param context
         * @param target 依赖目标
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addSubSuckBloodBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【加强攻击-百分比】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addAttackEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【加强攻击-值】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增加值
         * @param duration 持续时长
         */
        addAttackEnhanceBuffEffect2(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【降低攻击-百分比】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addAttackWeakenBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【降低攻击-值】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 降低值
         * @param duration 持续时长
         */
        addAttackWeakenBuffEffect2(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【魔法减伤下降】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 降低值
         * @param duration 持续时长
         */
        addMagicDefenseWeakenBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【命中提高(百分比)】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 提高倍率
         * @param duration 持续时长
         */
        addHitRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【命中下降(百分比)】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addHitRateWeakenBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【命中提高(值)】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 提高值
         * @param duration 持续时长
         */
        addHitValueEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【命中下降(值)】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addHitValueWeakenBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【克制伤害系数】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 值
         * @param duration 持续时长
         */
        addRestraintHurtRateBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【免疫伤害】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addInjuryFreeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫物理伤害】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addPhysicInjuryFreeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫魔法伤害】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addMagicInjuryFreeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫特定职业的英雄伤害】
         * BUFF包装器元素
         * @param context
         * @param attrValue 1:力量 | 2:智力 | 3:敏捷
         * @param duration 持续时长
         */
        addInjuryFreeByCareerBuffEffect(context: logicchart.trigger.Context, attrValue: HeroCareerType, duration: number): void;
        /**
         * 包含效果【免疫某些BUFF】
         * BUFF包装器元素
         * @param duration 时长
         * @param buffIds BUFFID
         */
        addImmuneBuffsBuffEffect(context: logicchart.trigger.Context, duration: number, ...buffIds: string[]): void;
        /**
         * 包含效果【禁魔】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addSkillUnUsableBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【隐身】
         * BUFF包装器元素
         * @param context
         * @param attrValue 透明度
         * @param duration 持续时长
         */
        addInvisibleBuffEffect(context: logicchart.trigger.Context, attrValue: number, duration: number): void;
        /**
         * 包含效果【恢复血量限制】
         * BUFF包装器元素
         * @param context
         * @param attrValue 参数
         * @param duration 持续时长
         */
        addHealingLimitBuffEffect(context: logicchart.trigger.Context, attrValue: number, duration: number): void;
        /**
         * 包含效果【不可被敌方选中】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addUnSelectableBuffEffectByEnermy(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【眩晕状态】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addDizzyStateBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【无法攻击】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addUnAttackableBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【无法闪避】
         * BUFF包装器元素
         * @param context
         * @param duration
         */
        addUnDodgeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【不可被我方选中】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addUnSelectableBuffEffectByCompanion(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【持续性范围伤害】
         * BUFF包装器元素
         * @param context
         * @param effectRate 攻击力转化倍率
         * @param duration 持续时长
         * @param interval 作用间隔
         */
        addPeriodlyHurtBuffEffect(context: logicchart.trigger.Context, effectRate: number, duration: number, interval: number): void;
        /**
         * 包含效果【中毒】
         * BUFF包装器元素
         * @param context
         * @param effectRate 扣血百分比（传小数）
         * @param duration 持续时长
         * @param interval 作用间隔
         */
        addPoisonedBuffEffect(context: logicchart.trigger.Context, effectRate: number, duration: number, interval: number): void;
        /**
         * 包含效果【加强友军攻击】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addCompanionAttackEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【加强吸血】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 吸血等级
         * @param duration 持续时长
         */
        addSuckBloodLevelBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【免疫debuff】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addDebuffFreeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫正面buff】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addEnhanceBuffFreeBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【输出伤害增加】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强倍率
         * @param duration 持续时长
         */
        addHarmGrowUpBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【输出伤害降低】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强倍率
         * @param duration 持续时长
         */
        addHarmCutDownBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【减伤】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addInjuryFreeRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【魔法减伤】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addExtraDefenseMagicHurtBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【物理减伤】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addExtraDefensePhysicalHurtBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【易伤】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryHardRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【易伤-物理】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryPhyicHardRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【易伤-魔法】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryMagicHardRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【闪避(传值)】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addDodgeEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【暴击率】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addCritRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【暴击伤害】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addCritHurtRateEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【移动速度】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addMoveSpeedEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【减移速】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addMoveSpeedWeakenBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【攻击速度】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addAttackSpeedEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【能量恢复效率】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addPowerChargeRateBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【受击能量恢复效率】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addPowerChargeRateWithHurtBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【防御-百分比】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addDefenseEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【防御-值】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addDefenseValueBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【生命上限】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addHpMaxEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【治疗效果】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addHealingEffectEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【被治疗效果】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addBeHealEffectEnhanceBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【受攻击能量恢复速度】
         * BUFF包装器元素
         * @param context
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addPowerIncreaseSpeedWithHurtBuffEffect(context: logicchart.trigger.Context, enhanceRate: number, duration: number): void;
        /**
         * 包含效果【护盾】
         * BUFF包装器元素
         * @param context
         * @param slotMap onfinish->护盾消失->$name;
         * @param attrValue 伤害吸收比例
         * @param duration 持续时长
         */
        addShieldBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, attrValue: number, duration: number): void;
        /**
         * 包含效果【持续修改命中】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyHitRateBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续修改闪避】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyDodgeRateBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续修改暴击率】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyCritRateBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续修改暴击伤害】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyCritHurtBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续恢复生命】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeHealingBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续掉血】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次掉血量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeHurtingBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【移动持续掉血】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次掉血量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addMoveBeHurtingBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【持续恢复能量】
         * BUFF包装器元素
         * @param context
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeChargingEnergyBuffEffect(context: logicchart.trigger.Context, attrValue: number, interval: number, duration: number): void;
        /**
         * 包含效果【反转阵营】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addRevertBattleTeamBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【限制技能】
         * BUFF包装器元素
         * @param context
         * @param skillId 技能id
         * @param duration 持续时长
         */
        addFetterSkillBuffEffect(context: logicchart.trigger.Context, skillType: SkillTypeEnum, duration: number): void;
        /**
         * 包含效果【魔伤反甲】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         * @param enhanceRate 倍率
         * @param interval 最小触发间隔，填 0 则不限制
         */
        addMagicThornsBuffEffect(context: logicchart.trigger.Context, duration: number, enhanceRate: number, interval: number): void;
        /**
         * 包含效果【触发反馈】
         * BUFF包装器元素
         * @param context
         * @param slotMap ok->作用点触发->{"sourceHero":{"describe":"来源英雄","type":"Hero"},"triggerData":{"describe":"触发数据","type":"HeroTriggerData"}}
         * @param triggerEvent 触发事件
         * @param duration 持续时长
         * @param interval 触发最小间隔
         * @param custom 自定义数据
         */
        addHeroActioinTriggerBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, triggerEvent: HeroTriggerEventEnum, duration: number, interval: number, custom: number | boolean | string): void;
        /**
         * 包含效果【战斗数据累积反馈】
         * BUFF包装器元素
         * @param context
         * @param slotMap ok->作用点触发->{"fightDataAccumulated":{"describe":"累计数据","type":"HeroFightDataAccumulated"}}
         * @param duration 持续时长
         */
        addHeroFightDataAccuBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, duration: number): void;
        /**
         * 包含效果【无法移动】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addUnMovableBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫控制】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addImmuneControlBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【假死】
         * BUFF包装器元素
         * @param context
         * @param slotMap die->死亡触发->{"sourceHero":{"describe":"来源英雄","type":"Hero"}}
         * @param duration 持续时长
         */
        addShockBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, duration: number): void;
        /**
         * 包含效果【技能冷却时间】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addSkillIntervalCdBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
        /**
         * 包含效果【优先攻击】
         * BUFF包装器元素
         * @param context
         * @param target 目标
         * @param duration 持续时长
         */
        addFirstAttackHeroBuffEffect(context: logicchart.trigger.Context, target: Hero, duration: number): void;
        /**
         * 包含效果【距离监听】
         * BUFF包装器元素
         * @param context
         * @param slotMap inRange->范围内->{"范围内选择器":{"describe":"范围内选择器","type":"HeroSelector"}};outRange->范围外->{"范围外选择器":{"describe":"范围外选择器","type":"HeroSelector"}};onRemove->监听结束
         * @param distance 范围
         * @param duration 持续时长
         */
        addDistanceListenBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, distance: number, duration: number): void;
        /**
         * 包含效果【矩形监听】
         * BUFF包装器元素
         * @param context
         * @param slotMap inRange->范围内->{"范围内选择器":{"describe":"范围内选择器","type":"HeroSelector"}};outRange->范围外->{"范围外选择器":{"describe":"范围外选择器","type":"HeroSelector"}};onRemove->监听结束
         * @param width 宽
         * @param height 高
         * @param duration 持续时长
         */
        addRectListenBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, width: number, height: number, duration: number): void;
        /**
         * 包含效果【能量监听】
         * BUFF包装器元素
         * @param context
         * @param slotMap lessThan->小于;moreThan->大于;equal->等于
         * @param compareValue 比较值
         * @param duration 持续时长
         */
        addPowerListenBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, compareValue: number, duration: number): void;
        /**
         * 包含效果【血量监听】
         * BUFF包装器元素
         * @param context
         * @param slotMap lessThan->小于;moreThan->大于;equal->等于
         * @param compareValue 比较值
         * @param duration 持续时长
         */
        addHpListenBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, compareValue: number, duration: number): void;
        /**
         * 包含效果【免疫持续掉血】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addImmuneBloodLossBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【免疫中毒】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addImmunePoisoningBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【逃跑】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addRunawayBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【空Buff】
         * BUFF包装器元素
         * @param context
         * @param duration 持续时长
         */
        addBuffEffectDoNothing(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【延迟Buff】
         * BUFF包装器元素
         * @param slotMap onFinish->结束
         * @param duration 时长
         */
        addDelayBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, duration: number): void;
        /**
         * 包含效果【承伤英雄】
         * BUFF包装器元素
         * @param slotMap onFinish->结束
         * @param hero 承伤英雄
         * @param duration 时长
         */
        addAcceptInjuryBuffEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, hero: Hero, duration: number): void;
        /**
         * 包含效果【施法中】
         * BUFF包装器元素
         * @param duration 时长
         */
        addConjuringBuffEffect(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 包含效果【攻击距离】
         * BUFF包装器元素
         * @param attrValue 值
         * @param duration 时长
         */
        addAttackDistanceBuffEffect(context: logicchart.trigger.Context, attrValue: number, duration: number): void;
        /**
         * 包含效果【变身】
         * BUFF包装器元素
         * @param skin 皮肤
         * @param duration 时长
         */
        addTransformBuffEffect(context: logicchart.trigger.Context, skin: string, duration: number): void;
        /**
         * 包含效果【施法迅捷】
         * BUFF包装器元素
         * @param context
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addSkillSpeedBuffEffect(context: logicchart.trigger.Context, enhanceValue: number, duration: number): void;
    }
}
declare namespace rpgfight {
    class HeroSelectorBuffUIHelper {
        /**
         * buff设计助手
         */
        protected buffHelper: HeroBuffHelper;
        protected _heroSelector: HeroSelector;
        constructor(heroSelector: HeroSelector);
        get selectedTargetList(): Hero[];
        /**
         * 移除buff
         * @param context
         * @param buffId buffId
         */
        removeBuffById(context: logicchart.trigger.Context, buffId: string): void;
        /**
         * 添加【无敌】
         * @param context
         * @param duration 持续时长
         */
        addDisappearBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【放逐】
         * @param context
         * @param duration 持续时长
         */
        addExileBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【冰冻】
         * @param context
         * @param duration 持续时长
         */
        addFrozenBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【眩晕】
         * @param context
         * @param duration 持续时长
         */
        addDizzyBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【恐惧】
         * @param context
         * @param duration 持续时长
         */
        addFrightenedBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【共享吸血】
         * @param context
         * @param buffId buffId
         * @param target 依赖目标
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addSubSuckBloodBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【加强攻击-百分比】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addAttackEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【加强攻击-值】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增加值
         * @param duration 持续时长
         */
        addAttackEnhanceBuff2(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【降低攻击-百分比】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addAttackWeakenBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【降低攻击-值】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 降低值
         * @param duration 持续时长
         */
        addAttackWeakenBuff2(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【魔法减伤下降】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 降低值
         * @param duration 持续时长
         */
        addMagicDefenseWeakenBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【命中提高(百分比)】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 提高倍率
         * @param duration 持续时长
         */
        addHitRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【命中下降(百分比)】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addHitRateWeakenBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【命中提高(值)】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 提高值
         * @param duration 持续时长
         */
        addHitValueEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【命中下降(值)】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 降低倍率
         * @param duration 持续时长
         */
        addHitValueWeakenBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【克制伤害系数】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 值
         * @param duration 持续时长
         */
        addRestraintHurtRateBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【免疫伤害】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addInjuryFreeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫物理伤害】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addPhysicInjuryFreeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫魔法伤害】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addMagicInjuryFreeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫特定职业的英雄伤害】
         * @param context
         * @param buffId buffId
         * @param attrValue 1:力量 | 2:智力 | 3:敏捷
         * @param duration 持续时长
         */
        addInjuryFreeByCareerBuff(context: logicchart.trigger.Context, buffId: string, attrValue: HeroCareerType, duration: number): void;
        /**
         * 添加【免疫某些BUFF】
         * BUFF包装器元素
         * @param duration 时长
         * @param buffId buffId
         * @param buffIds BUFFID
         */
        addImmuneBuffsBuff(context: logicchart.trigger.Context, buffId: string, duration: number, ...buffIds: string[]): void;
        /**
         * 添加【禁魔】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addSkillUnUsableBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【隐身】
         * @param context
         * @param buffId buffId
         * @param attrValue 透明度
         * @param duration 持续时长
         */
        addInvisibleBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, duration: number): void;
        /**
         * 添加【恢复血量限制】
         * @param context
         * @param buffId buffId
         * @param attrValue 参数
         * @param duration 持续时长
         */
        addHealingLimitBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, duration: number): void;
        /**
         * 添加【不可被敌方选中】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addUnSelectableBuffByEnermy(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【眩晕状态】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addDizzyStateBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【无法攻击】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addUnAttackableBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【无法闪避】
         * @param context
         * @param buffId buffId
         * @param duration
         */
        addUnDodgeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【不可被我方选中】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addUnSelectableBuffByCompanion(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【持续性范围伤害】
         * @param context
         * @param buffId buffId
         * @param effectRate 攻击力转化倍率
         * @param duration 持续时长
         * @param interval 作用间隔
         */
        addPeriodlyHurtBuff(context: logicchart.trigger.Context, buffId: string, effectRate: number, duration: number, interval: number): void;
        /**
         * 添加【中毒】
         * @param context
         * @param buffId buffId
         * @param effectRate 扣血百分比（传小数）
         * @param duration 持续时长
         * @param interval 作用间隔
         */
        addPoisonedBuff(context: logicchart.trigger.Context, buffId: string, effectRate: number, duration: number, interval: number): void;
        /**
         * 添加【加强友军攻击】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addCompanionAttackEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【加强吸血】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 吸血等级
         * @param duration 持续时长
         */
        addSuckBloodLevelBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【免疫debuff】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addDebuffFreeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫正面buff】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addEnhanceBuffFreeBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【输出伤害增加】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强倍率
         * @param duration 持续时长
         */
        addHarmGrowUpBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【输出伤害降低】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强倍率
         * @param duration 持续时长
         */
        addHarmCutDownBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【减伤】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addInjuryFreeRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【魔法减伤】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addExtraDefenseMagicHurtBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【物理减伤】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addExtraDefensePhysicalHurtBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【易伤】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryHardRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【易伤-物理】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryPhyicHardRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【易伤-魔法】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addInjuryMagicHardRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【闪避(传值)】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addDodgeEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【暴击率】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addCritRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【暴击伤害】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addCritHurtRateEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【移动速度】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addMoveSpeedEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【减移速】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addMoveSpeedWeakenBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【攻击速度】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addAttackSpeedEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【能量恢复效率】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addPowerChargeRateBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【受击能量恢复效率】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强数值
         * @param duration 持续时长
         */
        addPowerChargeRateWithHurtBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【防御-百分比】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addDefenseEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【防御-值】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addDefenseValueBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【生命上限】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addHpMaxEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【治疗效果】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addHealingEffectEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【被治疗效果】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addBeHealEffectEnhanceBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【受攻击能量恢复速度】
         * @param context
         * @param buffId buffId
         * @param enhanceRate 增强倍率
         * @param duration 持续时长
         */
        addPowerIncreaseSpeedWithHurtBuff(context: logicchart.trigger.Context, buffId: string, enhanceRate: number, duration: number): void;
        /**
         * 添加【护盾】
         * @param context
         * @param buffId buffId
         * @param slotMap onfinish->护盾消失->$name;
         * @param attrValue 伤害吸收比例
         * @param duration 持续时长
         */
        addShieldBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, attrValue: number, duration: number): void;
        /**
         * 添加【持续修改命中】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyHitRateBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续修改闪避】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyDodgeRateBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续修改暴击率】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyCritRateBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续修改暴击伤害】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addModifyCritHurtBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续恢复生命】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeHealingBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续掉血】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次掉血量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeHurtingBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【移动持续掉血】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次掉血量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addMoveBeHurtingBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【持续恢复能量】
         * @param context
         * @param buffId buffId
         * @param attrValue 每秒单次恢复量
         * @param interval 作用间隔
         * @param duration 持续时长
         */
        addBeChargingEnergyBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, interval: number, duration: number): void;
        /**
         * 添加【反转阵营】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addRevertBattleTeamBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【限制技能】
         * @param context
         * @param buffId buffId
         * @param skillId 技能id
         * @param duration 持续时长
         */
        addFetterSkillBuff(context: logicchart.trigger.Context, buffId: string, skillType: SkillTypeEnum, duration: number): void;
        /**
         * 添加【魔伤反甲】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         * @param enhanceRate 倍率
         * @param interval 最小触发间隔，填 0 则不限制
         */
        addMagicThornsBuff(context: logicchart.trigger.Context, buffId: string, duration: number, enhanceRate: number, interval: number): void;
        /**
         * 添加【触发反馈】
         * @param context
         * @param buffId buffId
         * @param slotMap ok->作用点触发->{"sourceHero":{"describe":"来源英雄","type":"Hero"},"triggerData":{"describe":"触发数据","type":"HeroTriggerData"}}
         * @param triggerEvent 触发事件
         * @param duration 持续时长
         * @param interval 触发最小间隔
         * @param custom 自定义数据
         */
        addHeroActioinTriggerBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, triggerEvent: HeroTriggerEventEnum, duration: number, interval: number, custom: number | boolean | string): void;
        /**
         * 添加【战斗数据累积反馈】
         * @param context
         * @param buffId buffId
         * @param slotMap ok->作用点触发->{"fightDataAccumulated":{"describe":"累计数据","type":"HeroFightDataAccumulated"}}
         * @param duration 持续时长
         */
        addHeroFightDataAccuBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, duration: number): void;
        /**
         * 添加【无法移动】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addUnMovableBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫控制】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addImmuneControlBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【假死】
         * @param context
         * @param buffId buffId
         * @param slotMap die->死亡触发->{"sourceHero":{"describe":"来源英雄","type":"Hero"}}
         * @param duration 持续时长
         */
        addShockBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, duration: number): void;
        /**
         * 添加【技能冷却时间】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addSkillIntervalCdBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
        /**
         * 添加【优先攻击】
         * @param context
         * @param buffId buffId
         * @param target 目标
         * @param duration 持续时长
         */
        addFirstAttackHeroBuff(context: logicchart.trigger.Context, buffId: string, target: Hero, duration: number): void;
        /**
         * 添加【距离监听】
         * @param context
         * @param buffId buffId
         * @param slotMap inRange->范围内->{"范围内选择器":{"describe":"范围内选择器","type":"HeroSelector"}};outRange->范围外->{"范围外选择器":{"describe":"范围外选择器","type":"HeroSelector"}};onRemove->监听结束
         * @param distance 范围
         * @param duration 持续时长
         */
        addDistanceListenBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, distance: number, duration: number): void;
        /**
         * 添加【矩形监听】
         * @param context
         * @param buffId buffId
         * @param slotMap inRange->范围内->{"范围内选择器":{"describe":"范围内选择器","type":"HeroSelector"}};outRange->范围外->{"范围外选择器":{"describe":"范围外选择器","type":"HeroSelector"}};onRemove->监听结束
         * @param width 宽
         * @param height 高
         * @param duration 持续时长
         */
        addRectListenBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, width: number, height: number, duration: number): void;
        /**
         * 添加【能量监听】
         * @param context
         * @param buffId buffId
         * @param slotMap lessThan->小于;moreThan->大于;equal->等于
         * @param compareValue 比较值
         * @param duration 持续时长
         */
        addPowerListenBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, compareValue: number, duration: number): void;
        /**
         * 添加【血量监听】
         * @param context
         * @param buffId buffId
         * @param slotMap lessThan->小于;moreThan->大于;equal->等于
         * @param compareValue 比较值
         * @param duration 持续时长
         */
        addHpListenBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, compareValue: number, duration: number): void;
        /**
         * 添加【免疫持续掉血】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addImmuneBloodLossBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【免疫中毒】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addImmunePoisoningBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【逃跑】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addRunawayBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【空Buff】
         * @param context
         * @param buffId buffId
         * @param duration 持续时长
         */
        addBuffDoNothing(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【延迟Buff】
         * @param slotMap onFinish->结束
         * @param buffId buffId
         * @param duration 时长
         */
        addDelayBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, duration: number): void;
        /**
         * 添加【承伤英雄】
         * @param slotMap onFinish->结束
         * @param buffId buffId
         * @param hero 承伤英雄
         * @param duration 时长
         */
        addAcceptInjuryBuff(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, buffId: string, hero: Hero, duration: number): void;
        /**
         * 添加【施法中】
         * @param duration 时长
         * @param buffId buffId
         */
        addConjuringBuff(context: logicchart.trigger.Context, buffId: string, duration: number): void;
        /**
         * 添加【攻击距离】
         * @param attrValue 值
         * @param buffId buffId
         * @param duration 时长
         */
        addAttackDistanceBuff(context: logicchart.trigger.Context, buffId: string, attrValue: number, duration: number): void;
        /**
         * 添加【变身】
         * BUFF包装器元素
         * @param skin 皮肤
         * @param buffId buffId
         * @param duration 时长
         */
        addTransformBuff(context: logicchart.trigger.Context, buffId: string, skin: string, duration: number): void;
        /**
         * 添加【施法迅捷】
         * @param context
         * @param buffId buffId
         * @param enhanceValue 增强值
         * @param duration 持续时长
         */
        addSkillSpeedBuff(context: logicchart.trigger.Context, buffId: string, enhanceValue: number, duration: number): void;
    }
}
declare namespace rpgfight {
    function cloneObject<T extends Object>(target: T, source: T): T;
    function isInstanceOf(a: any, b: string): boolean;
    function findEle<T>(ls: T[], fn: (ele: T) => boolean): T | undefined;
    function existsEle<T>(ls: T[], fn: (ele: T) => boolean): boolean;
}
declare namespace rpgfight {
    interface AttrBuffEffectOptions {
        /**
         * 属性增强倍率
         */
        enhanceRate?: number;
        /**
         * 属性增强数值(暂时无用)
         */
        enhanceValue?: number;
        /**
         * 作用时长
         */
        duration?: number;
        /**
         * 结束回调
         */
        onRemove?: (params: {
            source: IBuffBase;
        }) => void;
    }
    /**
     * 属性数值修饰buff
     */
    class HeroAttrBuffEffect extends BuffEffect {
        owner: Hero;
        options: AttrBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: AttrBuffEffectOptions);
        attrNameEnhanced: string;
        protected onApply(target: HeroData, options: BuffApplyOptions): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroSelfTimeLimitBuffEffectOptions {
        /**
         * 作用时长
         */
        duration?: number;
        /**
         * 结束回调
         */
        onRemove?: (params: {
            source: IBuffBase;
        }) => void;
    }
    /**
     * 限制时长
     */
    class HeroSelfTimeLimitBuffEffect extends BuffEffect {
        options: HeroSelfTimeLimitBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroSelfTimeLimitBuffEffectOptions);
        onRemove(): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroAcceptInjuryBuffEffectOptions {
        /**
         * 承伤英雄
         */
        hero?: Hero;
        /**
         * 作用时长
         */
        duration?: number;
        /**
         * 结束回调
         */
        onRemove?: (params: {
            source: IBuffBase;
        }) => void;
    }
    /**
     * 承伤英雄
     */
    class HeroAcceptInjuryBuffEffect extends HeroSelfTimeLimitBuffEffect {
        options: HeroAcceptInjuryBuffEffectOptions;
        constructor(runner: Runner, owner: Hero, options: HeroAcceptInjuryBuffEffectOptions);
        onAdd(): void;
        onRemove(): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroActioinTriggerBuffEffectOptions {
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 最小作用间隔
         */
        interval: number;
        triggerEvent: HeroTriggerEventEnum;
        /**
         * 作用作用回调
         */
        onEffectCallback?: (params: {
            source: IBuffBase;
            value: string | number;
            who: Hero;
        }) => void;
    }
    /**
     * 英雄事件触发反馈buff
     */
    class HeroActioinTriggerBuffEffect extends BuffEffect {
        owner: Hero;
        options: HeroActioinTriggerBuffEffectOptions;
        ctype: string;
        static HeroTriggerEvents: string[];
        protected _event: string;
        protected _handler: any;
        constructor(runner: Runner, owner: Hero, options: HeroActioinTriggerBuffEffectOptions);
        onRemove(): void;
        resetHourglass(): void;
        triggerInterval: number;
        timeAcc: number;
        update(dt: number): void;
        protected onApply(target: HeroData, options: BuffApplyOptions): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroAttackDistanceBuffEffectOptions {
        /**
         * 属性值
         */
        attrValue: number;
        /**
         * 作用时长
         */
        duration?: number;
    }
    /**
     * 属性数值修饰buff
     */
    class HeroAttachDistanceBuffEffect extends HeroSelfTimeLimitBuffEffect {
        owner: Hero;
        options: HeroShieldBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroShieldBuffEffectOptions);
        onAdd(): void;
        onRemove(): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    /**
     * 通过友军数量影响属性
     */
    class HeroAttrBuffEffectByFriends extends HeroAttrBuffEffect {
        options: AttrBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: AttrBuffEffectOptions);
        protected onApply(target: HeroData, options: BuffApplyOptions): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    let useSafeProperty: boolean;
    function SafeNumber(): (target: any, propertyName: string) => void;
    function SafeBoolean(): (target: any, propertyName: string) => void;
}
declare namespace rpgfight {
    /**
     * 英雄类型
     */
    enum HeroType {
        /**英雄 */
        Hero = 0,
        /**召唤物 */
        Summoned = 1,
        /**小怪 */
        Monster = 2,
        /**Boss */
        Boss = 3
    }
    /**
     * 英雄职业
     */
    enum HeroCareerType {
        /**
         * 不生效
         */
        None = -1,
        /**
         * 任意
         */
        Any = 0,
        /**
         * 力量
         */
        strength = 1,
        /**
         * 智力
         */
        intelligence = 2,
        /**
         * 敏捷
         */
        agility = 3
    }
    /**
     * 英雄种族
     */
    enum HeroFactionType {
        /**
         * 武装
         */
        arm = 1,
        /**
         * 机械
         */
        machine = 2,
        /**
         * 变种
         */
        variant = 3,
        /**
         * 僵尸
         */
        zombie = 4,
        /**
         * 超能
         */
        super = 5,
        /**
         * 毁灭
         */
        ruin = 6
    }
    class HeroConfig {
        /**
         * 英雄类别名称
         * @ignore
         */
        heroName: string;
        /**
         * 英雄对象id
         * - 改对象id来自外部，只能用于返还给外部使用，战斗内不能用
         * @ignore
         */
        heroId: string;
        /**
         * 英雄类型id
         * @ignore
         */
        heroConfigId: string;
        /**
         * 英雄类型
         * @ignore
         */
        heroType: HeroType;
        /**
         * 生命值
         */
        hp: number;
        /**
         * 最大生命
         */
        hpMax: number;
        /**
         * 能量
         */
        power: number;
        /**
         * 最大能量
         * @ignore
         */
        powerMax: number;
        /**
         * 攻击力
         */
        attack: number;
        /**
         * 防御力
         */
        defense: number;
        /**
         * 暴击率
         */
        critRate: number;
        /**
         * 暴击伤害
         */
        critHurt: number;
        /**
         * 命中
         */
        hitRate: number;
        /**
         * 闪避
         */
        dodgeRate: number;
        /**
         * 移动速度
         */
        moveSpeed: number;
        /**
         * 回血 战斗中每秒自动恢复的生命固定数值
         */
        hpHealingSpeed: number;
        /**
         * 额外减少受到的魔法伤害
         */
        extraDefenseMagicHurt: number;
        /**
         * 额外减少受到的物理伤害
         */
        extraDefensePhysicalHurt: number;
        /**
         * 吸血等级
         * - 给敌人造成伤害时，根据伤害数值百分比恢复的血量
         */
        suckBloodLv: number;
        /**
         * 等级
         */
        level: number;
        /**
         * 品阶
         */
        rank: number;
        /**
         * 英雄所使用的皮肤
         */
        skin: string;
        /**
         * 英雄远程普攻道具出手位置 X
         */
        normalAttackStartPositionX: number;
        /**
         * 英雄远程普攻道具出手位置 Y
         */
        normalAttackStartPositionY: number;
        /**
         * 英雄受击位置 X
         */
        normalOnHitPositionX: number;
        /**
         * 英雄受击位置 Y
         */
        normalOnHitPositionY: number;
        /**
         * 初始站位
         */
        battleInitPosition?: ml.Point;
        /**
         * 出场战位
         * - 0 表示没有战位
         */
        battleStation: number;
        /**
         * 英雄的缩放值
         */
        scale: number;
        /**
         * 属于哪一方
         */
        battleTeam: BattleTeam;
        /**
         * 进场动画的时间，0表示没有进场动画
         */
        enterAnimTime: number;
        /**
         * 进场动画的播放位置
         */
        enterAnimPos: EnterAnimPos;
        /**
         * 英雄之间最小间距
         * - 默认不用传，采用统一固定值
         */
        nearestDistance: number;
        /**
         * 英雄碰撞包围盒宽度
         */
        width: number;
        /**
         * 英雄碰撞包围盒高度
         */
        height: number;
        /**
         * 种族
         */
        faction: HeroFactionType;
        /**
         * 职业
        * - 1：力量
        * - 2：智力
        * - 3：敏捷
         */
        career: HeroCareerType;
        /**
         * 能量每秒恢复速度
         */
        powerChargeSpeedNormal: number;
        /**
         * 受击能量恢复速度
         * @ignore
         */
        powerChargeSpeedWithHurt: number;
        /**
         * 攻击出手恢复能量
         */
        powerChargeSpeedWithUsingSkill: number;
        /**
         * 回能系数
         */
        powerSpeedupRate: number;
        /**
         * 普攻是否可用
         * - 默认不用传，采用统一固定值
         * @ignore
         */
        isNormalAttackUsable: boolean;
        /**
         * 击杀恢复能量
         * - 默认不用传，采用统一固定值
         */
        powerChargeSpeedWithKilling: number;
        /**
         * 战斗力
         * @ignore
         */
        fightPower: number;
        /**
         * 技能伤害
         * @ignore
         */
        skillHarm: number;
        /**
         * 施法迅捷
         * @ignore
         */
        skillSpeed: number;
        /**
         * 专属技能等级
         */
        exclusiveLevel: number;
        /**
         * 治疗能力
         */
        healCap: number;
        /**
         * 抗爆率
         */
        deCri: number;
        /**
         * 伤害增加
         */
        incHarm: number;
        /**
         * 神器主动技能增伤
         */
        incArtifactHarm: number;
        /**
         * 神器主动技能减伤
         */
        decArtifactHarm: number;
        /**
         * 神器主动技能暴击率
         */
        criPctArtifact: number;
        /**
         * 神器主动技能暴击伤害
         */
        criAtkArtifact: number;
        /**
         * 阵营克制
         */
        factionRestrain: number;
        /**
         * 普通攻击技能
         */
        attackSkill?: SkillConfig;
        /**
         * 技能列表，按优先级排序
         */
        skillList?: SkillConfig[];
        constructor(attackSkill?: SkillConfig, skillList?: SkillConfig[]);
        /**
         * 根据config创建英雄的data
         * @param runner
         */
        createHeroData(runner: Runner): HeroData;
        clone(): HeroConfig;
    }
}
declare namespace rpgfight {
    interface HeroAttrSetBuffEffectOptions {
        /**
         * 属性增强倍率
         */
        attrValue: number | string | boolean;
        /**
         * 作用时长
         */
        duration?: number;
    }
    /**
     * 属性数值修饰buff
     */
    class HeroAttrSetBuffEffect extends BuffEffect {
        owner: Hero;
        options: HeroAttrSetBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroAttrSetBuffEffectOptions);
        attrNameToSet: string;
        protected onApply(target: HeroData, options: BuffApplyOptions): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface PeriodlyBuffEffectOptions {
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用间隔
         */
        interval: number;
    }
    /**
     * 周期性buff
     */
    class PeriodlyApplyBuffEffect extends BuffEffect {
        options: PeriodlyBuffEffectOptions;
        ctype: string;
        protected _timer: IntervalIdInfo | undefined;
        constructor(runner: Runner, owner: GameObject, options: PeriodlyBuffEffectOptions);
        update(dt: number): void;
        onAdd(): void;
        onRemove(): void;
        protected _isValidFor(target: GameObject, options: BuffApplyOptions): boolean;
        /**
        * 每个间隔针对每个对象作用
        * @param objs
        */
        protected updatePeriodlyForPerTarget(obj: GameObject): void;
        /**
         * 每个间隔针对对象列表作用
         * @param objs
         */
        protected updatePeriodlyForAllTargets(objs: GameObject[]): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): PeriodlyApplyBuffEffect;
    }
}
declare namespace rpgfight {
    interface BeChargingEnergyBuffEffectOptions {
        /**
         * 属性增强数值(暂时无用)
         */
        attrValue: number;
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用间隔
         */
        interval: number;
    }
    /**
     * 英雄持续恢复能量
     */
    class BeChargingEnergyBuffEffect extends PeriodlyApplyBuffEffect {
        owner: Hero;
        options: BeChargingEnergyBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: BeChargingEnergyBuffEffectOptions);
        /**
        * 每帧针对每个对象作用
        * @param objs
        */
        protected updatePeriodlyForPerTarget(obj: Hero): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroBeHealingBuffEffectOptions {
        /**
         * 属性增强数值(暂时无用)
         */
        attrValue: number;
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用间隔
         */
        interval: number;
    }
    /**
     * 英雄持续恢复生命
     */
    class HeroBeHealingBuffEffect extends PeriodlyApplyBuffEffect {
        owner: Hero;
        options: HeroBeHealingBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroBeHealingBuffEffectOptions);
        /**
        * 每帧针对每个对象作用
        * @param objs
        */
        protected updatePeriodlyForPerTarget(obj: Hero): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroBeHurtingBuffEffectOptions {
        /**
         * 属性增强数值(暂时无用)
         */
        attrValue: number;
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用间隔
         */
        interval: number;
    }
    /**
     * 英雄持续掉血
     */
    class HeroBeHurtingBuffEffect extends PeriodlyApplyBuffEffect {
        owner: Hero;
        options: HeroBeHurtingBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroBeHurtingBuffEffectOptions);
        protected _isValidFor(target: GameObject, options: BuffApplyOptions): boolean;
        /**
        * 每帧针对每个对象作用
        * @param objs
        */
        protected updatePeriodlyForPerTarget(obj: Hero): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
    class HeroMoveBeHurtingBuffEffect extends HeroBeHurtingBuffEffect {
        owner: Hero;
        options: HeroBeHurtingBuffEffectOptions;
        ctype: string;
        ownerPosition: ml.Point;
        lastApplyTimestamp: number;
        constructor(runner: Runner, owner: Hero, options: HeroBeHurtingBuffEffectOptions);
        onAdd(): void;
        protected updatePerFrameForPerTarget(obj: Hero): void;
        /**
        * 每帧针对每个对象作用
        * @param objs
        */
        protected updatePeriodlyForPerTarget(obj: Hero): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroDebuffFreeBuffEffectOptions {
        /**
         * 作用时长
         */
        duration?: number;
    }
    /**
     * 免疫debuff
     */
    class HeroDebuffFreeBuffEffect extends BuffEffect {
        owner: Hero;
        options: HeroDebuffFreeBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroDebuffFreeBuffEffectOptions);
        dealBuffRelation(buff: IBuffBase): boolean;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroDistanceListenBuffEffectOptions {
        /**
         * 距离
         */
        distance: number;
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用间隔
         */
        interval: number;
        /**
         * 范围内
         */
        inRange?: (source: IBuffBase, heroes: Hero[]) => void;
        /**
         * 范围外
         */
        outRange?: (source: IBuffBase, heroes: Hero[]) => void;
        /**
         * 移除
         */
        onRemove?: (source: IBuffBase) => void;
    }
    /**
     * 距离监听
     */
    class HeroDistanceListenBuffEffect extends PeriodlyApplyBuffEffect {
        owner: Hero;
        options: HeroDistanceListenBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroDistanceListenBuffEffectOptions);
        onRemove(): void;
        /**
        * 每帧针对每个对象作用
        * @param objs
        */
        protected updatePeriodlyForPerTarget(obj: Hero): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    /**
     * 眩晕buff
     */
    class HeroDizzyBuffEffect extends HeroSelfTimeLimitBuffEffect {
        owner: Hero;
        options: HeroSelfTimeLimitBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroSelfTimeLimitBuffEffectOptions);
        onAdd(): void;
        onRemove(): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroEnhanceBuffFreeBuffEffectOptions {
        /**
         * 作用时长
         */
        duration?: number;
    }
    /**
     * 免疫正面buff
     */
    class HeroEnhanceBuffFreeBuffEffect extends BuffEffect {
        owner: Hero;
        options: HeroEnhanceBuffFreeBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroEnhanceBuffFreeBuffEffectOptions);
        dealBuffRelation(buff: IBuffBase): boolean;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroFetterSkillBuffEffectOptions {
        /**
         * 技能id
         */
        skillType: SkillTypeEnum;
        /**
         * 作用时长
         */
        duration?: number;
    }
    /**
     * 限制技能/沉默技能
     */
    class HeroFetterSkillBuffEffect extends BuffEffect {
        owner: Hero;
        options: HeroFetterSkillBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroFetterSkillBuffEffectOptions);
        protected onApply(target: HeroData, options: BuffApplyOptions): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    /**
     * 累计数据项
     */
    class HeroFightDataAccumulated {
        /**
         * 受损血量
         */
        hurtHpAccumulated: number;
        /**
         * 使别人受伤的伤害
        */
        injuryOtherAccumulated: number;
    }
    interface HeroFightDataAccuBuffEffectOptions {
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用作用回调
         */
        onEffectCallback?: (params: {
            source: IBuffBase;
            fightData: HeroFightDataAccumulated;
        }) => void;
    }
    /**
     * 英雄战斗累计数据反馈
     */
    class HeroFightDataAccuBuffEffect extends BuffEffect {
        owner: Hero;
        options: HeroFightDataAccuBuffEffectOptions;
        ctype: string;
        fightData: HeroFightDataAccumulated;
        constructor(runner: Runner, owner: Hero, options: HeroFightDataAccuBuffEffectOptions);
        resetHourglass(): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): HeroFightDataAccuBuffEffect;
    }
}
declare namespace rpgfight {
    interface HeroFirstAttackBuffEffectOptions {
        /**
         * 目标
         */
        target?: Hero;
        /**
         * 作用时长
         */
        duration?: number;
    }
    /**
     * 属性数值修饰buff
     */
    class HeroFirstAttackBuffEffect extends HeroSelfTimeLimitBuffEffect {
        owner: Hero;
        options: HeroFirstAttackBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroFirstAttackBuffEffectOptions);
        onAdd(): void;
        onRemove(): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroHpMaxBuffEffectOptions {
        /**
         * 属性值
         */
        enhanceRate: number;
        /**
         * 作用时长
         */
        duration?: number;
    }
    /**
     * 属性数值修饰buff
     */
    class HeroHpMaxBuffEffect extends HeroSelfTimeLimitBuffEffect {
        owner: Hero;
        options: HeroHpMaxBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroHpMaxBuffEffectOptions);
        protected onApply(target: HeroData, options: BuffApplyOptions): void;
        get isValid(): boolean;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroImmuneBuffsBuffEffectOptions {
        /**
         * BuffId
         */
        buffIds: string[];
        /**
         * 作用时长
         */
        duration?: number;
    }
    /**
     * 属性数值修饰buff
     */
    class HeroImmuneBuffsBuffEffect extends HeroSelfTimeLimitBuffEffect {
        owner: Hero;
        options: HeroImmuneBuffsBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroImmuneBuffsBuffEffectOptions);
        onAdd(): void;
        onRemove(): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    /**
     * 免疫控制
     */
    class HeroImmuneControlBuffEffect extends HeroAttrSetBuffEffect {
        ctype: string;
        protected static relationBuffsMap: {
            "无法移动": boolean;
            "无法攻击": boolean;
            "反转阵营": boolean;
            "限制技能": boolean;
            "禁魔": boolean;
        };
        dealBuffRelation(buff: IBuffBase): boolean;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroMagicThornsBuffEffectOptions {
        /**
         * 技能id
         */
        enhanceRate: number;
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用间隔
         */
        interval: number;
    }
    /**
     * 魔法反伤
     * - 荆棘护盾
     */
    class HeroMagicThornsBuffEffect extends BuffEffect {
        owner: Hero;
        options: HeroMagicThornsBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroMagicThornsBuffEffectOptions);
        resetHourglass(): void;
        triggerInterval: number;
        timeAcc: number;
        update(dt: number): void;
        protected onApply(target: HeroData, options: BuffApplyOptions): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroModifyPropertyBuffEffectOptions {
        /**
         * 属性增强数值
         */
        attrValue: number;
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用间隔
         */
        interval: number;
    }
    /**
     * 英雄持续掉血
     */
    class HeroModifyPropertyBuffEffect extends PeriodlyApplyBuffEffect {
        owner: Hero;
        options: HeroModifyPropertyBuffEffectOptions;
        ctype: string;
        attrNameToSet: string;
        constructor(runner: Runner, owner: Hero, options: HeroModifyPropertyBuffEffectOptions);
        /**
        * 每帧针对每个对象作用
        * @param objs
        */
        protected updatePeriodlyForPerTarget(obj: Hero): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroPoisonedBuffEffectOptions {
        /**
         * 作用率
         */
        effectRate: number;
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用间隔
         */
        interval: number;
    }
    /**
     * 中毒
     */
    class HeroPoisonedBuffEffect extends PeriodlyApplyBuffEffect {
        owner: Hero;
        options: HeroPoisonedBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroPoisonedBuffEffectOptions);
        protected _isValidFor(target: GameObject, options: BuffApplyOptions): boolean;
        /**
        * 每个间隔针对每个对象作用
        * - 如果目标血量足够，那么按照百分比直降减血
        * - 如果目标血量不足，那么扣到剩一点血，不致死
        * @param obj
        */
        protected updatePeriodlyForPerTarget(obj: Hero): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): HeroPoisonedBuffEffect;
    }
}
declare namespace rpgfight {
    interface HeroPropertyListenBuffEffectOptions {
        /**
         * 属性数值
         */
        propertyValue?: (hero: Hero) => number;
        /**
         * 比较数值
         */
        compareValue: number;
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用间隔
         */
        interval: number;
        /**
         * 小于
         */
        lessThan?: (source: IBuffBase) => void;
        /**
         * 大于
         */
        moreThan?: (source: IBuffBase) => void;
        /**
         * 等于
         */
        equal?: (source: IBuffBase) => void;
    }
    /**
     * 距离监听
     */
    class HeroPropertyListenBuffEffect extends PeriodlyApplyBuffEffect {
        owner: Hero;
        options: HeroPropertyListenBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroPropertyListenBuffEffectOptions);
        /**
        * 每帧针对每个对象作用
        * @param objs
        */
        protected updatePeriodlyForPerTarget(obj: Hero): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroRectListenBuffEffectOptions {
        /**
         * 宽
         */
        width: number;
        /**
         * 高
         */
        height: number;
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用间隔
         */
        interval: number;
        /**
         * 范围内
         */
        inRange?: (source: IBuffBase, heroes: Hero[]) => void;
        /**
         * 范围外
         */
        outRange?: (source: IBuffBase, heroes: Hero[]) => void;
        /**
         * 移除
         */
        onRemove?: (source: IBuffBase) => void;
    }
    /**
     * 距离监听
     */
    class HeroRectListenBuffEffect extends PeriodlyApplyBuffEffect {
        owner: Hero;
        options: HeroRectListenBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroRectListenBuffEffectOptions);
        onRemove(): void;
        /**
        * 每帧针对每个对象作用
        * @param objs
        */
        protected updatePeriodlyForPerTarget(obj: Hero): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroRevertBattleTeamBuffEffectOptions {
        /**
         * 作用时长
         */
        duration?: number;
    }
    /**
     * 反转阵营
     */
    class HeroRevertBattleTeamBuffEffect extends BuffEffect {
        owner: Hero;
        options: HeroRevertBattleTeamBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroRevertBattleTeamBuffEffectOptions);
        onAdd(): void;
        onRemove(): void;
        protected onApply(target: HeroData, options: BuffApplyOptions): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroRunawayBuffEffectOptions {
        /**
         * 作用时长
         */
        duration?: number;
        /**
         * 结束回调
         */
        onRemove?: (params: {
            source: IBuffBase;
        }) => void;
    }
    /**
     * 属性数值修饰buff
     */
    class HeroRunawayBuffEffect extends HeroSelfTimeLimitBuffEffect {
        owner: Hero;
        options: HeroRunawayBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroRunawayBuffEffectOptions);
        onAdd(): void;
        onRemove(): void;
        update(dt: number): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    /**
     * 限制时长，并且只对英雄自身作用的属性修饰buff
     */
    class HeroSelfTimeLimitAttrBuffEffect extends HeroAttrBuffEffect {
        options: AttrBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: AttrBuffEffectOptions);
        onRemove(): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroShieldBuffEffectOptions {
        /**
         * 属性值
         */
        attrValue: number;
        /**
         * 作用时长
         */
        duration?: number;
        /**
         * 结束回调
         */
        onRemove?: (params: {
            source: IBuffBase;
        }) => void;
    }
    /**
     * 属性数值修饰buff
     */
    class HeroShieldBuffEffect extends HeroSelfTimeLimitBuffEffect {
        owner: Hero;
        options: HeroShieldBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroShieldBuffEffectOptions);
        onAdd(): void;
        onRemove(): void;
        get isValid(): boolean;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroShockBuffEffectOptions {
        /**
         * 死亡触发
         */
        dieCallback?: (owner: Hero, source: IBuffBase) => void;
        /**
         * 作用时长
         */
        duration: number;
    }
    /**
     * 属性数值修饰buff
     */
    class HeroShockBuffEffect extends HeroSelfTimeLimitBuffEffect {
        owner: Hero;
        options: HeroShockBuffEffectOptions;
        ctype: string;
        protected _handler: logicchart.statetree.EventHandler | undefined;
        protected _options: HeroShockBuffEffectOptions | undefined;
        constructor(runner: Runner, owner: Hero, options: HeroShockBuffEffectOptions);
        onAdd(): void;
        onRemove(): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroSubSuckBloodBuffEffectOptions {
        /**
         * 属性增强倍率
         */
        enhanceRate: number;
        /**
         * 作用时长
         */
        duration?: number;
        /**
         * 伴随吸血对象
         */
        followHero?: Hero;
    }
    /**
     * 英雄伴随吸血
     * - 当友军吸血时，自己会随着友军恢复一定程度的血量
     */
    class HeroSubSuckBloodBuffEffect extends BuffEffect {
        owner: Hero;
        options: HeroSubSuckBloodBuffEffectOptions;
        ctype: string;
        /**
         * 伴随吸血对象
         */
        followHero?: Hero;
        constructor(runner: Runner, owner: Hero, options: HeroSubSuckBloodBuffEffectOptions);
        update(dt: number): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface HeroTransformBuffEffectOptions {
        /**
         * 皮肤
         */
        skin: string;
        /**
         * 作用时长
         */
        duration?: number;
    }
    class HeroTransformBuffEffect extends HeroSelfTimeLimitBuffEffect {
        owner: Hero;
        options: HeroTransformBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: HeroTransformBuffEffectOptions);
        onAdd(): void;
        onRemove(): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    interface IntervalHurtBuffEffectOptions {
        effectRate: number;
        /**
         * 作用时长
         */
        duration: number;
        /**
         * 作用间隔
         */
        interval: number;
    }
    /**
     * 定时伤害buff
     */
    class PeriodlyHurtBuffEffect extends PeriodlyApplyBuffEffect {
        owner: Hero;
        options: IntervalHurtBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: IntervalHurtBuffEffectOptions);
        /**
        * 每个间隔针对每个对象作用
        * @param objs
        */
        protected updatePeriodlyForPerTarget(obj: Hero): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): PeriodlyHurtBuffEffect;
    }
}
declare namespace rpgfight {
    interface SkillAttrBuffEffectOptions {
        /**
         * 属性增强倍率
         */
        enhanceRate?: number;
        /**
         * 属性增强数值
         */
        enhanceValue?: number;
        /**
         * 作用时长
         */
        duration?: number;
        /**
         * 技能
         */
        skillData?: SkillData;
    }
    /**
     * 属性数值修饰buff
     */
    class SkillAttrBuffEffect extends BuffEffect {
        owner: Hero;
        options: SkillAttrBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: SkillAttrBuffEffectOptions);
        attrNameEnhanced: string;
        onAdd(): void;
        onRemove(): void;
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    /**
     * 限制时长，并且只对技能自身作用的属性修饰buff
     */
    class SkillSelfTimeLimitAttrBuffEffect extends SkillAttrBuffEffect {
        options: SkillAttrBuffEffectOptions;
        ctype: string;
        constructor(runner: Runner, owner: Hero, options: SkillAttrBuffEffectOptions);
        clone(context: logicchart.trigger.Context, runner: Runner, owner: GameObject, options: any): any;
    }
}
declare namespace rpgfight {
    /**
     * 传入数据
     */
    class HeroCalcParams {
        /**
         * 系数
         */
        kP1: number;
    }
    /**
     * 公式计算器
     */
    class HeroCalc {
        /**
         * 技能的运行器
         */
        calcRunner: logicchart.trigger.Runner;
        /**
         * 决策树上下文
         * @ignore
         */
        calcTreeContext: logicchart.trigger.Context;
        protected _calcTree: ICalcEntity;
        constructor(runner: Runner);
        /**
         * 计算物理伤害
         * @param hero 当前英雄
         * @param target 目标英雄
         * @param k 系数
         */
        calcPhysicHurt(context: logicchart.trigger.Context, hero: Hero, target: Hero, k: number): number;
        /**
         * 计算魔法伤害
         * @param hero 当前英雄
         * @param target 目标英雄
         * @param k 系数
         */
        calcMagicHurt(context: logicchart.trigger.Context, hero: Hero, target: Hero, k: number): number;
        /**
         * 计算恢复血量
         * @param hero 当前英雄
         * @param target 目标英雄
         * @param k 系数
         */
        calcBloodToHeal(context: logicchart.trigger.Context, hero: Hero, target: Hero, k: number): number;
    }
}
declare namespace rpgfight {
    class SceneConfig {
        /**
         * 战场宽度
         */
        width: number;
        /**
         * 战场高度
         */
        height: number;
        /**
         * 游戏时间，设置为0表示不计时 毫秒
         */
        time: number;
        /**
         * 随机种子
         */
        seed: number;
    }
}
declare namespace rpgfight {
    /**
     * 技能类型
     */
    enum SkillTypeEnum {
        /**
         * 大招
         */
        bskill = 0,
        /**
         * 小招
         */
        sskill = 1,
        /**
         * 被动技能
         */
        passive = 2,
        /**
         * 普攻
         */
        normalAttack = 3
    }
    type SkillType = "initiative" | "passive";
    class SkillConfig {
        /**
         * 所使用的配置文件
         */
        triggerTree: IEntity;
        /**
         * 技能配表中id
         */
        skillId: string;
        /**
         * 技能名称
         */
        name: string;
        /**
         * 技能优先级
         */
        priority: number;
        /**
         * 进入游戏的初始CD ms
         */
        startCd: number;
        /**
         * 间隔CD ms
         */
        intervalCd: number;
        /**
         * 攻击距离
         */
        distance: number;
        /**
         * 释放需要的能量
         */
        requiredPower: number;
        /**
         * 是否特写技能
         */
        isWithCloseUp: boolean;
        /**
         * 是否普攻技能
         */
        isNormalAttack: boolean;
        /**
        * 技能等级
        */
        skillLevel: number;
        /**
         * 技能序号
         */
        skillNo: number;
        /**
         * 技能类型
         * - initiative 主动
         * - passive 被动
         */
        skillType: SkillType;
        /**
         * 仅服务器传技能文件名用
         */
        triggerTreeName?: string;
        /**
         * 是否有效
         */
        isValid: boolean;
        /**
         * 技能品质
         */
        skillQuality: SkillQuality;
        /**
         * 免疫无法攻击
         */
        ignoreNoAttack: boolean;
        constructor(
        /**
         * 所使用的配置文件
         */
        triggerTree: IEntity);
        /**
         * 创建当前技能可使用的数据
         * @param runner
         */
        createSkillData(runner: Runner): SkillData;
    }
}
declare namespace rpgfight {
    let chartconfigEx: {
        [key: string]: IEntity;
    };
}
declare namespace rpgfight {
    /**
     * 英雄战损统计
     */
    class HeroContributionStatistic {
        /**
         * 英雄Id
         * @ignore
         */
        heroId: string;
        /**
         * 治疗总量
         */
        hpHealed: number;
        /**
         * 承伤总量
         */
        hpInjured: number;
        /**
         * 伤害总量
         */
        hpHurt: number;
        /**
         * 击杀数量
         */
        killCount: number;
        /**
         * 我方/地方
         * @ignore
         */
        battleTeam: BattleTeam;
        /**
         * 是否已死亡
         * @ignore
         */
        isDead: boolean;
    }
}
declare namespace rpgfight {
    class HeroData {
        /**
         * 英雄对象id
         * @ignore
         */
        heroId: string;
        get objectId(): string;
        /**
         * 英雄类型id
         */
        heroConfigId: string;
        /**
         * 数据类型
         * @ignore
         */
        cType: string;
        /**
         * 最大血量
         * @ignore
         */
        hpMax: number;
        /**
         * 当前血量(不考虑BUFF)
         */
        hp: number;
        /**
         * 护盾血量
         * @ignore
         */
        shieldHpMap: {
            [key: string]: {
                cur: number;
                total: number;
            };
        };
        /**
         * 护盾当前血量
         */
        get shieldHp(): number;
        /**
         * 护盾总血量
         */
        get shieldMaxHp(): number;
        /**
         * 当前能量
         * - 用于放大招
         * - 每个英雄上限固定 1000
         * @ignore
         */
        power: number;
        /**
         * 最大能量
         * @ignore
         */
        powerMax: number;
        /**
         * 攻击
         * @ignore
         */
        attack: number;
        /**
         * 攻击额外值
         * @ignore
         */
        attackExtra: number;
        /**
         * 防御
         * 减少受到的物理伤害/魔法伤害
         * @ignore
         */
        defense: number;
        /**
         * 暴击率(0.0-1.0)
         * @ignore
         */
        critRate: number;
        /**
         * 暴击伤害
         * 默认为2倍
         * @ignore
         */
        critHurt: number;
        /**
         * 命中
         * @ignore
         */
        hitRate: number;
        /**
         * 闪避率
         * 闪避英雄攻击的的成功率
         * @ignore
         */
        dodgeRate: number;
        /**
         * 攻速
         */
        attackSpeedRate: number;
        /**
         * 移动速度
         */
        moveSpeed: number;
        /**
         * 每秒回血
         * 战斗中每秒自动恢复的生命值
         * @ignore
         */
        hpHealingSpeed: number;
        /**
         * 被治疗效果
         * @ignore
         */
        hpBeHealEffectRate: number;
        /**
         * 被治疗效果
         */
        get hpBeHealEffectRateRuntime(): number;
        /**
         * 治疗效果
         * @ignore
         */
        hpHealingEffectRate: number;
        /**
         * 治疗效果
         */
        get hpHealingEffectRateRuntime(): number;
        /**
         * 魔法减伤率
         * 额外减少受到的魔法伤害
         * @ignore
         */
        extraDefenseMagicHurt: number;
        /**
         * 物理减伤率
         * 额外减少受到的物理伤害
         * @ignore
         */
        extraDefensePhysicalHurt: number;
        /**
         * 输出伤害增加比率
         * @ignore
         */
        damageRate: number;
        /**
         * 输出伤害增加比率
         */
        get damageRateRuntime(): number;
        /**
         * 吸血等级
         * - 给敌人造成伤害时，根据伤害数值百分比恢复的血量
         * @ignore
         */
        suckBloodLv: number;
        /**
         * 等级
         */
        level: number;
        /**
         * 品阶
         */
        rank: number;
        /**
         * 免疫任何伤害
         * @ignore
         */
        isInjuryFree: boolean;
        /**
         * 免疫任何伤害
         */
        get isInjuryFreeRuntime(): boolean;
        /**
         * 免疫物理伤害
         * @ignore
         */
        isPhysicalInjuryFree: boolean;
        /**
         * 免疫物理伤害
         */
        get isPhysicalInjuryFreeRuntime(): boolean;
        /**
         * 免疫魔法伤害
         * @ignore
         */
        isMagicInjuryFree: boolean;
        /**
         * 免疫魔法伤害
         */
        get isMagicInjuryFreeRuntime(): boolean;
        /**
         * 免疫特定职业英雄伤害
         * @ignore
         */
        injuryFreeCareer: HeroCareerType;
        /**
         * 免疫特定职业英雄伤害
         */
        get injuryFreeCareerRuntime(): HeroCareerType;
        /**
         * 是否假死
         */
        isShock: boolean;
        /**
         * 是否变身
         */
        isTransform: boolean;
        /**
         * 是否可选中
         * - 不可选中，则无法被攻击或施法
         * - 后面替换为使用状态树存储
         */
        protected isSelectableByEnermy: boolean;
        /**
         * @ignore
         */
        get isSelectableByEnermyRuntime(): boolean;
        /**
         * @ignore
         */
        set isSelectableByEnermyRuntime(value: boolean);
        /**
         * @ignore
         */
        protected isSelectableByCompanion: boolean;
        /**
         * @ignore
         */
        get isSelectableByCompanionRuntime(): boolean;
        /**
         * @ignore
         */
        set isSelectableByCompanionRuntime(value: boolean);
        /**
         * 实际吸血比例
         * @ignore
         */
        get suckBloodRateRealtime(): number;
        /**
         * 本帧已吸血总量
         * @ignore
         */
        suckedBloodPerFrame: number;
        /**
         * 已损失血量
         * @ignore
         */
        get lostHpRealtime(): number;
        /**
         * 普通攻击技能
         * @ignore
         */
        attackSkill?: SkillData;
        /**
         * 技能列表，按优先级排序
         * @ignore
         */
        skillList?: SkillData[];
        /**
         * @ignore
         */
        get skillListRuntime(): SkillData[];
        /**
         * 攻击的时间
         * @ignore
         */
        attackTime: number;
        /**
         * 属于哪一方
         * @ignore
         */
        battleTeam: BattleTeam;
        /**
         * 属于哪一方
         */
        get battleTeamRuntime(): BattleTeam;
        /**
         * 当前移动向量
         * @ignore
         */
        movingDeltaPerFrame: ml.Point;
        /**
         * 减伤率
         * @ignore
         */
        injuryFreeRate: number;
        /**
         * 减伤率
         */
        get injuryFreeRateRuntime(): number;
        /**
         * 易伤率
         * @ignore
         */
        injuryHardRate: number;
        /**
         * 易伤率
         */
        get injuryHardRateRuntime(): number;
        /**
         * 物理易伤率
         * @ignore
         */
        injuryPhysicHardRate: number;
        /**
         * 物理易伤率
         */
        get injuryPhysicHardRateRuntime(): number;
        /**
         * 魔法易伤率
         * @ignore
         */
        injuryMagicHardRate: number;
        /**
         * 魔法易伤率
         */
        get injuryMagicHardRateRuntime(): number;
        /**
         * 免疫持续掉血
         * @ignore
         */
        immuneBloodLoss: boolean;
        /**
         * 免疫持续掉血
         */
        get immuneBloodLossRuntime(): boolean;
        /**
         * 免疫中毒
         * @ignore
         */
        immunePoisoning: boolean;
        /**
         * 免疫中毒
         */
        get immunePoisoningRuntime(): boolean;
        /**
         * 阵营
         */
        get faction(): HeroFactionType;
        set faction(value: HeroFactionType);
        /**
         * 职业
         */
        get career(): HeroCareerType;
        set career(value: HeroCareerType);
        /**
         * 英雄类型
         */
        get heroType(): HeroType;
        set heroType(value: HeroType);
        /**
         * 是否为魔法英雄
         * @ignore
         */
        get isMagicHero(): boolean;
        set isMagicHero(value: boolean);
        /**
         * 英雄远程普攻道具出手位置
         * @ignore
         */
        normalAttackStartPosition: ml.Point;
        /**
         * 英雄受击位置
         * @ignore
         */
        normalOnHitPosition: ml.Point;
        /**
         * 原始数据
         * @ignore
         */
        config: HeroConfig;
        /**
         * @ignore
         */
        runner: Runner;
        /**
         * @ignore
         */
        private _owner;
        /**
         * @ignore
         */
        get owner(): Hero | undefined;
        set owner(value: Hero | undefined);
        /**
         * @ignore
         * @param runner
         * @param config
         */
        constructor(runner: Runner, config: HeroConfig);
        /**
         * 获取经过buff等影响计算后的数值
         * @ignore
         */
        getEffectedHeroData(): HeroData;
        static wrapMarkChanges(to: HeroData): void;
        _changedValues: string[];
        _dataCopy?: HeroData;
        protected _cachedEffectedHeroData?: HeroData;
        /**
         * 每帧遍历buff更新英雄数据副本
         */
        updateEffectedHeroData(): void;
        /**
         * 英雄战损数据
         */
        contributionStatistic: HeroContributionStatistic;
        /**
         * 能否攻击敌人
         * @ignore
         */
        isAttackEnabled: boolean;
        /**
         * 能否攻击敌人
         */
        get isAttackEnabledRuntime(): boolean;
        /**
         * 能否闪避
         * @ignore
         */
        isDodgeEnabled: boolean;
        /**
         * 能否闪避
         */
        get isDodgeEnabledRuntime(): boolean;
        /**
         * 普攻是否可用
         * @ignore
         */
        isNormalAttackUsable: boolean;
        /**
         * 普攻是否可用
         */
        get isNormalAttackUsableRuntime(): boolean;
        /**
         * 技能是否可用（未禁魔）
         * @ignore
         */
        isSkillUsable: boolean;
        get isSkillUsableRuntime(): boolean;
        /**
         * 根据当前环境计算每一帧的移动距离
         * @ignore
         */
        get moveSpeedPerFrame(): number;
        /**
         * 对象是否可移动
         * @ignore
         */
        protected isMovable: boolean;
        /**
         * 可移动
         */
        get isMovableRuntime(): boolean;
        set isMovableRuntime(value: boolean);
        /**
         * 是否免疫控制
         * @ignore
         */
        protected isImmuneControl: boolean;
        /**
         * 是否免疫控制
         */
        get isImmuneControlRuntime(): boolean;
        set isImmuneControlRuntime(value: boolean);
        /**
         * 直接扣血
         * @param dhp 扣除血量
         * @param ignoreShield 忽略护盾
         * @ignore
         */
        hurtHp(dhp: number, ignoreShield?: boolean): number;
        /**
         * 回血
         * @ignore
         */
        healHp(dhp0: number): number;
        /**
         * 攻击
         */
        get attackRealtime(): number;
        /**
         * 当前血量
         */
        get hpRealtime(): number;
        /**
         * 血量上限
         */
        get hpMaxRealtime(): number;
        /**
         * 当前能量
         */
        get powerRealtime(): number;
        /**
         * 能量上限
         */
        get powerMaxRealtime(): number;
        /**
         * 恢复能量
         * @ignore
         */
        chargePower(power0: number): number;
        /**
         * 能量恢复效率
         * @ignore
         */
        powerChargeRate: number;
        /**
         * 能量恢复效率
         */
        get powerChargeRateRealtime(): number;
        /**
         * 能量每秒恢复速度
         */
        powerChargeSpeedNormal: number;
        /**
         * 受击能量恢复速度
         * @ignore
         */
        powerChargeSpeedWithHurt: number;
        /**
         * 受击能量恢复效率
         * @ignore
         */
        powerChargeRateWithHurt: number;
        /**
         * 攻击出手恢复能量
         */
        powerChargeSpeedWithUsingSkill: number;
        /**
         * 击杀恢复能量
         */
        powerChargeSpeedWithKilling: number;
        /**
         * 回能系数
         */
        powerSpeedupRate: number;
        /**
         * 受击能量恢复效率
         */
        get powerChargeRateWithHurtRealtime(): number;
        /**
         * 受击能量恢复速度
         */
        get powerChargeSpeedWithHurtRealtime(): number;
        /**
         * 防御
         */
        get defenseRealtime(): number;
        /**
         * 暴击率
         */
        get critRateRealtime(): number;
        /**
         * 暴击伤害
         */
        get critHurtRealtime(): number;
        /**
         * 命中
         */
        get hitRateRealtime(): number;
        /**
         * 闪避
         */
        get dodgeRateRealtime(): number;
        /**
         * 攻速
         */
        get attackSpeedRateRealtime(): number;
        /**
         * 移动速度
         */
        get moveSpeedRealtime(): number;
        /**
         * 每秒回复
         */
        get hpHealingSpeedRealtime(): number;
        /**
         * 魔法减伤率
         */
        get extraDefenseMagicHurtRealtime(): number;
        /**
         * 物理减伤率
         */
        get extraDefensePhysicalHurtRealtime(): number;
        /**
         * 吸血等级
         */
        get suckBloodLvRealtime(): number;
        /**
         * 隐身
         * @ignore
         */
        opacity: number;
        /**
         * 隐身
         */
        get opacityRealtime(): number;
        /**
         * 恢复血量限制
         * @ignore
        */
        healingLimited: number;
        /**
         * 恢复血量限制
         */
        get healingLimitedRealtime(): number;
        /**
         * 克制伤害系数
         * @ignore
         */
        restraintHurtRate: number;
        /**
         * 克制伤害系数
         */
        get restraintHurtRateRealtime(): number;
        /**
         * 施法中
         * @ignore
         */
        isConjuring: boolean;
        /**
         * 施法中
         */
        get isConjuringRealtime(): boolean;
        /**
         * 迅捷等级
         * @ignore
         */
        skillSpeed: number;
        /**
         * 迅捷等级
         */
        get skillSpeedRealtime(): number;
        /**
         * 专属技能等级
         * @ignore
         */
        exclusiveLevel: number;
        /**
         * 专属技能等级
         */
        get exclusiveLevelRealtime(): number;
        /**
         * 治疗能力
         * @ignore
         */
        healCap: number;
        /**
         * 治疗能力
         */
        get healCapRealtime(): number;
        /**
         * 抗爆率
         * @ignore
         */
        deCri: number;
        /**
         * 抗爆率
         */
        get deCriRealtime(): number;
        /**
         * 伤害增加
         * @ignore
         */
        incHarm: number;
        /**
         * 伤害增加
         */
        get incHarmRealtime(): number;
        /**
         * 神器主动技能增伤
         * @ignore
         */
        incArtifactHarm: number;
        /**
         * 神器主动技能增伤
         */
        get incArtifactHarmRealtime(): number;
        /**
         * 神器主动技能减伤
         * @ignore
         */
        decArtifactHarm: number;
        /**
         * 神器主动技能减伤
         */
        get decArtifactHarmRealtime(): number;
        /**
         * 神器主动技能暴击率
         * @ignore
         */
        criPctArtifact: number;
        /**
         * 神器主动技能暴击率
         */
        get criPctArtifactRealtime(): number;
        /**
         * 神器主动技能暴击伤害
         */
        criAtkArtifact: number;
        /**
         * 神器主动技能暴击伤害
         */
        get criAtkArtifactRealtime(): number;
        /**
         * 阵营克制
         */
        factionRestrain: number;
        get factionRestrainRealtime(): number;
    }
}
declare namespace rpgfight {
    /**
     * 触发事件回传数据
     */
    class HeroTriggerData {
        /**
         * 治疗血量
         */
        bloodToHeal: number;
        /**
         * 受到伤害
         */
        hpToHurt: number;
    }
    class Point {
        x: number;
        y: number;
        isRelyOnHero?: boolean;
        constructor(x: number, y: number, isRelyOnHero?: boolean);
    }
    class CollideTriggerData {
        /**
         * 碰撞位置
         * - （绝对位置）
         */
        collidePosition: Point;
    }
}
declare namespace rpgfight {
    enum BattleTeam {
        /**
         * 我方
         */
        our = 0,
        /**
         * 敌方
         */
        enemy = 1,
        /**
         * 中立
         */
        neutral = 2
    }
    enum EnterAnimPos {
        /**
         * 由英雄站位决定
         */
        default = 0,
        /**
         * 每次直接进场到前排
         */
        frontRow = 1,
        /**
         * 每次直接进场到后排
         */
        backRow = 2
    }
    /**
     * 英雄
     */
    enum HeroProperty {
        /**
         * 血量上限
         * 战斗中的初始生命值上限
         */
        hpMax = 0,
        /**
         * 能量
         * 用于放大招
         */
        power = 1,
        /**
         * 攻击
         * 战斗中的初始攻击力
         */
        attack = 2,
        /**
         * 防御
         * 减少受到的物理伤害/魔法伤害
         */
        defense = 3,
        /**
         * 暴击率
         * 触发暴击的概率
         */
        critRate = 4,
        /**
         * 暴击伤害倍率
         * 触发暴击后的伤害倍数，默认为2倍
         */
        critHurt = 5,
        /**
         * 命中
         * 物理英雄攻击的准确率
         */
        hitRate = 6,
        /**
         * 闪避
         * 闪避物理英雄攻击的的成功率
         */
        dodgeRate = 7,
        /**
         * 施法迅捷
         */
        skillSpeed = 8,
        /**
         * 每秒恢复
         * 战斗中每秒自动恢复的生命值
         */
        hpHealingSpeed = 9,
        /**
         * 魔法减伤率
         * 额外减少受到的魔法伤害
         */
        extraDefenseMagicHurt = 10,
        /**
         * 物理减伤率
         * 额外减少受到的物理伤害
         */
        extraDefensePhysicalHurt = 11,
        /**
         * 吸血等级
         * 给敌人造成伤害时，根据伤害数值百分比恢复的血量
         */
        suckBloodLv = 12,
        /**
         * 所属
         */
        battleTeam = 13,
        /**
         * 损失血量
         */
        lostHp = 14,
        /**
         * 当前血量
         */
        hp = 15,
        /**
         * 能量上限
         * 用于放大招
         */
        powerMax = 16
    }
    enum ValueType {
        /**
         * 百分比
         */
        percent = 0,
        /**
         * 固定数值
         */
        value = 1
    }
}
declare namespace rpgfight {
    class SceneData {
        config: SceneConfig;
        constructor(config: SceneConfig);
    }
}
declare namespace rpgfight {
    enum SkillQuality {
        /**
         * 无
         */
        None = 0,
        /**
         * 稀有
         */
        Normal = 1,
        /**精英 */
        Epic = 2,
        /**传奇 */
        Myth = 3
    }
    class SkillData {
        runner: Runner;
        config: SkillConfig;
        /**
         * 技能配表中id
         */
        skillId: string;
        /**
         * 使用技能的时间
         */
        useTime: number;
        /**
         * 是否为第一次使用该技能
         */
        isFirstUse: boolean;
        /**
         * 是否为有效技能
         */
        isValid: boolean;
        /**
         * 自定义攻击距离
         */
        customDistance: number;
        /**
         * 大招是否自动释放
         */
        autoPlay: boolean;
        /**
         * 是否为神器技能
         */
        isArtifactSkill: boolean;
        /**
         * 强制进入特写
         */
        forceEnterCloseup: boolean;
        /**
         * 手动触发过
         */
        protected _isTriggeredManual: boolean;
        protected _startCd: number;
        get startCd(): number;
        set startCd(value: number);
        protected _intervalCd: number;
        get intervalCd(): number;
        set intervalCd(value: number);
        /**
         * 是否特写技能
         */
        get isWithCloseUp(): boolean;
        /**
         * 技能分类
         */
        get skillTypeExt(): SkillTypeEnum;
        /**
         * 是否被手动触发过
         */
        get isTriggeredManual(): boolean;
        set isTriggeredManual(value: boolean);
        /**
         * 技能的运行器
         */
        skillRunner: logicchart.trigger.Runner;
        triggerTree: ISkillEntity;
        resetSkillRunner(): void;
        owner?: Hero;
        constructor(runner: Runner, config: SkillConfig);
        protected setTimeout(callback: () => void, delay: number): void;
        /**
         * 攻击距离
         */
        get distance(): number;
        /**
         * 技能是否可以使用（检查技能cd）
         */
        get isUsable(): boolean;
        /**
         * 是否已冷却
         */
        isSkillColdDown(context: logicchart.trigger.Context): boolean;
        /**
         * 技能等级
         */
        getSkillLevel(context: logicchart.trigger.Context): number;
        /**
         * 技能品质
         */
        getSkillQuality(context: logicchart.trigger.Context): SkillQuality;
    }
}
declare namespace rpgfight {
    /**
     * 技能运行时会话数据
     * - 仅释放当前技能的上下文中有效，释放完技能即无效
     */
    class SkillSession {
        /**
         * 目标受击能量恢复比率
         */
        powerChargeRateWithHurtForTarget: number;
    }
}
declare namespace rpgfight {
    /**
     * 战斗全局日志
     */
    const devLog: logicchart.statetree.Log;
}
declare namespace rpgfight {
    interface ILogSource {
        serialize(): string;
    }
    /**
     * 英雄技能信息
     */
    class HeroSkillInfoTyper implements ILogSource {
        skillConfig: SkillConfig;
        constructor(skillConfig: SkillConfig);
        serialize(): string;
    }
    /**
     * 英雄当前信息
     */
    class HeroInfoTyper implements ILogSource {
        heroConfig: HeroConfig;
        constructor(heroConfig: HeroConfig);
        serialize(): string;
    }
    /**
     * 英雄行为
     */
    class HeroActionRecord implements ILogSource {
        /**
         * 英雄
         */
        sourceHero?: Hero;
        /**
         * 目标英雄
         */
        targetHero?: Hero;
        /**
         * 行为
         */
        action?: HeroTriggerEventEnum;
        /**
         * 数值
         */
        value?: number | string;
        /**
         * 技能
         */
        theSkill?: SkillData;
        /**
         * buff
         */
        theBuff?: IBuffBase;
        constructor(
        /**
         * 英雄
         */
        sourceHero?: Hero, 
        /**
         * 目标英雄
         */
        targetHero?: Hero, 
        /**
         * 行为
         */
        action?: HeroTriggerEventEnum, 
        /**
         * 数值
         */
        value?: number | string, 
        /**
         * 技能
         */
        theSkill?: SkillData, 
        /**
         * buff
         */
        theBuff?: IBuffBase);
        serialize(): string;
    }
    /**
     * 日志记录
     */
    class LogRecord {
        /**
         * 记录时间
         */
        time: number;
        content: string;
        constructor(runner: Runner);
        protected init(runner: Runner): void;
        get second(): number;
        get msecond(): number;
    }
    class LogFlow {
        logList: LogRecord[];
        enabled: boolean;
        enableRuntimeLog: boolean;
        protected _runner: Runner;
        constructor(runner: Runner);
        info(s: string | ILogSource): void;
        serializeLine(record: LogRecord): string;
        serializeRecords(): string[];
        serialize(): string;
        formatDate(date: Date, style: string): string;
        clear(): void;
    }
}
declare namespace rpgfight {
    /**
     * 游戏对象基础类
     * - 对对象生命周期和基础属性管理
     */
    class GameObject implements ILiveObject {
        ctype: string;
        static currentObjectId: number;
        private _objectId;
        get objectId(): string;
        protected _isAlive: boolean;
        protected _destroyStack?: String;
        protected _runner: Runner;
        /**
         * 抽象视图层
         */
        protected _view?: View;
        /**
         * 状态树
         */
        protected _stateTree?: logicchart.statetree.StatusObject;
        timer: UpdateTimer;
        constructor(runner: Runner);
        isPaused: boolean;
        update(dt: number): void;
        onUpdate(dt: number): void;
        pause(): void;
        resume(): void;
        setTimeScale(value: number): void;
        onAdd(): void;
        onRemove(): void;
        onDestroy(): void;
        /**
         * 释放对象，触发onDestroy函数，并标志alive状态为false
         */
        destroy(): void;
        /**
         * 对象是否还活着，当调用destroy方法后，对象alive状态将会变成false
         */
        get isAlive(): boolean;
        get destroyStack(): String;
        /**
         * @ignore
         */
        get runner(): Runner;
        get stateTree(): logicchart.statetree.StatusObject;
        get view(): View;
        get manager(): ManagerBase;
    }
}
declare namespace rpgfight {
    /**
     * 特效对象
     */
    class EffectBase extends GameObject {
    }
}
declare namespace rpgfight {
    /**
     * 技能特效数据和视图对象
     */
    class SkillEffect extends EffectBase {
        /**
         * 特效id
         * @ignore
         */
        effectId: string;
        /**
         * 释放特效的英雄
         */
        owner: Hero;
        /**
         * 来源技能
         * @ignore
         */
        skillData: SkillData;
        protected _view: SkillView;
        /**
         * 是否进入特写之后暂停此特效
         * @ignore
         */
        needPauseWithCloseUp: boolean;
        /**
         * @ignore
         */
        constructor(
        /**
         * @ignore
         */
        runner: Runner, 
        /**
         * 特效id
         * @ignore
         */
        effectId: string, 
        /**
         * 释放特效的英雄
         */
        owner: Hero, 
        /**
         * 来源技能
         * @ignore
         */
        skillData: SkillData);
        /**
         * 是否暂停
         */
        isPaused: boolean;
        /**
         * @ignore
         */
        update(dt: number): void;
        /**
         * @ignore
         */
        onUpdate(dt: number): void;
        /**
         * 暂停
         * @ignore
         */
        pause(): void;
        /**
         * 继续
         * @ignore
         */
        resume(): void;
        setTimeScale(value: number): void;
        /**
         * @ignore
         */
        onDestroy(): void;
        get view(): SkillView;
        /**
         * 是否依赖当前技能释放状态
         */
        isRelyOnSkill: boolean;
        /**
         * 依赖的英雄对象
         */
        reliedHeros?: Hero;
        /**
         * 负面效果
         */
        isDebuff: boolean;
    }
}
declare namespace rpgfight {
    /**
     * 支持自定义特效
     */
    class CustomSkillEffect extends SkillEffect {
        /**
         * 特效id
         * @ignore
         */
        effectId: string;
        /**
         * 特效创建者
         */
        owner: Hero;
        /**
         * 来源技能
         * @ignore
         */
        skillData: SkillData;
        /**
         * @ignore
         */
        constructor(
        /**
         * @ignore
         */
        runner: Runner, 
        /**
         * 特效id
         * @ignore
         */
        effectId: string, 
        /**
         * 特效创建者
         */
        owner: Hero, 
        /**
         * 来源技能
         * @ignore
         */
        skillData: SkillData);
        /**
         * 设定不依赖任何对象存活
         */
        markIndependent(): void;
        /**
         * 设定需依赖某英雄存活
         * @param context
         * @param hero 当该英雄死亡，那么特效销毁
         */
        relyOnHero(context: logicchart.trigger.Context, hero: Hero): void;
        /**
         * 设定需依赖施法者存活
         * @param context
         * @param hero 当该英雄死亡，那么特效销毁
         */
        relyOnTheOwner(context: logicchart.trigger.Context): void;
        /**
         * 设定需依赖技能存活
         * - 当退出当前技能状态，那么特效销毁
         * @param context
         */
        relyOnTheSkill(context: logicchart.trigger.Context): void;
        /**
         * 销毁自身
         * @param context
         */
        destroyThisObject(context: logicchart.trigger.Context): void;
        /**
         * 从目标缩回
         * @param context
         * @param slotMap ok->已缩回->{}
         * @param speed 缩回速度
         * @param target 目标单位
         */
        shrinkFromTarget(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, speed: number, target: Hero): void;
        /**
         * 向目标延伸
         * @param context
         * @param slotMap ok->触及目标->{}
         * @param speed 延伸速度
         * @param target 目标单位
         */
        spreadToTarget(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, speed: number, target: Hero): void;
        protected addUpdateCallback(f: any): void;
        protected removeUpdateCallback(f: any): void;
        protected updateCallbacks: ((dt: number, f: any) => void)[];
        protected _removedUpdateCallbacks: ((dt: number, f: any) => void)[];
        /**
         * @param dt
         * @ignore
         */
        onUpdate(dt: number): void;
    }
}
declare namespace rpgfight {
    /**
     * 召唤英雄等代码可以独立挪出来
     */
    class GameObjectFactory {
        runner: Runner;
        constructor(runner: Runner);
    }
}
declare namespace rpgfight {
    function cloneContextMap(context: logicchart.trigger.Context, map?: Object): Object;
    /**
     * 英雄技能动画列表
     */
    enum HeroAnimations {
        /**
         * 技能一出招
         */
        skill_1_prepare = 0,
        /**
         * 技能一位移
         */
        skill_1_move = 1,
        /**
         * 技能一施法
         */
        skill_1_conjure = 2,
        /**
         * 技能一攻击
         */
        skill_1_attack = 3,
        /**
         * 技能一受击
         */
        skill_1_onhit = 4,
        /**
         * 技能一收招
         */
        skill_1_end = 5
    }
    enum FlyRoute {
        /**
         * 直线
         */
        direct = 0,
        /**
         * 回旋斧头
         */
        axe_arc = 1,
        /**
         * 环绕
         */
        around = 2,
        /**
         * 直线往返
         */
        come_and_go = 3,
        /**
         * 弧线跟踪
         */
        arc_and_track = 4
    }
    interface DeadInfo {
        /**
         * 击杀者
         */
        killer: Hero;
    }
    class Hero extends GameObject {
        /**
         * 属性
         * 英雄运行时数据
         */
        heroData: HeroData;
        decisionTreeData: IAiEntity;
        ctype: string;
        /**
         * 英雄行为的决策
         * @ignore
         */
        decisionTree: logicchart.trigger.Runner;
        /**
         * 决策树上下文
         * @ignore
         */
        decisionTreeContext: logicchart.trigger.Context;
        /**
         * 目标列表，例如选择了多个目标的时候
         * @ignore
         */
        heroSelected: HeroSelector;
        /**
         * 上一帧选择的技能
         * @ignore
         */
        lastSelectedSkill?: SkillData;
        /**
         * 当前选择的技能
         * @ignore
         */
        selectedSkill?: SkillData;
        /**
         * 选定目标的次数
         * @ignore
         */
        selectTargetCount: number;
        /**
         * 英雄坐标
         * @ignore
         */
        protected _position: ml.Point;
        /**
         * 是否处于特写中
         * @ignore
         */
        isInCloseUp: boolean;
        /**
         * 特效助手
         */
        effectHelper: HeroEffectUIHelper;
        /**
         * BUFF助手
         */
        buffUIHelper: HeroBuffUIHelper;
        /**
         * BUFF设计助手
         */
        buffDesignUIHelper: HeroBuffDesignUIHelper;
        /**
         * 技能助手
         */
        skillSessionUIHelper: SkillSessionUIHelper;
        /**
         * 站位助手
         */
        stationUIHelper: HeroStationUIHelper;
        /**
         * 属性设置助手
         */
        heroDataUIHelper: HeroDataSetUIHelper;
        /**
         * 是否已进入战场
         */
        enteredBattle: boolean;
        /**
         * 英雄朝向
         * - 方向 -1左 1右
         * @ignore
         */
        private _direction;
        /**
         * 英雄朝向
         */
        get direction(): number;
        set direction(value: number);
        /**
         * 获取英雄朝向
         */
        getDirection(context: logicchart.trigger.Context): HeroDirection;
        /**
         * 设置英雄朝向
         */
        setDirection(context: logicchart.trigger.Context, direction: HeroDirection): void;
        /**
         * 英雄名
         */
        get name(): string;
        /**
         * X坐标
         */
        get x(): number;
        /**
         * Y坐标
         */
        get y(): number;
        getNormalAttackStartPosition(): ml.Point;
        getNormalOnHitPosition(): ml.Point;
        /**
         * @ignore
         */
        heroStateHelper: HeroStateHelper;
        constructor(runner: Runner, 
        /**
         * 属性
         * 英雄运行时数据
         */
        heroData: HeroData, decisionTreeData: IAiEntity);
        /**
         * 站位横坐标
         * @ignore
         */
        static StationPositionY: number[];
        /**
         * 站位纵坐标
         * @ignore
         */
        static StationPositionX: number[];
        /**
         * @ignore
         */
        enterBattle(): void;
        protected _powerRecoverIntervalId?: IntervalIdInfo;
        protected _hpRecoverIntervalId?: IntervalIdInfo;
        onDestroy(): void;
        isRunaway: boolean;
        onUpdate(dt: number): void;
        /**
         * 处理自身造成的伤害
         * - 吸血
         * @ignore
         */
        dealWithCausedHurt(value: number): void;
        /**
         * 英雄是否存活状态
         * - 和 对象是否存活(isAlive) 不同
         */
        isAtAliveState(): boolean;
        /**
         * 重置技能CD时间
         * @param skillId 技能ID
         */
        resetSkillIntervalCD(context: logicchart.trigger.Context, skillId: number): void;
        /**
         * 英雄坐标
         * @ignore
         */
        get position(): ml.Point;
        /**
         * 进场结束为止
         */
        enterFinishPosition: ml.Point;
        protected _sceneConfig?: SceneConfig;
        /**
         * 场景数据
         * @ignore
         */
        get sceneConfig(): SceneConfig;
        /**
         * 英雄坐标
         * @ignore
         */
        protected _offsetW: number;
        protected _offsetH: number;
        set position(p: ml.Point);
        /**
         * 是否超越场景边界
         */
        isOverArrivedSceneBorder(p: ml.Point): boolean;
        /**
         * @ignore
         */
        get battleTeam(): BattleTeam;
        /**
         * 属于哪一方
         */
        get battleTeamRuntime(): BattleTeam;
        /**
         * @ignore
         */
        get tag(): string;
        /**
         * 标记当前技能为神器技能
         */
        markSelectSkillArtifact(context: logicchart.trigger.Context): void;
        /**
         * 获取唯一标识
         */
        getTag(context: logicchart.trigger.Context): string;
        /**
         * 高亮
         */
        highlight(context: logicchart.trigger.Context): void;
        /**
         * 震屏
         */
        shake(context: logicchart.trigger.Context): void;
        /**
         * 攻击恢复能量
         */
        chargePowerWithUsingSkill(context: logicchart.trigger.Context): void;
        /**
         * 优先攻击目标
         */
        protected _firstAttackTarget: Hero | null;
        /**
         * 设置优先攻击目标
         * @param target 目标单位
         */
        setFirstAttackTarget(context: logicchart.trigger.Context, target: Hero): void;
        /**
         * 获取优先攻击目标
         */
        getFirstAttackTarget(context: logicchart.trigger.Context): Hero;
        protected _lockPosition: boolean;
        /**
         * 锁定位置
         */
        lockPosition(context: logicchart.trigger.Context): void;
        /**
         * 解锁位置
         */
        unlockPosition(context: logicchart.trigger.Context): void;
        /**
         * 是否位置已锁定
         */
        isPositionLocked(context: logicchart.trigger.Context): boolean;
        /**
         * 自定义参数
         */
        protected _params: {
            [key: string]: any;
        };
        /**
         * 设置参数
         * @param key 名称
         * @param value 值
         */
        setValue(context: logicchart.trigger.Context, key: string, value: any): void;
        /**
         * 读取参数
         * @param key 名称
         */
        getValue(context: logicchart.trigger.Context, key: string): any;
        /**
         * 清空参数
         * @param key 名称
         */
        clearValue(context: logicchart.trigger.Context, key: string): void;
        /**
         * 有参数？
         * @param key 名称
         */
        hasValue(context: logicchart.trigger.Context, key: string): boolean;
        /**
         * 设置数组参数
         * @param context
         * @param key 名称
         * @param argv 值列表
         */
        setArray(context: logicchart.trigger.Context, key: string, ...argv: any[]): void;
        /**
         * 数组中读取参数
         * @param key 名称
         * @param index 索引
         */
        getValueInArray(context: logicchart.trigger.Context, key: string, index: number): any;
        /**
         * 数组长度
         * @param key 名称
         */
        getArrayLength(context: logicchart.trigger.Context, key: string): number;
        /**
         * 视图回调
         * @param context
         * @param key 名称
         * @param argv 值列表
         */
        callback(context: logicchart.trigger.Context, method: string, key: string, ...argv: any[]): void;
        /**
         * 打印日志
         * @param argv 内容
         */
        log(context: logicchart.trigger.Context, ...argv: any[]): void;
        /**
         * 延时
         * @param slotMap finish->$timems;
         * @param duration 时长
         */
        delay(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, duration: number): void;
        /**
         * 延时帧
         * @param slotMap finish->$timems;
         * @param fps 帧数
         */
        delayFPS(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, fps: number): void;
        /**
         * 恢复血量
         * @param from 治疗的来源
         * @ignore
         */
        onHealBlood(blood: number, who: Hero, from: HealFrom, source: any): void;
        /**
         * 恢复血量
         * @ignore
         */
        onHealBloodRaw(blood: number, who: Hero, from: HealFrom, source: any): number;
        /**
         * 直接扣除自身血量
         * @ignore
         * @param blood
         */
        onCutOffBlood(blood: number): void;
        /**
         * 吸血
         * @ignore
         */
        onSuckBlood(blood: number, source: any): void;
        /**
         * 判定技能能量
         * @ignore
         */
        isPowerEnough(skill: SkillData): boolean;
        /**
         * 事件管理
         * @ignore
         */
        eventHandlerRegister: logicchart.statetree.EventHandlerRegister;
        /**
         * 击杀者
         */
        killer?: Hero;
        /**
         * 击杀助攻
         * @ignore
         */
        protected _killerAssistants: {
            who: Hero;
            when: number;
        }[];
        /**
         * @ignore
         */
        get killerAssistants(): {
            who: Hero;
            when: number;
        }[];
        set killerAssistants(value: {
            who: Hero;
            when: number;
        }[]);
        /**
         * 获取伤害、治疗等效果的来源，用于日志记录
         * @ignore
         */
        getActionSource(context: logicchart.trigger.Context, who?: Hero): any;
        protected _hurtValue: number;
        /**
         * 设置受伤值
         * @param value 值
         */
        setHurtValue(context: logicchart.trigger.Context, value: number): void;
        /**
         * 读取受伤值
         */
        getHurtValue(context: logicchart.trigger.Context): number;
        protected _periodBuffValue: number;
        /**
         * 设置周期性Buff效果值
         * @param value 值
         */
        setPeriodBuffValue(context: logicchart.trigger.Context, value: number): void;
        /**
         * 读取周期性Buff效果值
         */
        getPeriodBuffValue(context: logicchart.trigger.Context): number;
        /**
         * 受到伤害
         */
        hurt(context: logicchart.trigger.Context, value: number, who: Hero | undefined): void;
        protected _defaultSkillSession: SkillSession;
        /**
         * @ignore
         */
        protected getSkillSession(context: logicchart.trigger.Context): SkillSession;
        /**
         * 承伤英雄
         * @ignore
         */
        acceptInjuryHero: Hero | undefined;
        /**
         * 受到伤害
         * @ignore
         */
        hurtRaw(context: logicchart.trigger.Context, value: number, who: Hero | undefined, source: any | undefined, specialHurt?: boolean, acceptInjury?: boolean): void;
        /**
         * 是否已死亡
         */
        isDie(context: logicchart.trigger.Context): boolean;
        /**
         * 自杀
         */
        killSelf(context: logicchart.trigger.Context): void;
        protected _checkDie(context: logicchart.trigger.Context, who: Hero | undefined, source: any | undefined, realHurtValue: number): void;
        /**
         * 复活
         * @param hp 复活血量
         */
        revive(context: logicchart.trigger.Context, hp: number): void;
        /**
         * 强制打断施法
         */
        interruptSkillForce(context: logicchart.trigger.Context): void;
        /**
         * 被打断
         * @ignore
         */
        interruptSkill(context: logicchart.trigger.Context): void;
        protected _destroyObjects: GameObject[];
        /**
         * 设定当技能打断时销毁
         */
        addDestroyObjectWhenInterruptSkill(context: logicchart.trigger.Context, obj: GameObject): void;
        /**
         * 获取英雄对象id
         * @ignore
         */
        getHeroObjectId(context: logicchart.trigger.Context): string;
        /**
         * 检查状态是否存在
         * @ignore
         * @param state 状态的名称
         * @returns 状态是否为true
         */
        checkState(context: logicchart.trigger.Context, state: string): boolean;
        /**
         * 播放角色动画
         * @ignore
         * @param name 动画名
         * @param loop 是否循环
         */
        playAnim(context: logicchart.trigger.Context, name: string, loop?: boolean): void;
        /**
         * 属性
         * @ignore
         * @param context 上下文
         * @param property 属性
         */
        getProperty(context: logicchart.trigger.Context, property: HeroProperty): any;
        /**
         * 按规则选定技能
         * - 按照技能优先级顺序
         * - 依次检查技能冷却时间和攻击间隔
         * - 技能内置条件
         * - 来确定技能
         * - 如果没有可用的技能，使用普攻保底
         */
        selectSkill(context: logicchart.trigger.Context): void;
        /**
         * 创建目标容器
         * @param context
         * @param slotMap ok->->{"$name":{"describe":"目标容器","type":"HeroSelector"}}
         * @param name 目标容器名称
         */
        createSelector(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, name?: string): void;
        /**
         * 召唤英雄
         * @param context
         * @param slotMap ok->->{"$name":{"describe":"召唤物","type":"Hero"}}
         * @param name 召唤物名称
         * @param heroConfigId 召唤物配表里的英雄id
         * @param positionX 英雄横坐标（绝对坐标）
         * @param positionY 英雄纵坐标（绝对坐标）
         */
        summonHero(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, name: string, heroConfigId: string, position: Point): void;
        /**
         * 指定英雄位置召唤英雄
         * @param context
         * @param slotMap ok->->{"$name":{"describe":"召唤物","type":"Hero"}}
         * @param name 召唤物名称
         * @param heroConfigId 召唤物配表里的英雄id
         * @param target 英雄
         * @param count 数量
         */
        summonHeroInHero(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, name: string, heroConfigId: string, target: Hero, count?: number): void;
        /**
         * 指定位置召唤英雄
         * @param context
         * @param slotMap ok->->{"$name":{"describe":"召唤物","type":"Hero"}}
         * @param name 召唤物名称
         * @param heroConfigId 召唤物配表里的英雄id
         * @param x x坐标
         * @param y y坐标
         * @param count 数量
         */
        summonHeroByPosition(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, name: string, heroConfigId: string, x: number, y: number, count?: number): void;
        isBSkillSelected(): boolean;
        /**
         * 大招是否激活
         * @ignore
         */
        isBSkillAvailable(): boolean;
        /**
         * 判定攻击间隔
         * @param context
         */
        isSkillUsable(context: logicchart.trigger.Context): boolean;
        /**
         * 技能是否启用
         * @param context
         */
        isSkillEnabled(context: logicchart.trigger.Context): boolean;
        /**
         * 获取距离
         */
        getTargetDistance(context: logicchart.trigger.Context, target: Hero): number;
        /**
         * 获取到指定点的距离
         */
        getDistance(context: logicchart.trigger.Context, position: Point): number;
        /**
         * 按规则选定目标
         */
        filterTarget(context: logicchart.trigger.Context): void;
        /**
         * 判定攻击距离
         */
        checkTargetDistance(context: logicchart.trigger.Context): boolean;
        /**
         * 获取正在攻击的目标
         * @param context
         * @param slotMap ok->->{"$name":{"describe":"目标容器","type":"HeroSelector"}}
         * @param name 目标容器名称
         */
        getAttackingTargets(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, name?: string): void;
        /**
         * 检查与目标最近距离
         */
        checkTargetNearestDistance(context: logicchart.trigger.Context): boolean;
        /**
         * 背离目标移动
         */
        leaveTarget(context: logicchart.trigger.Context): boolean;
        /**
         * 锁定移动方向
         */
        lockMoveDirection(context: logicchart.trigger.Context): void;
        /**
         * 解锁移动方向
         */
        unlockMoveDirection(context: logicchart.trigger.Context): void;
        /**
         * 设置攻击额外值
         */
        setAttackExtra(context: logicchart.trigger.Context, value: number): void;
        /**
         * 复位攻击额外值
         */
        clearAttackExtra(context: logicchart.trigger.Context): void;
        /**
         * 触发技能
         */
        useSkill(context: logicchart.trigger.Context): void;
        /**
         * 驱除buff
         * @param buffSide 立场
         */
        removeBuffs(context: logicchart.trigger.Context, buffSide: BuffSide): void;
        /**
         * 获取当前ai tree中选择的目标
         * @ignore
         */
        getCurrentTarget(): Hero | undefined;
        /**
         * 获取正在攻击的目标
         */
        getCurrentAttackTarget(context: logicchart.trigger.Context): Hero;
        /**
         * 正在调整攻击站位
         * @ignore
         */
        isSeekingTarget: boolean;
        protected _isMoveDirectionLock: boolean;
        protected _lastPositions: {
            [key: string]: boolean;
        };
        /**
         * 向默认目标移动
         */
        moveToDefaultTarget(context: logicchart.trigger.Context): boolean;
        /**
         * 向目标移动
         */
        moveToTarget(context: logicchart.trigger.Context, target: Hero): void;
        /**
         * 追踪移动到目标
         * @param slotMap onfinish->移动到位->{};
         * @param speed 移动速度
         */
        seekToTarget(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, speed: number, target: any): void;
        /**
         * 直线位移动作
         * @ignore
         */
        protected moveAction?: MoveAction;
        /**
         * 追踪位移动作
         * @ignore
         */
        protected seekingAction?: SeekingAction;
        /**
         * 正弦位移动作
         * @ignore
         */
        protected sinAction?: SinAction;
        /**
         * 直线移动
         * @param angle 移动角度，右手螺旋
         * @param distance 距离
         * @param speed 速度
         * @param outScreen 能否出屏幕
         */
        moveByDirection(context: logicchart.trigger.Context, angle: number, distance: number, speed: number, outScreen?: boolean): void;
        protected _isMoveUp: boolean;
        /**
         * 抛起
         * @param slotMap onfinish->移动结束触发
         * @param offsetX 横坐标偏移
         * @param height 高度
         * @param duration 时长
         */
        moveSinAction(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, offsetX: number, height: number, duration: number): void;
        /**
         * 纵向移动
         * @param slotMap onfinish->移动结束触发
         * @param offsetY 纵坐标偏移
         * @param minY 纵坐标最小值
         * @param maxY 纵坐标最大值
         * @param speed 速度
         */
        moveByOffsetY(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, offsetY: number, minY: number, maxY: number, speed: number): void;
        /**
         * 丢出飞行道具
         * @param context 当前上下文
         * @param slotMap oncollide->碰撞触发->{"targetsSelector":{"describe":"碰撞目标选择器","type":"HeroSelector"},"triggerData":{"describe":"触发数据","type":"CollideTriggerData"}}
         * @param effectId 飞行道具id
         * @param radius 飞行物碰撞半径
         * @param flyRoute 飞行轨迹
         * @param distance 飞行距离
         * @param duration 飞行时间
         * @param repeatTimes 循环次数，默认 1 次
         */
        callupFlyWoodsHSEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, effectId: string, flyRoute: FlyRoute, distance: number, duration: number, radius: number, repeatTimes?: number): void;
        /**
         * 沿抛物线丢出道具
         * @param context 当前上下文
         * @param slotMap oncollide->到达目的->{"targetsSelector":{"describe":"碰撞目标选择器","type":"HeroSelector"},"triggerData":{"describe":"触发数据","type":"CollideTriggerData"}}
         * @param effectId 飞行道具id
         * @param target 目标
         * @param height 高度
         * @param duration 用时
         */
        callupFlyParabolicCurveHSEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, effectId: string, target: Hero, height: number, duration: number): void;
        /**
         * 丢出指向性飞行道具
         * @param context 当前上下文
         * @param slotMap oncollide->碰撞触发->{};onfinish->结束->{}
         * @param effectId 飞行道具id
         * @param flyRoute 飞行轨迹
         * @param speed 飞行速度
         * @param target 目标英雄
         * @param angularSpeed 飞行角速度
         */
        callupTargetedFlyWoodsHSEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, effectId: string, flyRoute: FlyRoute, speed: number, target: Hero, angularSpeed?: number): void;
        /**
         * 瞬移
         * @param target 目标英雄
         * @param direction 相对目标的位置，1：正面，-1：背面
         * @param distance 相对目标当前朝向的横向位置
         */
        locateToTarget(context: logicchart.trigger.Context, target: Hero, direction: number, distance: number): void;
        /**
         * 瞬移到目标前面
         * @param target 目标英雄
         * @param distance 相对目标当前朝向的横向位置
         */
        locateToTargetFront(context: logicchart.trigger.Context, target: Hero, distance: number): void;
        /**
         * 瞬移到目标背面
         * @param target 目标英雄
         * @param distance 相对目标当前朝向的横向位置
         */
        locateToTargetBack(context: logicchart.trigger.Context, target: Hero, distance: number): void;
        /**
         * 瞬移到指定位置
         * @param x 指定x轴坐标
         * @param y 指定x轴坐标
         */
        locateToXY(context: logicchart.trigger.Context, x: number, y: number): void;
        protected _recordX: number;
        protected _recordY: number;
        /**
         * 记录X坐标
         */
        recordX(context: logicchart.trigger.Context): void;
        /**
         * 记录Y坐标
         */
        recordY(context: logicchart.trigger.Context): void;
        /**
         * 获取记录的X坐标
         */
        getRecordX(context: logicchart.trigger.Context): number;
        /**
         * 获取记录的Y坐标
         */
        getRecordY(context: logicchart.trigger.Context): number;
        /**
         * 获取初始的X坐标
         */
        getEnterFinishX(context: logicchart.trigger.Context): number;
        /**
         * 获取初始的Y坐标
         */
        getEnterFinishY(context: logicchart.trigger.Context): number;
        /**
         * 获取站位ID
         */
        getBattleNo(context: logicchart.trigger.Context): number;
        /**
         * 待机
         * @param context
         */
        enterIdle(context: logicchart.trigger.Context): void;
        /**
         * 待机2
         * @param context
         */
        enterIdle2(context: logicchart.trigger.Context, anim: string): void;
        /**
         * 受击
         * @param context
         * @param slotMap onhit->作用点触发->{"target":{"describe":"目标英雄","type":"Hero"},"hero":{"describe":"来源英雄","type":"Hero"}}
         * @param who 来源英雄
         * @param hitPos 受击位置
         */
        enterOnHitState(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, who: Hero): void;
        /**
         * 被击倒
         * @param context
         * @param duration 时长（毫秒）
         */
        enterKnockOffState(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 被击退
         * @param context
         * @param direction 方向 -1左 1右
         * @param distance 距离
         * @param duration 时长（毫秒）
         */
        enterKnockBackState(context: logicchart.trigger.Context, direction: HeroDirection, distance: number, duration: number): void;
        /**
         * 被击飞
         * @param context
         * @param direction 方向 -1左 1右
         * @param distance 距离
         * @param height 高度
         * @param duration 时长（毫秒）
         */
        enterKnockFlyState(context: logicchart.trigger.Context, direction: HeroDirection, distance: number, height: number, duration: number): void;
        /**
         * 消耗能量
         * @param power 消耗的能量值
         */
        consoumePower(context: logicchart.trigger.Context, power: number): void;
        /**
         * 增加能量
         * @param power 能量值
         */
        chargePower(context: logicchart.trigger.Context, power: number, from?: PowerFrom): void;
        /**
         * 消耗所有能量
         * @param power 消耗的能量值
         */
        clearPower(context: logicchart.trigger.Context): void;
        /**
         * 攻击
         * @param name 动画名
         * @param loop 是否循环
         */
        playAttackAnim(context: logicchart.trigger.Context, name: string, loop?: boolean): void;
        /**
         * 位移
         * @param name 动画名
         * @param loop 是否循环
         */
        playMoveAnim(context: logicchart.trigger.Context, name: string, loop?: boolean): void;
        /**
         * 恢复血量
         */
        healSelf(context: logicchart.trigger.Context, hp: number, source: any): void;
        /**
         * 损失血量
         * @param context
         * @param hp 血量
         */
        cutOffBloodSelf(context: logicchart.trigger.Context, hp: number): void;
        /**
         * 计算物理伤害
         * @param who 攻击者
         * @param k 系数
         */
        calcPhysicHurt(context: logicchart.trigger.Context, who: Hero | undefined, k: number): number;
        /**
         * 计算魔法伤害
         * @param who 攻击者
         * @param k 系数
         */
        calcMagicHurt(context: logicchart.trigger.Context, who: Hero | undefined, k: number): number;
        /**
         * 计算恢复血量
         * @param who 攻击者
         * @param k 系数
         */
        calcHeal(context: logicchart.trigger.Context, who: Hero | undefined, k: number): number;
        /**
         * 当前技能等级
         */
        getCurrentSkillLevel(context: logicchart.trigger.Context): number;
        /**
         * 当前技能品质
         */
        getCurrentSkillQuality(context: logicchart.trigger.Context): SkillQuality.None | SkillQuality;
        /**
         * 增加治疗触发点
         * @param slotMap onhandle->治疗触发->{"triggerData":{"describe":"触发数据","type":"HeroTriggerData"}};
         */
        addOnHealTrigger(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP): void;
        /**
         * 进入特写
         */
        enterCloseUp(context: logicchart.trigger.Context): void;
        /**
         * 强制进入特写
         */
        enterCloseUpForce(context: logicchart.trigger.Context): void;
        /**
         * 结束特写
         */
        leaveCloseUp(context: logicchart.trigger.Context): void;
        /**
         * 跟随的目标
         * @ignore
         */
        followTarget: Hero | undefined;
        /**
         * 跟随间距
         * @ignore
         */
        followDistance: number;
        /**
         * 跟随英雄
         * @param target 目标英雄
         * @param distance 间距
         */
        followHero(context: logicchart.trigger.Context, target: Hero, distance: number): void;
        /**
         * 清理跟随英雄
         */
        clearFollowHero(context: logicchart.trigger.Context): void;
        /**
         * 隐藏
         */
        hideView(context: logicchart.trigger.Context): void;
        /**
         * 显示
         */
        showView(context: logicchart.trigger.Context): void;
        checkBuffList(): IBuffBase[];
        /**
         * @ignore
         */
        immuneBuffIds: {
            [key: string]: boolean;
        };
    }
}
declare namespace rpgfight {
    /**
    * 英雄属性设置助手
    */
    class HeroDataSetUIHelper {
        protected owner: Hero;
        /**
        * @param owner
        * @ignore
        */
        constructor(owner: Hero);
        /**
         * 设置生命值
         */
        setHp(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置最大生命
         */
        setHpMax(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置能量
         */
        setPower(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置最大能量
         */
        setPowerMax(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置攻击力
         */
        setAttack(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置防御力
         */
        setDefense(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置暴击率
         */
        setCritRate(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置暴击伤害
         */
        setCritHurt(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置命中
         */
        setHitRate(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置闪避
         */
        setDodgeRate(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置移动速度
         */
        setMoveSpeed(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置回血 战斗中每秒自动恢复的生命固定数值
         */
        setHpHealingSpeed(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置额外减少受到的魔法伤害
         */
        setExtraDefenseMagicHurt(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置额外减少受到的物理伤害
         */
        setExtraDefensePhysicalHurt(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置吸血等级
         */
        setSuckBloodLv(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置等级
         */
        setLevel(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置品阶
         */
        setRank(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置属于哪一方
         */
        setBattleTeam(context: logicchart.trigger.Context, value: BattleTeam): void;
        /**
         * 设置种族
         */
        setFaction(context: logicchart.trigger.Context, value: HeroFactionType): void;
        /**
         * 设置职业
         */
        setCareer(context: logicchart.trigger.Context, value: HeroCareerType): void;
        /**
         * 设置能量每秒恢复速度
         */
        setPowerChargeSpeedNormal(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置受击能量恢复速度
         */
        setPowerChargeSpeedWithHurt(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置攻击出手恢复能量
         */
        setPowerChargeSpeedWithUsingSkill(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置回能系数
         */
        setPowerSpeedupRate(context: logicchart.trigger.Context, value: number): void;
        /**
         * 设置普攻是否可用
         */
        setIsNormalAttackUsable(context: logicchart.trigger.Context, value: boolean): void;
        /**
         * 设置击杀恢复能量
         */
        setPowerChargeSpeedWithKilling(context: logicchart.trigger.Context, value: number): void;
    }
}
declare namespace rpgfight {
    class HurtOptions {
        /**
         * 数量
         */
        value: number;
        /**
         * 是否暴击
         */
        isCrit?: boolean;
    }
    enum HealFrom {
        /**
         * 自身属性恢复
         */
        Self = 0,
        /**
         * 技能恢复
         */
        Skill = 1,
        /**吸血恢复 */
        Suck = 2
    }
    class HealOptions {
        /**
         * 数量
         */
        value: number;
        /**
         * 原因
         */
        from: HealFrom;
    }
    enum PowerFrom {
        /**
         * 技能恢复
         */
        Skill = 0,
        /**
         * 每秒恢复
         */
        PerSecond = 1,
        /**
         * 受伤恢复
         */
        Hurt = 2,
        /**
         * 攻击恢复
         */
        Attack = 3,
        /**
         * 击杀恢复
         */
        Kill = 4,
        /**
         * BUFF恢复
         */
        Buff = 5
    }
    class PowerOptions {
        /**
         * 数量
         */
        value: number;
        /**
         * 原因
         */
        from: PowerFrom;
    }
    enum BuffEffectEnum {
        /**格挡 */
        Shield = 0,
        /**加速 */
        SpeedUp = 1,
        /**减速 */
        SpeedDown = 2,
        /**免疫 */
        Immune = 3,
        /**闪避 */
        Dodge = 4,
        /**攻击 */
        Attack = 5,
        /**防御 */
        Defense = 6,
        /**攻速 */
        AttackSpeed = 7
    }
    class BuffOptions {
        /**
         * BUFF类型
         */
        effect: BuffEffectEnum;
        /**
         * 技能
         */
        theSkill?: SkillData;
        /**
         * 数值
         */
        value?: number;
    }
    class KillOptions {
        /**
         * 被杀者
         */
        killedHero: Hero | undefined;
        /**
         * 击杀数量
         */
        killCount: number;
    }
    /**
     * 英雄特效相关帮助类
     */
    class HeroEffectUIHelper {
        /**
         * 英雄
         * @ignore
         */
        hero: Hero;
        /**
         * effectView
         * @ignore
         */
        sharedEffectView: SharedEffectView;
        constructor(
        /**
         * 英雄
         * @ignore
         */
        hero: Hero);
        /**
         * 展示伤害值
         * @param name
         */
        playHurtEffect(options: HurtOptions): void;
        /**
         * 展示治疗量
         * @param name
         */
        playHealEffect(options: HealOptions): void;
        /**
         * 展示回能量
         * @param options
         */
        playPowerEffect(options: PowerOptions): void;
        /**
         * 展示Buff效果
         * @param options
         */
        playBuffEffect(options: BuffOptions): void;
        /**
         * 展示Buff效果
         * @param options
         */
        playKillEffect(options: KillOptions): void;
        /**
         * 展示黑色遮罩
         * @param opacity 透明度
         * @param duration 时长
         */
        playMaskEffect(context: logicchart.trigger.Context, opacity: number, duration: number): void;
        /**
         * 播放特效
         * @param context
         * @param name 特效名称
         * @param duration 播放时长，默认 1200ms
         * @param position 绝对坐标
         * @param rotation 角度
         * @param isDebuff 负面效果
         */
        playHSEffect(context: logicchart.trigger.Context, name: string, duration: number, position?: Point, rotation?: number, isDebuff?: boolean): void;
        /**
         * 指定位置播放特效
         * @param context
         * @param name 特效名称
         * @param duration 播放时长，默认 1200ms
         * @param x x坐标
         * @param y y坐标
         * @param rotation 角度
         * @param isDebuff 负面效果
         */
        playHSEffectEx(context: logicchart.trigger.Context, name: string, duration: number, x?: number, y?: number, rotation?: number, isDebuff?: boolean): void;
        /**
         * 移除特效
         * @param context
         * @param name 特效名称
         */
        removeHSEffect(context: logicchart.trigger.Context, name: string): void;
        /**
         * 播放音效
         * @param name 名称
         * @param loop 循环
         */
        playAudio(context: logicchart.trigger.Context, name: string, loop?: boolean): void;
        /**
         * 创建特效对象
         * @param context
         * @param slotMap ok->->{"$name":{"describe":"目标容器","type":"CustomSkillEffect"}}
         * @param name 特效对象名称
         */
        createEffectObject(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, name: string, effectId: string): void;
        release(): void;
    }
}
declare namespace rpgfight {
    class HeroSelector {
        /**
         * hero
         * @ignore
         */
        hero: Hero;
        /**
         * 目标集合
         * @ignore
         */
        selectedTargetList: Hero[];
        /**
         * buff助手
         */
        buffUIHelper: HeroSelectorBuffUIHelper;
        /**
         * buff设计助手
         */
        buffDesignUIHelper: HeroSelectorBuffDesignUIHelper;
        /**
         * 特效助手
         */
        effectHelper: HeroSelectorEffectUIHelper;
        constructor(
        /**
         * hero
         * @ignore
         */
        hero: Hero);
        selectAvailableTargetRaw(): Hero[];
        /**
         * 复制当前选择器
         * @param context
         * @param slotMap ok->->{"$name":{"describe":"目标容器","type":"HeroSelector"}}
         * @param name 目标容器名称
         */
        cloneSelector(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, name?: string): void;
        /**
         * 圈选
         */
        filterHerosInCircleShapeAroundTargetRaw(targets: Hero[], cadidates: Hero[], radius: number): Hero[];
        /**
         * 选择矩形范围内的英雄
         * @param x 中心点X
         * @param y 中心点Y
         * @param width 矩形宽
         * @param height 矩形高
         */
        filterHeroesByRectangle(context: logicchart.trigger.Context, x: number, y: number, width: number, height: number): void;
        /**
         * 框选
         */
        filterHerosInRectangleShapeBeforeTargetRaw(width: number, height: number, angle: number): Hero[];
        /**
         * 过滤指定的英雄
         * @ignore
         * @param context
         */
        filterHero(context: logicchart.trigger.Context, hero: Hero | Hero[]): void;
        /**
         * 根据英雄某个属性进行排序
         * @ignore
         * @param context 上下文
         * @param property 所使用的属性
         * @param max 是否按最大的排序，否则最小
         */
        orderTargetByProperty(context: logicchart.trigger.Context, property: HeroProperty, max: boolean): boolean;
        /**
         * 按顺序保留一定数量的目标
         * @ignore
         * @param context
         * @param count
         */
        retain(context: logicchart.trigger.Context, count: number): void;
        /**
         * 获取英雄
         * @ignore
         * @param context
         * @param slotMap findOut->得到英雄;notFound->没找到
         * @param index 索引
         */
        getHero(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, index: number): void;
        /**
         * 获取当前所有英雄
         * @ignore
         * @param context
         */
        getAllHero(context: logicchart.trigger.Context): Hero[];
        /**
         * 获取所有英雄（不含自己）
         */
        getAllHeroWithoutSelf(context: logicchart.trigger.Context): void;
        /**
         * 获取英雄数量
         * @ignore
         * @param context
         */
        getHeroCount(context: logicchart.trigger.Context): number;
        /**
         * 不含自己所有敌军数量
         * @ignore
         */
        getEnermyCount(context: logicchart.trigger.Context): number;
        /**
         * 不含自己所有友军数量
         * @ignore
         */
        getCompanionCount(context: logicchart.trigger.Context): number;
        /**
         * 过滤可选中英雄
         * @ignore
         * - 默认已经都只对可选中英雄操作
         */
        filterSelectableHeros(context: logicchart.trigger.Context): void;
        /**
         * 是否自动释放大招
         */
        isAutoSkill(context: logicchart.trigger.Context): boolean;
        /**
         * 是否还存在任何目标
         */
        isAnyTargetExist(context: logicchart.trigger.Context): boolean;
        /**
         * 已选择英雄数量
         */
        getSelectedHerosCount(context: logicchart.trigger.Context): number;
        /**
         * 恢复自身血量
         * @ignore
         */
        healSelf(context: logicchart.trigger.Context, hp: number): void;
        /**
         * 调整英雄朝向
         */
        adjustDirectionForSkills(context: logicchart.trigger.Context): void;
        /**
         * 按规则选定目标
         */
        filterTarget(context: logicchart.trigger.Context): void;
        /**
         * 临时X轴坐标
         */
        tempX: number;
        /**
         * 临时Y轴坐标
         */
        tempY: number;
        /**
         * 获取躲藏的位置
         */
        getHidingPosition(context: logicchart.trigger.Context): ml.Point;
        /**
         * 是否有友军存活
         * @param count 个数
         */
        isAnyCompanionAlive(context: logicchart.trigger.Context, count?: number): boolean;
        /**
         * 是否有敌军存活
         * @param count 个数
         */
        isAnyEnermyAlive(context: logicchart.trigger.Context, count?: number): boolean;
        /**
         * 按距离排序
         * @param context 上下文
         * @param nearest TRUE表示从近到远
         */
        orderTargetByDistance(context: logicchart.trigger.Context, nearest: boolean): boolean;
        /**
         * 选定所有敌人
         */
        filterEnermies(context: logicchart.trigger.Context): void;
        /**
         * 选定敌方前排英雄
         */
        filterFrontEnermies(context: logicchart.trigger.Context): void;
        /**
         * 选定敌方后排英雄
         */
        filterBackEnermies(context: logicchart.trigger.Context): void;
        /**
         * 预选所有存活英雄
         */
        selectAllHeros(context: logicchart.trigger.Context): void;
        /**
         * 选定所有友军（包含自己）
         */
        filterCompanionWithSelf(context: logicchart.trigger.Context): void;
        /**
         * 选定所有友军
         */
        filterCompanion(context: logicchart.trigger.Context): void;
        /**
         * 选定我方前排英雄
         */
        filterFrontSelf(context: logicchart.trigger.Context): void;
        /**
         * 选定我方后排英雄
         */
        filterBackSelf(context: logicchart.trigger.Context): void;
        /**
         * 选择敌方阵营克制英雄
         */
        fitlerRestrainHeros(context: logicchart.trigger.Context): void;
        /**
         * 选定随机N个
         * @param context
         * @param count N个
         */
        selectRandomHeros(context: logicchart.trigger.Context, count: number): void;
        /**
         * 选定圆形范围
         * @param context
         * @param radius 半径
         */
        filterHerosInCircleShapeAroundSelf(context: logicchart.trigger.Context, radius: number): void;
        /**
         * 选定前方矩形范围
         * @param context
         * @param width 宽度
         * @param height 长度
         * @param angle 角度
         */
        filterHerosInRectangleShapeBeforeSelf(context: logicchart.trigger.Context, width: number, height: number, angle: number): void;
        /**
         * 选定目标圆形范围
         * @param context
         * @param radius 半径
         */
        filterHerosInCircleShapeAroundTarget(context: logicchart.trigger.Context, radius: number): void;
        /**
         * 选定最靠前的英雄
         * @param context
         */
        filterFrontHero(context: logicchart.trigger.Context): void;
        /**
         * 选定最近1个
         */
        filterTheNearestHero(context: logicchart.trigger.Context): void;
        /**
         * 选定最近N个
         * @param count N个
         */
        filterNearestHeros(context: logicchart.trigger.Context, count: number): void;
        /**
         * 选定最远1个
         */
        filterTheFarestHero(context: logicchart.trigger.Context): void;
        /**
         * 选定最远N个
         * @param count N个
         */
        filterFarestHeros(context: logicchart.trigger.Context, count: number): void;
        /**
         * 选定血量最多N个
         * @param count N个
         */
        filterHerosByHpDes(context: logicchart.trigger.Context, count: number): void;
        /**
         * 选定血量最少N个
         * @param count N个
         */
        filterHerosByHealth(context: logicchart.trigger.Context, count: number): void;
        /**
         * 选定能量最多N个
         * @param count N个
         */
        filterHerosByPower(context: logicchart.trigger.Context, count: number): void;
        /**
         * 选定攻击力最高N个
         * @param count N个
         */
        filterHerosByAttack(context: logicchart.trigger.Context, count: number): void;
        /**
         * 选定防御最低N个
         * @param count N个
         */
        filterHerosByDefense(context: logicchart.trigger.Context, count: number): void;
        /**
         * 选择某种族英雄
         */
        filterHerosByFaction(context: logicchart.trigger.Context, faction: HeroFactionType): void;
        /**
         * 选择某职业英雄
         */
        filterHerosByCareer(context: logicchart.trigger.Context, career: HeroCareerType): void;
        /**
         * 选择非某职业英雄
         */
        filterHerosByCareerNot(context: logicchart.trigger.Context, career: HeroCareerType): void;
        /**
         * 选择某类型英雄
         */
        filterHerosByType(context: logicchart.trigger.Context, type: HeroType): void;
        /**
         * 历史选择过的英雄
         */
        protected selectedHerosEver: Hero[];
        protected currentReselectRange?: Hero[];
        /**
         * 选择不重复的英雄
         * @param context
         * @param count 数量，不填则不限制数量
         */
        filterNoRepeatHeros(context: logicchart.trigger.Context, count: number): void;
        /**
         * 选择血量低于某值英雄
         * @param value 百分比
         */
        filterHerosWithLessBlood(context: logicchart.trigger.Context, value: number): void;
        /**
         * 选择血量高于某值英雄
         * @param value 百分比
         */
        filterHerosWithMoreBlood(context: logicchart.trigger.Context, value: number): void;
        /**
         * 选择能量低于某值英雄
         * @param value 百分比
         */
        filterHerosWithLessPower(context: logicchart.trigger.Context, value: number): void;
        /**
         * 选择能量高于某值英雄
         * @param value 百分比
         */
        filterHerosWithMorePower(context: logicchart.trigger.Context, value: number): void;
        /**
         * 选择存在负面buff的英雄
         */
        filterHerosWithDebuff(context: logicchart.trigger.Context): void;
        /**
         * 选择对称站位的英雄
         */
        filterHeroOnTheOpposite(context: logicchart.trigger.Context): void;
        /**
         * 选出等级或品阶低于自己的英雄
         */
        filterHerosWithLowerLevelOrRank(context: logicchart.trigger.Context): void;
        /**
         * 选择当前正在攻击的英雄
         */
        filterHerosWithAttackState(context: logicchart.trigger.Context): void;
        /**
         * 选择优先攻击的英雄
         */
        filterFirstAttackTargets(context: logicchart.trigger.Context): void;
        /**
         * 选择战斗力最高的英雄
         */
        filterHighestFightPowerTarget(context: logicchart.trigger.Context): void;
        /**
         * 选择战斗力最低的英雄
         */
        filterLowestFightPowerTarget(context: logicchart.trigger.Context): void;
        /**
         * 选择是否免疫控制的英雄
         * @param isImmuneControl 是否免疫控制
         */
        filterImmuneControlTargets(context: logicchart.trigger.Context, isImmuneControl: boolean): void;
        /**
         * 是否存在攻击距离内的英雄
         */
        checkTargetDistance(context: logicchart.trigger.Context): boolean;
        /**
         * 本次击杀英雄数量
         * @param context
         */
        getKilledHerosCount(context: logicchart.trigger.Context): number;
        /**
         * 目标受击
         * @param slotMap onhit->作用点触发->{"target":{"describe":"目标英雄","type":"Hero"},"hero":{"describe":"来源英雄","type":"Hero"}}
         */
        makeTargetsEnterOnHitState(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP): void;
        /**
         * 目标被击倒
         * @param duration 时长（毫秒）
         */
        makeTargetsEnterKnockOffState(context: logicchart.trigger.Context, duration: number): void;
        /**
         * 目标被击退
         * @param direction 方向 -1左 1右
         * @param distance 距离
         * @param duration 时长（毫秒）
         */
        makeTargetsEnterKnockBackState(context: logicchart.trigger.Context, direction: number, distance: number, duration: number): void;
        /**
         * 目标被击飞
         * @param direction 方向 -1左 1右
         * @param distance 距离
         * @param height 高度
         * @param duration 时长（毫秒）
         */
        makeTargetsEnterKnockFlyState(context: logicchart.trigger.Context, direction: number, distance: number, height: number, duration: number): void;
        /**
         * 高亮
         */
        highlight(context: logicchart.trigger.Context): void;
        /**
         * 瞬移
         * @param direction 相对目标的位置，1：正面，-1：背面
         * @param distance 相对目标当前朝向的横向位置
         */
        locateToTarget(context: logicchart.trigger.Context, direction: number, distance: number): boolean;
        /**
         * 追踪移动到目标
         * @param slotMap onfinish->移动到位->{};
         * @param speed 移动速度
         */
        seekToTarget(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, speed: number): void;
        /**
         * 向目标丢出远程普攻道具
         * @param context 当前上下文
         * @param slotMap oncollide->$name;
         * @param effectId 飞行道具id
         * @param speed 飞行速度
         */
        callupFlyAttackHSEffect(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP, effectId: string, speed: number): void;
        /**
         * 目标回血
         * @param context
         * @param value 伤害的数值
         */
        heal(context: logicchart.trigger.Context, value: number): void;
        /**
         * 增加能量
         * @param power 能量值
         */
        chargePower(context: logicchart.trigger.Context, power: number): void;
        /**
         * 消耗能量
         * @param power 消耗的能量值
         */
        consoumePower(context: logicchart.trigger.Context, power: number): void;
        /**
         * 目标受伤
         * @param context
         * @param value 伤害的数值
         */
        hurt(context: logicchart.trigger.Context, value: number): void;
        /**
         * 获取伤害、治疗等效果的来源，用于日志记录
         * @ignore
         */
        getActionSource(context: logicchart.trigger.Context): any;
        /**
         * 遍历处理目标
         * @param slotMap onhandle->遍历->{"target":{"describe":"目标单位","type":"Hero"},"hero":{"describe":"容器创建者","type":"Hero"}};
         */
        foreachTargets(context: logicchart.trigger.Context, slotMap: logicchart.trigger.SLOTMAP): void;
        /**
         * 隐藏
         */
        hideView(context: logicchart.trigger.Context): void;
        /**
         * 显示
         */
        showView(context: logicchart.trigger.Context): void;
    }
}
declare namespace rpgfight {
    class HeroSelectorEffectUIHelper {
        /**
         * 英雄选择器
         * @ignore
         */
        selector: HeroSelector;
        constructor(
        /**
         * 英雄选择器
         * @ignore
         */
        selector: HeroSelector);
        /**
         * 播放特效
         * @param context
         * @param name 特效名称
         */
        playHSEffect(context: logicchart.trigger.Context, name: string, time: number, position?: Point): void;
        /**
         * 指定位置播放特效
         * @param context
         * @param name 特效名称
         */
        playHSEffectEx(context: logicchart.trigger.Context, name: string, time: number, x?: number, y?: number, rotation?: number): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄状态辅助管理
     */
    class HeroStateHelper {
        hero: Hero;
        constructor(hero: Hero);
        update(dt: number): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄站位坐标助手
     */
    class HeroStationUIHelper {
        protected owner: Hero;
        /**
         * @param owner
         * @ignore
         */
        constructor(owner: Hero);
        /**
         * 转为绝对坐标
         */
        getAbsolutePostionWithHeroRelativePosition(context: logicchart.trigger.Context, positionX?: number, positionY?: number): any;
        /**
         * 包装坐标
         * @param positionX 横坐标
         * @param positionY 纵坐标
         * @param isRelyOnHero 是否跟随英雄
         */
        wrapPoint(context: logicchart.trigger.Context, positionX?: number, positionY?: number, isRelyOnHero?: boolean): Point;
    }
}
declare namespace rpgfight {
    /**
     * 存活对象接口
     * - 英雄
     * - buff effect
     */
    interface ILiveObject {
        isAlive: boolean;
        objectId: string;
    }
}
declare namespace rpgfight {
    class NormalSelector {
        owner?: GameObject | null;
        constructor(owner?: GameObject);
    }
}
declare namespace rpgfight {
    class Scene extends GameObject {
        sceneData: SceneData;
        constructor(runner: Runner, sceneData: SceneData);
    }
}
declare namespace rpgfight {
    class SkillSessionUIHelper {
        protected owner: Hero;
        /**
         * @param owner
         * @ignore
         */
        constructor(owner: Hero);
        /**
         * @ignore
         */
        protected getSkillSession(context: logicchart.trigger.Context): SkillSession;
        /**
         * 设置目标受击能量恢复比率
         * @param context
         * @param enhanceRate 比率
         */
        setSkillPowerChargeRateWithHurtForTarget(context: logicchart.trigger.Context, enhanceRate: number): void;
    }
}
declare namespace rpgfight {
    interface IntervalIdInfo {
        id: number;
    }
    /**
     * 帧刷定时器
     */
    class UpdateTimer {
        /**
         * 每一帧的长度，毫秒
         */
        readonly frameStep = 40;
        /**
         * 当前逻辑帧数
         */
        protected _frameCount: number;
        /**
         * 毫秒
         */
        protected _currentTime: number;
        /**
         * 延时时间
         */
        protected _timeoutId: number;
        protected _timeoutList: {
            id: number;
            callback: () => void;
            startTime: number;
            delay: number;
            valid: boolean;
        }[];
        /**
         * 计时速率
         */
        timeScale: number;
        protected _paused: boolean;
        pause(): void;
        resume(): void;
        /**
         * 获取步长
         */
        getFrameStep(): number;
        /**
         * 用于可缩放速率计时
         */
        protected scalingZone: number;
        /**
         * 观测调试用
         */
        protected targetScalingZone: number;
        update(): void;
        _update(): void;
        get frameCount(): number;
        get currentTime(): number;
        /**
         * 延迟执行某个逻辑
         * @param callback 回掉函数
         * @param delay 延迟时间 毫秒
         */
        setTimeout(callback: () => void, delay: number): number;
        /**
         * duration 时间之后自动取消 interval
         */
        setIntervalWithDuration(callback: () => void, interval: number, duration: number): {
            id: number;
        };
        setInterval(callback: () => void, interval: number): {
            id: number;
        };
        clearInterval(info: IntervalIdInfo): void;
        protected _timerMap: {
            [key: string]: number;
        };
        protected _timerInfoMap: {
            [key: string]: {
                timerId: string;
                callback: () => void;
                delay: number;
                timerKey: string;
            };
        };
        protected getTimerKey(targetId: string, timerId: string): string;
        protected updateTimerInfo(timerKey: string, timerId: string, callback?: () => void, delay?: number): {
            timerId: string;
            callback: () => void;
            delay: number;
            timerKey: string;
        };
        /**
         * 开始或重新启动同一个定时器
         * @param target 依赖的对象id，如果target为ILiveObject，那么当target destory之后，callback不会再被调用
         * @param timerId 自定义定时器绑定id
         * @param callback 回调
         * @param delay 延迟
         */
        resetTimeoutFor(target: ILiveObject | string, timerId: string, callback?: () => void, delay?: number): void;
        /**
         * 清除定时器
         * @param target 依赖的对象id
         * @param timerId 自定义定时器绑定id
         */
        clearTimeoutFor(target: ILiveObject | string, timerId: string): void;
        setIntervalFor(target: ILiveObject | string, timerId: string, callback: () => void, interval: number): void;
        /**
         * 清除某个timeout
         * @param id
         */
        clearTimeout(id: number): void;
    }
}
declare namespace rpgfight {
    /**
     * 轨迹基类
     */
    abstract class FlyPath extends SkillEffect {
        curtime: number;
        distance: number;
        duration: number;
        onUpdate(dt: number): void;
        abstract updateCurrentPosition(dt: number): {
            position: ml.Point;
            destroy: boolean;
        };
        /**
         * 每帧回调
         */
        triggerCallback?: (pt: ml.Point) => void;
    }
}
declare namespace rpgfight {
    /**
     * 环绕
     */
    class FlyAround extends FlyPath {
        updateCurrentPosition(dt: number): {
            position: ml.Point;
            destroy: boolean;
        };
    }
}
declare namespace rpgfight {
    /**
     * 飞斧
     */
    class FlyAxe extends FlyPath {
        updateCurrentPosition(dt: number): {
            position: ml.Point;
            destroy: boolean;
        };
    }
}
declare namespace rpgfight {
    /**
     * 追踪型远程普攻
     */
    class FlyBackMissile extends FlyPath {
        owner: Hero;
        /**
         * 来源技能
         */
        skillData: SkillData;
        target: Hero;
        constructor(runner: Runner, 
        /**
         * 特效id
         */
        effectId: string, owner: Hero, 
        /**
         * 来源技能
         */
        skillData: SkillData, target: Hero);
        position: ml.Point;
        speed: number;
        /**
         * 阶段标志
         * - 0 表示正在飞向目标
         * - 1 表示正在飞回
         */
        stageIndex: number;
        onUpdate(dt: number): void;
        updateCurrentPosition(dt: number): {
            position: ml.Point;
            destroy: boolean;
        };
        /**
         * 回到原位回调
         */
        finishCallback?: (pt: ml.Point) => void;
    }
}
declare namespace rpgfight {
    /**
     * 追踪型弧线
     */
    class FlyBackArcMissile extends FlyBackMissile {
        owner: Hero;
        skillData: SkillData;
        target: Hero;
        rotation: number;
        position: ml.Point;
        speed: number;
        angularSpeed: number;
        protected _targetRotation: number;
        protected _isLeft: boolean;
        constructor(runner: Runner, effectId: string, owner: Hero, skillData: SkillData, target: Hero);
        protected _updateRotation(): void;
        onUpdate(dt: number): void;
        updateCurrentPosition(dt: number): {
            position: ml.Point;
            destroy: boolean;
        };
        /**
         * 回到原位回调
         */
        finishCallback?: (pt: ml.Point) => void;
    }
}
declare namespace rpgfight {
    /**
     * 直线
     */
    class FlyDirect extends FlyPath {
        owner: Hero;
        /**
         * 来源技能
         */
        skillData: SkillData;
        isReturn: boolean;
        protected _isReturn: boolean;
        constructor(runner: Runner, 
        /**
         * 特效id
         */
        effectId: string, owner: Hero, 
        /**
         * 来源技能
         */
        skillData: SkillData, isReturn: boolean);
        updateCurrentPosition(dt: number): {
            position: ml.Point;
            destroy: boolean;
        };
    }
}
declare namespace rpgfight {
    /**
     * 追踪型远程普攻
     */
    class FlyMissile extends FlyPath {
        owner: Hero;
        /**
         * 来源技能
         */
        skillData: SkillData;
        target: Hero;
        speed: number;
        protected _delta: ml.Point;
        protected _totalDuration: number;
        protected _curDuration: number;
        position: ml.Point;
        constructor(runner: Runner, 
        /**
         * 特效id
         */
        effectId: string, owner: Hero, 
        /**
         * 来源技能
         */
        skillData: SkillData, target: Hero, speed: number);
        onUpdate(dt: number): void;
        updateCurrentPosition(dt: number): {
            position: ml.Point;
            destroy: boolean;
        };
        protected _updateView(): void;
    }
}
declare namespace rpgfight {
    /**
     * 飞斧
     */
    class FlyParabolicCurve extends FlyPath {
        /**
         * 释放技能的英雄
         */
        owner: Hero;
        /**
         * 来源技能
         */
        skillData: SkillData;
        target: Hero;
        constructor(runner: Runner, 
        /**
         * 特效id
         */
        effectId: string, 
        /**
         * 释放技能的英雄
         */
        owner: Hero, 
        /**
         * 来源技能
         */
        skillData: SkillData, target: Hero);
        position: ml.Point;
        destPos: ml.Point;
        height: number;
        protected curHeight: number;
        updateCurrentPosition(dt: number): {
            position: ml.Point;
            destroy: boolean;
        };
        /**
         * 结束回调
         */
        finishCallback?: (pt: ml.Point) => void;
    }
}
declare namespace rpgfight {
    /**
     * 直线位移
     */
    class MoveAction {
        direction: ml.Point;
        distance: number;
        speed: number;
        host: Hero;
        outScreen?: boolean;
        /**
         * 初始位置
         */
        pos0: ml.Point;
        moveDone: boolean;
        constructor(direction: ml.Point, distance: number, speed: number, host: Hero, outScreen?: boolean);
        update(dt: number): void;
    }
}
declare namespace rpgfight {
    /**
     * 追踪位移
     */
    class SeekingAction {
        speed: number;
        host: Hero;
        target: Hero;
        onDoneCallback: Function;
        /**
         * 初始位置
         */
        pos0: ml.Point;
        moveDone: boolean;
        constructor(speed: number, host: Hero, target: Hero, onDoneCallback: Function);
        update(dt: number): void;
    }
}
declare namespace rpgfight {
    /**
     * 正弦曲线
     */
    class SinAction {
        duration: number;
        offsetX: number;
        height: number;
        host: Hero;
        outScreen?: boolean;
        /**
         * 初始位置
         */
        startPosition: ml.Point;
        moveDone: boolean;
        protected _elapsed: number;
        protected _ratio: number;
        constructor(duration: number, offsetX: number, height: number, host: Hero, outScreen?: boolean);
        update(dt: number): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄攻击
     */
    class HeroAttackHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄死亡中
     */
    class HeroDeadHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄眩晕中
     */
    class HeroDizzyHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄进场
     */
    class HeroEnterHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        /**
         * 判断是已经走入场景
         */
        protected inScene(): boolean;
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄跟随中
     */
    class HeroFollowHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄待机
     */
    class HeroIdelHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        protected idleAnim: string;
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄击退
     */
    class HeroKnockBackHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        protected startTime: number;
        protected startPos: ml.Point;
        protected direction: number;
        protected distance: number;
        protected duration: number;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄击飞
     */
    class HeroKnockFlyHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        protected startTime: number;
        protected startPos: ml.Point;
        protected direction: number;
        protected distance: number;
        protected height: number;
        protected duration: number;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄受到攻击
     */
    class HeroKnockHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄击倒
     */
    class HeroKnockOffHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        protected duration: number;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 输了的一方英雄状态
     */
    class HeroLossHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄移动
     */
    class HeroMoveHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄假死中
     */
    class HeroShockHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 英雄站起来
     */
    class HeroStandupHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    /**
     * 赢的一方英雄状态
     */
    class HeroWinHandler extends logicchart.statetree.StatusEventHandler {
        hero: Hero;
        constructor(hero: Hero);
        execute(message: logicchart.statetree.StatusEventMessage): void;
    }
}
declare namespace rpgfight {
    enum GameState {
        running = 0,
        win = 1,
        failed = 2
    }
    /**
     * 实现对战斗的管理
     */
    class ManagerBase {
        /**
         * 战斗日志
         */
        devLog: LogFlow;
        /**
         * buff管理器
         */
        buffManager: BuffManager;
        /**
         * 特效管理器
         */
        effectViewManager: EffectViewManager;
        robotPlayer: RobotPlayer;
        /**
         * 游戏运行期
         */
        runner: Runner;
        /**
         * 用于在触发树中创建游戏对象
         */
        gameObjectFactory: GameObjectFactory;
        /**
         * 战斗视图工厂，所有view层对象由该对象创建
         */
        viewFactory: ViewFactory;
        calculator: HeroCalc;
        /**
         * 场景的查询缓存
         */
        protected _scene?: Scene;
        /**
         * 倒计时结束
         */
        onGameTimeout?: () => void;
        /**
         * 我方英雄全部死亡
         */
        onOurHeroDeadAll?: () => void;
        /**
         * 敌方英雄全部死亡
         */
        onEnemyDeadAll?: () => void;
        /**
         * 游戏结果
         */
        onGameResult?: (options: {
            /**
             * 我方胜利
             */
            win: boolean;
        }) => void;
        /**
         * 时钟
         */
        clock: UpdateTimer;
        /**
         * 英雄是否已入场
         */
        isHeroEntered: boolean;
        /**
         *
         * @param viewFactory 视图工厂，工具资源id加载动画
         */
        constructor(viewFactory?: ViewFactory);
        getHeroConfigById(id: string, level: number): HeroConfig | undefined;
        /**
         * 动态新增英雄
         */
        addHeroWithHeroConfig(heroConfig: HeroConfig): Hero | undefined;
        /**
         * 获取所有英雄
         */
        getHeroList(filter?: (hero: Hero) => boolean): Hero[];
        /**
         * 获取最近的英雄排列
         */
        getNearestHeroList(hero: Hero, filter?: (hero: Hero) => boolean): Hero[];
        getHeroCountOfTeam(team: BattleTeam): number;
        getEnermyCount(team: BattleTeam): number;
        /**
         * 获取当前战场环境的scene
         */
        getScene(): Scene;
        battleType: number | undefined;
        gameStart(battleType?: number): void;
        finishGame(battleTeam: BattleTeam): void;
        /**
         * 英雄进入欢呼或失败
         */
        updateGameResultState(): void;
        /**
         * 使某些英雄进入胜利欢呼状态
         * @param filter
         */
        playWinAnim(filter?: (hero: Hero) => boolean): void;
        gameState: GameState;
        protected isOurHeroDeadAll: boolean;
        protected isEnemyDeadAll: boolean;
        protected isGameTimeout: boolean;
        update(dt: number): void;
        /**
         * 仅用于分析内存占用
         */
        statMemoryUsing(): {
            effectCount: number;
            objCount: GameObject;
            heroCount: Hero[];
        };
        /**
         * 丢弃战役，清理战场
         */
        abortBattle(): void;
    }
}
declare namespace rpgfight {
    class NormalData {
        scene: SceneConfig;
        heroList: HeroConfig[];
        heroTemplates: HeroConfig[];
        constructor(scene: SceneConfig, heroList: HeroConfig[], heroTemplates?: HeroConfig[]);
    }
    /**
     * 不局限战斗结束条件
     */
    class NormalManager extends ManagerBase {
        normalData: NormalData;
        protected heroTemplates: HeroConfig[];
        protected _aiTree: IAiEntity;
        constructor(normalData: NormalData, viewFactory?: ViewFactory);
        getHeroConfigById(id: string, level: number): HeroConfig | undefined;
        protected init(normalData: NormalData, viewFactory?: ViewFactory): void;
        protected _addHeroWithHeroConfig(heroConfig: HeroConfig): Hero;
        addHeroWithHeroConfig(heroConfig: HeroConfig): Hero;
        /**
         * 记录英雄信息
         * @param heroConfig
         */
        logHeroConfig(heroConfig: HeroConfig): void;
        gameStart(battleType?: number): void;
    }
}
declare namespace rpgfight {
    class BattleData {
        scene: SceneConfig;
        heroList: HeroConfig[];
        heroTemplates: HeroConfig[];
        constructor(scene: SceneConfig, heroList: HeroConfig[], heroTemplates?: HeroConfig[]);
    }
    /**
     * 普通战役
     */
    class BattleManager extends NormalManager {
        battleData: BattleData;
        constructor(battleData: BattleData, viewFactory?: ViewFactory);
        protected init(normalData: NormalData, viewFactory?: ViewFactory): void;
        updateGameResultState(): void;
        /**
         * 战损列表
         */
        contributionList?: Hero[];
        protected _addHeroWithHeroConfig(heroConfig: HeroConfig): Hero;
        /**
         * 获取战损统计
         */
        getContributionResult(): HeroContributionStatistic[];
    }
}
declare namespace rpgfight {
    class ArenaData {
        scene: SceneConfig;
        heroList: HeroConfig[];
        heroTemplates: HeroConfig[];
        constructor(scene: SceneConfig, heroList: HeroConfig[], heroTemplates?: HeroConfig[]);
    }
    /**
     * 竞技场
     */
    class ArenaManager extends BattleManager {
        arenaData: ArenaData;
        constructor(arenaData: ArenaData, viewFactory?: ViewFactory);
    }
}
declare namespace rpgfight {
    class BuffManager {
        /**
         * buff列表
         * - 汇总包含所有对象的buff
         */
        buffList: IBuffBase[];
        /**
         * 对目标应用所有buff效果
         */
        applyBuffs(target: any, options?: BuffApplyOptions): void;
        /**
         * 是否一个对象上已经存在同类buff
         * @param newBuff
         */
        isBuffExist(newBuff: IBuffBase): boolean;
        /**
         * 是否一个对象上已经存在同类buff
         * @param newBuff
         */
        findBuffExist(newBuff: IBuffBase): IBuffBase | undefined;
        /**
         * 过滤拥有某effect的buff
         * @param effectType
         * @param owner
         */
        filterBuffsWithTypeOfEffect(effectType: BuffEffectType, owner: GameObject): HeroBuff[];
        /**
         * 获取同类buff
         * @param newBuff
         */
        getBuffsOfType(name: BuffType, owner: GameObject): IBuffBase[];
        /**
         * 获取同类buff数量
         * @param newBuff
         */
        getBuffCountOfType(name: BuffType, owner: GameObject): number;
        /**
         * 是否一个对象上已经存在同类buff
         * @param newBuff
         */
        isBuffExistWithSameType(name: BuffType, owner: GameObject): boolean;
        /**
         * 是否一个对象上已经存在同个buff
         * @param newBuff
         */
        isBuffExistWithSameId(buffId: string, owner: GameObject): boolean;
        isBuffExistWithSameIdAndSender(buffId: string, owner: GameObject, sender: GameObject): boolean;
        dealBuffRelation(buff: IBuffBase): boolean;
        /**
         * 加buff
         * - 暂时不允许对同一个对象添加同类buff
         */
        addBuff(buff: IBuffBase): void;
        filterBuffForHero(hero: Hero): IBuffBase[];
        /**
         * 减buff
         */
        removeBuff(buff: IBuffBase): void;
        /**
         * 移除几层buff
         */
        removeDuplicateBuffById(buffId: string, owner: Hero, count: number): void;
        /**
         * 减buff
         */
        removeBuffById(buffId: string, owner: Hero): void;
        /**
         * 重置buff持续时间
         */
        resetHourglass(buffId: string): void;
        /**
         * 批量移除buff
         */
        removeBuffList(delList: (IBuffBase | null)[]): void;
        update(dt: number): void;
        clear(): void;
    }
}
declare namespace rpgfight {
    /**
     * 特效和特写管理
     */
    class EffectViewManager {
        runner: Runner;
        clock: UpdateTimer;
        isEnemyCloseupEnabled: boolean;
        constructor(runner: Runner, clock: UpdateTimer);
        getEffectList(): SkillEffect[];
        getHeroList(): Hero[];
        /**
         * 清理失去依赖的特效
         */
        cleanEffectList(): void;
        /**
         * 设置计时速率
         */
        setAllObjectTimerScale(value: number): void;
        protected _currentCloseUpTeam?: BattleTeam;
        /**
         * 进入特写
         * ***
         * - 英雄的攻击间隔和技能cd仅和自身计时相关
         * - 助攻的有效期和战场时间相关
         * - 比如特写之后，所有能动的东西都要以 0.8 慢倍速率播放
         * - 进入特写，静止的一方，如果被 击倒、击退、击飞，那么要以放慢倍速播放击倒、击退、击飞动画，然后重新进入静止
         */
        enterCloseUp(battleTeam: BattleTeam): void;
        clearAllEffectOfHero(hero: Hero): void;
        protected leaveCloseUp(battleTeam: BattleTeam): void;
        resumeAllHeros(): void;
        updateHeroState(): void;
        /**
         * 每帧检测是否有英雄正在释放特写技能
         */
        update(): void;
    }
}
declare namespace rpgfight {
    /**
     * 游戏托管机器人
     */
    class RobotPlayer {
        runner: Runner;
        constructor(runner: Runner);
        /**
         * 自动托管
         * - false：仅敌方英雄自动托管
         * - true：己方英雄也自动托管
         */
        private _autoPlay;
        get autoPlay(): boolean;
        set autoPlay(value: boolean);
        protected _activeHeroes: Hero[];
        protected _deactiveHeroes: Hero[];
        protected cancelAutoPlay: boolean;
        /**
         * 释放大招
         * @param heroId
         */
        activeHeroSkillWithHeroId(heroId: string): void;
        /**
         * 取消大招
         * @param heroId
         */
        deactiveHeroSkillWithHeroId(heroId: string): void;
        /**
         * 释放大招
         * @param hero
         */
        activeHeroSkill(hero: Hero): boolean;
        /**
         * 禁止主动释放大招
         * @param hero
         */
        deactiveHeroSkill(hero: Hero): boolean;
        update(dt: number): void;
    }
}
