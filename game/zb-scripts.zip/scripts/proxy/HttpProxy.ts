import gm from "../manager/GameManager";
import {stringConfigMap} from "../configs/stringConfig";
import commonUtils from "../utils/CommonUtils";

export default class HttpProxy {
    static readonly gameClient: slib.HttpClient = new slib.HttpClient();

    static async httpGet<T>(url: string): Promise<T> {
        return new Promise<T>((resolve, reject) => {
            let headMap = {};
            headMap["Content-Type"] = "application/json;charset=utf-8";
            headMap["Access-Control-Allow-Methods"] = "*";
            let callback = (data: any) => {
                gm.hideIndicator();
                resolve(data);
            };
            let onError = (data: any) => {
                gm.hideIndicator();
                // reject(data);
                errorCallback(data, request);
            };
            let retryCount = 0;
            let errorCallback = async (data: any, retry: () => void) => {
                if (retryCount > 3) {
                    retryCount = 0;
                    reject(data);
                }
                else {
                    await commonUtils.sleep(1);
                    retry();
                    retryCount++;
                }
            };
            gm.showIndicator(1);
            let request = () => {
                this.gameClient.request({method: "GET", headMap: headMap, url: url, onDone: callback, onError: onError});
            };
            request();
        })
    }
}
