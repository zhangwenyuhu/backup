type int = number
type integer = number
type array<T> = Array<T>

//IPirate Api



export class AnnouncementDO {

    /**
    * 
    */

    _appId_: integer

    /**
    * 
    */

    cdIds: array<integer>

    /**
    * 
    */

    endTime: integer

    /**
    * 
    */

    id: string

    /**
    * 
    */

    index: integer

    /**
    * 
    */

    manyLanguage: array<LanguageBO>

    /**
    * 
    */

    packageTags: array<string>

    /**
    * 
    */

    remark: string

    /**
    * 
    */

    startTime: integer

    /**
    * 
    */

    state: integer

    /**
    * 
    */

    type: integer

}


export class AnnouncementRequest {

    /**
    * 
    */

    language: string

    /**
    * 
    */

    packageTag: string

}


export class ChooseV2Request {

    /**
    * 渠道信息
    */

    channelId: integer

    /**
    * 登陆的服ID
    */

    id: integer

    /**
    * 来源
    */

    sourceId: integer

    /**
    * 设备平台0:未知，1:安卓，2:IOS
    */

    system: integer

    /**
    * 设备信息
    */

    systemInfo: object

    /**
    * 客户端版本号
    */

    v: string

    /**
     * 广告信息
     */
    ad: string
}


export class DistrictDO {

    /**
    * 
    */

    _appId_: integer

    /**
    * 
    */

    closedInfo: string

    /**
    * 
    */

    districtId: integer

    /**
    * 
    */

    host: string

    /**
    * 
    */

    id: string

    /**
    * 
    */

    name: string

    /**
    * 
    */

    no: integer

    /**
    * 
    */

    open: boolean

    /**
    * 
    */

    openAt: integer

    /**
    * 
    */

    sandbox: boolean

    /**
    * 
    */

    state: integer

    /**
    * 
    */

    test: boolean

}


export class JSONRequest {

    /**
    * 
    */

    data: object

    /**
    * 
    */

    index: integer

    /**
    * 
    */

    retry: integer

}








export class JSONResult {

    /**
    * 
    */

    c: integer

    /**
    * 
    */

    c_min_v: string

    /**
    * 
    */

    errorcode: string

    /**
    * 
    */

    m: string

    /**
    * 
    */

    ok: boolean

    /**
    * 
    */

    r: object

    /**
    * 
    */

    ts: integer

}







export class LanguageBO {

    /**
    * 
    */

    content: string

    /**
    * 
    */

    language: string

    /**
    * 
    */

    title: string

}


export class MyDistrictListVO {

    /**
    * 当前服信息
    */

    list: array<DistrictDO>

    /**
    * 我的服列表，已做排序
    */

    myList: array<integer>

}


export class MyListRequest {

    /**
    * 
    */

    packageTag: string

    /**
    * 
    */

    tishen: boolean

}


export class NodeVO {

    /**
    * 节点域名
    */

    host: string

    /**
    * 节点名称
    */

    name: string

}


export class RoleDO {

    /**
    * 
    */

    _appId_: integer

    /**
    * 
    */

    _cdId_: integer

    /**
    * 
    */

    _uid_: string

    /**
    * 
    */

    _userId_: integer

    /**
    * 
    */

    create: integer

    /**
    * 
    */

    data: object

    /**
    * 
    */

    disableTimeMS: integer

    /**
    * 
    */

    id: integer

    /**
    * 
    */

    loginAt: integer

    /**
    * 
    */

    name: string

    /**
    * 
    */

    silentTimeMS: integer

}


export class RoleName {

    /**
    * 
    */

    name: string

}


export class RoleNameData {

    /**
    * 
    */

    data: object

    /**
    * 
    */

    name: string

}



export default class IPirateProxy {
    static readonly gameClient: slib.HttpGameClient = new slib.HttpGameClient();

    /**
     * 获取公告列表
     * para.data 不用传值
     */
    static apiannouncementlist(


        data: AnnouncementRequest,
        callback: (data: {
            succeed: boolean,
            code: 0 | number,
            message: "success" | string,
            data: AnnouncementDO[]
        }) => void,
        modal: boolean = false, errorCallback: (error: any, retry: () => void) => void = null) {
        this.gameClient.request('api/announcement/list', data, (data) => {
            callback(data);
        }, { modal: modal, errorCallback: errorCallback })
    }


    /**
     * 选服 & 创建角色、生成角色id，换取新的gametoken
     * 
     */
    static apidistrictchoose(


        data: ChooseV2Request,
        callback: (data: {
            succeed: boolean,
            code: 0 | number,
            message: "success" | string,
            data: string
        }) => void,
        modal: boolean = false, errorCallback: (error: any, retry: () => void) => void = null) {
        this.gameClient.request('api/district/choose', data, (data) => {
            callback(data);
        }, { modal: modal, errorCallback: errorCallback })
    }


    /**
     * 获取游戏服列表,包含玩家自己登陆过的服信息
     * para.data 不用传值
     */
    static apidistrictmylist(


        data: MyListRequest,
        callback: (data: {
            succeed: boolean,
            code: 0 | number,
            message: "success" | string,
            data: MyDistrictListVO
        }) => void,
        modal: boolean = false, errorCallback: (error: any, retry: () => void) => void = null) {
        this.gameClient.request('api/district/mylist', data, (data) => {
            callback(data);
        }, { modal: modal, errorCallback: errorCallback })
    }







    /**
     * 获取当前节点信息
     * 
     */
    static apiobjectgetNode(


        data: null,
        callback: (data: {
            succeed: boolean,
            code: 0 | number,
            message: "success" | string,
            data: NodeVO
        }) => void,
        modal: boolean = false, errorCallback: (error: any, retry: () => void) => void = null) {
        this.gameClient.request('api/object/getNode', data, (data) => {
            callback(data);
        }, { modal: modal, errorCallback: errorCallback })
    }


    /**
     * 保存对象，并获取对象URL
     * 
     */
    static apiobjectsave(


        data: string,
        callback: (data: {
            succeed: boolean,
            code: 0 | number,
            message: "success" | string,
            data: string
        }) => void,
        modal: boolean = false, errorCallback: (error: any, retry: () => void) => void = null) {
        this.gameClient.request('api/object/save', data, (data) => {
            callback(data);
        }, { modal: modal, errorCallback: errorCallback })
    }


    /**
     * 根据角色名获取本服的某个角色
     * 
     */
    static apirolegetRole(


        data: RoleName,
        callback: (data: {
            succeed: boolean,
            code: 0 | number,
            message: "success" | string,
            data: RoleDO
        }) => void,
        modal: boolean = false, errorCallback: (error: any, retry: () => void) => void = null) {
        this.gameClient.request('api/role/getRole', data, (data) => {
            callback(data);
        }, { modal: modal, errorCallback: errorCallback })
    }


    /**
     * 角色取名/改名、同步自定义数据到公共服数据库
     * name、data 至少有一个有值。空值不做更新<br>name：如果有值则检查是否重名并更新<br>data：客户端自定义数据
     */
    static apirolesync(


        data: RoleNameData,
        callback: (data: {
            succeed: boolean,
            code: 0 | number,
            message: "success" | string,
            data: RoleDO
        }) => void,
        modal: boolean = false, errorCallback: (error: any, retry: () => void) => void = null) {
        this.gameClient.request('api/role/sync', data, (data) => {
            callback(data);
        }, { modal: modal, errorCallback: errorCallback })
    }







}


