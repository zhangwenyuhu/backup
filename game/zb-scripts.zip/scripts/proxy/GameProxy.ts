type int=number
type integer=number
type array<T>=Array<T>
type HashMap<K, V> = Map<K, V>
type long = number
type double = number
type KeyValueBO<K, V> = { key: K, value: V }

//zombieii plus Api


    
export class ActBossHitReq{
    
    /**
    * 活动ID
    */
    
    actId:string
    
    /**
    * 战报
    */
    
    result:object
    
    /**
    * 总伤害量
    */
    
    totalHurt:integer
    
}

    
export class ActChessStepReq{
    
    /**
    * 活动ID
    */
    
    actId:string
    
    /**
    * 事件列表，计算奖励及消耗用
    */
    
    eventList:array<ChessEventItem>
    
    /**
    * 最终的玩家位置(第一圈第一格为1，第二圈第一格为25）
    */
    
    newPlayerStep:integer
    
    /**
    * 最终的僵尸位置(第一圈第一格为1，第二圈第一格为25）
    */
    
    newZombieStep:integer
    
}

    
export class ActSevenChargeBO{
    
    /**
    * 每日的充值金额
    */
    
    amtProgress:object
    
    /**
    * 领取详情
    */
    
    detail:array<ActSevenChargePItemBO>
    
    /**
    * 进度 当前是第几天
    */
    
    nowDay:integer
    
    /**
    * 开始时间戳
    */
    
    startTs:integer
    
}

    
export class ActSevenChargePItemBO{
    
    /**
    * 任务ID Activechargeconfig中的ID
    */
    
    recTag:string
    
    /**
    * 是否已经领取
    */
    
    recv:boolean
    
}

    
export class ActTreaChangeRewardReq{
    
    /**
    * 活动ID
    */
    
    actId:string
    
    /**
    * 新的终极奖励配置ID
    */
    
    confId:integer
    
    /**
    * 是否使用更换BUFF
    */
    
    useBuff:boolean
    
}

    
export class ActTreaOpenReq{
    
    /**
    * 活动ID
    */
    
    actId:string
    
    /**
    * 需要翻开的索引 0开始
    */
    
    index:integer
    
}

    
export class ActTreaRaiderBuy{
    
    /**
    * 活动ID
    */
    
    actId:string
    
    /**
    * 购买个数
    */
    
    buyCount:integer
    
}

    
export class ActiveRewardReq{
    
    /**
    * activerewardConfig中的id
    */
    
    rewardId:integer
    
    /**
    * 是否使用视频加倍
    */
    
    useVideo:boolean
    
}

    
export class ActivityBO{
    
    /**
    * 配置数据
    */
    
    actConfig:object
    
    /**
    * 生效区服 -999999表示全服
    */
    
    cdIds:array<integer>
    
    /**
    * 配置关闭时间
    */
    
    closeAt:integer
    
    /**
    * 附带信息
    */
    
    extra:string
    
    /**
    * 活动ID-唯一标识
    */
    
    id:string
    
    /**
    * 配置开启时间
    */
    
    openAt:integer
    
    /**
    * 新服保护后的 实际关闭时间
    */
    
    realCloseAt:integer
    
    /**
    * 新服保护后的 实际开启时间
    */
    
    realOpenAt:integer
    
    /**
    * 活动备注（策划配置的一种标识）
    */
    
    remark:string
    
    /**
    * 活动类型
    */
    
    type:integer
    
}

    
export class ActivityCumRewardReq{
    
    /**
    * 活动ID
    */
    
    actId:string
    
    /**
    * 领取的奖励项中的recTag
    */
    
    recTag:string
    
    /**
    * 3累计充值 4累计消费 10日消返利 用于世界BOSS累伤、奇兵商店、棋盘、探趣寻宝、任务活动时，该值无效
    */
    
    type:integer
    
}

    
export class ActivityDO{
    
    /**
    * 
    */
    
    _appId_:integer
    
    /**
    * 
    */
    
    actData:string
    
    /**
    * 
    */
    
    cdIds:array<integer>
    
    /**
    * 
    */
    
    closeAt:integer
    
    /**
    * 
    */
    
    extra:string
    
    /**
    * 
    */
    
    id:string
    
    /**
    * 
    */
    
    openAt:integer
    
    /**
    * 
    */
    
    remark:string
    
    /**
    * 
    */
    
    send:boolean
    
    /**
    * 
    */
    
    type:integer
    
}

    
export class ActivityExchangeBuyReq{
    
    /**
    * 活动ID
    */
    
    actId:string
    
    /**
    * 需要消耗的装备Ids
    */
    
    equipIds:array<string>
    
    /**
    * 需要消耗的英雄HeroIds
    */
    
    heroIds:array<string>
    
    /**
    * 领取的奖励项中的recTag
    */
    
    recTag:string
    
}

    
export class ActivityProgressBO{
    
    /**
    * 所需进度/购买上限 -1表示不限制
    */
    
    needProgress:integer
    
    /**
    * 当前进度/当前购买次数
    */
    
    progress:integer
    
    /**
    * 是否已领取
    */
    
    recv:boolean
    
    /**
    * 标识 识别进度归属
    */
    
    tag:string
    
}

    
export class ActivityProgressChangeReq{
    
    /**
    * 活动ID
    */
    
    actId:string
    
    /**
    * 需要推动的进度("recvTag":进度值)
    */
    
    changeMap:object
    
}

    
export class ActivityRoleBO{
    
    /**
    * 活动配置信息
    */
    
    activityBO:ActivityBO
    
    /**
    * 个人活动数据
    */
    
    roleActivityDatas:object
    
    /**
    * 附带七日充值活动数据
    */
    
    sevenInfo:ActSevenChargeBO
    
}

    
export class ActivitySevenRewardReq{
    
    /**
    * 活动ID
    */
    
    actId:string
    
    /**
    * 领取的奖励项中的needProgress（部分请求无效）
    */
    
    needProgress:integer
    
    /**
    * 领取的奖励项中的recTag
    */
    
    recTag:string
    
}

    
export class ActivityTreaInstBO{
    
    /**
    * buff状态 BUFFID-是否开启
    */
    
    buffs:object
    
    /**
    * 终极待选列表领取次数
    */
    
    finalCount:object
    
    /**
    * 终极大奖配置ID(<1表示没有选择)
    */
    
    finalRewardId:integer
    
    /**
    * 终极大奖位置(<0表示没有选择)
    */
    
    finalRewardIndex:integer
    
    /**
    * 活动ID-唯一标识
    */
    
    id:string
    
    /**
    * 目前层数 1开始
    */
    
    layerNo:integer
    
    /**
    * 层奖励领取情况
    */
    
    layerRewards:array<ActivityProgressBO>
    
    /**
    * 奖励格子翻开情况
    */
    
    positionRec:array<boolean>
    
    /**
    * 奖励领取情况 奖励配置ID-剩余可领数量
    */
    
    rewardDetail:object
    
}

    
export class AdvBattleReportVO{
    
    /**
    * 单场战斗输赢(battleNo-boolean)
    */
    
    battleWin:object
    
    /**
    * 是否主动攻击
    */
    
    isActive:boolean
    
    /**
    * 是否胜利
    */
    
    isWin:boolean
    
    /**
    * 新的排名
    */
    
    newRank:string
    
    /**
    * 新段位
    */
    
    newRankId:integer
    
    /**
    * 新积分
    */
    
    newScore:integer
    
    /**
    * 原排名
    */
    
    rawRank:string
    
    /**
    * 原积分
    */
    
    rawScore:integer
    
    /**
    * 奖励资源
    */
    
    resourceVO:ResourceVO
    
    /**
    * 对手新排名
    */
    
    rivalNewRank:string
    
    /**
    * 对手新段位
    */
    
    rivalNewRankId:integer
    
    /**
    * 对手新积分
    */
    
    rivalNewScore:integer
    
    /**
    * 对手原排名
    */
    
    rivalRawRank:string
    
    /**
    * 对手原积分
    */
    
    rivalRawScore:integer
    
    /**
    * 战斗系列编号
    */
    
    seriesNo:string
    
}

    
export class AppointGuildReq{
    
    /**
    * 公会职位ID，(对应factionconfig 3成员\2副会长)
    */
    
    jobId:integer
    
    /**
    * 目标RoleID
    */
    
    targetRoleId:string
    
}

    
export class ArenaAdvBattleReq{
    
    /**
    * 战场高度
    */
    
    height:integer
    
    /**
    * 我方站位英雄信息 按照索引表示场次
    */
    
    heros:array<array<undefined>>
    
    /**
    * 对手id
    */
    
    rivalRoleId:string
    
    /**
    * 战斗类型 1高级
    */
    
    type:integer
    
    /**
    * 战斗版本号
    */
    
    version:integer
    
    /**
    * 战场宽度
    */
    
    width:integer
    
}

    
export class ArenaAdvRecordVO{
    
    /**
    * 
    */
    
    active:boolean
    
    /**
    * 对手头像
    */
    
    avatar:string
    
    /**
    * 对手头像框
    */
    
    avatarFrame:string
    
    /**
    * 单场战斗输赢(battleNo-boolean)
    */
    
    battleWin:object
    
    /**
    * 战斗时间
    */
    
    createTs:integer
    
    /**
    * 对手公会Id
    */
    
    guildId:integer
    
    /**
    * 对手公会名
    */
    
    guildName:string
    
    /**
    * 唯一ID
    */
    
    id:string
    
    /**
    * 对手等级
    */
    
    lv:integer
    
    /**
    * 对手新的排名
    */
    
    newRank:string
    
    /**
    * 对手新段位
    */
    
    newRankId:integer
    
    /**
    * 对手昵称
    */
    
    nick:string
    
    /**
    * 对手原排名
    */
    
    rawRank:string
    
    /**
    * 对手原段位
    */
    
    rawRankId:integer
    
    /**
    * 对手id
    */
    
    rivalRoleId:string
    
    /**
    * 战斗系列编号
    */
    
    seriesNo:string
    
    /**
    * 
    */
    
    win:boolean
    
}

    
export class ArenaBattleReq{
    
    /**
    * 机器人对手数据，仅机器人有效
    */
    
    aiList:array<HeroBO>
    
    /**
    * 战场高度
    */
    
    height:integer
    
    /**
    * 我方站位英雄信息
    */
    
    heros:array<DefendHeroBO>
    
    /**
    * 对手id,对手为机器人时，填 configID-竞技场分数,如1-1535.0
    */
    
    rivalRoleId:string
    
    /**
    * 战斗版本号
    */
    
    version:integer
    
    /**
    * 战场宽度
    */
    
    width:integer
    
}

    
export class ArenaRecordVO{
    
    /**
    * AI阵容,仅在对手是AI时有效
    */
    
    aiHeroes:array<HeroVO>
    
    /**
    * 对手头像
    */
    
    avatar:string
    
    /**
    * 对手头像框
    */
    
    avatarFrame:string
    
    /**
    * 战斗编号,用于获取回放战斗数据
    */
    
    battleNo:integer
    
    /**
    * 战斗时间
    */
    
    createTs:integer
    
    /**
    * 唯一ID
    */
    
    id:string
    
    /**
    * 是否复仇 0 是 1否
    */
    
    isRevenge:integer
    
    /**
    * 我是否赢下战斗 0 是 1否
    */
    
    isWin:integer
    
    /**
    * 对手等级
    */
    
    lv:integer
    
    /**
    * 对手昵称
    */
    
    nick:string
    
    /**
    * 防守战力
    */
    
    power:integer
    
    /**
    * 对手id
    */
    
    rivalRoleId:string
    
    /**
    * 积分变动
    */
    
    score:integer
    
}

    
export class ArenaReq{
    
    /**
    * 站位英雄信息 非必填
    */
    
    heros:array<DefendHeroBO>
    
    /**
    * 对手id 非必填
    */
    
    rivalRoleId:string
    
    /**
    * 竞技场类型 必填 0普通1高阶2巅峰
    */
    
    type:integer
    
}

    
export class ArenaRevengeReq{
    
    /**
    * 战场高度
    */
    
    height:integer
    
    /**
    * 我方站位英雄信息
    */
    
    heros:array<DefendHeroBO>
    
    /**
    * 复仇记录唯一ID
    */
    
    id:string
    
    /**
    * 战斗版本号
    */
    
    version:integer
    
    /**
    * 战场宽度
    */
    
    width:integer
    
}

    
export class ArenaTaskVO{
    
    /**
    * 赛季性任务-高阶竞技场挑战次数
    */
    
    advArenaBcTask:array<TaskInfoVO>
    
    /**
    * 赛季性任务-高阶竞技场段位任务
    */
    
    advArenaRankTask:array<TaskInfoVO>
    
    /**
    * 赛季性任务-挑战次数
    */
    
    arenaBcTask:array<TaskInfoVO>
    
    /**
    * 一次性任务-历史最高战力奖励
    */
    
    topScoreTask:array<TaskInfoVO>
    
}

    
export class ArtifactBO{
    
    /**
    * artifact配置表中对应的key，表示神器配置ID
    */
    
    artifactCofId:integer
    
    /**
    * 神器ID-唯一标识
    */
    
    artifactId:string
    
    /**
    * 锻造等级
    */
    
    forgeLv:integer
    
    /**
    * 锻造属性列表 key-value:位置-属性Id:值
    */
    
    forgeProps:object
    
    /**
    * 数据库hero表中的ID。表示谁佩戴了该装备，无人佩戴置为""(空字符串)或null
    */
    
    heroId:string
    
    /**
    * 当前装备的品阶等级（用于结算加成属性和技能等级）
    */
    
    rank:integer
    
}

    
export class ArtifactDO{
    
    /**
    * 
    */
    
    artifactCofId:integer
    
    /**
    * 
    */
    
    createTs:integer
    
    /**
    * 
    */
    
    forgeLv:integer
    
    /**
    * 
    */
    
    forgeProps:object
    
    /**
    * 
    */
    
    heroId:string
    
    /**
    * 
    */
    
    id:string
    
    /**
    * 
    */
    
    rank:integer
    
    /**
    * 
    */
    
    roleId:integer
    
}

    
export class ArtifactForgeReq{
    
    /**
    * 神器ID
    */
    
    artifactId:string
    
    /**
    * 
    */
    
    lock:boolean
    
}

    
export class ArtifactInitBO{
    
    /**
    * 
    */
    
    artifactCofId:integer
    
    /**
    * 
    */
    
    forgeLv:integer
    
    /**
    * 
    */
    
    no:integer
    
    /**
    * 
    */
    
    rank:integer
    
}

    
export class BagVO{
    
    /**
    * 神器列表
    */
    
    artifacts:array<ArtifactBO>
    
    /**
    * 装备列表
    */
    
    equips:array<EquipBO>
    
    /**
    * 背包物品
    */
    
    goods:array<GoodVO>
    
}

    
export class BattleReportBO{
    
    /**
    * 
    */
    
    battleNo:string
    
    /**
    * 是否胜利 0是1否
    */
    
    isWin:integer
    
    /**
    * 新的排名
    */
    
    rank:integer
    
    /**
    * 对手原分数
    */
    
    rivalRawScore:integer
    
    /**
    * 对手的分值变动
    */
    
    rivalScore:integer
    
    /**
    * 我的分值变动
    */
    
    score:integer
    
}

    
export class BattleStanceBO{
    
    /**
    * 英雄配置ID
    */
    
    heroCofId:integer
    
    /**
    * 英雄唯一ID
    */
    
    heroId:string
    
    /**
    * 位号 高阶竞技场使用 (场次-1)*5+位数 表示，如第2场第1个为6
    */
    
    stanceNo:integer
    
}

    
export class BattleStanceReq{
    
    /**
    * 过期时间(ms)<0表示不重置，否则经过指定ms后站位数据清空
    */
    
    expire:integer
    
    /**
    * 英雄位置
    */
    
    stance:array<BattleStanceBO>
    
    /**
    * 站位类型
    */
    
    stanceTypeEnum:string
    
}

    
export class Battle_ArenaData{
    
    /**
    * 
    */
    
    battleNo:string
    
    /**
    * 
    */
    
    heroList:array<Battle_heroConfig>
    
    /**
    * 
    */
    
    inputDataVersion:integer
    
    /**
    * 
    */
    
    result:object
    
    /**
    * 
    */
    
    rivalRoleId:string
    
    /**
    * 
    */
    
    roleId:string
    
    /**
    * 
    */
    
    scene:Battle_sceneConfig
    
    /**
    * 
    */
    
    summonList:array<Battle_heroConfig>
    
}

    
export class Battle_ArenaData_Mul{
    
    /**
    * 
    */
    
    datas:array<Battle_ArenaData>
    
    /**
    * 
    */
    
    seriesNo:string
    
}

    
export class Battle_heroConfig{
    
    /**
    * 
    */
    
    attack:Number
    
    /**
    * 
    */
    
    attackInterval:Number
    
    /**
    * 
    */
    
    attackSkill:Battle_skillConfig
    
    /**
    * 
    */
    
    battleStation:Number
    
    /**
    * 
    */
    
    battleTeam:integer
    
    /**
    * 
    */
    
    career:Number
    
    /**
    * 
    */
    
    critHurt:Number
    
    /**
    * 
    */
    
    critRate:Number
    
    /**
    * 
    */
    
    deCri:Number
    
    /**
    * 
    */
    
    defense:Number
    
    /**
    * 
    */
    
    dodgeRate:Number
    
    /**
    * 
    */
    
    enterAnimPos:integer
    
    /**
    * 
    */
    
    enterAnimTime:Number
    
    /**
    * 
    */
    
    exclusiveLevel:Number
    
    /**
    * 
    */
    
    extraDefenseMagicHurt:Number
    
    /**
    * 
    */
    
    extraDefensePhysicalHurt:Number
    
    /**
    * 
    */
    
    faction:Number
    
    /**
    * 
    */
    
    fightPower:Number
    
    /**
    * 
    */
    
    healCap:Number
    
    /**
    * 
    */
    
    height:Number
    
    /**
    * 
    */
    
    heroConfigId:string
    
    /**
    * 
    */
    
    heroId:string
    
    /**
    * 
    */
    
    heroName:string
    
    /**
    * 
    */
    
    heroType:Number
    
    /**
    * 
    */
    
    hitRate:Number
    
    /**
    * 
    */
    
    hp:Number
    
    /**
    * 
    */
    
    hpHealingSpeed:Number
    
    /**
    * 
    */
    
    incHarm:Number
    
    /**
    * 
    */
    
    isNormalAttackUsable:boolean
    
    /**
    * 
    */
    
    level:Number
    
    /**
    * 
    */
    
    nearestDistance:Number
    
    /**
    * 
    */
    
    normalAttackStartPositionX:Number
    
    /**
    * 
    */
    
    normalAttackStartPositionY:Number
    
    /**
    * 
    */
    
    normalOnHitPositionX:Number
    
    /**
    * 
    */
    
    normalOnHitPositionY:Number
    
    /**
    * 
    */
    
    power:Number
    
    /**
    * 
    */
    
    powerChargeSpeedNormal:Number
    
    /**
    * 
    */
    
    powerChargeSpeedWithHurt:Number
    
    /**
    * 
    */
    
    powerChargeSpeedWithKilling:Number
    
    /**
    * 
    */
    
    powerChargeSpeedWithUsingSkill:Number
    
    /**
    * 
    */
    
    powerMax:Number
    
    /**
    * 
    */
    
    rank:Number
    
    /**
    * 
    */
    
    rapid:Number
    
    /**
    * 
    */
    
    scale:Number
    
    /**
    * 
    */
    
    skillHarm:Number
    
    /**
    * 
    */
    
    skillList:array<Battle_skillConfig>
    
    /**
    * 
    */
    
    skillSpeed:Number
    
    /**
    * 
    */
    
    skin:string
    
    /**
    * 
    */
    
    speed:Number
    
    /**
    * 
    */
    
    suckBloodLv:Number
    
    /**
    * 
    */
    
    width:Number
    
}

    
export class Battle_sceneConfig{
    
    /**
    * 
    */
    
    height:Number
    
    /**
    * 
    */
    
    seed:Number
    
    /**
    * 
    */
    
    time:Number
    
    /**
    * 
    */
    
    width:Number
    
}

    
export class Battle_skillConfig{
    
    /**
    * 
    */
    
    distance:Number
    
    /**
    * 
    */
    
    ignoreNoAttack:boolean
    
    /**
    * 
    */
    
    intervalCd:Number
    
    /**
    * 
    */
    
    isNormalAttack:boolean
    
    /**
    * 
    */
    
    isWithCloseUp:boolean
    
    /**
    * 
    */
    
    name:string
    
    /**
    * 
    */
    
    priority:Number
    
    /**
    * 
    */
    
    requiredPower:Number
    
    /**
    * 
    */
    
    skillId:string
    
    /**
    * 
    */
    
    skillLevel:Number
    
    /**
    * 
    */
    
    skillType:string
    
    /**
    * 
    */
    
    startCd:Number
    
    /**
    * 
    */
    
    triggerTreeName:string
    
}

    
export class BuyCountBO{
    
    /**
    * 已购买次数
    */
    
    buyCount:integer
    
    /**
    * 下次刷新时间戳
    */
    
    freshTs:integer
    
    /**
    * 已使用次数
    */
    
    nowCount:integer
    
    /**
    * 类型
    */
    
    type:integer
    
}

    
export class BuyFromStoreReq{
    
    /**
    * 商品位置
    */
    
    order:integer
    
    /**
    * 商店类型
    */
    
    shopType:string
    
    /**
    * 是否使用视频次数购买
    */
    
    useVideo:boolean
    
}

    
export class ChangeArtifactReq{
    
    /**
    * 
    */
    
    fstArtifactId:string
    
    /**
    * 
    */
    
    fstHeroId:string
    
    /**
    * 
    */
    
    secArtifactId:string
    
    /**
    * 
    */
    
    secHeroId:string
    
}

    
export class ChessEventItem{
    
    /**
    * 事件ID boardEventConfig-id 以及 以下事件
事件ID
101骰子 102普通奖励格 103玩家与僵尸位置重叠 104获取星星
    */
    
    eventId:integer
    
    /**
    * 事件参数【没有则传空】
101：【0普通骰子 1幸运骰子】
102：【奖励configId,奖励索引-0开始】
103：【0玩家追上僵尸 1僵尸追上玩家】
104：【本次获取几个星星】
1001：【需要升级的蘑菇屋的编号】
    */
    
    para:string
    
}

    
export class ChessTenItemVO{
    
    /**
    * 蘑菇屋等级
    */
    
    mashLvMap:object
    
    /**
    * 玩家最终位置
    */
    
    playerStep:integer
    
    /**
    * 奖励
    */
    
    resourceVO:ResourceVO
    
    /**
    * 本次活动获取的星星数
    */
    
    starCount:integer
    
    /**
    * 僵尸最终位置
    */
    
    zombieStep:integer
    
}

    
export class CloneBatSubmitReq{
    
    /**
    * 
    */
    
    double:boolean
    
    /**
    * 挑战的英雄configId
    */
    
    heroConfId:integer
    
    /**
    * 
    */
    
    startTs:string
    
    /**
    * 打过了第几波 clonebattleconfig-Id,第一波都没打过传0
    */
    
    waveNo:integer
    
}

    
export class CloneBatVO{
    
    /**
    * 本次英雄池内容
    */
    
    confIds:array<integer>
    
    /**
    * 今日已挑战次数
    */
    
    dayCount:integer
    
    /**
    * 今日挑战次数统计
    */
    
    dayCountMap:object
    
    /**
    * 今日已刷新次数
    */
    
    freshCount:integer
    
    /**
    * 已挑战过的英雄的最高进度
    */
    
    heroMaxProgress:object
    
    /**
    * 本次英雄池重置时间
    */
    
    refreshTs:integer
    
}

    
export class CloudObjectReq{
    
    /**
    * 存储时长(ms)，在该值时间后，值自动过期，小于1表示不过期
    */
    
    expire:integer
    
    /**
    * 键（不区分role，请务必自行保持唯一）
    */
    
    key:string
    
    /**
    * 对象内容
    */
    
    objData:object
    
}

    
export class CycleGiftBO{
    
    /**
    * 当前已购买次数
    */
    
    nowCount:integer
    
    /**
    * 是否需要支付，免费礼包不需要支付，不要调用支付接口，通过领取接口直接领取
    */
    
    pay:boolean
    
    /**
    * storeconfig表的Id
    */
    
    storeId:integer
    
    /**
    * 9日礼包 10周礼包 11月礼包 12运营活动礼包 storeconfig表的type
    */
    
    type:integer
    
}

    
export class DefendHeroBO{
    
    /**
    * 出场战位 0 表示没有战位
    */
    
    battleStation:integer
    
    /**
    * 组id，高阶竞技场使用必填，默认第一组
    */
    
    groupId:integer
    
    /**
    * 英雄唯一ID
    */
    
    heroId:string
    
}

    
export class DungeonInfoBO{
    
    /**
    * 附带数据(用于客户端存储额外数据)
    */
    
    extra:object
    
    /**
    * 持久化附带数据（不清除）
    */
    
    extraSave:object
    
    /**
    * 助力刷新次数
    */
    
    helpFresh:integer
    
    /**
    * 配置表dungeonconfig-levelID
    */
    
    levelID:integer
    
    /**
    * 
    */
    
    passRecv:boolean
    
    /**
    * 重置时间
    */
    
    resetTs:integer
    
}

    
export class DungeonRewardReq{
    
    /**
    * 事件ID/通关奖励，表示英雄configId
    */
    
    eventId:integer
    
    /**
    * dungeonconfig-levelid
    */
    
    levelId:integer
    
}

    
export class EquipBO{
    
    /**
    * 阵营加成(0：无 1: 武装 2:机械 3:变种 4:僵尸 5:超能 6:毁灭)
    */
    
    campBonus:integer
    
    /**
    * 装备职业类型（1力量 2智力 3敏捷）
    */
    
    career:integer
    
    /**
    * 充能等级
    */
    
    chargingLv:integer
    
    /**
    * equip配置表中对应的id，表示装备ID
    */
    
    equipCofId:integer
    
    /**
    * 装备唯一ID
    */
    
    equipId:string
    
    /**
    * 数据库hero表中的ID。表示谁佩戴了该装备，无人佩戴置为""(空字符串)或null
    */
    
    heroId:string
    
    /**
    * 装备部位（1武器 2盔甲 3头盔 4鞋子）
    */
    
    place:integer
    
    /**
    * 强化等级
    */
    
    strengLv:integer
    
    /**
    *  总星级经验（累计值并不是当前升星等级的经验，可以根据这个值和配置表计算星级）
    */
    
    totalStarExp:integer
    
}

    
export class EquipChangeReq{
    
    /**
    * 
    */
    
    fstEquipId:string
    
    /**
    * 
    */
    
    fstHeroId:string
    
    /**
    * 
    */
    
    secEquipId:string
    
    /**
    * 
    */
    
    secHeroId:string
    
}

    
export class EquipCompIntelliItem{
    
    /**
    * 被消耗的装备IDs
    */
    
    consumeIds:array<string>
    
    /**
    * 装备equipConfig-Id
    */
    
    equipConfId:integer
    
}

    
export class EquipCompReq{
    
    /**
    * 被消耗的装备IDs
    */
    
    consumeIds:array<string>
    
    /**
    * 装备唯一ID
    */
    
    equipId:string
    
}

    
export class EquipDO{
    
    /**
    * 
    */
    
    campBonus:integer
    
    /**
    * 
    */
    
    career:integer
    
    /**
    * 充能等级
    */
    
    chargingLv:integer
    
    /**
    * 
    */
    
    createTs:integer
    
    /**
    * 
    */
    
    equipCofId:integer
    
    /**
    * 
    */
    
    heroId:string
    
    /**
    * 
    */
    
    id:string
    
    /**
    * 
    */
    
    place:integer
    
    /**
    * 
    */
    
    roleId:integer
    
    /**
    * 
    */
    
    strengLv:integer
    
    /**
    * 
    */
    
    totalStarExp:integer
    
}

    
export class EquipInheritReq{
    
    /**
    * 
    */
    
    fstEquipId:string
    
    /**
    * 
    */
    
    secEquipId:string
    
}

    
export class EquipInitBO{
    
    /**
    * 
    */
    
    campBonus:integer
    
    /**
    * 
    */
    
    equipCofId:integer
    
    /**
    * 
    */
    
    no:integer
    
    /**
    * 
    */
    
    star:integer
    
}

    
export class EquipLvUpReq{
    
    /**
    * 装备ID
    */
    
    equipId:string
    
    /**
    * 升到几级
    */
    
    lv:integer
    
}

    
export class EquipRecastReq{
    
    /**
    * 装备唯一ID
    */
    
    equipId:string
    
    /**
    * 目标阵营 0：无 1: 武装 2:机械 3:变种 4:僵尸 5:超能 6:毁灭
    */
    
    fac:integer
    
}

    
export class EquipRewardBO{
    
    /**
    * 数量
    */
    
    amt:string
    
    /**
    * 阵营加成(0：无 1: 武装 2:机械 3:变种 4:僵尸 5:超能 6:毁灭)
    */
    
    campBonus:integer
    
    /**
    * 奖励类型 英雄对应hero, 装备对应equip, 神器对应artifact ,物品对应goods
    */
    
    objId:string
    
    /**
    * 物品Id 英雄对应hero表里面的key, 装备对应equip表里的key
    */
    
    propId:integer
    
    /**
    * 星级
    */
    
    star:integer
    
}

    
export class EquipStarUpReq{
    
    /**
    * 【升星】消耗高级黑铁铸币数量
    */
    
    blackCoinAdvCount:integer
    
    /**
    * 【升星】消耗黑铁铸币数量
    */
    
    blackCoinCount:integer
    
    /**
    * 被强化的装备
    */
    
    equipId:string
    
}

    
export class FPointRecvVO{
    
    /**
    * 
    */
    
    fpoint:GoodVO
    
    /**
    * 新的已领取次数
    */
    
    recvCount:integer
    
}

    
export class FetterAddBO{
    
    /**
    * 生效的的配置Id
    */
    
    effectConfs:array<integer>
    
    /**
    * 最终属性加成
    */
    
    heroModulBO:HeroModulBO
    
}

    
export class FlowerEquipItemBO{
    
    /**
    * 共享的装备IDs
    */
    
    equipIds:array<string>
    
    /**
    * 英雄Id
    */
    
    heroId:string
    
    /**
    * 最终属性加成
    */
    
    heroModulBO:HeroModulBO
    
}

    
export class FlowerPlaceInfoVO{
    
    /**
    * 当前已购买次数
    */
    
    nowBuy:integer
    
    /**
    * 当前格子数
    */
    
    nowCount:integer
    
}

    
export class FreeGiftBO{
    
    /**
    * default表的Id
    */
    
    confId:integer
    
    /**
    * 当前已购买次数
    */
    
    nowCount:integer
    
}

    
export class FriendInfoItem{
    
    /**
    * 头像地址
    */
    
    avatar:string
    
    /**
    * 头像框
    */
    
    avatarFrame:string
    
    /**
    * 当前服id
    */
    
    cdId:integer
    
    /**
    * 共享花坛等级
    */
    
    flowerLv:integer
    
    /**
    * 共享花坛品阶
    */
    
    flowerRank:integer
    
    /**
    * 能否送出友情点
    */
    
    friendPointCanSend:boolean
    
    /**
    * 友情点领取情况 0无法领取 1可以领取 2领取过
    */
    
    friendPointGetStatus:integer
    
    /**
    * 性别  0未知 1男 2女
    */
    
    gender:integer
    
    /**
    * 上次离线时间（如果在线状态为true，该值无效）
    */
    
    lastOfflineTs:integer
    
    /**
    * 等级
    */
    
    lv:integer
    
    /**
    * 昵称
    */
    
    nick:string
    
    /**
    * 
    */
    
    online:boolean
    
    /**
    * 战力
    */
    
    power:integer
    
    /**
    * 关卡进度
    */
    
    progress:string
    
    /**
    * 关系ID，唯一ID用于批量操作，空表示还没有建立关系
    */
    
    relationId:string
    
    /**
    * 角色ID
    */
    
    roleId:string
    
    /**
    * 短ID
    */
    
    shortId:integer
    
    /**
    * 好友状态 -1黑名单 0路人（陌生人）关系，1申请等待中，2好友关系
    */
    
    status:integer
    
    /**
    * vip总经验
    */
    
    vipExp:integer
    
}

    
export class FriendListVO{
    
    /**
    * 当前友情点
    */
    
    fPointNow:integer
    
    /**
    * 
    */
    
    fpointNow:integer
    
    /**
    * 好友列表
    */
    
    friendList:array<FriendInfoItem>
    
    /**
    * 今日领取友情点
    */
    
    hasRecvCount:integer
    
    /**
    * 今日送出友情点
    */
    
    hasSentCount:integer
    
}

    
export class FriendManageVO{
    
    /**
    * 申请列表
    */
    
    applyList:array<FriendInfoItem>
    
    /**
    * 黑名单列表
    */
    
    blackList:array<FriendInfoItem>
    
}

    
export class FriendRelationVO{
    
    /**
    * 关系 -1黑名单 0陌生人 1申请等待中 2好友
    */
    
    relationType:integer
    
    /**
    * 目标roleId
    */
    
    targetRoleId:string
    
}

    
export class GHegeHitReq{
    
    /**
    * 战斗序列号
    */
    
    battleSeq:integer
    
    /**
    * 新的防守阵容(胜利时，传自己的阵容，失败时，传对方的)
    */
    
    battle_heroConfigs:array<Battle_heroConfig>
    
    /**
    * 
    */
    
    neutral:boolean
    
    /**
    * 击杀节点Id
    */
    
    nodeId:integer
    
    /**
    * 是否胜利
    */
    
    win:boolean
    
}

    
export class GHegeRecHeroReq{
    
    /**
    * 节点Id
    */
    
    nodeId:integer
    
    /**
    * 进攻发生时间
    */
    
    ts:string
    
}

    
export class GJourneyBO{
    
    /**
    * 讨伐宝箱领取情况  simple不含 k-GJourneyCRewardItemBO[]:第几只boss-GJourneyCRewardItemBO数组
    */
    
    completeBossRecvIds:object
    
    /**
    * 当前第几天
    */
    
    day:integer
    
    /**
    * 讨伐进度 k-v:第几只BOSS-该BOSS积分
    */
    
    dayBossScoreMap:object
    
    /**
    * 结束时间 最后两小时为公示期，不可参赛
    */
    
    endTs:integer
    
    /**
    * 公会ID
    */
    
    guildId:integer
    
    /**
    * 公会副本等级
    */
    
    journeyLv:integer
    
    /**
    * 本期公会人数（和讨伐宝箱数量有关)
    */
    
    memberCount:integer
    
    /**
    * 最近一次结算时间 -1表示没结算过
    */
    
    preCulEndTs:integer
    
    /**
    * 上次对手公会ID <1表示轮空
    */
    
    preRivalGuildId:integer
    
    /**
    * 上次对手总分
    */
    
    preRivalTotalScore:integer
    
    /**
    * 上次总分
    */
    
    preTotalScore:integer
    
    /**
    * 上次是否胜利
    */
    
    preWin:boolean
    
    /**
    * 敌对公会Id,<1为怪物军团
    */
    
    rivalGuildId:integer
    
    /**
    * 敌对公会总积分 simple不含
    */
    
    rivalTotalScore:integer
    
    /**
    * 个人数据  simple不含
    */
    
    roleInfo:GJourneyRoleBO
    
    /**
    * 本日公会累计积分
    */
    
    score:integer
    
    /**
    * 随机种子
    */
    
    seed:integer
    
    /**
    * 当前主题  1武装 2机械 3变种 4僵尸
    */
    
    theme:integer
    
    /**
    * 本期公会累计积分
    */
    
    totalScore:integer
    
}

    
export class GJourneyCRewardItemBO{
    
    /**
    * 
    */
    
    boxId:integer
    
    /**
    * 
    */
    
    index:integer
    
    /**
    * 
    */
    
    roleId:string
    
}

    
export class GJourneyCompleteRecvReq{
    
    /**
    * 领取第几只怪物的奖励(1-5)
    */
    
    bossIndex:integer
    
    /**
    * 位置号 1开始
    */
    
    rewardIndex:integer
    
}

    
export class GJourneyHitReq{
    
    /**
    * 击杀的是第几只怪物 1-5
    */
    
    bossIndex:integer
    
    /**
    * 关卡难度（1简单2普通3困难） factionganmeconfig-difficulty
    */
    
    difficulty:integer
    
    /**
    * 本次击杀Boss怪物个数
    */
    
    killBoss:integer
    
    /**
    * 本次击杀普通怪物个数
    */
    
    killNormal:integer
    
}

    
export class GJourneyRoleBO{
    
    /**
    * 讨伐奖励领取情况 k-v:第几只boss-是否领取过
    */
    
    bossCompleteRecvMap:object
    
    /**
    * 本日已攻击次数
    */
    
    count:integer
    
    /**
    * 下次次数刷新时间
    */
    
    countFreshTs:integer
    
    /**
    * 个人贡献积分 k-v:第几天-积分
    */
    
    dayScoreMap:object
    
    /**
    * 成就奖励领取详情 k-v:公会副本等级-是否已领取
    */
    
    onceRecvInfo:object
    
    /**
    * 
    */
    
    totalScore:integer
    
}

    
export class GTechBO{
    
    /**
    * 激活的配置ID
    */
    
    activeIds:array<integer>
    
    /**
    * 大类重置计数 techtype-已重置次数
    */
    
    resetMap:object
    
}

    
export class GachaReq{
    
    /**
    * 抽奖次数，暂有1或10
    */
    
    gachaTimes:integer
    
    /**
    * 抽卡类型 1友情池 2 钻石池 3武装 4机械 5变种 6僵尸
    */
    
    gachaType:integer
    
    /**
    * 是否使用视频抽（当为true时，抽奖次数为1 池子为钻石池）
    */
    
    useVideo:boolean
    
}

    
export class GachaVO{
    
    /**
    * 物品消耗后结果状态
    */
    
    goodVO:GoodVO
    
    /**
    * 抽奖结果
    */
    
    heroVOS:array<HeroVO>
    
    /**
    * 
    */
    
    resourceVO:ResourceVO
    
    /**
    * 当前累计十连次数(钻石池)
    */
    
    tenTimes:integer
    
    /**
    *  总抽奖次数
    */
    
    total:integer
    
    /**
    * 心愿英雄
    */
    
    wishHeroIds:array<integer>
    
}

    
export class GashaponReq{
    
    /**
    * 抽奖次数，暂有1或10
    */
    
    gachaTimes:integer
    
    /**
    * 是否使用扭蛋券
    */
    
    useTicket:boolean
    
}

    
export class GashaponVO{
    
    /**
    * 本次英雄池内容
    */
    
    confIds:array<integer>
    
    /**
    * 指定奖励ID
    */
    
    finalId:integer
    
    /**
    * 本次指定英雄重置时间
    */
    
    finalRefreshTs:integer
    
    /**
    * 
    */
    
    firstDan:boolean
    
    /**
    * 本次英雄池重置时间
    */
    
    refreshTs:integer
    
}

    
export class GoodRewardBO{
    
    /**
    * 
    */
    
    amt:integer
    
    /**
    * 
    */
    
    effect:integer
    
    /**
    * 
    */
    
    goodsEnum:string
    
    /**
    * 
    */
    
    objId:string
    
    /**
    * 
    */
    
    propId:integer
    
}

    
export class GoodUseReq{
    
    /**
    * 道具ID
    */
    
    goodsId:integer
    
    /**
    * 附带参数,用于使用需要参数的物品
参数如下:【type=29】[key:faction] value(int): 1: 武装 2:机械 3:变种 4:僵尸 缺省值:1【type=48-50】[key:heroConfId] value(int): 对应heroConfig-Id【type=58】[key:chooseMap] value(HashMap<String,int>): 对应boxselfconfig<uid,个数>
    */
    
    paras:object
    
    /**
    * 使用数量
    */
    
    useCount:integer
    
}

    
export class GoodVO{
    
    /**
    * 数量
    */
    
    amt:integer
    
    /**
    * goods配置表中对应的type，物品类型ID
    */
    
    objId:string
    
    /**
    * goods配置表中对应的key，物品ID
    */
    
    propId:integer
    
}

    
export class GrowUpBO{
    
    /**
    * 是否开启礼包
    */
    
    open:boolean
    
    /**
    * 【成长】growUpConfig Id，【基金】：sevendayfundconfig Id 【首充】第n天-是否领取
    */
    
    recvs:object
    
    /**
    * 当前进度 【成长】stage表ID 【基金】从购买日开始，累计登录天数，购买当天为1 【首充】当前是第几天
    */
    
    stageIdNow:integer
    
}

    
export class GuildApplyOptReq{
    
    /**
    * true:同意 false:拒绝
    */
    
    agree:boolean
    
    /**
    * 需要处理的申请人的roleId
    */
    
    targetIds:array<string>
    
}

    
export class GuildCreateReq{
    
    /**
    * 公会头像
    */
    
    avatar:string
    
    /**
    * 公会名
    */
    
    name:string
    
}

    
export class GuildHegeBO{
    
    /**
    * 分组公会信息（报名结束后的结果才是最终结果,若为空数组表示报名失败）
    */
    
    groupGuildIds:array<integer>
    
    /**
    * 分组ID -1表示报名失败
    */
    
    groupId:integer
    
    /**
    * 已报名名单RoleIds
    */
    
    signIds:array<string>
    
    /**
    * 本次报名开始时间
    */
    
    signStartTs:integer
    
}

    
export class GuildHegeMapBO{
    
    /**
    * 本次结束时间时间
    */
    
    endTs:integer
    
    /**
    * 公会争霸节点信息
    */
    
    nodes:array<GuildHegeNodeBO>
    
    /**
    * 公会争霸个人信息
    */
    
    roleData:GuildHegeRoleDataBO
    
}

    
export class GuildHegeNodeBO{
    
    /**
    * 战斗序列号
    */
    
    battleSeq:integer
    
    /**
    * 所属公会ID，-1表示初始怪物占领
    */
    
    guild:integer
    
    /**
    * 是否战斗中
    */
    
    inBattle:boolean
    
    /**
    * 防守阵容，初始怪物占领时，此项为null
    */
    
    nodeHeroInfos:array<GuildHegeNodeHeroBO>
    
    /**
    * 
    */
    
    nodeId:integer
    
    /**
    * 资源点占领时间
    */
    
    occupyTs:integer
    
    /**
    * 本次资源产出开始时间
    */
    
    produceStartTs:integer
    
    /**
    * 资源点战斗记录
    */
    
    records:array<GuildHegeNodeRecBO>
    
    /**
    * 所属玩家ID，-1表示初始怪物占领
    */
    
    roleId:string
    
}

    
export class GuildHegeNodeHeroBO{
    
    /**
    * 英雄信息
    */
    
    heroConfigInfo:Battle_heroConfig
    
}

    
export class GuildHegeNodeRecBO{
    
    /**
    * 攻击时间
    */
    
    batTs:integer
    
    /**
    * 公会ID
    */
    
    guild:integer
    
    /**
    * 玩家ID
    */
    
    roleId:string
    
    /**
    * 攻占是否成功
    */
    
    win:boolean
    
}

    
export class GuildHegeRoleDataBO{
    
    /**
    * 自己拥有的资源点
    */
    
    haveIds:array<integer>
    
    /**
    * 今日已体力购买次数
    */
    
    nowBuyCount:integer
    
    /**
    * 当前体力值
    */
    
    nowCount:integer
    
    /**
    * 当前已派出英雄 k-v:nodeId-heroIds
    */
    
    outHeroIdsMap:object
    
    /**
    * 下次刷新次数时间
    */
    
    refreshCountTs:integer
    
    /**
    * 下次恢复体力时间(-1表示体力满，无法回复)
    */
    
    refreshTs:integer
    
    /**
    * 个人资源分
    */
    
    score:integer
    
    /**
    * 公会总分
    */
    
    totalScore:integer
    
}

    
export class GuildMailSendReq{
    
    /**
    * 邮件内容
    */
    
    content:string
    
    /**
    * 邮件标题
    */
    
    title:string
    
}

    
export class GuildMemberVO{
    
    /**
    * 当前活跃点
    */
    
    activeScore:integer
    
    /**
    * 头像
    */
    
    avatar:string
    
    /**
    * 头像框
    */
    
    avatarFrame:string
    
    /**
    * 分服服务器ID
    */
    
    cdId:integer
    
    /**
    * 0未知 1男 2女
    */
    
    gender:integer
    
    /**
    * 公会数字ID
    */
    
    guildId:integer
    
    /**
    * 公会职位(对应factionconfig 3成员\2副会长\1会长)
    */
    
    guildJob:integer
    
    /**
    * 当前互助已领取次数
    */
    
    helpRecv:integer
    
    /**
    * 当前互助已赠送次数
    */
    
    helpSend:integer
    
    /**
    * 加入本公会的时间戳（ms）,仅自己才有效
    */
    
    joinTs:integer
    
    /**
    * 上次离线时间（如果在线状态为true，该值无效）
    */
    
    lastOfflineTs:integer
    
    /**
    * 等级
    */
    
    lv:integer
    
    /**
    * 昵称
    */
    
    nick:string
    
    /**
    * 
    */
    
    online:boolean
    
    /**
    * 战斗力
    */
    
    power:integer
    
    /**
    * 角色ID
    */
    
    roleId:string
    
    /**
    * 短ID
    */
    
    shortId:integer
    
    /**
    * userId
    */
    
    userId:integer
    
    /**
    * vip总经验
    */
    
    vipExp:integer
    
}

    
export class GuildOptVO{
    
    /**
    * 已有公会被申请被忽略的名单
    */
    
    hasGuildList:array<RoleVO>
    
    /**
    * 新的申请名单
    */
    
    newList:array<RoleVO>
    
}

    
export class GuildRecommandReq{
    
    /**
    * 按照时间倒序，否：随机抽取
    */
    
    byTime:boolean
    
    /**
    * 获取个数
    */
    
    count:integer
    
}

    
export class GuildSimpleReq{
    
    /**
    * 需要获取的公会IDs
    */
    
    guildIds:array<integer>
    
    /**
    * 是否需要获取成员列表
    */
    
    needMember:boolean
    
}

    
export class GuildSimpleVO{
    
    /**
    * 公会头像
    */
    
    avatar:string
    
    /**
    * 公会创建时间
    */
    
    createTs:integer
    
    /**
    * 公会数字ID
    */
    
    id:integer
    
    /**
    * 公会等级
    */
    
    lv:integer
    
    /**
    * 成员列表
    */
    
    members:array<RoleSimpleVO>
    
    /**
    * 公会名
    */
    
    name:string
    
}

    
export class GuildStatueBO{
    
    /**
    * 雕像配置
    */
    
    conf:StatueConfig
    
    /**
    * 雕像配置(互助缓存值)
    */
    
    confCache:StatueConfig
    
    /**
    * 部位组成
    */
    
    parts:array<GuildStatuePartBO>
    
    /**
    * 当前雕像等级
    */
    
    statueRank:integer
    
}

    
export class GuildStatuePartBO{
    
    /**
    * 是否开启视频临时加成
    */
    
    buffOn:boolean
    
    /**
    * StatueRankConfig
    */
    
    config:StatueRankConfig
    
    /**
    * 部位铸造总量
    */
    
    exps:object
    
    /**
    * 属性加成信息
    */
    
    heroModulBO:HeroModulBO
    
    /**
    * 今日已强化进度
    */
    
    todayProgress:integer
    
    /**
    * 当前部位
    */
    
    type:integer
    
}

    
export class GuildStatueRecVO{
    
    /**
    * 升级后的雕像等级(仅isStatueUp=true有效)
    */
    
    newStatueLv:integer
    
    /**
    * 贡献值
    */
    
    recInfo:object
    
    /**
    * 角色VO
    */
    
    role:RoleVO
    
    /**
    * 
    */
    
    statueUp:boolean
    
    /**
    * 发生时间(ms)
    */
    
    ts:integer
    
}

    
export class GuildStatueStrengReq{
    
    /**
    * 提供的材料
    */
    
    give:object
    
    /**
    * 强化雕像部位 statueRankConfig-statueType
    */
    
    type:integer
    
}

    
export class GuildStrengBO{
    
    /**
    * 雕像信息
    */
    
    info:GuildStatueBO
    
    /**
    * 消耗返还（当由于消耗品过多有剩余的时候返回）
    */
    
    retComsume:object
    
}

    
export class GuildTableInfoVO{
    
    /**
    * 当前已转次数
    */
    
    roleTableCount:integer
    
}

    
export class GuildVO{
    
    /**
    * 公会头像
    */
    
    avatar:string
    
    /**
    * 公会创建时间
    */
    
    createTs:integer
    
    /**
    * 累积活跃
    */
    
    cumActiveScore:integer
    
    /**
    * 准入等级
    */
    
    enterLv:integer
    
    /**
    * 入会模式 0所有人可加入 1批准加入 2不可加入
    */
    
    enterMode:integer
    
    /**
    * 公会雕像信息
    */
    
    guildStatue:GuildStatueBO
    
    /**
    * 公会数字ID
    */
    
    id:integer
    
    /**
    * 公会等级
    */
    
    lv:integer
    
    /**
    * 人数上限
    */
    
    memberMax:integer
    
    /**
    * 成员名单
    */
    
    memeber:array<GuildMemberVO>
    
    /**
    * 公会名
    */
    
    name:string
    
    /**
    * 公会公告
    */
    
    notice:string
    
    /**
    * 当前活跃
    */
    
    nowActiveScore:integer
    
}

    
export class HangUpProduceBO{
    
    /**
    * 粉尘产出
    */
    
    dustProduce:integer
    
    /**
    * 
    */
    
    empty:boolean
    
    /**
    * 装备产出
    */
    
    equipProduce:array<RewardBO>
    
    /**
    * 金币产出
    */
    
    goldProduce:integer
    
    /**
    * 团队经验产出
    */
    
    groupExpProduce:integer
    
    /**
    * 英雄经验产出
    */
    
    heroExpProduce:integer
    
}

    
export class HangUpProduceVO{
    
    /**
    * 本次挂机产出
    */
    
    produce:HangUpProduceBO
    
    /**
    * 资源VO，同所有其他ResourceVO
    */
    
    resource:ResourceVO
    
    /**
    * 新的挂机产速信息
    */
    
    speed:HangUpSpeedBO
    
}

    
export class HangUpSpeedBO{
    
    /**
    * 金币产速（每分钟）
    */
    
    goldSpeed:integer
    
    /**
    * 团队经验产速（每分钟）
    */
    
    groupExpSpeed:integer
    
    /**
    * 英雄经验产速（每分钟）
    */
    
    heroExpSpeed:integer
    
    /**
    * 快速挂机价格
    */
    
    quickHangCost:integer
    
    /**
    * 剩余快速挂机次数
    */
    
    quickRemain:integer
    
    /**
    * 快速挂机次数重置时间戳(ms)
    */
    
    quickResetTs:integer
    
    /**
    * 挂机开始时间(ms)
    */
    
    startTs:integer
    
}

    
    
    
    
    
export class HelpHeroVO{
    
    /**
    * 是否正在任务，否则在图书馆休息
    */
    
    atTask:boolean
    
    /**
    * 外援角色昵称
    */
    
    helpRoleNick:string
    
    /**
    * 英雄成长面板在hero配置表中的ID
    */
    
    heroCofId:integer
    
    /**
    * 英雄唯一id
    */
    
    heroId:string
    
    /**
    * 英雄等级
    */
    
    lv:integer
    
    /**
    * 品阶
    */
    
    rank:integer
    
    /**
    * 角色id
    */
    
    roleId:string
    
    /**
    * 外援任务id Xsconfig表配置id
    */
    
    xsId:integer
    
}

    
export class HeroBO{
    
    /**
    * 穿戴神器
    */
    
    artifact:ArtifactBO
    
    /**
    * 攻击
    */
    
    atkValue:integer
    
    /**
    * 每秒恢复能量
    */
    
    autoEnergy:integer
    
    /**
    * 受击恢复能量
    */
    
    beHitEnergy:number
    
    /**
    * 神器主动技能暴击伤害
    */
    
    criAtkArtifact:number
    
    /**
    * 神器主动技能暴击率
    */
    
    criPctArtifact:number
    
    /**
    * 暴击伤害
    */
    
    criticalAtkValue:number
    
    /**
    * 暴击率
    */
    
    criticalPct:number
    
    /**
    * 抗暴击
    */
    
    deCritical:number
    
    /**
    * 神器主动技能减伤
    */
    
    decArtifactHarm:number
    
    /**
    * 防御
    */
    
    defValue:integer
    
    /**
    * 闪避
    */
    
    dodgeValue:integer
    
    /**
    * 装备穿戴
    */
    
    equips:array<EquipBO>
    
    /**
    * 总经验（根据heroLv）
    */
    
    exp:integer
    
    /**
    * 附带信息，根据接口附带额外数据：
佣兵
1.merc_applyStatus:int-佣兵申请状态[0:可申请,1:申请中,2:已申请到,3:已被别人申请]
2.merc_useCount:Object(k-v)[系统ID-使用次数]
3.merc_applyCount:long-有多少人在申请（仅当merc_applyStatus=1时有效）
4.merc_outRoleId:String-谁申请到了（仅当merc_applyStatus=2或3时有效
    */
    
    extra:object
    
    /**
    * 共享花坛位置(<1表示不在共享花坛，>0表示其共享花坛位置)
    */
    
    flowerPlace:integer
    
    /**
    * 治疗能力增加
    */
    
    healCap:number
    
    /**
    * 模块加成信息
    */
    
    heroAddInfos:array<HeroModulDO>
    
    /**
    * 英雄成长面板在hero配置表中的ID
    */
    
    heroCofId:integer
    
    /**
    * 英雄ID，英雄的唯一标识
    */
    
    heroId:string
    
    /**
    * 攻击恢复能量
    */
    
    hitEnergy:integer
    
    /**
    * 命中
    */
    
    hitValue:integer
    
    /**
    * 生命
    */
    
    hp:integer
    
    /**
    * 神器主动技能增伤
    */
    
    incArtifactHarm:number
    
    /**
    * 伤害增加
    */
    
    incHarm:number
    
    /**
    * 攻击速度
    */
    
    intervalCd:integer
    
    /**
    * 吸血等级
    */
    
    liftLeechValue:integer
    
    /**
    * 是否被锁定
    */
    
    lock:boolean
    
    /**
    * 等级
    */
    
    lv:integer
    
    /**
    * 魔法减伤率
    */
    
    magicResistPct:number
    
    /**
    * 移动速度
    */
    
    moveSpeed:integer
    
    /**
    * 物理减伤率
    */
    
    phyResistPct:number
    
    /**
    * 品阶
    */
    
    rank:integer
    
    /**
    * 每秒回复
    */
    
    recoverSec:integer
    
    /**
    * 角色ID
    */
    
    roleId:string
    
    /**
    * 技能伤害
    */
    
    skillHarm:number
    
    /**
    * 迅捷等级
    */
    
    skillSpeed:integer
    
    /**
    * 穿戴皮肤Id
    */
    
    skinId:integer
    
    /**
    * 星级
    */
    
    star:integer
    
}

    
export class HeroBagVO{
    
    /**
    * 神器祭坛加成
    */
    
    artifactAltarAdd:HeroModulBO
    
    /**
    * 购买格子花费
    */
    
    buyCost:integer
    
    /**
    * 
    */
    
    gtechAdd:array<HeroModulBO>
    
    /**
    * 英雄羁绊加成
    */
    
    heroFetterAdd:array<FetterAddBO>
    
    /**
    * 共享祭祀装备加成，只有在共享花坛的英雄可能有
    */
    
    heroFlowerEquipAdd:array<FlowerEquipItemBO>
    
    /**
    * 英雄列表
    */
    
    heroes:array<HeroVO>
    
    /**
    * 图书馆羁绊加成
    */
    
    libFetterAdd:FetterAddBO
    
    /**
    * 勋章等级加成
    */
    
    medalAdd:HeroModulBO
    
    /**
    * 皮肤加成
    */
    
    skinAdd:array<TalentAddVO>
    
    /**
    * 战略树加成，heroCofId对应medaltechconfig.id
    */
    
    stratAdd:array<HeroModulBO>
    
    /**
    * 天赋加成列表
    */
    
    talentAdd:array<TalentAddVO>
    
}

    
export class HeroBookVO{
    
    /**
    * 英雄成长面板在hero配置表中的ID
    */
    
    heroCofId:integer
    
    /**
    * 是否领取奖励 0未领取 1领取
    */
    
    isGet:integer
    
    /**
    * 获得过的最高品阶
    */
    
    topRank:integer
    
    /**
    * 获得过的最高星级
    */
    
    topStar:integer
    
}

    
export class HeroCapacityVO{
    
    /**
    * 购买格子花费
    */
    
    buyCost:integer
    
    /**
    * 新的容量
    */
    
    heroCapacity:integer
    
}

    
export class HeroChangeEnterReq{
    
    /**
    * 置换目标configId
    */
    
    changeHeroConf:integer
    
    /**
    * 红包个数
    */
    
    heroId:string
    
}

    
export class HeroDO{
    
    /**
    * 
    */
    
    atkValue:integer
    
    /**
    * 
    */
    
    autoEnergy:integer
    
    /**
    * 
    */
    
    beHitEnergy:number
    
    /**
    * 
    */
    
    createTs:integer
    
    /**
    * 
    */
    
    criAtkArtifact:number
    
    /**
    * 
    */
    
    criPctArtifact:number
    
    /**
    * 
    */
    
    criticalAtkValue:number
    
    /**
    * 
    */
    
    criticalPct:number
    
    /**
    * 
    */
    
    deCritical:number
    
    /**
    * 
    */
    
    decArtifactHarm:number
    
    /**
    * 
    */
    
    defValue:integer
    
    /**
    * 
    */
    
    dodgeValue:integer
    
    /**
    * 
    */
    
    exp:integer
    
    /**
    * 
    */
    
    flowerPlace:integer
    
    /**
    * 
    */
    
    healCap:number
    
    /**
    * 
    */
    
    heroCofId:integer
    
    /**
    * 
    */
    
    hitEnergy:integer
    
    /**
    * 
    */
    
    hitValue:integer
    
    /**
    * 
    */
    
    hp:integer
    
    /**
    * 
    */
    
    id:string
    
    /**
    * 
    */
    
    incArtifactHarm:number
    
    /**
    * 
    */
    
    incHarm:number
    
    /**
    * 
    */
    
    intervalCd:integer
    
    /**
    * 
    */
    
    liftLeechValue:integer
    
    /**
    * 
    */
    
    lock:boolean
    
    /**
    * 
    */
    
    lv:integer
    
    /**
    * 
    */
    
    magicResistPct:number
    
    /**
    * 
    */
    
    moveSpeed:integer
    
    /**
    * 
    */
    
    phyResistPct:number
    
    /**
    * 
    */
    
    rank:integer
    
    /**
    * 
    */
    
    recoverSec:integer
    
    /**
    * 
    */
    
    roleId:integer
    
    /**
    * 
    */
    
    skillHarm:number
    
    /**
    * 
    */
    
    skillSpeed:integer
    
    /**
    * 
    */
    
    skilllVS:array<integer>
    
    /**
    * 
    */
    
    skinId:integer
    
    /**
    * 
    */
    
    star:integer
    
}

    
export class HeroInitBO{
    
    /**
    * 
    */
    
    heroCofId:integer
    
    /**
    * 
    */
    
    lv:integer
    
    /**
    * 
    */
    
    no:integer
    
    /**
    * 
    */
    
    rank:integer
    
    /**
    * 
    */
    
    star:integer
    
}

    
export class HeroLvUpReq{
    
    /**
    * 英雄ID
    */
    
    heroId:string
    
    /**
    * 升到几级
    */
    
    lv:integer
    
}

    
export class HeroLvUpVO{
    
    /**
    * 消耗品的剩余值
    */
    
    goods:array<GoodVO>
    
    /**
    * 英雄信息 由于升级只改变英雄裸属性，不反回模块加成部分，请客户端同学不要由于返回中的模块加成为空清空模块加成
    */
    
    heroVO:HeroVO
    
}

    
export class HeroModulAddItem{
    
    /**
    * 加成百分比
    */
    
    addPct:number
    
    /**
    * 加成值
    */
    
    addValue:number
    
    /**
    * 
    */
    
    empty:boolean
    
}

    
export class HeroModulBO{
    
    /**
    * 攻击加成
    */
    
    atkAdd:HeroModulAddItem
    
    /**
    * 每秒回能
    */
    
    autoEnergyAdd:HeroModulAddItem
    
    /**
    * 受击恢复能量
    */
    
    beHitEnergyAdd:HeroModulAddItem
    
    /**
    * 暴击伤害加成
    */
    
    criAtkAdd:HeroModulAddItem
    
    /**
    * 神器主动技能暴击伤害
    */
    
    criAtkArtifactAdd:HeroModulAddItem
    
    /**
    * 暴击率加成
    */
    
    criPctAdd:HeroModulAddItem
    
    /**
    * 神器主动技能暴击率
    */
    
    criPctArtifactAdd:HeroModulAddItem
    
    /**
    * 抗暴击
    */
    
    deCriAdd:HeroModulAddItem
    
    /**
    * 神器主动技能减伤
    */
    
    decArtifactHarmAdd:HeroModulAddItem
    
    /**
    * 防御加成
    */
    
    defAdd:HeroModulAddItem
    
    /**
    * 闪避加成
    */
    
    dodgeAdd:HeroModulAddItem
    
    /**
    * 治疗能力
    */
    
    healCapAdd:HeroModulAddItem
    
    /**
    * 英雄成长面板在hero配置表中的ID,当表示全部时，为加成配置表ID：公会雕像【statueRankConfig-Id】，羁绊/天赋时，表示生效的英雄confId，公会科技时，表示英雄定位【1输出 2辅助 3坦克 4控制】，勋章加成时，表示medaltechconfig.id
    */
    
    heroCofId:integer
    
    /**
    * 英雄唯一ID，空表示全部或者一类英雄
    */
    
    heroId:string
    
    /**
    * 命中加成
    */
    
    hitAdd:HeroModulAddItem
    
    /**
    * 攻击恢复能量
    */
    
    hitEnergyAdd:HeroModulAddItem
    
    /**
    * 生命加成
    */
    
    hpAdd:HeroModulAddItem
    
    /**
    * 神器主动技能增伤
    */
    
    incArtifactHarmAdd:HeroModulAddItem
    
    /**
    * 伤害增加
    */
    
    incHarmAdd:HeroModulAddItem
    
    /**
    * 普攻CD
    */
    
    intervalCdAdd:HeroModulAddItem
    
    /**
    * 吸血等级加成
    */
    
    liftLeechAdd:HeroModulAddItem
    
    /**
    * 魔免加成
    */
    
    magicResistAdd:HeroModulAddItem
    
    /**
    * 加成所属的模块类型
    */
    
    moduType:string
    
    /**
    * 移动速度
    */
    
    moveSpeedAdd:HeroModulAddItem
    
    /**
    * 物免加成
    */
    
    phyResistAdd:HeroModulAddItem
    
    /**
    * 秒回复加成
    */
    
    recoverSecAdd:HeroModulAddItem
    
    /**
    * 技能伤害
    */
    
    skillHarmAdd:HeroModulAddItem
    
    /**
    * 迅捷等级
    */
    
    skillSpeedAdd:HeroModulAddItem
    
}

    
export class HeroModulDO{
    
    /**
    * 
    */
    
    atkAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    autoEnergyAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    beHitEnergyAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    createTs:integer
    
    /**
    * 
    */
    
    criAtkAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    criAtkArtifactAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    criPctAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    criPctArtifactAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    deCriAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    decArtifactHarmAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    defAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    dodgeAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    healCapAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    heroCofId:integer
    
    /**
    * 
    */
    
    heroId:string
    
    /**
    * 
    */
    
    hitAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    hitEnergyAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    hpAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    id:string
    
    /**
    * 
    */
    
    incArtifactHarmAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    incHarmAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    intervalCdAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    liftLeechAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    magicResistAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    moduType:string
    
    /**
    * 
    */
    
    moveSpeedAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    phyResistAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    recoverSecAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    roleId:integer
    
    /**
    * 
    */
    
    skillHarmAdd:HeroModulAddItem
    
    /**
    * 
    */
    
    skillSpeedAdd:HeroModulAddItem
    
}

    
export class HeroRewardBO{
    
    /**
    * 数量
    */
    
    amt:string
    
    /**
    * 等级
    */
    
    lv:integer
    
    /**
    * 奖励类型 英雄对应hero, 装备对应equip, 神器对应artifact ,物品对应goods
    */
    
    objId:string
    
    /**
    * 物品Id 英雄对应hero表里面的key, 装备对应equip表里的key
    */
    
    propId:integer
    
    /**
    * 品阶
    */
    
    rank:integer
    
    /**
    * 星级
    */
    
    star:integer
    
}

    
export class HeroSimpleBO{
    
    /**
    * 出场战位
    */
    
    battleStation:integer
    
    /**
    * 英雄具体数据
    */
    
    data:HeroBO
    
    /**
    * 组id，高阶竞技场使用，默认第一组
    */
    
    groupId:integer
    
    /**
    * 英雄唯一ID
    */
    
    heroId:string
    
    /**
    * 附加技能 map: skillId-lv
    */
    
    skillAdd:object
    
}

    
export class HeroVO{
    
    /**
    * 穿戴神器
    */
    
    artifact:ArtifactBO
    
    /**
    * 攻击
    */
    
    atkValue:integer
    
    /**
    * 每秒恢复能量
    */
    
    autoEnergy:integer
    
    /**
    * 受击恢复能量
    */
    
    beHitEnergy:number
    
    /**
    * 神器主动技能暴击伤害
    */
    
    criAtkArtifact:number
    
    /**
    * 神器主动技能暴击率
    */
    
    criPctArtifact:number
    
    /**
    * 暴击伤害
    */
    
    criticalAtkValue:number
    
    /**
    * 暴击率
    */
    
    criticalPct:number
    
    /**
    * 抗暴击
    */
    
    deCritical:number
    
    /**
    * 神器主动技能减伤
    */
    
    decArtifactHarm:number
    
    /**
    * 防御
    */
    
    defValue:integer
    
    /**
    * 闪避
    */
    
    dodgeValue:integer
    
    /**
    * 装备穿戴
    */
    
    equips:array<EquipBO>
    
    /**
    * 总经验（根据heroLv）
    */
    
    exp:integer
    
    /**
    * 附带信息，根据接口附带额外数据：
佣兵
1.merc_applyStatus:int-佣兵申请状态[0:可申请,1:申请中,2:已申请到,3:已被别人申请]
2.merc_useCount:Object(k-v)[系统ID-使用次数]
3.merc_applyCount:long-有多少人在申请（仅当merc_applyStatus=1时有效）
4.merc_outRoleId:String-谁申请到了（仅当merc_applyStatus=2或3时有效）
    */
    
    extra:object
    
    /**
    * 共享花坛位置(<1表示不在共享花坛，>0表示其共享花坛位置)
    */
    
    flowerPlace:integer
    
    /**
    * 治疗能力增加
    */
    
    healCap:number
    
    /**
    * 模块加成信息
    */
    
    heroAddInfos:array<HeroModulBO>
    
    /**
    * 英雄成长面板在hero配置表中的ID
    */
    
    heroCofId:integer
    
    /**
    * 英雄ID，英雄的唯一标识
    */
    
    heroId:string
    
    /**
    * 攻击恢复能量
    */
    
    hitEnergy:integer
    
    /**
    * 命中
    */
    
    hitValue:integer
    
    /**
    * 生命
    */
    
    hp:integer
    
    /**
    * 神器主动技能增伤
    */
    
    incArtifactHarm:number
    
    /**
    * 伤害增加
    */
    
    incHarm:number
    
    /**
    * 攻击速度
    */
    
    intervalCd:integer
    
    /**
    * 吸血等级
    */
    
    liftLeechValue:integer
    
    /**
    * 是否被锁定
    */
    
    lock:boolean
    
    /**
    * 等级
    */
    
    lv:integer
    
    /**
    * 魔法减伤率
    */
    
    magicResistPct:number
    
    /**
    * 移动速度
    */
    
    moveSpeed:integer
    
    /**
    * 物理减伤率
    */
    
    phyResistPct:number
    
    /**
    * 品阶
    */
    
    rank:integer
    
    /**
    * 每秒回复
    */
    
    recoverSec:integer
    
    /**
    * 角色ID
    */
    
    roleId:string
    
    /**
    * 技能伤害
    */
    
    skillHarm:number
    
    /**
    * 迅捷等级
    */
    
    skillSpeed:integer
    
    /**
    * 穿戴皮肤Id
    */
    
    skinId:integer
    
    /**
    * 星级
    */
    
    star:integer
    
}

    
export class HuntBossVO{
    
    /**
    * Boss唯一ID
    */
    
    bossId:string
    
    /**
    * 已购买挑战次数
    */
    
    buyCount:integer
    
    /**
    * 结束时间戳(ms)
    */
    
    endTs:integer
    
    /**
    * 本次弱点联盟 1武装 2机械 3变种 4僵尸 5超能 6毁灭
    */
    
    flawFac:integer
    
    /**
    * 剩余可挑战次数
    */
    
    hitCountRemain:integer
    
    /**
    * 最高伤害记录
    */
    
    topRecord:HuntRecordVO
    
    /**
    * 累计伤害，防止丢精度，使用string
    */
    
    totalHurt:string
    
    /**
    * boss类型 huntconfig中type 1八角刺 2毒箭木
    */
    
    type:integer
    
}

    
export class HuntHitReq{
    
    /**
    * bossId
    */
    
    bossId:string
    
    /**
    * 战报
    */
    
    result:object
    
    /**
    * 种子
    */
    
    seed:string
    
    /**
    * 扫荡(扫荡不记录)
    */
    
    sweep:boolean
    
    /**
    * 总伤害量
    */
    
    totalHurt:string
    
    /**
    * 1八角刺 2毒箭木
    */
    
    type:integer
    
}

    
export class HuntRecordReq{
    
    /**
    * BossId
    */
    
    boosId:string
    
    /**
    * 1八角刺 2毒箭木
    */
    
    type:integer
    
}

    
export class HuntRecordVO{
    
    /**
    * 战报下载oss地址
    */
    
    battleOssUrl:string
    
    /**
    * 战斗时间
    */
    
    battleTs:integer
    
    /**
    * 攻击者信息
    */
    
    roleVO:RoleVO
    
    /**
    * 总伤害
    */
    
    totalHurt:string
    
}

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
export class JSONResult{
    
    /**
    * 
    */
    
    c:integer
    
    /**
    * 
    */
    
    c_min_v:string
    
    /**
    * 
    */
    
    errorcode:string
    
    /**
    * 
    */
    
    m:string
    
    /**
    * 
    */
    
    map_min_v:object
    
    /**
    * 
    */
    
    ok:boolean
    
    /**
    * 
    */
    
    r:object
    
    /**
    * 
    */
    
    ts:integer
    
}

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
export class KaoShangBO{
    
    /**
    * 本期结束时间 -1表示未开启
    */
    
    endTs:integer
    
    /**
    * 当前积分
    */
    
    nowScore:integer
    
    /**
    * 是否购买付费奖励
    */
    
    pay:boolean
    
    /**
    * 领取详情
    */
    
    recvs:array<KaoShangItem>
    
    /**
    * 1活跃 2智慧树
    */
    
    type:integer
    
}

    
export class KaoShangItem{
    
    /**
    * kaoshangConfig Id/stagerewardconfig
    */
    
    id:integer
    
    /**
    * 是否领取收费奖励
    */
    
    recvPay:boolean
    
    /**
    * 是否领取免费奖励
    */
    
    recvfree:boolean
    
}

    
    
export class KeyValueReq{
    
    /**
    * 键
    */
    
    key:string
    
    /**
    * 值
    */
    
    objData:object
    
}

    
export class LanguageBO{
    
    /**
    * 
    */
    
    content:string
    
    /**
    * 
    */
    
    language:string
    
    /**
    * 
    */
    
    title:string
    
}

    
export class LikeSOReq{
    
    /**
    * 给谁点赞
    */
    
    targetRoleId:string
    
    /**
    * 0战力榜 1周期活动排行榜
    */
    
    type:integer
    
}

    
export class LvUpArtifactReq{
    
    /**
    * 消耗品
    */
    
    consume:array<GoodUseReq>
    
}

    
export class MailDO{
    
    /**
    * 
    */
    
    _appId_:integer
    
    /**
    * 
    */
    
    _cdId_:integer
    
    /**
    * 
    */
    
    _roleId_:integer
    
    /**
    * 
    */
    
    _uid_:string
    
    /**
    * 
    */
    
    _userId_:integer
    
    /**
    * 
    */
    
    baseRewards:array<HashMap<string,string>>
    
    /**
    * 
    */
    
    content:string
    
    /**
    * 
    */
    
    create:integer
    
    /**
    * 
    */
    
    extraData:object
    
    /**
    * 
    */
    
    i18n:array<LanguageBO>
    
    /**
    * 
    */
    
    id:string
    
    /**
    * 
    */
    
    mailSysId:string
    
    /**
    * 
    */
    
    read:boolean
    
    /**
    * 
    */
    
    receiveAt:integer
    
    /**
    * 
    */
    
    rewardGot:boolean
    
    /**
    * 
    */
    
    rewards:array<HashMap<string,string>>
    
    /**
    * 
    */
    
    sender:MailSender
    
    /**
    * 
    */
    
    source:string
    
    /**
    * 
    */
    
    system:boolean
    
    /**
    * 
    */
    
    templateId:string
    
    /**
    * 
    */
    
    templateValue:object
    
    /**
    * 
    */
    
    title:string
    
}

    
export class MailSendReq{
    
    /**
    * 邮件内容
    */
    
    content:string
    
    /**
    * 接收者ID
    */
    
    roleId:string
    
    /**
    * 邮件标题
    */
    
    title:string
    
}

    
export class MailSender{
    
    /**
    * 
    */
    
    name:string
    
    /**
    * 
    */
    
    roleId:integer
    
    /**
    * 
    */
    
    userId:integer
    
}

    
export class MailSenderVO{
    
    /**
    * 昵称
    */
    
    name:string
    
    /**
    * 角色DI
    */
    
    roleId:string
    
    /**
    * 账号ID
    */
    
    userId:integer
    
}

    
export class MailVO{
    
    /**
    * 内容
    */
    
    content:string
    
    /**
    * 发放时间
    */
    
    create:integer
    
    /**
    * 
    */
    
    extraData:object
    
    /**
    * 邮件ID
    */
    
    id:string
    
    /**
    * 是否已读
    */
    
    read:boolean
    
    /**
    * 奖励已领取
    */
    
    rewardGot:boolean
    
    /**
    * 奖励列表objId 英雄对应hero,装备对应equip,神器对应artifacts,物品对应goods
    */
    
    rewards:array<object>
    
    /**
    * 发件人信息
    */
    
    sender:MailSenderVO
    
    /**
    * 是否系统邮件
    */
    
    system:boolean
    
    /**
    * 邮件模板Id，游戏内发的邮件会用到，需要配合模板表来
    */
    
    templateId:string
    
    /**
    * 邮件模板Value，K-V的方式，需要刷新模板中的内容
    */
    
    templateValue:object
    
    /**
    * 标题
    */
    
    title:string
    
}

    
export class MainTaskInfoVO{
    
    /**
    * 进度（引导任务时，此值无效）,新手七日新版时，双参数任务progress>0表示完成
    */
    
    progress:integer
    
    /**
    * 是否已经领取
    */
    
    recv:boolean
    
    /**
    * 任务ID taskconfig中的taskId/guidetaskconfig/boardconfig/sevendaysnewconfig/medalstagerewardconfig中的Id
    */
    
    taskId:integer
    
}

    
    
export class MercApplyReq{
    
    /**
    * 目标HeroId
    */
    
    heroId:string
    
    /**
    * 目标RoleID
    */
    
    roleId:string
    
}

    
export class MercApplyVO{
    
    /**
    * 申请的英雄ID
    */
    
    heroId:string
    
    /**
    * 该英雄的申请人列表
    */
    
    roleIds:array<RoleVO>
    
}

    
export class MercInfoVO{
    
    /**
    * 佣兵英雄列表
    */
    
    heroes:array<HeroVO>
    
    /**
    * 重置时间
    */
    
    resetTs:integer
    
    /**
    * 天赋加成列表
    */
    
    talentAddList:array<TalentSimpleInfoVO>
    
}

    
export class MercOptApplyReq{
    
    /**
    * true 同意/false 忽略
    */
    
    agree:boolean
    
    /**
    * 需要操作的英雄ID
    */
    
    heroId:string
    
    /**
    * 需要操作的申请者ID
    */
    
    roleId:string
    
}

    
export class MercOutVO{
    
    /**
    * 借出的英雄ID
    */
    
    heroId:string
    
    /**
    * 使用者Role
    */
    
    user:RoleVO
    
}

    
export class MercUseIncReq{
    
    /**
    * 目标HeroId
    */
    
    heroId:string
    
    /**
    * 系统ID 1主线副本 2摩天楼 3奇妙时空 4禅镜花园 5智慧树
    */
    
    systemId:string
    
}

    
export class MonthCardBO{
    
    /**
    * 0普通月卡 1超级月卡 2周卡
    */
    
    cardType:integer
    
    /**
    * 截止时间 <=0表示无效
    */
    
    endTs:integer
    
    /**
    * 今日是否领取
    */
    
    recv:boolean
    
}

    
export class Number{
    
}

    
export class OnlineGiftRecvReq{
    
    /**
    * 配置ID
    */
    
    confId:integer
    
    /**
    * 一键领取
    */
    
    recvAll:boolean
    
}

    
export class PayCallBO{
    
    /**
    * 
    */
    
    appId:integer
    
    /**
    * 
    */
    
    createTime:integer
    
    /**
    * 
    */
    
    extra:string
    
    /**
    * 
    */
    
    goodsId:integer
    
    /**
    * 
    */
    
    outTradeNo:string
    
    /**
    * 
    */
    
    paySign:string
    
    /**
    * 
    */
    
    purchase:string
    
    /**
    * 
    */
    
    quantity:integer
    
    /**
    * 
    */
    
    state:integer
    
    /**
    * 
    */
    
    title:string
    
    /**
    * 
    */
    
    userId:integer
    
}

    
export class PayOrderDO{
    
    /**
    * 
    */
    
    appId:integer
    
    /**
    * 
    */
    
    cdId:integer
    
    /**
    * 
    */
    
    createTs:integer
    
    /**
    * 
    */
    
    extra:object
    
    /**
    * 
    */
    
    goodsId:integer
    
    /**
    * 
    */
    
    id:string
    
    /**
    * 
    */
    
    outTradeNo:string
    
    /**
    * 
    */
    
    paySign:string
    
    /**
    * 
    */
    
    purchase:string
    
    /**
    * 
    */
    
    quantity:integer
    
    /**
    * 
    */
    
    reason:object
    
    /**
    * 
    */
    
    resource:object
    
    /**
    * 
    */
    
    roleId:integer
    
    /**
    * 
    */
    
    shortId:integer
    
    /**
    * 
    */
    
    state:integer
    
    /**
    * 
    */
    
    title:string
    
    /**
    * 
    */
    
    userId:integer
    
    /**
    * 
    */
    
    way:string
    
}

    
export class PayOrderReq{
    
    /**
    * 区服ID
    */
    
    cdid:integer
    
    /**
    * 订单号
    */
    
    tradeOutNo:string
    
}

    
export class PioneerRecvBO{
    
    /**
    * 入罐详情 pionner2config的id-是否存入
    */
    
    enterDetail:object
    
    /**
    * 先锋储蓄罐未领张数
    */
    
    reaminCount:integer
    
    /**
    * 先锋储蓄罐已领取张数
    */
    
    recvCount:integer
    
    /**
    * 每次最小领取数额
    */
    
    recvLimit:integer
    
    /**
    * 进度stageId
    */
    
    stageId:integer
    
}

    
export class PlayBackReq{
    
    /**
    * 普通-战斗编号/高阶-系列战斗编号
    */
    
    battleNo:string
    
    /**
    * 竞技场类型 0普通 1高阶
    */
    
    type:integer
    
}

    
export class ProcessRecordVO{
    
    /**
    * 关系类型 0、全服  1、工会 2、好友
    */
    
    relationType:integer
    
    /**
    * 角色信息
    */
    
    roleVO:RoleVO
    
}

    
export class ProcessReq{
    
    /**
    * 附带信息 地牢时，输入英雄configId
    */
    
    paras:array<string>
    
    /**
    * 主线对应stageConfig表ID,摩天楼对应层数，地牢对应dungeonconfig-levelId
    */
    
    stageId:integer
    
    /**
    * 系统类型 1主线副本 2摩天楼 3武装 4机械 5变种 6僵尸 7地牢
    */
    
    systemId:integer
    
}

    
export class ProcessVO{
    
    /**
    * 主线对应建筑stageConfig表HouseID/地牢时，表示英雄ID
    */
    
    houseId:integer
    
    /**
    * 主线对应关卡stageConfig level,其他对应地图点坐标
    */
    
    level:integer
    
    /**
    * 主线进度名称转换
    */
    
    progressName:string
    
    /**
    * 主线对应stageConfig表ID,摩天楼对应楼层数
    */
    
    stageId:integer
    
    /**
    * 系统id 1主线副本 2摩天楼 3武装塔 4机械塔 5变种塔 6僵尸塔 7地牢
    */
    
    systemId:integer
    
}

    
export class RMissionBuyReq{
    
    /**
    * 购买几次
    */
    
    buyCount:integer
    
    /**
    * 资源副本类型 配置表type字段
    */
    
    type:integer
    
}

    
export class RMissionCycleReq{
    
    /**
    * 是否付费
    */
    
    pay:boolean
    
    /**
    * type
    */
    
    types:array<integer>
    
}

    
export class RMissonInfoBO{
    
    /**
    * 配置表resourcegameconfig-stageId
    */
    
    info:array<RMissonItemBO>
    
    /**
    * 重置时间
    */
    
    resetTs:integer
    
}

    
export class RMissonItemBO{
    
    /**
    * 当前挑战购买次数
    */
    
    buyCount:integer
    
    /**
    * 本次购买价格
    */
    
    buyPrice:integer
    
    /**
    * 当前已挑战次数
    */
    
    nowCount:integer
    
    /**
    * 累计回收次数
    */
    
    recovCount:integer
    
    /**
    * 配置表resourcegameconfig-stageId
    */
    
    stageId:integer
    
    /**
    * 副本类型
    */
    
    type:integer
    
}

    
export class RankListReq{
    
    /**
    * 自定义排行榜 type=16时，{guild}{下划线}{endTs},type=17时，{较大的公会Id}{下划线}{较小的公会Id}{下划线}{entTs},type=18时，{分组ID}{下划线}{GuildHegeBO.signStartTs},type=19时，{分组Id}{下划线}{GuildHegeBO.signStartTs}
    */
    
    customKey:string
    
    /**
    *  start 和 stop 都以 0 为底，也就是说，以 0 表示有序集第一个成员，以 1 表示有序集第二个成员，以此类推。 你也可以使用负数下标，以 -1 表示最后一个成员， -2 表示倒数第二个成员，以此类推。
    */
    
    end:integer
    
    /**
    * 排行榜类型 9、本服战力排行榜 10、跨服战力排行榜 16公会副本排行【内部】 17公会副本排行【加敌对】 18公会争霸排行榜【个人】 19公会争霸排行榜【公会】
    */
    
    rankType:integer
    
    /**
    * start 和 stop 都以 0 为底，也就是说，以 0 表示有序集第一个成员，以 1 表示有序集第二个成员，以此类推。 你也可以使用负数下标，以 -1 表示最后一个成员， -2 表示倒数第二个成员，以此类推。
    */
    
    start:integer
    
}

    
export class RankListVO{
    
    /**
    * 我的排行信息
    */
    
    myRank:RankVO
    
    /**
    * 上期前三
    */
    
    preTop:array<RankVO>
    
    /**
    * 排行信息
    */
    
    rankDetail:array<RankVO>
    
}

    
export class RankReq{
    
    /**
    * 排行榜类型 1、阵营1 2、阵营2 3、阵营3 4、阵营4 5、关卡进度榜 6、王座之塔榜 7、普通竞技场 8、高阶竞技场
    */
    
    rankType:integer
    
    /**
    * 奖励 RankingScoreconfig 配置表ID 非必填
    */
    
    rewardId:integer
    
}

    
export class RankRewardInfoBO{
    
    /**
    * 已经领取的奖励 RankingScoreconfig 配置表ID
    */
    
    gotRewards:array<integer>
    
    /**
    * 已经开启的奖励 RankingScoreconfig 配置表ID
    */
    
    openRewards:array<integer>
    
}

    
export class RankUpHeroReq{
    
    /**
    * 被消耗的英雄IDs（合成时 不包括主英雄）
    */
    
    consumeIds:array<string>
    
    /**
    * 升阶/升星英雄 合成时，表示合成表HeroCompoundConfig Id的字符串形式
    */
    
    heroId:string
    
}

    
export class RankVO{
    
    /**
    * 高阶竞技场待收取高级角斗士币数量
    */
    
    advConins:integer
    
    /**
    * 高阶竞技场段位ID
    */
    
    advRankId:integer
    
    /**
    * 是否机器人
    */
    
    ai:boolean
    
    /**
    * 高阶竞技场待收取角斗士币数量/活动类型(周期活动排行用)//公会副本讨伐次数/参与公会争霸的人数
    */
    
    conins:integer
    
    /**
    * 已点赞的次数
    */
    
    dayScore:integer
    
    /**
    * 赛季过期时间(竞技场用)，代表区服（战力排行榜用）[-999999 表示全服]，代表活动结束时间（周期活动用）
    */
    
    limitTime:integer
    
    /**
    * 排名
    */
    
    no:integer
    
    /**
    * 出战战力(竞技场用)
    */
    
    power:integer
    
    /**
    * 排行榜类型 1阵营1 2阵营2 3阵营3 4阵营4 5关卡进度榜 6王座之塔榜 7普通竞技场 8高阶竞技场 9区服战力排行榜 10跨服战力排行榜 15周期活动排行 16公会副本排行【内部】 17公会副本排行【加敌对】 18公会争霸排行榜【内部】 19公会争霸排行榜【对抗组】
    */
    
    rankType:integer
    
    /**
    * 机器人ConfigId,仅为机器人时生效
    */
    
    robotConfId:integer
    
    /**
    * 角色信息
    */
    
    role:RoleVO
    
    /**
    * 角色ID
    */
    
    roleId:string
    
    /**
    * 积分
    */
    
    score:number
    
    /**
    * 上次更新时间
    */
    
    time:integer
    
}

    
export class RedPackInfoBO{
    
    /**
    * 附带数据
    */
    
    extra:object
    
    /**
    * 红包内容Id
    */
    
    goodsId:integer
    
    /**
    * 红包ID
    */
    
    packId:string
    
    /**
    * 
    */
    
    pcount:integer
    
    /**
    * 红包剩余金额
    */
    
    remainAmt:integer
    
    /**
    * 发送者Id/公会红包时，1表示钻石红包 2表示公会币红包
    */
    
    senderId:integer
    
    /**
    * 红包总金额
    */
    
    totalAmt:integer
    
    /**
    * 发出时间
    */
    
    ts:integer
    
    /**
    * 红包类型 0公会红包 1成员红包 2成就红包
    */
    
    type:integer
    
}

    
export class RedPackTaskInfoVO{
    
    /**
    * 任务不可重复时 进度/任务可重复时 剩余次数
    */
    
    progress:integer
    
    /**
    * 是否已经领取 任务不可重复时 有效
    */
    
    recv:boolean
    
    /**
    * 任务ID statuefreewalletconfig中的ID
    */
    
    taskId:integer
    
    /**
    * 任务类型ID tasktypeconfig中的tasktypeID
    */
    
    typeId:integer
    
}

    
export class RedPackVO{
    
    /**
    * 附带数据
    */
    
    extra:object
    
    /**
    * 红包内容Id
    */
    
    goodsId:integer
    
    /**
    * 红包ID
    */
    
    packId:string
    
    /**
    * 
    */
    
    pcount:integer
    
    /**
    * 领取列表
    */
    
    recvInfo:object
    
    /**
    * 红包剩余金额
    */
    
    remainAmt:integer
    
    /**
    * 发送者Id/公会红包时，1表示钻石红包 2表示公会币红包
    */
    
    senderId:string
    
    /**
    * 红包总金额
    */
    
    totalAmt:integer
    
    /**
    * 发出时间
    */
    
    ts:integer
    
    /**
    * 红包类型 0公会红包 1成员红包 2成就红包
    */
    
    type:integer
    
}

    
export class RedPointItem{
    
    /**
    * 
    */
    
    pointType:string
    
    /**
    * 
    */
    
    source:string
    
    /**
    * 
    */
    
    status:boolean
    
}

    
export class ResourceVO{
    
    /**
    * 神器
    */
    
    artifacts:array<ArtifactBO>
    
    /**
    * 
    */
    
    battleReport:BattleReportBO
    
    /**
    * 装备
    */
    
    equips:array<EquipBO>
    
    /**
    * 附带信息
    */
    
    extra:array<object>
    
    /**
    * 物品
    */
    
    goods:array<GoodVO>
    
    /**
    * 英雄
    */
    
    heros:array<HeroVO>
    
    /**
    * 单系统进度、地图点
    */
    
    proces:ProcessVO
    
    /**
    * 所有系统进度、地图点
    */
    
    process:array<ProcessVO>
    
    /**
    * 奖励（恭喜获得）
    */
    
    rewards:array<object>
    
    /**
    * 单系统排名信息
    */
    
    roleRank:RankVO
    
    /**
    * 所有排名信息
    */
    
    roleRanks:array<RankVO>
    
    /**
    * 角色
    */
    
    roleVO:RoleVO
    
    /**
    * 皮肤
    */
    
    skins:array<SkinBO>
    
    /**
    * 悬赏等级、进度
    */
    
    xsVO:XsVO
    
}

    
export class RewardBO{
    
    /**
    * 数量
    */
    
    amt:string
    
    /**
    * 
    */
    
    extra:object
    
    /**
    * 奖励类型 英雄对应hero, 装备对应equip, 神器对应artifacts ,物品对应goods ,皮肤对应skin
    */
    
    objId:string
    
    /**
    * 物品Id 英雄对应hero表里面的key, 装备对应equip表里的key.皮肤对应skin表里的Id
    */
    
    propId:integer
    
}

    
export class RoleDataBO{
    
    /**
    * 
    */
    
    artifactList:array<ArtifactDO>
    
    /**
    * 
    */
    
    equipList:array<EquipDO>
    
    /**
    * 
    */
    
    heroList:array<HeroDO>
    
    /**
    * 活动ID-唯一标识
    */
    
    roleId:string
    
}

    
export class RoleDefendVO{
    
    /**
    * 工会名称
    */
    
    guildName:string
    
    /**
    * 防守阵容简单数据
    */
    
    heros:array<HeroSimpleBO>
    
    /**
    * 昵称
    */
    
    nick:string
    
    /**
    * 
    */
    
    powerCount:string
    
    /**
    * 角色id
    */
    
    roleId:string
    
}

    
export class RoleRankVO{
    
    /**
    * 普通竞技场每日奖励结算时间
    */
    
    dailyTime:integer
    
    /**
    * 普通竞技场免费挑战剩余次数
    */
    
    freeTimes:integer
    
    /**
    * 角色所有排名和赛季信息
    */
    
    myRanks:array<RankVO>
    
    /**
    * 本日普通竞技场已刷新次数
    */
    
    normalFreshCount:integer
    
}

    
export class RoleSimpleVO{
    
    /**
    * 头像
    */
    
    avatar:string
    
    /**
    * 头像框
    */
    
    avatarFrame:string
    
    /**
    * 分服服务器ID
    */
    
    cdId:integer
    
    /**
    * 角色创建时间戳
    */
    
    createTs:integer
    
    /**
    * 总经验
    */
    
    exp:integer
    
    /**
    * 0未知 1男 2女
    */
    
    gender:integer
    
    /**
    * 所在公会ID，<1为无公会
    */
    
    guildId:integer
    
    /**
    * 公会职位(对应factionconfig 3成员\2副会长\1会长)
    */
    
    guildJob:integer
    
    /**
    * 英雄格子数
    */
    
    heroCapacity:integer
    
    /**
    * 被赞数
    */
    
    likeCount:integer
    
    /**
    * 等级
    */
    
    lv:integer
    
    /**
    * 等级经验
    */
    
    lvExp:integer
    
    /**
    * 昵称
    */
    
    nick:string
    
    /**
    * 综合战力
    */
    
    power:integer
    
    /**
    * 角色ID
    */
    
    roleId:string
    
    /**
    * 短用户ID,显示、+好友使用
    */
    
    shortId:string
    
    /**
    * 个性签名
    */
    
    signature:string
    
    /**
    * 队伍战力
    */
    
    top5power:integer
    
    /**
    * 账号ID
    */
    
    userId:integer
    
}

    
export class RoleVO{
    
    /**
    * 应用ID
    */
    
    appId:integer
    
    /**
    * 头像
    */
    
    avatar:string
    
    /**
    * 头像框
    */
    
    avatarFrame:string
    
    /**
    * 分服服务器ID
    */
    
    cdId:integer
    
    /**
    * 创建时间戳
    */
    
    createTs:integer
    
    /**
    * 总经验
    */
    
    exp:integer
    
    /**
    * 共享花坛等级
    */
    
    flowerLv:integer
    
    /**
    * 共享花坛品阶
    */
    
    flowerRank:integer
    
    /**
    * 0未知 1男 2女
    */
    
    gender:integer
    
    /**
    * 所在公会ID，<1为无公会
    */
    
    guildId:integer
    
    /**
    * 公会职位(对应factionconfig 3成员\2副会长\1会长)
    */
    
    guildJob:integer
    
    /**
    * 所在公会名称
    */
    
    guildName:string
    
    /**
    * 公会红包已领取次数
    */
    
    guildPackRecvCount:integer
    
    /**
    * 公共加成模块信息
    */
    
    heroAddInfos:array<HeroModulBO>
    
    /**
    * 英雄格子数
    */
    
    heroCapacity:integer
    
    /**
    * 被赞数
    */
    
    likeCount:integer
    
    /**
    * 累计登录天数
    */
    
    loginDayCount:integer
    
    /**
    * 等级
    */
    
    lv:integer
    
    /**
    * 等级经验
    */
    
    lvExp:integer
    
    /**
    * 主力阵容
    */
    
    mainForce:array<HeroVO>
    
    /**
    * 勋章等级
    */
    
    medalLv:integer
    
    /**
    * 昵称
    */
    
    nick:string
    
    /**
    * 综合战力
    */
    
    power:integer
    
    /**
    * 关卡进度
    */
    
    progress:string
    
    /**
    * 改名次数
    */
    
    renameCount:integer
    
    /**
    * 角色ID
    */
    
    roleId:string
    
    /**
    * 短用户ID,显示、+好友使用
    */
    
    shortId:string
    
    /**
    * 个性签名
    */
    
    signature:string
    
    /**
    * 队伍战力
    */
    
    top5power:integer
    
    /**
    * 账号ID
    */
    
    userId:integer
    
    /**
    * vip总经验
    */
    
    vipExp:integer
    
}

    
export class SearchReq{
    
    /**
    * 关键词
    */
    
    keyword:string
    
    /**
    * 搜索数量
    */
    
    limitCount:integer
    
}

    
export class SevenDaySignInfoVO{
    
    /**
    * 天数
    */
    
    day:integer
    
    /**
    * 是否已经领取
    */
    
    recv:boolean
    
}

    
export class ShopConfig{
    
    /**
    * 
    */
    
    buylimit:boolean
    
    /**
    * 
    */
    
    costType:integer
    
    /**
    * 
    */
    
    discount:Number
    
    /**
    * 
    */
    
    id:integer
    
    /**
    * 
    */
    
    idAD:Number
    
    /**
    * 
    */
    
    order:Number
    
    /**
    * 
    */
    
    price:Number
    
    /**
    * 
    */
    
    rewards:Number
    
    /**
    * 
    */
    
    type:Number
    
}

    
export class ShopItem{
    
    /**
    * 商品数量（一次购买就能获得的物品的数量））
    */
    
    goodsCount:integer
    
    /**
    * 商品ID，可能是equip配置ID、也可能是物品配置ID
    */
    
    goodsId:integer
    
    /**
    * 位置序号（1开始）
    */
    
    order:integer
    
    /**
    * 价格系数
    */
    
    pricePara:number
    
    /**
    * 剩余购买次数
    */
    
    remainCount:integer
    
    /**
    * 商品配置
    */
    
    shopConfig:ShopConfig
    
}

    
export class ShopVO{
    
    /**
    * 商品列表
    */
    
    goodsInfo:array<ShopItem>
    
    /**
    * 手动刷新所需要的消耗
    */
    
    refreshCost:integer
    
    /**
    * 下次刷新时间戳（ms）
    */
    
    refreshTs:integer
    
    /**
    * 商店类型
    */
    
    shopType:string
    
}

    
export class SkinBO{
    
    /**
    * skin配置表中对应的id
    */
    
    skinCofId:integer
    
    /**
    * 皮肤唯一ID
    */
    
    skinId:string
    
}

    
export class StatueConfig{
    
    /**
    * 
    */
    
    dialreward:Number
    
    /**
    * 
    */
    
    dialtime:Number
    
    /**
    * 
    */
    
    diamond:Number
    
    /**
    * 
    */
    
    factioncoin:Number
    
    /**
    * 
    */
    
    gettime:Number
    
    /**
    * 
    */
    
    helpreward:object
    
    /**
    * 
    */
    
    helptime:Number
    
    /**
    * 
    */
    
    id:integer
    
    /**
    * 
    */
    
    levelreward:object
    
    /**
    * 
    */
    
    limit:array<Number>
    
    /**
    * 
    */
    
    receivetime:Number
    
    /**
    * 
    */
    
    statuelevel:Number
    
    /**
    * 
    */
    
    statuename:string
    
    /**
    * 
    */
    
    statuerank:Number
    
}

    
export class StatueRankConfig{
    
    /**
    * 
    */
    
    attack:Number
    
    /**
    * 
    */
    
    attacknumber:Number
    
    /**
    * 
    */
    
    defend:Number
    
    /**
    * 
    */
    
    defendnumber:Number
    
    /**
    * 
    */
    
    hp:Number
    
    /**
    * 
    */
    
    hpnumber:Number
    
    /**
    * 
    */
    
    id:integer
    
    /**
    * 
    */
    
    levelupspend:object
    
    /**
    * 
    */
    
    statuelevel:Number
    
    /**
    * 
    */
    
    statuetype:Number
    
    /**
    * 
    */
    
    videoadd:Number
    
}

    
export class StoreBuyCountBO{
    
    /**
    * 累计购买次数
    */
    
    buyCount:integer
    
    /**
    * storeConfig Id
    */
    
    configId:integer
    
}

    
export class StorePromotionReq{
    
    /**
    * 促销活动ID
    */
    
    actId:string
    
    /**
    * 购买标志
    */
    
    buyTag:string
    
}

    
export class StoreVO{
    
    /**
    * 
    */
    
    active:KaoShangBO
    
    /**
    * 
    */
    
    buyInfo:array<StoreBuyCountBO>
    
    /**
    * 
    */
    
    costFirstPay:object
    
    /**
    * 
    */
    
    cycle:array<CycleGiftBO>
    
    /**
    * 
    */
    
    firstPay:GrowUpBO
    
    /**
    * 
    */
    
    free:array<FreeGiftBO>
    
    /**
    * 成长基金
    */
    
    grow:GrowUpBO
    
    /**
    * 
    */
    
    lifeCard:MonthCardBO
    
    /**
    * 主线战令
    */
    
    mainOrder:WarOrderBO
    
    /**
    * 
    */
    
    normalCard:MonthCardBO
    
    /**
    * 
    */
    
    sevenFund:GrowUpBO
    
    /**
    * 
    */
    
    superCard:MonthCardBO
    
    /**
    * 摩天楼战令
    */
    
    towerOrder:WarOrderBO
    
    /**
    * 
    */
    
    weekCard:MonthCardBO
    
    /**
    * 
    */
    
    wisdom:KaoShangBO
    
}

    
export class StrategicBO{
    
    /**
    * 配置ID-等级
    */
    
    cfgLvMap:object
    
}

    
export class StrengArtifactVO{
    
    /**
    * 被强化的神器
    */
    
    artifactInfo:ArtifactBO
    
    /**
    * 模块加成信息
    */
    
    heroAddInfos:HeroModulBO
    
}

    
export class StrengEquipVO{
    
    /**
    * 被强化的装备
    */
    
    equipInfo:EquipBO
    
    /**
    * 模块加成信息【如果准备穿在英雄身上，此处返回该英雄新的加成状态】
    */
    
    heroAddInfos:HeroModulBO
    
    /**
    * 返还资源
    */
    
    resourceVO:ResourceVO
    
}

    
export class SupplyGoReq{
    
    /**
    * 搜寻条件物品个数 <1表示没有要求
    */
    
    needAmt:integer
    
    /**
    * 搜寻条件物品ID needAmt<1时，该配置无效
    */
    
    needGoodsId:integer
    
    /**
    * 资源点Id supplyConfig.id
    */
    
    supplyId:integer
    
    /**
    * 搜寻次数
    */
    
    supplyTimes:integer
    
}

    
export class SupplyGoResVO{
    
    /**
    * 恭喜获得
    */
    
    resource:ResourceVO
    
    /**
    * 每次搜寻的结果map k-v:第几次（1开始）-结果列表
    */
    
    rewardMap:object
    
    /**
    * 新的体力信息
    */
    
    supplyInfo:SupplyInfoBO
    
}

    
export class SupplyInfoBO{
    
    /**
    * 今日搜寻高级点的次数
    */
    
    findAdvCount:integer
    
    /**
    * 今日已体力购买次数
    */
    
    nowBuyCount:integer
    
    /**
    * 当前体力值
    */
    
    nowCount:integer
    
    /**
    * 下次刷新次数时间
    */
    
    refreshCountTs:integer
    
    /**
    * 下次恢复体力时间(-1表示体力满，无法回复)
    */
    
    refreshTs:integer
    
    /**
    * 已购买重置次数
    */
    
    resetBuyCount:integer
    
    /**
    * 
    */
    
    resetCanUse:integer
    
    /**
    * 已重置次数
    */
    
    resetCount:integer
    
}

    
export class TalentAddBO{
    
    /**
    * 
    */
    
    heroConfId:integer
    
    /**
    * 属性加成
    */
    
    heroModulBO:HeroModulBO
    
    /**
    * 附加技能 map: skillId-lv
    */
    
    skillAdd:object
    
}

    
export class TalentAddSkillItemBO{
    
    /**
    * 技能等级
    */
    
    lv:integer
    
    /**
    * 技能ID
    */
    
    skillId:integer
    
}

    
export class TalentAddVO{
    
    /**
    * 英雄配置ID
    */
    
    heroConfId:integer
    
    /**
    * 属性加成
    */
    
    heroModulBO:HeroModulBO
    
    /**
    * 附加技能 list: skillId-lv
    */
    
    skillAdd:array<TalentAddSkillItemBO>
    
}

    
export class TalentGetReq{
    
    /**
    * 需要查询的HeroConfig Ids
    */
    
    heroConfIds:array<integer>
    
    /**
    * 目标roleId
    */
    
    roleId:string
    
}

    
export class TalentInfoVO{
    
    /**
    * 天赋开启情况 key:value-geniusConfig id:点亮时消耗的天赋点 当<1时，表示未激活
    */
    
    details:object
    
    /**
    * 天赋加成
    */
    
    heroAdd:HeroModulBO
    
    /**
    * 剩余中级天赋点
    */
    
    remainTMPoint:integer
    
    /**
    * 剩余普通天赋点
    */
    
    remainTPoint:integer
    
    /**
    * 剩余高级天赋点
    */
    
    remainTSPoint:integer
    
    /**
    * 附加技能 list: skillId-lv
    */
    
    skillAdd:array<TalentAddSkillItemBO>
    
}

    
export class TalentReq{
    
    /**
    * 
    */
    
    gconfId:integer
    
    /**
    * 英雄configId
    */
    
    heroConfId:integer
    
}

    
export class TalentSimpleInfoVO{
    
    /**
    * 天赋加成
    */
    
    heroAdd:HeroModulBO
    
    /**
    * 英雄配置Id
    */
    
    heroConfId:integer
    
    /**
    * 加成英雄Id(可能为空)
    */
    
    heroId:string
    
    /**
    * 附加技能 list: skillId-lv
    */
    
    skillAdd:array<TalentAddSkillItemBO>
    
}

    
export class TaskActiveInfoVO{
    
    /**
    * 是否已经领取
    */
    
    recv:boolean
    
    /**
    * 活跃度 activeRewardConfig中的vitality
    */
    
    vitaility:integer
    
}

    
export class TaskInfoVO{
    
    /**
    * 进度 在线奖励/新手光环 时，无效
    */
    
    progress:integer
    
    /**
    * 是否已经领取
    */
    
    recv:boolean
    
    /**
    * 任务ID dailytaskconfig/sevenDaysConfig/onlinegiftconfig/sevendayschargeconfig/arenachallangetimeconfig/arenascorerewardconfig中的ID/arenarankconfig中的rankId
    */
    
    taskId:integer
    
}

    
export class TaskProgressSetReq{
    
    /**
    * 新的进度/引导任务中为 需要新增的进度值
    */
    
    progress:integer
    
    /**
    * 日常ID dailytaskconfig表中ID/引导任务中 为taskTypeConfig中的tasktypeID
    */
    
    taskId:integer
    
}

    
export class TaskSevenNewVO{
    
    /**
    * 每日的充值金额
    */
    
    amtProgress:object
    
    /**
    * 领取详情
    */
    
    detail:array<TaskInfoVO>
    
    /**
    * 进度 当前是第几天
    */
    
    nowDay:integer
    
    /**
    * 开始时间戳
    */
    
    startTs:integer
    
}

    
export class TaskTotalVO{
    
    /**
    * 活跃进度
    */
    
    activeInfos:array<TaskActiveInfoVO>
    
    /**
    * 当前活跃值
    */
    
    activeSocre:integer
    
    /**
    * 刷新时间(ms)
    */
    
    refreshTs:integer
    
}

    
export class TaskVO{
    
    /**
    * 日常
    */
    
    daily:TaskTotalVO
    
    /**
    * 任务进度
    */
    
    taskInfos:array<TaskInfoVO>
    
    /**
    * 周常
    */
    
    weekly:TaskTotalVO
    
}

    
export class TowerBattleDataReq{
    
    /**
    * 楼层数
    */
    
    floor:integer
    
    /**
    * 角色id
    */
    
    roleId:string
    
    /**
    * 摩天楼类型 3武装塔 4机械塔 5变种塔 6僵尸塔 其它:普通摩天楼
    */
    
    type:integer
    
}

    
export class TowerBattleFindReq{
    
    /**
    * 楼层数
    */
    
    floor:integer
    
    /**
    * 摩天楼类型 3武装塔 4机械塔 5变种塔 6僵尸塔 其它:普通摩天楼
    */
    
    type:integer
    
}

    
export class TowerBattleReq{
    
    /**
    * 战斗数据
    */
    
    battleData:object
    
    /**
    * 楼层数
    */
    
    floor:integer
    
    /**
    * 摩天楼类型 3武装塔 4机械塔 5变种塔 6僵尸塔 其它:普通摩天楼
    */
    
    type:integer
    
}

    
export class TreaBoxBO{
    
    /**
    * 已抽取Ids
    */
    
    confIds:array<integer>
    
    /**
    * 今日剩余抽取次数
    */
    
    count:integer
    
    /**
    * 今日付费金额
    */
    
    dayPay:number
    
    /**
    * 次数重置时间戳
    */
    
    finalRefreshTs:integer
    
}

    
export class TurnInfoVO{
    
    /**
    * 转盘限时活动结束时间 -1表示没有活动
    */
    
    actEndTs:integer
    
    /**
    * 高级转盘内容 位置号-配置内容
    */
    
    advContent:object
    
    /**
    * 高级转盘今日已刷新次数
    */
    
    advFreshCount:integer
    
    /**
    * 高级转盘刷新时间
    */
    
    advFreshTs:integer
    
    /**
    * 高级转盘保底计数
    */
    
    advMustCount:integer
    
    /**
    * 普通转盘内容 位置号-配置内容
    */
    
    normalContent:object
    
    /**
    * 普通转盘剩余免费次数
    */
    
    normalFreeCount:integer
    
    /**
    * 普通转盘今日已刷新次数
    */
    
    normalFreshCount:integer
    
    /**
    * 普通转盘刷新时间
    */
    
    normalFreshTs:integer
    
    /**
    * 普通转盘保底计数
    */
    
    normalMustCount:integer
    
}

    
export class TurnResVO{
    
    /**
    * 转盘限时活动结束时间 -1表示没有活动
    */
    
    actEndTs:integer
    
    /**
    * 转盘内容 位置号-配置内容
    */
    
    content:object
    
    /**
    * 转盘今日已刷新次数
    */
    
    freshCount:integer
    
    /**
    * 转盘刷新时间
    */
    
    freshTs:integer
    
    /**
    * 转盘保底计数
    */
    
    mustCount:integer
    
    /**
    * 转盘奖励
    */
    
    resourceVO:ResourceVO
    
}

    
export class TurnTableGoReq{
    
    /**
    * 是否使用视频抽
    */
    
    useVideo:boolean
    
}

    
export class TurnTableReq{
    
    /**
    * 抽奖次数
    */
    
    turnTimes:integer
    
    /**
    * 转盘类型 1普通 2高级
    */
    
    turnType:integer
    
    /**
    * 是否使用视频抽（当为true时，抽奖次数为1 且强制使用普通转盘）
    */
    
    useVideo:boolean
    
}

    
export class UnEquipReq{
    
    /**
    * 英雄ID
    */
    
    heroId:string
    
    /**
    * 装备部位 1武器 2盔甲 3头盔 4鞋子
    */
    
    places:array<integer>
    
}

    
export class UpdateFlowerReq{
    
    /**
    * 需要更新的英雄ID
    */
    
    heroId:string
    
    /**
    * <1表示取消共享花坛状态，>0表示放到指定花坛位置
    */
    
    position:integer
    
}

    
export class UpdateLockReq{
    
    /**
    * 需要更新的英雄ID
    */
    
    heroId:string
    
    /**
    * 新的状态：false取消锁定 true锁定
    */
    
    newStatus:boolean
    
}

    
export class WarOrderBO{
    
    /**
    * 刷新时间
    */
    
    freshTs:integer
    
    /**
    * 当前阶段
    */
    
    moment:integer
    
    /**
    * 当前进度
    */
    
    nowScore:integer
    
    /**
    * 已经购买的战令阶段
    */
    
    payMoment:array<integer>
    
    /**
    * 领取详情
    */
    
    recvs:array<KaoShangItem>
    
    /**
    * 1主线战令 2摩天楼战令 
    */
    
    type:integer
    
}

    
export class WearArtifactReq{
    
    /**
    * 神器ID
    */
    
    artifactId:string
    
    /**
    * 英雄ID
    */
    
    heroId:string
    
}

    
export class WearEquipReq{
    
    /**
    * 装备IDs
    */
    
    equipIds:array<string>
    
    /**
    * 英雄ID
    */
    
    heroId:string
    
}

    
export class WearSkinReq{
    
    /**
    * 英雄ID
    */
    
    heroId:string
    
    /**
    * 皮肤confId
    */
    
    skinId:integer
    
}

    
export class Wheelprizepool{
    
    /**
    * 
    */
    
    drawWeight:Number
    
    /**
    * 
    */
    
    id:integer
    
    /**
    * 
    */
    
    item:object
    
    /**
    * 
    */
    
    level:Number
    
    /**
    * 
    */
    
    order:Number
    
    /**
    * 
    */
    
    type:Number
    
    /**
    * 
    */
    
    wheelWeight:Number
    
}

    
export class WisdomBuyReq{
    
    /**
    * 位置
    */
    
    order:integer
    
    /**
    * 商店ID
    */
    
    shopId:string
    
}

    
export class WisdomGuardRewardReq{
    
    /**
    * 守卫类型 对应eventConfig中的eventId:5\6\7
    */
    
    eventId:integer
    
    /**
    * 守卫战力
    */
    
    guardPower:integer
    
    /**
    * 层数1开始
    */
    
    layerNo:integer
    
    /**
    * 位置（第一行为1，如此累计）
    */
    
    nodeNo:integer
    
    /**
    * 重置时最新通关关卡获胜时金币奖励
    */
    
    passRewardCount:integer
    
    /**
    * 玩家最高品阶5英雄品阶总合
    */
    
    top5Rank:integer
    
}

    
export class WisdomMapBO{
    
    /**
    * 层数
    */
    
    layerNo:integer
    
    /**
    * 地图数据
    */
    
    mapData:array<array<integer>>
    
    /**
    * 通关关卡获胜时的金币奖励
    */
    
    passRewardCount:integer
    
    /**
    * 重置时间戳
    */
    
    resetTs:integer
    
    /**
    * 层宝箱奖励数据
    */
    
    rewards:array<RewardBO>
    
    /**
    * 商品列表（当地图中有商店出现时才有数据）
    */
    
    shopItems:array<WisdomShopItem>
    
}

    
export class WisdomNodeUpdateReq{
    
    /**
    * 新的内容
    */
    
    newData:object
    
    /**
    * 节点索引 0开始
    */
    
    nodeIndex:integer
    
}

    
export class WisdomShopItem{
    
    /**
    * 购买价格（折扣前的价格）
    */
    
    amt:integer
    
    /**
    * 货币类型ID
    */
    
    costType:integer
    
    /**
    * 折扣率 0.6表示6折
    */
    
    discount:number
    
    /**
    * 是否可购买
    */
    
    enable:boolean
    
    /**
    * 特殊事件ID,当此处>0表示为特殊事件，goodsId无效
    */
    
    eventId:integer
    
    /**
    * 商品数量（一次购买就能获得的物品的数量））
    */
    
    goodsCount:integer
    
    /**
    * 商品ID，可能是equip配置ID、也可能是物品配置ID
    */
    
    goodsId:integer
    
    /**
    * 位置序号（1开始）
    */
    
    order:integer
    
    /**
    * 已购买 false表示还可以购买，true表示售罄
    */
    
    sellOut:boolean
    
    /**
    * 商店唯一编号
    */
    
    shopId:string
    
}

    
export class WonderExtraReq{
    
    /**
    * 键值对
    */
    
    pairs:array<KeyValueReq>
    
    /**
    * 配置id，地牢时填英雄configId
    */
    
    stageId:integer
    
}

    
export class WonderInfoBO{
    
    /**
    * 附带数据(用于客户端存储额外数据)
    */
    
    extra:object
    
    /**
    * 持久化附带数据（不清除）
    */
    
    extraSave:object
    
    /**
    * 已经领取的奖励ID
    */
    
    rewardRecvedIds:array<string>
    
    /**
    * 进度积分
    */
    
    score:integer
    
}

    
export class WonderRewardReq{
    
    /**
    * rewardId.组成{位置ID}-{spaceboxConfig-boxid}
    */
    
    rewardId:string
    
    /**
    * spacetimeconfig-id
    */
    
    stageId:integer
    
}

    
export class WonderScoreReq{
    
    /**
    * 新的积分进度
    */
    
    score:integer
    
    /**
    * spacetimeconfig-id
    */
    
    stageId:integer
    
}

    
export class XsConfigBO{
    
    /**
    * 任务结束时间
    */
    
    endTime:integer
    
    /**
    * 任务过期时间
    */
    
    expireTime:integer
    
    /**
    * 阵营要求
    */
    
    factions:array<integer>
    
    /**
    * 任务状态 0未开启 1已开启
    */
    
    state:integer
    
    /**
    * 任务id 取xsConfig表Id
    */
    
    xsConfigId:integer
    
    /**
    *  悬赏任务唯一id
    */
    
    xsId:string
    
    /**
    * 任务场景
    */
    
    xsType:integer
    
}

    
export class XsReq{
    
    /**
    * 派遣英雄唯一id
    */
    
    heroIds:array<string>
    
    /**
    * 悬赏任务唯一Id
    */
    
    xsId:string
    
}

    
export class XsVO{
    
    /**
    * 升级需求进度
    */
    
    condition:integer
    
    /**
    * 
    */
    
    lvUp:boolean
    
    /**
    * 下次重置任务时间
    */
    
    nextTime:integer
    
    /**
    * 任务列表
    */
    
    xsConfigBOS:array<XsConfigBO>
    
    /**
    * 悬赏栏等级
    */
    
    xsLv:integer
    
}



export default class GameProxy{
    /*
    static get gameClient(): slib.HttpGameClient {
        return GSSDK.ServerProxy.gameClient;
    } */   
    static readonly gameClient:slib.HttpGameClient=new slib.HttpGameClient();   


    
    /**
     * 提交夺宝奇兵伤害
     * data
     */
    static apiActivityatkTreaRaider(
        
        
        data:ActBossHitReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/atkTreaRaider',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 提交世界BOSS伤害
     * data
     */
    static apiActivityatkWorldBoss(
        
        
        data:ActBossHitReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/atkWorldBoss',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买促销商店物品
     * 
     */
    static apiActivitybugFromPromotion(
        
        
        data:StorePromotionReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/bugFromPromotion',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 进行兑换活动的兑换
     * 
     */
    static apiActivitybuyExchangeItem(
        
        
        data:ActivityExchangeBuyReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/buyExchangeItem',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 从奇兵商店兑换奖励
     * data填buyTag
     */
    static apiActivitybuyRaiderStore(
        
        
        data:ActivityCumRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/buyRaiderStore',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买夺宝奇兵门票
     * data填活动ID
     */
    static apiActivitybuyTreaRaider(
        
        
        data:ActTreaRaiderBuy,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/buyTreaRaider',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取活动附带七日充值活动奖励
     * 
     */
    static apiActivitygetActSevenReward(
        
        
        data:ActivitySevenRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/getActSevenReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取棋盘任务奖励
     * 
     */
    static apiActivitygetCTaskReward(
        
        
        data:ActivityCumRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/getCTaskReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取角色活动数据
     * -1:全部 1:七日累充 2:超值促销 3:累计充值 4:累计消费 5:世界BOSS 6:夺宝奇兵 7:奇兵商店 8:棋盘活动 9:大乱斗 10:日消返利 11:签到有礼 12:探趣寻宝 13:任务-抽卡活动 14:任务-寻宝庆典 15:任务-英雄养成 16:任务-狂热竞技 17:任务-智慧风暴 18:任务-悬赏季 19:任务-联盟集结 20:兑换-英雄降临 21:兑换-熔炉馈赠 22:兑换-神秘宝库 23:任务-联盟抽卡 24:世界树的馈赠
     */
    static apiActivitygetRoleActivities(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ActivityRoleBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/getRoleActivities',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置任务系列活动进度(累加)
     * 
     */
    static apiActivityincTaskActProgress(
        
        
        data:ActivityProgressChangeReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ActivityProgressBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/incTaskActProgress',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 将指定配置的兑换券加入储蓄罐,储蓄罐版
     * pionner2Config-id
     */
    static apiActivitypioneerEnterV2(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:PioneerRecvBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/pioneerEnterV2',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取先锋奖励详情,储蓄罐版
     * 
     */
    static apiActivitypioneerInfoV2(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:PioneerRecvBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/pioneerInfoV2',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取棋盘视频免费骰子
     * 
     */
    static apiActivityrecvCVideoDice(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/recvCVideoDice',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取棋盘活动星星进度奖励
     * 
     */
    static apiActivityrecvChessBoardCircle(
        
        
        data:ActivityCumRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/recvChessBoardCircle',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取累充/累消/日消返利 活动奖励
     * 
     */
    static apiActivityrecvCumChargeConsum(
        
        
        data:ActivityCumRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/recvCumChargeConsum',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取世界树的馈赠奖励
     * data填tag，服务端根据用户付费情况自动领取奖励
     */
    static apiActivityrecvMonthKsReward(
        
        
        data:ActivityCumRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/recvMonthKsReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取先锋奖励，储蓄罐版
     * data随便填
     */
    static apiActivityrecvPioneerV2(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/recvPioneerV2',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取七日累充活动奖励
     * 
     */
    static apiActivityrecvSevenDayCum(
        
        
        data:ActivitySevenRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/recvSevenDayCum',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取签到有礼活动奖励
     * 
     */
    static apiActivityrecvSignGift(
        
        
        data:ActivitySevenRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/recvSignGift',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取任务系列活动奖励
     * 
     */
    static apiActivityrecvTaskActReward(
        
        
        data:ActivityCumRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/recvTaskActReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取世界BOSS活动累计伤害奖励
     * 
     */
    static apiActivityrecvWordBoss(
        
        
        data:ActivityCumRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/recvWordBoss',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 提交棋盘推进
     * 当只有消耗没有奖励时 resourceBO=null
     */
    static apiActivitysetChessPlayerStep(
        
        
        data:ActChessStepReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ChessTenItemVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/setChessPlayerStep',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置任务系列活动进度(覆盖)
     * 
     */
    static apiActivitysetTaskActProgress(
        
        
        data:ActivityProgressChangeReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ActivityProgressBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/setTaskActProgress',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 更换终极奖励
     * 返回新的奖励配置ID
     */
    static apiActivitytreaChangeFReward(
        
        
        data:ActTreaChangeRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:int
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/treaChangeFReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 进入新的一层
     * data传actId
     */
    static apiActivitytreaNewLayer(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ActivityTreaInstBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/treaNewLayer',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 翻开一格
     * 
     */
    static apiActivitytreaOpenBlock(
        
        
        data:ActTreaOpenReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/treaOpenBlock',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取探趣寻宝层数奖励
     * 
     */
    static apiActivitytreaRecvLayerReward(
        
        
        data:ActivityCumRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Activity/treaRecvLayerReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取指定类型的英雄站位
     * Normal_Battle(普通战役站位),
Normal_Arena_Battle(普通竞技场),
Nomal_Tower_Battle(摩天楼),
Nomal_Maze_Battle(迷宫),
Nomal_Hunt_Battle(公会狩猎),
Activity_WordBoss(世界BOSS),
Activity_TreaRaiders(夺宝奇兵),
Wz_Tower_Battle(武装塔),
Jx_Tower_Battle(机械塔),
Bz_Tower_Battle(变种塔),
Js_Tower_Battle(僵尸塔),
Normal_Wonder_Battle(奇妙时空),
Adv_Arena_Battle(高阶竞技场),
Resource_Mission(资源副本),
Clone_Battle(克隆大作战),
Guild_Hege(公会争霸),
Guild_Journey(公会副本)
     */
    static apiBattlegetBattleStance(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:BattleStanceBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Battle/getBattleStance',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置指定类型的英雄站位
     * 重复站位只取第一个，没有设置的站位保留原来数据，返回新的站位数据
     */
    static apiBattlesetBattleStance(
        
        
        data:BattleStanceReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:BattleStanceBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Battle/setBattleStance',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 拉黑
     * data填要添加的roleId返回新的黑名单
     */
    static apiFriendaddToBlackList(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FriendInfoItem[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/addToBlackList',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 申请成为好友
     * data填写目标RoleId 返回data无具体意义
     */
    static apiFriendapplyForFriend(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/applyForFriend',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 批量同意申请
     * data填relationIds 返回新的好友列表
     */
    static apiFriendbatchAcceptApply(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FriendListVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/batchAcceptApply',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 批量忽略申请
     * data填relationIds 返回data无具体意义
     */
    static apiFriendbatchRefuseApply(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/batchRefuseApply',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 查找角色关系
     * 查找请求者和指定角色的关系
     */
    static apiFriendfindrelation(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FriendRelationVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/findrelation',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取好友管理数据（黑名单、好友申请）
     * 
     */
    static apiFriendgetFriendManage(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FriendManageVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/getFriendManage',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取好友数据
     * 
     */
    static apiFriendgetFriends(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FriendListVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/getFriends',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取友情点
     * data填要领取的的roleId 返回新的已领取次数和新的友情点道具个数
     */
    static apiFriendrecvFPoint(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FPointRecvVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/recvFPoint',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取友情点（批量）
     * data填要领取的的roleIds 返回新的已领取次数和新的友情点道具个数
     */
    static apiFriendrecvFPointBatch(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FPointRecvVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/recvFPointBatch',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 移除黑名单
     * data填要移除的roleId 返回新的黑名单
     */
    static apiFriendremoveBlackList(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FriendInfoItem[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/removeBlackList',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 移除好友
     * data填写目标RoleId 返回新的好友列表
     */
    static apiFriendremoveFriend(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FriendListVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/removeFriend',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 搜索角色(使用短ID)
     * 根据关键字搜索，当关键字是数字字符串时，会额外进行ID搜索
     */
    static apiFriendsearch(
        
        
        data:SearchReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FriendInfoItem[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/search',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 赠送友情点
     * data填要赠送的的roleId 返回新的已赠送次数
     */
    static apiFriendsendFPoint(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:int
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/sendFPoint',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 赠送友情点（批量）
     * data填要赠送的的roleIds 返回新的已赠送次数
     */
    static apiFriendsendFPointBatch(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:int
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Friend/sendFPointBatch',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 抽卡并返回结果
     * data 抽卡请求类
     */
    static apiGachadoGacha(
        
        
        data:GachaReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GachaVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Gacha/doGacha',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取抽卡次数
     * data传空字符串或空表示获取历史抽奖次数
     */
    static apiGachagetGacha(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GachaVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Gacha/getGacha',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取抽卡100次奖励
     * data传空字符串或空表示获取自己
     */
    static apiGachagetGacha100Reward(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Gacha/getGacha100Reward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置、更新心愿英雄列表
     * data为数组，填写hero配置表中的id，空数组或NULL表示清除所有心愿英雄
     */
    static apiGachasetWishHeros(
        
        
        data:Array<int>,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GachaVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Gacha/setWishHeros',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买英雄格子
     * data随便填，返回新的英雄格子数
     */
    static apiRolebuyHeroCapacity(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroCapacityVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/buyHeroCapacity',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取所有红点状态
     * 
     */
    static apiRolecheckRP(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RedPointItem[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/checkRP',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 关闭红点
     * data填红点枚举
     */
    static apiRolecloseRP(
        
        
        data:Array<string>,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:object
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/closeRP',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取升级奖励
     * 随便填
     */
    static apiRolegetLvUpReward(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/getLvUpReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取角色数据
     * data传空字符串或空表示获取自己
     */
    static apiRolegetRole(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RoleVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/getRole',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取历史最高5英雄战力
     * 随便填
     */
    static apiRolegetRoleTop5Power(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/getRoleTop5Power',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取战略树详情
     * data随便填
     */
    static apiRolegetStrategicInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:StrategicBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/getStrategicInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 给某个玩家点赞
     * 
     */
    static apiRolelikeRole(
        
        
        data:LikeSOReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/likeRole',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 升级战略树
     * data填策略表ID
     */
    static apiRolelvUpStrategic(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroModulBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/lvUpStrategic',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 升级勋章等级
     * 随便填
     */
    static apiRolemedalLvUp(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/medalLvUp',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 重置某一页战略树
     * data填策略类型
     */
    static apiRoleresetStrategic(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/resetStrategic',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置头像
     * data填新头像
     */
    static apiRolesetAvatar(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RoleVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/setAvatar',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置头像框
     * data填新头像框
     */
    static apiRolesetAvatarFrame(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RoleVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/setAvatarFrame',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置性别
     * data填新性别枚举
     */
    static apiRolesetGender(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RoleVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/setGender',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置主力阵容
     * data填写HeroId数组，服务端会去重，超过五个只取前五个，返回设置完成后的主力阵容HeroIds
     */
    static apiRolesetMainForce(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/setMainForce',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 改名
     * data填新名字
     */
    static apiRolesetNick(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RoleVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/setNick',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置个性签名
     * data填个性签名
     */
    static apiRolesetSignature(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RoleVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Role/setSignature',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买商店物品
     * 
     */
    static apiShopbugFromStore(
        
        
        data:BuyFromStoreReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Shop/bugFromStore',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 钻石刷新商店内容
     * data传 商店类型
     */
    static apiShopdiamondRefresh(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ShopVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Shop/diamondRefresh',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取商店商品详情
     * data传 商店类型
     */
    static apiShopgetShopDetail(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ShopVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Shop/getShopDetail',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 使用兑换码
     * data填写兑换码
     */
    static apiShopuseExchangeCode(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Shop/useExchangeCode',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取商店商品详情
     * data随便传
     */
    static apiStoregetStore(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:StoreVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Store/getStore',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取VIP奖励领取情况
     * data随便填
     */
    static apiStoregetVipRerwardStatus(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:{[key:number]:boolean}
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Store/getVipRerwardStatus',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取首充礼包奖励
     * data传首充金额，任意金额传0
     */
    static apiStorerecvFirstReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Store/recvFirstReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取免费周期性礼包
     * data传storeConfig-Id
     */
    static apiStorerecvFreeCycleReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Store/recvFreeCycleReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取非Store类礼包
     * data传defaultConfig-Id
     */
    static apiStorerecvFreeReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Store/recvFreeReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取成长礼包奖励
     * data传 growUpConfig id
     */
    static apiStorerecvGrowUp(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Store/recvGrowUp',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取犒赏系列礼包奖励
     * 注意！若返回体data为null表示该id没有可以领取的奖励！,请求体data传kaoshangConfig的ID,服务端根据ID自行判断类型，会领取当前配置进度之前的所有可以领取的奖励（没领过的且可领取的奖励）
     */
    static apiStorerecvKsReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Store/recvKsReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取月、周、终生卡卡奖励
     * data传 0:普通月卡 1:超级月卡 2:周卡 3:终生卡
     */
    static apiStorerecvMonthCard(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Store/recvMonthCard',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取新手基金奖励
     * data传 sevenDayfundconfig id
     */
    static apiStorerecvSevenFund(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Store/recvSevenFund',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取Vip奖励
     * data填需要领取的VIP等级
     */
    static apiStorerecvVipReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Store/recvVipReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取战令奖励
     * 注意！若返回体data为null表示该id没有可以领取的奖励！,请求体data传stageRewardConfig的ID,服务端根据ID自行判断类型，会领取当前配置进度之前的所有可以领取的奖励（没领过的且可领取的奖励）
     */
    static apiStorerecvWarOrderReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/Store/recvWarOrderReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买智慧树商店商品
     * 
     */
    static apiWisdomTreebuy(
        
        
        data:WisdomBuyReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/WisdomTree/buy',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取智慧树守卫奖励
     * 
     */
    static apiWisdomTreegetGuardReward(
        
        
        data:WisdomGuardRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/WisdomTree/getGuardReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取智慧树层宝箱奖励
     * data填第几层
     */
    static apiWisdomTreegetLayerReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/WisdomTree/getLayerReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取智慧树云端数据
     * data随便传
     */
    static apiWisdomTreegetWisdomExtra(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:Map<string,object>
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/WisdomTree/getWisdomExtra',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取（生成）所有智慧树地图数据
     * data随便传
     */
    static apiWisdomTreegetWisdomMaps(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:WisdomMapBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/WisdomTree/getWisdomMaps',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置智慧树云端数据
     * 键值对，同键数据若存在，用新数据覆盖
     */
    static apiWisdomTreeputWisdomExtra(
        
        
        data:KeyValueReq[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:object
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/WisdomTree/putWisdomExtra',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 使用复活道具
     * 由于为单纯的消耗，此处返回被消耗道具的最新数值
     */
    static apiWisdomTreerebornGoodUse(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GoodVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/WisdomTree/rebornGoodUse',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 使用复活视频
     * 返回新的剩余可用次数
     */
    static apiWisdomTreerebornVideoUse(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/WisdomTree/rebornVideoUse',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 刷新智慧树商店数据
     * data填需要提升的刷新等级
     */
    static apiWisdomTreerefreshShops(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:WisdomMapBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/WisdomTree/refreshShops',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 更新智慧树节点数据
     * data随便传
     */
    static apiWisdomTreeupdateWisdomNodeArr(
        
        
        data:WisdomNodeUpdateReq[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/WisdomTree/updateWisdomNodeArr',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 点击战斗，返回战斗数据,异步计算战斗结果
     * data竞技场战斗开始数据请求模型
     */
    static apiarenaadvbattle(
        
        
        data:ArenaAdvBattleReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:Battle_ArenaData_Mul
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/adv/battle',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 我的高阶竞技场排名
     * data值无实际意义
     */
    static apiarenaadvmyRank(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RoleRankVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/adv/myRank',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 通用 - 战斗回放,返回战斗数据链接地址
     * 
     */
    static apiarenaadvplayback(
        
        
        data:PlayBackReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/adv/playback',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 高阶战斗记录
     * 
     */
    static apiarenaadvrecord(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ArenaAdvRecordVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/adv/record',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取角斗士币
     * data无意义
     */
    static apiarenaadvrecvAdvCoin(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/adv/recvAdvCoin',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取战斗结果
     * data传战斗系列编号
     */
    static apiarenaadvresult(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:AdvBattleReportVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/adv/result',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 点击战斗，返回战斗数据,异步计算战斗结果
     * data竞技场战斗开始数据请求模型
     */
    static apiarenabattle(
        
        
        data:ArenaBattleReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:Battle_ArenaData
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/battle',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买门票
     * data传购买数量
     */
    static apiarenabuyTickets(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/buyTickets',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 通用-获取防守阵容等数据信息
     * data竞技场数据请求模型,对手角色roleId空字符串或空表示获取自己数据
     */
    static apiarenadefendHero(
        
        
        data:ArenaReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RoleDefendVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/defendHero',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 普通竞技场-刷新匹配结果并匹配
     * data随便传
     */
    static apiarenafreshMatch(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/freshMatch',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 通用 - 发起挑战,匹配对手，返回对手信息列表
     * data竞技场类型0普通 1高阶
     */
    static apiarenamatch(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/match',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 我的竞技场排名
     * data值无实际意义
     */
    static apiarenamyRank(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RoleRankVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/myRank',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 战斗回放,返回战斗数据链接地址
     * data传战斗编号
     */
    static apiarenaplayback(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/playback',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 通用-竞技场排行榜
     * data竞技场类型0普通 1高阶
     */
    static apiarenarank(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/rank',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 通用-上期竞技场排行榜 TOP10
     * data竞技场类型-1全部竞技场 0普通 1高阶
     */
    static apiarenarankLast(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/rankLast',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 战斗记录
     * data
     */
    static apiarenarecord(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ArenaRecordVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/record',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取战斗结果
     * data传战斗编号
     */
    static apiarenaresult(
        
        
        data:long,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/result',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 复仇，返回战斗数据
     * data请求模型
     */
    static apiarenarevenge(
        
        
        data:ArenaRevengeReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:Battle_ArenaData
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/revenge',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 通用-防守阵容设置
     * data竞技场数据请求模型
     */
    static apiarenasetDefendHero(
        
        
        data:ArenaReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/arena/setDefendHero',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 解锁神器（已经拥有时，返回DATA NULL）
     * data填神器ConfigId
     */
    static apiartifactartifactUnlock(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/artifact/artifactUnlock',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取神器解锁进度
     * 随便填，data返回中 "-99":神器祭坛经验，可用于计算神器祭坛等级
     */
    static apiartifactartifactUnlockInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:{[key:number]:long}
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/artifact/artifactUnlockInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 交换两位英雄所佩戴的神器
     * 
     */
    static apiartifactchangeArtifact(
        
        
        data:ChangeArtifactReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/artifact/changeArtifact',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 锻造神器
     * 
     */
    static apiartifactforgeArtifact(
        
        
        data:ArtifactForgeReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:StrengArtifactVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/artifact/forgeArtifact',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 接受锻造转化
     * 需要先进行转化预览消耗资源才能接受转化
     */
    static apiartifactforgeChange(
        
        
        data:ArtifactForgeReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:StrengArtifactVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/artifact/forgeChange',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 锻造转化预览(消耗资源)
     * 
     */
    static apiartifactforgeChangePre(
        
        
        data:ArtifactForgeReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:Map<int,KeyValueBO<int,double>>
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/artifact/forgeChangePre',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 升级神器祭坛
     * 
     */
    static apiartifactlvUpArtifact(
        
        
        data:LvUpArtifactReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/artifact/lvUpArtifact',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 强化神器
     * data填神器ID
     */
    static apiartifactstrengArtifact(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:StrengArtifactVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/artifact/strengArtifact',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 脱神器
     * data填heroId
     */
    static apiartifactunArtifact(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/artifact/unArtifact',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 佩戴神器
     * 
     */
    static apiartifactwearArtifact(
        
        
        data:WearArtifactReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/artifact/wearArtifact',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取我的背包内容
     * data随便填写
     */
    static apibaggetMyBags(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:BagVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/bag/getMyBags',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取指定Id道具列表
     * data为数组，填写要获取的类型，goods配置表中的Id，空数组或NULL表示获取全部
     */
    static apibaggetTypeGoods(
        
        
        data:Array<int>,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GoodVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/bag/getTypeGoods',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 使用背包道具
     * 
     */
    static apibaguseGoods(
        
        
        data:GoodUseReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/bag/useGoods',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取克隆大作战信息
     * data随便填
     */
    static apiclonebatcloneInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:CloneBatVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/clonebat/cloneInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 刷新克隆大作战英雄池
     * data随便填
     */
    static apiclonebatfreshClone(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:CloneBatVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/clonebat/freshClone',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 克隆大作战结果提交
     * 
     */
    static apiclonebatpassClone(
        
        
        data:CloneBatSubmitReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/clonebat/passClone',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 刷新助力英雄
     * 请求data填英雄confId data返回新的次数
     */
    static apidungeondungeonHelpFresh(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/dungeon/dungeonHelpFresh',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取关卡一次性奖励
     * 
     */
    static apidungeondungeonOneThingRecv(
        
        
        data:DungeonRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/dungeon/dungeonOneThingRecv',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取地牢通关奖励
     * 
     */
    static apidungeondungeonPassRecv(
        
        
        data:DungeonRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/dungeon/dungeonPassRecv',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取地牢事件奖励
     * 
     */
    static apidungeongetDungeonEventReward(
        
        
        data:DungeonRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/dungeon/getDungeonEventReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取地牢详情
     * data填英雄ConfigId
     */
    static apidungeongetDungeonInfo(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:DungeonInfoBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/dungeon/getDungeonInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置地牢云端数据
     * 键值对，同键数据若存在，用新数据覆盖
     */
    static apidungeonputDungeonExtra(
        
        
        data:WonderExtraReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/dungeon/putDungeonExtra',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置地牢云端持久化数据
     * 键值对，同键数据若存在，用新数据覆盖
     */
    static apidungeonputDungeonExtraSave(
        
        
        data:WonderExtraReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/dungeon/putDungeonExtraSave',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 放弃重铸
     * 会记录指定装备的放弃阵营加成
     */
    static apiequipcancelRecast(
        
        
        data:EquipRecastReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:int
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/cancelRecast',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 交换两位英雄所佩戴的装备
     * 
     */
    static apiequipchangeEquips(
        
        
        data:EquipChangeReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/changeEquips',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 装备充能
     * 
     */
    static apiequipchargeEquip(
        
        
        data:EquipLvUpReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:StrengEquipVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/chargeEquip',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 合成
     * resourceVO.extra[0]为新的EquipBO[],resourceVO.extra[1]为新的HeroVO[](数量由参与合成的装备是否在英雄身上而定)
     */
    static apiequipcompoundBatch(
        
        
        data:EquipCompReq[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/compoundBatch',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 智能合成
     * 所有装备都不可为穿在身上的装备,被消耗的装备请自行删除
     */
    static apiequipcompoundIntelli(
        
        
        data:EquipCompIntelliItem[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/compoundIntelli',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 分解装备
     * 批量分解，data传装备IDs
     */
    static apiequipdecompEquip(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/decompEquip',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 分解预览
     * 批量分解，data传装备IDs
     */
    static apiequipdecompPre(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RewardBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/decompPre',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取指定装备上次重铸放弃的属性
     * data填装备唯一ID，返回属性结果 -1表示没有历史记录
     */
    static apiequipgetCancelRecast(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:int
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/getCancelRecast',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 装备继承
     * resourceVO.extra[0]为新的EquipBO[],resourceVO.extra[1]为新的HeroVO[](数量由参与继承的装备是否在英雄身上而定)
     */
    static apiequipinheritEquips(
        
        
        data:EquipInheritReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/inheritEquips',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 装备强化
     * 
     */
    static apiequiplvUpEquip(
        
        
        data:EquipLvUpReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:StrengEquipVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/lvUpEquip',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 重铸
     * 
     */
    static apiequiprecastEquip(
        
        
        data:EquipRecastReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:StrengEquipVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/recastEquip',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 重生装备
     * 批量重生，data传装备IDs,消耗的钻石需要客户端自行扣除，data传装备IDs,resourceVO.extra[0]为新的EquipBO[]
     */
    static apiequipresetEquip(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/resetEquip',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 重生预览
     * 批量重生，data传装备IDs
     */
    static apiequipresetPre(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RewardBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/resetPre',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 装备升星
     * 
     */
    static apiequipstarUpEquip(
        
        
        data:EquipStarUpReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:StrengEquipVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/starUpEquip',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 脱装备
     * 按英雄部位脱去装备
     */
    static apiequipunEquip(
        
        
        data:UnEquipReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/unEquip',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 佩戴最佳装备（一键穿装）
     * data填写heroId
     */
    static apiequipwearBestEquips(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/wearBestEquips',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 佩戴装备
     * 
     */
    static apiequipwearEquips(
        
        
        data:WearEquipReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/equip/wearEquips',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 替换扭蛋大奖
     * data填niudanheroconfig-id
     */
    static apigashaponchangeFinal(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GashaponVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/gashapon/changeFinal',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 扭蛋
     * data填
     */
    static apigashapongopon(
        
        
        data:GashaponReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/gashapon/gopon',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取扭蛋信息
     * data随便填
     */
    static apigashaponponInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GashaponVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/gashapon/ponInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取新手七日光环领取详情
     * 
     */
    static apigiftgetNewSevenDetail(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:TaskSevenNewVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/gift/getNewSevenDetail',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取新手七日光环奖励
     * data传id(SevendayschargeConfig表中)
     */
    static apigiftgetNewSevenReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/gift/getNewSevenReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取在线奖励领取详情
     * 
     */
    static apigiftgetOnlineDetail(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:TaskInfoVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/gift/getOnlineDetail',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取在线奖励
     * data传ud(onlinegiftconfig表中)
     */
    static apigiftgetOnlineReward(
        
        
        data:OnlineGiftRecvReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/gift/getOnlineReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取七日签到数据
     * 一共七日，返回体中，缺失的Day表示没有资格领取，角色的累计登录天数 查看roleVO
     */
    static apigiftgetSevenDayInfo(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:SevenDaySignInfoVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/gift/getSevenDayInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取七日签到奖励
     * Data填获取第几天的奖励
     */
    static apigiftrecvSevenDay(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/gift/recvSevenDay',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 任命职位
     * data
     */
    static apiguildappointGuildJob(
        
        
        data:AppointGuildReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/appointGuildJob',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 更改公会头像
     * data填新的头像,返回data新的公会信息
     */
    static apiguildchangeAvatar(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/changeAvatar',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 更改入会等级
     * data填新的入会等级,返回data新的公会信息
     */
    static apiguildchangeEnterLv(
        
        
        data:long,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/changeEnterLv',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 更改入会模式
     * data填新的入会要求 0所有人可加入 1批准加入 2不可加入,返回data新的公会信息
     */
    static apiguildchangeEnterMode(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/changeEnterMode',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 更改公会公告
     * data填新的公告,返回data新的公会信息
     */
    static apiguildchangeNotice(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/changeNotice',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 转转盘
     *  返回data为ResourceVO,已转次数请客户端本地自行+1，此处不返回了
     */
    static apiguildchoseTable(
        
        
        data:TurnTableGoReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/choseTable',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 创建公会
     * data
     */
    static apiguildcreateGuild(
        
        
        data:GuildCreateReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/createGuild',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 解散公会（解散自己是会长的公会）
     * data随便填，该接口会解散自己是会长的公会,成功返回原公会成员roleids
     */
    static apiguilddisbanGuild(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/disbanGuild',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 退出公会
     * data随便填
     */
    static apiguildexitFromGuild(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/exitFromGuild',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 查找公会（根据id或名字，精确搜索）
     * 返回体data为公会详情数组（存在ID和名字都符合的，都返回），若无结果为空数组
     */
    static apiguildfindGuild(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/findGuild',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 根据公会ID获取公会基础信息
     * 若无结果为空数组
     */
    static apiguildfindGuildSimple(
        
        
        data:GuildSimpleReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildSimpleVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/findGuildSimple',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取推荐
     * 返回体data为公会详情数组，若无结果为空数组
     */
    static apiguildfindRecommand(
        
        
        data:GuildRecommandReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/findRecommand',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取公会入会申请
     * 返回data：申请名单
     */
    static apiguildgetApplyList(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RoleVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/getApplyList',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取公会科技详情
     * data随便填，返回已经开启的公会科技配置表ID列表
     */
    static apiguildgetGTechInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GTechBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/getGTechInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取公会雕像加成信息
     * 随便填
     */
    static apiguildgetGuildStetueInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildStatueBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/getGuildStetueInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取雕像强化日志
     * data随便填
     */
    static apiguildgetstatuelog(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildStatueRecVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/getstatuelog',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 赠送互助礼包
     * data填目标RoleId,返回extra[0]为目标最新接收次数
     */
    static apiguildhelpSend(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/helpSend',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 弹劾会长
     * data随便填 返回新的会长roleId
     */
    static apiguildimpeachGuildBoss(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/impeachGuildBoss',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 踢出成员
     * data填需要踢出的roleId,成功返回被踢出的roleId
     */
    static apiguildkickFromGuild(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/kickFromGuild',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 升级公会科技
     * data填要升级的科技techUid，会检测前置条件并进行升级消耗，升1级,返回新的全量公会加成
     */
    static apiguildlvUpGTech(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroModulBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/lvUpGTech',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 处理公会申请
     * 返回data：新的申请名单
     */
    static apiguildoptApply(
        
        
        data:GuildApplyOptReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildOptVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/optApply',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 修改公会名
     * data
     */
    static apiguildrenameGuild(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/renameGuild',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 重置公会科技
     * data填要重置的公会科技大类【factiontechconfig.techtype】
     */
    static apiguildresetGTech(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/resetGTech',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 发送公会邮件
     * 返回data：发送的人数
     */
    static apiguildsendGuildMail(
        
        
        data:GuildMailSendReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/sendGuildMail',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 强化雕像
     * 
     */
    static apiguildstrengStatue(
        
        
        data:GuildStatueStrengReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildStrengBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/strengStatue',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 发起公会申请
     * data填公会id 返回data：已经申请的公会列表,为null表示该公会申请可直接加入，加入已经成功
     */
    static apiguildsubmitApply(
        
        
        data:long,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/submitApply',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 转让会长
     * data填要转让的RoleId 返回新的会长roleId
     */
    static apiguildtransGuildBoss(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/transGuildBoss',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取转盘信息
     * data随便填
     */
    static apiguildturnTableInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildTableInfoVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/turnTableInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 雕像视频BUFF激活
     * data：强化雕像部位 statueRankConfig-statueType
     */
    static apiguildvideoStatue(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildStatuePartBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild/videoStatue',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 开始战斗，锁资源点
     * 返回体为当前资源点最新信息
     */
    static apiguild_hegebatStart(
        
        
        data:GHegeHitReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildHegeNodeBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_hege/batStart',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买体力
     * data填购买次数，一次购买的体力值根据配置变更
     */
    static apiguild_hegebugTili(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildHegeMapBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_hege/bugTili',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 收集资源点积分
     * data传 需要收取的资源点的nodeIds
     */
    static apiguild_hegecollectScore(
        
        
        data:int[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildHegeMapBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_hege/collectScore',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取公会争霸基础信息
     * data随便填，返回体data为null表示没有达到开启条件
     */
    static apiguild_hegefindHege(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildHegeBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_hege/findHege',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取公会争霸地图信息（多个）
     * data填所要获取的节点ID factionBattleConfig.Ids，返回体data为null表示没有达到开启条件
     */
    static apiguild_hegefindHegeMap(
        
        
        data:int[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildHegeNodeBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_hege/findHegeMap',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取公会争霸地图信息（总）
     * data随便填，返回体data为null表示没有达到开启条件
     */
    static apiguild_hegefindHegeMaps(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildHegeMapBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_hege/findHegeMaps',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 查询资源点某条进攻记录的阵容
     * 
     */
    static apiguild_hegefindRecHero(
        
        
        data:GHegeRecHeroReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildHegeNodeHeroBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_hege/findRecHero',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 报名参加公会争霸
     * data随便填，返回体data为null表示没有达到开启条件
     */
    static apiguild_hegesignHege(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildHegeBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_hege/signHege',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 提交资源点战斗结果
     * 
     */
    static apiguild_hegesubmitHege(
        
        
        data:GHegeHitReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GuildHegeMapBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_hege/submitHege',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取公会副本信息
     * data随便填，返回体data为null表示没有达到开启条件
     */
    static apiguild_journeyfindGJourney(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GJourneyBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_journey/findGJourney',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取公会副本基础信息
     * data随便填，返回体data为null表示没有达到开启条件
     */
    static apiguild_journeyfindSimpleGJourney(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:GJourneyBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_journey/findSimpleGJourney',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取讨伐奖励
     * 
     */
    static apiguild_journeyrecvCompleteReward(
        
        
        data:GJourneyCompleteRecvReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_journey/recvCompleteReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取通关成就奖励
     * data填需要领取的通关奖励对应的副本等级
     */
    static apiguild_journeyrecvOncePassReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_journey/recvOncePassReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 提交公会副本成绩
     * 返回data null表示公会没有开启公会副本
     */
    static apiguild_journeysubmitJourney(
        
        
        data:GJourneyHitReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/guild_journey/submitJourney',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取挂机收益
     * data随便填,返回null表示挂机时间小于1分钟，无收益，挂机时间不重置，相当于本次接口调用没有产生任何影响
     */
    static apihangUpgetHangUpProduce(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HangUpProduceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hangUp/getHangUpProduce',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取挂机速度和快速挂机价格
     * data随便填
     */
    static apihangUpgetHangUpSpeed(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HangUpSpeedBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hangUp/getHangUpSpeed',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 快速挂机
     * data随便填
     */
    static apihangUpgoQuickHangUp(
        
        
        data:boolean,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HangUpProduceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hangUp/goQuickHangUp',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 英雄回退
     * data填写HeroId 新的HeroVO见ResourceVO.extra[0] 脱下的装备及消耗的资源需要自行计算
     */
    static apiheroback(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/back',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 英雄回退预览
     * data填写HeroId 脱下的装备及消耗的资源需要自行计算
     */
    static apiherobackPre(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RewardBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/backPre',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买共享花坛格子
     * 
     */
    static apiherobuyFlowerPlace(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FlowerPlaceInfoVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/buyFlowerPlace',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 放弃本次置换
     * 
     */
    static apiherocancelHeroChange(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/cancelHeroChange',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 提交置换并获取新英雄
     * 
     */
    static apiherochangeHero(
        
        
        data:HeroChangeEnterReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/changeHero',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取英雄置换结果并消耗资源
     * 
     */
    static apiherochangeHeroRandom(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:int
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/changeHeroRandom',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 英雄合成（批量）
     * 合成后为无装备、无神器的裸英雄，属性为裸属性
     */
    static apiherocompoundBatch(
        
        
        data:RankUpHeroReq[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/compoundBatch',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 英雄遣散
     * 
     */
    static apiherodemobHero(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/demobHero',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取神器祭坛及共鸣加成数据
     * data传空字符串或空表示获取自己
     */
    static apiherogetArtifactAltarAdd(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroModulBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getArtifactAltarAdd',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取花坛共享装备加成
     * data传空字符串或空表示获取自己
     */
    static apiherogetFlowerEquipAdd(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FlowerEquipItemBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getFlowerEquipAdd',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取共享花坛信息
     * 
     */
    static apiherogetFlowerPlaceInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FlowerPlaceInfoVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getFlowerPlaceInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取公会科技加成数据
     * data传空字符串或空表示获取自己
     */
    static apiherogetGTechAdd(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroModulBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getGTechAdd',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取英雄图鉴
     * data传空字符串或空表示获取自己
     */
    static apiherogetHeroBook(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroBookVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getHeroBook',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取英雄图鉴奖励
     * data传已点亮未领取过奖励的英雄confId
     */
    static apiherogetHeroBookReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getHeroBookReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取英雄羁绊加成数据【非图书馆】
     * data传空字符串或空表示获取自己
     */
    static apiherogetHeroFetterAdd(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FetterAddBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getHeroFetterAdd',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取英雄皮肤加成数据
     * data传空字符串或空表示获取自己
     */
    static apiherogetHeroSkinAdd(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:TalentAddVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getHeroSkinAdd',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取英雄数据
     * data传空字符串或空表示获取自己
     */
    static apiherogetHeros(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroBagVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getHeros',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取勋章等级加成数据
     * data传空字符串或空表示获取自己
     */
    static apiherogetMedalAdd(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroModulBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getMedalAdd',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取战略树加成数据
     * data传空字符串或空表示获取自己
     */
    static apiherogetStrategicAdd(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroModulBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getStrategicAdd',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取自己的某几种英雄数据
     * data传空或null表示拉取所有，传configId数组拉数组内type
     */
    static apiherogetTypeHeros(
        
        
        data:Array<int>,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroBagVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/getTypeHeros',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 锁定英雄
     * data填写HeroId，返回新的HeroVO
     */
    static apiherolock(
        
        
        data:UpdateLockReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/lock',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 英雄升级
     * 由于升级只改变英雄裸属性，不反回模块加成部分，请客户端同学不要由于返回中的模块加成为空清空模块加成
     */
    static apiherolvUpV2(
        
        
        data:HeroLvUpReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroLvUpVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/lvUpV2',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 英雄升阶
     * 由于升阶只改变英雄裸属性，不反回模块加成部分，请客户端同学不要由于返回中的模块加成为空清空模块加成
     */
    static apiherorankUp(
        
        
        data:RankUpHeroReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/rankUp',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 英雄升阶（批量）
     * 由于升阶只改变英雄裸属性，不反回模块加成部分，请客户端同学不要由于返回中的模块加成为空清空模块加成
     */
    static apiherorankUpBatch(
        
        
        data:RankUpHeroReq[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/rankUpBatch',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 英雄重置
     * data填写HeroId 新的HeroVO见ResourceVO.extra[0] 脱下的装备及消耗的资源需要自行计算
     */
    static apiheroreset(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/reset',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 英雄重置预览
     * data填写HeroId, 脱下的装备及消耗的资源需要自行计算
     */
    static apiheroresetPre(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RewardBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/resetPre',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 英雄升星（批量）
     * 由于升星只改变英雄裸属性，不反回模块加成部分，请客户端同学不要由于返回中的模块加成为空清空模块加成
     */
    static apiherostarUpBatch(
        
        
        data:RankUpHeroReq[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/starUpBatch',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 更新英雄共享花坛状态
     * 
     */
    static apiheroupdateFlowerPlace(
        
        
        data:UpdateFlowerReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hero/updateFlowerPlace',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买Boss挑战次数
     * 这是个返回结果没有意义的接口，成功返回bossId
     */
    static apihuntbuyBossCount(
        
        
        data:HuntHitReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HuntBossVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hunt/buyBossCount',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 狩猎校验
     * 用于预检查狩猎条件和获取奖励预生成列表，data传bossType
     */
    static apihuntcheckHunt(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hunt/checkHunt',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取狩猎BOSS详情
     * data传boss类型，空或null表示获取所有，请求了对应类型但返回中没有，表示未开启
     */
    static apihuntgetBossInfo(
        
        
        data:int[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HuntBossVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hunt/getBossInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取狩猎日志
     * 
     */
    static apihuntgetHuntRecord(
        
        
        data:HuntRecordReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HuntRecordVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hunt/getHuntRecord',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 提交狩猎结果
     * 
     */
    static apihuntgoHunt(
        
        
        data:HuntHitReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hunt/goHunt',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 开启毒箭木
     * 这是个返回结果没有意义的接口，成功返回bossId
     */
    static apihuntstartHuntJH(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HuntBossVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/hunt/startHuntJH',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    /**
     * addArtifact
     * 
     */
    static apiindexaddArtifact(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/addArtifact',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * addEquip
     * 
     */
    static apiindexaddEquip(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/addEquip',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    /**
     * addHero
     * 
     */
    static apiindexaddHero(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/addHero',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    
    /**
     * 更改服务端API版本支持范围
     * 0表示不修改
     */
    static apiindexchangeVersionMap(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/changeVersionMap',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    
    
    /**
     * 清空智慧树地图缓存
     * 清空的层数，0表示所有
     */
    static apiindexclearWisMapCache(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/clearWisMapCache',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    
    /**
     * convertToMap
     * 
     */
    static apiindexconvertFromMap(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/convertFromMap',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * convertToMap
     * 
     */
    static apiindexconvertToMap(
        
        
        data:null,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/convertToMap',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * culJourney
     * 
     */
    static apiindexculJourney(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/culJourney',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    
    
    
    /**
     * 测试进度查询
     * data为需要查询的子系统（副本）
     */
    static apiindexgetProcess(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/getProcess',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    
    
    
    /**
     * 增加/扣除公会活跃度
     * data传要增加多少，负数为扣除
     */
    static apiindexincGuildActiveScore(
        
        
        data:long,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/incGuildActiveScore',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    
    
    
    /**
     * 将输入的玩家数据还原到指定账号中
     * roleId填写需要还原的目标roleId
     */
    static apiindexrecoverRoleData(
        
        
        data:null,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/recoverRoleData',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    /**
     * refreshEquipModul
     * 
     */
    static apiindexrefreshEquipModul(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/refreshEquipModul',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 测试装备删除
     * data为需要移除的装备IDS
     */
    static apiindexremoveEquipTest(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/removeEquipTest',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    /**
     * sendMail
     * 
     */
    static apiindexsendMail(
        
        
        data:null,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/sendMail',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 测试奖励装备发放
     * data为需要发放的奖励配置
     */
    static apiindexsendRewardEquip(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/sendRewardEquip',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 测试奖励物品发放
     * data为需要发放的奖励配置
     */
    static apiindexsendRewardGoods(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/sendRewardGoods',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 测试奖励英雄发放
     * data为需要发放的奖励配置
     */
    static apiindexsendRewardHero(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/sendRewardHero',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 发送测试跑马灯
     * 
     */
    static apiindexsendTestMarquee(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/sendTestMarquee',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    
    /**
     * 设置狩猎次数
     * 公会ID，角色ID，BOSS类型，BOSSID，新的次数
     */
    static apiindexsetHuntHurtCount(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/setHuntHurtCount',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    
    
    
    /**
     * 修改天赋点
     * post体index：0普通 1中级 2高级，返回新的天赋剩余情况
     */
    static apiindexsetTalentPoint(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/setTalentPoint',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    
    /**
     * 同步短ID数据到Ipirate
     * 
     */
    static apiindexsyncShortIdToIpirate(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/syncShortIdToIpirate',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * test
     * 
     */
    static apiindextest(
        
        
        data:Battle_heroConfig[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/test',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 更新地牢进度
     * data传levelId
     */
    static apiindexupdateDungeonProcess(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/updateDungeonProcess',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 更新阵营积分
     * data无实际意义
     */
    static apiindexupdateFactionScore(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/updateFactionScore',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 测试点亮图鉴
     * data为数组，填写hero配置表中的id
     */
    static apiindexupdateHeroBook(
        
        
        data:any,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/updateHeroBook',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 更新角色主线进度
     * data传修改stageId
     */
    static apiindexupdateMainProcess(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/updateMainProcess',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 更新角色摩天楼进度
     * data传层数
     */
    static apiindexupdateTowerProcess(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/index/updateTowerProcess',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 开启某个羁绊
     * data输入需要激活的libararyconfig-jibanId
     */
    static apilibraactiveFetter(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FetterAddBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/libra/activeFetter',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 开启某个英雄羁绊
     * data输入需要激活的jibanconfig-Id
     */
    static apilibraactiveHeroFetter(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FetterAddBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/libra/activeHeroFetter',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取图书馆羁绊加成信息
     * 随便填
     */
    static apilibragetFetterInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:FetterAddBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/libra/getFetterInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 删除邮件
     * para 邮件id
     */
    static apimaildelete(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/mail/delete',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 一键删除
     * 
     */
    static apimaildeleteAll(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/mail/deleteAll',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取邮件列表
     * 
     */
    static apimaillist(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:MailVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/mail/list',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取奖励
     * para 邮件id
     */
    static apimailreceive(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/mail/receive',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 一键领取全部奖励
     * para 无实际意义
     */
    static apimailreceiveAll(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/mail/receiveAll',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 发送邮件
     * para 邮件id
     */
    static apimailsend(
        
        
        data:MailSendReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:MailVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/mail/send',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置已读
     * para 邮件id
     */
    static apimailsetRead(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/mail/setRead',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 提交佣兵申请请求
     * data随便填
     */
    static apimercapplyForMerc(
        
        
        data:MercApplyReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/merc/applyForMerc',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 取消佣兵申请请求
     * data随便填
     */
    static apimerccancelForMerc(
        
        
        data:MercApplyReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/merc/cancelForMerc',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取向我提交的佣兵申请列表
     * data随便填
     */
    static apimercgetMercApplyToMe(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:MercApplyVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/merc/getMercApplyToMe',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取所有佣兵列表
     * data随便填
     */
    static apimercgetMercList(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:MercInfoVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/merc/getMercList',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 增加使用次数
     * 返回新的佣兵列表
     */
    static apimercincMercUse(
        
        
        data:MercUseIncReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HeroVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/merc/incMercUse',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取已经借出的英雄列表
     * 返回借出的英雄信息
     */
    static apimercmyMercOut(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:MercOutVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/merc/myMercOut',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 一键 同意/忽略 佣兵申请
     * data填true同意，false拒绝
     */
    static apimercoptAllMercApply(
        
        
        data:boolean,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:MercApplyVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/merc/optAllMercApply',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 同意/忽略 佣兵申请
     * 返回新的申请列表，当一个hero的申请被同意，其它此hero的申请会自动处理为忽略
     */
    static apimercoptMercApply(
        
        
        data:MercOptApplyReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:MercApplyVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/merc/optMercApply',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 归还英雄
     * data填要归还的heroId
     */
    static apimercretrunBackMerc(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/merc/retrunBackMerc',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 订单查询接口
     * 
     */
    static apipaycheckTrade(
        
        
        data:PayOrderReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:PayOrderDO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/pay/checkTrade',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 给力支付回调
     * 处理成功返回字符串'success'否则'fail'
     */
    static apipaymrgleecall(
        
        
        data:null,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:null
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/pay/mrgleecall',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 提交关卡失败
     * 系统类型 1主线副本 2摩天楼 3武装 4机械 5变种 6僵尸
     */
    static apiprocessfailProcess(
        
        
        data:ProcessReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/process/failProcess',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 我的外援英雄
     * data传空字符串或空
     */
    static apiprocessgetHelpHeros(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HelpHeroVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/process/getHelpHeros',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 外援我滴英雄列表
     * data传空字符串或空
     */
    static apiprocessgetHelpMeHeros(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:HelpHeroVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/process/getHelpMeHeros',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 进度查询
     * data系统类型 空字符串表示查所有， 1主线副本 2摩天楼 3武装 4机械 5变种 6僵尸 7地牢 8金币副本 9经验副本 10铸币副本 11强化石副本 12灵魂石副本
     */
    static apiprocessgetProcess(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/process/getProcess',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 过关进入下一关卡
     * 
     */
    static apiprocesspassProcess(
        
        
        data:ProcessReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/process/passProcess',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置外援英雄
     * data传英雄唯一Id
     */
    static apiprocesssetHelpHeros(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/process/setHelpHeros',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取周期活动排行信息
     * 
     */
    static apirankgetCycleActRank(
        
        
        data:RankListReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankListVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rank/getCycleActRank',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取排行榜奖励
     * data 排行榜请求模型
     */
    static apirankgetRankReward(
        
        
        data:RankReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rank/getRankReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 我的自定义排行榜排名
     * 
     */
    static apirankmyGameRank(
        
        
        data:RankListReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankListVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rank/myGameRank',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 我的排行榜排名
     * data值无意义
     */
    static apirankmyRank(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rank/myRank',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 排行榜TOP 50
     * data传对应排行榜类型
     */
    static apirankrank(
        
        
        data:RankReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rank/rank',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取所有排行榜的top1
     * data传对应排行榜类型
     */
    static apirankrankAllTop(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rank/rankAllTop',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 排行榜奖励开启、领取信息
     * data排行榜请求模型
     */
    static apirankrankRewardInfo(
        
        
        data:RankReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankRewardInfoBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rank/rankRewardInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 排行榜首位奖励完成玩家信息
     * data 排行榜请求模型，返回模型的no为配置表对应的奖励rewardId
     */
    static apirankrankTop(
        
        
        data:RankReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rank/rankTop',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 前五名达成玩家
     * data 排行榜请求模型
     */
    static apirankrankTop5(
        
        
        data:RankReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RankVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rank/rankTop5',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取公会红包列表
     * 
     */
    static apiredpackgetGuildPacks(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RedPackVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/redpack/getGuildPacks',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取红包信息
     * 
     */
    static apiredpackgetPacks(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RedPackVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/redpack/getPacks',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取红包成就进度及领取状态
     * data传ID(statuefreewalletconfig表中)，小于1表示获取全部
     */
    static apiredpackgetRTaskInfo(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RedPackTaskInfoVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/redpack/getRTaskInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取红包
     * data填红包ID
     */
    static apiredpackrecvPack(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/redpack/recvPack',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 发送成就红包
     * data传ID(statuefreewalletconfig表中)
     */
    static apiredpacksendGuildPack(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RedPackVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/redpack/sendGuildPack',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买次数
     * data传type 返回新的已购买次数
     */
    static apirmissionbuyRMissionCount(
        
        
        data:RMissionBuyReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rmission/buyRMissionCount',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取资源副本详情
     * 
     */
    static apirmissiongetRMissionInfo(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RMissonInfoBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rmission/getRMissionInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 回收
     * data传type
     */
    static apirmissionrecycle(
        
        
        data:RMissionCycleReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rmission/recycle',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 扫荡
     * data传type
     */
    static apirmissionsweep(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/rmission/sweep',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 皮肤兑换，碎片
     * 
     */
    static apiskinexchangeSkin(
        
        
        data:WearSkinReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/skin/exchangeSkin',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取皮肤数据
     * 
     */
    static apiskingetSkins(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:SkinBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/skin/getSkins',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 穿戴皮肤
     * 
     */
    static apiskinwearSkin(
        
        
        data:WearSkinReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:boolean
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/skin/wearSkin',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买体力
     * data填购买次数，一次购买的体力值根据配置变更
     */
    static apisupplybugTili(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:SupplyInfoBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/supply/bugTili',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买高级资源点重置次数
     * data填购买几次重置次数
     */
    static apisupplybugreset(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:SupplyInfoBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/supply/bugreset',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 重置高级资源点搜寻次数
     * data随便填
     */
    static apisupplyresetAdvFind(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:SupplyInfoBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/supply/resetAdvFind',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 资源点搜寻
     * 
     */
    static apisupplysupplyGo(
        
        
        data:SupplyGoReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:SupplyGoResVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/supply/supplyGo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取补给站体力信息
     * data随便填
     */
    static apisupplysupplyInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:SupplyInfoBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/supply/supplyInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取某个Role的天赋加成信息
     * 
     */
    static apitalentgetRoleTalentInfo(
        
        
        data:TalentGetReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:TalentSimpleInfoVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/talent/getRoleTalentInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取天赋详情
     * 
     */
    static apitalentgetTalentInfo(
        
        
        data:TalentReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:TalentInfoVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/talent/getTalentInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 点亮天赋
     * 
     */
    static apitalentopenTalentPoint(
        
        
        data:TalentReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:TalentInfoVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/talent/openTalentPoint',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 重置天赋树
     * 结果返回中extra返回新的天赋点数量，【index】0普通点 1中级点 2高级点
     */
    static apitalentresetTalent(
        
        
        data:TalentReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/talent/resetTalent',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取活跃度奖励
     * data传rewardID(activerewardConfig中的id)
     */
    static apitaskgetActiveReward(
        
        
        data:ActiveRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getActiveReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取竞技场相关任务 进度及领取状态
     * 随便填
     */
    static apitaskgetArenaTasksInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ArenaTaskVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getArenaTasksInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取引导任务领取状态
     * data传ID(guidetaskconfig表中)，小于1表示获取全部
     */
    static apitaskgetGTaskInfo(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:MainTaskInfoVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getGTaskInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取引导任务奖励
     * data传ID(guidetaskconfig表中)
     */
    static apitaskgetGTaskReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getGTaskReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取主线任务进度及领取状态
     * data传taskID(taskconfig表中)，小于1表示获取全部
     */
    static apitaskgetMTaskInfo(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:MainTaskInfoVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getMTaskInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取主线任务奖励
     * data传taskID(taskconfig表中)
     */
    static apitaskgetMTaskReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getMTaskReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取战略点任务进度及领取状态
     * data传id(medalstagerewardconfig表中)，小于1表示获取全部
     */
    static apitaskgetMedalTaskInfo(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:MainTaskInfoVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getMedalTaskInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取战略点任务奖励
     * data传ID(medalstagerewardconfig表中)
     */
    static apitaskgetMedalTaskReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getMedalTaskReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取新手七日任务新版进度及领取状态
     * data传id(sevendaysnew表中)，小于1表示获取全部
     */
    static apitaskgetSevenNewTaskInfo(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:MainTaskInfoVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getSevenNewTaskInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取新手七日任务新版奖励
     * data传ID(sevendaysnew表中)
     */
    static apitaskgetSevenNewTaskReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getSevenNewTaskReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取日/周任务进度及领取状态
     * data传ID(dailytaskconfig表中)，小于1表示获取全部
     */
    static apitaskgetTaskInfo(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:TaskVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getTaskInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置日/周任务完成（领取奖励）
     * data传ID(dailytaskconfig表中)，由于目前日/周常没有单独奖励，只有设置完成，该接口返回新的日/周活跃度
     */
    static apitaskgetTaskReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/getTaskReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 增加引导任务进度
     * data返回新的进度
     */
    static apitaskincGTaskProgress(
        
        
        data:TaskProgressSetReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/incGTaskProgress',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取高阶竞技场段位奖励
     * data填rankId,即arenarankconfig-rankId
     */
    static apitaskrecvAdvTopRankReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/recvAdvTopRankReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取赛季挑战次数奖励
     * data填taskId,即arenachallangetimeconfig-id
     */
    static apitaskrecvArenaBcTaskReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/recvArenaBcTaskReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取竞技场历史最高分奖励
     * data填taskId,Arenascorerewardconfig-id
     */
    static apitaskrecvArenaTsTaskReward(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/recvArenaTsTaskReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置账号绑定任务进度
     * 当前进度
     */
    static apitasksetAccountBind(
        
        
        data:long,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/setAccountBind',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置日/周常进度
     * data返回新的进度
     */
    static apitasksetTaskProgress(
        
        
        data:TaskProgressSetReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/task/setTaskProgress',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买搜寻次数
     * data 2摩天楼 3武装 4机械 5变种 6僵尸,返回新的已购买次数
     */
    static apitowerbuySearchCount(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/tower/buySearchCount',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取摩天楼/种族塔搜寻次数信息
     * type 2摩天楼 3武装 4机械 5变种 6僵尸
     */
    static apitowergetSearchInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:BuyCountBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/tower/getSearchInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 搜寻一次摩天楼
     * data 2摩天楼 3武装 4机械 5变种 6僵尸，resourceVO为Null表示当前搜寻的类型没有进度，不会扣除次数
     */
    static apitowergoSearch(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/tower/goSearch',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 关卡好友
     * 
     */
    static apitowernowFriendsv2(
        
        
        data:TowerBattleFindReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:RoleVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/tower/nowFriendsv2',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 关卡信息
     * 
     */
    static apitowernowRecordsv2(
        
        
        data:TowerBattleFindReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ProcessRecordVO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/tower/nowRecordsv2',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 关卡战斗数据信息上传
     * data 请求
     */
    static apitowertowerBattle(
        
        
        data:TowerBattleReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/tower/towerBattle',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 关卡战斗数据信息下载，返回链接地址
     * data 请求
     */
    static apitowertowerBattleData(
        
        
        data:TowerBattleDataReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:string
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/tower/towerBattleData',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 抽取百宝箱
     * 返回resource.extra[0]为本次抽取结果
     */
    static apitreaboxgotrea(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/treabox/gotrea',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取百宝箱信息
     * data随便填
     */
    static apitreaboxtreaboxInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:TreaBoxBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/treabox/treaboxInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 购买普通许愿币
     * data传个数
     */
    static apiturntablebuyWishCoin(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/turntable/buyWishCoin',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 刷新转盘
     * data
     */
    static apiturntablefreshturn(
        
        
        data:TurnTableReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:TurnResVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/turntable/freshturn',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 转盘抽取
     * data
     */
    static apiturntablegoturn(
        
        
        data:TurnTableReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:TurnResVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/turntable/goturn',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取转盘信息
     * data随便填
     */
    static apiturntableturnInfo(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:TurnInfoVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/turntable/turnInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取云对象存储值
     * 通用型云对象存储接口，根据roleId隔离
     */
    static apiutilgetCloudObject(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:{[key:string]:object}
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/util/getCloudObject',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取系统配置（按区服隔离）
     * 获取本区服的一些系统数据
     */
    static apiutilgetSystemConfig(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:Map<string,object>
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/util/getSystemConfig',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取服务器时间(ms)
     * 游戏业务服对时接口，data随便填
     */
    static apiutilgetSystemTime(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/util/getSystemTime',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 删除云对象存储值
     * 通用型云对象存储接口，根据roleId隔离
     */
    static apiutilrmCloudObject(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:int
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/util/rmCloudObject',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置云对象存储值
     * 通用型云对象存储接口，根据roleId隔离
     */
    static apiutilsetCloudObject(
        
        
        data:CloudObjectReq[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:{[key:string]:object}
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/util/setCloudObject',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取所有视频点剩余次数
     * 
     */
    static apivideogetAllVideoCount(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:{[key:number]:long}
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/video/getAllVideoCount',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取指定视频点剩余次数
     * 
     */
    static apivideogetVideoCount(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/video/getVideoCount',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取关卡数据
     * data填spacetimeconfig-id
     */
    static apiwondergetWonderInfo(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:WonderInfoBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/wonder/getWonderInfo',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取关卡总览
     * data随便填
     */
    static apiwondergetWonderList(
        
        
        data:object,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:WonderInfoBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/wonder/getWonderList',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置奇妙时空云端数据
     * 键值对，同键数据若存在，用新数据覆盖
     */
    static apiwonderputWonderExtra(
        
        
        data:WonderExtraReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:object
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/wonder/putWonderExtra',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置奇妙时空云端持久化数据
     * 键值对，同键数据若存在，用新数据覆盖
     */
    static apiwonderputWonderExtraSave(
        
        
        data:WonderExtraReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:object
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/wonder/putWonderExtraSave',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 领取关卡中的宝箱奖励
     * 
     */
    static apiwonderrecvStageReward(
        
        
        data:WonderRewardReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/wonder/recvStageReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 重置关卡
     * data填spacetimeconfig-id
     */
    static apiwonderresetWonder(
        
        
        data:int,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:WonderInfoBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/wonder/resetWonder',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 设置关卡积分进度
     * 返回新的积分
     */
    static apiwondersetWonderScore(
        
        
        data:WonderScoreReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:long
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/wonder/setWonderScore',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取我的任务中英雄列表
     * data传空字符串或空
     */
    static apixsgetMyHeros(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:Set<string>
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/xs/getMyHeros',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取悬赏任务奖励
     * data传派遣任务唯一Id
     */
    static apixsgetReward(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/xs/getReward',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取悬赏任务奖励[批量]
     * 
     */
    static apixsgetRewardMul(
        
        
        data:string[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:ResourceVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/xs/getRewardMul',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 获取悬赏任务列表、进度信息
     * data传空字符串或空
     */
    static apixsgetXsDetail(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:XsVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/xs/getXsDetail',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 快速完成悬赏
     * data传xsId
     */
    static apixsquickXs(
        
        
        data:string,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:XsVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/xs/quickXs',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 刷新悬赏任务列表
     * data传空字符串或空
     */
    static apixsrefreshXs(
        
        
        data:boolean,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:XsConfigBO[]
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/xs/refreshXs',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 派遣悬赏任务
     * data传派遣任务唯一Id和派遣英雄唯一Id
     */
    static apixsstartXs(
        
        
        data:XsReq,
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:XsConfigBO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/xs/startXs',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }

    
    /**
     * 派遣悬赏任务[批量]
     * 
     */
    static apixsstartXsMul(
        
        
        data:XsReq[],
        callback:(data:{
            succeed:boolean,
            code:0|number,
            message:"success"|string,
            ts:number,
		        map_min_v: {
		            min: string;
		            max: string;
		        },            
            errorcode:string,
            data:XsVO
        })=>void,
        modal:boolean=false,errorCallback:(error:any,retry:()=>void)=>void=null){
            this.gameClient.request('api/xs/startXsMul',data,(data)=>{
            callback(data);
        },{modal:modal,errorCallback:errorCallback})
    }


}


